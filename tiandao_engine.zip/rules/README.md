# 規則檔

24 個分類資料夾對應舊專案 rules.py::_GENRE_DIRS。每個分類放 UTF-8 的 .txt 檔。
第一階段只有 cultivation 會放進提示詞（上限 4000 字）；其他分類在移植對應功能時接上。
