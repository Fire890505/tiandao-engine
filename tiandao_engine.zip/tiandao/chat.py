"""聊天版的入口：Python 照原本的程式跑整個回合，模型那一步交給聊天裡的 Claude。

用法（在工作資料夾）：
  python -m tiandao.chat new 名字 性別 [時代]   開世界、建角、開場
  python -m tiandao.chat turn "玩家這句"          玩一回合
  python -m tiandao.chat answer                   Claude 寫好 ai_answer.json 後，接著跑同一回合
  python -m tiandao.chat write                    寫背景內容（物品、傳說、怪談、事端），原程式在背景叫模型寫的那些
  python -m tiandao.chat state                    印角色卡、所在、眼前的人
  python -m tiandao.chat save 檔名                存檔（資料庫壓成一行文字）
  python -m tiandao.chat load 檔名                讀檔

要模型寫字時：印出提示詞、寫進 ai_ask.json，結束碼 3。Claude 照 schema 寫 JSON 到 ai_answer.json，再跑 answer。
回合是單一交易、擲骰照種子固定，所以重跑同一回合結果一樣；前面答過的照順序重放。
"""
from __future__ import annotations

import base64
import gzip
import hashlib
import shutil
import sqlite3
import json
import re
import sys
from pathlib import Path

from .ai.narrators import OllamaNarrator
from .config import PROJECT_ROOT, Settings
from .store.db import connect
from .web.app import App

HOME = Path.cwd() / "棋盤"
DB, STATE, ASK, ANSWER = HOME / "world.db", HOME / "state.json", HOME / "ai_ask.json", HOME / "ai_answer.json"
JOBS, JOB_DB = HOME / "jobs.json", HOME / "job.db"


# ── 錢的顯示（2026-11-23）：程式裡一律記凡人錢、換時代數字不變；給 Claude 和玩家看的照時代換成那個時代的說法 ──
SCALE = {"古代": 20, "現代": 600, "未來": 100}            # 凡人錢 1 → 古代 20 文、現代 600 元、未來 100 點
ERA_OF = {"銀兩": "古代", "元": "現代", "信用點": "未來"}   # 從角色卡的錢名認時代
# 「30 銀兩」或「銀兩 64」（角色卡那種寫法）；一次換完，不會換兩次
MONEY = re.compile(r"(\d[\d,]*)\s*(?:凡人錢|銀兩|信用點|元(?![嬰神氣寶始宵]))|(?<![\u4e00-\u9fff])(?:凡人錢|銀兩|信用點|元)\s*(\d[\d,]*)")
SAID = {"古代": re.compile(r"(?:(\d[\d,]*)\s*兩\s*)?(?:(\d[\d,]*)\s*文)?"),       # 玩家說的錢（顯示用的說法）
        "現代": re.compile(r"(\d[\d,]*)\s*(?:元|塊)(?![嬰神氣寶始宵])"),
        "未來": re.compile(r"(\d[\d,]*)\s*(?:信用點|點)")}


def coin(n: int, era: str) -> str:
    v = round(n * SCALE[era])
    if era == "古代":
        liang, wen = divmod(v, 1000)
        return (f"{liang} 兩" if liang else "") + (f"{' ' if liang else ''}{wen} 文" if wen or not liang else "")
    return f"{v:,} 元" if era == "現代" else f"{v:,} 點"


def show(text: str, era: str) -> str:
    """把程式寫的「N 凡人錢／銀兩／元／信用點」換成顯示用的數字。"""
    if not era:
        return text
    return MONEY.sub(lambda m: coin(int((m[1] or m[2]).replace(",", "")), era), text)


def take(said: str, era: str) -> str:
    """玩家話裡的錢（顯示用的）換成程式的「N 凡人錢」，之後判定、說書都照程式的數字走。"""
    def one(m) -> str:
        if era == "古代":
            if not (m[1] or m[2]):
                return m[0]
            v = int((m[1] or "0").replace(",", "")) * 1000 + int((m[2] or "0").replace(",", ""))
        else:
            v = int(m[1].replace(",", ""))
        return f"{max(1, round(v / SCALE[era]))} 凡人錢"
    return SAID[era].sub(one, said) if era in SAID else said


class BadAnswer(Exception):
    """Claude 的回覆不合格式。"""


class NeedAI(BaseException):
    """BaseException：穿過程式裡的 except Exception，讓整個回合交易回滾，等 Claude 回覆再重跑。"""


class ChatNarrator(OllamaNarrator):
    """跟 Ollama 同一套提示詞、schema、合約檢查；只把「送出去」換成「問 Claude」。"""

    def __init__(self, answers: list[dict], era: str = ""):
        super().__init__("chat", "claude", attempts=1)   # 不合格式不自動重叫：退回給 Claude 看錯在哪、重寫
        self.answers, self.used, self.era = answers, 0, era

    def _prime(self, system: str) -> None:
        pass

    def _chat(self, messages, schema, temperature):
        key = hashlib.sha1(json.dumps(messages, ensure_ascii=False).encode()).hexdigest()[:12]
        while self.used < len(self.answers):
            a = self.answers[self.used]
            self.used += 1
            if a["key"] == key:
                return self._back(a["raw"], messages), 0
        shown = [{**m, "content": show(m["content"], self.era)} for m in messages]
        ASK.write_text(json.dumps({"key": key, "messages": shown, "schema": schema}, ensure_ascii=False, indent=1), "utf-8")
        raise NeedAI(key)

    def _back(self, raw: str, messages) -> str:
        """讀懂玩家的話時，Claude 看到的錢是顯示用的；「數字」欄照玩家話裡那筆換回凡人錢。"""
        said = messages[-1]["content"].rsplit("【玩家的話】", 1)[-1]
        m = re.search(r"(\d+) 凡人錢", said)
        try:
            got = json.loads(raw)
        except ValueError:
            return raw
        if m and isinstance(got, dict) and got.get("數字"):
            got["數字"] = m[1]
            return json.dumps(got, ensure_ascii=False)
        return raw


def _load() -> dict:
    return json.loads(STATE.read_text("utf-8")) if STATE.exists() else {}


def _save(s: dict) -> None:
    STATE.write_text(json.dumps(s, ensure_ascii=False, indent=1), "utf-8")


def _app(answers: list[dict], db: Path = DB, era: str = "") -> App:
    settings = Settings(db_path=db, ai_backend="ollama", rules_dir=PROJECT_ROOT / "rules", frontend_dir=PROJECT_ROOT / "frontend")
    app = App(settings, narrator=ChatNarrator(answers, era))
    app.game.later = lambda job: job()          # 背景工作當場呼叫，但 _alone 只排進待寫清單（下面）
    app.game._alone = _queue
    return app


def _queue(path, job, *args) -> None:
    """原程式在背景叫模型寫物品、傳說、怪談、事端；聊天版先記下來，等 write 指令一件一件寫。"""
    jobs = json.loads(JOBS.read_text("utf-8")) if JOBS.exists() else []
    item = [job.__name__, list(args)]
    if item not in jobs:
        jobs.append(item)
        JOBS.write_text(json.dumps(jobs, ensure_ascii=False), "utf-8")


def _jobs() -> list:
    return json.loads(JOBS.read_text("utf-8")) if JOBS.exists() else []


def _call(s: dict, method: str, path: str, body=None):
    app = _app(s.get("answers", []), era=s.get("era", ""))
    headers = {"Content-Type": "application/json"}
    if s.get("token"):
        headers["Authorization"] = f"Bearer {s['token']}"
    status, _, payload = app.dispatch(method, path, headers, json.dumps(body).encode() if body is not None else b"")
    data = json.loads(payload)
    if status == 502 and data["error"].get("code") == "ai_contract" and s.get("answers"):
        raise BadAnswer(data["error"]["message"])
    if status >= 400:
        raise SystemExit(f"錯誤 {status}：{json.dumps(data, ensure_ascii=False)[:500]}")
    return data


def _ask(s: dict) -> None:
    """印出要 Claude 寫的東西。系統提示詞跟上次印過的一樣就不再印（省用量）。"""
    ask = json.loads(ASK.read_text("utf-8"))
    seen = set(s.get("seen", []))
    for m in ask["messages"]:
        h = hashlib.sha1(m["content"].encode()).hexdigest()[:12]
        if m["role"] == "system" and h in seen:
            print(f"===== system =====\n（同上次印過的系統提示詞 {h}，照它寫）")
            continue
        if m["role"] == "system":
            seen.add(h)
        print(f"===== {m['role']} =====\n{m['content']}")
    s["seen"] = sorted(seen)
    _save(s)
    print("===== 回覆格式（JSON schema）=====")
    print(json.dumps(ask["schema"], ensure_ascii=False))
    print(f"\n請把 JSON 寫進 {ANSWER}，再跑：python -m tiandao.chat answer")
    sys.exit(3)


def _run(s: dict) -> None:
    """跑 s['pending']（一個要做的請求）；要模型時停下來問。"""
    if s["pending"] == ["write"]:
        return _write(s)
    method, path, body = s["pending"]
    try:
        data = _call(s, method, path, body)
    except NeedAI:
        _save(s)
        _ask(s)
    except BadAnswer as exc:
        s["answers"].pop()
        _save(s)
        print(f"上一次寫的 JSON 不合格式：{exc}\n請照同一份提示詞重寫。")
        _ask(s)
    s.pop("pending")
    s["answers"] = []
    ASK.unlink(missing_ok=True)
    _save(s)
    turn = data.get("turn") or {}
    print(show(json.dumps({"判定": turn.get("judgment"), "敘事": turn.get("narrative"), "選項": data.get("choices") or turn.get("choices")},
                          ensure_ascii=False, indent=1), s.get("era", "")))
    _card(s)
    if _jobs():
        print(f"（有 {len(_jobs())} 件背景內容待寫：之後找空檔跑 python -m tiandao.chat write）")


def _write(s: dict) -> None:
    """照順序寫待寫清單。每件在資料庫的副本上跑：要 Claude 寫字就丟掉副本、問完重跑；寫完才換上。"""
    while _jobs():
        name, args = _jobs()[0]
        shutil.copy(DB, JOB_DB)
        app = _app(s.get("answers", []), JOB_DB, s.get("era", ""))
        conn = connect(JOB_DB)
        try:
            getattr(app.game, name)(conn, *args)
        except NeedAI:
            conn.close()
            JOB_DB.unlink(missing_ok=True)
            s["pending"] = ["write"]
            _save(s)
            _ask(s)
        except Exception as exc:   # 寫壞了就跳過這件：世界照樣有手寫的內容（同原程式）
            print(f"跳過 {name}：{exc}")
        conn.close()
        if JOB_DB.exists():
            JOB_DB.replace(DB)
        JOBS.write_text(json.dumps(_jobs()[1:], ensure_ascii=False), "utf-8")
        s["answers"] = []
        _save(s)
    s.pop("pending", None)
    ASK.unlink(missing_ok=True)
    _save(s)
    print("背景內容都寫完了")


def _card(s: dict) -> None:
    """精簡角色卡：直接照程式算好的欄位印，不心算。"""
    d = _call(s, "GET", f"/api/sessions/{s['sid']}")
    c, se = d["character"], d["session"]
    era = ERA_OF.get(c["moneyName"], "")
    if era != s.get("era"):          # 第一次或換了時代：記下來，之後的提示詞照這個時代換錢
        s["era"] = era
        _save(s)
    lines = [
        f"{c['name']}｜{c['lineage'].split('｜')[0]}｜{c['age']} 歲（壽元 {c['lifespan']}）",
        f"時間：{se['clock']['label']}｜{c['weather']}",
        f"境界：{c['realm']}｜修為 {c['cultivation']}/100{'（瓶頸）' if c['atBottleneck'] else ''}｜氣血 {c['hp']}/{c['hpMax']}",
        f"狀態：{'、'.join(x.get('name', str(x)) if isinstance(x, dict) else str(x) for x in c['statuses']) or '無'}",
        f"所在：{c['location']}",
        f"靈石 {c['spiritStones']}｜{coin(c['money'], era)}" + (f"（欠房租 {c['rentOwed']} 個月）" if c['rentOwed'] else ""),
        f"天道：{c['heavenFeeling']}",
    ]
    print("── 角色卡 ──\n" + "\n".join(lines))


def main(argv: list[str]) -> None:
    HOME.mkdir(exist_ok=True)
    cmd, args = argv[0], argv[1:]
    s = _load()
    if cmd == "new":
        name, gender = args[0], args[1]
        s = {"answers": []}
        _call(s, "POST", "/api/auth/register", {"username": "player", "password": "password123"})
        s["token"] = _call(s, "POST", "/api/auth/login", {"username": "player", "password": "password123"})["token"]
        body = {"title": name}
        if len(args) > 2:
            body["era"] = args[2]
        s["sid"] = _call(s, "POST", "/api/sessions", body)["session"]["id"]
        _call(s, "POST", f"/api/sessions/{s['sid']}/character", {"name": name, "gender": gender})
        s["n"], s["era"] = 0, args[2] if len(args) > 2 else "古代"
        s["pending"] = ["POST", f"/api/sessions/{s['sid']}/opening", {"requestId": "open"}]
        _save(s)
        _run(s)
    elif cmd == "turn":
        if s.get("pending"):
            raise SystemExit("上一個請求還沒跑完，先 answer")
        s["n"] += 1
        s["pending"] = ["POST", f"/api/sessions/{s['sid']}/turns", {"requestId": f"t{s['n']}", "input": take(args[0], s.get("era", ""))}]
        _save(s)
        _run(s)
    elif cmd == "answer":
        ask = json.loads(ASK.read_text("utf-8"))
        s.setdefault("answers", []).append({"key": ask["key"], "raw": ANSWER.read_text("utf-8")})
        ANSWER.unlink()
        _save(s)
        _run(s)
    elif cmd == "save":       # 存檔：整個資料庫壓成一行文字（給 project_write 上傳）
        tmp = HOME / "save.db"
        tmp.unlink(missing_ok=True)
        conn = sqlite3.connect(DB)
        conn.execute("VACUUM INTO ?", (str(tmp),))
        conn.close()
        packed = {"db": base64.b64encode(gzip.compress(tmp.read_bytes(), 9)).decode(), "state": {k: s[k] for k in ("token", "sid", "n")}, "jobs": _jobs()}
        tmp.unlink()
        Path(args[0]).write_text("天道棋盤存檔 v1（主持人用 python -m tiandao.chat load 讀）\n" + json.dumps(packed), "utf-8")
        print(f"已存：{args[0]}（{len(packed['db'])} 字）")
    elif cmd == "load":       # 讀檔：還原資料庫，從存檔那一回合接著玩
        packed = json.loads(Path(args[0]).read_text("utf-8").split("\n", 1)[1])
        for f in (DB, Path(str(DB) + "-wal"), Path(str(DB) + "-shm"), ASK, ANSWER):
            f.unlink(missing_ok=True)
        DB.write_bytes(gzip.decompress(base64.b64decode(packed["db"])))
        JOBS.write_text(json.dumps(packed.get("jobs", []), ensure_ascii=False), "utf-8")
        s = {**packed["state"], "answers": []}
        _save(s)
        got = _call(s, "GET", f"/api/sessions/{s['sid']}")
        s["era"] = ERA_OF.get(got["character"]["moneyName"], "")
        _save(s)
        print(f"已讀檔：第 {got['session']['turnNo']} 回合，{got['session']['clock']}")
    elif cmd == "write":      # 寫背景內容（物品、傳說、怪談、事端）
        if s.get("pending"):
            raise SystemExit("上一個請求還沒跑完，先 answer")
        _write(s)
    elif cmd == "state":
        _card(s)
    else:
        raise SystemExit(__doc__)


if __name__ == "__main__":
    main(sys.argv[1:])
