"""聊天版的入口：Python 照原本的程式跑整個回合，模型那一步交給聊天裡的 Claude。

用法（在工作資料夾）：
  python -m tiandao.chat new 名字 性別 [時代]   開世界、建角、開場
  python -m tiandao.chat turn "玩家這句"          玩一回合
  python -m tiandao.chat answer                   Claude 寫好 ai_answer.json 後，接著跑同一回合
  python -m tiandao.chat write                    寫背景內容（物品、傳說、怪談、事端），原程式在背景叫模型寫的那些
  python -m tiandao.chat state                    印角色卡、所在、眼前的人
  python -m tiandao.chat save 檔名                存檔（資料庫壓成一行文字）
  python -m tiandao.chat load 檔名                讀檔

要模型寫字時：印出提示詞、寫進 ai_ask.json，結束碼 3。Claude 照 schema 寫 JSON 到 ai_answer.json，再跑 answer。
回合是單一交易、擲骰照種子固定，所以重跑同一回合結果一樣；前面答過的照順序重放。
"""
from __future__ import annotations

import base64
import gzip
import hashlib
import shutil
import sqlite3
import json
import re
import sys
from pathlib import Path

from .ai import prompts
from .ai.narrators import OllamaNarrator
from .config import PROJECT_ROOT, Settings
from .store.db import connect
from .web.app import App

HOME = Path.cwd() / "棋盤"
DB, STATE, ASK, ANSWER = HOME / "world.db", HOME / "state.json", HOME / "ai_ask.json", HOME / "ai_answer.json"
JOBS, JOB_DB = HOME / "jobs.json", HOME / "job.db"


# ── 錢的顯示（2026-11-23）：程式裡一律記凡人錢、換時代數字不變；給 Claude 和玩家看的照時代換成那個時代的說法 ──
SCALE = {"古代": 20, "現代": 600, "未來": 100}            # 凡人錢 1 → 古代 20 文、現代 600 元、未來 100 點
ERA_OF = {"銀兩": "古代", "元": "現代", "信用點": "未來"}   # 從角色卡的錢名認時代
# 「30 銀兩」或「銀兩 64」（角色卡那種寫法）；一次換完，不會換兩次
MONEY = re.compile(r"(\d[\d,]*)\s*(?:凡人錢|銀兩|信用點|元(?![嬰神氣寶始宵]))|(?<![\u4e00-\u9fff])(?:凡人錢|銀兩|信用點|元)\s*(\d[\d,]*)")
SAID = {"古代": re.compile(r"(?:(\d[\d,]*)\s*兩\s*)?(?:(\d[\d,]*)\s*文)?"),       # 玩家說的錢（顯示用的說法）
        "現代": re.compile(r"(\d[\d,]*)\s*(?:元|塊)(?![嬰神氣寶始宵])"),
        "未來": re.compile(r"(\d[\d,]*)\s*(?:信用點|點)")}


def coin(n: int, era: str) -> str:
    v = round(n * SCALE[era])
    if era == "古代":
        liang, wen = divmod(v, 1000)
        return (f"{liang} 兩" if liang else "") + (f"{' ' if liang else ''}{wen} 文" if wen or not liang else "")
    return f"{v:,} 元" if era == "現代" else f"{v:,} 點"


def show(text: str, era: str) -> str:
    """把程式寫的「N 凡人錢／銀兩／元／信用點」換成顯示用的數字。"""
    if not era:
        return text
    return MONEY.sub(lambda m: coin(int((m[1] or m[2]).replace(",", "")), era), text)


def take(said: str, era: str) -> str:
    """玩家話裡的錢（顯示用的）換成程式的「N 凡人錢」，之後判定、說書都照程式的數字走。"""
    def one(m) -> str:
        if era == "古代":
            if not (m[1] or m[2]):
                return m[0]
            v = int((m[1] or "0").replace(",", "")) * 1000 + int((m[2] or "0").replace(",", ""))
        else:
            v = int(m[1].replace(",", ""))
        return f"{max(1, round(v / SCALE[era]))} 凡人錢"
    return SAID[era].sub(one, said) if era in SAID else said


# 說書人規則：原本那十條是寫給 9b 的（篇幅、一條一條禁止）。給 Claude 換成原則：程式算的是事實，其他放手寫（2026-11-23）
HEAD_9B = prompts.RULES.split("輸出格式：")[0]
HEAD_BIG = """你是修仙文字冒險遊戲「天道棋盤」的說書人，用繁體中文寫。

程式負責你做不準的事，你負責把故事說好：
1. 【判定】【結果】【旁支】是程式算好的事實：成敗、數值、誰生誰死、得到失去什麼、過了多少時間，照它寫，不改、不加、不否認。
   沒列出來的，就是沒發生：沒有人死、沒有得到東西、修為境界沒有變、時間沒有多過。
2. 其他都由你發揮：場景、氣氛、人物的言行和口氣、節奏、開場怎麼開、篇幅多長，照這個故事需要的寫。
3. 用第二人稱「你」寫主角：你描述世界、玩家決定主角做什麼（程式給的事實也都寫成「你」）。
   主角只做玩家說的事。不替主角做玩家沒說的決定、不替他說誓言或想法，也不讓他自己去別處、等到別的時辰。
4. 你寫出來、之後要記得的人、地點、勢力、承諾、懸念，用 proposals 登錄；沒登錄的，世界記不住。
   你立下要被遵守的規矩（住戶守則、村裡的禁忌、廟裡的忌諱），用 proposals.rules 登錄：place 綁在哪個地點（空＝主角所在）、
   text 規矩原文、when 什麼時候算、act 做哪一類事會犯、word 說了哪個字會犯（可空）、cost 犯了怎樣。
   登錄了，程式之後就會照它執行（主角犯了，【結果】會寫出來）；沒登錄的規矩只是說說，不會發生。
5. 主角只做得到【境界規格】允許的事。敘事不寫修為、氣血、傷勢的點數。
6. 玩家想走就讓他走出去；只有提示寫明出不去的（例如封閉的怪談）才困住。

"""
# 說書放寬（2026-11-23 試玩回報、回報/narrator-loosen.patch）：程式只管事實，主事、眼前的人、他要講的事都是可用素材
LOOSE = {
    "- 【主事】這回合只有這一件事，一定要寫進敘事；情節由你寫，性質不能改。\n  「登場的人」必須出場":
    "- 【主事】是這回合可用的一件事，不是非寫不可：合眼前的場景就寫進去（情節由你寫，性質不能改）；\n"
    "  不合（主角獨處、時機不對、它假設的前提沒發生過）就不寫，或只留一點徵兆。不要為了圓它編出主角沒做過的事。\n"
    "  寫了的話：「登場的人」要出場",
    "- 【眼前的人】主角面對的就是他：照外貌寫，不要換人，也不要讓他自己離開。態度只有事實寫了才變，判定失敗不是翻臉。\n"
    "  他照自己想要的說話做事，敘事裡至少一句他親口說的話，放在「」裡。":
    "- 【眼前的人】主角衝著的就是他：照外貌寫，不要換人。態度只有事實寫了才變，判定失敗不是翻臉。\n"
    "  他照自己想要的、照自己的個性說話做事；主角對他說話時他要有反應。主角沒找他、他也不在主角身邊時，他可以不出場、不說話。\n"
    "  「說話」是他的習慣，不是每句台詞都要用到：口頭禪偶爾冒一句就好。台詞照真人講話寫，口語、短，熟人之間用簡稱，不要把人名地名講全。\n"
    "  「這回合他會講到」是他可以講的事：話少、不肯講的人可以只講半句、岔開、或用動作帶過，不必全講出來。\n  ",
    "- 【結果】一定要寫到。": "- 【結果】一定要寫到（跟【主事】同一件的那條，照【主事】的寫法）。",
    "（用他的口氣親口說出來，帶上裡面的人名、地名、東西，不要多講這之外的秘密）": "（照他的個性決定講多少，不要多講這之外的秘密）",
}
SWAPS = {HEAD_9B: HEAD_BIG, **LOOSE,
         "- 時長：要花多久，照原文抄（「三個月」「到天亮」）；沒有就空字串。":
         "- 時長：要花多久，照原文抄（「三個月」「到天亮」）；沒有就空字串。\n"
         "- 多久：這件事做下來花多久。看一眼、起身、說一兩句話、拿個東西＝片刻；其他＝一時辰左右。",
         "【任務】寫出這段旅程的開場：交代主角身處何地、眼前有什麼值得注意的人事物。":
         "【任務】寫出這段旅程的開場：讓玩家覺得一個世界開始了——主角在哪裡、過著什麼樣的日子、身邊有誰。"}


def adapt(text: str) -> str:
    for a, b in SWAPS.items():
        text = text.replace(a, b)
    return text


class BadAnswer(Exception):
    """Claude 的回覆不合格式。"""


class CannotTry(Exception):
    """程式說這件事做不了（未能嘗試）：沒有寫回合、時間沒過，照原話告訴玩家。"""


class NeedAI(BaseException):
    """BaseException：穿過程式裡的 except Exception，讓整個回合交易回滾，等 Claude 回覆再重跑。"""


class ChatNarrator(OllamaNarrator):
    """跟 Ollama 同一套提示詞、schema、合約檢查；只把「送出去」換成「問 Claude」。"""

    def __init__(self, answers: list[dict], era: str = ""):
        super().__init__("chat", "claude", attempts=1)   # 不合格式不自動重叫：退回給 Claude 看錯在哪、重寫
        self.answers, self.used, self.era = answers, 0, era

    def _prime(self, system: str) -> None:
        pass

    def _chat(self, messages, schema, temperature):
        key = hashlib.sha1(json.dumps(messages, ensure_ascii=False).encode()).hexdigest()[:12]
        while self.used < len(self.answers):
            a = self.answers[self.used]
            self.used += 1
            if a["key"] == key:
                return self._back(a["raw"], messages), 0
        shown = [{**m, "content": show(adapt(m["content"]), self.era)} for m in messages]
        ASK.write_text(json.dumps({"key": key, "messages": shown, "schema": schema}, ensure_ascii=False, indent=1), "utf-8")
        raise NeedAI(key)

    def _back(self, raw: str, messages) -> str:
        """讀懂玩家的話時，Claude 看到的錢是顯示用的；「數字」欄照玩家話裡那筆換回凡人錢。"""
        said = messages[-1]["content"].rsplit("【玩家的話】", 1)[-1]
        m = re.search(r"(\d+) 凡人錢", said)
        try:
            got = json.loads(raw)
        except ValueError:
            return raw
        if m and isinstance(got, dict) and got.get("數字"):
            got["數字"] = m[1]
            return json.dumps(got, ensure_ascii=False)
        return raw


def _load() -> dict:
    return json.loads(STATE.read_text("utf-8")) if STATE.exists() else {}


def _save(s: dict) -> None:
    STATE.write_text(json.dumps(s, ensure_ascii=False, indent=1), "utf-8")


def _app(answers: list[dict], db: Path = DB, era: str = "") -> App:
    settings = Settings(db_path=db, ai_backend="ollama", rules_dir=PROJECT_ROOT / "rules", frontend_dir=PROJECT_ROOT / "frontend")
    app = App(settings, narrator=ChatNarrator(answers, era))
    app.game.big = True                         # 寫的是 Claude：事端一次叫完、傳說怪談不叫是非題
    app.game.later = lambda job: job()          # 背景工作當場呼叫，但 _alone 只排進待寫清單（下面）
    app.game._alone = _queue
    return app


def _queue(path, job, *args) -> None:
    """原程式在背景叫模型寫物品、傳說、怪談、事端；聊天版先記下來，等 write 指令一件一件寫。"""
    jobs = json.loads(JOBS.read_text("utf-8")) if JOBS.exists() else []
    item = [job.__name__, list(args)]
    if item not in jobs:
        jobs.append(item)
        JOBS.write_text(json.dumps(jobs, ensure_ascii=False), "utf-8")


def _jobs() -> list:
    return json.loads(JOBS.read_text("utf-8")) if JOBS.exists() else []


def _call(s: dict, method: str, path: str, body=None):
    app = _app(s.get("answers", []), era=s.get("era", ""))
    headers = {"Content-Type": "application/json"}
    if s.get("token"):
        headers["Authorization"] = f"Bearer {s['token']}"
    status, _, payload = app.dispatch(method, path, headers, json.dumps(body).encode() if body is not None else b"")
    data = json.loads(payload)
    if status == 502 and data["error"].get("code") == "ai_contract" and s.get("answers"):
        raise BadAnswer(data["error"]["message"])
    if status == 409 and data["error"].get("code") == "cannot_try":
        raise CannotTry(data["error"]["message"] + "".join(f"\n{i}. {c}" for i, c in enumerate(data["error"].get("choices", []), 1)))
    if status >= 400:
        raise SystemExit(f"錯誤 {status}：{json.dumps(data, ensure_ascii=False)[:500]}")
    return data


def _ask(s: dict) -> None:
    """印出要 Claude 寫的東西。系統提示詞跟上次印過的一樣就不再印（省用量）。"""
    ask = json.loads(ASK.read_text("utf-8"))
    seen = set(s.get("seen", []))
    for m in ask["messages"]:
        h = hashlib.sha1(m["content"].encode()).hexdigest()[:12]
        if m["role"] == "system" and h in seen:
            print(f"===== system =====\n（同上次印過的系統提示詞 {h}，照它寫）")
            continue
        if m["role"] == "system":
            seen.add(h)
        print(f"===== {m['role']} =====\n{m['content']}")
    s["seen"] = sorted(seen)
    _save(s)
    print("===== 回覆格式（JSON schema）=====")
    props = ask["schema"].get("properties", {})
    if "做什麼" in props:   # 讀懂那一步：選項跟【各欄可選】一樣，不再印一次
        free = [k for k, v in props.items() if "enum" not in v and v.get("type") == "string"]
        print(f"一個 JSON 物件，欄位就是【各欄可選】那幾欄，值照那裡選（判什麼是清單，可以選一到兩個）；"
              f"另外幾欄照玩家的話填，沒有就給空字串：{'、'.join(free)}")
    else:
        print(_brief(ask["schema"]))
    print(f"\n請把 JSON 寫進 {ANSWER}，再跑：python -m tiandao.chat answer")
    sys.exit(3)


def _brief(schema: dict) -> str:
    """JSON schema 改寫成幾行字（大模型看得懂，不用整份 schema）：欄名、必填、數量、可選的值。"""
    def one(name: str, v: dict, pad: str = "") -> list[str]:
        t, need = v.get("type"), ""
        if "enum" in v:
            return [f"{pad}{name}：{'／'.join(v['enum'])}"]
        if t == "array":
            n = v.get("maxItems")
            count = f"剛好 {n} 個" if n and v.get("minItems") == n else f"最多 {n} 個" if n else "清單"
            item = v.get("items", {})
            if item.get("type") == "object":
                return [f"{pad}{name}（{count}，每個是物件）："] + [x for k, sub in item.get("properties", {}).items()
                                                                for x in one(k + ("（必填）" if k in item.get("required", []) else ""), sub, pad + "  ")]
            return one(f"{name}（{count}）", item, pad)
        if t == "object":
            return [f"{pad}{name}："] + [x for k, sub in v.get("properties", {}).items() for x in one(k, sub, pad + "  ")]
        return [f"{pad}{name}：字串{need}"]
    lines = [x for k, v in schema.get("properties", {}).items() for x in one(k, v)]
    return "只輸出一個 JSON 物件，欄位如下（沒有就給空陣列或空字串）：\n" + "\n".join(lines)


def _run(s: dict) -> None:
    """跑 s['pending']（一個要做的請求）；要模型時停下來問。"""
    if s["pending"] == ["write"]:
        return _write(s)
    method, path, body = s["pending"]
    try:
        data = _call(s, method, path, body)
    except NeedAI:
        _save(s)
        _ask(s)
    except BadAnswer as exc:
        s["answers"].pop()
        _save(s)
        print(f"上一次寫的 JSON 不合格式：{exc}\n請照同一份提示詞重寫。")
        _ask(s)
    except CannotTry as exc:
        s.pop("pending")
        s["answers"] = []
        ASK.unlink(missing_ok=True)
        _save(s)
        print(f"{exc}\n（這回合沒有發生，時間也沒過；照這句告訴玩家，等他重新說要做什麼）")
        return
    s.pop("pending")
    s["answers"] = []
    ASK.unlink(missing_ok=True)
    _save(s)
    turn = data.get("turn") or {}
    j = turn.get("judgment") or {}
    checks = "；".join(f"{c['target']} {c['chance']}%，擲 {c['roll']}，{c['outcome']}" for c in j.get("checks", []))
    print(f"【判定】{j.get('action_type', '')}：{checks}" if checks else "【判定】不用擲骰")
    print(show(turn.get("narrative") or "", s.get("era", "")))
    print("\n".join(f"{i}. {c}" for i, c in enumerate(data.get("choices") or turn.get("choices") or [], 1)))
    _card(s)
    if _jobs():
        print(f"（有 {len(_jobs())} 件背景內容待寫：之後找空檔跑 python -m tiandao.chat write）")


def _write(s: dict) -> None:
    """照順序寫待寫清單。每件在資料庫的副本上跑：要 Claude 寫字就丟掉副本、問完重跑；寫完才換上。"""
    while _jobs():
        name, args = _jobs()[0]
        shutil.copy(DB, JOB_DB)
        app = _app(s.get("answers", []), JOB_DB, s.get("era", ""))
        conn = connect(JOB_DB)
        try:
            getattr(app.game, name)(conn, *args)
        except NeedAI:
            conn.close()
            JOB_DB.unlink(missing_ok=True)
            s["pending"] = ["write"]
            _save(s)
            _ask(s)
        except Exception as exc:   # 寫壞了就跳過這件：世界照樣有手寫的內容（同原程式）
            print(f"跳過 {name}：{exc}")
        conn.close()
        if JOB_DB.exists():
            JOB_DB.replace(DB)
        JOBS.write_text(json.dumps(_jobs()[1:], ensure_ascii=False), "utf-8")
        s["answers"] = []
        _save(s)
    s.pop("pending", None)
    ASK.unlink(missing_ok=True)
    _save(s)
    print("背景內容都寫完了")


def _card(s: dict) -> None:
    """精簡角色卡：直接照程式算好的欄位印，不心算。"""
    d = _call(s, "GET", f"/api/sessions/{s['sid']}")
    c, se = d["character"], d["session"]
    era = ERA_OF.get(c["moneyName"], "")
    if era != s.get("era"):          # 第一次或換了時代：記下來，之後的提示詞照這個時代換錢
        s["era"] = era
        _save(s)
    lines = [
        f"{c['name']}｜{c['lineage'].split('｜')[0]}｜{c['age']} 歲（壽元 {c['lifespan']}）",
        f"時間：{se['clock']['label']}｜{c['weather']}",
        f"境界：{c['realm']}｜修為 {c['cultivation']}/100{'（瓶頸）' if c['atBottleneck'] else ''}｜氣血 {c['hp']}/{c['hpMax']}",
        f"狀態：{'、'.join(x.get('name', str(x)) if isinstance(x, dict) else str(x) for x in c['statuses']) or '無'}",
        f"所在：{c['location']}",
        f"靈石 {c['spiritStones']}｜{coin(c['money'], era)}" + (f"（欠房租 {c['rentOwed']} 個月）" if c['rentOwed'] else ""),
        f"天道：{c['heavenFeeling']}",
    ]
    print("── 角色卡 ──\n" + "\n".join(lines))
    if daily := _daily(d["routine"], era):
        print(daily)


def _daily(panel: dict, era: str) -> str:
    """日常那一行（仙緣草稿第五節：聊天沒有日常面板，每回合列出來）；仇家在場不列。"""
    if not panel or panel.get("locked"):
        return ""
    out = []
    for kind, counts in panel["kinds"].items():
        name, unit, why = panel["names"].get(kind, kind), panel["units"][kind], panel["jobs"].get(kind)
        laws = f"：{'、'.join(panel['laws'])}" if kind == "參悟" and panel["laws"] else ""
        wage = f"，每月 {coin(panel['wage'][kind], era) if era else panel['wage'][kind]}" if why == "" else ""
        out.append(f"{name}（{'／'.join(map(str, counts))} {unit}{wage}{laws}）" + (f"（{why}）" if why else ""))
    return "日常：" + "、".join(out)


def _routine(s: dict, text: str) -> dict | None:
    """玩家照日常那一行回（「吐納3個月」「參悟靈系1個月」「押運6個月」）就照面板送，跟網頁版按鈕一樣，不經過讀懂。"""
    panel = _call(s, "GET", f"/api/sessions/{s['sid']}")["routine"]
    if not panel or panel.get("locked"):
        return None
    text = text.replace(" ", "")
    for kind, counts in panel["kinds"].items():
        for name in {kind, panel["names"].get(kind, kind)}:
            m = re.fullmatch(rf"{name}(\S*?)(\d+){panel['units'][kind]}", text)
            if m and int(m[2]) in counts and (m[1] in panel["laws"] if kind == "參悟" else not m[1]):
                return {"kind": kind, "count": int(m[2]), **({"law": m[1]} if kind == "參悟" else {})}
    return None


def main(argv: list[str]) -> None:
    HOME.mkdir(exist_ok=True)
    cmd, args = argv[0], argv[1:]
    s = _load()
    if cmd == "new":
        name, gender = args[0], args[1]
        s = {"answers": []}
        _call(s, "POST", "/api/auth/register", {"username": "player", "password": "password123"})
        s["token"] = _call(s, "POST", "/api/auth/login", {"username": "player", "password": "password123"})["token"]
        body = {"title": name}
        if len(args) > 2:
            body["era"] = args[2]
        s["sid"] = _call(s, "POST", "/api/sessions", body)["session"]["id"]
        _call(s, "POST", f"/api/sessions/{s['sid']}/character", {"name": name, "gender": gender})
        s["n"], s["era"] = 0, args[2] if len(args) > 2 else "古代"
        s["pending"] = ["POST", f"/api/sessions/{s['sid']}/opening", {"requestId": "open"}]
        _save(s)
        _run(s)
    elif cmd == "turn":
        if s.get("pending"):
            raise SystemExit("上一個請求還沒跑完，先 answer")
        s["n"] += 1
        body = {"requestId": f"t{s['n']}", "input": take(args[0], s.get("era", ""))}
        if routine := _routine(s, args[0]):
            body["routine"] = routine
        s["pending"] = ["POST", f"/api/sessions/{s['sid']}/turns", body]
        _save(s)
        _run(s)
    elif cmd == "answer":
        ask = json.loads(ASK.read_text("utf-8"))
        s.setdefault("answers", []).append({"key": ask["key"], "raw": ANSWER.read_text("utf-8")})
        ANSWER.unlink()
        _save(s)
        _run(s)
    elif cmd == "save":       # 存檔：整個資料庫壓成一行文字（給 project_write 上傳）
        tmp = HOME / "save.db"
        tmp.unlink(missing_ok=True)
        conn = sqlite3.connect(DB)
        conn.execute("VACUUM INTO ?", (str(tmp),))
        conn.close()
        packed = {"db": base64.b64encode(gzip.compress(tmp.read_bytes(), 9)).decode(), "state": {k: s[k] for k in ("token", "sid", "n")}, "jobs": _jobs()}
        tmp.unlink()
        Path(args[0]).write_text("天道棋盤存檔 v1（主持人用 python -m tiandao.chat load 讀）\n" + json.dumps(packed), "utf-8")
        print(f"已存：{args[0]}（{len(packed['db'])} 字）")
    elif cmd == "load":       # 讀檔：還原資料庫，從存檔那一回合接著玩
        packed = json.loads(Path(args[0]).read_text("utf-8").split("\n", 1)[1])
        for f in (DB, Path(str(DB) + "-wal"), Path(str(DB) + "-shm"), ASK, ANSWER):
            f.unlink(missing_ok=True)
        DB.write_bytes(gzip.decompress(base64.b64decode(packed["db"])))
        JOBS.write_text(json.dumps(packed.get("jobs", []), ensure_ascii=False), "utf-8")
        s = {**packed["state"], "answers": []}
        _save(s)
        got = _call(s, "GET", f"/api/sessions/{s['sid']}")
        s["era"] = ERA_OF.get(got["character"]["moneyName"], "")
        _save(s)
        print(f"已讀檔：第 {got['session']['turnNo']} 回合，{got['session']['clock']['label']}")
    elif cmd == "write":      # 寫背景內容（物品、傳說、怪談、事端）
        if s.get("pending"):
            raise SystemExit("上一個請求還沒跑完，先 answer")
        _write(s)
    elif cmd == "state":
        _card(s)
    else:
        raise SystemExit(__doc__)


if __name__ == "__main__":
    main(sys.argv[1:])
