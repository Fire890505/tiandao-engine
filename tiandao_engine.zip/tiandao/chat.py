"""聊天版的入口：Python 照原本的程式跑整個回合，模型那一步交給聊天裡的 Claude。

用法（在工作資料夾）：
  python -m tiandao.chat new 名字 性別 [時代]   開世界、建角、開場
  python -m tiandao.chat turn "玩家這句"          玩一回合
  python -m tiandao.chat answer                   Claude 寫好 ai_answer.json 後，接著跑同一回合
  python -m tiandao.chat state                    印角色卡、所在、眼前的人
  python -m tiandao.chat save 檔名                存檔（資料庫壓成一行文字）
  python -m tiandao.chat load 檔名                讀檔

要模型寫字時：印出提示詞、寫進 ai_ask.json，結束碼 3。Claude 照 schema 寫 JSON 到 ai_answer.json，再跑 answer。
回合是單一交易、擲骰照種子固定，所以重跑同一回合結果一樣；前面答過的照順序重放。
"""
from __future__ import annotations

import base64
import gzip
import hashlib
import sqlite3
import json
import sys
from pathlib import Path

from .ai.narrators import OllamaNarrator
from .errors import UpstreamError
from .config import PROJECT_ROOT, Settings
from .web.app import App

HOME = Path.cwd() / "棋盤"
DB, STATE, ASK, ANSWER = HOME / "world.db", HOME / "state.json", HOME / "ai_ask.json", HOME / "ai_answer.json"


class NeedAI(BaseException):
    """BaseException：穿過程式裡的 except Exception，讓整個回合交易回滾，等 Claude 回覆再重跑。"""


class ChatNarrator(OllamaNarrator):
    """跟 Ollama 同一套提示詞、schema、合約檢查；只把「送出去」換成「問 Claude」。"""

    def __init__(self, answers: list[dict]):
        super().__init__("chat", "claude")
        self.answers, self.used = answers, 0

    def _prime(self, system: str) -> None:
        pass

    def forge(self, *a, **k):     # 背景寫世界物品、傳說、怪談、事端：聊天版先用手寫的（程式本來就會退回）
        raise UpstreamError("聊天版不在背景寫", code="chat_skip")

    story = bits = judge = forge

    def _chat(self, messages, schema, temperature):
        key = hashlib.sha1(json.dumps(messages, ensure_ascii=False).encode()).hexdigest()[:12]
        while self.used < len(self.answers):
            a = self.answers[self.used]
            self.used += 1
            if a["key"] == key:
                return a["raw"], 0
        ASK.write_text(json.dumps({"key": key, "messages": messages, "schema": schema}, ensure_ascii=False, indent=1), "utf-8")
        raise NeedAI(key)


def _load() -> dict:
    return json.loads(STATE.read_text("utf-8")) if STATE.exists() else {}


def _save(s: dict) -> None:
    STATE.write_text(json.dumps(s, ensure_ascii=False, indent=1), "utf-8")


def _app(answers: list[dict]) -> App:
    settings = Settings(db_path=DB, ai_backend="ollama", rules_dir=PROJECT_ROOT / "rules", frontend_dir=PROJECT_ROOT / "frontend")
    return App(settings, narrator=ChatNarrator(answers))


def _call(s: dict, method: str, path: str, body=None):
    app = _app(s.get("answers", []))
    headers = {"Content-Type": "application/json"}
    if s.get("token"):
        headers["Authorization"] = f"Bearer {s['token']}"
    try:
        status, _, payload = app.dispatch(method, path, headers, json.dumps(body).encode() if body is not None else b"")
    except NeedAI:
        raise
    data = json.loads(payload)
    if status == 502 and ASK.exists() and json.loads(ASK.read_text("utf-8"))["key"] not in {a["key"] for a in s.get("answers", [])}:
        raise NeedAI("")
    if status >= 400:
        raise SystemExit(f"錯誤 {status}：{json.dumps(data, ensure_ascii=False)[:500]}")
    return data


def _ask(s: dict) -> None:
    """印出要 Claude 寫的東西。系統提示詞跟上次印過的一樣就不再印（省用量）。"""
    ask = json.loads(ASK.read_text("utf-8"))
    seen = set(s.get("seen", []))
    for m in ask["messages"]:
        h = hashlib.sha1(m["content"].encode()).hexdigest()[:12]
        if m["role"] == "system" and h in seen:
            print(f"===== system =====\n（同上次印過的系統提示詞 {h}，照它寫）")
            continue
        seen.add(h) if m["role"] == "system" else None
        print(f"===== {m['role']} =====\n{m['content']}")
    s["seen"] = sorted(seen)
    _save(s)
    print("===== 回覆格式（JSON schema）=====")
    print(json.dumps(ask["schema"], ensure_ascii=False))
    print(f"\n請把 JSON 寫進 {ANSWER}，再跑：python -m tiandao.chat answer")
    sys.exit(3)


def _run(s: dict) -> None:
    """跑 s['pending']（一個要做的請求）；要模型時停下來問。"""
    method, path, body = s["pending"]
    try:
        data = _call(s, method, path, body)
    except NeedAI:
        _save(s)
        _ask(s)
    s.pop("pending")
    s["answers"] = []
    ASK.unlink(missing_ok=True)
    _save(s)
    turn = data.get("turn") or {}
    print(json.dumps({"判定": turn.get("judgment"), "敘事": turn.get("narrative"), "選項": data.get("choices") or turn.get("choices")},
                     ensure_ascii=False, indent=1))
    _card(s)


def _card(s: dict) -> None:
    """精簡角色卡：直接照程式算好的欄位印，不心算。"""
    d = _call(s, "GET", f"/api/sessions/{s['sid']}")
    c, se = d["character"], d["session"]
    lines = [
        f"{c['name']}｜{c['lineage'].split('｜')[0]}｜{c['age']} 歲（壽元 {c['lifespan']}）",
        f"時間：{se['clock']['label']}｜{c['weather']}",
        f"境界：{c['realm']}｜修為 {c['cultivation']}/100{'（瓶頸）' if c['atBottleneck'] else ''}｜氣血 {c['hp']}/{c['hpMax']}",
        f"狀態：{'、'.join(x.get('name', str(x)) if isinstance(x, dict) else str(x) for x in c['statuses']) or '無'}",
        f"所在：{c['location']}",
        f"靈石 {c['spiritStones']}｜{c['moneyName']} {c['money']}" + (f"（欠房租 {c['rentOwed']} 個月）" if c['rentOwed'] else ""),
        f"天道：{c['heavenFeeling']}",
    ]
    print("── 角色卡 ──\n" + "\n".join(lines))


def main(argv: list[str]) -> None:
    HOME.mkdir(exist_ok=True)
    cmd, args = argv[0], argv[1:]
    s = _load()
    if cmd == "new":
        name, gender = args[0], args[1]
        s = {"answers": []}
        c = _call(s, "POST", "/api/auth/register", {"username": "player", "password": "password123"})
        s["token"] = _call(s, "POST", "/api/auth/login", {"username": "player", "password": "password123"})["token"]
        body = {"title": name}
        if len(args) > 2:
            body["era"] = args[2]
        s["sid"] = _call(s, "POST", "/api/sessions", body)["session"]["id"]
        _call(s, "POST", f"/api/sessions/{s['sid']}/character", {"name": name, "gender": gender})
        s["n"] = 0
        s["pending"] = ["POST", f"/api/sessions/{s['sid']}/opening", {"requestId": "open"}]
        _save(s)
        _run(s)
    elif cmd == "turn":
        if s.get("pending"):
            raise SystemExit("上一個請求還沒跑完，先 answer")
        s["n"] += 1
        s["pending"] = ["POST", f"/api/sessions/{s['sid']}/turns", {"requestId": f"t{s['n']}", "input": args[0]}]
        _save(s)
        _run(s)
    elif cmd == "answer":
        ask = json.loads(ASK.read_text("utf-8"))
        s.setdefault("answers", []).append({"key": ask["key"], "raw": ANSWER.read_text("utf-8")})
        ANSWER.unlink()
        _save(s)
        _run(s)
    elif cmd == "save":       # 存檔：整個資料庫壓成一行文字（給 project_write 上傳）
        tmp = HOME / "save.db"
        tmp.unlink(missing_ok=True)
        conn = sqlite3.connect(DB)
        conn.execute("VACUUM INTO ?", (str(tmp),))
        conn.close()
        packed = {"db": base64.b64encode(gzip.compress(tmp.read_bytes(), 9)).decode(), "state": {k: s[k] for k in ("token", "sid", "n")}}
        tmp.unlink()
        Path(args[0]).write_text("天道棋盤存檔 v1（主持人用 python -m tiandao.chat load 讀）\n" + json.dumps(packed), "utf-8")
        print(f"已存：{args[0]}（{len(packed['db'])} 字）")
    elif cmd == "load":       # 讀檔：還原資料庫，從存檔那一回合接著玩
        packed = json.loads(Path(args[0]).read_text("utf-8").split("\n", 1)[1])
        for f in (DB, Path(str(DB) + "-wal"), Path(str(DB) + "-shm"), ASK, ANSWER):
            f.unlink(missing_ok=True)
        DB.write_bytes(gzip.decompress(base64.b64decode(packed["db"])))
        s = {**packed["state"], "answers": []}
        _save(s)
        got = _call(s, "GET", f"/api/sessions/{s['sid']}")
        print(f"已讀檔：第 {got['session']['turnNo']} 回合，{got['session']['clock']}")
    elif cmd == "state":
        _card(s)
    else:
        raise SystemExit(__doc__)


if __name__ == "__main__":
    main(sys.argv[1:])
