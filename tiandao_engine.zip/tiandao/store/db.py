"""SQLite 連線與版本化遷移。

每個 HTTP 請求開自己的連線（sqlite3 連線不跨執行緒共用）。
寫入一律包在 transaction() 裡：要嘛整批成功，要嘛整批不寫。
"""
from __future__ import annotations

import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

# 只能往後追加，不能修改已發布的遷移。
MIGRATIONS: list[str] = [
    # v1：最小 vertical slice
    """
    CREATE TABLE users (
      id            TEXT PRIMARY KEY,
      username      TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      created_at    TEXT NOT NULL
    );
    CREATE TABLE auth_tokens (
      token_hash TEXT PRIMARY KEY,
      user_id    TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      created_at TEXT NOT NULL,
      expires_at TEXT NOT NULL
    );
    CREATE TABLE game_sessions (
      id            TEXT PRIMARY KEY,
      user_id       TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      title         TEXT NOT NULL,
      phase         TEXT NOT NULL,
      turn_no       INTEGER NOT NULL DEFAULT 0,
      clock_shichen INTEGER NOT NULL DEFAULT 0,
      rng_seed      TEXT NOT NULL,
      created_at    TEXT NOT NULL,
      updated_at    TEXT NOT NULL
    );
    CREATE INDEX idx_sessions_user ON game_sessions(user_id, updated_at);
    CREATE TABLE characters (
      session_id TEXT PRIMARY KEY REFERENCES game_sessions(id) ON DELETE CASCADE,
      sheet_json TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
    CREATE TABLE turns (
      id            TEXT PRIMARY KEY,
      session_id    TEXT NOT NULL REFERENCES game_sessions(id) ON DELETE CASCADE,
      turn_no       INTEGER NOT NULL,
      request_id    TEXT NOT NULL,
      kind          TEXT NOT NULL,
      player_input  TEXT NOT NULL DEFAULT '',
      judgment_json TEXT NOT NULL DEFAULT '{}',
      delta_json    TEXT NOT NULL DEFAULT '{}',
      narrative     TEXT NOT NULL,
      choices_json  TEXT NOT NULL DEFAULT '[]',
      model         TEXT NOT NULL DEFAULT '',
      created_at    TEXT NOT NULL,
      UNIQUE(session_id, turn_no),
      UNIQUE(session_id, request_id)
    );
    """,
    # v2：AI 呼叫遙測（第 0 步用真模型驗證時的量測依據；不屬於遊戲狀態）
    """
    CREATE TABLE ai_calls (
      id            TEXT PRIMARY KEY,
      session_id    TEXT NOT NULL REFERENCES game_sessions(id) ON DELETE CASCADE,
      turn_no       INTEGER NOT NULL,
      kind          TEXT NOT NULL,
      model         TEXT NOT NULL,
      ok            INTEGER NOT NULL,
      attempts      INTEGER NOT NULL,
      latency_ms    INTEGER NOT NULL,
      error_code    TEXT NOT NULL DEFAULT '',
      error_message TEXT NOT NULL DEFAULT '',
      ignored_keys  TEXT NOT NULL DEFAULT '[]',
      outcome       TEXT NOT NULL DEFAULT '',
      tone_check    TEXT NOT NULL DEFAULT '',
      narrative_len INTEGER NOT NULL DEFAULT 0,
      created_at    TEXT NOT NULL
    );
    CREATE INDEX idx_ai_calls_session ON ai_calls(session_id, turn_no);
    """,
    # v3：AI 提案通道（第 1 步）。地點與 NPC 只有通過 game/proposals.py 審核後才會寫入
    """
    CREATE TABLE locations (
      id              TEXT PRIMARY KEY,
      session_id      TEXT NOT NULL REFERENCES game_sessions(id) ON DELETE CASCADE,
      name            TEXT NOT NULL,
      description     TEXT NOT NULL,
      loc_type        TEXT NOT NULL DEFAULT '',
      discovered_turn INTEGER NOT NULL,
      created_at      TEXT NOT NULL,
      UNIQUE(session_id, name)
    );
    CREATE TABLE npcs (
      id              TEXT PRIMARY KEY,
      session_id      TEXT NOT NULL REFERENCES game_sessions(id) ON DELETE CASCADE,
      name            TEXT NOT NULL,
      appearance      TEXT NOT NULL DEFAULT '',
      profile         TEXT NOT NULL DEFAULT '',
      location        TEXT NOT NULL DEFAULT '',
      status          TEXT NOT NULL DEFAULT 'ALIVE',
      ai_driven       INTEGER NOT NULL DEFAULT 1,
      created_by      TEXT NOT NULL DEFAULT 'narrator',
      first_seen_turn INTEGER NOT NULL,
      created_at      TEXT NOT NULL,
      UNIQUE(session_id, name)
    );
    CREATE TABLE proposal_log (
      id         TEXT PRIMARY KEY,
      session_id TEXT NOT NULL REFERENCES game_sessions(id) ON DELETE CASCADE,
      turn_no    INTEGER NOT NULL,
      kind       TEXT NOT NULL,
      name       TEXT NOT NULL,
      accepted   INTEGER NOT NULL,
      reason     TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL
    );
    CREATE INDEX idx_proposal_log_session ON proposal_log(session_id, turn_no);
    """,
    # v4：世界層（第 16 步）。「世界」成為最上層：局歸屬世界，地點與 NPC 屬於世界、比單一局活得久。
    # 既有的每一局各自轉成一個獨立世界（id 由局 id 推導），資料不遺失。
    """
    CREATE TABLE worlds (
      id            TEXT PRIMARY KEY,
      user_id       TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      name          TEXT NOT NULL,
      kind          TEXT NOT NULL DEFAULT 'origin',
      clock_shichen INTEGER NOT NULL DEFAULT 0,
      rng_seed      TEXT NOT NULL,
      created_at    TEXT NOT NULL,
      updated_at    TEXT NOT NULL
    );
    CREATE INDEX idx_worlds_user ON worlds(user_id, updated_at);
    INSERT INTO worlds(id, user_id, name, kind, clock_shichen, rng_seed, created_at, updated_at)
      SELECT 'wld_' || substr(id, 5), user_id, title, 'origin', clock_shichen, rng_seed || ':world', created_at, updated_at
      FROM game_sessions;
    ALTER TABLE game_sessions ADD COLUMN world_id TEXT REFERENCES worlds(id) ON DELETE CASCADE;
    UPDATE game_sessions SET world_id = 'wld_' || substr(id, 5);
    CREATE INDEX idx_sessions_world ON game_sessions(world_id, created_at);
    CREATE UNIQUE INDEX ux_sessions_one_active_per_world ON game_sessions(world_id)
      WHERE phase IN ('NEED_CHARACTER', 'NEED_OPENING', 'PLAYING');
    CREATE TABLE locations_w (
      id                    TEXT PRIMARY KEY,
      world_id              TEXT NOT NULL REFERENCES worlds(id) ON DELETE CASCADE,
      name                  TEXT NOT NULL,
      description           TEXT NOT NULL,
      loc_type              TEXT NOT NULL DEFAULT '',
      discovered_session_id TEXT NOT NULL DEFAULT '',
      discovered_turn       INTEGER NOT NULL,
      created_at            TEXT NOT NULL,
      UNIQUE(world_id, name)
    );
    INSERT INTO locations_w
      SELECT l.id, s.world_id, l.name, l.description, l.loc_type, l.session_id, l.discovered_turn, l.created_at
      FROM locations l JOIN game_sessions s ON s.id = l.session_id;
    DROP TABLE locations;
    ALTER TABLE locations_w RENAME TO locations;
    CREATE TABLE npcs_w (
      id                    TEXT PRIMARY KEY,
      world_id              TEXT NOT NULL REFERENCES worlds(id) ON DELETE CASCADE,
      name                  TEXT NOT NULL,
      appearance            TEXT NOT NULL DEFAULT '',
      profile               TEXT NOT NULL DEFAULT '',
      location              TEXT NOT NULL DEFAULT '',
      status                TEXT NOT NULL DEFAULT 'ALIVE',
      ai_driven             INTEGER NOT NULL DEFAULT 1,
      created_by            TEXT NOT NULL DEFAULT 'narrator',
      first_seen_session_id TEXT NOT NULL DEFAULT '',
      first_seen_turn       INTEGER NOT NULL,
      created_at            TEXT NOT NULL,
      UNIQUE(world_id, name)
    );
    INSERT INTO npcs_w
      SELECT n.id, s.world_id, n.name, n.appearance, n.profile, n.location, n.status, n.ai_driven, n.created_by,
             n.session_id, n.first_seen_turn, n.created_at
      FROM npcs n JOIN game_sessions s ON s.id = n.session_id;
    DROP TABLE npcs;
    ALTER TABLE npcs_w RENAME TO npcs;
    """,
    # v5：選項標註（第 4 步）。AI 產生選項時順便標好行動類型與難易，玩家點選項時直接採用，不必再分類
    """
    ALTER TABLE turns ADD COLUMN choice_tags_json TEXT NOT NULL DEFAULT '[]';
    """,
    # v6：地點與移動（第 7 步）。地點多了上層地點、規模、危險度；連接記錄兩地之間的路（距離、方向）。
    # 連接無向：每對地點只存一筆，方向是「從 a 看 b 在哪個方位」
    """
    ALTER TABLE locations ADD COLUMN parent TEXT NOT NULL DEFAULT '';
    ALTER TABLE locations ADD COLUMN scale TEXT NOT NULL DEFAULT '';
    ALTER TABLE locations ADD COLUMN danger TEXT NOT NULL DEFAULT '';
    CREATE TABLE connections (
      id                    TEXT PRIMARY KEY,
      world_id              TEXT NOT NULL REFERENCES worlds(id) ON DELETE CASCADE,
      a                     TEXT NOT NULL,
      b                     TEXT NOT NULL,
      distance_km           INTEGER NOT NULL,
      tier                  TEXT NOT NULL,
      direction             TEXT NOT NULL DEFAULT '',
      discovered_session_id TEXT NOT NULL DEFAULT '',
      discovered_turn       INTEGER NOT NULL DEFAULT 0,
      created_at            TEXT NOT NULL,
      UNIQUE(world_id, a, b)
    );
    CREATE INDEX idx_connections_world ON connections(world_id);
    """,
    # v7：NPC（第 6 步）。出生時間（推算年齡）、境界、狀態階梯、說話風格、各段描述寫於幾歲；
    # 關係以「NPC × 哪一生的主角」為單位存在世界裡（主角死後 NPC 仍記得他）。
    # 第 6 步之前登錄的 NPC 沒有出生時間（NULL＝年齡不詳，按未成年保護）。
    """
    ALTER TABLE npcs ADD COLUMN race TEXT NOT NULL DEFAULT '人族';
    ALTER TABLE npcs ADD COLUMN birth_shichen INTEGER;
    ALTER TABLE npcs ADD COLUMN realm_lv INTEGER NOT NULL DEFAULT 0;
    ALTER TABLE npcs ADD COLUMN stage_index INTEGER NOT NULL DEFAULT 0;
    ALTER TABLE npcs ADD COLUMN hidden_power INTEGER NOT NULL DEFAULT 0;
    ALTER TABLE npcs ADD COLUMN condition_state TEXT NOT NULL DEFAULT '無恙';
    ALTER TABLE npcs ADD COLUMN speech TEXT NOT NULL DEFAULT '';
    ALTER TABLE npcs ADD COLUMN appearance_age INTEGER;
    ALTER TABLE npcs ADD COLUMN profile_age INTEGER;
    ALTER TABLE npcs ADD COLUMN speech_age INTEGER;
    CREATE TABLE npc_relations (
      world_id   TEXT NOT NULL REFERENCES worlds(id) ON DELETE CASCADE,
      npc_name   TEXT NOT NULL,
      session_id TEXT NOT NULL,
      affinity   INTEGER NOT NULL DEFAULT 0,
      trust      INTEGER NOT NULL DEFAULT 0,
      grudge     TEXT NOT NULL DEFAULT '',
      updated_at TEXT NOT NULL,
      PRIMARY KEY (world_id, npc_name, session_id)
    );
    ALTER TABLE ai_calls ADD COLUMN warnings TEXT NOT NULL DEFAULT '';
    """,
    # v8：長期記憶（第 17 步）。記事綁在人、地、主角身上（session_id＝哪一生記下的，前世往事靠它分辨）；
    # 線頭有編號（世界內遞增，給 AI 結線時引用）、狀態、期限、最後接觸時間。
    """
    CREATE TABLE memories (
      id            TEXT PRIMARY KEY,
      world_id      TEXT NOT NULL REFERENCES worlds(id) ON DELETE CASCADE,
      session_id    TEXT NOT NULL,
      subject_kind  TEXT NOT NULL,
      subject       TEXT NOT NULL,
      kind          TEXT NOT NULL,
      text          TEXT NOT NULL,
      source        TEXT NOT NULL,
      clock_shichen INTEGER NOT NULL,
      turn_no       INTEGER NOT NULL,
      thread_id     TEXT,
      created_at    TEXT NOT NULL
    );
    CREATE INDEX idx_memories_subject ON memories(world_id, subject);
    CREATE TABLE threads (
      id               TEXT PRIMARY KEY,
      world_id         TEXT NOT NULL REFERENCES worlds(id) ON DELETE CASCADE,
      session_id       TEXT NOT NULL,
      no               INTEGER NOT NULL,
      kind             TEXT NOT NULL,
      subject_kind     TEXT NOT NULL,
      subject          TEXT NOT NULL,
      text             TEXT NOT NULL,
      status           TEXT NOT NULL,
      deadline_shichen INTEGER,
      opened_shichen   INTEGER NOT NULL,
      opened_turn      INTEGER NOT NULL,
      touched_shichen  INTEGER NOT NULL,
      closed_shichen   INTEGER,
      result_note      TEXT NOT NULL DEFAULT '',
      created_at       TEXT NOT NULL,
      UNIQUE(world_id, no)
    );
    """,
    # v9：背景演化第一段（第 10a 步）。NPC 的目標與性格（機制層）、天道角色（第 18 步才指派）、描述改寫原因；
    # 羈絆（甲對乙而言是〔種類〕，人物或勢力）；勢力（最小版）。goal 空字串＝第 10a 步之前登錄、尚未補上性格。
    """
    ALTER TABLE npcs ADD COLUMN goal TEXT NOT NULL DEFAULT '';
    ALTER TABLE npcs ADD COLUMN goal_target TEXT NOT NULL DEFAULT '';
    ALTER TABLE npcs ADD COLUMN ambition INTEGER NOT NULL DEFAULT 50;
    ALTER TABLE npcs ADD COLUMN kindness INTEGER NOT NULL DEFAULT 50;
    ALTER TABLE npcs ADD COLUMN courage INTEGER NOT NULL DEFAULT 50;
    ALTER TABLE npcs ADD COLUMN suspicion INTEGER NOT NULL DEFAULT 50;
    ALTER TABLE npcs ADD COLUMN heaven_role TEXT NOT NULL DEFAULT '';
    ALTER TABLE npcs ADD COLUMN rewrite_reason TEXT NOT NULL DEFAULT '';
    CREATE TABLE factions (
      id                    TEXT PRIMARY KEY,
      world_id              TEXT NOT NULL REFERENCES worlds(id) ON DELETE CASCADE,
      name                  TEXT NOT NULL,
      type                  TEXT NOT NULL,
      location              TEXT NOT NULL,
      discovered_session_id TEXT NOT NULL,
      discovered_turn       INTEGER NOT NULL,
      created_at            TEXT NOT NULL,
      UNIQUE(world_id, name)
    );
    CREATE TABLE bonds (
      id            TEXT PRIMARY KEY,
      world_id      TEXT NOT NULL REFERENCES worlds(id) ON DELETE CASCADE,
      session_id    TEXT NOT NULL,
      a_kind        TEXT NOT NULL,
      a             TEXT NOT NULL,
      b_kind        TEXT NOT NULL,
      b             TEXT NOT NULL,
      type          TEXT NOT NULL,
      clock_shichen INTEGER NOT NULL,
      turn_no       INTEGER NOT NULL,
      created_at    TEXT NOT NULL
    );
    CREATE INDEX idx_bonds_world ON bonds(world_id);
    """,
    # v10：背景演化第二段（第 10b 步）。NPC 上次演算到的時間（NULL＝第 10b 步之前登錄，第一次遇到時才開始計時）、
    # 小境界內的修為；這一生的主角打聽到的目標與打聽的時間（目標要打聽才知道）。
    """
    ALTER TABLE npcs ADD COLUMN evolved_shichen INTEGER;
    ALTER TABLE npcs ADD COLUMN cultivation INTEGER NOT NULL DEFAULT 0;
    ALTER TABLE npc_relations ADD COLUMN known_goal TEXT NOT NULL DEFAULT '';
    ALTER TABLE npc_relations ADD COLUMN known_goal_shichen INTEGER;
    """,
    # v11：記事多兩個欄位，讓程式不必解析記事文字（置頂維護原則第 6 條）：
    # actor＝誰下的手（目前只有「死於主角之手」會填）；attitude＝關係轉折後對主角的態度（親近、敵視……）
    """
    ALTER TABLE memories ADD COLUMN actor TEXT NOT NULL DEFAULT '';
    ALTER TABLE memories ADD COLUMN attitude TEXT NOT NULL DEFAULT '';
    """,
    # v12：去了遠方的人什麼時候走的、從哪裡走的（第 10c-2b 步：保底回家要算時間、要知道家鄉；不解析記事文字）。
    # away_since NULL＝不在遠方（或第 10c-2b 步之前就去了遠方，第一次演算時才開始計時）
    """
    ALTER TABLE npcs ADD COLUMN away_since INTEGER;
    ALTER TABLE npcs ADD COLUMN away_from TEXT NOT NULL DEFAULT '';
    """,
    # v13：傳聞（第 10c-3a 步）。每則只記一次：誰（subject）對誰（target）做了什麼（kind）、在哪、何時、多大；
    # lv＝被殺／受傷者、突破後、坐化者的境界，subject_lv＝做事的人的境界（名聲用）；life＝做事的是哪一生的主角（NPC 之間的事是空字串）。
    # 記事的 rumor_id：這一生聽到了哪一則傳聞（同一則同一生只聽一次）。
    """
    CREATE TABLE rumors (
      id            TEXT PRIMARY KEY,
      world_id      TEXT NOT NULL REFERENCES worlds(id) ON DELETE CASCADE,
      kind          TEXT NOT NULL,
      subject       TEXT NOT NULL,
      target        TEXT NOT NULL DEFAULT '',
      place         TEXT NOT NULL,
      detail        TEXT NOT NULL DEFAULT '',
      lv            INTEGER NOT NULL DEFAULT 0,
      subject_lv    INTEGER NOT NULL DEFAULT 0,
      life          TEXT NOT NULL DEFAULT '',
      size          TEXT NOT NULL,
      clock_shichen INTEGER NOT NULL,
      created_at    TEXT NOT NULL
    );
    CREATE INDEX idx_rumors_world ON rumors(world_id, clock_shichen);
    ALTER TABLE memories ADD COLUMN rumor_id TEXT;
    """,
    # v14：地點狀況（第 9b 步）。事件留在地點上的狀況（燈會、妖獸出沒……）：name＝哪一件事件、text＝給人看的描述、
    # source＝世界／天道、game＝天道的棋局編號（第 18 步）；ends_shichen 過了就自動消失（不刪，只是不再顯示）。
    """
    CREATE TABLE place_states (
      id              TEXT PRIMARY KEY,
      world_id        TEXT NOT NULL REFERENCES worlds(id) ON DELETE CASCADE,
      place           TEXT NOT NULL,
      name            TEXT NOT NULL,
      text            TEXT NOT NULL,
      source          TEXT NOT NULL,
      game            TEXT,
      started_shichen INTEGER NOT NULL,
      ends_shichen    INTEGER NOT NULL,
      created_at      TEXT NOT NULL
    );
    CREATE INDEX idx_place_states_world ON place_states(world_id, ends_shichen);
    """,
    # v15：天道人格卡（第 18-1 步，domain/heaven.py）。JSON；空字串＝還沒擲（舊世界第一次用到時補擲）。
    """
    ALTER TABLE worlds ADD COLUMN heaven TEXT NOT NULL DEFAULT '';
    """,
    # v16：棋譜（第 18-2a 步，domain/games.py）。天道每一手一筆：no＝世界裡的第幾盤（回合紀錄的事件用它指回來）、
    # kind＝渡劫／小劫數／心魔／餌、name＝哪一件、result＝勝／負（空＝還沒分勝負）。屬於世界，天道跨世記得（第 18-3 步用）。
    """
    CREATE TABLE heaven_games (
      id              TEXT PRIMARY KEY,
      world_id        TEXT NOT NULL REFERENCES worlds(id) ON DELETE CASCADE,
      session_id      TEXT NOT NULL,
      no              INTEGER NOT NULL,
      kind            TEXT NOT NULL,
      name            TEXT NOT NULL,
      result          TEXT NOT NULL DEFAULT '',
      started_shichen INTEGER NOT NULL,
      started_turn    INTEGER NOT NULL,
      ended_shichen   INTEGER,
      ended_turn      INTEGER,
      created_at      TEXT NOT NULL
    );
    CREATE UNIQUE INDEX ux_heaven_games_no ON heaven_games(world_id, no);
    """,
    # v17：遺物（第 11-1 步，domain/legacy.py）。一筆＝一疊物品；記在某個 NPC 名下（holder）或某個地點上（place），
    # 兩者只有一個。owner＝原本是誰的、session_id＝哪一生留下的；lasts＝落地後能留多久，placed_shichen＝落地的時間。
    """
    CREATE TABLE relics (
      id             TEXT PRIMARY KEY,
      world_id       TEXT NOT NULL REFERENCES worlds(id) ON DELETE CASCADE,
      session_id     TEXT NOT NULL,
      owner          TEXT NOT NULL,
      name           TEXT NOT NULL,
      tier           INTEGER NOT NULL,
      count          INTEGER NOT NULL,
      holder         TEXT NOT NULL DEFAULT '',
      place          TEXT NOT NULL DEFAULT '',
      placed_shichen INTEGER,
      lasts          INTEGER NOT NULL,
      created_at     TEXT NOT NULL
    );
    CREATE INDEX idx_relics_world ON relics(world_id);
    """,
    # v18：亡者（第 11-2 步，domain/undead.py）。name＝生前的名字、form＝幽魂／屍變、lv＝生前境界；等級不存（依死了多久算）。
    # grudge／grudge_on＝幽魂的執念（恩怨或約定、對象）；awake＝現身中（主角離開這個地點就隱去）。session_id＝哪一生記下的。
    """
    CREATE TABLE undead (
      id           TEXT PRIMARY KEY,
      world_id     TEXT NOT NULL REFERENCES worlds(id) ON DELETE CASCADE,
      session_id   TEXT NOT NULL,
      name         TEXT NOT NULL,
      form         TEXT NOT NULL,
      lv           INTEGER NOT NULL,
      died_shichen INTEGER NOT NULL,
      place        TEXT NOT NULL,
      condition    TEXT NOT NULL,
      grudge       TEXT NOT NULL DEFAULT '',
      grudge_on    TEXT NOT NULL DEFAULT '',
      awake        INTEGER NOT NULL DEFAULT 0,
      created_at   TEXT NOT NULL
    );
    CREATE INDEX idx_undead_world ON undead(world_id);
    """,
    # v19：前期領域（第 19-1 步，domain/domains.py、domain/tales.py）。tale＝主題、place＝籠罩的地點、neighbor／person＝{鄰地}{人}、
    # ghost＝亡者執念型借的幽魂；rules／staged＝抽中的守則、上演過的情境（JSON 編號）；life＝最近進去的那一生，
    # step／strikes／chased＝那一生的破解進度、犯規次數、本體在不在追（換一生進去就重來）；status＝籠罩／破解／散去。
    """
    CREATE TABLE domains (
      id              TEXT PRIMARY KEY,
      world_id        TEXT NOT NULL REFERENCES worlds(id) ON DELETE CASCADE,
      tale            TEXT NOT NULL,
      place           TEXT NOT NULL,
      neighbor        TEXT NOT NULL,
      person          TEXT NOT NULL DEFAULT '',
      ghost           TEXT NOT NULL DEFAULT '',
      rules           TEXT NOT NULL,
      life            TEXT NOT NULL DEFAULT '',
      step            INTEGER NOT NULL DEFAULT 0,
      strikes         INTEGER NOT NULL DEFAULT 0,
      staged          TEXT NOT NULL DEFAULT '[]',
      chased          INTEGER NOT NULL DEFAULT 0,
      status          TEXT NOT NULL,
      created_shichen INTEGER NOT NULL,
      solved_shichen  INTEGER,
      created_at      TEXT NOT NULL
    );
    CREATE INDEX idx_domains_world ON domains(world_id);
    """,
    # v20：領域的規模（第 19-1 步第 10 題：家、村落、鄉鎮、城市）。之前的領域：客棧當家級（舊守則都合家級），其他是村落級
    # （與 domain/domains.OLD_SCALE 一致）。
    """
    ALTER TABLE domains ADD COLUMN scale TEXT NOT NULL DEFAULT '村落';
    UPDATE domains SET scale = '家' WHERE tale = '打烊後的客棧';
    """,
    # v21：都市傳說（第 19-2 步，domain/legends.py）。theme＝主題；center＝出沒範圍的中心（會移動）、root＝根源（不動）、
    # neighbor＝根源的{鄰地}；客死異鄉另記 dead（死者）、target（仇人／托話對象）、home（老家）；met＝最近碰上它的那一生，
    # step／misses／chased＝那一生的了結進度、答錯次數、本體在不在追；haunts／haunt_until＝纏上哪一生、到什麼時候。
    """
    CREATE TABLE legends (
      id              TEXT PRIMARY KEY,
      world_id        TEXT NOT NULL REFERENCES worlds(id) ON DELETE CASCADE,
      theme           TEXT NOT NULL,
      center          TEXT NOT NULL,
      root            TEXT NOT NULL,
      neighbor        TEXT NOT NULL,
      dead            TEXT NOT NULL DEFAULT '',
      target          TEXT NOT NULL DEFAULT '',
      home            TEXT NOT NULL DEFAULT '',
      met             TEXT NOT NULL DEFAULT '',
      step            INTEGER NOT NULL DEFAULT 0,
      misses          INTEGER NOT NULL DEFAULT 0,
      chased          INTEGER NOT NULL DEFAULT 0,
      haunts          TEXT NOT NULL DEFAULT '',
      haunt_until     INTEGER,
      status          TEXT NOT NULL,
      created_shichen INTEGER NOT NULL,
      moved_shichen   INTEGER NOT NULL,
      solved_shichen  INTEGER,
      created_at      TEXT NOT NULL
    );
    CREATE INDEX idx_legends_world ON legends(world_id);
    """,
    # v22：時代卡（第 16e 節，domain/era.py）。JSON；空字串＝還沒擲（舊世界第一次用到時補擲，從古代開始）。
    """
    ALTER TABLE worlds ADD COLUMN era TEXT NOT NULL DEFAULT '';
    """,
    # v23：19-3（domain/rites.py）。流傳中的玩法：tale＝儀式型主題、town＝流傳地、source＝源頭、place＝做儀式的地方、
    # stage＝流傳／準備／斷根／淡掉／出事、person＝準備中的人、cut＝準備中被斷了根、known＝找到過源頭的那一生、
    # next_shichen＝下一個時間點（挑人或做儀式）。都市傳說多記 rewarded＝已經拿過答對好處的那一生。
    """
    CREATE TABLE rites (
      id              TEXT PRIMARY KEY,
      world_id        TEXT NOT NULL REFERENCES worlds(id) ON DELETE CASCADE,
      tale            TEXT NOT NULL,
      town            TEXT NOT NULL,
      source          TEXT NOT NULL,
      place           TEXT NOT NULL,
      stage           TEXT NOT NULL,
      person          TEXT NOT NULL DEFAULT '',
      cut             INTEGER NOT NULL DEFAULT 0,
      known           TEXT NOT NULL DEFAULT '',
      next_shichen    INTEGER NOT NULL,
      created_shichen INTEGER NOT NULL,
      ended_shichen   INTEGER,
      created_at      TEXT NOT NULL
    );
    CREATE INDEX idx_rites_world ON rites(world_id);
    ALTER TABLE legends ADD COLUMN rewarded TEXT NOT NULL DEFAULT '';
    """,
    # v24：勢力的特徵（16h 國法與宗規）：國家的信仰、文化、風氣，宗門的道統、門風（JSON；其他勢力是 {}）
    """
    ALTER TABLE factions ADD COLUMN traits TEXT NOT NULL DEFAULT '{}';
    """,
    # v25：天下骨架（16k）：國家、州、主城（JSON，domain/atlas.py；舊世界第一回合補上）
    """
    ALTER TABLE worlds ADD COLUMN atlas TEXT NOT NULL DEFAULT '';
    """,
    # v26：仙域骨架（16l）：每個玩家一份，所有世界共用（JSON，domain/immortal.py；第一次用到時生成）
    """
    ALTER TABLE users ADD COLUMN immortal TEXT NOT NULL DEFAULT '';
    """,
    # v27：仙域同時有好幾個飛升上來的主角（16l）：shared 的局不受「一個世界同時只有一局」限制
    """
    ALTER TABLE game_sessions ADD COLUMN shared INTEGER NOT NULL DEFAULT 0;
    DROP INDEX ux_sessions_one_active_per_world;
    CREATE UNIQUE INDEX ux_sessions_one_active_per_world ON game_sessions(world_id)
      WHERE phase IN ('NEED_CHARACTER', 'NEED_OPENING', 'PLAYING') AND shared = 0;
    """,
    # v28：世界長出來的新物品（16p）：說書人提案、Python 審核；base＝借效果的基本款（domain/items.py）
    """
    CREATE TABLE items_w (
      id                    TEXT PRIMARY KEY,
      world_id              TEXT NOT NULL REFERENCES worlds(id) ON DELETE CASCADE,
      name                  TEXT NOT NULL,
      base                  TEXT NOT NULL,
      description           TEXT NOT NULL,
      discovered_session_id TEXT NOT NULL,
      discovered_turn       INTEGER NOT NULL,
      created_at            TEXT NOT NULL,
      UNIQUE (world_id, name)
    );
    """,
    # v29：地點眼前的環境物（16r，JSON，domain/scene.py；NULL＝還沒列過）
    """
    ALTER TABLE locations ADD COLUMN features TEXT;
    """,
    # v30：世界長出來的新事件（16p 第二批）：base＝借類別、應對方式、獎懲的基本款（domain/incident.py）
    """
    CREATE TABLE incidents_w (
      id                    TEXT PRIMARY KEY,
      world_id              TEXT NOT NULL REFERENCES worlds(id) ON DELETE CASCADE,
      name                  TEXT NOT NULL,
      base                  TEXT NOT NULL,
      scene                 TEXT NOT NULL,
      discovered_session_id TEXT NOT NULL,
      discovered_turn       INTEGER NOT NULL,
      created_at            TEXT NOT NULL,
      UNIQUE (world_id, name)
    );
    """,
    # v31：世界裡的事端（16t）：name＝模板，cast＝填入的人和地方（JSON），stage＝時間線走到第幾步；
    # turned_shichen＝關鍵人物死去、事情轉向的時候，killed＝他是不是死在玩家手上
    """
    CREATE TABLE plots_w (
      id              TEXT PRIMARY KEY,
      world_id        TEXT NOT NULL REFERENCES worlds(id) ON DELETE CASCADE,
      name            TEXT NOT NULL,
      town            TEXT NOT NULL,
      started_shichen INTEGER NOT NULL,
      stage           INTEGER NOT NULL,
      ended_shichen   INTEGER,
      turned_shichen  INTEGER,
      killed          INTEGER NOT NULL,
      cast_json       TEXT NOT NULL,
      created_at      TEXT NOT NULL
    );
    CREATE INDEX idx_plots_world ON plots_w(world_id);
    """,
    # v32：事端分醞釀和爆發（16t 第 11 題）：brew_until＝醞釀到什麼時候，lit_shichen＝玩家走進來、開始爆發的時候
    """
    ALTER TABLE plots_w ADD COLUMN brew_until INTEGER NOT NULL DEFAULT 0;
    ALTER TABLE plots_w ADD COLUMN lit_shichen INTEGER;
    """,
    # v33：NPC 的性別和支系（16u 第 3、6 題）；舊世界的人留空
    """
    ALTER TABLE npcs ADD COLUMN gender TEXT NOT NULL DEFAULT '';
    ALTER TABLE npcs ADD COLUMN lineage TEXT NOT NULL DEFAULT '';
    """,
    # v34：NPC 的職業（16u 外貌第二批）；舊世界的人留空
    """
    ALTER TABLE npcs ADD COLUMN job TEXT NOT NULL DEFAULT '';
    """,
    # v35：世界碼（認兩個存檔是不是同一個世界）、壓力（domain/pressure.py，16v 第 93、101 題）
    """
    ALTER TABLE worlds ADD COLUMN uid TEXT NOT NULL DEFAULT '';
    ALTER TABLE worlds ADD COLUMN pressure TEXT NOT NULL DEFAULT '{}';
    UPDATE worlds SET uid = lower(hex(randomblob(8)));
    """,
    # v36：「未了的事」：線頭的來源、下一步（16v 第 78 題）
    """
    ALTER TABLE threads ADD COLUMN origin TEXT NOT NULL DEFAULT '';
    ALTER TABLE threads ADD COLUMN next_step TEXT NOT NULL DEFAULT '';
    """,
    # v37：支線辦到哪（domain/side.py，16v 第 76 題）
    """
    ALTER TABLE threads ADD COLUMN task TEXT NOT NULL DEFAULT '{}';
    """,
    # v38：人情帳（domain/favour.py，16v 第 87、106～113 題）
    """
    ALTER TABLE npc_relations ADD COLUMN favours TEXT NOT NULL DEFAULT '[]';
    """,
    # v39：事件、好感原因、知情、帳（第 120-5、120-7 題，實作第 1-1 批）。事件只加不改；原因、知情、帳都連回事件。
    # session_id：主角那一生（主角↔NPC 的原因每一生分開）；NPC 之間的是空字串。era＝發生時的時代（126-11）。
    """
    CREATE TABLE events (
      id            TEXT PRIMARY KEY,
      world_id      TEXT NOT NULL REFERENCES worlds(id) ON DELETE CASCADE,
      session_id    TEXT NOT NULL DEFAULT '',
      kind          TEXT NOT NULL,
      actor         TEXT NOT NULL DEFAULT '',
      target        TEXT NOT NULL DEFAULT '',
      place         TEXT NOT NULL DEFAULT '',
      detail        TEXT NOT NULL DEFAULT '{}',
      secret        INTEGER NOT NULL DEFAULT 0,
      era           TEXT NOT NULL DEFAULT '',
      clock_shichen INTEGER NOT NULL,
      turn_no       INTEGER NOT NULL DEFAULT 0,
      created_at    TEXT NOT NULL
    );
    CREATE INDEX idx_events_world ON events(world_id, clock_shichen);
    CREATE TABLE reasons (
      id            TEXT PRIMARY KEY,
      world_id      TEXT NOT NULL REFERENCES worlds(id) ON DELETE CASCADE,
      session_id    TEXT NOT NULL DEFAULT '',
      holder        TEXT NOT NULL,
      toward        TEXT NOT NULL,
      axis          TEXT NOT NULL,
      size          TEXT NOT NULL,
      value         INTEGER NOT NULL,
      kind          TEXT NOT NULL,
      event_id      TEXT NOT NULL DEFAULT '',
      clock_shichen INTEGER NOT NULL,
      created_at    TEXT NOT NULL
    );
    CREATE INDEX idx_reasons_world ON reasons(world_id, holder);
    CREATE TABLE knows (
      id            TEXT PRIMARY KEY,
      world_id      TEXT NOT NULL REFERENCES worlds(id) ON DELETE CASCADE,
      session_id    TEXT NOT NULL DEFAULT '',
      event_id      TEXT NOT NULL,
      who           TEXT NOT NULL,
      knows_who     INTEGER NOT NULL DEFAULT 1,
      knows_why     INTEGER NOT NULL DEFAULT 0,
      via           TEXT NOT NULL,
      clock_shichen INTEGER NOT NULL,
      created_at    TEXT NOT NULL
    );
    CREATE INDEX idx_knows_world ON knows(world_id, event_id);
    CREATE TABLE ledger (
      id               TEXT PRIMARY KEY,
      world_id         TEXT NOT NULL REFERENCES worlds(id) ON DELETE CASCADE,
      session_id       TEXT NOT NULL DEFAULT '',
      kind             TEXT NOT NULL,
      a                TEXT NOT NULL,
      b                TEXT NOT NULL DEFAULT '',
      event_id         TEXT NOT NULL DEFAULT '',
      settle           TEXT NOT NULL DEFAULT '',
      deadline_shichen INTEGER,
      waiting          TEXT NOT NULL DEFAULT '',
      status           TEXT NOT NULL,
      era              TEXT NOT NULL DEFAULT '',
      body             TEXT NOT NULL DEFAULT '{}',
      clock_shichen    INTEGER NOT NULL,
      created_at       TEXT NOT NULL
    );
    CREATE INDEX idx_ledger_world ON ledger(world_id, status);
    """,
    # v40：關係分四類（第 1-3 批）。友人、仇家、恩人、同門改成讀的時候算，不存；好感、信任只由原因算，拿掉兩欄。
    """
    DELETE FROM bonds WHERE type IN ('友人', '仇家', '恩人', '同門');
    ALTER TABLE npc_relations DROP COLUMN affinity;
    ALTER TABLE npc_relations DROP COLUMN trust;
    """,
    # v41：關係種類的固定加減（第 1-3b 批）取代暫用的同門、除名原因；主角的關係（家人、宗門）也寫進 bonds
    "DELETE FROM reasons WHERE kind IN ('同門', '除名');",
    # v42：主角的人情搬到帳上（第 1-4a 批，domain/favour.py row）。開發期，舊的人情不搬
    "ALTER TABLE npc_relations DROP COLUMN favours;",
    # v43：誰知道（第 1-5a 批，domain/hearsay.py）：說出去了沒，每筆只說一次
    "ALTER TABLE knows ADD COLUMN told INTEGER NOT NULL DEFAULT 0;",
    # v44：見過面（第 1-5e 批）：只聽說過你的人是 0，不算這一生認識的人
    "ALTER TABLE npc_relations ADD COLUMN met INTEGER NOT NULL DEFAULT 1;",
    # v45：讀懂影子模式（3-2）：每回合讀懂的行動單和關鍵字那條鏈的判斷並排記，只觀察、不是遊戲狀態
    """
    CREATE TABLE reads (
      id         TEXT PRIMARY KEY,
      session_id TEXT NOT NULL REFERENCES game_sessions(id) ON DELETE CASCADE,
      turn_no    INTEGER NOT NULL,
      text       TEXT NOT NULL,
      sheet      TEXT NOT NULL,
      keyword    TEXT NOT NULL,
      created_at TEXT NOT NULL
    );
    CREATE INDEX idx_reads_session ON reads(session_id, turn_no);
    """,
    # v46：NPC 的命（第 122a 批，origins.npc）：一般命、特殊命、哪一讀是真的；走過的章（第 122b 批，JSON）；開著的章（第 122c 批）。開發期，舊 NPC 沒有命
    """
    ALTER TABLE npcs ADD COLUMN fate TEXT NOT NULL DEFAULT '';
    ALTER TABLE npcs ADD COLUMN hidden TEXT NOT NULL DEFAULT '';
    ALTER TABLE npcs ADD COLUMN reading INTEGER NOT NULL DEFAULT 0;
    ALTER TABLE npcs ADD COLUMN chapters TEXT NOT NULL DEFAULT '[]';
    ALTER TABLE npcs ADD COLUMN opened TEXT NOT NULL DEFAULT '';
    """,
    # v47：NPC 的出身（第 7-1a 批，domain/profile.origin）：登錄後回合開頭補一次（people.ensure_now）
    """
    ALTER TABLE npcs ADD COLUMN origin TEXT NOT NULL DEFAULT '';
    """,
    # v48：氣量、口風（第 7-1b 批，npc.TEMPERS）：登錄時擲；開發期舊 NPC 照預設 50（中）
    """
    ALTER TABLE npcs ADD COLUMN tolerance INTEGER NOT NULL DEFAULT 50;
    ALTER TABLE npcs ADD COLUMN discretion INTEGER NOT NULL DEFAULT 50;
    """,
    # v49：學識、專長（第 7-1c 批，domain/learn.py）：回合開頭照出身擲（game/people.ensure_now）
    """
    ALTER TABLE npcs ADD COLUMN learning TEXT NOT NULL DEFAULT '';
    ALTER TABLE npcs ADD COLUMN knacks TEXT NOT NULL DEFAULT '[]';
    """,
    # v50：特點、口頭禪（第 7-1d 批，domain/voice.py）：回合開頭擲（game/people.ensure_now）
    """
    ALTER TABLE npcs ADD COLUMN quirks TEXT NOT NULL DEFAULT '[]';
    ALTER TABLE npcs ADD COLUMN catchphrase TEXT NOT NULL DEFAULT '';
    """,
    # v51：NPC 小事補到哪（第 7-2a 批，domain/chatter.py）：還沒補過是 NULL
    "ALTER TABLE locations ADD COLUMN chat_shichen INTEGER;",
    # v52：新物品的來源（手寫、模型、說書人）、產地（模型寫的綁一州，空＝哪裡都有；第 128-5、128-6 題）。開發期舊的留空
    "ALTER TABLE items_w ADD COLUMN source TEXT NOT NULL DEFAULT ''; ALTER TABLE items_w ADD COLUMN state TEXT NOT NULL DEFAULT '';",
    # v53：模型寫的物品用了哪個零件詞（副作用照 parts.txt 的標的，第 128-10 題甲）。開發期舊的留空
    "ALTER TABLE items_w ADD COLUMN part TEXT NOT NULL DEFAULT '';",
    # v54：模型寫的都市傳說主題（第 128 系列乙，domain/newlegends.py）：只屬這個世界、只在 state 那一州出現；
    # body＝跟 rules/content/legends/ 一樣格式的全文（domain/legends.parse 讀）
    """
    CREATE TABLE legends_w (
      id         TEXT PRIMARY KEY,
      world_id   TEXT NOT NULL REFERENCES worlds(id) ON DELETE CASCADE,
      name       TEXT NOT NULL,
      state      TEXT NOT NULL,
      body       TEXT NOT NULL,
      source     TEXT NOT NULL,
      created_at TEXT NOT NULL,
      UNIQUE (world_id, name)
    );
    """,
    # v55：模型寫的規則怪談主題（第 128 系列乙第二批，domain/newtales.py）：欄位同 legends_w，body 照 rules/content/tales/ 的格式
    """
    CREATE TABLE tales_w (
      id         TEXT PRIMARY KEY,
      world_id   TEXT NOT NULL REFERENCES worlds(id) ON DELETE CASCADE,
      name       TEXT NOT NULL,
      state      TEXT NOT NULL,
      body       TEXT NOT NULL,
      source     TEXT NOT NULL,
      created_at TEXT NOT NULL,
      UNIQUE (world_id, name)
    );
    """,
    # v56：模型寫的事端模板（progress/模型生成內容.md 第八節，domain/newplots.py）：欄位同 tales_w，state＝時代，body 照 rules/content/plots/ 的格式
    """
    CREATE TABLE plots_m (
      id         TEXT PRIMARY KEY,
      world_id   TEXT NOT NULL REFERENCES worlds(id) ON DELETE CASCADE,
      name       TEXT NOT NULL,
      state      TEXT NOT NULL,
      body       TEXT NOT NULL,
      source     TEXT NOT NULL,
      created_at TEXT NOT NULL,
      UNIQUE (world_id, name)
    );
    """,
    # v57：人物卡（第 9e-4 批）：最後見到時的那張卡（seen，含日期、地點）、聽他說過的心事（heard，說出口那句）
    """
    ALTER TABLE npc_relations ADD COLUMN seen TEXT NOT NULL DEFAULT '{}';
    ALTER TABLE npc_relations ADD COLUMN heard TEXT NOT NULL DEFAULT '[]';
    """,
    # v58：重逢（第 9f-1 批）：人物層牌算到哪（你跟他同處時、抽過牌時更新）、家運（地位多加減一級）
    """
    ALTER TABLE npcs ADD COLUMN life_shichen INTEGER;
    ALTER TABLE npcs ADD COLUMN fortune INTEGER NOT NULL DEFAULT 0;
    """,
    # v59：地點裡的小地方（第 9g 批，domain/spots.py）：裡面放了什麼、翻過沒有、收起沒有、最後去過的時刻、來歷特徵（JSON）；NULL＝不是小地方
    "ALTER TABLE locations ADD COLUMN spot TEXT;",
    # 說書立下、要程式執行的規矩（domain/house.py，2026-11-23）
    "ALTER TABLE locations ADD COLUMN rules TEXT;",
]


def connect(path: Path | str) -> sqlite3.Connection:
    conn = sqlite3.connect(str(path), timeout=15, isolation_level=None)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")
    return conn


def migrate(path: Path | str) -> int:
    """套用尚未執行的遷移，回傳目前的 schema 版本。"""
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    conn = connect(path)
    try:
        conn.execute("CREATE TABLE IF NOT EXISTS schema_version (version INTEGER NOT NULL)")
        row = conn.execute("SELECT MAX(version) AS v FROM schema_version").fetchone()
        current = row["v"] or 0
        for version, sql in enumerate(MIGRATIONS, start=1):
            if version <= current:
                continue
            with transaction(conn):
                for stmt in _split_sql(sql):
                    conn.execute(stmt)
                conn.execute("INSERT INTO schema_version(version) VALUES (?)", (version,))
            current = version
        return current
    finally:
        conn.close()


def _split_sql(sql: str) -> list[str]:
    return [s.strip() for s in sql.split(";") if s.strip()]


@contextmanager
def transaction(conn: sqlite3.Connection) -> Iterator[sqlite3.Connection]:
    conn.execute("BEGIN IMMEDIATE")
    try:
        yield conn
    except BaseException:
        conn.execute("ROLLBACK")
        raise
    else:
        conn.execute("COMMIT")
