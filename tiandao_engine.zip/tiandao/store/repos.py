"""資料存取層：全專案唯一出現 SQL 的地方。

規則：
- 這裡只做讀寫，不做遊戲判定。
- 讀取遊戲局一律要帶 user_id（get_session_for_user），從資料層就杜絕跨使用者存取。
"""
from __future__ import annotations

import random
import secrets
import sqlite3
from typing import Any

from ..domain import atlas, favour, legacy, origins, pending, rebirth, society, space
from ..domain import npc as npc_mod
from ..util import dumps, iso, loads, new_id


# ── users / tokens ──────────────────────────────────────────────────────────
def insert_user(conn: sqlite3.Connection, user_id: str, username: str, password_hash: str) -> None:
    conn.execute(
        "INSERT INTO users(id, username, password_hash, created_at) VALUES (?,?,?,?)",
        (user_id, username, password_hash, iso()),
    )


def get_user_by_username(conn: sqlite3.Connection, username: str) -> sqlite3.Row | None:
    return conn.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()


def get_user(conn: sqlite3.Connection, user_id: str) -> sqlite3.Row | None:
    return conn.execute("SELECT id, username, created_at FROM users WHERE id=?", (user_id,)).fetchone()


def insert_token(conn: sqlite3.Connection, token_hash: str, user_id: str, expires_at: str) -> None:
    conn.execute(
        "INSERT INTO auth_tokens(token_hash, user_id, created_at, expires_at) VALUES (?,?,?,?)",
        (token_hash, user_id, iso(), expires_at),
    )


def get_token_user(conn: sqlite3.Connection, token_hash: str, now_iso: str) -> str | None:
    row = conn.execute(
        "SELECT user_id FROM auth_tokens WHERE token_hash=? AND expires_at > ?",
        (token_hash, now_iso),
    ).fetchone()
    return row["user_id"] if row else None


def delete_token(conn: sqlite3.Connection, token_hash: str) -> None:
    conn.execute("DELETE FROM auth_tokens WHERE token_hash=?", (token_hash,))


# ── worlds ──────────────────────────────────────────────────────────────────
ACTIVE_PHASES = ("NEED_CHARACTER", "NEED_OPENING", "PLAYING")   # 與 v4 遷移的部分唯一索引一致


def insert_world(conn, *, world_id: str, user_id: str, name: str, rng_seed: str,
                 kind: str = "origin", clock_shichen: int = 0, uid: str = "") -> None:
    """uid：世界碼，匯入時帶原本的，其他時候新開一個（16v 第 101 題）。"""
    now = iso()
    conn.execute(
        "INSERT INTO worlds(id, user_id, name, kind, clock_shichen, rng_seed, uid, created_at, updated_at)"
        " VALUES (?,?,?,?,?,?,?,?,?)",
        (world_id, user_id, name, kind, clock_shichen, rng_seed, uid or secrets.token_hex(8), now, now),
    )


def get_world_for_user(conn, world_id: str, user_id: str) -> dict[str, Any] | None:
    row = conn.execute("SELECT * FROM worlds WHERE id=? AND user_id=?", (world_id, user_id)).fetchone()
    return dict(row) if row else None


def get_world(conn, world_id: str) -> dict[str, Any]:
    return dict(conn.execute("SELECT * FROM worlds WHERE id=?", (world_id,)).fetchone())


def get_world_or_none(conn, world_id: str) -> dict[str, Any] | None:
    row = conn.execute("SELECT * FROM worlds WHERE id=?", (world_id,)).fetchone()
    return dict(row) if row else None


def list_worlds(conn, user_id: str) -> list[dict[str, Any]]:
    """每個世界附上進行中的局（若有）與已經歷的局數。"""
    placeholders = ",".join("?" * len(ACTIVE_PHASES))
    rows = conn.execute(
        "SELECT w.*,"
        f" (SELECT s.id FROM game_sessions s WHERE s.world_id=w.id AND s.phase IN ({placeholders})) AS active_session_id,"
        " (SELECT COUNT(*) FROM game_sessions s WHERE s.world_id=w.id) AS lives"
        " FROM worlds w WHERE w.user_id=? ORDER BY w.updated_at DESC",
        (*ACTIVE_PHASES, user_id),
    ).fetchall()
    return [dict(r) for r in rows]


def set_world_clock(conn, world_id: str, clock_shichen: int) -> None:
    conn.execute("UPDATE worlds SET clock_shichen=?, updated_at=? WHERE id=?", (clock_shichen, iso(), world_id))


def get_heaven(conn, world_id: str) -> dict | None:
    """天道人格卡（第 18-1 步）；還沒擲回傳 None。"""
    row = conn.execute("SELECT heaven FROM worlds WHERE id=?", (world_id,)).fetchone()
    return loads(row["heaven"], None) if row and row["heaven"] else None


def set_heaven(conn, world_id: str, card: dict) -> None:
    conn.execute("UPDATE worlds SET heaven=? WHERE id=?", (dumps(card), world_id))


def get_era(conn, world_id: str) -> dict | None:
    """時代卡（第 16e 節）；還沒擲回傳 None。"""
    row = conn.execute("SELECT era FROM worlds WHERE id=?", (world_id,)).fetchone()
    return loads(row["era"], None) if row and row["era"] else None


def set_era(conn, world_id: str, card: dict) -> None:
    conn.execute("UPDATE worlds SET era=? WHERE id=?", (dumps(card), world_id))


def get_pressure(conn, world_id: str) -> dict:
    """村鎮的壓力（16v 第 94 題）。"""
    return loads(conn.execute("SELECT pressure FROM worlds WHERE id=?", (world_id,)).fetchone()["pressure"], {})


def set_pressure(conn, world_id: str, card: dict) -> None:
    conn.execute("UPDATE worlds SET pressure=? WHERE id=?", (dumps(card), world_id))


def get_atlas(conn, world_id: str) -> dict | None:
    """天下骨架（16k）；還沒生成回傳 None。"""
    row = conn.execute("SELECT atlas FROM worlds WHERE id=?", (world_id,)).fetchone()
    return loads(row["atlas"], None) if row and row["atlas"] else None


def set_atlas(conn, world_id: str, atlas: dict) -> None:
    conn.execute("UPDATE worlds SET atlas=? WHERE id=?", (dumps(atlas), world_id))


def get_immortal(conn, user_id: str) -> dict | None:
    """仙域骨架（16l）：每個玩家一份；還沒生成回傳 None。"""
    row = conn.execute("SELECT immortal FROM users WHERE id=?", (user_id,)).fetchone()
    return loads(row["immortal"], None) if row and row["immortal"] else None


def set_immortal(conn, user_id: str, realm: dict) -> None:
    conn.execute("UPDATE users SET immortal=? WHERE id=?", (dumps(realm), user_id))


# 記地名的欄位（換時代改地名時一起改，第 16e 節）。新增記地名的欄位要補在這裡
PLACE_COLUMNS = (("locations", "name"), ("locations", "parent"), ("connections", "a"), ("connections", "b"),
                 ("npcs", "location"), ("npcs", "away_from"), ("npcs", "goal_target"),   # 守護的對象可以是地方
                 ("factions", "location"), ("rumors", "place"), ("rumors", "subject"),   # 怪談、傳說的傳聞以地點當主詞
                 ("place_states", "place"), ("relics", "place"), ("undead", "place"), ("domains", "place"),
                 ("domains", "neighbor"), ("legends", "center"), ("legends", "root"), ("legends", "neighbor"),
                 ("legends", "home"), ("memories", "subject"), ("threads", "subject"),
                 ("rites", "town"), ("rites", "source"), ("rites", "place"), ("plots_w", "town"))


def rename_place(conn, world_id: str, old: str, new: str) -> None:
    """地點改名：所有記地名的欄位，以及這個世界每一生的角色卡與回合紀錄（JSON 裡完整等於地名的字串；
    下一回合要用上回合紀錄裡的領域、都市傳說的地點來認）。"""
    for table, column in PLACE_COLUMNS:
        conn.execute(f"UPDATE {table} SET {column}=? WHERE world_id=? AND {column}=?", (new, world_id, old))
    for table, column in (("characters", "sheet_json"), ("turns", "delta_json")):
        conn.execute(f"UPDATE {table} SET {column}=REPLACE({column}, ?, ?)"
                     " WHERE session_id IN (SELECT id FROM game_sessions WHERE world_id=?)",
                     (dumps(old), dumps(new), world_id))
    conn.execute("UPDATE worlds SET atlas=REPLACE(atlas, ?, ?) WHERE id=?", (dumps(old), dumps(new), world_id))   # 主城
    conn.execute("UPDATE ledger SET body=REPLACE(body, ?, ?) WHERE world_id=?", (dumps(old), dumps(new), world_id))   # 等你處理的事（第 1-6 批）


def set_location_type(conn, world_id: str, name: str, loc_type: str) -> None:
    conn.execute("UPDATE locations SET loc_type=? WHERE world_id=? AND name=?", (loc_type, world_id, name))


def set_features(conn, world_id: str, name: str, features: list[dict]) -> None:
    conn.execute("UPDATE locations SET features=? WHERE world_id=? AND name=?", (dumps(features), world_id, name))


def set_description(conn, world_id: str, names: list[str], text: str) -> None:
    conn.executemany("UPDATE locations SET description=? WHERE world_id=? AND name=?",
                     [(text, world_id, n) for n in names])


# ── 棋譜（第 18-2a 步）────────────────────────────────────────────────────
GAME_FIELDS = ("session_id", "no", "kind", "name", "result", "started_shichen", "started_turn", "ended_shichen",
               "ended_turn")


def insert_game(conn, world_id: str, game: dict[str, Any]) -> None:
    conn.execute(f"INSERT INTO heaven_games(id, world_id, {', '.join(GAME_FIELDS)}, created_at)"
                 f" VALUES (?,?,{','.join('?' * len(GAME_FIELDS))},?)",
                 (new_id("hgm"), world_id, *(game[k] for k in GAME_FIELDS), iso()))


def end_game(conn, world_id: str, no: int, result: str, clock_shichen: int, turn_no: int) -> None:
    conn.execute("UPDATE heaven_games SET result=?, ended_shichen=?, ended_turn=? WHERE world_id=? AND no=?",
                 (result, clock_shichen, turn_no, world_id, no))


def list_games(conn, world_id: str) -> list[dict[str, Any]]:
    rows = conn.execute("SELECT * FROM heaven_games WHERE world_id=? ORDER BY no", (world_id,))
    return [dict(r) for r in rows]


# ── 遺物（第 11-1 步）────────────────────────────────────────────────────
RELIC_FIELDS = ("owner", "name", "tier", "count", "holder", "place", "placed_shichen", "lasts")


def insert_relic(conn, world_id: str, session_id: str, relic: dict[str, Any]) -> None:
    conn.execute(f"INSERT INTO relics(id, world_id, session_id, {', '.join(RELIC_FIELDS)}, created_at)"
                 f" VALUES (?,?,?,{','.join('?' * len(RELIC_FIELDS))},?)",
                 (new_id("rlc"), world_id, session_id, *(relic[k] for k in RELIC_FIELDS), iso()))


def list_relics(conn, world_id: str) -> list[dict[str, Any]]:
    rows = conn.execute("SELECT * FROM relics WHERE world_id=? ORDER BY created_at, rowid", (world_id,))
    return [{**dict(r), "life": r["session_id"]} for r in rows]


def take_relic(conn, relic_id: str) -> None:
    conn.execute("DELETE FROM relics WHERE id=?", (relic_id,))


def drop_relics(conn, world_id: str, holder: str, clock_shichen: int, lost: str, to: str = "") -> None:
    """持有的人死了：他帶著的遺物落在他（死時）所在的地點；死在 lost（沒有登錄的遠方）的跟著下落不明。
    to：客死異鄉變成都市傳說的（第 19-2 步），遺物落在傳說的根源處。"""
    if to:
        conn.execute("UPDATE relics SET holder='', placed_shichen=?, place=? WHERE world_id=? AND holder=?",
                     (clock_shichen, to, world_id, holder))
        return
    conn.execute("DELETE FROM relics WHERE world_id=? AND holder=?"
                 " AND (SELECT location FROM npcs WHERE world_id=? AND name=?)=?",
                 (world_id, holder, world_id, holder, lost))
    conn.execute("UPDATE relics SET holder='', placed_shichen=?,"
                 " place=(SELECT location FROM npcs WHERE world_id=? AND name=?) WHERE world_id=? AND holder=?",
                 (clock_shichen, world_id, holder, world_id, holder))


# ── 亡者（第 11-2 步）────────────────────────────────────────────────────
UNDEAD_FIELDS = ("name", "form", "lv", "died_shichen", "place", "condition", "grudge", "grudge_on", "awake")


def insert_undead(conn, world_id: str, session_id: str, u: dict[str, Any]) -> None:
    conn.execute(f"INSERT INTO undead(id, world_id, session_id, {', '.join(UNDEAD_FIELDS)}, created_at)"
                 f" VALUES (?,?,?,{','.join('?' * len(UNDEAD_FIELDS))},?)",
                 (new_id("und"), world_id, session_id, *(int(u[k]) if k == "awake" else u[k] for k in UNDEAD_FIELDS),
                  iso()))


def list_undead(conn, world_id: str) -> list[dict[str, Any]]:
    rows = conn.execute("SELECT * FROM undead WHERE world_id=? ORDER BY created_at, rowid", (world_id,))
    return [{**dict(r), "awake": bool(r["awake"])} for r in rows]


def update_undead(conn, undead_id: str, condition: str, awake: bool, form: str = "") -> None:
    """form：改形態（舊亡魂作祟＝幽魂變屍變，執念跟著清掉；domain/newghosts.py）。"""
    if form:
        conn.execute("UPDATE undead SET form=?, grudge='', grudge_on='' WHERE id=?", (form, undead_id))
    conn.execute("UPDATE undead SET condition=?, awake=? WHERE id=?", (condition, int(awake), undead_id))


# ── 前期領域（第 19-1 步）────────────────────────────────────────────────
DOMAIN_FIELDS = ("tale", "scale", "place", "neighbor", "person", "ghost", "rules", "life", "step", "strikes", "staged",
                 "chased", "status", "created_shichen", "solved_shichen")
_DOMAIN_JSON = ("rules", "staged")


def _domain_values(d: dict[str, Any]) -> list:
    return [dumps(d[k]) if k in _DOMAIN_JSON else int(d[k]) if k == "chased" else d[k] for k in DOMAIN_FIELDS]


def insert_domain(conn, world_id: str, d: dict[str, Any]) -> None:
    conn.execute(f"INSERT INTO domains(id, world_id, {', '.join(DOMAIN_FIELDS)}, created_at)"
                 f" VALUES (?,?,{','.join('?' * len(DOMAIN_FIELDS))},?)",
                 (new_id("dom"), world_id, *_domain_values(d), iso()))


def update_domain(conn, domain_id: str, d: dict[str, Any]) -> None:
    conn.execute(f"UPDATE domains SET {', '.join(f'{k}=?' for k in DOMAIN_FIELDS)} WHERE id=?",
                 (*_domain_values(d), domain_id))


def list_domains(conn, world_id: str) -> list[dict[str, Any]]:
    rows = conn.execute("SELECT * FROM domains WHERE world_id=? ORDER BY created_at, rowid", (world_id,))
    return [{**dict(r), "rules": loads(r["rules"], []), "staged": loads(r["staged"], []), "chased": bool(r["chased"])}
            for r in rows]


# ── 都市傳說（第 19-2 步）────────────────────────────────────────────────
LEGEND_FIELDS = ("theme", "center", "root", "neighbor", "dead", "target", "home", "met", "step", "misses", "chased",
                 "haunts", "haunt_until", "status", "created_shichen", "moved_shichen", "solved_shichen", "rewarded")


def insert_legend(conn, world_id: str, g: dict[str, Any]) -> None:
    conn.execute(f"INSERT INTO legends(id, world_id, {', '.join(LEGEND_FIELDS)}, created_at)"
                 f" VALUES (?,?,{','.join('?' * len(LEGEND_FIELDS))},?)",
                 (new_id("lgd"), world_id, *(int(g[k]) if k == "chased" else g[k] for k in LEGEND_FIELDS), iso()))


def update_legend(conn, legend_id: str, g: dict[str, Any]) -> None:
    conn.execute(f"UPDATE legends SET {', '.join(f'{k}=?' for k in LEGEND_FIELDS)} WHERE id=?",
                 (*(int(g[k]) if k == "chased" else g[k] for k in LEGEND_FIELDS), legend_id))


# ── 流傳中的玩法（19-3）────────────────────────────────────────────────────
RITE_FIELDS = ("tale", "town", "source", "place", "stage", "person", "cut", "known", "next_shichen", "created_shichen",
               "ended_shichen")


def insert_rite(conn, world_id: str, r: dict[str, Any]) -> None:
    conn.execute(f"INSERT INTO rites(id, world_id, {', '.join(RITE_FIELDS)}, created_at)"
                 f" VALUES (?,?,{','.join('?' * len(RITE_FIELDS))},?)",
                 (new_id("rit"), world_id, *(int(r[k]) if k == "cut" else r[k] for k in RITE_FIELDS), iso()))


def update_rite(conn, rite_id: str, r: dict[str, Any]) -> None:
    conn.execute(f"UPDATE rites SET {', '.join(f'{k}=?' for k in RITE_FIELDS)} WHERE id=?",
                 (*(int(r[k]) if k == "cut" else r[k] for k in RITE_FIELDS), rite_id))


def list_rites(conn, world_id: str) -> list[dict[str, Any]]:
    rows = conn.execute("SELECT * FROM rites WHERE world_id=? ORDER BY created_at, rowid", (world_id,))
    return [{**dict(r), "cut": bool(r["cut"])} for r in rows]


def list_legends(conn, world_id: str) -> list[dict[str, Any]]:
    rows = conn.execute("SELECT * FROM legends WHERE world_id=? ORDER BY created_at, rowid", (world_id,))
    return [{**dict(r), "chased": bool(r["chased"])} for r in rows]


# ── game sessions ───────────────────────────────────────────────────────────
def insert_session(conn, *, session_id: str, user_id: str, world_id: str, title: str, phase: str, rng_seed: str,
                   turn_no: int = 0, clock_shichen: int = 0, shared: bool = False) -> None:
    """shared：仙域裡的局（16l），同一個世界可以同時有好幾局。"""
    now = iso()
    conn.execute(
        "INSERT INTO game_sessions(id, user_id, world_id, title, phase, turn_no, clock_shichen, rng_seed,"
        " created_at, updated_at, shared) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
        (session_id, user_id, world_id, title, phase, turn_no, clock_shichen, rng_seed, now, now, int(shared)),
    )


def list_sessions_in_world(conn, world_id: str) -> list[dict[str, Any]]:
    rows = conn.execute("SELECT * FROM game_sessions WHERE world_id=? ORDER BY created_at, rowid", (world_id,))
    return [dict(r) for r in rows]


def get_session_for_user(conn, session_id: str, user_id: str) -> dict[str, Any] | None:
    row = conn.execute(
        "SELECT * FROM game_sessions WHERE id=? AND user_id=?", (session_id, user_id)
    ).fetchone()
    return dict(row) if row else None


def list_sessions(conn, user_id: str) -> list[dict[str, Any]]:
    rows = conn.execute(
        "SELECT s.id, s.world_id, w.name AS world_name, s.title, s.phase, s.turn_no, s.clock_shichen,"
        " s.created_at, s.updated_at"
        " FROM game_sessions s JOIN worlds w ON w.id = s.world_id WHERE s.user_id=? ORDER BY s.updated_at DESC",
        (user_id,),
    ).fetchall()
    return [dict(r) for r in rows]


def advance_session(conn, session_id: str, *, expected_turn_no: int, new_turn_no: int,
                    phase: str, clock_shichen: int) -> None:
    """樂觀鎖：只有 turn_no 仍是 expected_turn_no 時才更新，否則代表有並行請求先寫入。

    同一個交易內一併推進世界時間：一個世界同時只有一局，進行中的局的時間就是世界的時間。
    局的 clock_shichen 則保留為「這一生最後一回合的時間」，局結束後世界可以繼續往後走。
    世界時間只往前走（16l：仙域同時有好幾局，下界的時間也會流進來，不能被較舊的局蓋回去）。
    """
    cur = conn.execute(
        "UPDATE game_sessions SET turn_no=?, phase=?, clock_shichen=?, updated_at=?"
        " WHERE id=? AND turn_no=?",
        (new_turn_no, phase, clock_shichen, iso(), session_id, expected_turn_no),
    )
    if cur.rowcount != 1:
        from ..errors import Conflict
        raise Conflict("這一局剛被另一個請求更新，請重新整理後再試。", code="turn_conflict")
    conn.execute(
        "UPDATE worlds SET clock_shichen=MAX(clock_shichen, ?), updated_at=?"
        " WHERE id=(SELECT world_id FROM game_sessions WHERE id=?)",
        (clock_shichen, iso(), session_id),
    )


def transition_phase(conn, session_id: str, *, from_phase: str, to_phase: str) -> None:
    """只有目前仍處於 from_phase 時才切換，避免兩個請求同時建角或同時開場。"""
    cur = conn.execute(
        "UPDATE game_sessions SET phase=?, updated_at=? WHERE id=? AND phase=?",
        (to_phase, iso(), session_id, from_phase),
    )
    if cur.rowcount != 1:
        from ..errors import Conflict
        raise Conflict("這一局的狀態已經改變，請重新整理後再試。", code="phase_conflict")


# ── characters ──────────────────────────────────────────────────────────────
def upsert_character(conn, session_id: str, sheet: dict[str, Any]) -> None:
    """等你處理的事（回音、請託、風聲、暗線、破格）拆出來存在帳上（domain/pending.py，第 1-6 批），每次整份換掉。"""
    world = conn.execute("SELECT s.world_id, w.clock_shichen FROM game_sessions s JOIN worlds w ON w.id=s.world_id WHERE s.id=?",
                         (session_id,)).fetchone()
    kept, rows = pending.split(sheet, session_id, world["clock_shichen"]) if world else (sheet, [])
    conn.execute(
        "INSERT INTO characters(session_id, sheet_json, updated_at) VALUES (?,?,?)"
        " ON CONFLICT(session_id) DO UPDATE SET sheet_json=excluded.sheet_json, updated_at=excluded.updated_at",
        (session_id, dumps(kept), iso()),
    )
    if world:
        conn.execute(f"DELETE FROM ledger WHERE session_id=? AND kind IN ({', '.join('?' * len(pending.KINDS))})", (session_id, *pending.KINDS))
        for r in rows:
            insert_book(conn, "ledger", world["world_id"], r)
    _mirror_sect(conn, session_id, sheet)


def _mirror_sect(conn, session_id: str, sheet: dict[str, Any]) -> None:
    """角色卡的門派照抄成主角這一生的「成員」關係（第 1-3b 批）：入門、辭別、除名、叛門、飛升、立宗都改角色卡，
    在這裡一次對齊；這一生結束了就拿掉。"""
    s = conn.execute("SELECT world_id, phase FROM game_sessions WHERE id=?", (session_id,)).fetchone()
    if not s:
        return
    hall = (sheet.get("sect") or "") if s["phase"] != "ENDED" else ""   # game.phases.ENDED
    now = conn.execute("SELECT b FROM bonds WHERE world_id=? AND a_kind=? AND a=? AND type='成員'",
                       (s["world_id"], society.PLAYER, session_id)).fetchone()
    if (now["b"] if now else "") == hall:
        return
    conn.execute("DELETE FROM bonds WHERE world_id=? AND a_kind=? AND a=? AND type='成員'", (s["world_id"], society.PLAYER, session_id))
    if hall:
        insert_bond(conn, s["world_id"], session_id, {"a_kind": society.PLAYER, "a": session_id, "b_kind": society.FACTION,
                                                      "b": hall, "type": "成員", "clock_shichen": sheet.get("sect_back") or 0, "turn_no": 0})


def get_character(conn, session_id: str) -> dict[str, Any] | None:
    row = conn.execute("SELECT sheet_json FROM characters WHERE session_id=?", (session_id,)).fetchone()
    if not row:
        return None
    rows = conn.execute(f"SELECT kind, body FROM ledger WHERE session_id=? AND kind IN ({', '.join('?' * len(pending.KINDS))}) ORDER BY rowid",
                        (session_id, *pending.KINDS))
    return pending.join(loads(row["sheet_json"], None), [{"kind": r["kind"], "body": loads(r["body"], {})} for r in rows])


# ── turns ───────────────────────────────────────────────────────────────────
def insert_turn(conn, turn: dict[str, Any]) -> None:
    conn.execute(
        "INSERT INTO turns(id, session_id, turn_no, request_id, kind, player_input, judgment_json,"
        " delta_json, narrative, choices_json, choice_tags_json, model, created_at)"
        " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (
            turn["id"], turn["session_id"], turn["turn_no"], turn["request_id"], turn["kind"],
            turn["player_input"], dumps(turn["judgment"]), dumps(turn["delta"]),
            turn["narrative"], dumps(turn["choices"]), dumps(turn.get("choice_tags", [])), turn["model"],
            turn.get("created_at") or iso(),
        ),
    )


def _turn_row(row: sqlite3.Row) -> dict[str, Any]:
    return {
        "id": row["id"], "session_id": row["session_id"], "turn_no": row["turn_no"],
        "request_id": row["request_id"], "kind": row["kind"], "player_input": row["player_input"],
        "judgment": loads(row["judgment_json"], {}), "delta": loads(row["delta_json"], {}),
        "narrative": row["narrative"], "choices": loads(row["choices_json"], []),
        "choice_tags": loads(row["choice_tags_json"], []),
        "model": row["model"], "created_at": row["created_at"],
    }


def get_turn_by_request(conn, session_id: str, request_id: str) -> dict[str, Any] | None:
    row = conn.execute(
        "SELECT * FROM turns WHERE session_id=? AND request_id=?", (session_id, request_id)
    ).fetchone()
    return _turn_row(row) if row else None


def list_turns(conn, session_id: str, *, after: int = -1, limit: int = 50) -> list[dict[str, Any]]:
    rows = conn.execute(
        "SELECT * FROM turns WHERE session_id=? AND turn_no>? ORDER BY turn_no ASC LIMIT ?",
        (session_id, after, limit),
    ).fetchall()
    return [_turn_row(r) for r in rows]


def recent_turns(conn, session_id: str, count: int) -> list[dict[str, Any]]:
    rows = conn.execute(
        "SELECT * FROM turns WHERE session_id=? ORDER BY turn_no DESC LIMIT ?", (session_id, count)
    ).fetchall()
    return [_turn_row(r) for r in reversed(rows)]


# ── 世界：地點與 NPC（屬於世界；只寫入已通過 game/proposals.py 審核的資料）──────
def insert_location(conn, world_id: str, session_id: str, loc: dict[str, Any]) -> None:
    """session_id 是首次登錄這個地點的那一局（用來標出哪一回合有新發現）；系統自動登錄的地點給空字串。"""
    if not space._NAME_RE.match(loc["name"]):   # 防呆：存檔讀不回來的地名當場擋下，好找出是誰生的
        raise ValueError(f"地名不合法：{loc['name']}（上層：{loc.get('parent', '')}）")
    conn.execute(
        "INSERT INTO locations(id, world_id, name, description, loc_type, parent, scale, danger,"
        " discovered_session_id, discovered_turn, created_at, features, chat_shichen, spot, rules) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (new_id("loc"), world_id, loc["name"], loc["description"], loc["type"], loc.get("parent", ""),
         loc.get("scale", ""), loc.get("danger", ""), session_id, loc["discovered_turn"], iso(),
         None if loc.get("features") is None else dumps(loc["features"]), loc.get("chat_shichen"),
         None if loc.get("spot") is None else dumps(loc["spot"]), None if not loc.get("rules") else dumps(loc["rules"])),
    )


def set_rules(conn, world_id: str, name: str, rules: list) -> None:
    """說書立下的規矩（domain/house.py）。"""
    conn.execute("UPDATE locations SET rules=? WHERE world_id=? AND name=?", (dumps(rules), world_id, name))


def set_spot(conn, world_id: str, name: str, spot: dict) -> None:
    """小地方去過、翻過、收起（第 9g 批）。"""
    conn.execute("UPDATE locations SET spot=? WHERE world_id=? AND name=?", (dumps(spot), world_id, name))


def list_locations(conn, world_id: str) -> list[dict[str, Any]]:
    rows = conn.execute(
        "SELECT name, description, loc_type, parent, scale, danger, discovered_session_id, discovered_turn, features, chat_shichen, spot, rules"
        " FROM locations WHERE world_id=? ORDER BY created_at, rowid", (world_id,),
    ).fetchall()
    return [{"name": r["name"], "description": r["description"], "type": r["loc_type"], "parent": r["parent"],
             "scale": r["scale"], "danger": r["danger"], "features": loads(r["features"], None) if r["features"] else None,
             "discovered_session_id": r["discovered_session_id"], "discovered_turn": r["discovered_turn"],
             "chat_shichen": r["chat_shichen"], "spot": loads(r["spot"], None) if r["spot"] else None,
             "rules": loads(r["rules"], None) if r["rules"] else None}
            for r in rows]


def set_chat(conn, world_id: str, name: str, clock_shichen: int) -> None:
    """這一處的 NPC 小事補到這一刻（第 7-2a 批）。"""
    conn.execute("UPDATE locations SET chat_shichen=? WHERE world_id=? AND name=?", (clock_shichen, world_id, name))


def insert_connection(conn, world_id: str, session_id: str, edge: dict[str, Any]) -> bool:
    """登錄兩地之間的路。已經有路（不論哪個方向）就不重複登錄，回傳 False。"""
    exists = conn.execute(
        "SELECT 1 FROM connections WHERE world_id=? AND ((a=? AND b=?) OR (a=? AND b=?))",
        (world_id, edge["a"], edge["b"], edge["b"], edge["a"]),
    ).fetchone()
    if exists or edge["a"] == edge["b"]:
        return False
    conn.execute(
        "INSERT INTO connections(id, world_id, a, b, distance_km, tier, direction, discovered_session_id,"
        " discovered_turn, created_at) VALUES (?,?,?,?,?,?,?,?,?,?)",
        (new_id("con"), world_id, edge["a"], edge["b"], edge["distance_km"], edge["tier"], edge.get("direction", ""),
         session_id, edge.get("discovered_turn", 0), iso()),
    )
    return True


def list_connections(conn, world_id: str) -> list[dict[str, Any]]:
    rows = conn.execute(
        "SELECT a, b, distance_km, tier, direction, discovered_session_id, discovered_turn FROM connections"
        " WHERE world_id=? ORDER BY created_at, rowid", (world_id,),
    ).fetchall()
    return [dict(r) for r in rows]


_NPC_COLUMNS = ("name", "appearance", "profile", "location", "status", "ai_driven", "created_by", "race",
                "gender", "lineage", "job", "birth_shichen", "realm_lv", "stage_index", "hidden_power", "condition_state", "speech",
                "appearance_age", "profile_age", "speech_age", "goal", "goal_target", "ambition", "kindness",
                "courage", "suspicion", "heaven_role", "rewrite_reason", "evolved_shichen", "cultivation",
                "away_since", "away_from", "first_seen_session_id", "first_seen_turn", *origins.NPC_KEYS, "chapters", "opened", "origin", *npc_mod.TEMPERS, "learning", "knacks", "quirks", "catchphrase", "life_shichen", "fortune")
NPC_UPDATABLE = {"appearance", "profile", "speech", "appearance_age", "profile_age", "speech_age",
                 "location", "status", "realm_lv", "stage_index", "condition", "goal", "goal_target",
                 "ambition", "kindness", "courage", "suspicion", "heaven_role", "rewrite_reason",
                 "evolved_shichen", "cultivation", "away_since", "away_from", "job",
                 "chapters", "opened", "origin", *npc_mod.TEMPERS, "learning", "knacks", "quirks", "catchphrase", "life_shichen", "fortune"}   # 名字、種族、出生不可改；origin：出身（第 7-1a 批）；chapters、opened：特殊命走過的章、開著的章（第 122b、122c 批，evolution.chapter）
NPC_DEFAULTS = {"race": "人族", "gender": "", "lineage": "", "job": "", "birth_shichen": None, "realm_lv": 0, "stage_index": 0, "hidden_power": False,
                 "condition": "無恙", "speech": "", "appearance_age": None, "profile_age": None, "speech_age": None,
                 "goal": "", "goal_target": "", "ambition": 50, "kindness": 50, "courage": 50, "suspicion": 50,
                 "heaven_role": "", "rewrite_reason": "", "evolved_shichen": None, "cultivation": 0,
                 "away_since": None, "away_from": "", "chapters": [], "opened": "", "origin": "", "learning": "", "knacks": [], "quirks": [], "catchphrase": "",
                "life_shichen": None, "fortune": 0}   # 重逢（第 9f-1 批）：人物層牌算到哪、家運


def _npc_value(v):
    """ai_driven、hidden_power 存成整數，chapters 存成 JSON。"""
    return 1 if v is True else 0 if v is False else dumps(v) if isinstance(v, list) else v


def insert_npc(conn, world_id: str, session_id: str, npc: dict[str, Any], past: bool = True) -> None:
    """沒帶命的照世界＋名字抽一個（第 122a 批，origins.npc）；命一生不變，不在 NPC_UPDATABLE。
    past：新人抽前世（第 7-5c 批）；讀檔、搬家（升仙域）的不抽，前世的主角也不抽。"""
    if past and npc.get("created_by") != legacy.RETIRED_BY:
        _reborn(conn, world_id, npc)
    row = {**NPC_DEFAULTS, **origins.npc(random.Random(f"{world_id}|命|{npc['name']}")),
           **npc_mod.roll_tempers(random.Random(f"{world_id}|性|{npc['name']}")), **npc}   # 氣量、口風（第 7-1b 批）
    columns = [c for c in _NPC_COLUMNS if c not in ("first_seen_session_id", "first_seen_turn")]
    values = [_npc_value(row["condition"] if c == "condition_state" else row[c]) for c in columns]
    conn.execute(
        f"INSERT INTO npcs(id, world_id, {', '.join(columns)}, first_seen_session_id, first_seen_turn, created_at)"
        f" VALUES ({', '.join('?' * (len(columns) + 5))})",
        (new_id("npc"), world_id, *values, session_id, npc["first_seen_turn"], iso()),
    )


def _reborn(conn, world_id: str, p: dict[str, Any]) -> None:
    """從他那一州（沒有就鄰州）的待投胎名單抽前世（rebirth.draw）：抽中的那筆了結，settle 寫他的名字。"""
    rows = conn.execute("SELECT id, a, body FROM ledger WHERE world_id=? AND kind=? AND status=?",
                        (world_id, society.WAITING, society.OPEN)).fetchall()
    a = get_atlas(conn, world_id) if rows else None
    if not a:
        return
    state = atlas.state_of(a, list_connections(conn, world_id), p.get("location", ""))
    w = rebirth.draw(random.Random(f"{world_id}|前世|{p['name']}"), [{**dict(r), "body": loads(r["body"], {})} for r in rows],
                     state["name"], atlas.near_states(a, state), p.get("birth_shichen"))
    if w:
        conn.execute("UPDATE ledger SET status=?, settle=? WHERE id=?", (society.DONE, p["name"], w["id"]))


def wake(conn, ledger_id: str, when: int) -> None:
    """轉世的人覺醒了（第 7-5c 批）：那筆名單 body 記「醒」。"""
    body = loads(conn.execute("SELECT body FROM ledger WHERE id=?", (ledger_id,)).fetchone()["body"], {})
    conn.execute("UPDATE ledger SET body=? WHERE id=?", (dumps({**body, "醒": when}), ledger_id))


def list_npcs(conn, world_id: str) -> list[dict[str, Any]]:
    rows = conn.execute(
        f"SELECT {', '.join(_NPC_COLUMNS)} FROM npcs WHERE world_id=? ORDER BY created_at, rowid", (world_id,),
    ).fetchall()
    return [{**{k: r[k] for k in _NPC_COLUMNS if k != "condition_state"}, "condition": r["condition_state"],
             "ai_driven": bool(r["ai_driven"]), "hidden_power": bool(r["hidden_power"]), "chapters": loads(r["chapters"], []),
             "knacks": loads(r["knacks"], []), "quirks": loads(r["quirks"], [])} for r in rows]


def update_npc(conn, world_id: str, name: str, fields: dict[str, Any]) -> None:
    """只允許改 NPC_UPDATABLE 裡的欄位；名字、種族、出生不可改（第 6 步）。"""
    bad = set(fields) - NPC_UPDATABLE
    if bad:
        raise ValueError(f"NPC 欄位不可修改：{sorted(bad)}")
    columns = {("condition_state" if k == "condition" else k): _npc_value(v) for k, v in fields.items()}
    sets = ", ".join(f"{k}=?" for k in columns)
    conn.execute(f"UPDATE npcs SET {sets} WHERE world_id=? AND name=?", (*columns.values(), world_id, name))


def set_rewrite(conn, world_id: str, names: list[str], reason: str) -> None:
    """一批 NPC 標同一個改寫原因（換時代，第 8-3 批）。"""
    conn.executemany("UPDATE npcs SET rewrite_reason=? WHERE world_id=? AND name=?", [(reason, world_id, n) for n in names])


_FAVOURS = "FROM ledger WHERE world_id=? AND session_id IN (a, b) AND kind IN (?, ?)"   # 主角的人情（第 1-4a 批）


def _favours(conn, world_id: str, more: str = "", args: tuple = ()) -> dict[tuple[str, str], list[dict]]:
    """（NPC, 那一生）→ 人情清單，照寫入的順序。"""
    out: dict[tuple[str, str], list[dict]] = {}
    for r in conn.execute(f"SELECT session_id, kind, a, b, event_id, deadline_shichen, body, clock_shichen {_FAVOURS}{more} ORDER BY rowid",
                          (world_id, *favour.KINDS, *args)):
        r = {**dict(r), "body": loads(r["body"], {})}
        out.setdefault((r["b"] if r["a"] == r["session_id"] else r["a"], r["session_id"]), []).append(favour.back(r))
    return out


def get_relation(conn, world_id: str, npc_name: str, session_id: str) -> dict[str, Any] | None:
    row = conn.execute("SELECT grudge FROM npc_relations WHERE world_id=? AND npc_name=? AND session_id=?",
                       (world_id, npc_name, session_id)).fetchone()
    pair = " AND session_id=? AND ? IN (a, b)", (session_id, npc_name)
    return {**dict(row), "favours": _favours(conn, world_id, *pair).get((npc_name, session_id), [])} if row else None


def set_known_goal(conn, world_id: str, npc_name: str, session_id: str, text: str, clock_shichen: int) -> None:
    """這一生的主角打聽到某人的目標（第 10b 步）。沒有關係紀錄時建一筆中立的。"""
    conn.execute(
        "INSERT INTO npc_relations(world_id, npc_name, session_id, known_goal, known_goal_shichen, updated_at)"
        " VALUES (?,?,?,?,?,?) ON CONFLICT(world_id, npc_name, session_id) DO UPDATE SET"
        " known_goal=excluded.known_goal, known_goal_shichen=excluded.known_goal_shichen, updated_at=excluded.updated_at",
        (world_id, npc_name, session_id, text, clock_shichen, iso()),
    )


def upsert_relation(conn, world_id: str, npc_name: str, session_id: str, relation: dict[str, Any]) -> None:
    """帶 favours 的：這一生和他的人情帳整份換掉（存在帳上）；沒帶的不動。這回合新加的原因（adds）寫進 reasons，記在這一生；
    同一筆寫兩次只留一筆。好感、信任不存（讀的時候由原因算，npc.scored）。"""
    conn.execute(
        "INSERT INTO npc_relations(world_id, npc_name, session_id, grudge, met, updated_at) VALUES (?,?,?,?,?,?)"
        " ON CONFLICT(world_id, npc_name, session_id) DO UPDATE SET grudge=excluded.grudge, met=excluded.met, updated_at=excluded.updated_at",
        (world_id, npc_name, session_id, relation["grudge"], relation.get("met", 1), iso()),
    )
    if "favours" in relation:
        conn.execute(f"DELETE {_FAVOURS} AND session_id=? AND ? IN (a, b)", (world_id, *favour.KINDS, session_id, npc_name))
        for f in relation["favours"]:
            insert_book(conn, "ledger", world_id, favour.row(f, npc_name, session_id))
    for r in relation.get("adds", []):
        insert_book(conn, "reasons", world_id, {**r, "session_id": session_id})


def set_card(conn, world_id: str, npc_name: str, session_id: str, *, seen: dict | None = None, heard: list | None = None) -> None:
    """人物卡（第 9e-4 批）：最後見到時的卡、聽過的心事。只改已經有的關係（沒見過面的不建）。"""
    for col, v in (("seen", seen), ("heard", heard)):
        if v is not None:
            conn.execute(f"UPDATE npc_relations SET {col}=? WHERE world_id=? AND npc_name=? AND session_id=?",
                         (dumps(v), world_id, npc_name, session_id))


def list_relations(conn, world_id: str) -> list[dict[str, Any]]:
    rows = conn.execute("SELECT npc_name, session_id, grudge, known_goal, known_goal_shichen, met, seen, heard"
                        " FROM npc_relations WHERE world_id=? ORDER BY npc_name, session_id", (world_id,))
    book = _favours(conn, world_id)
    return [{**dict(r), "seen": loads(r["seen"], {}), "heard": loads(r["heard"], []),
             "favours": book.get((r["npc_name"], r["session_id"]), [])} for r in rows]


# ── 勢力與羈絆（第 10a 步）─────────────────────────────────────────────────
_FACTION_COLUMNS = ("name", "type", "location", "discovered_session_id", "discovered_turn", "traits")
_BOND_COLUMNS = ("session_id", "a_kind", "a", "b_kind", "b", "type", "clock_shichen", "turn_no")


def insert_faction(conn, world_id: str, session_id: str, faction: dict[str, Any]) -> None:
    conn.execute("INSERT INTO factions(id, world_id, name, type, location, discovered_session_id, discovered_turn,"
                 " traits, created_at) VALUES (?,?,?,?,?,?,?,?,?)",
                 (new_id("fac"), world_id, faction["name"], faction["type"], faction["location"], session_id,
                  faction["discovered_turn"], dumps(faction.get("traits", {})), iso()))


def list_factions(conn, world_id: str) -> list[dict[str, Any]]:
    rows = conn.execute(f"SELECT {', '.join(_FACTION_COLUMNS)} FROM factions WHERE world_id=?"
                        " ORDER BY created_at, rowid", (world_id,))
    return [{**dict(r), "traits": loads(r["traits"], {})} for r in rows]


ITEM_FIELDS = ("name", "base", "description", "discovered_turn", "source", "state", "part")   # 世界長出來的新物品（16p；來源、產地、零件詞第 128 系列）


def insert_item(conn, world_id: str, session_id: str, item: dict[str, Any]) -> None:
    conn.execute("INSERT INTO items_w(id, world_id, name, base, description, discovered_session_id, discovered_turn,"
                 " created_at, source, state, part) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                 (new_id("itm"), world_id, *(item[k] for k in ITEM_FIELDS[:3]), session_id, item["discovered_turn"], iso(),
                  item.get("source") or "", item.get("state") or "", item.get("part") or ""))


def list_items(conn, world_id: str) -> list[dict[str, Any]]:
    rows = conn.execute("SELECT * FROM items_w WHERE world_id=? ORDER BY created_at, rowid", (world_id,))
    return [dict(r) for r in rows]


THEME_FIELDS = ("name", "state", "body", "source")   # 模型寫的主題（第 128 系列乙）：都市傳說 legends_w、規則怪談 tales_w
LEGENDS_W, TALES_W, PLOTS_M = "legends_w", "tales_w", "plots_m"   # plots_m：模型寫的事端模板（state＝時代）


def insert_theme(conn, world_id: str, t: dict[str, Any], table: str = LEGENDS_W) -> None:
    conn.execute(f"INSERT INTO {table}(id, world_id, {', '.join(THEME_FIELDS)}, created_at) VALUES (?,?,?,?,?,?,?)",
                 (new_id("thm"), world_id, *(t[k] for k in THEME_FIELDS), iso()))


def list_themes(conn, world_id: str, table: str = LEGENDS_W) -> list[dict[str, Any]]:
    rows = conn.execute(f"SELECT * FROM {table} WHERE world_id=? ORDER BY created_at, rowid", (world_id,))
    return [dict(r) for r in rows]


EVENT_FIELDS = ("name", "base", "scene", "discovered_turn")   # 世界長出來的新事件（16p）


def insert_event(conn, world_id: str, session_id: str, event: dict[str, Any]) -> None:
    conn.execute("INSERT INTO incidents_w(id, world_id, name, base, scene, discovered_session_id, discovered_turn,"
                 " created_at) VALUES (?,?,?,?,?,?,?,?)",
                 (new_id("evt"), world_id, *(event[k] for k in EVENT_FIELDS[:3]), session_id, event["discovered_turn"], iso()))


def list_events(conn, world_id: str) -> list[dict[str, Any]]:
    rows = conn.execute("SELECT * FROM incidents_w WHERE world_id=? ORDER BY created_at, rowid", (world_id,))
    return [dict(r) for r in rows]


PLOT_FIELDS = ("name", "town", "started_shichen", "stage", "ended_shichen", "turned_shichen", "killed", "brew_until",
               "lit_shichen", "cast")   # 世界裡的事端（16t）


def insert_plot(conn, world_id: str, plot: dict[str, Any]) -> None:
    conn.execute("INSERT INTO plots_w(id, world_id, name, town, started_shichen, stage, ended_shichen, turned_shichen, killed,"
                 " brew_until, lit_shichen, cast_json, created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                 (new_id("plt"), world_id, *(plot[k] for k in PLOT_FIELDS[:9]), dumps(plot["cast"]), iso()))


def list_plots(conn, world_id: str) -> list[dict[str, Any]]:
    rows = conn.execute("SELECT * FROM plots_w WHERE world_id=? ORDER BY started_shichen, created_at, rowid", (world_id,))
    return [{**dict(r), "cast": loads(r["cast_json"], {})} for r in rows]


def update_plot(conn, plot: dict[str, Any]) -> None:
    conn.execute("UPDATE plots_w SET stage=?, ended_shichen=?, turned_shichen=?, killed=?, lit_shichen=? WHERE id=?",
                 (plot["stage"], plot["ended_shichen"], plot["turned_shichen"], plot["killed"], plot["lit_shichen"], plot["id"]))


def update_faction(conn, world_id: str, name: str, fields: dict) -> None:
    """打垮（第 7-3b1b1 批）：遷改所在地、滅在 traits 記覆滅。"""
    for k, v in fields.items():
        assert k in ("location", "traits"), k
        conn.execute(f"UPDATE factions SET {k}=? WHERE world_id=? AND name=?", (dumps(v) if k == "traits" else v, world_id, name))


def set_traits(conn, world_id: str, name: str, traits: dict) -> None:
    """換時代時國家重擲特徵（16h）。"""
    conn.execute("UPDATE factions SET traits=? WHERE world_id=? AND name=?", (dumps(traits), world_id, name))


def insert_bond(conn, world_id: str, session_id: str, bond: dict[str, Any]) -> None:
    """算出來的友人、仇家、恩人、同門不存（第 1-3 批，society.derived）。"""
    if bond["type"] in society.DERIVED:
        raise ValueError(f"算出來的關係不存：{bond['type']}")
    conn.execute(f"INSERT INTO bonds(id, world_id, {', '.join(_BOND_COLUMNS)}, created_at) VALUES ({', '.join('?' * 11)})",
                 (new_id("bnd"), world_id, session_id, bond["a_kind"], bond["a"], bond["b_kind"], bond["b"],
                  bond["type"], bond["clock_shichen"], bond["turn_no"], iso()))


def rebind(conn, world_id: str, lower: str, old: str, new: str) -> None:
    """改從屬（16l C1）：本山的上宗覆滅，被別的仙宗收編。"""
    conn.execute("UPDATE bonds SET b=? WHERE world_id=? AND a=? AND b=? AND type='從屬'", (new, world_id, lower, old))


def delete_bond(conn, world_id: str, a: str, b: str, types: tuple[str, ...]) -> None:
    """斷關係要指定種類（第 1-3 批；例如離開勢力只拿掉首領、成員，師徒加戀人的只斷其中一條）。"""
    conn.execute(f"DELETE FROM bonds WHERE world_id=? AND a=? AND b=? AND type IN ({','.join('?' * len(types))})",
                 (world_id, a, b, *types))


def list_bonds(conn, world_id: str, everyone: bool = False) -> list[dict[str, Any]]:
    """everyone：連主角的關係（家人、宗門，第 1-3b 批）一起；預設只有 NPC、勢力之間的。"""
    mine = "" if everyone else f" AND a_kind != '{society.PLAYER}' AND b_kind != '{society.PLAYER}'"
    rows = conn.execute(f"SELECT {', '.join(_BOND_COLUMNS)} FROM bonds WHERE world_id=?{mine} ORDER BY created_at, rowid",
                        (world_id,))
    return [dict(r) for r in rows]


def hand_over(conn, world_id: str, life: str, name: str) -> None:
    """退隱：這一生的關係改接到登錄成 NPC 的他（121-16 ①），不再是任何勢力的成員。"""
    conn.execute("DELETE FROM bonds WHERE world_id=? AND a_kind=? AND a=? AND type IN ('首領', '成員')", (world_id, society.PLAYER, life))
    for side in ("a", "b"):
        conn.execute(f"UPDATE bonds SET {side}_kind=?, {side}=? WHERE world_id=? AND {side}_kind=? AND {side}=?",
                     (society.NPC, name, world_id, society.PLAYER, life))


def hand_ledger(conn, world_id: str, life: str, name: str, alive: set[str]) -> None:
    """退隱：這一生的人情帳原封不動轉給隱居的他（第 6-6a-1 題），記成 NPC 之間的帳；對方已經死了的不轉。"""
    for r in conn.execute(f"SELECT id, a, b {_FAVOURS} AND session_id=?", (world_id, *favour.KINDS, life)).fetchall():
        a, b = (name if x == life else x for x in (r["a"], r["b"]))
        if {a, b} - {name} <= alive:
            conn.execute("UPDATE ledger SET session_id='', a=?, b=? WHERE id=?", (a, b, r["id"]))


# ── 長期記憶（第 17 步）───────────────────────────────────────────────────
_MEMORY_COLUMNS = ("id", "session_id", "subject_kind", "subject", "kind", "text", "source", "clock_shichen",
                   "turn_no", "thread_id", "actor", "attitude", "rumor_id")
_THREAD_COLUMNS = ("id", "session_id", "no", "kind", "subject_kind", "subject", "text", "status", "deadline_shichen",
                   "opened_shichen", "opened_turn", "touched_shichen", "closed_shichen", "result_note", "origin", "next_step", "task")
THREAD_UPDATABLE = {"status", "touched_shichen", "closed_shichen", "result_note"}


def insert_memory(conn, world_id: str, session_id: str, note: dict[str, Any]) -> None:
    conn.execute(
        f"INSERT INTO memories({', '.join(_MEMORY_COLUMNS)}, world_id, created_at) VALUES ({', '.join('?' * 15)})",
        (note.get("id") or new_id("mem"), session_id, note["subject_kind"], note["subject"], note["kind"],
         note["text"], note["source"], note["clock_shichen"], note["turn_no"], note.get("thread_id"),
         note.get("actor", ""), note.get("attitude", ""), note.get("rumor_id"), world_id, iso()),
    )


def list_memories(conn, world_id: str) -> list[dict[str, Any]]:
    rows = conn.execute(f"SELECT {', '.join(_MEMORY_COLUMNS)} FROM memories WHERE world_id=?"
                        " ORDER BY clock_shichen, created_at, rowid", (world_id,))
    return [dict(r) for r in rows]


# ── 傳聞（第 10c-3a 步）───────────────────────────────────────────────────
_RUMOR_COLUMNS = ("id", "kind", "subject", "target", "place", "detail", "lv", "subject_lv", "life", "size",
                  "clock_shichen")


def insert_rumor(conn, world_id: str, rumor: dict[str, Any]) -> None:
    row = {**rumor, "id": rumor.get("id") or new_id("rum")}
    conn.execute(f"INSERT INTO rumors({', '.join(_RUMOR_COLUMNS)}, world_id, created_at) VALUES ({', '.join('?' * 13)})",
                 (*[row[k] for k in _RUMOR_COLUMNS], world_id, iso()))


def list_rumors(conn, world_id: str) -> list[dict[str, Any]]:
    rows = conn.execute(f"SELECT {', '.join(_RUMOR_COLUMNS)} FROM rumors WHERE world_id=?"
                        " ORDER BY clock_shichen, created_at, rowid", (world_id,))
    return [dict(r) for r in rows]


# ── 事件、好感原因、知情、帳（第 120-5、120-7 題）：四張表同一組寫法 ──────────
_BOOKS = {
    "events": ("evt", ("id", "session_id", "kind", "actor", "target", "place", "detail", "secret", "era",
                       "clock_shichen", "turn_no")),
    "reasons": ("rsn", ("id", "session_id", "holder", "toward", "axis", "size", "value", "kind", "event_id",
                        "clock_shichen")),
    "knows": ("knw", ("id", "session_id", "event_id", "who", "knows_who", "knows_why", "via", "clock_shichen", "told")),
    "ledger": ("led", ("id", "session_id", "kind", "a", "b", "event_id", "settle", "deadline_shichen", "waiting",
                       "status", "era", "body", "clock_shichen")),
}
_BOOK_JSON = ("detail", "body")


def insert_book(conn, table: str, world_id: str, row: dict[str, Any]) -> dict[str, Any]:
    """寫一筆到 events／reasons／knows／ledger；回傳含 id 的那一筆。同一個 id 寫兩次只留第一筆。"""
    prefix, cols = _BOOKS[table]
    row = {**row, "id": row.get("id") or new_id(prefix)}
    conn.execute(f"INSERT OR IGNORE INTO {table}({', '.join(cols)}, world_id, created_at) VALUES ({', '.join('?' * (len(cols) + 2))})",
                 (*[dumps(row[k]) if k in _BOOK_JSON else row[k] for k in cols], world_id, iso()))
    return row


def mark_told(conn, ids: list[str]) -> None:
    """知道的人說出去了（每筆只說一次，第 1-5a 批）。"""
    conn.execute(f"UPDATE knows SET told=1 WHERE id IN ({', '.join('?' * len(ids))})", ids)


def drop_reasons(conn, ids: list[str]) -> None:
    """撤掉這幾筆原因（嫁禍被識破，第 7-3b1b2 批）。"""
    conn.execute(f"DELETE FROM reasons WHERE id IN ({', '.join('?' * len(ids))})", ids)


def settle(conn, ids: list[str]) -> None:
    """這幾筆帳了結了（標已了、不刪）。"""
    conn.execute(f"UPDATE ledger SET status=? WHERE id IN ({', '.join('?' * len(ids))})", (society.DONE, *ids))


def close_ledger(conn, world_id: str, dead: set[str], heirs: dict[str, str] | None = None) -> None:
    """NPC 之間的帳，一方死了（第 1-4c 批）：恩、受託、債還沒傳過的轉給接手的人（heirs：死者 → 接手的人，body 記前人；
    第 8-4-4 題甲）；其他的、傳過的、沒人接的標已了（不刪），恩受託債沉了記是誰（body 的「沉」，舊聞用）。"""
    names = sorted(dead)
    marks = ", ".join("?" * len(names))
    rows = conn.execute(f"SELECT id, kind, a, b, body FROM ledger WHERE world_id=? AND session_id='' AND status=? AND (a IN ({marks}) OR b IN ({marks}))",
                        (world_id, society.OPEN, *names, *names)).fetchall()
    for r in rows:
        body, d = loads(r["body"], {}), r["a"] if r["a"] in dead else r["b"]
        h = (heirs or {}).get(d, "")
        if r["kind"] in society.PASSED and h and not body.get("前人") and not ({r["a"], r["b"]} - {d}) & dead and h not in (r["a"], r["b"]):
            a, b = (h, r["b"]) if d == r["a"] else (r["a"], h)
            conn.execute("UPDATE ledger SET a=?, b=?, body=? WHERE id=?", (a, b, dumps({**body, "前人": d}), r["id"]))
        else:
            sunk = {**body, "沉": d} if r["kind"] in society.PASSED else body
            conn.execute("UPDATE ledger SET status=?, body=? WHERE id=?", (society.DONE, dumps(sunk), r["id"]))


def list_book(conn, table: str, world_id: str) -> list[dict[str, Any]]:
    cols = _BOOKS[table][1]
    rows = conn.execute(f"SELECT {', '.join(cols)} FROM {table} WHERE world_id=? ORDER BY clock_shichen, created_at, rowid",
                        (world_id,))
    return [{**dict(r), **{k: loads(r[k], {}) for k in _BOOK_JSON if k in cols}} for r in rows]


# ── 地點狀況（第 9b 步）───────────────────────────────────────────────────
_PLACE_STATE_COLUMNS = ("place", "name", "text", "source", "game", "started_shichen", "ends_shichen")


def insert_place_state(conn, world_id: str, state: dict[str, Any]) -> None:
    conn.execute(f"INSERT INTO place_states(id, {', '.join(_PLACE_STATE_COLUMNS)}, world_id, created_at)"
                 f" VALUES ({', '.join('?' * 10)})",
                 (new_id("pst"), *[state[k] for k in _PLACE_STATE_COLUMNS], world_id, iso()))


def cut_place_state(conn, world_id: str, place: str, name: str, started: int, ends: int) -> None:
    """天災提早結束（模型寫的天災的轉機，domain/newdisasters.py）。"""
    conn.execute("UPDATE place_states SET ends_shichen=? WHERE world_id=? AND place=? AND name=? AND started_shichen=?",
                 (ends, world_id, place, name, started))


def list_place_states(conn, world_id: str) -> list[dict[str, Any]]:
    rows = conn.execute(f"SELECT {', '.join(_PLACE_STATE_COLUMNS)} FROM place_states WHERE world_id=?"
                        " ORDER BY started_shichen, created_at, rowid", (world_id,))
    return [dict(r) for r in rows]


def insert_thread(conn, world_id: str, session_id: str, thread: dict[str, Any]) -> dict[str, Any]:
    """新線頭；編號在世界內遞增（給 AI 結線時引用）。回傳含 id、no 的完整線頭。"""
    no = thread.get("no") or (conn.execute("SELECT COALESCE(MAX(no), 0) + 1 FROM threads WHERE world_id=?",
                                           (world_id,)).fetchone()[0])
    row = {"id": thread.get("id") or new_id("thr"), "session_id": session_id, "no": no,
           **{k: thread.get(k) for k in _THREAD_COLUMNS if k not in ("id", "session_id", "no")}}
    row.update({k: row[k] or "" for k in ("result_note", "origin", "next_step")}, task=row["task"] or {})
    conn.execute(
        f"INSERT INTO threads({', '.join(_THREAD_COLUMNS)}, world_id, created_at) VALUES ({', '.join('?' * (len(_THREAD_COLUMNS) + 2))})",
        (*[dumps(row[k]) if k == "task" else row[k] for k in _THREAD_COLUMNS], world_id, iso()),
    )
    return row


def list_threads(conn, world_id: str) -> list[dict[str, Any]]:
    rows = conn.execute(f"SELECT {', '.join(_THREAD_COLUMNS)} FROM threads WHERE world_id=? ORDER BY no", (world_id,))
    return [{**dict(r), "task": loads(r["task"], {})} for r in rows]


def update_thread(conn, thread_id: str, fields: dict[str, Any]) -> None:
    """只允許改狀態、接觸時間、結束時間與原因；內容、綁定對象、期限一旦開線就不變。"""
    bad = set(fields) - THREAD_UPDATABLE
    if bad:
        raise ValueError(f"線頭欄位不可修改：{sorted(bad)}")
    sets = ", ".join(f"{k}=?" for k in fields)
    conn.execute(f"UPDATE threads SET {sets} WHERE id=?", (*fields.values(), thread_id))


def insert_proposal_log(conn, session_id: str, turn_no: int, kind: str, name: str,
                        accepted: bool, reason: str) -> None:
    conn.execute(
        "INSERT INTO proposal_log(id, session_id, turn_no, kind, name, accepted, reason, created_at)"
        " VALUES (?,?,?,?,?,?,?,?)",
        (new_id("prp"), session_id, turn_no, kind, name[:40], 1 if accepted else 0, reason, iso()),
    )


def list_proposal_log(conn, session_id: str | None = None) -> list[dict[str, Any]]:
    if session_id:
        rows = conn.execute("SELECT * FROM proposal_log WHERE session_id=? ORDER BY created_at", (session_id,))
    else:
        rows = conn.execute("SELECT * FROM proposal_log ORDER BY created_at")
    return [{**dict(r), "accepted": bool(r["accepted"])} for r in rows]


# ── 讀懂影子模式（3-2）────────────────────────────────────────────────────
def insert_read(conn, session_id: str, turn_no: int, text: str, sheet: dict, keyword: dict) -> None:
    """sheet：驗證後的行動單（含「確認」）；keyword：照走的做什麼、判什麼、對誰、去哪（3-3a；3-2 影子模式時是關鍵字判的，欄名沿用）。"""
    conn.execute("INSERT INTO reads(id, session_id, turn_no, text, sheet, keyword, created_at) VALUES (?,?,?,?,?,?,?)",
                 (new_id("rd"), session_id, turn_no, text, dumps(sheet), dumps(keyword), iso()))


def asked_read(conn, session_id: str, turn_no: int, text: str) -> dict | None:
    """3-3b：這回合同一句問過的行動單（keyword 記著「問」哪一欄）；最近一筆不是問的就沒有。"""
    row = conn.execute("SELECT sheet, keyword FROM reads WHERE session_id=? AND turn_no=? AND text=? ORDER BY rowid DESC LIMIT 1",
                       (session_id, turn_no, text)).fetchone()
    return loads(row["sheet"], {}) if row and "問" in loads(row["keyword"], {}) else None


def list_reads(conn) -> list[dict[str, Any]]:
    return [{**dict(r), "sheet": loads(r["sheet"], {}), "keyword": loads(r["keyword"], {})}
            for r in conn.execute("SELECT * FROM reads ORDER BY created_at, rowid")]


# ── AI 呼叫遙測 ─────────────────────────────────────────────────────────────
def insert_ai_call(conn, call: dict[str, Any]) -> None:
    conn.execute(
        "INSERT INTO ai_calls(id, session_id, turn_no, kind, model, ok, attempts, latency_ms, error_code,"
        " error_message, ignored_keys, outcome, tone_check, narrative_len, warnings, created_at)"
        " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (call["id"], call["session_id"], call["turn_no"], call["kind"], call["model"], 1 if call["ok"] else 0,
         call["attempts"], call["latency_ms"], call.get("error_code", ""), call.get("error_message", "")[:2000],
         dumps(call.get("ignored_keys", [])), call.get("outcome", ""), call.get("tone_check", ""),
         call.get("narrative_len", 0), "\n".join(call.get("warnings", []))[:1000], iso()),
    )


def list_ai_calls(conn, session_id: str | None = None) -> list[dict[str, Any]]:
    if session_id:
        rows = conn.execute("SELECT * FROM ai_calls WHERE session_id=? ORDER BY created_at", (session_id,))
    else:
        rows = conn.execute("SELECT * FROM ai_calls ORDER BY created_at")
    return [{**dict(r), "ok": bool(r["ok"]), "ignored_keys": loads(r["ignored_keys"], []),
             "warnings": [w for w in (r["warnings"] or "").split("\n") if w]} for r in rows]
