"""啟動方式：python -m tiandao [serve|init-db|ai-check|ai-report] [--mock-ai] [--port N] [--db PATH] [--turns N]"""
from __future__ import annotations

import argparse
import logging
from pathlib import Path

from . import __version__
from .config import Settings
from .store.db import migrate
from .web.app import App
from .web.server import make_server


def main(argv: list[str] | None = None) -> None:
    p = argparse.ArgumentParser(prog="tiandao")
    p.add_argument("command", nargs="?", default="serve", choices=["serve", "init-db", "ai-check", "ai-report"])
    p.add_argument("--host")
    p.add_argument("--port", type=int)
    p.add_argument("--db", type=Path)
    p.add_argument("--mock-ai", action="store_true", help="使用確定性的假說書人（不連 Ollama）")
    p.add_argument("--model", help="說書人模型名稱")
    p.add_argument("--debug", action="store_true")
    p.add_argument("--turns", type=int, default=30, help="ai-check 要玩幾回合")
    p.add_argument("--out", type=Path, help="ai-check 報告輸出資料夾（預設 progress/）")
    p.add_argument("--games", type=int, default=1, help="ai-check 玩幾局（每局 --turns 回合）")
    p.add_argument("--seed", type=int, help="ai-check 固定種子：第 g 局用 seed+g，改前改後比同一組世界")
    p.add_argument("--era", help="ai-check 起始時代（古代、現代、未來；預設古代）")
    args = p.parse_args(argv)

    settings = Settings.from_env(
        host=args.host, port=args.port, db_path=args.db, narrator_model=args.model,
        ai_backend="mock" if args.mock_ai else None, debug=True if args.debug else None,
    )
    logging.basicConfig(level=logging.DEBUG if settings.debug else logging.INFO,
                        format="%(asctime)s %(levelname)s %(name)s: %(message)s")

    if args.command == "init-db":
        print(f"schema version {migrate(settings.db_path)} → {settings.db_path}")
        return

    if args.command == "ai-report":
        from .tools import ai_check
        result = ai_check.report_existing(settings, args.out)
        m = result.metrics
        print(f"結論：{'通過' if result.passed else '需要檢查'}　AI 呼叫 {m['calls']} 次　首次即合格 {m['firstTryRate']:.0%}　"
              f"語氣相反 {m['mismatches']}/{m['rolledTurns']}")
        print(f"報告：{result.report_path}")
        return

    if args.command == "ai-check":
        from .tools import ai_check
        print(f"以 {settings.narrator_model if settings.ai_backend == 'ollama' else 'mock'} 自動進行 {args.turns} 回合……")
        result = ai_check.run(settings, args.turns, args.out, games=args.games, seed=args.seed, era=args.era)
        m = result.metrics
        print(f"\n結論：{'通過' if result.passed else '需要檢查'}　首次即合格 {m['firstTryRate']:.0%}　"
              f"最終失敗 {m['failed']} 次　語氣相反 {m['mismatches']}/{m['rolledTurns']}")
        print(f"報告：{result.report_path}")
        raise SystemExit(0 if result.passed else 1)

    app = App(settings)
    rules = app.rulebook.status()
    print(f"天道棋盤 v{__version__}  http://{settings.host}:{settings.port}")
    print(f"說書人：{app.narrator.name}　資料庫：{settings.db_path}")
    if rules["missingDirs"] or rules["emptyDirs"]:
        print(f"注意：規則檔有 {len(rules['missingDirs'])} 個分類缺資料夾、{len(rules['emptyDirs'])} 個分類沒有內容。")
    server = make_server(app, settings.host, settings.port)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
