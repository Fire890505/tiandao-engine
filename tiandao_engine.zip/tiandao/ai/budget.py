"""超額三關（127-8、第 2-5 批）：送出前由 Python 修剪請求，整條丟、不切半句，丟了什麼都記下來。

第 1 關每格上限（127-3）；第 2 關總量估 token，超過照固定順序再砍；第 3 關固定層、這一世層只用測試檢查（FIXED、LIFE）。
【結果】、主角的行動、主角狀態、規則不砍（第 2 題）；【領域】是守則，也不砍。
"""
import dataclasses
from collections import defaultdict

from .contract import NarrationRequest
from .narrators import PROMPT_BUDGET as BUDGET
from .prompts import build_messages

RATIO = 0.677                  # 127-9 真模型量的 token ÷ 字數
FIXED, LIFE = 4800, 1300       # 第 3 關：固定層、這一世層上限（字）
THREAD, MAIN = 100, 200        # 主線、主事
HEAD = 20                      # 丟掉的每條記前幾個字（報告逐條看）
MOVED ="沒跟來的人都不在這裡"    # 前情提要最後的「已離開某處」（16v 第 90 題）是這回合的事實，不算一條、不砍
# 第 1 關：格名、欄位、分隔（None＝清單）、丟最前面（最舊的）、上限
# 眼前的人 400：說話（7-1d）和「這回合他會講到」接在最後一段，250 時 90 回合砍 26 次（2026-11-20 實玩）
SLOTS = (("所在", "place_info", "　", False, 400), ("眼前的人", "focus", "；", False, 400),
         ("旁支", "side", None, False, 240), ("前情提要", "recent", None, True, 300))
# 第 2 關：砍的順序（127-8）
ORDER = (("前情提要", "recent", None, True), ("已知地點", "known_locations", None, False),
         ("聯絡簿", "contact", "\n", False), ("旁支", "side", None, False), ("眼前的人", "focus", "；", False))


def tokens(req: NarrationRequest) -> float:
    return sum(len(m["content"]) for m in build_messages(req)) * RATIO


def _size(v) -> int:
    return len(v) if isinstance(v, str) else sum(map(len, v))


def _pop(req, field, sep, old):
    """丟一條（至少留一條），回傳（新請求, 丟掉的那條）；丟不了回 None。"""
    v = getattr(req, field)
    parts = v.split(sep) if sep else list(v)
    if len(parts) < 2:
        return None
    gone = parts.pop(0 if old else -1)
    return dataclasses.replace(req, **{field: sep.join(parts) if sep else parts}), gone


def fit(req: NarrationRequest) -> tuple[NarrationRequest, list[str]]:
    """回傳（修剪後的請求, 丟了什麼）。例：「dropped:所在 1 條（大周國往事：大周開國……）」，每條記前 20 字。"""
    dropped = defaultdict(list)
    moved = req.recent[-1:] if req.recent and req.recent[-1].endswith(MOVED) else []
    req = dataclasses.replace(req, recent=req.recent[:len(req.recent) - len(moved)])

    def cut(req, slot, field, sep, old, over):
        while over(req) and (new := _pop(req, field, sep, old)):
            req = new[0]
            dropped[slot].append(new[1].strip()[:HEAD])
        return req

    if req.route and req.plot and len(req.route) + len(req.plot) > THREAD:   # 主線一句：此地的事讓路
        dropped["主線"].append(req.plot[:HEAD])
        req = dataclasses.replace(req, plot="")
    req = cut(req, "主事", "arrival", "；", False, lambda r: len(r.incident) + len(r.arrival) > MAIN)
    for slot, field, sep, old, cap in SLOTS:
        req = cut(req, slot, field, sep, old, lambda r: _size(getattr(r, field)) > cap)
    for slot, field, sep, old in ORDER:
        req = cut(req, slot, field, sep, old, lambda r: tokens(dataclasses.replace(r, recent=r.recent + moved)) > BUDGET)
    return dataclasses.replace(req, recent=req.recent + moved), [
        f"dropped:{k} {len(v)} 條（{'／'.join(v)}）" for k, v in dropped.items()]
