"""Narrator 實作：Ollama（正式）與 Mock（測試／離線開發）。

兩者使用同一個 parse_output 合約，所以 mock 測試通過的流程，
換成真模型時只會在「模型是否遵守合約」這一點上有差異，不會有資料形狀落差
（對應舊專案稽核 B-12、R-04：mock 與真實資料形狀不一致）。
"""
from __future__ import annotations

import dataclasses
import json
import logging
import re
import urllib.error
import urllib.request

from ..errors import UpstreamError
from .contract import (
    CHOICE_NATURES, CLASSIFY_NATURES, DEFAULT_KINDS, DIFFICULTIES, PROPOSAL_ENUMS, PROPOSAL_FIELDS, PROPOSAL_MAX_PER_TURN,
    PROPOSAL_REQUIRED, READ_FREE, READ_MULTI, READ_ORDER, Classification,
    VET, ContractError, FORGE_KEYS, NO, STORY_KEYS, YES, Forged, NarrationRequest, NarrationResult, Reading, Written, parse_classification, parse_forged,
    parse_output, parse_reading,
    parse_vet, parse_weave, parse_written, sentences, weave_ids,
)
from . import zh
from .prompts import (
    build_classify_messages, build_forge_messages, build_judge_messages, build_messages, build_persona_messages, build_bits_messages,
    build_read_messages, build_spot_messages, build_story_messages, build_vet_messages, build_weave_messages, build_whole_messages,
)

log = logging.getLogger(__name__)

PROMPT_CHOICES = 3          # 要求模型給的選項數（合約仍接受 MIN_CHOICES～MAX_CHOICES）
REJECTED_RAW_CHARS = 600    # 遙測中保留的不合格原始輸出長度
# 上下文長度（WHITEPAPER 12.3）：定死 8192，不再往上調。Ollama 預設 4096，超過會默默從開頭截掉規則。
# 送出前由 ai/budget.py 照額度修剪（第 2-5 批）；模型事後回報仍超過預算就記警告（ai-check 報告列出），不加大上下文。
NUM_CTX = 8192
PROMPT_BUDGET = 6000        # 留約 2000 給模型的回覆（實測最多約 800）
KEEP_ALIVE = "30m"          # 模型閒置多久才卸載（Ollama 預設 5 分鐘）


def budget_warnings(result) -> list[str]:
    """提示詞超過預算時的遙測警告。"""
    if result.prompt_tokens <= PROMPT_BUDGET:
        return []
    return [f"prompt_over_budget:{result.prompt_tokens}/{PROMPT_BUDGET} token"]


def output_schema(fallen: bool, kinds: tuple[str, ...] = DEFAULT_KINDS, voice: bool = False) -> dict:
    """交給 Ollama format 欄位的 JSON schema。殞落時 choices 必須是空陣列。
    kinds：這回合送出的提案種類；沒送的種類不在 schema 裡，模型就不會寫。voice：這回合天道開口，多一個 heaven 欄位。"""
    count = 0 if fallen else PROMPT_CHOICES
    kinds = [k for k in PROPOSAL_FIELDS if k in kinds]

    def items(kind: str, fields: tuple[str, ...], max_items: int) -> dict:
        enums = PROPOSAL_ENUMS.get(kind, {})
        props = {f: ({"type": "string", "enum": list(enums[f])} if f in enums else {"type": "string"}) for f in fields}
        return {"type": "array", "maxItems": max_items, "items": {
            "type": "object", "properties": props, "required": list(PROPOSAL_REQUIRED[kind]),
            "additionalProperties": False}}

    choice = {"type": "object", "properties": {
        "text": {"type": "string"},
        "nature": {"type": "string", "enum": list(CHOICE_NATURES)},
        "target": {"type": "string"},
    }, "required": ["text", "nature"], "additionalProperties": False}   # 3-5 第 5 題：不再標難度，domain/stake.py 估要的有多大
    schema = {
        "type": "object",
        "properties": {
            "narrative": {"type": "string"},
            "situation": {"type": "string"},
            "choices": {"type": "array", "items": choice, "minItems": count, "maxItems": count},
            "proposals": {"type": "object", "properties": {
                kind: items(kind, PROPOSAL_FIELDS[kind], PROPOSAL_MAX_PER_TURN[kind]) for kind in kinds
            }, "required": kinds, "additionalProperties": False},
        },
        "required": ["narrative", "situation", "choices", "proposals"],
    }
    if voice:
        schema["properties"]["heaven"] = {"type": "string"}
        schema["required"].append("heaven")
    return schema


WRITTEN_SCHEMA = {"type": "object", "properties": {"text": {"type": "string"}}, "required": ["text"],
                  "additionalProperties": False}


SPOT, NOT_SPOT = "甲", "都不是"
SPOT_SCHEMA = {"type": "object", "properties": {"text": {"type": "string", "enum": [SPOT, NOT_SPOT]}}, "required": ["text"],
               "additionalProperties": False}


VET_SCHEMA = {"type": "object", "properties": {"有沒有問題": {"type": "string", "enum": list(VET)}, "哪一句": {"type": "string"}},
              "required": ["有沒有問題", "哪一句"], "additionalProperties": False}
VET_PASS = {"有沒有問題": "沒有", "哪一句": ""}


def weave_schema(parts: list[str]) -> dict:
    return {"type": "object", "properties": {"pick": {"type": "string", "enum": weave_ids(parts)}, "text": {"type": "string"}},
            "required": ["pick", "text"], "additionalProperties": False}


def read_schema(lists: dict[str, tuple]) -> dict:
    """3-2 第 2 題：每欄只能從清單挑，只有一個選項的欄不放（Python 直接填）；照原文抄的欄是字串。"""
    one = lambda v: {"type": "string", "enum": list(v)}   # noqa: E731
    props = {k: {"type": "array", "items": one(lists[k])} if k == READ_MULTI else one(lists[k])
             for k in READ_ORDER if len(lists.get(k, ())) > 1}
    props |= {k: {"type": "string"} for k in READ_FREE}
    return {"type": "object", "properties": props, "required": list(props), "additionalProperties": False}


def forge_schema(n: int, keys: tuple[str, ...] = FORGE_KEYS, enum: tuple[str, ...] = ()) -> dict:
    """第 128 系列：件數在生成時就固定。enum：每欄只能是這幾個（是非題）。"""
    one = {"type": "object", "properties": {k: {"type": "string", **({"enum": list(enum)} if enum else {})} for k in keys},
           "required": list(keys), "additionalProperties": False}
    return {"type": "object", "properties": {"items": {"type": "array", "items": one, "minItems": n, "maxItems": n}},
            "required": ["items"], "additionalProperties": False}


CLASSIFY_SCHEMA = {
    "type": "object",
    "properties": {"nature": {"type": "string", "enum": list(CLASSIFY_NATURES)},
                   "difficulty": {"type": "string", "enum": list(DIFFICULTIES)}},
    "required": ["nature", "difficulty"], "additionalProperties": False,
}


class OllamaNarrator:
    def __init__(self, base_url: str, model: str, timeout: float = 300.0, attempts: int = 2):
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.timeout = timeout
        self.attempts = attempts
        self.name = f"ollama:{model}"
        self.sizes: list[tuple[int, int]] = []   # 每次敘事送出的（字數, token），ai-check 量 127-9 基準用

    def narrate(self, request: NarrationRequest) -> NarrationResult:
        voice = bool(request.heaven)
        messages = build_messages(request)
        self._prime(messages[0]["content"])
        result = self._call(messages, output_schema(request.fallen, request.proposal_kinds, voice),
                            lambda raw: parse_output(raw, model=self.model, fallen=request.fallen, voice=voice))
        self.sizes.append((sum(len(m["content"]) for m in messages), result.prompt_tokens))
        if result.ignored_keys:
            log.info("已忽略 AI 輸出中的非合約欄位：%s", result.ignored_keys)
        return result

    def persona(self, card_lines: str) -> Written:
        """把條列的天道人格卡潤色成一段人設（第 18-1 步）。審核由 domain/heaven.check_polish 做。"""
        return self._call(build_persona_messages(card_lines), WRITTEN_SCHEMA,
                          lambda raw: parse_written(raw, model=self.model))

    def classify(self, player_input: str, context: str) -> Classification:
        """判斷不出行動類型時才呼叫（第 4 步混合分類）：只從固定清單選性質與難易，溫度調低求穩定。"""
        return self._call(build_classify_messages(player_input, context), CLASSIFY_SCHEMA,
                          lambda raw: parse_classification(raw, model=self.model), temperature=0.2)

    def read(self, player_input: str, lists: dict[str, tuple], facts: list[str]) -> Reading:
        """3-2 讀懂：把玩家這句填成行動單。lists：各欄清單（Python 當回合列）；facts：Python 記下的情境，不帶旁白。"""
        return self._call(build_read_messages(player_input, lists, facts), read_schema(lists),
                          lambda raw: parse_reading(raw, lists, model=self.model), temperature=0.2)

    def spot(self, player_input: str, detail: str) -> Written:
        """第 53-2 題：玩家這句是不是在查這個破綻。text 是選項。"""
        return self._call(build_spot_messages(player_input, detail), SPOT_SCHEMA, lambda raw: parse_written(raw, model=self.model),
                          temperature=0.2)

    def vet(self, text: str) -> Reading:
        """3-7b：玩家寫的長期文字有沒有夾指令、把能力寫成既定事實。sheet＝有沒有問題（沒有／有）、哪一句。"""
        return self._call(build_vet_messages(text), VET_SCHEMA, lambda raw: parse_vet(raw, model=self.model), temperature=0.2)

    def weave(self, narrative: str, detail: str) -> Written:
        """第 53-3 題：把破綻帶進敘事，只改一句。text 是改好的整段敘事。"""
        parts = sentences(narrative)
        return self._call(build_weave_messages(parts, detail), weave_schema(parts),
                          lambda raw: parse_weave(raw, parts, model=self.model), temperature=0.4)

    def forge(self, slots: list[dict], era_now: str) -> Forged:
        """第 128 系列：建世界時一次替整批物品寫名字、外觀、來歷。審核由 domain/newitems.review 做。"""
        return self._call(build_forge_messages(slots, era_now), forge_schema(len(slots)),
                          lambda raw: parse_forged(raw, len(slots), model=self.model))

    def story(self, kind: str, slot: dict) -> Forged:
        """第 128 系列乙（句型組守則）：傳說（legend）、規則怪談（tale）一篇的故事段。審核由 domain/newlegends、newtales.review 做。"""
        return self._one(build_story_messages(kind, slot), STORY_KEYS[kind])

    def bits(self, kind: str, slot: dict, asks: list[dict]) -> Forged:
        """接在 Python 拼好的整句後面的小段，一欄一題；回傳的欄照 asks 的 key。"""
        got = self._one(build_bits_messages(kind, slot, asks), tuple(f"b{i}" for i in range(1, len(asks) + 1)))
        return dataclasses.replace(got, items=[{x["key"]: got.items[0][f"b{i}"] for i, x in enumerate(asks, 1)}])

    def whole(self, brief: dict, fix: list[str] = (), last: str = "") -> Forged:
        """大模型整篇寫（domain/whole.py）：回傳 {body: 全文}。"""
        return self._one(build_whole_messages(brief, fix, last), ("body",))

    def judge(self, questions: list[dict]) -> Forged:
        """是非題：回傳 {q1: 是／否, …}。"""
        return self._one(build_judge_messages(questions), tuple(f"q{i}" for i in range(1, len(questions) + 1)), (YES, NO),
                         temperature=0.2)

    def _one(self, messages: list[dict], keys: tuple[str, ...], enum: tuple[str, ...] = (), temperature: float = 0.8) -> Forged:
        return self._call(messages, forge_schema(1, keys, enum), lambda raw: parse_forged(raw, 1, model=self.model, keys=keys),
                          temperature=temperature)

    def _call(self, messages: list[dict], schema: dict, parse, temperature: float = 0.8):
        """呼叫模型並驗證合約；不合格重試，連續失敗丟 UpstreamError（附被拒絕的原始輸出供遙測）。"""
        last_error = ""
        rejected: list[str] = []
        for attempt in range(1, self.attempts + 1):
            raw, prompt_tokens = self._chat(messages, schema, temperature)
            try:
                result = parse(raw)
            except ContractError as exc:
                last_error = str(exc)
                rejected.append(f"第 {attempt} 次：{exc}｜原始輸出：{raw[:REJECTED_RAW_CHARS]}")
                log.warning("AI 輸出不符合合約（第 %d 次）：%s", attempt, exc)
                continue
            return dataclasses.replace(result, attempts=attempt, rejected=rejected, prompt_tokens=prompt_tokens)
        raise UpstreamError(f"AI 連續 {self.attempts} 次輸出格式錯誤：{last_error}", code="ai_contract",
                            details={"attempts": self.attempts, "rejected": rejected})

    def _prime(self, system: str) -> None:
        """第 14 題：先單獨送系統提示詞（照 chatml 原樣），讓 llama.cpp 在它的結尾存快取存檔點。
        qwen3.5 這類混合架構只能從存檔點接快取；有了這個點，每回合只重讀 user 訊息（實測 33 秒 → 12 秒）。
        系統提示詞沒變時這一步約 0.1 秒；失敗或模板不同只是快取接不上，不影響輸出。"""
        body = json.dumps({
            "model": self.model, "prompt": f"<|im_start|>system\n{system}<|im_end|>\n<|im_start|>user\n",
            "raw": True, "stream": False, "keep_alive": KEEP_ALIVE,
            "options": {"num_ctx": NUM_CTX, "num_predict": 1},
        }).encode("utf-8")
        req = urllib.request.Request(f"{self.base_url}/api/generate", data=body, method="POST",
                                     headers={"Content-Type": "application/json"})
        try:
            urllib.request.urlopen(req, timeout=self.timeout).close()
        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            log.info("快取存檔點沒送成：%s", exc)

    def _chat(self, messages: list[dict], schema: dict, temperature: float) -> tuple[str, int]:
        """回傳（模型輸出, 提示詞 token 數）。"""
        body = json.dumps({
            "model": self.model, "messages": messages, "stream": False,
            # 結構化輸出：Ollama 依 schema 限制生成，choices 的數量在生成時就被固定，不只靠提示詞。
            "format": schema, "options": {"temperature": temperature, "num_ctx": NUM_CTX},
            # 關閉思考模式：qwen3 系列預設會先長篇思考，CPU 上單回合超過 400 秒。
            # 不支援思考的模型（如 Yi）收到 false 會直接忽略。
            "think": False,
            "keep_alive": KEEP_ALIVE,   # 16m 第 1 題：留在顯卡上，下一回合不用重新載入（冷載入約 40 秒）
        }).encode("utf-8")
        req = urllib.request.Request(
            f"{self.base_url}/api/chat", data=body, method="POST",
            headers={"Content-Type": "application/json"},
        )
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                payload = json.loads(resp.read().decode("utf-8"))
        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            raise UpstreamError(f"無法連線到 Ollama（{self.base_url}）：{exc}") from exc
        content = (payload.get("message") or {}).get("content")
        if not isinstance(content, str):
            raise UpstreamError("Ollama 回應缺少 message.content", code="ai_contract")
        return zh.to_trad(content), int(payload.get("prompt_eval_count") or 0)   # 16m 第 5 題：夾雜的簡體字換回繁體


class MockNarrator:
    """確定性的假說書人。輸出仍經過 parse_output，與真模型走同一條驗證路徑。"""

    name = "mock"

    def __init__(self) -> None:
        self.fail_next = 0   # 測試用：接下來幾次呼叫要模擬 AI 失敗
        self.sheet: dict = {}   # 測試用：讀懂回傳的行動單；空的＝遊戲改走關鍵字鏈（3-3 第 10 題）
        self.classified: list[str] = []   # 測試用：記錄哪些輸入被送去 AI 分類
        self.heaven_line = MOCK_HEAVEN    # 測試用：天道開口時寫的台詞（可改成不合格的來測驗證）
        self.persona_text = MOCK_PERSONA  # 測試用：潤色人設時寫的文字
        self.personas: list[str] = []     # 測試用：記錄潤色被呼叫幾次
        self.last_request: NarrationRequest | None = None   # 測試用：最近一次敘事請求
        self.vetted = dict(VET_PASS)      # 測試用：檢查長期文字的答案（3-7b），預設放行
        self.vets: list[str] = []         # 測試用：送去檢查的文字
        self.forges: list[list[dict]] = []   # 測試用：建世界時送去寫物品的條件（第 128 系列）
        self.forged: list[dict] | None = None   # 測試用：寫物品的輸出（None＝照條件產生合格的）
        self.lore_asks: list[tuple[str, str]] = []   # 測試用：傳說、怪談叫了哪幾段（kind, story／bits／judge）
        self.lore_out: dict[str, dict] = {}   # 測試用：某一段要換的輸出（給了就照它；沒給＝產生合格的）
        self.lore_names: dict[str, list[str]] = {"legend": [], "tale": [], "plot": []}   # 假傳說、假怪談、假事端各自用過的名字

    def narrate(self, request: NarrationRequest) -> NarrationResult:
        self.last_request = request
        if self.fail_next > 0:
            self.fail_next -= 1
            raise UpstreamError("模擬的 AI 失敗")
        c = request.character
        proposed = {"locations": [], "npcs": [], "relations": [], "memories": [], "thread_opens": [],
                    "thread_closes": [], "factions": [], "bonds": [], "self_appearance": [], "self_reputation": [],
                    "place_text": [], "history_text": []}
        elder_here = MOCK_NPC["name"] in request.contact
        if request.kind == "opening":
            text = (f"{request.clock_label}，{c['name']}站在{c['location']}。山風帶著草木氣息，遠處隱約傳來鐘聲。"
                    f"路旁一位{MOCK_NPC['name']}正打量著你。")
            proposed["npcs"].append(MOCK_NPC)
        else:
            j = request.judgment
            verdict = f"結果是「{j['outcome']}」。" if j.get("rolled") else ""
            facts = "；".join(request.facts) if request.facts else "一切如常"
            text = f"你決定{request.player_input}。{verdict}（{facts}）"
            if j.get("action_type") == "探索":
                # 每次探索都提同一個地點：第一次採用，之後由 Python 以「已知」拒絕
                text += f" 山道盡頭隱約可見{MOCK_LOCATION['name']}。"
                proposed["locations"].append(MOCK_LOCATION)
            if j.get("target_npc") == MOCK_NPC["name"] and j.get("action_type") == "社交" and j.get("rolled"):
                # 判定以外的互動：老人欣賞你肯開口請教（Python 換算並限制幅度）
                text += (f" {MOCK_NPC['name']}捋了捋鬍鬚，似乎對你多了幾分興趣，"
                         f"低聲說山後有座古墓，三十年前就封了。")
                proposed["relations"].append({"name": MOCK_NPC["name"], "change": "小幅好轉", "reason": "虛心請教"})
                proposed["memories"].append(MOCK_MEMORY)
                proposed["thread_opens"].append(MOCK_THREAD)
            if "了結" in request.player_input and (opened := re.search(r"〔線(\d+)〕", request.contact)):
                # 測試用：玩家說「了結」時，把聯絡簿裡第一條線頭結掉
                proposed["thread_closes"].append({"thread": f"線{opened.group(1)}", "result": "解開"})
            if "宗門" in request.player_input and elder_here:
                # 測試用：打聽宗門時，提一個勢力與「守碑老人是青雲宗的首領」的羈絆
                text += f" 有人說附近有個{MOCK_FACTION['name']}，{MOCK_NPC['name']}正是{MOCK_FACTION['name']}的首領。"
                proposed["factions"].append(MOCK_FACTION)
                proposed["bonds"].append(MOCK_BOND)
        if request.appearance_task:
            proposed["self_appearance"].append({"text": MOCK_APPEARANCE})
            if request.fallen:
                text += " 你的意識漸漸沉入黑暗。"
        if request.reputation_task:
            proposed["self_reputation"].append({"text": MOCK_REPUTATION})
        if request.place_task:
            proposed["place_text"].append({"text": MOCK_PLACE_TEXT})
        if request.history_task:
            proposed["history_text"].append({"text": MOCK_HISTORY})
        choices = [] if request.fallen else _mock_choices(c)
        if elder_here and choices and choices[2]["nature"] == "社交":
            choices[2] = {"text": f"向{MOCK_NPC['name']}請教", "nature": "社交", "difficulty": "普通",
                          "target": MOCK_NPC["name"]}
        # 與真模型一樣：這回合沒送的提案種類不會出現（真模型是 schema 擋掉）
        proposed = {k: v for k, v in proposed.items() if k in request.proposal_kinds}
        out = {"narrative": text, "choices": choices, "proposals": proposed}
        if request.heaven:
            out["heaven"] = self.heaven_line
        return parse_output(json.dumps(out, ensure_ascii=False), model="mock", fallen=request.fallen,
                            voice=bool(request.heaven))

    def persona(self, card_lines: str) -> Written:
        self.personas.append(card_lines)
        return parse_written(json.dumps({"text": self.persona_text}, ensure_ascii=False), model="mock")

    def read(self, player_input: str, lists: dict[str, tuple], facts: list[str]) -> Reading:
        """假讀懂：回傳測試給的行動單，沒給就是空的（句集算「問」，遊戲走關鍵字鏈）。"""
        return Reading(sheet=dict(self.sheet), model="mock")

    def vet(self, text: str) -> Reading:
        self.vets.append(text)
        if self.fail_next > 0:
            self.fail_next -= 1
            raise UpstreamError("模擬的 AI 失敗")
        return Reading(sheet=dict(self.vetted), model="mock")

    def spot(self, player_input: str, detail: str) -> Written:
        """確定性的假判斷：話裡有兩個字和破綻一樣就算。"""
        hit = any(player_input[i:i + 2] in detail for i in range(len(player_input) - 1))
        return Written(text=SPOT if hit else NOT_SPOT, model="mock")

    def weave(self, narrative: str, detail: str) -> Written:
        """確定性的假改寫：接在最後一句，和真模型走同一條驗證路徑。"""
        parts = sentences(narrative)
        return parse_weave(json.dumps({"pick": weave_ids(parts)[-1], "text": f"{parts[-1][:-1]}，{detail[:60]}。"},
                                      ensure_ascii=False), parts, model="mock")

    def forge(self, slots: list[dict], era_now: str) -> Forged:
        """確定性的假物品：名字＝材料＋物產第一個字＋兩個編號字＋一個結尾字（forms.txt），外觀用編號字開頭、照樣用上材料，來歷用上物產。
        每件的兩個編號字都跟別件不同：名字不會只差一個字（撞名），外觀開頭兩字不會一樣（重複），不會被退回重叫。
        forged：測試要換的輸出（給了就照它）。"""
        n, c = sum(map(len, self.forges)), "甲乙丙丁戊己庚辛壬癸子丑寅卯辰巳午未申酉戌亥"
        tag = [c[(n + i) % len(c)] + c[(n + i + 7) % len(c)] for i in range(len(slots))]
        self.forges.append(slots)
        if self.fail_next > 0:
            self.fail_next -= 1
            raise UpstreamError("模擬的 AI 失敗")
        got = self.forged if self.forged is not None else [
            {"name": s["part"] + s["made"][0] + tag[i] + s["ends"][i % len(s["ends"])],
             "look": f"{tag[i]}二字刻在上頭，以{s['part']}製成，拿在手裡微微發涼", "origin": f"出自{s['made']}一帶，當地人代代相傳"}
            for i, s in enumerate(slots)]
        return parse_forged(json.dumps({"items": got[:len(slots)]}, ensure_ascii=False), len(slots), model="mock")

    def story(self, kind: str, slot: dict) -> Forged:
        """確定性的假故事段：名字四個字每篇都換（每種 12 篇內不會只差一個字而撞名），其他欄寫固定的通順句子。"""
        def one():
            n, c = len(self.lore_names[kind]), "甲乙丙丁戊己庚辛壬癸子丑"
            name = "".join(c[(n + k) % 12] for k in (0, 3, 6, 9))
            self.lore_names[kind].append(name)
            base = {"name": name, "mood": f"夜霧、{slot['images'][-1]}、看不清的身影", "found1": "它原是{此地}一個冤死的人",
                    "found2": "在{鄰地}找到了第一個說起它的人", "end": "事情了結了，再也沒人碰到它", "why": "那東西一直在找替身"}
            if kind == "tale":
                return {**base, "rumor": f"{name}一帶入夜後沒人敢出門"}
            return {**base, "line": f"{name}的影子朝你走來，開口叫住了你", "true2": "它只找落單的人", "boss": "怨魂"}
        return self._lore(kind, "story", one, STORY_KEYS[kind])

    def bits(self, kind: str, slot: dict, asks: list[dict]) -> Forged:
        """確定性的假小段：條件、真的、假的、情境各一句固定的（不提那件事、長短每種語氣都合）。"""
        fixed = {"c": "夜深時窗外有響動", "s": "四周忽然靜得出奇"}
        if kind == "plot":   # 事端的處（stash）至少 10 字，同地點描述
            fixed["s"] = "四周忽然靜得出奇，一點聲響也沒有"
        if kind == "plot" and any(x["key"] == "name" for x in asks):   # 事端的名字每條都換（同 story）
            n = len(self.lore_names[kind])
            fixed["n"] = "".join("甲乙丙丁戊己庚辛壬癸子丑"[(n + k) % 12] for k in (0, 5)) + "之事"
            self.lore_names[kind].append(fixed["n"])
        seg = lambda x: "日子就會平平安安過去" if x.get("fake") else fixed.get(x["key"][0], "那東西從此會一直記住你")   # noqa: E731
        return self._lore(kind, "bits", lambda: {x["key"]: seg(x) for x in asks}, tuple(x["key"] for x in asks))

    def whole(self, brief: dict, fix: list[str] = (), last: str = "") -> Forged:
        """確定性的假整篇：第一篇範例換個名字（每類每篇都換）；lore_out["whole"] 給了就照它。"""
        def one():
            body = brief["examples"][0]
            old = next(l.split("｜")[1] for l in body.splitlines() if l.startswith("牌｜"))
            n = len(self.lore_names[brief["what"]] if brief["what"] in self.lore_names else self.lore_names.setdefault(brief["what"], []))
            new = "".join("甲乙丙丁戊己庚辛壬癸子丑"[(n + k) % 12] for k in (0, 4, 8)) + "事"
            self.lore_names[brief["what"]].append(new)
            return {"body": body.replace(old, new)}
        return self._lore(brief["what"], "whole", one, ("body",))

    def judge(self, questions: list[dict]) -> Forged:
        """確定性的假是非題：照題目要的答案答。"""
        keys = tuple(f"q{i}" for i in range(1, len(questions) + 1))
        return self._lore("", "judge", lambda: {k: YES if q["want"] else NO for k, q in zip(keys, questions)}, keys)

    def _lore(self, kind: str, part: str, make, keys: tuple[str, ...]) -> Forged:
        """lore_out[part]：測試要換掉的欄（蓋在合格的輸出上）。"""
        self.lore_asks.append((kind, part))
        if self.fail_next > 0:
            self.fail_next -= 1
            raise UpstreamError("模擬的 AI 失敗")
        got = {**make(), **self.lore_out.get(part, {})}
        return parse_forged(json.dumps({"items": [got]}, ensure_ascii=False), 1, model="mock", keys=keys)

    def classify(self, player_input: str, context: str) -> Classification:
        """確定性的假分類：一律視為普通難度的探索。輸出仍經過 parse_classification。"""
        if self.fail_next > 0:
            self.fail_next -= 1
            raise UpstreamError("模擬的 AI 失敗")
        self.classified.append(player_input)
        return parse_classification(json.dumps({"nature": "探索", "difficulty": "普通"}), model="mock")


def _mock_choices(c: dict) -> list[dict]:
    """依角色狀況給出附帶標註的選項（與真模型同一種形狀）。"""
    if c.get("status") == "DYING":
        return [{"text": "就地包紮療傷", "nature": "休息", "difficulty": "普通"},
                {"text": "燃燒壽元強壓傷勢", "nature": "代價", "difficulty": "普通"},
                {"text": "拚死逃離此地", "nature": "戰鬥", "difficulty": "困難"}]
    choices = [{"text": "靜心打坐修煉", "nature": "修煉", "difficulty": "普通"},
               {"text": "四處探索", "nature": "探索", "difficulty": "普通"},
               {"text": "找人打聽消息", "nature": "社交", "difficulty": "普通"}]
    if (c.get("breakthrough") or {}).get("ready"):
        choices[2] = {"text": "嘗試衝擊瓶頸", "nature": "突破", "difficulty": "困難"}
    return choices


MOCK_NPC = {"name": "守碑老人", "appearance": "白髮老者，拄著一根磨得發亮的木杖",
            "profile": "在山道旁守著古碑多年，對往來的人總要多看兩眼",
            "age": "老年", "power": "深不可測", "goal": "守護", "goal_target": "古碑",
            "ambition": "低", "kindness": "中", "courage": "高", "suspicion": "高"}
MOCK_HEAVEN = "又一隻螻蟻，抬頭看天了。"
MOCK_PERSONA = ("上一個紀元，它還是一名獨行的劍修，一劍斬斷了舊天，從此坐在棋盤的另一端看著眾生。它冷峻、重規矩，"
                "說話極短，從不解釋；它最在意的是秩序，任何人伸手去碰那些被鎖住的大道，都會讓它皺起眉頭。"
                "它記得自己當年是怎麼走上來的，所以也最清楚，該在哪裡等著後來的人。")
MOCK_FACTION = {"name": "青雲宗", "type": "宗門", "location": ""}
MOCK_BOND = {"a": "守碑老人", "b": "青雲宗", "type": "首領"}
MOCK_APPEARANCE = "一身洗得發白的粗布衣裳，眉目清秀，眼神沉靜"
MOCK_REPUTATION = "聽說此人出手狠辣，招惹不得"
MOCK_PLACE_TEXT = "四下安靜，風從路口吹過，帶著塵土與炊煙的氣味。"
MOCK_HISTORY = "立國數百年，歷經數次興衰，如今國力平平，邊境時有摩擦。"
MOCK_MEMORY = {"kind": "說", "subject": "守碑老人", "text": "守碑老人說山後有座古墓，三十年前封了"}
MOCK_THREAD = {"kind": "懸念", "subject": "守碑老人", "text": "山後古墓為何被封", "deadline": "無期限"}
MOCK_LOCATION = {"name": "斷崖古亭", "description": "斷崖邊一座半塌的石亭，亭柱刻滿風化的字跡，崖下雲霧翻湧。",
                 "type": "廢墟"}


def build_narrator(settings) -> "OllamaNarrator | MockNarrator":
    if settings.ai_backend == "mock":
        return MockNarrator()
    return OllamaNarrator(settings.ollama_url, settings.narrator_model, settings.ai_timeout_seconds)
