"""AI 敘事的輸入／輸出合約。

分工原則（沿用舊專案 division_of_labor 的核心精神）：
- Python 決定發生了什麼（判定、數值、時間），AI 只負責把它寫成故事。
- AI 的輸出只接受 narrative、choices 與 proposals 三個欄位（Python 請天道開口的回合多收 heaven）；其他任何欄位一律丟棄，
  不會寫進狀態。舊專案中「AI 填了 Python 權威欄位再由 Python 剝除」的模式
  在這裡從合約層就不存在。
- proposals 是「提案」，不是寫入：這裡只檢查形狀並剝掉白名單外的欄位，
  要不要採用由 game/proposals.py 依遊戲狀態判斷。提案形狀錯誤不會讓整段敘事失敗，
  只會被整批丟棄並記進 ignored_keys。
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from typing import Protocol

MAX_NARRATIVE_CHARS = 2000
MIN_CHOICES, MAX_CHOICES = 2, 4
MAX_CHOICE_CHARS = 40
WEAVE_ROOM = 80   # 改寫一句時最多多幾個字（第 53-3 題）
# 模型偶爾在敘事尾巴接著寫別的欄位（「本回合的 proposals 欄位：{」）；從那一句起都不是敘事
FIELD_TAIL = re.compile(r"[^。！？」\n]*\b(?:proposals|choices|situation|heaven)\b.*", re.S | re.A)

# 選項標註與 AI 分類只能用的值（第 4 步）。與 domain/judgment.py 的 NATURES、DIFFICULTY 必須一致，
# tests/test_judgment.py 會比對（ai 層不依賴 domain 層，所以在這裡另列一份）。
CHOICE_NATURES = ("戰鬥", "潛行", "探索", "社交", "修煉", "抗性", "休息", "觀察", "做工", "參悟", "煉丹", "煉器",
                  "突破", "代價", "移動")
CLASSIFY_NATURES = tuple(n for n in CHOICE_NATURES if n not in ("突破", "代價", "做工"))   # 這幾種只能由玩家明確宣告
DIFFICULTIES = ("容易", "普通", "困難", "極難")

# 提案白名單：AI 只能描述「是什麼」。位置、狀態、aiDriven、境界、年齡、種族等由 Python 決定或留待後續步驟
PROPOSAL_FIELDS = {
    # 第 7 步起地點可以附：與目前所在地的距離分級、方位、上層地點、規模、危險度（Python 驗證，不合格的欄位丟掉）
    "locations": ("name", "description", "type", "distance", "direction", "parent", "scale", "danger"),
    # 第 6 步：NPC 登錄時必須選年齡層與實力層級（Python 換算歲數與境界）；登場後可提案更新描述、互動帶來的關係變化
    # 第 10a 步起 NPC 登錄還要選目標（可指名對象）與四個性格軸（低／中／高）
    "npcs": ("name", "gender", "appearance", "profile", "age", "power", "goal", "goal_target",
             "ambition", "kindness", "courage", "suspicion"),
    "npc_updates": ("name", "appearance", "profile"),
    "relations": ("name", "change", "reason"),
    "favours": ("name", "way", "why"),   # 16v 第 113 題：玩家打字做的事帶來的人情，輕重由 Python 算
    # 第 17 步：見聞（說／做／見，綁在已登錄的人或地點上）、開線（承諾、懸念）、結線（用聯絡簿裡的線頭編號）
    "memories": ("kind", "subject", "text"),
    "thread_opens": ("kind", "subject", "text", "deadline"),
    "thread_closes": ("thread", "result"),
    # 第 10a 步：勢力（最小版）、羈絆（甲對乙而言是〔種類〕）、主角外貌（Python 標記要改寫或開場還沒寫時）
    "factions": ("name", "type", "location"),
    "bonds": ("a", "b", "type"),
    "self_appearance": ("text",),
    # 第 10c-3b 步：江湖傳言中的你（Python 判斷此地名聲跨過門檻、或有大事新傳到時才請 AI 寫）
    "self_reputation": ("text",),
    # 地圖第二輪：所在地的描述還是預設文字時，請 AI 寫一段
    "place_text": ("text",),
    # 16k：一國的往事還沒寫時（第一次走進那一國、打聽往事），請 AI 寫一段
    "history_text": ("text",),
    # 16p：世界的新物品（借 base 的效果與價格，只進世界清單，不進背包）
    "items": ("name", "base", "description"),
    # 16r：地點眼前的環境物（第一次到訪時才請 AI 列）
    "place_features": ("name", "use", "once"),
    # 16p 第二批：世界的新事件（借 base 的類別、應對方式、獎懲，只換名字與場景）
    "incidents": ("name", "base", "scene"),
    # 第 2-4b 批：「發生了什麼事」合成一種（120-8），開關 Settings.acts；Python 換回關係、人情、見聞、開線（game/proposals.expand）
    "acts": ("kind", "name", "by", "text"),
}
ACTS = "acts"
DEFAULT_KINDS = tuple(k for k in PROPOSAL_FIELDS if k != ACTS)   # 開關沒開：舊的四種
ACT_KINDS = ("幫忙", "送禮", "救命", "照顧", "冒犯", "害他丟臉", "說謊", "威脅", "答應", "借錢", "還情", "說了", "看到", "懸念")
ACT_BY = ("你", "他")
PROPOSAL_MAX_PER_TURN = {"locations": 1, "npcs": 2, "npc_updates": 2, "relations": 3, "favours": 1,
                         "memories": 2, "thread_opens": 1, "thread_closes": 2,
                         "factions": 1, "bonds": 2, "self_appearance": 1, "self_reputation": 1, "place_text": 1,
                         "history_text": 1, "items": 1, "place_features": 5, "incidents": 1, "acts": 3}
# 與 domain/npc.py、domain/memory.py 一致（tests/test_npc.py、tests/test_memory.py 比對）
NPC_AGE_BANDS = ("孩童", "少年", "青年", "壯年", "老年")
NPC_POWER_TIERS = ("凡人", "初入修行", "小有修為", "一方強者", "深不可測")
RELATION_CHANGE_TYPES = ("小幅好轉", "明顯好轉", "小幅惡化", "明顯惡化")
FAVOUR_WAYS = ("欠你", "你欠", "借你", "還了")   # 與 domain/favour.py 一致；借你＝他答應借錢，還了＝他答應還你人情
MEMORY_KINDS = ("說", "做", "見")
THREAD_KINDS = ("我的承諾", "他人的承諾", "懸念")
THREAD_DEADLINES = ("數日", "一月", "一年", "無期限")
THREAD_RESULTS = ("兌現", "解開", "落空")
NPC_GOALS = ("求道", "守護", "逐利", "求名", "復仇", "報恩", "追隨", "隱居", "尋物")
TRAIT_LEVELS = ("低", "中", "高")
FACTION_TYPES = ("宗門", "武館", "家族", "幫派", "朝廷", "商會")
FEATURE_USES = ("掩蔽", "投擲", "阻擋", "攀高")   # 與 domain/scene.py 的 USES 一致
BOND_TYPES = ("親人", "師父", "徒弟", "戀人", "伴侶", "首領", "成員", "盟友", "敵對", "從屬")   # 友人、仇家、恩人、同門由 Python 算出（121-4）
PROPOSAL_ENUMS = {   # 提案種類 → 欄位 → 可用的值（同名欄位在不同種類可以有不同清單）
    "npcs": {"age": NPC_AGE_BANDS, "power": NPC_POWER_TIERS, "goal": NPC_GOALS, "ambition": TRAIT_LEVELS,
             "kindness": TRAIT_LEVELS, "courage": TRAIT_LEVELS, "suspicion": TRAIT_LEVELS},
    "factions": {"type": FACTION_TYPES},
    "bonds": {"type": BOND_TYPES},
    "relations": {"change": RELATION_CHANGE_TYPES},
    "favours": {"way": FAVOUR_WAYS},
    "memories": {"kind": MEMORY_KINDS},
    "thread_opens": {"kind": THREAD_KINDS, "deadline": THREAD_DEADLINES},
    "thread_closes": {"result": THREAD_RESULTS},
    "place_features": {"use": FEATURE_USES, "once": ("是", "否")},
    "acts": {"kind": ACT_KINDS, "by": ACT_BY},
}
PROPOSAL_REQUIRED = {"locations": ("name",), "npcs": ("name", "age", "power", "goal", "ambition", "kindness",
                                                       "courage", "suspicion"),
                     "npc_updates": ("name",),
                     "relations": ("name", "change"), "favours": ("name", "way"), "memories": ("kind", "subject", "text"),
                     "thread_opens": ("kind", "subject", "text"), "thread_closes": ("thread", "result"),
                     "factions": ("name", "type"), "bonds": ("a", "b", "type"), "self_appearance": ("text",),
                     "self_reputation": ("text",), "place_text": ("text",), "history_text": ("text",),
                     "items": ("name", "base", "description"), "place_features": ("name", "use", "once"),
                     "incidents": ("name", "base", "scene"), "acts": ("kind", "name", "by", "text")}
MAX_SITUATION_CHARS = 60      # 局面備忘：要求 40 字內，超過的截斷
MAX_PROPOSAL_ITEMS = 5        # 形狀層的硬上限：超過的直接截斷，不進審核
MAX_PROPOSAL_FIELD_CHARS = 400


class ContractError(ValueError):
    """AI 輸出不符合合約。由 Narrator 實作決定是否重試。"""


@dataclass(frozen=True)
class NarrationRequest:
    kind: str                      # "opening" | "action"
    character: dict                # character.summary()
    clock_label: str
    player_input: str = ""         # 原文：只給假說書人（3-6a：真說書人看 action、speech）
    action: str = ""               # 【主角的行動】Python 組的一行（domain/reading.action）
    speech: str = ""               # 【主角說的話】讀懂抄的台詞，最長 60 字
    judgment: dict = field(default_factory=dict)
    facts: list[str] = field(default_factory=list)
    side: list[str] = field(default_factory=list)    # 【旁支】排程給的旁支事實，最多三行（第 2-3 批第 5 題）
    recent: list[str] = field(default_factory=list)   # 近幾回合的行動摘要（最後一則附敘事結尾）
    fallen: bool = False
    rules_text: str = ""
    known_locations: list[str] = field(default_factory=list)   # 已登錄的地點名稱（避免 AI 重複提案）
    known_npcs: list[str] = field(default_factory=list)
    realm_guide: str = ""      # 境界規格（空間規模、敘事上限、禁止描寫），由 domain/realm.py 產生
    sect_lore: str = ""        # 宗門的層級：依主角境界只給看得到的那一行（第 16b 步，domain/region.py）
    place_info: str = ""       # 所在地（類型、危險度、描述、相連的地點），第 7 步
    contact: str = ""          # 聯絡簿：在場人物（第 6 步）＋記事、線頭、主角近況（第 17 步），由 Python 挑選組好
    inspiration: str = ""      # 新人物的靈感素材（第 10a 步，Python 隨機抽，AI 可不照用）
    appearance_task: str = ""  # 這回合要請 AI 寫主角外貌的原因（開場還沒寫、年歲漸長、境界提升、留下傷痕）；空＝不用
    place_task: str = ""       # 這回合要請 AI 寫描述的地點（所在地的描述還是預設文字）；空＝不用
    place_hint: str = ""       # 小地方的來歷、特徵（第 9g 批，domain/spots.py）：寫描述時照這個寫；空＝沒有
    history_task: str = ""     # 這回合要請 AI 寫往事的國（16k）；空＝不用
    # 可用的名字（WHITEPAPER 12.6）：{"place_prefix": 地名字首}；空＝不給
    name_offer: dict = field(default_factory=dict)
    arrival: str = ""          # Python 安排這回合登場的人的設定（domain/newcomer.describe）；空＝沒有安排
    incident: str = ""         # 這回合的事件（第 9a 步）：Python 定的骨架與寫法；空＝沒有事件
    # 名聲（第 10c-3b 步）：此地有人提起的方向與等級（文字）；要請 AI 寫「江湖傳言中的你」時附上等級與傳聞
    reputation: str = ""
    reputation_task: str = ""
    heaven: str = ""           # 【天道開口】的內容（第 18-1 步，domain/heaven.voice_task）；空＝天道這回合不出聲
    retired: bool = False      # 主角這回合退隱（第 11-1 步）：寫退場尾聲，與殞落一樣不給選項（fallen 也是 True）
    legend: str = ""           # 前人的傳說（第 11-1 步，domain/legacy.told）；空＝這回合沒有相關的
    zone: str = ""             # 【領域】主角在籠罩中的領域裡（第 19-1 步，domain/domains.prompt）；空＝不在
    legend_line: str = ""      # 【都市傳說】主角在出沒範圍或被纏上（第 19-2 步，domain/legends.prompt）；空＝沒有
    era_line: str = ""         # 【時代】現代、未來的樣子與修士的處境（第 16e 節，domain/era.prompt）；古代是空的
    era_words: tuple = ()      # 時代詞表（古代的詞, 這時代的說法）：組好的提示詞整份照換，「」裡的不換（第 8-1 批，domain/era.pairs）
    era_keep: tuple = ()       # 不換的名字：地名、人名、勢力名（換了模型提案對不上資料）
    rite_line: str = ""        # 【玩法】主角所在的一帶流傳的儀式玩法、在張羅的人（19-3，game/rites.play）；空＝沒有
    subjects: list[str] = field(default_factory=list)   # 【可用的主語】在場的人＋此地（16m 第 11 題）

    # 這回合送給說書人的提案種類（只送用得到的，見 service._proposal_kinds）；預設全部
    proposal_kinds: tuple[str, ...] = DEFAULT_KINDS
    item_bases: tuple[str, ...] = ()   # 這回合新物品可以借的底（16p）；空＝不開放
    absent: str = ""                   # 玩家說要用、但身上和眼前都沒有的東西（打字第 9 題）
    scene_task: str = ""               # 這回合請 AI 列環境物的地點（16r）；空＝沒請
    event_bases: tuple[str, ...] = ()  # 這回合新事件可以借的底（16p）：「名字：場景」；空＝不請
    situation: str = ""                # 上回合的局面備忘（故事第 1 題）
    focus: str = ""                    # 眼前的人（故事第 2 題）：名字、態度、目標、外貌
    stay: bool = False                 # 這回合沒有離開原處
    plot: str = ""                     # 這裡的事端（16t）：風聲與主角已查到的，秘密不送
    route: str = ""                    # 手上的路線（16v）：這類故事怎麼走
    held: str = ""                     # 還留在場景的牌（16v 第 83 題）：這回合沒有別的事才送


def empty_proposals() -> dict[str, list[dict]]:
    return {kind: [] for kind in PROPOSAL_FIELDS}


@dataclass(frozen=True)
class NarrationResult:
    narrative: str
    choices: list[str]
    model: str
    ignored_keys: list[str] = field(default_factory=list)
    proposals: dict = field(default_factory=empty_proposals)   # 尚未驗證的提案，只保證形狀
    attempts: int = 1        # 第幾次呼叫才得到合格輸出（遙測用）
    rejected: list[str] = field(default_factory=list)   # 前幾次不合格的錯誤與原始輸出（遙測用）
    choice_tags: list[dict] = field(default_factory=list)   # 與 choices 對齊：{"nature", "difficulty", "target"}，未標或不合法為空字串
    prompt_tokens: int = 0   # 模型回報的提示詞長度（token，遙測用；假說書人為 0）
    heaven: str = ""         # 天道的台詞（只有請求有【天道開口】才收；內容由 domain/heaven.check_line 驗證）
    situation: str = ""      # 局面備忘（故事第 1 題）：說書人寫給下一回合的自己，玩家看不到


@dataclass(frozen=True)
class Written:
    """請 AI 寫的一段文字（第 18-1 步：天道人設的潤色）。內容由 domain 層審核。"""
    text: str
    model: str
    attempts: int = 1
    rejected: list[str] = field(default_factory=list)
    prompt_tokens: int = 0


@dataclass(frozen=True)
class Classification:
    """AI 分類的結果：性質與任務難易，都已確認在清單內。"""
    nature: str
    difficulty: str
    model: str
    attempts: int = 1
    rejected: list[str] = field(default_factory=list)
    prompt_tokens: int = 0


# 讀懂（3-2）：欄的順序就是模型填的順序。先讀懂動作，再判斷是誰做、有沒有替別人寫結果（「怎麼調」甲）
READ_ORDER = ("做什麼", "判什麼", "對誰", "對著什麼", "用什麼", "去哪", "做出什麼", "買賣找人", "貨", "回應哪一個", "在查哪一個",
              "在辦哪件請託", "說出前世的事", "勢力之間", "說到哪個勢力", "做法", "誰做", "替別人寫結果")
READ_MULTI = "判什麼"                          # 可以挑幾個的欄
READ_FREE = ("主角說的話", "數字", "時長", "地名", "對象名")   # 照原文抄的欄，沒有就空字串（是不是原文由 domain/reading.py 驗）


@dataclass(frozen=True)
class Reading:
    """讀懂的行動單（3-2）：欄 → 答案，都已確認在 Python 給的清單內；判什麼用「+」連。"""
    sheet: dict
    model: str
    attempts: int = 1
    rejected: list[str] = field(default_factory=list)
    prompt_tokens: int = 0


@dataclass(frozen=True)
class Forged:
    """建世界時寫的一批物品（第 128 系列）：每件 {name, look, origin}，件數跟條件一樣；內容由 domain/newitems.review 審。"""
    items: list[dict]
    model: str
    attempts: int = 1
    rejected: list[str] = field(default_factory=list)
    prompt_tokens: int = 0


FORGE_KEYS = ("name", "look", "origin")
STORY_KEYS = {   # 第 128 系列乙：傳說、規則怪談的故事段（＝domain/newlegends.STORY、newtales.STORY）
    "legend": ("name", "mood", "line", "true2", "boss", "found1", "found2", "end", "why"),
    "tale": ("name", "rumor", "mood", "found1", "found2", "end", "why"),
}
YES, NO = "是", "否"   # 是非題的答案


def parse_forged(raw: str, n: int, *, model: str, keys: tuple[str, ...] = FORGE_KEYS) -> Forged:
    """一批 n 件，每件 keys 都是字串（物品 FORGE_KEYS；傳說、怪談的故事、潤色、是非題都是 1 件）。"""
    try:
        data = json.loads(raw)
    except (json.JSONDecodeError, TypeError) as exc:
        raise ContractError(f"AI 輸出不是合法 JSON：{exc}") from exc
    got = data.get("items") if isinstance(data, dict) else None
    if not isinstance(got, list) or len(got) != n or not all(isinstance(g, dict) and all(isinstance(g.get(k), str) for k in keys)
                                                             for g in got):
        raise ContractError(f"items 要剛好 {n} 件，每件有 {'、'.join(keys)} 字串")
    return Forged(items=[{k: g[k].strip() for k in keys} for g in got], model=model)


class Narrator(Protocol):
    name: str

    def narrate(self, request: NarrationRequest) -> NarrationResult: ...

    def classify(self, player_input: str, context: str) -> Classification: ...

    def persona(self, card_lines: str) -> Written: ...

    def spot(self, player_input: str, detail: str) -> Written: ...

    def vet(self, text: str) -> Reading: ...

    def weave(self, narrative: str, detail: str) -> Written: ...

    def forge(self, slots: list[dict], era_now: str) -> Forged: ...

    def story(self, kind: str, slot: dict) -> Forged: ...

    def bits(self, kind: str, slot: dict, asks: list[dict]) -> Forged: ...

    def judge(self, questions: list[dict]) -> Forged: ...


def parse_written(raw: str, *, model: str) -> Written:
    try:
        data = json.loads(raw)
    except (json.JSONDecodeError, TypeError) as exc:
        raise ContractError(f"AI 輸出不是合法 JSON：{exc}") from exc
    if not isinstance(data, dict) or not isinstance(data.get("text"), str) or not data["text"].strip():
        raise ContractError("缺少 text 字串")
    return Written(text=data["text"].strip(), model=model)


VET = ("沒有", "有")   # 3-7b：玩家長期文字有沒有問題（夾指令或既定事實，收尾甲合成一欄），另抄「哪一句」


def parse_vet(raw: str, *, model: str) -> Reading:
    try:
        data = json.loads(raw)
    except (json.JSONDecodeError, TypeError) as exc:
        raise ContractError(f"AI 輸出不是合法 JSON：{exc}") from exc
    if not isinstance(data, dict) or data.get("有沒有問題") not in VET or not isinstance(data.get("哪一句"), str):
        raise ContractError("有沒有問題要填沒有或有，哪一句要是字串")
    return Reading(sheet={k: data[k] for k in ("有沒有問題", "哪一句")}, model=model)


def sentences(text: str) -> list[str]:
    """切成句子，接回去和原文一字不差。"""
    return re.findall(r"[^。！？]*[。！？」]+|[^。！？]+$", text)


def weave_ids(parts: list[str]) -> list[str]:
    """改寫哪一句：開頭那句接著玩家的行動，不動。"""
    return [str(i) for i in range(2, len(parts) + 1)] or ["1"]


def parse_weave(raw: str, parts: list[str], *, model: str) -> Written:
    """第 53-3 題：模型回編號和新句子，Python 換掉那句。新句子要比原句長，也要是完整的句子。"""
    try:
        data = json.loads(raw)
    except (json.JSONDecodeError, TypeError) as exc:
        raise ContractError(f"AI 輸出不是合法 JSON：{exc}") from exc
    if not isinstance(data, dict) or data.get("pick") not in weave_ids(parts) or not isinstance(data.get("text"), str):
        raise ContractError("缺少 pick 或 text")
    i, new = int(data["pick"]) - 1, data["text"].strip()
    if not len(parts[i]) < len(new) <= len(parts[i]) + WEAVE_ROOM or new[-1] not in "。！？」":
        raise ContractError(f"改寫的句子不合格：{new[:40]}")
    return Written(text="".join([*parts[:i], new, *parts[i + 1:]]), model=model)


def parse_classification(raw: str, *, model: str) -> Classification:
    try:
        data = json.loads(raw)
    except (json.JSONDecodeError, TypeError) as exc:
        raise ContractError(f"AI 輸出不是合法 JSON：{exc}") from exc
    if not isinstance(data, dict):
        raise ContractError("AI 輸出必須是 JSON 物件")
    if data.get("nature") not in CLASSIFY_NATURES:
        raise ContractError(f"nature 不在清單內：{data.get('nature')!r}")
    if data.get("difficulty") not in DIFFICULTIES:
        raise ContractError(f"difficulty 不在清單內：{data.get('difficulty')!r}")
    return Classification(nature=data["nature"], difficulty=data["difficulty"], model=model)


def parse_reading(raw: str, lists: dict[str, tuple], *, model: str) -> Reading:
    """只有一個選項的欄不在 schema 裡（3-2 第 2 題），直接填那一個。"""
    try:
        data = json.loads(raw)
    except (json.JSONDecodeError, TypeError) as exc:
        raise ContractError(f"AI 輸出不是合法 JSON：{exc}") from exc
    if not isinstance(data, dict):
        raise ContractError("AI 輸出必須是 JSON 物件")
    sheet = {}
    for k, opts in lists.items():
        v = data.get(k, opts[0] if len(opts) == 1 else None)
        if not (isinstance(v, list) and all(x in opts for x in v) if k == READ_MULTI else v in opts):
            raise ContractError(f"{k} 不在清單內：{v!r}")
        sheet[k] = "+".join(v) if k == READ_MULTI else v
    sheet |= {k: data[k].strip() if isinstance(data.get(k), str) else "" for k in READ_FREE}
    return Reading(sheet=sheet, model=model)


def parse_output(raw: str, *, model: str, fallen: bool, voice: bool = False) -> NarrationResult:
    """voice：這回合有請天道開口，才收 heaven 欄位（沒請卻寫了一樣丟掉）。"""
    try:
        data = json.loads(raw)
    except (json.JSONDecodeError, TypeError) as exc:
        raise ContractError(f"AI 輸出不是合法 JSON：{exc}") from exc
    if not isinstance(data, dict):
        raise ContractError("AI 輸出必須是 JSON 物件")

    narrative = data.get("narrative")
    narrative = FIELD_TAIL.sub("", narrative).strip() if isinstance(narrative, str) else ""
    if not narrative:
        raise ContractError("缺少 narrative 字串")
    narrative = narrative[:MAX_NARRATIVE_CHARS]

    raw_choices = data.get("choices", [])
    if not isinstance(raw_choices, list):
        raise ContractError("choices 必須是陣列")
    choices: list[str] = []
    tags: list[dict] = []
    for item in raw_choices:
        # 選項可以是字串，或附帶 AI 標註的物件 {"text", "nature", "target"}；標註不在清單內就當作沒標
        # 難度不收（3-5 第 5 題：說書人標的會被前情提要帶偏，改由 domain/stake.py 估要的有多大）；欄留著，存檔格式不變
        text = item.get("text") if isinstance(item, dict) else item
        if not isinstance(text, str) or not text.strip() or text.strip()[:MAX_CHOICE_CHARS] in choices:
            continue
        choices.append(text.strip()[:MAX_CHOICE_CHARS])
        nature = item.get("nature") if isinstance(item, dict) else ""
        target = item.get("target") if isinstance(item, dict) else ""
        tags.append({"nature": nature if nature in CHOICE_NATURES else "", "difficulty": "",
                     # 對象 NPC 的名字（第 6 步）；是不是真的 NPC、在不在場由 game 層判斷
                     "target": target.strip()[:12] if isinstance(target, str) else ""})
    choices, tags = choices[:MAX_CHOICES], tags[:MAX_CHOICES]
    if fallen:
        choices, tags = [], []   # 角色已殞落，不再提供行動選項
    elif len(choices) < MIN_CHOICES:
        raise ContractError(f"choices 至少需要 {MIN_CHOICES} 個")

    allowed = ("narrative", "choices", "proposals", "situation", *(("heaven",) if voice else ()))
    ignored = sorted(k for k in data if k not in allowed)
    proposals, proposal_ignored = _parse_proposals(data.get("proposals"))
    heaven = data.get("heaven") if voice and isinstance(data.get("heaven"), str) else ""
    situation = data.get("situation") if isinstance(data.get("situation"), str) else ""
    return NarrationResult(narrative=narrative, choices=choices, model=model, choice_tags=tags,
                           ignored_keys=ignored + proposal_ignored, proposals=proposals, heaven=heaven.strip(),
                           situation=situation.strip()[:MAX_SITUATION_CHARS])


def _parse_proposals(raw) -> tuple[dict[str, list[dict]], list[str]]:
    """只做形狀檢查。回傳（白名單內的提案, 被丟棄的欄位名稱）。"""
    proposals = empty_proposals()
    if raw is None:
        return proposals, []
    if not isinstance(raw, dict):
        return proposals, ["proposals"]
    ignored = {f"proposals.{k}" for k in raw if k not in PROPOSAL_FIELDS}
    for kind, allowed in PROPOSAL_FIELDS.items():
        items = raw.get(kind, [])
        if not isinstance(items, list):
            ignored.add(f"proposals.{kind}")
            continue
        for item in items[:MAX_PROPOSAL_ITEMS]:
            if not isinstance(item, dict):
                ignored.add(f"proposals.{kind}")
                continue
            ignored |= {f"proposals.{kind}.{k}" for k in item if k not in allowed}
            proposals[kind].append({k: item[k].strip()[:MAX_PROPOSAL_FIELD_CHARS]
                                    for k in allowed if isinstance(item.get(k), str)})
    return proposals, sorted(ignored)
