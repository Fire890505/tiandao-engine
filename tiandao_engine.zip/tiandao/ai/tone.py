"""敘事語氣與判定結果的一致性檢查（只做遙測，不攔截、不改寫敘事）。

概念取自舊專案 narrative_consistency.py：不猜語意，只比對收尾語氣詞。
與舊版的差異（對應稽核 B-15）：
- 只在這回合真的有擲骰時才檢查，不擲骰的行動不產生警報；
- 先移除「未成功」「沒能完成」這類否定片語，再判斷成功詞，避免把失敗句算成成功；
- 刪掉「阻止」「擊退」等雙向詞——主角擊退敵人是成功，主角被擊退是失敗，無法只靠字面判斷。
"""
from __future__ import annotations

import re

_NEGATED_SUCCESS = re.compile(r"(未|沒有?|不曾|並未|無法|未能|沒能|不能)(能夠?)?(成功|完成|達成|得手|奏效|如願)")
_SUCCESS = ("成功", "順利", "得手", "奏效", "如願以償", "圓滿", "有所精進", "有所收穫", "大有長進", "突破了")
_FAILURE = ("失敗", "未能", "沒能", "落空", "未果", "徒勞", "白費", "功虧一簣", "無濟於事", "不了了之",
            "失手", "一無所獲", "毫無進展", "毫無收穫")

SUCCESS, FAILURE, UNCLEAR = "success", "failure", "unclear"


def detect(text: str) -> str:
    stripped = _NEGATED_SUCCESS.sub("〔否定〕", text or "")
    has_success = any(m in stripped for m in _SUCCESS)
    has_failure = "〔否定〕" in stripped or any(m in stripped for m in _FAILURE)
    if has_success == has_failure:
        return UNCLEAR
    return SUCCESS if has_success else FAILURE


def check(judgment: dict, narrative: str) -> str:
    """回傳 "" （不適用或一致）、"unclear"（看不出語氣）或 "mismatch"（語氣與判定相反）。"""
    if not judgment.get("rolled"):
        return ""
    tone = detect(narrative)
    if tone == UNCLEAR:
        return "unclear"
    expected = SUCCESS if judgment.get("outcome") in ("大成功", "成功") else FAILURE
    return "" if tone == expected else "mismatch"
