from __future__ import annotations

import json
import re
import secrets
from datetime import datetime, timedelta, timezone


def new_id(prefix: str) -> str:
    return f"{prefix}_{secrets.token_hex(8)}"


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def iso(dt: datetime | None = None) -> str:
    return (dt or utcnow()).isoformat(timespec="seconds")


def iso_in(hours: int) -> str:
    return iso(utcnow() + timedelta(hours=hours))


def dumps(value) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def swap(text: str, pairs, keep=()) -> str:
    """照 pairs（舊詞, 新詞）換字，「」裡的不換（判詞、台詞、玩家原話）；pairs 要長的詞排前面。時代詞表用（第 8-1 批）。
    keep：不換的名字（地名、人名、勢力名照舊，換了模型提案會對不上資料裡的名字）。"""
    keep = sorted((k for k in keep if any(old in k for old, _ in pairs)), key=len, reverse=True)
    for i, k in enumerate(keep):
        text = text.replace(k, f"\x00{i}\x00")
    parts = re.split(r"(「[^」]*」)", text)
    for i in range(0, len(parts), 2):
        for old, new in pairs:
            parts[i] = parts[i].replace(old, new)
    text = "".join(parts)
    for i, k in enumerate(keep):
        text = text.replace(f"\x00{i}\x00", k)
    return text


def loads(text: str | None, default):
    if not text:
        return default
    return json.loads(text)
