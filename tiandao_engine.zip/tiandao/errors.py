"""預期內的錯誤一律用 AppError 表達，HTTP 層只把 AppError 轉成對應狀態碼。

設計規則（對應舊專案稽核 T-01）：
程式錯誤（NameError、TypeError 等）不得被 `except Exception` 吞掉降級成 WARN。
它們會一路拋到 HTTP 層，記錄完整 traceback 並回 500；測試時直接失敗。
"""
from __future__ import annotations


class AppError(Exception):
    status = 400
    code = "bad_request"

    def __init__(self, message: str, *, code: str | None = None, details: dict | None = None):
        super().__init__(message)
        self.message = message
        if code:
            self.code = code
        self.details = details or {}


class BadRequest(AppError):
    status, code = 400, "bad_request"


class Unauthorized(AppError):
    status, code = 401, "unauthorized"


class NotFound(AppError):
    status, code = 404, "not_found"


class Conflict(AppError):
    status, code = 409, "conflict"


class UpstreamError(AppError):
    """AI 服務失敗。回合不會被寫入，玩家可以直接重送。"""
    status, code = 502, "ai_unavailable"


class MethodNotAllowed(AppError):
    status, code = 405, "method_not_allowed"


def text_field(value, label: str, code: str) -> str:
    """請求裡的文字欄位：沒給＝空字串；不是文字就回 400（數字、陣列直接 .strip() 會變成 500）。回傳去頭尾空白的文字。"""
    if value is None:
        return ""
    if not isinstance(value, str):
        raise BadRequest(f"{label}必須是文字。", code=code)
    return value.strip()
