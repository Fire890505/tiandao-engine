"""第 0 步驗證工具：用真模型自動玩 N 回合，量測說書人是否遵守合約。

    python -m tiandao ai-check --turns 30 --model yi:34b-chat

走的是與正式遊戲完全相同的 GameService 管線（只是不經過 HTTP），資料寫在獨立的
資料庫檔，不會碰到正式存檔。結束後輸出一份 Markdown 報告與該資料庫供人工翻閱。
"""
from __future__ import annotations

import random
import statistics
from collections import Counter
from contextlib import nullcontext
from dataclasses import dataclass, field
from unittest.mock import patch
from datetime import datetime
from pathlib import Path

from ..ai.narrators import build_narrator
from ..config import PROJECT_ROOT, Settings
from ..domain import stake
from ..errors import Conflict, UpstreamError
from ..game import auth
from ..game.rules import RuleBook
from ..game.service import ENDED, GameService
from ..store import repos
from ..store.db import connect, migrate

SCRIPTED_ACTIONS = (
    "盤膝打坐，吐納靈氣", "沿著山道往前探索", "找路人打聽附近的宗門", "拔劍攻擊攔路的山賊",
    "悄悄潛入林中跟蹤可疑的人", "環顧四周，觀察動靜", "在樹下休息療傷", "閉關修煉三日",
    "上前與眼前的人攀談，請教此地的事",
)
MAX_TRIES_PER_TURN = 3

# 建議門檻：第 0 步的「穩定」定義。可依實際體驗調整，但調整時請寫進 HANDOFF。
THRESHOLDS = {"first_try_rate": 0.90, "failure_rate": 0.02, "mismatch_rate": 0.10}


@dataclass
class CheckResult:
    report_path: Path
    db_path: Path
    metrics: dict
    passed: bool
    notes: list[str] = field(default_factory=list)


def run(settings: Settings, turns: int, out_dir: Path | None = None, narrator=None,
        log=print, games: int = 1, seed: int | None = None, era: str | None = None) -> CheckResult:
    """games 局各玩 turns 回合；給 seed 時第 g 局的世界、角色亂數固定成 seed+g（127-9 改前改後同一組種子）。era：起始時代（第 8-6 批驗現代）。"""
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    out_dir = out_dir or (PROJECT_ROOT / "progress")
    out_dir.mkdir(parents=True, exist_ok=True)
    db_path = out_dir / f"ai_check_{stamp}.db"
    migrate(db_path)
    narrator = narrator or build_narrator(settings)
    game = GameService(narrator, RuleBook(settings.rules_dir))
    game.acts = settings.acts
    game.later = lambda job: job()   # 建世界寫物品當場跑：不跟開場搶模型，量到的延遲才準（128-12）
    conn = connect(db_path)
    notes: list[str] = []
    try:
        auth.register(conn, "aicheck", "aicheck-password")
        user_id = repos.get_user_by_username(conn, "aicheck")["id"]
        total, aborted = 0, False
        for g in range(games):
            if aborted:
                break
            rng = random.Random(seed + g) if seed is not None else None
            with patch("secrets.token_hex", lambda n=16: rng.randbytes(n).hex()) if rng else nullcontext():
                played, aborted = _play(conn, game, user_id, turns, notes, log, era)
            total += played
        metrics = summarize(conn)
    finally:
        conn.close()
    metrics["turnsPlayed"] = total
    metrics["prompt"] = _sizes(getattr(narrator, "sizes", []))
    passed = _passed(metrics, aborted=aborted)
    report = out_dir / f"ai_check_{stamp}.md"
    report.write_text(render(metrics, passed, notes, narrator, db_path), encoding="utf-8")
    return CheckResult(report, db_path, metrics, passed, notes)


def _sizes(sizes: list[tuple[int, int]]) -> dict:
    """每次敘事送出的字數、token（模型回報，含快取接上的部分）和 token ÷ 字數。"""
    sizes = [(c, t) for c, t in sizes if c and t]   # 假說書人 token 是 0，不算
    if not sizes:
        return {}
    chars, tokens = sorted(c for c, _ in sizes), sorted(t for _, t in sizes)
    return {"n": len(sizes), "charsP50": int(statistics.median(chars)), "charsMax": chars[-1],
            "tokensP50": int(statistics.median(tokens)), "tokensMax": tokens[-1],
            "ratio": round(statistics.median(t / c for c, t in sizes), 3)}


def _play(conn, game: GameService, user_id: str, turns: int, notes: list[str], log, era: str | None = None) -> tuple[int, bool]:
    """開一局玩 turns 回合（殞落就開新局接著玩）；回傳（玩了幾回合, 是否提前結束）。"""
    session_id, played, scripted = _new_game(conn, game, user_id, log, era), 0, 0
    while played < turns:
        state = game.get_state(conn, user_id, session_id)
        if state["session"]["phase"] == ENDED:
            notes.append(f"第 {played} 回合時角色殞落，自動開新局繼續。")
            session_id = _new_game(conn, game, user_id, log, era)
            continue
        # 偶數回合用腳本行動（涵蓋所有行動類型），奇數回合用 AI 給的第一個選項（確認選項可玩）；
        # Python 塞的回話按鈕（標記空白、不是指路）先點（3-4 第 4 題）
        own = [c for c, t in zip(state["choices"], state["choiceTags"]) if not t.get("nature") and not c.startswith("前往")]
        choice = (own or state["choices"] or [None])[0] if played % 2 else None
        if not choice:
            scripted += 1
        action = choice or SCRIPTED_ACTIONS[(scripted - 1) % len(SCRIPTED_ACTIONS)]
        body = {"input": action}
        for attempt in range(1, MAX_TRIES_PER_TURN + 1):
            try:
                result = game.play_turn(conn, user_id, session_id, {**body, "requestId": f"chk-{session_id}-{played}-{attempt}"})
                break
            except UpstreamError as exc:
                log(f"  第 {played + 1} 回合 AI 失敗（{attempt}/{MAX_TRIES_PER_TURN}）：{exc.message}")
            except Conflict as exc:   # 3-3b 停下來問：真模型按不了，按最後那顆保守值（第 6 題）
                if exc.code == "unsure":   # 3-6b 看不懂：不寫回合，換下一句腳本
                    scripted += 1
                    body = {"input": SCRIPTED_ACTIONS[(scripted - 1) % len(SCRIPTED_ACTIONS)]}
                    log(f"  第 {played + 1} 回合看不懂「{action}」")
                    action = body["input"]
                    continue
                if exc.code != "asking":
                    raise
                body["answer"] = exc.details["buttons"][-1]["value"]
                log(f"  第 {played + 1} 回合問：{exc.message}")
        else:
            notes.append(f"第 {played + 1} 回合連續 {MAX_TRIES_PER_TURN} 次失敗，提前結束。")
            return played, True
        played += 1
        j = result["turn"]["judgment"]
        log(f"  {played:>3}/{turns} {j.get('action_type', '')}・{j.get('outcome') or '不擲骰'}　{action}")
    return played, False


def report_existing(settings: Settings, out_dir: Path | None = None) -> CheckResult:
    """為正式資料庫產生同一份報告：手動遊玩 30 回合後執行，量測的是真實玩法下的表現。"""
    out_dir = out_dir or (PROJECT_ROOT / "progress")
    out_dir.mkdir(parents=True, exist_ok=True)
    migrate(settings.db_path)
    conn = connect(settings.db_path)
    try:
        metrics = summarize(conn)
        metrics["turnsPlayed"] = sum(1 for c in repos.list_ai_calls(conn) if c["ok"] and c["kind"] == "action")
    finally:
        conn.close()
    passed = _passed(metrics, aborted=False)

    class _Name:  # render() 只需要 name 屬性
        name = f"{settings.narrator_model}（正式資料庫中的所有 AI 呼叫）"
    report = out_dir / f"ai_report_{datetime.now():%Y%m%d_%H%M%S}.md"
    report.write_text(render(metrics, passed, [], _Name, settings.db_path), encoding="utf-8")
    return CheckResult(report, settings.db_path, metrics, passed)


def _passed(m: dict, *, aborted: bool) -> bool:
    return (not aborted and m["calls"] > 0
            and m["firstTryRate"] >= THRESHOLDS["first_try_rate"]
            and m["failureRate"] <= THRESHOLDS["failure_rate"]
            and m["mismatchRate"] <= THRESHOLDS["mismatch_rate"])


def _new_game(conn, game: GameService, user_id: str, log, era: str | None = None) -> str:
    session_id = game.create_session(conn, user_id, "AI 檢查", start_era=era)["session"]["id"]
    game.create_character(conn, user_id, session_id, {"name": "試煉者", "gender": "男"})
    for attempt in range(1, MAX_TRIES_PER_TURN + 1):
        try:
            game.opening(conn, user_id, session_id, {"requestId": f"open-{attempt}"})
            log("  開場完成")
            return session_id
        except UpstreamError as exc:
            log(f"  開場 AI 失敗（{attempt}/{MAX_TRIES_PER_TURN}）：{exc.message}")
    raise UpstreamError("開場連續失敗，無法進行檢查。請確認 Ollama 已啟動且模型名稱正確。")


def _reads(conn, calls: list[dict]) -> dict:
    """3-3a 讀懂：跳確認幾回合、失敗幾次、多慢；跳確認的逐條列模型讀成什麼、照走的是什麼（最多 20 條，3-3 第 9 題）。"""
    rows, ms = repos.list_reads(conn), sorted(c["latency_ms"] for c in calls if c["kind"] == "read" and c["ok"])
    if not rows:
        return {}
    asked = [r for r in rows if r["sheet"].get("確認")]   # 問的那筆和按了之後那筆同一回合（3-3b），回合數照不重複的算
    return {"n": len({(r["session_id"], r["turn_no"]) for r in rows}), "p50": int(statistics.median(ms)) if ms else 0,
            "failed": sum(1 for c in calls if c["kind"] == "read" and not c["ok"]),
            "asked": len({(r["session_id"], r["turn_no"]) for r in asked}), "stops": sum("問" in r["keyword"] for r in rows),
            "spot": sum(c["kind"] == "spot" for c in calls),   # 3-4b：應該是 0
            "looks": [f"第 {r['turn_no']} 回合「{r['text']}」：{k} {r['sheet'][k]}" for r in rows if "問" not in r["keyword"]
                      for k in ("在查哪一個", "在辦哪件請託") if r["sheet"].get(k, "都不是") != "都不是"],
            "deals": dict(Counter(r["sheet"].get("買賣找人", "都不是") for r in rows if "問" not in r["keyword"])),   # 3-4c
            "stakes": dict(Counter(stake.said(r["text"]) for r in rows if "問" not in r["keyword"]
                                   and {"說服", "套話"} & set(r["sheet"].get("判什麼", "").split("+")))),   # 3-5 收尾乙：字表
            "diff": [f"第 {r['turn_no']} 回合「{r['text']}」：" + "、".join(f"{k}讀成{r['sheet'].get(k, '（沒填）')}" for k in r["sheet"]["確認"])
                     + "；照走：" + "、".join(f"{k} {v}" for k, v in r["keyword"].items() if k != "在") for r in asked][:20],
            "lost": len({(r["session_id"], r["turn_no"], r["text"]) for r in rows if "看不懂" in r["keyword"]})}   # 3-6b


def summarize(conn) -> dict:
    every = repos.list_ai_calls(conn)
    # 讀懂另算（_reads）、檢查長期文字（3-7b）、寫物品傳說怪談事端（第 128 系列：局中補寫看擲骰、物品沒過審核重叫，次數不固定）不算，不影響 127-9 的數字
    calls = [c for c in every if c["kind"] not in ("read", "vet", "forge", "legend", "tale", "plot")]
    turns = {(t["session_id"], t["turn_no"]): t for s in {c["session_id"] for c in calls}
             for t in repos.list_turns(conn, s, limit=1_000_000)}
    ok = [c for c in calls if c["ok"]]
    rolled = [c for c in ok if c["kind"] == "action" and c["outcome"]]
    mismatches = [c for c in rolled if c["tone_check"] == "mismatch"]
    unclear = [c for c in rolled if c["tone_check"] == "unclear"]
    latencies = sorted(c["latency_ms"] for c in ok)
    n = len(calls)

    def sample(c):
        t = turns.get((c["session_id"], c["turn_no"]), {})
        return {"turn": c["turn_no"], "outcome": c["outcome"], "input": t.get("player_input", ""),
                "narrative": t.get("narrative", "")}

    return {
        "calls": n,
        "firstTryRate": sum(1 for c in ok if c["attempts"] == 1) / n if n else 0.0,
        "retriedOk": sum(1 for c in ok if c["attempts"] > 1),
        "failed": n - len(ok),
        "failureRate": (n - len(ok)) / n if n else 0.0,
        "errors": Counter(c["error_message"].split("\n")[0] for c in calls if not c["ok"]).most_common(5),
        "rejectedSamples": [{"turn": c["turn_no"], "detail": c["error_message"]}
                            for c in calls if c["attempts"] > 1 and c["error_message"]][:5],
        "latencyMs": {"p50": int(statistics.median(latencies)) if latencies else 0,
                      "max": latencies[-1] if latencies else 0,
                      "avg": int(statistics.fmean(latencies)) if latencies else 0},
        "rolledTurns": len(rolled),
        "mismatches": len(mismatches),
        "mismatchRate": len(mismatches) / len(rolled) if rolled else 0.0,
        "unclear": len(unclear),
        "ignoredKeys": Counter(k for c in ok for k in c["ignored_keys"]).most_common(10),
        "narrativeLength": {"min": min((c["narrative_len"] for c in ok), default=0),
                            "max": max((c["narrative_len"] for c in ok), default=0)},
        "proposals": _proposal_stats(repos.list_proposal_log(conn)),
        # 敘事與 NPC 年齡的矛盾、未成年者附近出現親密用詞（第 6 步，只觀察）
        "warnings": [f"第 {c['turn_no']} 回合：{w}" for c in ok for w in c["warnings"] if not w.startswith("dropped:")][:20],
        # 超額三關丟掉的（第 2-5 批）：每一筆都列，逐條看有沒有砍到不該砍的
        "dropped": [f"第 {c['turn_no']} 回合：" + "、".join(w[8:] for w in c["warnings"] if w.startswith("dropped:"))
                    for c in calls if any(w.startswith("dropped:") for w in c["warnings"])],
        "reads": _reads(conn, every),
        "mismatchSamples": [sample(c) for c in mismatches[:5]],
        "unclearSamples": [sample(c) for c in unclear[:3]],
        "okSamples": [sample(c) for c in rolled[:3]],
    }


def _proposal_stats(rows: list[dict]) -> dict:
    """提案通道的統計（第 1 步）。只做觀察，不列入通過門檻。"""
    return {
        "total": len(rows),
        "accepted": Counter(r["kind"] for r in rows if r["accepted"]).most_common(),
        "rejected": Counter(r["reason"] for r in rows if not r["accepted"]).most_common(),
        "acceptedNames": [f"{r['kind']}:{r['name']}（第 {r['turn_no']} 回合）" for r in rows if r["accepted"]][:20],
        "copied": [f"第 {r['turn_no']} 回合 {r['kind']}:{r['name']} {r['reason']}" for r in rows if (r["reason"] or "").startswith("copied")],   # 3-7a
    }


def render(m: dict, passed: bool, notes: list[str], narrator, db_path: Path) -> str:
    pct = lambda x: f"{x * 100:.1f}%"  # noqa: E731
    lines = [
        f"# AI 合約檢查報告　{datetime.now():%Y-%m-%d %H:%M}",
        "",
        f"- 說書人：{narrator.name}",
        f"- 結論：**{'通過' if passed else '需要檢查'}**（門檻：首次即合格 ≥ {pct(THRESHOLDS['first_try_rate'])}、"
        f"最終失敗 ≤ {pct(THRESHOLDS['failure_rate'])}、語氣相反 ≤ {pct(THRESHOLDS['mismatch_rate'])}）",
        f"- 實際完成回合：{m['turnsPlayed']}；AI 呼叫：{m['calls']} 次",
        f"- 資料庫（可直接翻閱每回合內容）：{db_path.name}",
        "",
        "## 合約遵守",
        f"- 首次呼叫即合格：{pct(m['firstTryRate'])}",
        f"- 重試後合格：{m['retriedOk']} 次",
        f"- 最終失敗：{m['failed']} 次（{pct(m['failureRate'])}）",
    ]
    lines += [f"  - {count} 次：{msg}" for msg, count in m["errors"]]
    if m["ignoredKeys"]:
        lines.append("- AI 多寫、已被丟棄的欄位：" + "、".join(f"{k}（{c}）" for k, c in m["ignoredKeys"]))
    lines += [
        "",
        "## 敘事與判定是否一致",
        f"- 有擲骰的回合：{m['rolledTurns']}；語氣與判定相反：{m['mismatches']}（{pct(m['mismatchRate'])}）；"
        f"看不出語氣：{m['unclear']}",
        "- 語氣檢查只比對收尾用詞，「看不出語氣」不代表有錯；「相反」則值得逐條確認。",
        "",
        "## 速度",
        f"- 中位數 {m['latencyMs']['p50']} ms，平均 {m['latencyMs']['avg']} ms，最慢 {m['latencyMs']['max']} ms",
        f"- 敘事長度：{m['narrativeLength']['min']}～{m['narrativeLength']['max']} 字",
        "",
    ]
    if p := m.get("prompt"):
        lines += ["## 提示詞長度（127-9；token 是模型回報、含快取接上的部分）",
                  f"- 敘事 {p['n']} 次：字數中位數 {p['charsP50']:,}、最長 {p['charsMax']:,}；"
                  f"token 中位數 {p['tokensP50']:,}、最長 {p['tokensMax']:,}；token ÷ 字數 {p['ratio']}", ""]
    if r := m.get("reads"):
        lines += [f"## 讀懂（3-3b，{r['n']} 回合；停下來問的按保守值那顆，其餘跳確認的欄照保守值走）",
                  f"- 跳確認：{r['asked']} 回合（其中停下來問 {r.get('stops', 0)} 次）；讀懂失敗：{r['failed']} 次；速度中位數 {r['p50']} ms",
                  f"- 看不懂（3-6b，「你一時拿不定主意」）：{r.get('lost', 0)} 次",
                  *[f"- {d}" for d in r["diff"]],
                  f"- 查破綻、辦請託（3-4b）：spot 呼叫 {r.get('spot', 0)} 次；讀懂挑中 {len(r.get('looks', []))} 次",
                  *[f"  - {d}" for d in r.get("looks", [])],
                  "- 買賣找人（3-4c）：" + "、".join(f"{k} {r.get('deals', {}).get(k, 0)} 次" for k in ("買", "賣", "找人", "付錢")),
                  "- 要的有多大（3-5，說服、套話回合查字表；物品、錢另估）：" + "、".join(f"{k} {r.get('stakes', {}).get(k, 0)} 次" for k in ("小", "大", "救命")), ""]
    lines += [f"## 超額砍掉的（第 2-5 批，{len(m['dropped'])} 次）", *([f"- {d}" for d in m["dropped"]] or ["- 無"]), ""]
    lines += [
        "## 提案通道（新地點／新人物，不列入門檻）",
        f"- 提案總數：{m['proposals']['total']}",
        "- 採用：" + ("、".join(f"{k}（{c}）" for k, c in m["proposals"]["accepted"]) or "無"),
        "- 拒絕原因：" + ("、".join(f"{k}（{c}）" for k, c in m["proposals"]["rejected"]) or "無"),
        *[f"  - {name}" for name in m["proposals"]["acceptedNames"]],
        f"- 抄台詞丟掉的欄（3-7a，copied＝整筆退、copied_欄名＝只丟那欄）：{len(m['proposals'].get('copied', []))} 筆",
        *[f"  - {x}" for x in m["proposals"].get("copied", [])],
    ]
    lines += ["", "## 警告（年齡矛盾、未成年親密用詞、提示詞超過預算 prompt_over_budget，不列入門檻）",
              *([f"- {w}" for w in m["warnings"]] or ["- 無"])]
    if m["rejectedSamples"]:
        lines += ["", "## 被拒絕的原始輸出（抽樣）"]
        for s in m["rejectedSamples"]:
            lines += [f"### 第 {s['turn']} 回合", "", "```", s["detail"], "```", ""]
    for title, key in (("語氣相反的回合", "mismatchSamples"), ("看不出語氣的回合（抽樣）", "unclearSamples"),
                       ("一般回合（抽樣）", "okSamples")):
        if m[key]:
            lines += ["", f"## {title}"]
            for s in m[key]:
                lines += [f"### 第 {s['turn']} 回合：{s['input']}（判定：{s['outcome']}）", "", s["narrative"], ""]
    if notes:
        lines += ["", "## 備註"] + [f"- {n}" for n in notes]
    return "\n".join(lines) + "\n"
