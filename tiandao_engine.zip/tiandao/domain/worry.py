"""心事（第 84 題重定、第 9-1～9-9 題；第 9e-1、9e-2 批，progress/人物卡草稿.md）。純函式。

- 從他身上現成的狀態挑一件（game/talks.worries 收集，每件寫成 Worry）：救命 > 大 > 小，同檔取最近的（9-2、9-3）。
  跟你有關的（怕你、欠你、你握他把柄）是他對你的態度，不算。收過黑錢（126-7 還沒做）、命事先不算。
- 什麼都沒有才從小表抽一條（rules/content/worries.txt，9-6、9-7）：條件看目的、職業、修行那一組；抽到記一筆「心事」帳
  （society.WORRY，body 存那句、舉止、輕重、擲到的隱情），條目是債、怕、記過、傳開的另外寫進那個狀態（game/talks.draw）。
  一年內了結過心事的不抽（9-9）。
- 可信才說，口風緊要心腹、鬆的未定就說（9-4）；還沒說之前只露一個舉止，給說書人寫他現在的樣子。
- 說出口時開口求你（9-5、9e-3）：照心事接的支線擲一種，sides.txt「心事:」那組；辦成了結那件狀態，他照輕重欠你人情（game/sides.py）。
"""
from __future__ import annotations

import random
from typing import NamedTuple

from ..config import PROJECT_ROOT
from . import deck, npc

SAVE, BIG, SMALL = "救命", "大", "小"
TIERS = (SAVE, BIG, SMALL)
KINDS = {   # 現成狀態的種類 → （輕重, 說出口那句, 舉止, 接的支線）；{對}＝對象或親人的稱呼；支線是 sides.txt「心事:」那組，空的只說不求
    "血仇": (SAVE, "我跟{對}有血海深仇，這事沒完", "提到{對}就握緊拳頭", ("血債",)),
    "追查兇手": (SAVE, "我家裡人死得不明不白，我一定要查出是誰下的手", "常一個人發呆，眼神發狠", ("兇手", "血債")),
    "家人殞落": (SAVE, "我{對}前些日子走了，到現在還緩不過來", "說著說著就沒了聲音", ("上墳",)),
    "家人重傷": (SAVE, "我{對}傷得很重，躺著起不來，藥錢快撐不住了", "身上總有一股藥味", ("求藥",)),
    "家人關押": (SAVE, "我{對}被關在牢裡，不知道什麼時候放出來", "常往衙門的方向張望", ("救人",)),
    "債": (BIG, "我還欠{對}一筆錢，一直還不上", "算帳算到一半就停下來發呆", ("還債",)),
    "受託": (BIG, "我答應了人要對付{對}，到現在還沒辦成", "說話時總留半句", ("趕走", "說和")),
    "記過": (BIG, "我在{對}記了一過，在門裡抬不起頭", "同門走過時，把頭低下去", ("說和", "清白")),
    "怕": (BIG, "{對}一直找我麻煩，我躲都躲不掉", "有人進門就先往門口看", ("趕走", "說和")),
    "壞傳聞": (BIG, "外頭都在傳我{對}，我有口難辯", "聽人說閒話就沉下臉", ("清白",)),
    "家人遠方": (SMALL, "我{對}去了遠方，好久沒有消息", "有外地人來，就湊上去問是從哪裡來的", ("找人", "帶東西")),
    "家人負傷": (SMALL, "我{對}受了點傷，這陣子家裡的活都落在我身上", "做事總是匆匆忙忙", ("求藥",)),
    "殘夢": (SMALL, "我常夢到一個沒去過的地方，夢裡的人我都叫得出名字", "說到一半會突然愣住，像想起什麼", ()),
}
KIN = {"弟": "我弟弟", "兒子": "我兒子", "師父": "我師父", "娘": "我娘", "爹": "我爹"}   # 小表的親人在支線句子裡怎麼稱呼
OPEN_AT = {"高": 60, "中": 20, "低": -9}   # 他對你的信任到這裡才說（照口風）
TABLE = deck.read(PROJECT_ROOT / "rules" / "content" / "worries.txt")
STATES = ("債", "怕", "記過", "傳開", "心事")   # 小表結果欄的第一段
DEAD = "死"


class Worry(NamedTuple):
    """sides：開口求你時擲一種；who：對象（人名或字）；call：支線句子裡的{對象}；hidden：隱情；
    ids：辦成要了結的帳；fear：辦成要抵掉怕的人（9e-3）。"""
    tier: str
    at: int
    said: str
    manner: str
    sides: tuple = ()
    who: str = ""
    call: str = ""
    hidden: str = ""
    ids: tuple = ()
    fear: str = ""


def of(kind: str, who: str, at: int, *, call: str = "", name: str = "", ids: tuple = (), fear: str = "") -> Worry:
    """who：說出口那句的稱呼；name：真的對象（沒給就是 who）；call：支線句子裡的稱呼（沒給就是 who）。"""
    tier, said, manner, sides = KINDS[kind]
    return Worry(tier, at, said.format(對=who), manner.format(對=who), sides, name or who, call or who, "", ids, fear)


def sides(c: deck.Card) -> tuple[str, ...]:
    return tuple(c.more[2].split("、")) if len(c.more) > 2 and c.more[2] else ()


def pick(found: list[Worry]) -> Worry | None:
    """最重的一件；同檔取最近的。"""
    return min(found, key=lambda w: (TIERS.index(w.tier), -w.at), default=None)


def opens(p: dict, trust: int) -> bool:
    return trust >= OPEN_AT[npc.trait_level(p.get("discretion", 50))]


def result(c: deck.Card) -> dict:
    """小表結果欄 → {狀態, 輕重, 對象, 親, 死}。"""
    state, tier, *rest = c.result.split()
    return {"狀態": state, "輕重": tier, **dict(r.split(":", 1) for r in rest if ":" in r), "死": DEAD in rest}


def draw(rng: random.Random, facts: dict, ok) -> tuple[deck.Card, str] | None:
    """抽一條對得上的（ok(牌) 判斷對象、親人湊不湊得到）；回傳（牌, 擲到的隱情，空＝沒有）。"""
    pool = [c for c in TABLE if deck.fits(c, facts) and ok(c)]
    if not pool:
        return None
    c = rng.choice(pool)
    return c, rng.choice(c.more[1].split("／")) if len(c.more) > 1 else ""


for _c in TABLE:
    assert result(_c)["狀態"] in STATES and result(_c)["輕重"] in TIERS, _c
