"""人情帳（WHITEPAPER 16v 第 87、106～113 題；草稿 progress/人情帳草稿.md）。純函式，換得到的事在 rules/content/favours.txt。

- 一筆：way 欠你／你欠、kind 恩／債、level 小／大／救命（債沒有）、why 一句原因、since 記下的時刻、
  amount、due（債的數目、期限）、refused（他上門你推掉幾次）。
- 存在帳上（ledger，第 1-4a 批）：一筆一列，甲＝被欠的那方、主角那方寫那一生（row、back）；讀關係時組回
  relation["favours"]。換一世不帶走（第 100 題）。每人每個方向最多 3 筆，滿了新的取代最輕的。
- 輕重：表上的分量；牽涉他的生死直接算救命；你付出了（受傷、花錢）升一級，最高救命。
- 討：他在場又欠你恩，畫面列出這一級以下換得到的事；選一件不判定，用掉夠分量的最輕那筆。
- 三套規矩（第 120-2 題，實作第 1-4b 批；誰算哪套看 society.circle）：自家人不記帳，開口看好感（close），
  每開口一次記「又來麻煩」；熟人記恩，還了雙方多一筆「有來有往」；外人記債，賴掉債不銷（WELSHED），債主上門討。
"""
from __future__ import annotations

from dataclasses import dataclass

from ..config import PROJECT_ROOT
from . import society
from .clock import SHICHEN_PER_MONTH

OWED, OWE = "欠你", "你欠"
GRACE, DEBT = KINDS = society.OWE, society.DEBT
SMALL, BIG, LIFE = "小", "大", "救命"
LEVELS = (SMALL, BIG, LIFE)
NAMES = {SMALL: "小恩", BIG: "大恩", LIFE: "救命之恩"}
MAX = 3
TOKEN = "人情:"           # 表上寫的來源：人情:小、人情:大、人情:救命
ORIGIN, REPAY = "人情", "還情"   # 他上門請你還恩：支線的來源、辦成時用掉你欠他的那筆
BORROW, REPAID = "借你", "還了"  # 模型提案：他借你錢、他答應還你人情
GAP = 6 * SHICHEN_PER_MONTH      # 你欠他的恩：隔半年他才會再上門
SPAN, GRACE_MONTH = 12 * SHICHEN_PER_MONTH, SHICHEN_PER_MONTH   # 債的期限一年；寬限一個月
WELSHED = 2                      # refused：賴掉的債，債主上門討（第 120-2 題）
NEAR, FRIEND = 60, 20            # 自家人：親近求得到大事、友善求得到小事（npc.AFFINITY_TIERS）


@dataclass(frozen=True)
class Ask:
    level: str
    key: str     # 錢、路、擋、伴：game/favours.py 照這個辦
    text: str    # 選項：{人}
    fact: str    # 辦成的句子：{人}、{地}、{仇}


_ROWS = [line.split("｜") for line in (PROJECT_ROOT / "rules" / "content" / "favours.txt").read_text(encoding="utf-8").splitlines()]
ASKS = tuple(Ask(*r[1:5]) for r in _ROWS if r[0] == "換")
LINES = {r[1]: r[2] for r in _ROWS if r[0] == "句"}
PAY, WAIT = Ask("", "還錢", LINES["還錢"], "你還清了欠{人}的{數}"), Ask("", "寬限", LINES["寬限"], LINES["等等"])   # 債到期：還錢、再寬限


def make(way: str, level: str, why: str, now: int, seen: int = 0) -> dict:
    """gen：傳了幾代（本人 0，第 1-4c 批）。seen：受恩時有別人在場，賴掉才傳開（第 1-5d 批）。
    event：封口費綁著的那件事（events 表 id，存在帳的 event_id）。"""
    return {"way": way, "kind": GRACE, "level": level, "why": why[:40], "since": now, "amount": 0, "due": None, "refused": 0, "gen": 0,
            "seen": seen, "event": ""}


def debt(amount: int, why: str, now: int) -> dict:
    """他借你錢：你欠他一筆債，一年內還。"""
    return {**make(OWE, "", why, now), "kind": DEBT, "amount": amount, "due": now + SPAN}


def hush(amount: int, why: str, event: str, now: int) -> dict:
    """封口費（第 1-5d 批）：他拿你的把柄要錢，當場到期；照債的規矩寬限，賴掉他就揭穿。"""
    return {**debt(amount, why, now), "due": now, "event": event}


def lend(realm_lv: int, months: int = 3) -> int:
    """借得到（或小恩換得到）多少：幾個月的工錢 × 2 的境界次方（營生的工錢）。"""
    from .effects import WORK_WAGE   # effects 會間接載入 evolution，evolution 又用到這裡，放上面會循環
    return WORK_WAGE * 2 ** realm_lv * months


def weigh(base: str, *, dying: bool = False, paid: bool = False) -> str:
    return LIFE if dying else LEVELS[min(len(LEVELS) - 1, LEVELS.index(base) + paid)]


def _rank(f: dict) -> int:
    return LEVELS.index(f["level"]) if f["kind"] == GRACE else len(LEVELS)   # 債不會被擠掉


def add(favours: list[dict], f: dict) -> list[dict]:
    """記一筆。這個方向滿了，新的取代最輕的；新的比手上的都輕就不記。"""
    mine = [x for x in favours if x["way"] == f["way"]]
    if len(mine) < MAX:
        return [*favours, f]
    low = min(mine, key=_rank)
    return favours if _rank(low) > _rank(f) else [*(x for x in favours if x is not low), f]


def graces(favours: list[dict], way: str = OWED) -> list[dict]:
    return [f for f in favours if f["way"] == way and f["kind"] == GRACE]


def top(favours: list[dict], way: str = OWED) -> str:
    """這個方向最重的恩；沒有是空字串。"""
    return max((f["level"] for f in graces(favours, way)), key=LEVELS.index, default="")


def asks(favours: list[dict]) -> list[Ask]:
    """他欠你的恩換得到的事：最重那一級以下的都可以。"""
    return upto(top(favours))


def upto(level: str) -> list[Ask]:
    return [a for a in ASKS if level and LEVELS.index(a.level) <= LEVELS.index(level)]


def close(affinity: int) -> str:
    """自家人求得到哪一級的事。"""
    return BIG if affinity >= NEAR else SMALL if affinity >= FRIEND else ""


def use(favours: list[dict], level: str, way: str = OWED) -> list[dict]:
    """用掉夠分量的最輕那筆。"""
    fit = [f for f in graces(favours, way) if LEVELS.index(f["level"]) >= LEVELS.index(level)]
    pick = min(fit, key=_rank, default=None)
    return [f for f in favours if f is not pick]


def due(favours: list[dict], now: int) -> list[dict]:
    """到期的債。"""
    return [f for f in favours if f["kind"] == DEBT and f["due"] <= now]


def lower(f: dict, why: str) -> dict | None:
    """傳給家人或徒弟（第 108、125-2、126-2 題）：恩每代降一級、小恩銷掉；債第一代照原樣（父債子還）、
    第二代減半、再往下銷掉。銷掉回傳 None。"""
    f = {**f, "why": why[:40], "gen": f["gen"] + 1}
    if f["kind"] == DEBT:
        return f if f["gen"] == 1 else {**f, "amount": max(1, f["amount"] // 2)} if f["gen"] == 2 else None
    return {**f, "level": LEVELS[LEVELS.index(f["level"]) - 1]} if f["level"] != SMALL else None


def what(f: dict) -> str:
    return NAMES[f["level"]] if f["kind"] == GRACE else f"債{f['amount']}"


def label(favours: list[dict]) -> str:
    """在場人物那一行：「欠你：大恩」「你欠：債150」，各方向只標最重的一筆。"""
    return "・".join(f"{way}：{what(max(fs, key=_rank))}" for way in (OWED, OWE) if (fs := [f for f in favours if f["way"] == way]))


def notes(favours: list[dict]) -> list[str]:
    """點名字展開的原因。"""
    return [f"{f['way']}{what(f)}：{f['why']}" for f in favours]


def prompt(favours: list[dict]) -> str:
    """給說書人：眼前的人和你的人情。"""
    owed = [f"欠你一份{what(f)}（{f['why']}）" for f in favours if f["way"] == OWED]
    owe = [f"你欠他一份{what(f)}（{f['why']}）" for f in favours if f["way"] == OWE]
    return "，".join(owed + owe)


def row(f: dict, name: str, life: str) -> dict:
    """存成帳上的一列：甲＝被欠的那方；輕重、原因、數目、推掉幾次放 body。"""
    a, b = (life, name) if f["way"] == OWED else (name, life)
    return {**society.owed(f["kind"], a, b, f["since"]), "session_id": life, "deadline_shichen": f["due"],
            "event_id": f["event"], "body": {k: f[k] for k in ("level", "why", "amount", "refused", "gen", "seen")}}


def back(r: dict) -> dict:
    """帳上的一列 → 一筆人情（第 1-4c 批之前沒有 gen，算本人）。"""
    return {"gen": 0, "seen": 0, **r["body"], "way": OWED if r["a"] == r["session_id"] else OWE, "kind": r["kind"],
            "since": r["clock_shichen"], "due": r["deadline_shichen"], "event": r.get("event_id") or ""}


def valid(favours) -> bool:
    keys = {"way", "kind", "level", "why", "since", "amount", "due", "refused", "gen", "seen", "event"}
    return isinstance(favours, list) and all(
        isinstance(f, dict) and set(f) == keys and f["way"] in (OWED, OWE) and f["kind"] in (GRACE, DEBT)
        and (f["level"] in LEVELS if f["kind"] == GRACE else f["level"] == "" and isinstance(f["due"], int) and f["amount"] > 0)
        and isinstance(f["why"], str) and isinstance(f["since"], int) and f["gen"] in (0, 1, 2) and f["seen"] in (0, 1)
        and isinstance(f["event"], str) and (f["kind"] == DEBT or not f["event"])
        and f["refused"] in ((0, 1, WELSHED) if f["kind"] == DEBT else (0, 1)) for f in favours)
