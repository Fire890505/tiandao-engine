"""靈感素材（第 10a 步）：舊專案 core.py 的外觀與性格清單（progress/WORLD_MATERIALS.md 第 7 節）。

舊版用這些清單「抽籤組合」出人物，抽定就不會變，人物像拼貼。新版只拿來當**靈感**：
Python 隨機抽兩三個交給 AI 參考，避免人人相似；AI 不受限制，寫出來的才是那個人。
"""
from __future__ import annotations

import random

APPEARANCE = {
    "髮色": ("黑", "墨黑", "烏黑", "深棕", "栗棕", "赤紅", "緋紅", "金黃", "銀白", "雪白", "灰白", "青藍", "暗紫"),
    "髮型": ("及肩散髮", "及腰長髮", "極短的寸頭", "剃度光頭", "高馬尾", "雙丫髻", "披散不束", "編辮盤起", "簪成道髻",
             "凌亂不羈"),
    "眼": ("丹鳳眼", "桃花眼", "狹長眼", "圓潤大眼", "瞇眼常帶笑意"),
    "氣質": ("清冷孤傲", "溫和儒雅", "陰鷙深沉", "英氣逼人", "嬌媚妖異", "滄桑歷練"),
    "身形": ("修長清瘦", "精悍結實", "魁梧壯碩", "纖細嬌小", "豐腴圓潤", "矮小", "高䠷", "極其高大"),
    "衣著": ("儒衫", "道袍", "勁裝", "華服", "錦袍", "粗布麻衣", "法袍", "獵戶皮襖", "殘破舊衣"),
}
NOT_FOR = {"男": ("雙丫髻", "嬌媚妖異", "纖細嬌小"), "女": ("極短的寸頭", "剃度光頭", "魁梧壯碩")}   # 這個性別不抽；不明都抽
MINOR_SKIP = ("嬌媚妖異", "豐腴圓潤")   # 未成年不抽（底線）
PERSONALITY = {
    "核心": ("沉靜", "衝動", "謹慎", "桀驁", "冷漠", "溫厚", "多疑", "義氣", "記仇", "護短", "固執", "灑脫", "孤僻",
             "外熱內冷", "看破不說破", "慣於隱忍"),
    "次要": ("重承諾", "話少", "愛算計", "表裡不一", "記恩", "不輕易信任外人", "對弱者有惻隱", "對強者不卑",
             "有仇必報", "有恩必償", "不解釋", "慣用反問", "極少道歉"),
    "怪癖": ("從不主動提及身世", "說話前習慣先看對方的手", "對水質很敏感", "夜裡睡得很淺", "不喜歡被人從背後靠近",
             "用錢謹慎但花在別人身上不手軟", "去過一次的地方不會忘", "說謊時眼神反而更穩", "對動物比對人更放鬆",
             "聽到某種聲音會停下來，但從不解釋"),
}


def skipped(gender: str = "", minor: bool = True) -> tuple:
    """不抽的素材：不合性別的；不確定成年就當未成年。"""
    return NOT_FOR.get(gender, ()) + (MINOR_SKIP if minor else ())


def draw(rng: random.Random, *, appearance: int = 2, personality: int = 1, gender: str = "", minor: bool = True) -> list[str]:
    """從不同維度各抽一個，回傳「維度：值」的字串（給 AI 看的靈感，不是規定）。"""
    picks, skip = [], skipped(gender, minor)
    for pool, count in ((APPEARANCE, appearance), (PERSONALITY, personality)):
        for dim in rng.sample(sorted(pool), min(count, len(pool))):
            picks.append(f"{dim}：{rng.choice([v for v in pool[dim] if v not in skip])}")
    return picks
