"""NPC 的純規則（第 6 步）。純函式，不碰資料庫。

規則（2026-10-04 與使用者討論定案，見 progress/HANDOFF.md 第 6 步）：
- 年齡：AI 登錄時只選年齡層，Python 決定確切歲數並隨世界時間增長；成年與否直接由實際歲數算出（18 歲）。
  取代舊專案 minor_safety 的敘事關鍵字判定與鎖定狀態（稽核 B-13、B-14 一併消失）。
  底線不變：未成年角色不可出現戀愛、性或親密內容。
- 實力：AI 選實力層級，Python 換算成境界並依地點規模設上限；「深不可測」不告訴玩家境界。
- 固定不變：名字、種族、出生；只有 Python 能改：境界、生死、所在地、好感與信任；AI 可提案更新：外貌、身分個性、說話風格。
- 描述記錄「寫於幾歲」，時間差 10 年以上時要求 AI 更新。死亡不可逆。
- 關係：好感、信任（−100～100，由原因加起來，domain/opinion.py）、記仇；判定造成的變化由 Python 算，判定以外的互動由 AI 提案方向。
- 對 NPC 動手：狀態階梯 無恙 → 負傷 → 重傷 → 殞落，命中成功一階、大成功兩階。
"""
from __future__ import annotations

import random

from . import opinion, races, realm, society
from .clock import SHICHEN_PER_YEAR

ADULT_AGE = 18
GENDERS = ("男", "女")     # 16u 第 3 題；舊世界的人是空字串，退隱的主角可能是「不明」
CHILD, TEEN, YOUNG, PRIME, ELDER = "孩童", "少年", "青年", "壯年", "老年"
AGE_BANDS = (CHILD, TEEN, YOUNG, PRIME, ELDER)
_FIXED_AGES = {CHILD: (6, 12), TEEN: (13, 17)}                       # 未成年一律用實際歲數
_LIFESPAN_SHARE = {YOUNG: (None, 0.30), PRIME: (0.30, 0.60), ELDER: (0.60, 0.95)}   # 成年依壽元比例
MINOR_MAX_LV = 1
UNLIMITED_LIFESPAN_YEARS = 10000      # 不受壽元限制的境界，年齡層換算用的參考壽元

MORTAL, NOVICE, ADEPT, POWERFUL, UNFATHOMABLE = "凡人", "初入修行", "小有修為", "一方強者", "深不可測"
POWER_TIERS = {MORTAL: 0, NOVICE: 1, ADEPT: 2, POWERFUL: 3, UNFATHOMABLE: None}   # None＝當地上限
SCALE_CAP = {"家": 2, "村落": 2, "鄉鎮": 3, "城市": 4, "國家": 5}
DEFAULT_CAP = 2

CONDITIONS = ("無恙", "負傷", "重傷", "殞落")
STALE_YEARS = 10

# ── 目標與性格（第 10a 步）：機制層，Python 用；玩家看不到數字 ─────────────────
GOALS = ("求道", "守護", "逐利", "求名", "復仇", "報恩", "追隨", "隱居", "尋物")
ASCENDED = "飛升"   # 16l：破空去了仙域（不在 GOALS 裡：說書人提案不能用；人在遠方、背景演化不再動他）
GOALS_WITH_TARGET = ("守護", "復仇", "報恩", "追隨", "尋物")   # 這些目標可以指名對象（某人、某地、某物）
TRAITS = ("ambition", "kindness", "courage", "suspicion")
TRAIT_LABELS = {"ambition": "野心", "kindness": "善念", "courage": "膽識", "suspicion": "疑心"}
# 氣量、口風（第 7-1b 批）：同樣存 0～100、讀低中高；不給模型提，登錄時 Python 擲（repos.insert_npc）
TEMPERS = ("tolerance", "discretion")
TEMPER_LABELS = {"tolerance": "氣量", "discretion": "口風"}
TRAIT_LEVELS = {"低": 20, "中": 50, "高": 80}               # AI 從低中高選，Python 存 0–100（之後隨經歷移動）
TRAIT_RANGE = (0, 100)
_DEFAULT_GOALS = ("求道", "求道", "逐利", "求名", "守護", "隱居")   # 補給舊 NPC 的目標（沒有對象的為主）
HEAVEN_ROLES = ("", "宿敵", "貴人", "餌", "棋子")             # 天道角色（玩家與說書人都看不到；宿敵由第 18-2b 步指派）
NEW_ERA = "換時代"   # 換時代時在世上、或脫節的人適應了：照新時代重寫（第 8-3 批）
REWRITE_REASONS = ("", "重傷", "境界提升", "性情轉變", NEW_ERA)   # 描述要改寫的原因（年紀造成的另由 stale() 判斷）


def trait_level(value: int) -> str:
    return "低" if value < 35 else ("中" if value < 65 else "高")


def roll_traits(rng: random.Random) -> dict:
    """第 10a 步之前登錄的 NPC 沒有目標與性格：用固定種子補上。"""
    return {"goal": rng.choice(_DEFAULT_GOALS), "goal_target": "",
            **{t: TRAIT_LEVELS[rng.choice(tuple(TRAIT_LEVELS))] for t in TRAITS}}


def roll_tempers(rng: random.Random) -> dict:
    return {t: TRAIT_LEVELS[rng.choice(tuple(TRAIT_LEVELS))] for t in TEMPERS}


def traits_text(p: dict) -> str:
    """給說書人的性情：「野心高、善念中、膽識低、疑心中」。"""
    return "、".join(f"{TRAIT_LABELS[t]}{trait_level(p[t])}" for t in TRAITS)

# ── 關係：好感、信任由一筆一筆原因加起來（domain/opinion.py，第 1-2 批）──────────
AFFINITY_RANGE = TRUST_RANGE = (-100, 100)
GRUDGE_BELOW = -50
AFFINITY_TIERS = ((60, "親近"), (20, "友善"), (-9, "中立"), (-49, "冷淡"), (-100, "敵視"))
TRUST_TIERS = opinion.TRUST_TIERS
# 沿用舊版 d100_system；16l 第 6-2 題放寬到低 5 級（−95 ＝ 成功率夾到 5%：沒有破境道具不可能）
REALM_DIFF_MOD = {3: 25, 2: 15, 1: 8, 0: 0, -1: -10, -2: -22, -3: -35, -4: -50, -5: -95}


def lifespan_years(realm_lv: int, race: str = races.HUMAN) -> int:
    base = realm.TIERS[realm_lv].lifespan
    return round(base * races.LIFESPAN.get(race, 1)) if base else UNLIMITED_LIFESPAN_YEARS   # 16k：他族壽元倍數


def realm_cap(location_scale: str) -> int:
    return SCALE_CAP.get(location_scale, DEFAULT_CAP)


def roll_profile(rng: random.Random, age_band: str, power_tier: str, location_scale: str, clock_now: int) -> dict:
    """依年齡層與實力層級決定境界與出生時間。境界不超過地點上限，孩童與少年最高 Lv1。"""
    cap = realm_cap(location_scale)
    lv = POWER_TIERS[power_tier]
    lv = cap if lv is None else min(lv, cap)
    if age_band in _FIXED_AGES:
        lv = min(lv, MINOR_MAX_LV)
        age = rng.randint(*_FIXED_AGES[age_band])
    else:
        span = lifespan_years(lv)
        low, high = _LIFESPAN_SHARE[age_band]
        low_age = ADULT_AGE if low is None else max(ADULT_AGE, round(span * low))
        age = rng.randint(low_age, max(low_age, round(span * high)))
    stage = rng.randint(0, realm.last_stage(lv))
    return {"birth_shichen": clock_now - age * SHICHEN_PER_YEAR, "realm_lv": lv, "stage_index": stage,
            "hidden_power": power_tier == UNFATHOMABLE,
            # 第 10b 步：小境界內的修為、從登場這一刻開始背景演算
            "cultivation": rng.randint(0, 80), "evolved_shichen": clock_now}


def age(npc: dict, clock_now: int) -> int | None:
    """實際歲數；第 6 步之前登錄的 NPC 沒有出生時間，回傳 None（視為年齡不詳，按未成年保護）。"""
    if npc.get("birth_shichen") is None:
        return None
    return (clock_now - npc["birth_shichen"]) // SHICHEN_PER_YEAR


def is_minor(npc: dict, clock_now: int) -> bool:
    years = age(npc, clock_now)
    return years is None or years < ADULT_AGE


def stale(npc: dict, field_age_key: str, clock_now: int) -> bool:
    years, written = age(npc, clock_now), npc.get(field_age_key)
    return years is not None and written is not None and years - written >= STALE_YEARS


def harm(condition: str, steps: int) -> str:
    index = min(len(CONDITIONS) - 1, CONDITIONS.index(condition) + steps)
    return CONDITIONS[index]


def tier(value: int, tiers: tuple) -> str:
    return next(label for floor, label in tiers if value >= floor)


def clamp(value: int, bounds: tuple[int, int]) -> int:
    return max(bounds[0], min(bounds[1], value))


def realm_diff_modifier(player_lv: int, npc_lv: int, prep: int = 0, breaker: bool = False) -> int:
    """prep：偷襲、佈局、破境道具各算一項，每一項境界差少算一級（16l 第 6-2 題）。低 5 級以上沒有破境道具不打折。"""
    diff = max(-5, min(3, player_lv - npc_lv))
    if diff < 0 and (diff > -5 or breaker):
        diff = min(0, diff + prep)
    return REALM_DIFF_MOD[diff]


def affinity_modifier(affinity: int) -> int:
    return max(-20, min(20, int(affinity / 5)))


def new_relation(years: int | None = None, now: int = 0, wary: bool = False) -> dict:
    """還沒有原因的關係。had／adds／years／now／wary 見 domain/opinion.py；favours：人情帳（domain/favour.py）；
    turn_change：這回合模型提過幾筆（每人每回合最多一筆，第 120-6 題）；met：見過面（只聽說過你的是 0，第 1-5e 批）。"""
    return {"affinity": 0, "trust": 0, "fear": 0, "grudge": "", "favours": [], "turn_change": 0, "met": 1,
            "had": [], "adds": [], "years": years, "now": now, "wary": wary, "base": 0, "circle": society.STRANGER}


def relation_for(p: dict | None, now: int) -> dict:
    """還沒有原因的關係：壽元、疑心照這個人（找不到人就不淡、不多疑）。"""
    years = opinion.lifespan(p.get("realm_lv", 0), p.get("race", races.HUMAN)) if p else None
    return {**new_relation(years, now, bool(p) and trait_level(p.get("suspicion", 50)) == "高"),
            "grace": opinion.GRACE[trait_level(p.get("tolerance", 50))] if p else 1}   # 氣量（第 7-1b 批）


def scored(stored: list[dict], reasons: list[dict], npcs: list[dict], now: int,
           bonds: list[dict] = (), factions: list[dict] = (), fond: dict[str, float] = {}) -> list[dict]:
    """存著的關係（每一生各一筆）加上原因算出的好感、信任（不存數字，第 1-2、1-3 批）。
    fond：哪一生的關係好事留得久幾倍（纏絲，第 6-5d 批）。
    bonds 要含主角的關係（家人、宗門），好感加上關係種類的固定加減（society.bonus，第 1-3b 批）；
    circle：自家人、熟人、外人（society.circle，第 1-4b 批）。"""
    by, had, plus = {p["name"]: p for p in npcs}, {}, society.bonus(bonds, factions)
    for r in reasons:
        if r["toward"] == opinion.ME:
            had.setdefault((r["holder"], r["session_id"]), []).append(r)
    out = []
    for r in stored:
        mine = had.get((r["npc_name"], r["session_id"]), [])
        owed = any(f["kind"] == society.OWE for f in r.get("favours", []))
        rel = {**relation_for(by.get(r["npc_name"]), now), **r, "had": mine, "base": plus(r["npc_name"], r["session_id"]),
               "fond": fond.get(r["session_id"], 1), "circle":society.circle(r["session_id"], r["npc_name"], bonds, mine, owed)}
        out.append({**rel, **opinion.score(rel)})
    return out


# 第 1-2 批對照表（數字暫定）
HURT, KILL = (opinion.hit(opinion.ATTACK, opinion.LIKE, s, -1) for s in (opinion.BIG, opinion.GRAVE))   # 動手；重傷、打死算重
BOTCHED = opinion.hit(opinion.INSULT, opinion.LIKE, opinion.SMALL, -1)   # 說服、套話大失敗
RELATION_CHANGES = {"小幅好轉": opinion.HELP, "明顯好轉": opinion.HELP, "小幅惡化": opinion.INSULT, "明顯惡化": opinion.INSULT}
BROKEN_PROMISE = [opinion.hit(opinion.BREAK, opinion.TRUST, opinion.BIG, -1)]   # 失約（第 17 步）
RESCUED = [opinion.hit(opinion.SAVE, opinion.LIKE, opinion.GRAVE)]              # 救出照錯玩法做了儀式的人
CAUGHT = [opinion.hit(opinion.ROB, opinion.LIKE, opinion.SMALL, -1)]            # 當場抓到主角對他犯小罪
CAUGHT_PUBLIC = [opinion.hit(opinion.ROB, opinion.LIKE, opinion.BIG, -1)]       # 旁邊還有別人：當眾的壞事升一級

# 怕（第 121-10 題，實作第 1-5c 批，數字暫定）：原因加起來＋境界差，跟膽識比
GAP_FEAR, AWE_OVER = 20, 30                  # 你每高他一個大境界 +20（當場算不存）；比膽識高 30 以上畏懼
WARY, AWED = "忌憚", "畏懼"
THREAT_WORDS = ("威脅", "恐嚇", "嚇唬", "威嚇", "警告")
THREATENED = [opinion.hit(opinion.THREAT, opinion.FEAR, opinion.SMALL), opinion.hit(opinion.INSULT, opinion.LIKE, opinion.SMALL, -1)]
STRUCK = opinion.hit(opinion.ATTACK, opinion.FEAR, opinion.BIG)        # 對他動手
SCARED = opinion.hit(opinion.BLOODY, opinion.FEAR, opinion.BIG)        # 在他面前殺人


def dread(rel: dict, p: dict, my_lv: int) -> str:
    """他怕不怕你：怕（原因＋境界差）到膽識＝忌憚，再高 AWE_OVER＝畏懼。"""
    f = rel.get("fear", 0) + GAP_FEAR * max(0, my_lv - p.get("realm_lv", 0))
    c = p.get("courage", 50)
    return "" if f <= 0 else AWED if f >= c + AWE_OVER else WARY if f >= c else ""


def threatens(text: str) -> bool:
    return any(w in text for w in THREAT_WORDS)


def consequences(name: str, checks: list[tuple[str, str]], state: dict, relation: dict,
                 threat: bool = False) -> tuple[dict, dict, list[str]]:
    """判定對對象 NPC 造成的後果。回傳（新狀態, 新關係, 給 AI 的事實）。

    checks：[(標的, 結果)]。命中：動手記仇，成功往下一階、大成功兩階；打成重傷或打死算重，其他算大；他也怕你多一筆。
    說服、套話不動好感，只有大失敗算冒犯（第 121-3 題）。threat：你威脅他（怕 +小、好感 −小）。
    """
    state, events, hits, grudge = dict(state), [], list(THREATENED if threat else []), ""
    for target, outcome in checks:
        if target == "命中":
            grudge = "被你動手"
            steps = {"大成功": 2, "成功": 1}.get(outcome, 0)
            if steps:
                state["condition"] = harm(state["condition"], steps)
                events.append(f"{name}{state['condition']}")
            hits += [KILL if state["condition"] in CONDITIONS[2:] else HURT, STRUCK]
        elif target in ("說服", "套話") and outcome == "大失敗":
            hits.append(BOTCHED)
    if state["condition"] == CONDITIONS[-1]:
        state["status"] = "FALLEN"
    relation, more = shift(name, relation, hits, grudge)
    return state, relation, events + more


def apply_interaction(name: str, relation: dict, change: str) -> tuple[dict, list[str]]:
    """模型提的互動變化（判定以外）：一律小，每人每回合最多一筆（第 120-6 題）。"""
    if relation["turn_change"]:
        return relation, []
    kind = RELATION_CHANGES[change]
    relation, events = shift(name, relation, [opinion.hit(kind, opinion.LIKE, opinion.SMALL, -1 if kind == opinion.INSULT else 1)])
    return {**relation, "turn_change": 1}, events


def break_promise(name: str, relation: dict) -> tuple[dict, list[str]]:
    """主角對這個 NPC 的承諾逾期未兌現。"""
    return shift(name, relation, BROKEN_PROMISE)


def shift(name: str, relation: dict, hits: list, grudge: str = "") -> tuple[dict, list[str]]:
    """Python 規則造成的關係變化：幾筆原因（domain/opinion.Hit）；grudge：這次記上的仇（已有仇就不換）。"""
    relation = {**new_relation(), **relation}
    before = (tier(relation["affinity"], AFFINITY_TIERS), tier(relation["trust"], TRUST_TIERS), relation["grudge"])
    relation = opinion.apply(relation, name, list(hits))
    if not relation["grudge"]:
        relation["grudge"] = grudge or ("心生怨恨" if relation["affinity"] <= GRUDGE_BELOW else "")
    return relation, _relation_events(name, before, relation)


def _relation_events(name: str, before: tuple[str, str, str], relation: dict) -> list[str]:
    after = (tier(relation["affinity"], AFFINITY_TIERS), tier(relation["trust"], TRUST_TIERS))
    events = []
    if after[0] != before[0]:
        events.append(f"{name}對你的態度：{before[0]} → {after[0]}")
    if after[1] != before[1]:
        events.append(f"{name}對你的信任：{before[1]} → {after[1]}")
    if relation["grudge"] and not before[2]:      # 只在剛記上仇時通知
        events.append(f"{name}記恨在心（{relation['grudge']}）")
    return events
