"""讀懂的驗證（第 3 步 3-2，WHITEPAPER 118-2、118-4、3-2 第 4 題）：模型填好的行動單，Python 再檢查一次。

① 照原文抄的欄（主角說的話、數字、時長）要真的是原文的一段，不是就清空；數字去掉後面的單位（「三兩」→「三」）。
② 要明說的四種（突破、代價、做工、移動）原文也要有對應的字才算（兩把鑰匙）；對不上的欄記進「確認」，
   之後跳確認（「確定要突破嗎？」），不直接作廢。表故意認得寬：只擋模型憑空讀出來，否定和語氣交給讀懂。
③ 第三把鑰匙：原文有「系統」「設定」、括號這類指令的字，模型又說有人在做事 → 誰做、做什麼、回應哪一個跳確認。
④ 第四把鑰匙：原文有「好感」「免費」「定住」這類結果的字 → 替別人寫結果＝有。
⑤ 第五把鑰匙：移動的字前面緊接著不、沒、別（「我不去青石鎮了」），模型卻說要移動 → 去哪跳確認。問句（？、嗎）也一樣（「要去青石鎮嗎？」）。
   原文完全沒有移動的字，去哪直接改成不移動、不跳確認（3-3 第 13 題：9B 常亂填沒去過的地方）。
⑥ 第六把鑰匙（3-3 第 3 題）：對誰填了人，原文要有他的名字或身分；或用他、她、對方、眼前的人且他是上回合眼前的人；
   或做社交、沒點名別人且他是上回合眼前的人。在場只有他一個人，也當他是眼前的人（3-3b 第 5 題）。不然對誰跳確認。
   不是社交、戰鬥，原文又沒提到任何人（名字、身分、他她）：對誰直接改成沒有、不問（2026-11-20 實玩：環顧四周停下來問了 6 次）。
⑦ 第七把鑰匙（3-3 第 4 題）：用什麼挑了身上的東西，原文要有它的名字（或別名）。眼前的環境物不卡。
⑧ 買賣找人讀成付錢，原文要有付錢的字（`side.PAY`，3-4c 第 2 題），不然跳確認。
⑨ 說到哪個勢力要出現在原文（第 7-3b1b2 批），不然跳確認、照保守值都不是；勢力之間遇到問句（？、嗎）、
   不沒別緊接著挑撥撮合調停嫁禍（「才不會挑撥」）也一樣。
跳確認的欄：要緊的停下來按鈕問（3-3b，ask），其餘用保守值照走（3-3 第 1 題，settle）。
"""
from __future__ import annotations

import re

from .effects import JOBS
from .judgment import NATURES, TARGET_ATTRS, asking
from .side import PAY

COPY = ("主角說的話", "數字", "時長", "地名", "對象名")
QUOTES = ("「", "『", "\"", "“")
SAY = ("說", "問", "喊", "道", "告訴")   # 3-6a 收尾甲：沒引號的台詞前面 6 字內要有這些字，免得整句被當台詞
NAMED = 6                                 # 對象名最長 6 字（攔路的山賊、石匣）
STAY = "不移動"
PRONOUNS = ("他", "她", "對方", "眼前", "這人", "那人")   # 第六把鑰匙：指上回合眼前的人
SAFE = {"去哪": STAY, "對誰": "沒有", "用什麼": "沒有", "做什麼": "觀察", "誰做": "沒有行動", "回應哪一個": "都不是", "買賣找人": "都不是",
        "說到哪個勢力": "都不是", "勢力之間": "都不是"}   # 保守值
PLOYS = ("挑撥", "撮合", "調停", "嫁禍")   # 勢力之間（第 7-3b1b2 批，game/factions.py）：配「說到哪個勢力」
NOPLOY = re.compile(f"[不沒別](要|想|會|再|去)?({'|'.join(PLOYS)})")   # 「才不會挑撥」→ 勢力之間跳確認
GO = ("去", "回", "往", "走", "離開", "跟", "動身", "趕")
NOGO = re.compile(f"[不沒別](要|想|會|再)?({'|'.join(GO)})")   # 第五把鑰匙：「不去」「沒要走」→ 去哪跳確認
KEYS = {"突破": ("突破", "衝關", "破境", "瓶頸", "結丹"), "代價": ("壽元", "燃燒", "精血", "修為", "散功"),
        "做工": ("工", "活", "賺", "雜役", "跑堂", "搬", "扛", *JOBS)}
# 第三把鑰匙（3-2 換做法甲）：原文像在下指令，模型卻說有人在做事 → 定這回合做什麼的欄都跳確認
ORDER = ("系統", "設定", "選項", "請選", "忘掉", "忽略", "指令", "開發者", "【", "（", "(")
ACTS = ("誰做", "做什麼", "回應哪一個")
# 第四把鑰匙（3-2 第五輪甲）：原文寫了別人的反應、結果 → 替別人寫結果直接改成有，不問
RESULT = ("好感", "感激", "免費", "定住", "得標")
UNIT = re.compile("(?<=.)(兩|靈石|文|銀子|銀|錢)+$")   # 已知 7 句甲：9B 常把單位一起抄進數字
# 3-6 第 2 題：對著什麼＝這裡的環境物＋常見物件；做法六選一或不挑（118-3）
THINGS = ("門", "窗", "箱子", "櫃子", "抽屜", "床", "桌子", "椅子", "牆", "屋頂", "樑", "地板", "井", "樹", "石頭",
          "草叢", "河", "火堆", "燈", "信", "包袱", "錢袋", "帳本", "鎖", "鑰匙", "碗", "酒罈", "繩子", "梯子", "車")
WAYS = ("小心", "巧妙", "張揚", "強硬", "迅速", "隱密", "不挑")
SPEECH = 60   # 3-6 第 4 題：台詞最長 60 字
LOST, UNSURE = "看不懂", "你一時拿不定主意。"   # 3-6b：亂打的字、跟遊戲無關的話


def blank(text: str) -> bool:
    """3-6b 第 1 題：沒有中文字或只有一個字，不呼叫讀懂。"""
    return len(re.findall("[一-鿿]", text)) < 2


def hint(people: dict[str, str]) -> str:
    """3-6b 第 3 題：灰字例子，用在場的人組（people：名字 → 身分）。"""
    who = next((j or n for n, j in people.items()), "")
    return f"寫下主角要做的事，例如：{f'問{who}最近有什麼消息' if who else '四處看看'}"


def options(people, things, sights, places, recipes, **more) -> dict[str, tuple]:
    """各欄清單，Python 每回合現列（3-2 影子模式甲）。more：回應哪一個、在查哪一個、在辦哪件請託、貨，
    沒給的只有一個選項，表單不放（3-4 再由各系統交）。"""
    one = lambda *v: tuple(dict.fromkeys(v))   # noqa: E731  名字重複的只留一個
    return {"誰做": ("主角", "別人", "沒有行動", LOST), "做什麼": NATURES, "判什麼": tuple(TARGET_ATTRS), "對誰": one(*people, "沒有"),
            "用什麼": one(*things, *sights, "沒有", "清單外"), "對著什麼": one(*sights, *THINGS, "沒有", "清單外"), "做法": WAYS, "去哪": one(*places, *(f"跟著{n}" for n in people), "沒去過的地方", STAY),
            "做出什麼": one(*recipes, "沒有"), "買賣找人": ("買", "賣", "付錢", "找人", "都不是"), "貨": one(*more.get("貨", ()), "沒有"),
            **{k: one(*more.get(k, ()), "都不是") for k in ("回應哪一個", "在查哪一個", "在辦哪件請託", "說出前世的事", "說到哪個勢力")},
            "勢力之間": (*PLOYS, "都不是") if more.get("說到哪個勢力") else ("都不是",),
            "替別人寫結果": ("有", "沒有")}


def facts(place: str, people: dict[str, str], focus: str, waiting: str = "") -> list[str]:
    """讀懂的情境（3-2 第 3 題）：只帶 Python 記下的事實，不帶旁白。people：名字 → 身分。"""
    who = "、".join(f"{n}（{j}）" if j else n for n, j in people.items()) or "沒有人"
    return [f"【地點】{place}", f"【在場的人】{who}", f"【上回合眼前的人】{focus or '沒有'}",
            *([f"【等著回應的事】{waiting}"] if waiting else [])]


def aimed(who: str, text: str, people: dict[str, str], focus: str, nature: str) -> bool:
    """第六把鑰匙：對誰填的人原文對得上。people：在場的人 名字 → 身分。"""
    named = lambda n: n in text or bool(people.get(n)) and people[n] in text   # noqa: E731
    return named(who) or (who == focus or list(people) == [who]) and (any(p in text for p in PRONOUNS)
                                           or nature == "社交" and not any(named(n) for n in people if n != who))


def _moved(go, text: str) -> bool:
    """原文有移動的字：走、去這類，或說到目的地（全名或後兩個字，「渡口」）。"""
    return any(w in text for w in GO) or go not in (STAY, None) and (go in text or go[-2:] in text)


def unkeyed(sheet: dict, text: str, people: dict | None = None, focus: str = "", carried: dict | None = None,
            costly: dict | None = None, trusted: bool = False) -> list[str]:
    """鑰匙對不上的欄。移動的字：走、去這類，或說到目的地（全名或後兩個字，「渡口」）。
    people、carried 沒給就不看第六、七把（carried：身上的東西 名字 → 別名）。
    costly：有代價的回應 選項 → 字（3-4 第 3 題），挑了它原文要有選項全文或其中一個字。"""
    nature, go, who, thing = sheet.get("做什麼"), sheet.get("去哪"), sheet.get("對誰"), sheet.get("用什麼")
    pick = sheet.get("回應哪一個")
    moving, moved = go not in (STAY, None), _moved(go, text)
    ordered = sheet.get("誰做") not in ("沒有行動", None) and any(w in text for w in ORDER)
    bad = [k for k, b in (("做什麼", nature in KEYS and not any(w in text for w in KEYS[nature]) or nature == "移動" and not moved),
                          ("去哪", moving and (not moved or NOGO.search(text) or asking(text) or "嗎" in text)),
                          ("對誰", people is not None and who not in ("沒有", None) and not aimed(who, text, people, focus, nature)),
                          ("用什麼", carried is not None and thing in carried
                           and not any(n in text for n in (thing, *carried[thing]))),
                          ("買賣找人", sheet.get("買賣找人") == "付錢" and not any(w in text for w in PAY)),   # 3-4c 第 2 題：花錢要有付錢的字
                          ("說到哪個勢力", sheet.get("說到哪個勢力") not in (None, "都不是") and sheet["說到哪個勢力"] not in text),   # 第 7-3b1b2 批
                          ("勢力之間", sheet.get("勢力之間") in PLOYS and (asking(text) or "嗎" in text or NOPLOY.search(text))),   # 問該不該做、說不做不算
                          ("回應哪一個", costly is not None and pick in costly and not any(w in text for w in (pick, *costly[pick])))) if b]
    if trusted:   # 大模型（2026-11-23）：讀得懂否定、問句、代稱，只留收不回來的（突破、代價、有代價的回應）和像在下指令的
        bad = [k for k in bad if k == "回應哪一個" or k == "做什麼" and nature in ("突破", "代價")]
    return list(dict.fromkeys(bad + [k for k in ACTS if ordered and k in sheet]))


def check(sheet: dict, text: str, people: dict | None = None, focus: str = "", carried: dict | None = None,
          costly: dict | None = None, trusted: bool = False) -> dict:
    """驗證後的行動單：多一欄「確認」＝鑰匙對不上的欄。trusted：大模型讀的，不用字表改它的去哪、對誰。"""
    out = {k: ("" if k in COPY and v not in text else v) for k, v in sheet.items()}
    if out.get("數字"):
        out["數字"] = UNIT.sub("", out["數字"])
    if (sp := out.get("主角說的話")) and not any(q in text for q in QUOTES) \
            and not re.search(f"({'|'.join(SAY)}).{{0,6}}{re.escape(sp)}", text):
        out["主角說的話"] = ""
    if out.get("主角說的話"):
        out["主角說的話"] = out["主角說的話"][:SPEECH]
    if len(out.get("對象名", "")) > NAMED:
        out["對象名"] = ""
    if "替別人寫結果" in out and any(w in text for w in RESULT):
        out["替別人寫結果"] = "有"
    if "去哪" in out and not trusted and not _moved(out["去哪"], text):   # 3-3 第 13 題：原文沒有移動的字，直接不移動、不問
        out["去哪"] = STAY
    if out.get("誰做") in ("沒有行動", LOST) and "做什麼" in out:   # 3-6b 收尾：主角沒有動作，就只是看看
        out["做什麼"] = SAFE["做什麼"]
    if "對誰" in out and people is not None and not trusted and out.get("做什麼") not in ("社交", "戰鬥") \
            and not any(n in text or j and j in text for n, j in people.items()) and not any(p in text for p in PRONOUNS):
        out["對誰"] = SAFE["對誰"]   # 2026-11-20 實玩：環顧四周也填了在場的人。原文沒提到任何人、又不是說話打架：直接沒有對象、不問（同去哪）
    out["確認"] = unkeyed(out, text, people, focus, carried, costly, trusted)
    return out


SAID = {"去哪": "留在原地", "對誰": "沒有對象", "做什麼": "只是看看", "誰做": "只是看看", "回應哪一個": "沒有回應", "買賣找人": "沒有花錢"}   # 用什麼沒有下游，不寫


def said(sheet: dict) -> str:
    """畫面那一行灰字（3-3 第 12 題）：只在有欄照保守值走的回合寫。"""
    got = dict.fromkeys(SAID[k] for k in sheet.get("確認", ()) if k in SAID)
    return f"（讀成：{'、'.join(got)}）" if got else ""


def settle(sheet: dict) -> dict:
    """跳確認、沒問的欄用保守值照走（3-3 第 1 題）。"""
    return {**sheet, **{k: SAFE[k] for k in sheet.get("確認", ()) if k in SAFE}}


def action(nature: str, targets=(), who: str = "", aim: str = "", tool: str = "", go: str = "", way: str = "") -> str:
    """【主角的行動】那一行（3-6 第 3 題）：只串有填的欄，空的不寫。例：潛行：匿蹤＋發現；對著窗；用麻繩；隱密地"""
    head = f"{nature}：{'＋'.join(targets)}" if targets else nature
    return "；".join([head, *(s for s in (who and f"對著{who}", aim and f"對著{aim}", tool and f"用{tool}",
                                          go and f"往{go}", way and f"{way}地") if s)])


def quote(speech: str, n: int = SPEECH) -> str:
    """台詞加標記（3-6 第 4、5 題）：前情提要只留前 20 字。"""
    return f"說「{speech[:n]}」" if speech else ""


def picked(*picks: str):
    """3-4b：讀懂挑的在查、在辦取代 spot。破綻、陷阱跡象一字不差；請託看開頭（後面接「：怎麼辦」）。"""
    return lambda detail: any(detail == p or detail.startswith(p + "：") for p in picks if p)


BIG = {"突破": ("你在關口前遲疑了一下：真要現在衝關嗎？", "衝關"), "代價": ("這一下要付出的不小，你還在掂量。", "豁出去")}


def ask(sheet: dict, people: dict) -> dict | None:
    """3-3b：要停下來問的那一欄（第 1、3 題），一回合只問一欄：突破、代價 → 有代價的回應（3-4 第 3 題）→ 付錢（3-4c）→ 去哪 → 對誰；
    像指令的句子不問。
    buttons：（字, 值），最後一顆是保守值。people：在場的人 名字 → 身分。"""
    c, nature, go, names = sheet.get("確認", ()), sheet.get("做什麼"), sheet.get("去哪"), list(people)
    if "誰做" in c:
        return None
    if "做什麼" in c and nature in BIG:
        return {"field": "做什麼", "question": BIG[nature][0], "buttons": [(BIG[nature][1], nature), ("先不要", SAFE["做什麼"])]}
    if "回應哪一個" in c:
        pick = sheet["回應哪一個"]
        return {"field": "回應哪一個", "question": f"你心裡還在猶豫：{pick}，還是先不要？", "buttons": [(pick, pick), ("先不要", SAFE["回應哪一個"])]}
    if "買賣找人" in c:   # 3-4c 第 2 題：讀成付錢、原文沒付錢的字
        return {"field": "買賣找人", "question": "這一下要花錢，你還在掂量。", "buttons": [("花錢", "付錢"), ("先不要", SAFE["買賣找人"])]}
    if "去哪" in c:
        to = go if go.startswith("跟著") else f"去{sheet.get('地名') or '別處'}" if go == "沒去過的地方" else f"去{go}"
        return {"field": "去哪", "question": f"你心裡還在猶豫：{to}，還是留在這裡？", "buttons": [(to, go), ("留在這裡", STAY)]}
    if "對誰" in c and names:
        who = f"{'、'.join(names[:-1])}和{names[-1]}" if len(names) > 1 else names[0]
        return {"field": "對誰", "question": f"你看了看{who}，一時沒想好先找誰。", "buttons": [*((n, n) for n in names), ("誰都不找", "沒有")]}
    return None


def answered(sheet: dict, field: str, value: str) -> dict:
    """按了按鈕：那一欄換成選的值、不再算跳確認（3-3b 第 2 題）。"""
    return {**sheet, field: value, "確認": [k for k in sheet.get("確認", ()) if k != field]}
