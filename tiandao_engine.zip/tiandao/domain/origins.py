"""凡人身分與命途（2026-10-12，WHITEPAPER 16g；內容在 progress/ORIGINS.md）。純函式。

- 凡人身分：每個時代一套；影響出生地類型、落腳處與家人、起始凡人錢、給說書人一句。玩家自己指定的優先。
- 命途（第 123 系列，內容在 rules/content/fates.txt）：建角不能選；人人有一般命，三成另有藏著的特殊命（第 37-5、37-6 題）；NPC 3%（`npc`，第 122a 批）。
  第 6-1 批拆掉舊的 12 種和注定的事，6-2 放新的 24 種；加成兩個命都算（第 123-7 題）。
  待接的第 6-5d 批接上（下面「待接」那段）；fates.txt 待接欄只剩等別的系統的兩項（前世戀人似曾相識、開封類判定）。
  前世欄（第 6-6b 批）：空＝無、殘夢（纏絲、聞冥、寄身）；用法在 domain/rebirth.py、game/rebirths.py。
- 角色卡欄位：origin（身分）、fate（面板的一般命）、hidden（特殊命）、reading（哪一讀是真的）、decade_from／decade_step（大限，第 129-2 題）。換一世重擲。
"""
from __future__ import annotations

import math
import random
import re
from dataclasses import dataclass, field

from ..config import PROJECT_ROOT
from ..errors import BadRequest, text_field
from . import bondage, era, palace, stage
from .clock import SHICHEN_NAMES, SHICHEN_PER_DAY
from .home import OLD_HOME, RENT_TYPES, RENTED


@dataclass(frozen=True)
class Origin:
    name: str
    born: str        # 出生地類型；空＝不限
    home: str        # 老家／租的房；空＝不限
    money: float     # 起始凡人錢的倍數
    line: str        # 給說書人的一句
    family: str = ""
    fortune: str = ""


def _o(name, born, home, money, line, family="", fortune=""):
    return Origin(name, born, home, money, line, family, fortune)


ORIGINS = {
    era.ANCIENT: (
        _o("農戶子弟", "村落", OLD_HOME, 1, "家裡種地，從小幫著下田"),
        _o("獵戶", "荒野", OLD_HOME, 1, "跟著長輩在山裡打獵，認得獸蹤"),
        _o("家庭美滿", "", OLD_HOME, 1.5, "家裡和樂，沒吃過什麼苦", "雙親", "和睦"),
        _o("棄嬰", "", OLD_HOME, 0.5, "襁褓時被人丟在路邊，養父母撿回來的", "養父母"),
        _o("坊市孤兒", "城鎮", RENTED, 0.3, "在市集裡長大，靠跑腿、撿剩飯過活"),
        _o("小商販", "城鎮", "", 2, "家裡擺攤做小買賣，從小會算帳"),
        _o("書院雜役", "城鎮", RENTED, 1, "在書院打雜，偷聽了不少先生講學"),
        _o("宗門外役", "城鎮", RENTED, 1, "替附近的宗門做粗活，見過修士，卻摸不到門檻"),
        _o("逃難者", "", RENTED, 0.2, "家鄉遭了災，一路逃到這裡"),
        _o("罪民之後", "村落", OLD_HOME, 0.5, "祖上犯過事，鄉里看你的眼神總帶著些什麼", fortune="虧欠"),
        _o("祭品候選", "村落", OLD_HOME, 1, "村裡的祭典，你的名字總排在候選的名單上"),
        _o("醫館學徒", "城鎮", RENTED, 1, "在醫館當學徒，識得些草藥"),
        _o("墓匠後人", "村落", OLD_HOME, 1, "家裡世代替人修墳造墓，知道些不該知道的事"),
        _o("沒落世家旁支", "城鎮", OLD_HOME, 3, "祖上顯赫過，如今只剩一座舊宅和一身規矩", fortune="疏離"),
    ),
    era.MODERN: (
        _o("上班族", "城鎮", RENTED, 1.5, "朝九晚五，每天擠車上下班"),
        _o("外送員", "城鎮", RENTED, 0.8, "騎車在城裡穿梭，熟悉每一條巷子"),
        _o("育幼院長大", "城鎮", RENTED, 0.3, "不知道父母是誰，在育幼院長大"),
        _o("拆遷戶", "村落", OLD_HOME, 3, "老家被劃進開發區，拿了一筆補償金"),
        _o("雜貨店的孩子", "村落", OLD_HOME, 1, "家裡在小鎮開雜貨店，街坊都認得你"),
        _o("夜市攤販", "城鎮", "", 1.5, "晚上擺攤，白天補眠"),
        _o("大學生", "城鎮", RENTED, 0.8, "離家念書，日子過得緊"),
        _o("宮廟子弟", "村落", OLD_HOME, 1, "家裡管著一間小廟，從小看大人辦法事"),
        _o("守林人", "荒野", OLD_HOME, 1, "在山上巡林，一年下山沒幾次"),
        _o("欠債人家", "", OLD_HOME, 0.2, "家裡欠了一屁股債，討債的常上門", fortune="虧欠"),
    ),
    era.FUTURE: (
        _o("底層勞工", "城鎮", RENTED, 0.8, "在工廠輪班，身上有幾處便宜的義體"),
        _o("義體維修工", "城鎮", RENTED, 1.2, "在巷子裡修義體，什麼零件都見過"),
        _o("數據黑戶", "城鎮", RENTED, 0.2, "系統裡查不到你，活在網路的縫隙裡"),
        _o("企業宿舍長大", "城鎮", RENTED, 1, "父母替大企業賣命，你在宿舍區長大"),
        _o("中產之家", "城鎮", OLD_HOME, 2, "住在乾淨的街區，生活安穩", "雙親", "和睦"),
        _o("聚落農工", "村落", OLD_HOME, 1, "在城外的聚落種水耕作物"),
        _o("廢土拾荒者", "荒野", OLD_HOME, 0.3, "在城外的廢墟裡撿能賣的東西"),
        _o("地下診所學徒", "城鎮", RENTED, 1, "在不問來歷的診所打下手"),
        _o("退役傭兵之後", "城鎮", OLD_HOME, 1, "父親當過傭兵，家裡藏著一把舊槍"),
        _o("逃出來的實驗體", "荒野", OLD_HOME, 0.1, "從某座實驗室逃了出來，記憶斷斷續續", "無父無母"),
    ),
}
# 出身奴隸（16k，domain/bondage.py）：每個時代都能選；沒選時另外擲（不在隨機的表裡）
SLAVE = _o("奴隸", "城鎮", "", 0, "被賣進人市，身不由己", "無父無母")
BY_NAME = {o.name: o for table in ORIGINS.values() for o in table} | {SLAVE.name: SLAVE}


@dataclass(frozen=True)
class Fate:
    """cover 空＝一般命；有寫＝特殊命，面板顯示 cover。kinds、fortunes、undead、road 是倍數，checks、stones、lifespan、meet 是加減。"""
    name: str
    kind: str                # 六類：親、情、物與地、幽冥、眾生、己身
    cover: str
    verse: str               # 判詞
    line: str                # 一般命：給說書人的一句；特殊命：讀一
    other: str               # 特殊命：讀二
    kinds: dict = field(default_factory=dict)      # 事件種類的權重
    fortunes: dict = field(default_factory=dict)   # 家運的權重
    checks: dict = field(default_factory=dict)     # 判定標的 → 點數
    stones: int = 0          # 起始靈石
    lifespan: int = 0        # 壽元（年）
    undead: float = 1        # 亡者現身的機率
    road: float = 1          # 移動回合的事件機率
    meet: int = 0            # 初見好感
    later: str = ""          # 待接的加成（第 6-2-1 題甲，6-5 接）
    lean: str = ""           # 偏宮（第 129-6 題、第 129c 批）：一般命才有，用法等 116
    past: str = ""           # 前世（第 6-6b 批）：空＝無；DREAM＝殘夢
    face: str = ""           # 對結（第 7-4 批）：護、損；兩個字＝讀一、讀二


_GROUPS = {"判定": "checks", "事件": "kinds", "家運": "fortunes"}
_ONES = {"靈石": "stones", "壽元": "lifespan", "亡者": "undead", "路上": "road", "初見": "meet"}


def _fate(name, kind, cover, verse, line, other, bonus, later, lean, past, face) -> Fate:
    f: dict = {"kinds": {}, "fortunes": {}, "checks": {}}
    for part in filter(None, bonus.split("、")):
        key, op, num = re.fullmatch(r"(.+?)([+\-×])([\d.]+)", part).groups()
        n = float(num) if op == "×" else int(op + num)
        group, _, sub = key.partition(":")
        if sub:
            f[_GROUPS[group]][sub] = n
        else:
            f[_ONES[key]] = n
    return Fate(name, kind, cover, verse, line, other, later=later, lean=lean, past=past, face=face, **f)


FATES = {f.name: f for f in (_fate(*line.split("｜")) for line in
                             (PROJECT_ROOT / "rules" / "content" / "fates.txt").read_text(encoding="utf-8").splitlines()
                             if line and not line.startswith("#"))}
assert all(f.face and set(f.face) <= {"護", "損"} and len(f.face) <= (2 if f.cover else 1) for f in FATES.values()), "fates.txt 對結寫錯了"
NORMALS = tuple(n for n, f in FATES.items() if not f.cover)
SPECIALS = tuple(n for n, f in FATES.items() if f.cover)
SPECIAL = 0.3    # 主角另有特殊命的機率（第 37-6 題）
LONGEST = max(f.lifespan for f in FATES.values())   # 壽元最多加幾年（天壽；存檔檢查用）
LAST_LIFE = 10   # 「壽元將盡」：剩餘壽元幾年內（第 123-9 題要用）
DREAM = "殘夢"   # 前世欄（第 6-6b 批）


def fields() -> dict:
    """fate：面板上的一般命；hidden：藏著的特殊命（只有 Python 知道，第 37-5 題）；reading：哪一讀是真的（1、2；沒有特殊命 0）。"""
    return {"origin": "", "fate": "", "hidden": "", "reading": 0, "decade_from": 0, "decade_step": 1,   # 大限（palace.born）
            "known": False}   # 已確定真讀法（第 6-5-6 題甲，一生一次）


def draw(rng: random.Random, sheet: dict) -> dict:
    """抽命（建角、換一世）：三成另有特殊命，面板顯示它掩護的一般命；靈石、壽元開局就加。"""
    if rng.random() < SPECIAL:
        hidden = FATES[rng.choice(SPECIALS)]
        sheet = {**sheet, "fate": hidden.cover, "hidden": hidden.name, "reading": rng.choice((1, 2))}
    else:
        sheet = {**sheet, "fate": rng.choice(NORMALS), "hidden": "", "reading": 0}
    mine = _mine(sheet)
    return {**sheet, **palace.born(rng), "spirit_stones": sheet["spirit_stones"] + sum(f.stones for f in mine),
            "lifespan_adjust": sheet["lifespan_adjust"] + sum(f.lifespan for f in mine)}


NPC_SPECIAL = 0.03   # NPC 另有特殊命的機率（第 37-6、122-2 題）
NPC_KEYS = ("fate", "hidden", "reading")


def npc(rng: random.Random) -> dict:
    """NPC 的命（第 122a 批）：人人有一般命、3% 另有特殊命，跟主角同一張表；不顯示、不用大限。"""
    if rng.random() < NPC_SPECIAL:
        hidden = FATES[rng.choice(SPECIALS)]
        return {"fate": hidden.cover, "hidden": hidden.name, "reading": rng.choice((1, 2))}
    return {"fate": rng.choice(NORMALS), "hidden": "", "reading": 0}


def years(p: dict) -> int:
    """命加減的壽元（年）：NPC 的壽元照境界算，命另外加（天壽 +5、渡壽 -10）。"""
    return sum(f.lifespan for f in _mine(p))


def _mine(sheet: dict) -> list[Fate]:
    return [FATES[n] for n in (sheet.get("fate"), sheet.get("hidden")) if n]


def _times(sheet: dict, attr: str) -> dict:
    out: dict = {}
    for f in _mine(sheet):
        for k, v in getattr(f, attr).items():
            out[k] = out.get(k, 1) * v
    return out


def kind_boost(sheet: dict) -> dict:
    return _times(sheet, "kinds")


def fortune_boost(sheet: dict) -> dict:
    return _times(sheet, "fortunes")


def check_bonus(sheet: dict) -> dict:
    out: dict = {}
    for f in _mine(sheet):
        for k, v in f.checks.items():
            out[k] = out.get(k, 0) + v
    return out


def undead_boost(sheet: dict) -> float:
    return math.prod(f.undead for f in _mine(sheet))


def road_boost(sheet: dict) -> float:
    return math.prod(f.road for f in _mine(sheet))


def dream(sheet: dict) -> bool:
    """前世有殘夢（第 6-6b 批）：兩個命有一個是就算。"""
    return any(f.past == DREAM for f in _mine(sheet))


def meet_bonus(sheet: dict) -> int:
    return sum(f.meet for f in _mine(sheet))


# 待接（第 6-5d 批，第 6-5-5 題甲；數字暫定小）：命本身的加成，兩讀都算
SMALL = 3                 # 當下的判定小加：孤星逢凶事、寄身對亡者鬼神、渡壽救人、礪上一次失敗
BLEED = 1.2               # 羊刃：判定失敗扣的氣血
RETREAT = 1.1             # 地氣：有寫時長的閉關修為
REST = 1.5                # 聞冥：幽魂安息給的感悟
NIGHT, NIGHT_ODDS = "亥子丑寅", 1.2   # 聞冥：夜裡遇事的機率
FOND = 1.5                # 纏絲：NPC 對主角的正面好感留得久
CROWD = 5                 # 眾推：勢力的人初見多一筆小的好感（同初見+5）
# 孤星的隨行同伴重傷在 truth.MATE_HURT（跟情劫走同一條背景演化）


def has(sheet: dict, name: str) -> bool:
    return name in (sheet.get("fate"), sheet.get("hidden"))


def moment(sheet: dict, *, woe: bool, ghost: bool, saving: bool, failed: bool) -> int:
    """當下的判定加成（每個標的都加）。"""
    return SMALL * sum(on and has(sheet, n) for n, on in (("孤星命", woe), ("寄身命", ghost), ("渡壽命", saving), ("礪命", failed)))


def bleed(sheet: dict) -> float:
    return BLEED if has(sheet, "羊刃") else 1


def retreat(sheet: dict, retreating: bool) -> float:
    return RETREAT if retreating and has(sheet, "地氣命") else 1


def rest(sheet: dict) -> float:
    return REST if has(sheet, "聞冥命") else 1


def night(sheet: dict, shichen: int) -> float:
    return NIGHT_ODDS if has(sheet, "聞冥命") and SHICHEN_NAMES[shichen % SHICHEN_PER_DAY] in NIGHT else 1


def fond(sheet: dict) -> float:
    return FOND if has(sheet, "纏絲命") else 1


def crowd(sheet: dict) -> int:
    return CROWD if has(sheet, "眾推命") else 0


def options(era_now: str) -> dict:
    """建角畫面的選項：這個時代的身分（附一句）。"""
    return {"origins": [{"name": o.name, "line": o.line} for o in (*ORIGINS[era_now], SLAVE)]}


def pick(rng: random.Random, era_now: str, origin) -> Origin:
    """建角時的身分：玩家挑的優先，沒挑就隨機。"""
    origin = text_field(origin, "身分", "invalid_origin")
    table = {o.name: o for o in (*ORIGINS[era_now], SLAVE)}
    if origin and origin not in table:
        raise BadRequest("身分只能從選項裡挑。", code="invalid_origin")
    return table.get(origin) or rng.choice(ORIGINS[era_now])


def born_types(origin: Origin) -> tuple:
    """隨機出生地從哪幾類挑：身分指定的那一類；租房的身分只挑租得到房的地方（追加第 1 題）；其餘不限。"""
    return (origin.born,) if origin.born else RENT_TYPES if origin.home == RENTED else ()


def apply(sheet: dict, origin: Origin) -> dict:
    """身分的錢套到剛建好的角色卡（出生地、落腳處由 service 照身分挑）。"""
    return {**sheet, "origin": origin.name, "money": round(sheet["money"] * origin.money)}


def shown(sheet: dict) -> bool:
    """特殊命露出來了（第 6-3-3 題甲）：第一章走到「點破」以後。"""
    return bool(sheet.get("hidden")) and (bool(sheet.get("chapters")) or bool(sheet.get("known"))
                                          or any(stage.chapter(r) and r["stage"] >= 1 for r in (sheet.get("route"), sheet.get("chapter"))))


def prompt_line(sheet: dict) -> str:
    """給說書人：「凡人身分：農戶子弟（家裡種地……）；命途：孤辰「六親緣薄」（親緣淡……）」。面板上的命；特殊命露出來才換（另一讀不給）。"""
    fate = sheet["hidden"] if shown(sheet) else sheet.get("fate")
    parts = ([f"凡人身分：{sheet['origin']}（{BY_NAME[sheet['origin']].line}）"] if sheet.get("origin") else []) \
        + ([f"命途：{fate}「{FATES[fate].verse}」（{FATES[fate].line}）"] if fate else []) \
        + ([bondage.prompt_line(sheet)] if sheet.get("bondage") else [])
    return "；".join(parts)


def fated(p: dict) -> bool:
    """命那三欄合不合（角色卡、NPC 都用）。"""
    return (p["fate"] in ("", *NORMALS) and p["hidden"] in ("", *SPECIALS) and p["reading"] in ((1, 2) if p["hidden"] else (0,))
            and (not p["hidden"] or FATES[p["hidden"]].cover == p["fate"]))


def valid(sheet: dict) -> bool:
    return (sheet["origin"] in ("", *BY_NAME) and fated(sheet)
            and sheet["decade_from"] in range(len(palace.PALACES)) and sheet["decade_step"] in (1, -1) and isinstance(sheet["known"], bool))
