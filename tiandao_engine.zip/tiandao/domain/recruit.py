"""仙域的招攬與入宗（16l 第 18、19、22 題；草稿 C4a）。純函式。

規則（2026-10-18 與使用者一題一題定案，見 progress/WHITEPAPER.md 16l，數字暫定）：
- 散仙入宗三條路：仙戰（C4b）、主動招攬、上門拜入（沿用下界入門考核，problem 擋掉不收的）。
- 主動招攬每個百日看一次：本身條件（境界到大羅金仙或有靈根）、表現（此地威名遠近皆知或戰績 FEATS 場）各一份；
  一份 1 家外門、兩份 2～3 家內門起跳。戰績＝打退仙宗的人（＋C4c 的受雇勝場），角色卡 feats。
- 條件記在角色卡 invites 留 LASTS（不擋回合），說「投入某宗」就入宗；各家條件不同：職位、附贈（法器、功法、戰功）、
  要立的誓（照接引的誓言）。立了誓記在 sect_oath（C4c 檢查）。
"""
from __future__ import annotations

from . import ascent, immortal, items, oath, paths, reputation, sect
from .clock import SHICHEN_PER_DAY

LASTS = 30 * SHICHEN_PER_DAY
TALENT = (7, 2)          # 大羅金仙：Lv7 第三個小境界
FEATS = 10
COUNT = {1: (1, 1), 2: (2, 3)}
RANK = {1: sect.OUTER, 2: sect.INNER}
GIFTS = ("", items.ARTIFACT, items.TECHNIQUE, "戰功")
GIFT_MERIT = 50
WORDS = ("投入", "加入", "答應")


def fields() -> dict:
    return {"invites": [], "feats": 0, "scouted": -1, "sect_oath": None}


def worth(sheet: dict, levels: dict) -> int:
    """幾份條件夠格（0～2）：本身條件、表現。levels：此地的名聲。"""
    talent = (sheet["realm_lv"], sheet["stage_index"]) >= TALENT or bool(sheet["roots"])
    deeds = levels.get(reputation.MIGHT) == reputation.FAMOUS or sheet["feats"] >= FEATS
    return talent + deeds


def scout(rng, realm: dict, sheet: dict, levels: dict, clock_now: int) -> list[dict]:
    """這個百日來招攬的仙宗（散仙才有；諸天異端隱匿只招諸天異端）。"""
    n = worth(sheet, levels)
    if not n or sheet["sect"]:
        return []
    pool = sorted((s for s in realm["sects"] if (sheet["heretic"] or s["alliance"] != immortal.HERETICS)
                   and clock_now >= sheet["sect_bans"].get(s["name"], -1)), key=lambda s: s["name"])
    return [offer(rng, s["name"], RANK[n], clock_now) for s in paths.pick(rng, pool, rng.randint(*COUNT[n]), sheet)]   # 同道統優先


def offer(rng, name: str, rank: str, clock_now: int) -> dict:
    return {"sect": name, "rank": rank, "gift": rng.choice(GIFTS), "oath": rng.choice(("",) + ascent.OATHS),
            "until": clock_now + LASTS}


def accept(rng, sheet: dict, words: str, clock_now: int) -> tuple[dict, list[str]]:
    """說「投入某宗」：入宗、職位照條件、拿附贈、立誓。過期的條件先清掉。"""
    sheet = {**sheet, "invites": [o for o in sheet["invites"] if o["until"] > clock_now]}
    pick = next((o for o in sheet["invites"] if o["sect"] in words), None)
    if not pick or sheet["sect"] or not any(w in words for w in WORDS):
        return sheet, []
    sheet, facts = sect.join(rng, sheet, pick["sect"], "", clock_now)
    sheet = {**sheet, "sect_rank": pick["rank"], "invites": [],
             "sect_oath": oath.make(pick["oath"], clock_now)}
    facts = [f"應了{pick['sect']}的招攬，成了{pick['rank']}弟子"] + facts[1:]
    if pick["gift"] == "戰功":
        sheet = {**sheet, "merit": sheet["merit"] + GIFT_MERIT}
        facts.append(f"{pick['sect']}送上 {GIFT_MERIT} 點戰功當見面禮")
    elif pick["gift"]:
        sheet, fact = items.grant(rng, sheet, pick["gift"], sheet["realm_lv"])
        facts.append(f"{pick['sect']}送上見面禮：{fact}")
    return sheet, facts + ([f"立下誓言：{pick['oath']}"] if pick["oath"] else [])


def problem(realm: dict, sheet: dict, name: str) -> str:
    """上門拜入仙宗不收的原因（空字串＝可以考）：境界不到 Lv7、種族不合（主收別族的仙宗）。
    道統（修鬼道的正道不收、不同道統考核 −10）在 service 照勢力的道統另外看，下界也一樣。"""
    s = next((x for x in realm["sects"] if x["name"] == name), None)
    if s is None:
        return ""
    if sheet["realm_lv"] < ascent.LV:
        return "仙宗不收未破空的人"
    return f"{name}只收{s['race']}" if s["race"] and s["race"] != sheet["race"] else ""


def text(sheet: dict, clock_now: int) -> str:
    live = [o for o in sheet["invites"] if o["until"] > clock_now]
    return ("招攬中：" + "、".join(f"{o['sect']}（{o['rank']}）" for o in live)) if live else ""


def valid(sheet: dict) -> bool:
    return (isinstance(sheet["invites"], list) and all(isinstance(o, dict) and set(o) == {"sect", "rank", "gift", "oath", "until"}
                                                       for o in sheet["invites"])
            and isinstance(sheet["feats"], int) and sheet["feats"] >= 0 and isinstance(sheet["scouted"], int)
            and (sheet["sect_oath"] is None or isinstance(sheet["sect_oath"], dict)))
