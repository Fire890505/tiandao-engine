"""路線的伏筆（WHITEPAPER 16v 第 82、82-1～82-3 題）：破綻綁在人或地方，見過兩次再查就翻開。純函式。內容在 rules/content/stages.txt。

- 「伏筆｜路線｜名字｜綁在｜從哪一階｜破綻一／破綻二｜翻開｜上門的人｜上門說的話｜留下」。
- 綁在：「人:角色」＝那個人是眼前的人、這回合在跟他說話；「地」＝人在路線那裡、這回合查探。
- 破綻：碰到了就寫進這回合的事件，算見過一次；同一條隔 GAP 回合才出現，見過兩次就停。之後在那裡查探成功就翻開。
- 結局時還沒翻開：見過的翻開，寫成回頭看的話；沒見過的排進回音，由「上門的人」來說。「留下」寫在主角身上（跨路線的記號）。
路線欄位 seen：名字 → {"n": 見過幾次, "at": 上次的回合, "open": 翻開了沒}。
"""
from __future__ import annotations

from dataclasses import dataclass

from . import stage

PERSON, PLACE = "人:", "地"
GAP, TIMES = 3, 2


@dataclass(frozen=True)
class Hint:
    name: str
    bound: str
    since: str
    tells: tuple[str, ...]
    reveal: str
    who: str
    words: str
    left: str


def hints(r: dict) -> list[Hint]:
    return [Hint(n, b, s, tuple(t.split("／")), rv, w, wd, lf) for n, b, s, t, rv, w, wd, lf in stage.TABLE.get(("伏筆", r["name"]), [])]


def _state(r: dict, h: Hint) -> dict:
    return r["seen"].get(h.name, {"n": 0, "at": -GAP, "open": False})


def _started(r: dict, h: Hint) -> bool:
    names = stage.names(r)
    return h.since not in names or r["stage"] >= names.index(h.since)


def _here(r: dict, h: Hint, *, focus: str, talked: bool, looked: bool) -> bool:
    """碰到了沒：那個人在眼前、這回合跟他說話；或人在那裡、這回合查探。"""
    if h.bound.startswith(PERSON):
        return talked and bool(focus) and r["cast"].get(h.bound[len(PERSON):]) == focus
    return looked


def turn(r: dict, *, focus: str, talked: bool, looked: bool, found: bool, turn_no: int) -> tuple[dict, list[str]]:
    """這回合：碰到了就露一句破綻，見過兩次後查探成功（found）就翻開。回傳（路線, 事件）。一回合最多一件。"""
    for h in hints(r):
        s = _state(r, h)
        if s["open"] or not _started(r, h) or not _here(r, h, focus=focus, talked=talked, looked=looked):
            continue
        if s["n"] >= TIMES and found:
            return {**r, "seen": {**r["seen"], h.name: {**s, "open": True}}}, [f"原來如此：{h.reveal}"]
        if s["n"] < TIMES and turn_no - s["at"] >= GAP:
            return {**r, "seen": {**r["seen"], h.name: {**s, "n": s["n"] + 1, "at": turn_no}}}, [h.tells[min(s["n"], len(h.tells) - 1)]]
    return r, []


def close(r: dict) -> tuple[list[str], list[tuple[str, str]], list[str]]:
    """結局時還沒翻開的（第 82-2 題）：（回頭看的話, 回音：（話, 上門的人的名字）, 留下的記號）。"""
    told, later, left = [], [], []
    for h in hints(r):
        s = _state(r, h)
        if not s["open"] and s["n"]:
            told.append(f"主角想起{'、'.join(h.tells[:s['n']])}，現在才明白：{h.reveal}")
        elif not s["open"]:
            later.append((h.words, r["cast"].get(h.who, "")))
        left += [h.left[len(stage.MARK):]] if h.left.startswith(stage.MARK) else []
    return told, later, left
