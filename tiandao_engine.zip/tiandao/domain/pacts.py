"""立約：國與國（game/nations.py，WHITEPAPER (56)～(60)）、盟與盟（domain/immortal.py，(61)～(64)）共用。

- 好感：原因（opinion）加總，壽元當 LIFE 步（國一步＝一年、盟一步＝一百日）；base 是固定的一筆（種族、正魔）。
- 立約：門檻同 factions.TIERS；冷戰、通商有緩衝（冷戰到互相友善才轉通商，通商掉到冷淡以下才轉冷戰）；
  議和兩邊記大好，議和後 TRUCE 步內不開戰；斷盟時還比較喜歡對方的那方記背叛；只有相鄰的會開戰。
- 開局（open）：照擲到的關係補一筆原因，免得第一步一口氣翻掉。
- 牌（國事牌、盟事牌）：每方每步抽一張，條件寫得最多那層才抽，目標挑好感最極端的（平手挑相鄰的），冷卻 CD 步。
"""
from __future__ import annotations

import random

from . import atlas, opinion
from .atlas import ALLY, COLD, TRADE, WAR
from .clock import SHICHEN_PER_YEAR as YEAR

OPEN = {WAR: ("交惡", -1), ALLY: ("交好", 1), COLD: ("舊怨", -1), TRADE: ("舊交", 1)}
WED, PEACE = "和親", "議和"
LIFE, FEAR_AT, WAR_STEPS, TRUCE, CD = 100, 20, 3, 8, 3   # 步數；FEAR_AT 同 factions
SIZE = {"小": opinion.SMALL, "大": opinion.BIG, "重": opinion.GRAVE}
SELF = ("戰", "盟")   # 牌看自己的條件；其他看目標
RESULTS = ("原", "原對", "原我", "畏對", "畏我")


def likes(v: int) -> set[str]:
    return {n for n, ok in (("親近", v >= 60), ("友善", v >= 20), ("中立", -9 <= v < 20), ("冷淡", v < -9), ("敵視", v < -49)) if ok}


def match(want: str, have) -> bool:
    return any(x in have for x in want.split("、"))


class Pacts:
    WED = WED   # 結盟條件的那筆原因（盟叫「聯姻」）

    def __init__(self, names, st: dict, since: dict, near: set, rs: list, cd: dict, step: int, deck=()):
        self.names, self.st, self.since, self.near = sorted(names), dict(st), dict(since), near
        self.rs, self.cd, self.step, self.deck = list(rs), dict(cd), step, deck
        self.years = LIFE * step / YEAR
        self.added: list[dict] = []             # 這一步新記的原因
        self.news: list[tuple[str, str]] = []   # 關係變了
        self.told: list[tuple[str, str]] = []   # 抽到的牌那一句
        self.wars: list[tuple[str, str]] = []   # 這一步開戰的（因果鏈，domain/chains）

    def base(self, x: str, y: str) -> int:
        return 0

    def like(self, x: str, y: str, t: int, axis: str = opinion.LIKE) -> int:
        return opinion.total([r for r in self.rs if (r["holder"], r["toward"], r["axis"]) == (x, y, axis)], self.years, t,
                             self.base(x, y) if axis == opinion.LIKE else 0)

    def feel(self, x: str, y: str, kind: str, size: str, sign: int, t: int, axis: str = opinion.LIKE, event: str = "") -> None:
        r = opinion.reason(x, y, opinion.hit(kind, axis, size, sign), t, event_id=event)
        self.rs.append(r)
        self.added.append(r)

    def set(self, x: str, y: str, new: str, t: int) -> None:
        key = atlas._key(x, y)
        self.news.append((x, atlas.news(x, y, self.st[key], new)))
        self.st[key], self.since[key] = new, t

    @staticmethod
    def fits(s: str, v: int) -> bool:
        """冷戰、通商不翻的那段（緩衝）。"""
        return v < 20 if s == COLD else v >= -9

    def open(self, keys, t: int) -> None:
        for key in sorted(keys):
            x, y = key.split("|")
            s = self.st[key]
            kind, sign = OPEN[s]
            base = self.like(x, y, t)
            if s in (WAR, ALLY):
                size = opinion.BIG
            elif self.fits(s, base):
                self.since[key] = t
                continue
            else:
                size = next(z for z in opinion.LEVELS if self.fits(s, base + sign * opinion.SIZES[z]))
            self.feel(x, y, kind, size, sign, t)
            self.feel(y, x, kind, size, sign, t)
            self.since[key] = t

    def pacts(self, t: int) -> None:
        """斷盟、議和、結盟、開戰，再看冷戰、通商。"""
        for i, x in enumerate(self.names):
            for y in self.names[i + 1:]:
                key = atlas._key(x, y)
                s, lx, ly = self.st[key], self.like(x, y, t), self.like(y, x, t)
                low = min(lx, ly)
                if s == ALLY and low < -9:
                    self.set(x, y, COLD, t)
                    hurt, other = (y, x) if lx < ly else (x, y)   # 還比較喜歡對方的那方被背棄
                    self.feel(hurt, other, opinion.BETRAY, opinion.BIG, -1, t)
                elif s == WAR and (max(self.like(x, y, t, opinion.FEAR), self.like(y, x, t, opinion.FEAR)) >= FEAR_AT
                                   or t - self.since.setdefault(key, t) >= WAR_STEPS * self.step):
                    self.set(x, y, COLD, t)
                    self.feel(x, y, PEACE, opinion.BIG, 1, t)
                    self.feel(y, x, PEACE, opinion.BIG, 1, t)
                elif s in (COLD, TRADE) and low >= 20 and (self.wed(x, y, t) or any(
                        max(self.like(x, z, t), self.like(y, z, t)) < -49
                        or self.st[atlas._key(x, z)] == self.st[atlas._key(y, z)] == WAR for z in self.names if z not in (x, y))):
                    self.set(x, y, ALLY, t)
                elif s in (COLD, TRADE) and low < -49 and key in self.near and not self.truce(x, y, t):
                    self.set(x, y, WAR, t)
                    self.wars.append((x, y))
                elif s in (COLD, TRADE) and not self.fits(s, low):
                    self.set(x, y, TRADE if s == COLD else COLD, t)

    def truce(self, x: str, y: str, t: int) -> bool:
        return any(r["kind"] == PEACE and {r["holder"], r["toward"]} == {x, y} and t - r["clock_shichen"] < TRUCE * self.step
                   for r in self.rs)

    def wed(self, x: str, y: str, t: int) -> bool:
        return any(r["kind"] == self.WED and {r["holder"], r["toward"]} == {x, y} and opinion.alive(r, self.years, t) for r in self.rs)

    # ── 牌 ──────────────────────────────────────────────────────────────────
    def pair(self, k: str, f: str, g: str, t: int) -> set[str]:
        """看目標的條件；「好」以外的由子類給。"""
        return likes(self.like(f, g, t))

    def aim(self, words: str, f: str, g: str) -> bool:
        key = atlas._key(f, g)
        near, ally = key in self.near, self.st[key] == ALLY
        ok = {"鄰國": near, "鄰盟": near, "交戰": self.st[key] == WAR, "盟國": ally, "盟友": ally}
        return all(ok[w] for w in words.split("、") if w)

    def draw(self, rng: random.Random, f: str, t: int) -> None:
        mine = {self.st[k] for k in self.st if f in k.split("|")}
        me = {"戰": {"是"} if WAR in mine else set(), "盟": {"是"} if ALLY in mine else set()}
        fits = []
        for c in self.deck:
            if self.cd.get(f"{f}|{c.name}", 0) > t or not all(match(v, me[k]) for k, v in c.need if k in SELF):
                continue
            cands = [g for g in self.names if g != f and self.aim(c.target, f, g)
                     and all(match(v, self.pair(k, f, g, t)) for k, v in c.need if k not in SELF)]
            if cands:
                fits.append((c, max(cands, key=lambda g: (abs(self.like(f, g, t)), atlas._key(f, g) in self.near, g))))
        top = max((len(c.need) for c, _ in fits), default=0)
        pool = [x for x in fits if len(x[0].need) == top]
        if not pool:
            return
        c, g = rng.choice(pool)
        self.cd[f"{f}|{c.name}"] = t + CD * self.step
        for x in c.result.split():
            k, _, v = x.partition(":")
            if k.startswith("原"):
                size, sign = SIZE[v[0]], 1 if v[1] == "好" else -1
                if k != "原對":
                    self.feel(f, g, c.name, size, sign, t)
                if k != "原我":
                    self.feel(g, f, c.name, size, sign, t)
            else:   # 畏對：目標怕自己；畏我：自己怕目標
                self.feel(*((f, g) if k == "畏我" else (g, f)), c.name, SIZE[v], 1, t, opinion.FEAR)
        self.told.append((f, c.text.format(國=f, 盟=f, 對=g)))
