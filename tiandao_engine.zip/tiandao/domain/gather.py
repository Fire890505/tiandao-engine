"""聚（第 7-5a 批，WHITEPAPER 124-5、124-9、7-5-1～7-5-3 題；數字暫定）。純函式，不碰資料庫。

- 一群：同一個村鎮的人，兩兩好感都到友善以上（society.FRIEND_AT）又是熟人或親人，SIZE 人以上，取最大的那群。
  朋友湊不到 SIZE 人時看同行（peers）：做同一行、彼此不討厭的也算一群（第 7-5a 補）。
  整群已經同一個勢力、或兩兩都結義了的不算。NPC 那群每處一年最多一次：帳上記一筆「聚過」（甲乙＝那一處），聚不聚都記。
- NPC 那群（7-5-2）：多疑高的每人不聚 +DOUBT；一半以上同一種（職業、目的、修士）開新勢力，不然結義。
  首領＝境界最高、同境界看野心；名字＝地名＋種類字，撞名換字，都撞了改結義。
- 主角那群（7-5-3）在 game/gathers.py：主角算一根線，只問結義或不聚。
"""
from __future__ import annotations

import random

from . import npc, society
from .clock import SHICHEN_PER_YEAR

SIZE, DOUBT = 4, 0.15
SWORN = "結義"
TRADE = {**dict.fromkeys(("掌櫃", "小販", "帳房", "朝奉", "管事", "夥計", "店小二"), "商會"),
         **dict.fromkeys(("武師", "鏢師", "趟子手"), "武館"), **dict.fromkeys(("腳夫", "賣藝人"), "幫派")}
AIM = {"逐利": "商會", "求名": "武館"}
WORDS = {"商會": ("商會", "商號", "商行"), "武館": ("武館", "拳館"), "幫派": ("幫", "會"), "宗門": ("派", "門")}


def biggest(edges: dict[str, set[str]], need: int = SIZE) -> list[str]:
    """兩兩相連的最大一群（Bron–Kerbosch；同樣大先找到的）。不到 need 人回傳空的。"""
    keep = {k for k, v in edges.items() if len(v) >= need - 1}
    edges = {k: edges[k] & keep for k in keep}
    best: list[str] = []

    def grow(r: set, p: set, x: set) -> None:
        nonlocal best
        if not p and not x and len(r) > len(best):
            best = sorted(r)
        for v in sorted(p):
            grow(r | {v}, p & edges[v], x & edges[v])
            p, x = p - {v}, x | {v}
    grow(set(), set(edges), set())
    return best if len(best) >= need else []


def links(names: list[str], npcs: list[dict], bonds: list[dict], reasons: list[dict], factions: list[dict], now: int) -> dict[str, set[str]]:
    """NPC 之間兩兩好的：雙方友善以上、熟人或親人。"""
    like = society.liking(npcs, bonds, reasons, now, factions)
    places = {p["name"]: p["location"] for p in npcs if p["location"] != society.AWAY}
    out = {n: set() for n in names}
    for i, x in enumerate(names):
        for y in names[i + 1:]:
            if like(x, y) >= society.FRIEND_AT and like(y, x) >= society.FRIEND_AT:
                talks = [r for r in reasons if {r["holder"], r["toward"]} == {x, y} and not r["session_id"]]
                if society.familiar(x, y, bonds, talks, places) in (society.KNOWN, society.KIN):
                    out[x].add(y)
                    out[y].add(x)
    return out


def peers(people: list[dict], npcs: list[dict], bonds: list[dict], reasons: list[dict], factions: list[dict], now: int) -> dict[str, set[str]]:
    """同行那條路（第 7-5a 補，使用者「丙二」）：做同一行（TRADE 同一種），雙方好感 0 以上（不討厭）就連起來。"""
    like = society.liking(npcs, bonds, reasons, now, factions)
    out = {p["name"]: set() for p in people}
    for i, p in enumerate(people):
        for q in people[i + 1:]:
            x, y = p["name"], q["name"]
            if TRADE.get(p.get("job", "")) and TRADE.get(p.get("job", "")) == TRADE.get(q.get("job", "")) \
                    and like(x, y) >= 0 and like(y, x) >= 0:
                out[x].add(y)
                out[y].add(x)
    return out


def joined(group: list[str], bonds: list[dict]) -> bool:
    """整群已經同一個勢力，或兩兩都結義了。"""
    halls = [{b["b"] for b in bonds if b["a"] == n and b["type"] in society.MEMBER_BONDS} for n in group]
    sworn = {frozenset((b["a"], b["b"])) for b in bonds if b["type"] == SWORN}
    return bool(set.intersection(*halls)) or all(frozenset((x, y)) in sworn for i, x in enumerate(group) for y in group[i + 1:])


def kind(p: dict) -> str:
    """這個人會開哪種勢力：修士開小宗門，凡人看職業、再看目的。"""
    return "宗門" if p["realm_lv"] >= 1 else TRADE.get(p.get("job", "")) or AIM.get(p["goal"], "")


def form(rng: random.Random, people: list[dict], town: str, taken: set[str]) -> tuple[str, str, str]:
    """（成什麼, 勢力名, 首領）：不聚＝空字串；結義＝SWORN；新勢力＝那種勢力。"""
    if rng.random() < DOUBT * sum(npc.trait_level(p["suspicion"]) == "高" for p in people):
        return "", "", ""
    kinds = [kind(p) for p in people]
    top = max(set(kinds) - {""}, key=lambda k: (kinds.count(k), k), default="")
    name = next((town + w for w in WORDS.get(top, ()) if town + w not in taken), "")
    if not name or kinds.count(top) * 2 < len(people):
        return SWORN, "", ""
    head = max(people, key=lambda p: (p["realm_lv"], p["stage_index"], p["ambition"], p["name"]))
    return top, name, head["name"]


def ties(group: list[str], what: str, name: str, head: str, bonds: list[dict], when: int, turn_no: int,
         me: tuple[str, str] = ()) -> list[dict]:
    """聚成之後的羈絆：結義兩兩一條（已經結義的不重複）；新勢力首領、成員。me：（那一生, PLAYER）也算進結義。"""
    def bond(a_kind, a, b_kind, b, type_):
        return {"a_kind": a_kind, "a": a, "b_kind": b_kind, "b": b, "type": type_, "clock_shichen": when, "turn_no": turn_no}
    if not what:
        return []
    if what != SWORN:
        return [bond(society.NPC, n, society.FACTION, name, "首領" if n == head else "成員") for n in group]
    sworn = {frozenset((b["a"], b["b"])) for b in bonds if b["type"] == SWORN}
    pairs = [(society.NPC, x, y) for i, x in enumerate(group) for y in group[i + 1:]]
    pairs += [(me[1], me[0], y) for y in group] if me else []
    return [bond(k, x, society.NPC, y, SWORN) for k, x, y in pairs if frozenset((x, y)) not in sworn]


def done(ledger: list[dict], town: str, now: int) -> bool:
    """這一處一年內聚過（或商量過沒聚）。"""
    return any(l["kind"] == society.GATHERED and l["a"] == town and not l["session_id"] and l["status"] == society.OPEN
               and (l["deadline_shichen"] or 0) > now for l in ledger)


def row(town: str, group: list[str], what: str, when: int) -> dict:
    return {**society.owed(society.GATHERED, town, town, when), "deadline_shichen": when + SHICHEN_PER_YEAR,
            "body": {"群": group, "成": what}}


def line(group: list[str], what: str, name: str, head: str, town: str) -> str:
    """傳開的那一句（沒聚就空字串）。"""
    if not what:
        return ""
    if what == SWORN:
        return f"{'、'.join(group)}在{town}拜了把子"
    return f"{head}帶著{'、'.join(n for n in group if n != head)}在{town}開了{name}"
