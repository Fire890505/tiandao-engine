"""地點與移動的純規則（第 7 步）。純函式，不碰資料庫。

規則（2026-10-04 與使用者討論定案，見 progress/HANDOFF.md 第 7 步）：
- 地點之間記錄連接（距離、方向）與母子階層；座標之後需要時再由已存的方向回推（舊版 spatial_system 的座標狀態機先不做）。
- 距離由 AI 從三級選、Python 換算公里（沿用舊版校準）；速度隨境界提升，凡人每時辰約 5 公里。
- 危險度只出現在荒野、秘境、廢墟，影響主動出擊類判定；規模只用來整理階層，不影響成功率。
- 前往已知地點：沿已知路線直接移動；前往未知但有名字的地方：先過「辨向」，成功才抵達（名字來自玩家）。
"""
from __future__ import annotations

import heapq
import math
import re

DISTANCE_TIERS = {"鄰近": 3, "半日路程": 20, "遠行": 80}     # 公里
NEAR, HALF_DAY = "鄰近", "半日路程"
STATE_ROADS = {"官道": 400, "海路": 500, "邊關": 600, "山道": 800}   # 州與州的主城之間（16k；凡人 7～13 天）
ALL_TIERS = {**DISTANCE_TIERS, **STATE_ROADS}
DIRECTIONS = ("北", "東北", "東", "東南", "南", "西南", "西", "西北")
SCALES = ("家", "村落", "鄉鎮", "城市", "國家")             # 對應舊版 S2–S6
DANGER = {"低": 0, "中": -6, "高": -12, "極危": -18}        # 對主動出擊類判定的成功率影響
DANGER_TYPES = {"荒野", "秘境", "廢墟"}                     # 只有這幾類地點有危險度
SPEED_BY_REALM = {0: 5, 1: 10, 2: 30, 3: 60, 4: 120, 5: 300}   # 公里／時辰（暫定）；Lv6 以上用 MAX_SPEED
MAX_SPEED = 1000
MAX_BREADCRUMB = 6
NEW_PLACE_DESCRIPTION = "初到此地，尚待細看。"   # 預設描述：還沒寫過、或要重寫（換時代、被怪談籠罩；地圖第二輪）

START_PLACE = {"name": "青石鎮外的山道", "description": "青石鎮外的一段山道，林木夾道，往來行人稀少。",
               "type": "荒野", "scale": "村落", "danger": "低", "parent": ""}

# 移動動詞：後面接的就是目的地。「去」太常見（去找人、去看看），不收
MOVE_VERBS = ("動身前往", "啟程前往", "前往", "趕往", "趕去", "去往", "回到", "返回", "走到", "到達", "抵達")
_STOP_CHARS = "，。、！？；：,.!?;: 　"
_TRAILING_ACTIONS = ("打聽", "看看", "查看", "拜訪", "求見", "尋找", "找", "探索", "修煉", "閉關", "買", "賣", "投宿",
                     # 第 17 步冒煙發現「前往青石鎮休息」被登錄成「青石鎮休息」：補上休養、落腳類的動作
                     "休息", "歇息", "歇腳", "過夜", "落腳", "療傷", "靜養", "打坐", "避雨", "躲避", "補給", "採買",
                     "交易", "求醫", "看病", "安頓")
_GENERIC_WORDS = ("的", "附近", "某", "一個", "一處", "哪", "那裡", "這裡", "地方", "那邊", "這邊")
_GO = re.compile(r"(?<![失過死離除逝])去")
_NAME_RE = re.compile(r"^[㐀-鿿·・]{2,12}$")
# 地圖上沒有的小地方（16t 第 3 題）：回到前院、走到門口是留在原處，不是新地點
_SPOTS = ("前院", "後院", "院子", "院裡", "門口", "門外", "門前", "門邊", "前門", "後門", "屋裡", "屋內", "屋外", "屋前", "屋後",
          "廳堂", "堂屋", "廚房", "臥房", "房間", "房裡", "窗邊", "牆邊", "樹下", "井邊", "路口", "巷口", "街上", "街角", "原地", "原處")


def speed(realm_lv: int) -> int:
    return SPEED_BY_REALM.get(realm_lv, MAX_SPEED)


def travel_shichen(km: int, realm_lv: int) -> int:
    return max(1, math.ceil(km / speed(realm_lv)))


def town_of(locations: list[dict], name: str) -> str:
    """「家」級的子地點算在它的上層村鎮裡；其他地點就是自己。"""
    place = next((l for l in locations if l["name"] == name), {})
    return place["parent"] if place.get("scale") == SCALES[0] and place.get("parent") else name


def within(locations: list[dict], here: str) -> list[str]:
    """同一個村鎮裡走得到的地方（16t 第 3 題）：上層村鎮和底下的幾處，不含這裡。"""
    town = town_of(locations, here)
    return [l["name"] for l in locations if l["name"] != here and town_of(locations, l["name"]) == town]


def danger_modifier(danger: str) -> int:
    return DANGER.get(danger, 0)


def scale_rank(scale: str) -> int:
    return SCALES.index(scale) if scale in SCALES else -1


def going(text: str) -> str:
    """話裡「去」之後的部分（走去、跑去、回去都算；失去、過去不算）；沒有回傳空字串。"""
    found = _GO.search(text or "")
    return text[found.end():] if found else ""


def extract_destination(text: str, known: list[str]) -> tuple[str, bool] | None:
    """從玩家輸入找出目的地。回傳（地名, 是否已知）；不是移動、或目的地沒有具體名字時回傳 None。

    已知地點優先（取最長的一個，避免「青石鎮」蓋過「青石鎮藥鋪」）；
    未知地點必須是像樣的名字（2–12 個中文字、不含「附近」「某個」這類泛稱），否則當成一般探索。
    口語的「去」只認已知地點（「去看看」「去找他」不是移動）。
    """
    text = text or ""
    verb = next((v for v in MOVE_VERBS if v in text), None)
    if verb is None:
        hits = [name for name in known if name and name in going(text)]
        return (max(hits, key=len), True) if hits else None
    after = text[text.index(verb) + len(verb):]
    hits = [name for name in known if name and name in after]
    if hits:
        return max(hits, key=len), True
    candidate = after
    for ch in _STOP_CHARS:
        candidate = candidate.split(ch)[0]
    for action in _TRAILING_ACTIONS:
        if action in candidate[1:]:
            candidate = candidate[:candidate.index(action, 1)]
    if _NAME_RE.match(candidate) and not any(w in candidate for w in _GENERIC_WORDS) and not candidate.endswith(_SPOTS):
        return candidate, False
    return None


def shortest_path(connections: list[dict], start: str, goal: str) -> tuple[int, list[str]] | None:
    """在已知的連接上找最短路線（無向）。回傳（總公里, 經過的地點）；走不到回傳 None。

    Dijkstra，每個地點最多展開一次，計算量受已知連接數限制。
    """
    graph: dict[str, list[tuple[str, int]]] = {}
    for c in connections:
        graph.setdefault(c["a"], []).append((c["b"], c["distance_km"]))
        graph.setdefault(c["b"], []).append((c["a"], c["distance_km"]))
    queue: list[tuple[int, str, list[str]]] = [(0, start, [start])]
    done: set[str] = set()
    while queue:
        km, here, path = heapq.heappop(queue)
        if here == goal:
            return km, path
        if here in done:
            continue
        done.add(here)
        for there, step in graph.get(here, ()):
            if there not in done:
                heapq.heappush(queue, (km + step, there, path + [there]))
    return None


def distances_from(connections: list[dict], start: str) -> dict[str, int]:
    """從這裡走到每個走得到的地點要幾公里（一次算完，傳聞判斷傳到了沒用，第 10c-3 步）。走不到的不在結果裡。"""
    graph: dict[str, list[tuple[str, int]]] = {}
    for c in connections:
        graph.setdefault(c["a"], []).append((c["b"], c["distance_km"]))
        graph.setdefault(c["b"], []).append((c["a"], c["distance_km"]))
    found: dict[str, int] = {}
    queue: list[tuple[int, str]] = [(0, start)]
    while queue:
        km, here = heapq.heappop(queue)
        if here in found:
            continue
        found[here] = km
        for there, step in graph.get(here, ()):
            if there not in found:
                heapq.heappush(queue, (km + step, there))
    return found


def neighbors(connections: list[dict], here: str) -> list[dict]:
    """與這裡直接相連的地點（含距離分級、公里、從這裡看的方位）。連接記的方位是 b 在 a 的哪一方，從 b 看就反過來。"""
    found = []
    for c in connections:
        if here in (c["a"], c["b"]):
            d = c.get("direction", "")
            if d and c["a"] != here:
                d = DIRECTIONS[(DIRECTIONS.index(d) + 4) % 8]
            found.append({"name": c["b"] if c["a"] == here else c["a"], "tier": c["tier"], "km": c["distance_km"],
                          "direction": d})
    return sorted(found, key=lambda n: n["km"])


def breadcrumb(parents: dict[str, str], here: str) -> list[str]:
    """由上而下的所屬區域，例如 [玄天州, 青石鎮, 回春藥鋪]。防循環、限制層數。"""
    chain = [here]
    while parents.get(chain[0]) and parents[chain[0]] not in chain and len(chain) < MAX_BREADCRUMB:
        chain.insert(0, parents[chain[0]])
    return chain
