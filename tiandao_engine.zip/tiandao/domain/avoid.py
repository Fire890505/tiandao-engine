"""避開（16l 第 6-3 題）：知道危機在哪就能繞開或躲過。純函式。

規則（2026-10-14 與使用者一題一題定案，見 progress/WHITEPAPER.md 16l，數字暫定）：
- 躲：說避風頭、躲起來……而且匿蹤成功＝這回合找上門的人找不到你。
- 繞：趕路時說繞道、繞開、走小路＝路上多花一半時間；不撞上獸潮（妖獸出沒不加倍）、不硬闖交戰的邊關。
- 闖：說硬闖、闖關才走封閉的邊關（算闖入）；兩種都沒說，game 層先停下來讓玩家選（16m 第 9 題）。
"""
from __future__ import annotations

from . import judgment as J

HIDE_WORDS = ("避風頭", "躲起來", "藏起來", "避一避", "躲一躲", "避開", "躲開")
DETOUR_WORDS = ("繞道", "繞開", "繞路", "走小路", "抄小路", "避開")
DETOUR = 1.5
FORCE_WORDS = ("硬闖", "闖關", "強闖")   # 16m 第 9 題：說了才算硬闖封閉的邊關，沒說就先停下來問


def hiding(verdict, words: str) -> bool:
    return any(w in (words or "") for w in HIDE_WORDS) and any(
        c.target == J.HIDE and c.outcome in (J.SUCCESS, J.GREAT_SUCCESS) for c in verdict.all_checks)


def detour(words: str) -> bool:
    return any(w in (words or "") for w in DETOUR_WORDS)


def forcing(words: str) -> bool:
    return any(w in (words or "") for w in FORCE_WORDS)
