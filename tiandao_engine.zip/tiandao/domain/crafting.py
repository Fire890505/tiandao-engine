"""技藝（第 3b-3 步）：煉丹、煉器。純函式。

規則（2026-10-06 與使用者一題一題定案，見 progress/WHITEPAPER.md 第 6 節「3b-3」，數字暫定）：
- 固定配方：丹方、器方分開列；消耗靈材（藥材煉丹、器材煉器），產出物品表裡現有的東西；AI 只描寫。
- 品階：自動選材料夠用的最高品階，不超過境界；同一爐的材料同一品階。Lv1 才能煉。
- 熟練度（各 0–100）：成功 +3、失敗 +1；每 10 點成功率 +2；入門 0、熟手 30、大師 70 解鎖配方。
- 成敗：大成功兩份、成功一份；失敗損失一半材料（無條件進位）；大失敗材料全毀，扣一成氣血（不致瀕死）。
- 加成：坊市 +10、荒野秘境廢墟 −10；煉丹看火系、煉器看金系或器系取高的（殘理 +5、法則 +10）。
"""
from __future__ import annotations

from dataclasses import dataclass

from . import items, laws
from . import judgment as J


@dataclass(frozen=True)
class Recipe:
    product: str
    materials: dict          # 靈材 → 數量
    skill: int = 0           # 需要的熟練度


PILL_RECIPES = (
    Recipe("回氣丹", {"靈草": 2}),
    Recipe("聚氣丹", {"靈草": 3}, 30),
    Recipe("續命丹", {"靈草": 2, "妖丹": 2}, 30),
    Recipe("破境丹", {"靈草": 3, "妖丹": 3}, 70),
)
GEAR_RECIPES = (
    Recipe("精鐵短刀", {"靈礦": 2, "獸骨": 1}),
    Recipe("明目鏡", {"靈礦": 1, "獸骨": 2}, 30),
)
RECIPES = {J.ALCHEMY: PILL_RECIPES, J.FORGE: GEAR_RECIPES}
LAW = {J.ALCHEMY: ("火系",), J.FORGE: ("金系", "器系")}   # 煉器金或器都算，取高的（新系改接對照 Q2 丙）
BROKEN = {J.ALCHEMY: "炸爐", J.FORGE: "器胚崩裂"}
RANKS = ((70, "大師"), (30, "熟手"), (0, "入門"))
SKILL_GAIN = {J.GREAT_SUCCESS: 3, J.SUCCESS: 3, J.FAILURE: 1, J.GREAT_FAILURE: 1}
MAX_SKILL, SKILL_STEP, SKILL_BONUS = 100, 10, 2
PLACE_BONUS = {"坊市": 10, "荒野": -10, "秘境": -10, "廢墟": -10}
BROKEN_HP = 0.1
VERBS = ("煉", "鍛", "鑄", "打造", "製")


def nature_of(text: str) -> str:
    """「煉製回氣丹」「鍛造精鐵短刀」：有煉製的動詞又點名了配方 → 煉丹或煉器；否則空字串。"""
    if not any(v in text for v in VERBS):
        return ""
    return next((craft for craft, recipes in RECIPES.items() for r in recipes if r.product in text), "")


def recipe_in(craft: str, text: str) -> str:
    return next((r.product for r in RECIPES[craft] if r.product in (text or "")), "")


def _recipe(craft: str, product: str) -> Recipe:
    return next(r for r in RECIPES[craft] if r.product == product)


def rank(level: int) -> str:
    return next(name for floor, name in RANKS if level >= floor)


def tier_for(sheet: dict, recipe: Recipe) -> int | None:
    """材料夠用的最高品階（不超過境界）；都不夠回傳 None。"""
    usable = [t for t in items.TIER_LABELS if t <= sheet["realm_lv"]
              and all(items.count(sheet, m, t) >= n for m, n in recipe.materials.items())]
    return max(usable, default=None)


def materials_text(recipe: Recipe) -> str:
    return "＋".join(f"{m}×{n}" for m, n in recipe.materials.items())


def problem(sheet: dict, craft: str, product: str) -> str:
    """煉不了的原因（不擲骰）；空字串＝可以。"""
    if sheet["realm_lv"] < 1:
        return f"凡人感應不到靈氣，無法{craft}"
    if not product:
        example = RECIPES[craft][0].product
        return f"要說出{craft}煉什麼（例如「煉製{example}」）"
    recipe = _recipe(craft, product)
    if sheet["craft_skill"][craft] < recipe.skill:
        return f"{craft}熟練度不足（{product}要{rank(recipe.skill)} {recipe.skill}）"
    if tier_for(sheet, recipe) is None:
        return f"材料不夠：{product}要{materials_text(recipe)}（同一品階，不高於境界）"
    return ""


def bonus(sheet: dict, craft: str, place_type: str) -> int:
    """成功率加成：熟練度、地點、法則。"""
    mine = laws.held(sheet)
    return (sheet["craft_skill"][craft] // SKILL_STEP * SKILL_BONUS + PLACE_BONUS.get(place_type, 0)
            + max(laws.BONUS.get(mine.get(s, ""), 0) for s in LAW[craft]))


def outcome(sheet: dict, craft: str, product: str, result: str) -> tuple[dict, list[str], float]:
    """套用煉製結果。回傳（角色卡, 事實, 要扣的氣血比例）。"""
    recipe = _recipe(craft, product)
    tier = tier_for(sheet, recipe)
    lost = {m: (n if result != J.FAILURE else -(-n // 2)) for m, n in recipe.materials.items()}
    if result == J.FAILURE:
        events = [f"{craft}失敗：損失{'、'.join(f'{m}×{n}' for m, n in lost.items())}"]
    elif result == J.GREAT_FAILURE:
        events = [f"{craft}大失敗：{BROKEN[craft]}，材料全毀"]
    else:
        made = 2 if result == J.GREAT_SUCCESS else 1
        events = [f"{craft}{result}：煉成{items.label(product, tier)}" + (f"×{made}" if made > 1 else "")]
    for m, n in lost.items():
        sheet = items.remove(sheet, m, tier, n)
    if result in (J.SUCCESS, J.GREAT_SUCCESS):
        sheet = items.add(sheet, product, tier, 2 if result == J.GREAT_SUCCESS else 1)
    before = sheet["craft_skill"][craft]
    after = min(MAX_SKILL, before + SKILL_GAIN[result])
    sheet = {**sheet, "craft_skill": {**sheet["craft_skill"], craft: after}}
    if rank(after) != rank(before):
        events.append(f"{craft}熟練度提升到{rank(after)}")
    return sheet, events, BROKEN_HP if result == J.GREAT_FAILURE else 0.0


# ── 角色卡與畫面 ─────────────────────────────────────────────────────────
def new_skills() -> dict:
    return {J.ALCHEMY: 0, J.FORGE: 0}


def valid(sheet: dict) -> bool:
    skills = sheet["craft_skill"]
    return (isinstance(skills, dict) and set(skills) == set(RECIPES)
            and all(isinstance(v, int) and not isinstance(v, bool) and 0 <= v <= MAX_SKILL for v in skills.values()))


def panel(sheet: dict) -> dict:
    """「可煉丹」「可煉器」：每個配方的材料、要的熟練度、現在能不能煉（不能的原因）。"""
    return {craft: {"level": sheet["craft_skill"][craft], "rank": rank(sheet["craft_skill"][craft]),
                    "recipes": [{"product": r.product, "materials": materials_text(r), "skill": r.skill,
                                 "problem": problem(sheet, craft, r.product)} for r in recipes]}
            for craft, recipes in RECIPES.items()}
