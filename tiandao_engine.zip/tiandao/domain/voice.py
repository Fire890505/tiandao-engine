"""說話那一行（第 7-1d 批，WHITEPAPER 第 7-1-9、7-1-11、7-1-16 題甲；詞池草稿 progress/特點口頭禪草稿.md）。純函式。

- 特點 1～2 個、口頭禪三成的人有：Python 從手寫詞池擲，存著（npcs.quirks、catchphrase）；模型不寫、不提新的。
- 組那一行：文白（學識）→ 稱呼和姿態（地位差）→ 偏得最明顯的兩項性格 → 特點 → 口頭禪。中間的不寫。
- 口頭禪初見那回合和每三回合放一次，寫明最多用一次；同一個地方的人不重複；稱呼型只在你的地位不比他高時放。
- 敬稱知道你是誰才加姓（見過、或這裡有人聽過你）；易容、魔族沒有姓一律「這位」。
"""
from __future__ import annotations

import random

from . import era, learn, npc, rank

PLAIN = ("說話直白、用土話，聽不懂文縐縐的話", "", "說話偶爾帶一兩句成語", "說話文雅，愛引經據典", "引的典故冷僻，常扯到古文、異族的說法")
LEAN = {   # 性格 → （低, 高）
    "ambition": ("什麼都說「夠用就好」", "句句帶著盤算，三句不離好處"), "kindness": ("說話冷，不管別人死活", "說話軟，先替別人著想"),
    "courage": ("說話小聲，看人臉色", "說話直衝，不怕得罪人"), "suspicion": ("你說什麼他都信", "反覆問你的來意，不輕易接話"),
    "tolerance": ("翻舊帳，記著誰欠他", "舊事一笑帶過"), "discretion": ("愛講別人的事，話多", "問什麼答一半")}
QUIRKS = {
    "愛面子": "被說破就改口說「我本來就知道」", "死要面子": "手頭再緊也搶著付帳", "愛擺架子": "說話慢半拍，等別人先開口",
    "怕被看不起": "別人一笑就以為在笑他",
    "寡言": "一句話只說半句", "嘮叨": "同一件事講三遍", "話中帶刺": "好話也要捎一句酸的", "愛講古": "開口就是「從前」",
    "嘴硬": "明知理虧也不認", "刀子嘴豆腐心": "罵完又偷偷幫忙", "愛抬槓": "你說東他偏說西", "說話繞彎": "正事放在最後一句",
    "愛說教": "三句不離「做人要……」",
    "精打細算": "什麼都講到錢，記著小帳", "潔癖": "碰過的東西要擦一擦", "貪吃": "聊著聊著就聊到吃的", "貪杯": "身上帶酒味，話離不開酒",
    "愛賭兩把": "什麼都要賭一賭", "早睡早起": "天一黑就趕人", "夜貓子": "白天哈欠連連",
    "迷信": "做事前看黃曆、說吉利話", "凡事擲筊": "拿不定主意就問神", "不信鬼神": "聽到鬧鬼就嗤笑", "拜很多神": "身上掛著好幾個平安符",
    "怕老婆": "三句提到「我家那口子」", "疼孩子": "話題總繞回自家孩子", "愛管閒事": "別人的事也要插一句", "自來熟": "頭一回見就稱兄道弟",
    "怕生": "跟生人說話不看人眼睛",
    "愛操心": "一直叮嚀你小心", "悲觀": "什麼都往壞處想", "樂天": "天塌下來也笑", "愛逞強": "做不到也說「小事」",
    "優柔寡斷": "問他什麼都說「再看看」", "一根筋": "認定的事九頭牛拉不回",
    "怕冷": "大熱天也裹著衣服", "怕水": "不肯靠近河邊", "暈血": "見血就臉白", "手腳不乾淨": "順手摸走小東西"}
ADULT = ("貪杯", "愛賭兩把", "怕老婆", "疼孩子", "手腳不乾淨")   # 小孩不抽
MALE = ("怕老婆",)
TONE = ("嘿", "唉呀", "得嘞", "嘖嘖", "好說好說", "可不是嘛", "怪了怪了", "罷了罷了")
FORM = ("說句不好聽的", "我跟你講", "這事兒吧", "不是我說", "你聽我的", "依我看", "話說回來")
CALL = ("小兄弟", "後生", "老弟")
HER = {"小兄弟": "小姑娘", "老弟": "後生"}   # 主角是女的
LINGO = {   # 職業或修行那一組（profile.GROUPS）→ 行話
    "掌櫃": "帳要算清楚", "店小二": "客官裡邊請", "小販": "便宜賣你了", "帳房": "一筆是一筆", "腳夫": "力氣活嘛",
    "賣藝人": "有錢捧個錢場", "廚子": "火候到了", "大夫": "病從口入", "藥童": "師父說過", "鐵匠": "趁熱打鐵", "學徒": "趁熱打鐵",
    "朝奉": "東西是好東西", "衙役": "王法在上", "書吏": "照規矩辦", "鏢師": "出門在外平安為上", "趟子手": "出門在外平安為上",
    "武師": "拳腳上見真章", "管事": "這得問上頭", "夥計": "這得問上頭", "農戶": "看天吃飯", "獵戶": "山有山的規矩",
    "木匠": "差一分都不行", "守祠人": "祖宗看著呢", "雜役": "我就是個打雜的", "宗門上層": "門規如此", "宗門弟子": "師尊說過",
    "散修": "修行靠自己", "隱修": "山中無甲子", "遊方": "有緣有緣", "遊俠": "路見不平", "辦事": "拿人錢財與人消災"}
FAITH = {"佛門": "阿彌陀佛", "道觀": "福生無量天尊"}   # 宗門道統
FOLK, SAGE = ("老天爺保佑", "菩薩保佑", "祖宗保佑"), "天道有眼"   # 特點迷信、拜很多神；修士
CHANCE, EVERY = 0.3, 3


def roll(rng: random.Random, p: dict, *, adult: bool, era_now: str, group: str = "", path: str = "", taken=()) -> dict:
    """擲特點、口頭禪：group＝修行那一組；path＝宗門道統；taken＝同一個地方的人已有的口頭禪。"""
    pool = [q for q in QUIRKS if (adult or q not in ADULT) and (p.get("gender") == "男" or q not in MALE)]
    quirks, lucky = rng.sample(pool, rng.randint(1, 2)), rng.random() < CHANCE
    faith = (*([FAITH[path]] if path in FAITH else []), *(FOLK if {"迷信", "拜很多神"} & set(quirks) else ()), *([SAGE] if p["realm_lv"] else []))
    kinds = [TONE, FORM, faith] + ([CALL, [LINGO[k] for k in (p.get("job", ""), group) if k in LINGO]] if era_now == era.ANCIENT else [])
    kinds = [w for w in ([x for x in k if x not in taken] for k in kinds) if w]
    return {"quirks": quirks, "catchphrase": rng.choice(rng.choice(kinds)) if lucky and kinds else ""}


def honour(me: int, *, female: bool, minor: bool, sage: bool, era_now: str, stance: str, surname: str) -> str:
    """叫你的敬稱（me：你的地位）；surname 空字串＝不知道你是誰，照表上寫。"""
    if era_now != era.ANCIENT:
        word = "大師" if sage and stance == era.OPEN else "小姐" if female else "先生"
    elif sage and stance in ("", era.OPEN):
        word = "仙子" if female else "仙長"
    elif me >= rank.GENTRY:
        word = ("小姐" if minor else "夫人") if female else "老爺"
    elif me == rank.DECENT:
        word = "姑娘" if female else "爺"
    else:
        return (surname or "這位") + ("大姐" if female else "兄弟")
    return surname + word


def manner(gap: int, title: str, female: bool) -> str:
    """稱呼和姿態：gap＝他的地位 − 你的。"""
    if gap == 0:
        return ""
    if gap > 0:
        return "直呼你，居高臨下，不太正眼看你" if gap >= 2 else f"叫你「{'小姑娘' if female else '小兄弟'}」，口氣端著"
    return f"叫你「{title}」，" + ("說話客氣" if gap == -1 else "恭恭敬敬、說話小心")


def line(p: dict, *, gap: int, title: str, female: bool, show: bool, kin: bool = False) -> str:
    """一個人的說話：show＝這回合放口頭禪；kin＝主角的家人（不講地位）。"""
    lean = sorted((t for t in LEAN if npc.trait_level(p.get(t, 50)) != "中"), key=lambda t: -abs(p[t] - 50))[:2]
    said = p.get("catchphrase", "") if show and (p.get("catchphrase") not in CALL or gap >= 0) else ""
    said = HER.get(said, said) if female else said
    parts = (PLAIN[learn.level(p)], "" if kin else manner(gap, title, female), "，".join(LEAN[t][p[t] >= 50] for t in lean),
             "、".join(f"{q}（{QUIRKS[q]}）" for q in p.get("quirks", ()) if q in QUIRKS),
             f"口頭禪『{said}』（最多用一次）" if said else "")
    return "；".join(x for x in parts if x)


def valid(p: dict) -> bool:
    q = p["quirks"]
    return isinstance(q, list) and len(q) <= 2 and all(x in QUIRKS for x in q) and isinstance(p["catchphrase"], str) and len(p["catchphrase"]) <= 8
