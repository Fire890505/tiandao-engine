"""命落在哪一宮（第 129 系列，細節 progress/命途重設計.md 第九節；數字暫定）。純函式。

- 分宮（第 129-1 題）：從「此人」的角度把認識的人排進十二宮，主角和 NPC 同一個函式（第 129-9 題）。
  一人只在一宮，立約近身的優先（ORDER）；隔一層的長輩（愛人的長輩、師祖）進同一宮、權重減半；死了留原宮標已故；
  只有帳的人：欠錢人情進財帛、記恨進交友；不認識的人不進宮。
- 抽宮（第 129-2、129-3 題）：只抽這種命能落的宮，分數＝宮裡的人，命宮、疾厄、福德看對宮（第 129-4 題）；
  大限、順著的同宮、放著的對宮各 ×2。
羈絆照 society：{a, b, type}＝a 是 b 的〔type〕；主角那方寫那一生。
"""
from __future__ import annotations

import random

from . import society
from .stage import ALONG, LEFT
from .clock import SHICHEN_PER_YEAR

PALACES = ("命宮", "兄弟", "夫妻", "子女", "財帛", "疾厄", "遷移", "交友", "官祿", "田宅", "福德", "父母")   # 紫微排法
OPPOSITE = dict(zip(PALACES, PALACES[6:] + PALACES[:6]))   # 隔六宮相對：命宮↔遷移、兄弟↔交友……
SELF = ("命宮", "疾厄", "福德")   # 宮裡沒有別人，命主從對宮來
ORDER = ("夫妻", "父母", "子女", "兄弟", "交友", "官祿", "財帛")   # 一人兩種關係時先算哪一宮
WHERE = {"戀人": "夫妻", "伴侶": "夫妻", "師父": "父母", "徒弟": "子女", "結義": "兄弟", "同門": "兄弟",
         "友人": "交友", "仇家": "交友", "奴": "交友", "僕": "交友", "主人": "交友", "恩人": "財帛"}   # 對方是我的〔種類〕
GRUDGE = (society.FEUD, society.HUNT, society.HIRED)   # 帳上記恨的進交友，其餘（恩、債、封口）進財帛
GEN = 15          # 親人大幾歲算長輩、小幾歲算晚輩
HALF = 0.5        # 隔一層的人
EMPTY = 0.5       # 沒人的宮照模板新來
TWICE = 2         # 大限、順著、放著
GHOSTS = "聞冥命"  # 已故的人只有這種命算進分數


def _ties(bonds: list[dict], me: str):
    """（對方, 對方是我的什麼）。人對勢力的不算。"""
    for b in bonds:
        if b["type"] in society.MEMBER_BONDS + society.FACTION_BONDS:
            continue
        if b["b"] == me:
            yield b["a"], b["type"]
        elif b["a"] == me:
            yield b["b"], society.INVERSE.get(b["type"], b["type"])


def _where(kind: str, mine: int | None, theirs: int | None) -> str:
    if kind != "親人":
        return WHERE.get(kind, "")
    gap = (theirs - mine) / SHICHEN_PER_YEAR if mine is not None and theirs is not None else 0
    return "父母" if gap <= -GEN else "子女" if gap >= GEN else "兄弟"


def _place(bonds: list[dict], me: str, births: dict) -> dict[str, str]:
    best: dict[str, str] = {}
    for who, kind in _ties(bonds, me):
        p = _where(kind, births.get(me), births.get(who))
        if p and who != me and (who not in best or ORDER.index(p) < ORDER.index(best[who])):
            best[who] = p
    halls = {b["b"] for b in bonds if b["a"] == me and b["type"] in society.MEMBER_BONDS}
    for b in bonds:   # 自己勢力的首領進官祿
        if b["type"] == "首領" and b["b"] in halls and b["a"] != me:
            best.setdefault(b["a"], "官祿")
    return best


def felt(relations: dict, life: str) -> list[dict]:
    """好感算出的友人仇家（第 129-1 題）：外人要好感到友人才算，敵視的都算。"""
    return [{"a": n, "b": life, "type": "友人" if r["affinity"] >= society.FRIEND_AT else "仇家"} for n, r in relations.items()
            if r["affinity"] <= society.FOE_AT or r["affinity"] >= society.FRIEND_AT and r["circle"] != society.STRANGER]


def split(me: str, bonds: list[dict], ledger: list[dict], births: dict, dead: set[str]) -> dict[str, list[tuple[str, float, bool]]]:
    """十二宮：宮 → [(名字, 權重, 已故)]。births：名字 → 出生時辰（不詳 None）；ledger 只算沒了結的。"""
    best = _place(bonds, me, births)
    for l in ledger:   # 帳的另一方是勢力、空著（不知道是誰）不進宮：宮裡只放人
        other = l["b"] if l["a"] == me else l["a"]
        if l["status"] == society.OPEN and me in (l["a"], l["b"]) and other in births:
            best.setdefault(other, "交友" if l["kind"] in GRUDGE else "財帛")
    out: dict[str, list] = {p: [] for p in PALACES}
    for who, p in best.items():
        out[p].append((who, 1.0, who in dead))
    for who, p in list(best.items()):   # 隔一層：愛人、長輩的長輩
        if p in ("夫妻", "父母"):
            out[p] += [(n, HALF, n in dead) for n, q in _place(bonds, who, births).items() if q == "父母" and n not in best and n != me]
    return out


def who(board: dict, p: str) -> list[str]:
    """這一宮還活著的人，權重高的在前；命宮、疾厄、福德看對宮。"""
    return [n for n, w, gone in sorted(board[OPPOSITE[p] if p in SELF else p], key=lambda x: -x[1]) if not gone]


def score(board: dict, p: str, fate: str) -> float:
    """這一宮的分數：宮裡的人（已故只有聞冥命算），沒人照模板新來。"""
    n = sum(w for _, w, gone in board[OPPOSITE[p] if p in SELF else p] if not gone or fate == GHOSTS)
    return n or EMPTY


def draw(rng: random.Random, board: dict, allowed: list[str], fate: str, boost: list[str]) -> str:
    """抽這一章落哪一宮。allowed：這種命能落的宮；boost：要 ×2 的宮（同一宮出現兩次就 ×4）。"""
    return rng.choices(allowed, weights=[score(board, p, fate) * TWICE ** boost.count(p) for p in allowed])[0]


def boost(last_end: str, last_palace: str, decade_now: str) -> list[str]:
    """大限宮，加上上一章怎麼收場（第 129-3 題）：順著同宮、放著對宮；抗著靠命主（routes._heir）不加宮。"""
    by_end = {ALONG: last_palace, LEFT: OPPOSITE.get(last_palace, "")}.get(last_end, "")
    return [p for p in (decade_now, by_end) if p]


def born(rng: random.Random) -> dict:
    """出生排大限：起點宮、順逆（第 129-2 題，簡化版）。"""
    return {"decade_from": rng.randrange(len(PALACES)), "decade_step": rng.choice((1, -1))}


def decade(sheet: dict, age: int) -> str:
    """這十年走到哪一宮。"""
    return PALACES[(sheet["decade_from"] + sheet["decade_step"] * (age // 10)) % len(PALACES)]
