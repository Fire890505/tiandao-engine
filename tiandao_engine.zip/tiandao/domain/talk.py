"""NPC 的話（WHITEPAPER 16v 第 65、65-1 題）：眼前的人這回合講什麼。純函式，內容在 rules/content/talk.txt（話題牌，第 4-3 題）。

- 順序照 ORDER（第 126-10 題）：手上的事 → 跟你有關的聽說 → 人際 → 重逢近況 → 往事 → 傳聞 → 常識牌（第 9b 批）→ 職業日常。
  背景把玩家帶進主線，後面的都是支線（第 65-2 題）。人際、近況第 9d、9f 批才有句子；舊聞照舊走 game/news（第 8-4 批）。
- 講過的不重複，全講完才重來。往事開局依家運抽一段，分三層；要主角開口問，隔 GAP 回合才往下一層。
- 往事講完變成支線（第 76 題）：side 是 sides.txt 的鍵，town、near 是開局定的地方，asked 是開過口了。
角色卡欄位：past（lines 三層、told 講到第幾層、turn 上次講的回合、side、town、near、asked）、said（講過的傳聞和日常）。
"""
from __future__ import annotations

import random
import re

from ..config import PROJECT_ROOT
from . import deck, opinion

COMMON = "通用"
GAP, KEEP = 2, 40
PAST, DAILY = "往事", "日常"
ORDER = ("手上", "聽說", "人際", "心事", "近況", PAST, "傳聞", "常識", DAILY)   # 第 126-10 題的同分順序；心事接在人際後（第 9e 批）；⑦ 職業那格先講常識牌（第 9b 批）
HAS = {"怪談": "怪談地", "災": "災", "國事": "國事", "關押": "某人", "秘境": "秘境", "傳說": "傳說地", "幽魂": "亡者", "荒野": "荒野",
       "勢力": "勢力", "地方": "地方", "打壓": "打壓", "通緝": "犯事地"}   # 常識牌「有:」→ 有這個字才算有（game/talks.common）
_SLOT = re.compile(r"\{(\w+)\}")
ORIGIN_JOB = {"農戶子弟": "農戶", "獵戶": "獵戶", "小商販": "小販"}   # 家人的職業看主角出身


CONTENT = PROJECT_ROOT / "rules" / "content"
TOPICS = deck.read(CONTENT / "talk.txt")   # 話題牌（第 4-3 題）：種類是背景、往事、職業，內容欄是要講的幾句
_lines = lambda c: [c.text, *c.more]
MAINS = {dict(c.need)["路線"]: _lines(c) for c in TOPICS if c.kind == "背景"}
PASTS: dict[str, list] = {}
for _c in TOPICS:
    if _c.kind == "往事":
        PASTS.setdefault(dict(_c.need)["家運"], []).append(_lines(_c))
JOBS = {dict(c.need).get("職業") or dict(c.need).get("修行") or COMMON: _lines(c) for c in TOPICS if c.kind == "職業"}   # 修行組（第 7-1a 批）跟職業同一張表


COMMONS = [c for c in TOPICS if c.kind == "常識"]
TIES = [c for c in TOPICS if c.kind == "人際"]
WHY = {opinion.HELP: "幫了{對}一把", opinion.GIFT: "送了{對}東西", opinion.SAVE: "救過{對}一命", opinion.CARE: "照顧過{對}",
       opinion.EVEN: "跟{對}有來有往", opinion.BEFRIEND: "跟{對}越走越近", opinion.KEEP: "對{對}說到做到", opinion.TRUTH: "跟{對}說了實話",
       opinion.INSULT: "當眾給{對}難看", opinion.ATTACK: "對{對}動過手", opinion.ROB: "搶過{對}的東西", opinion.SHAME: "害{對}丟了臉",
       opinion.BREAK: "對{對}說話不算話", opinion.LIE: "騙了{對}", opinion.BETRAY: "背叛了{對}", opinion.FEUD: "跟{對}結了梁子",
       opinion.SNUB: "在{對}有難時沒幫"}   # 好感原因（甲對乙，乙做的事）→ 人際牌的 {原因}（第 9-19 題）；{對}＝我、他


def _fill(cards: list, facts: dict, words: dict) -> list[list[str]]:
    """對得上、字湊得齊的牌，條件多的在前；每張是（第一句, 追問才講的第二句）。"""
    ok = [c for c in cards if deck.fits(c, facts) and set(_SLOT.findall("".join(_lines(c)))) <= set(words)]
    return [[l.format(**words) for l in _lines(c)] for c in sorted(ok, key=lambda c: -len(c.need))]


def commons(circle: str, words: dict) -> list[list[str]]:
    """常識牌（第 9-15 題）：這個圈的。"""
    return _fill(COMMONS, {"圈": {circle}, "有": {k for k, v in HAS.items() if v in words}, "季節": {words.get("季節", "")}}, words)


def ties(found: list[tuple[dict, dict]]) -> list[list[str]]:
    """人際牌（第 9-19、9-20 題）：found 照先後排好的（條件, 字），一個人一張。"""
    return [x for facts, words in found for x in _fill(TIES, facts, words)[:1]]


def fields() -> dict:
    return {"past": {"lines": [], "told": 0, "turn": 0, "side": "", "town": "", "near": "", "asked": False}, "said": []}


def past(rng: random.Random, sheet: dict, town: str, near: str) -> dict:
    """開局抽一段往事，填真的地名。沒有家運就沒有往事。"""
    if not sheet["fortune"]:
        return {**sheet, "past": fields()["past"]}
    i = rng.randrange(len(PASTS[sheet["fortune"]]))
    return {**sheet, "past": {**fields()["past"], "lines": [l.format(鎮=town, 鄰地=near) for l in PASTS[sheet["fortune"]][i]],
                              "side": f"{sheet['fortune']}{i + 1}", "town": town, "near": near}}


def pick(rng: random.Random, sheet: dict, turn_no: int, *, kin: bool, asked: bool, job: str, offers: dict | None = None) -> tuple[dict, str]:
    """這回合要講的事：回傳（角色卡, 內容）。kin：是家人。asked：主角開口問。
    offers：ORDER 各格現成的句子（{格: [句, …]}），照順序講第一句沒講過的；往事、日常這裡自己算。"""
    p, said = sheet["past"], sheet["said"]
    for slot in ORDER[:-1]:   # 最後一格日常輪著講
        if slot == PAST:
            if kin and asked and p["told"] < len(p["lines"]) and (not p["told"] or turn_no - p["turn"] >= GAP):
                return {**sheet, "past": {**p, "told": p["told"] + 1, "turn": turn_no}}, p["lines"][p["told"]]
            continue
        line = next((l for l in (offers or {}).get(slot, ()) if l and l not in said), "")
        if line:
            return {**sheet, "said": [*said, line][-KEEP:]}, line
    lines = JOBS.get(job) or JOBS[COMMON]
    left = [l for l in lines if l not in said]
    if not left:
        said, left = [s for s in said if s not in lines], lines
    line = rng.choice(left)
    return {**sheet, "said": [*said, line][-KEEP:]}, line


def valid(sheet: dict) -> bool:
    p = sheet["past"]
    return (isinstance(p, dict) and isinstance(p.get("lines"), list) and all(isinstance(l, str) for l in p["lines"])
            and isinstance(p.get("told"), int) and isinstance(p.get("turn"), int)
            and isinstance(sheet["said"], list) and all(isinstance(s, str) for s in sheet["said"]))
