"""儀式型完整版（2026-10-11 定案，WHITEPAPER 第 16d 節 19-3「儀式型完整版」）。純函式。

儀式型的規則怪談不再直接出事，而是先有一筆「流傳中的玩法」：
- 流傳（SPREAD）：某個城鎮或村落流傳錯的玩法；源頭在流傳地相連的一個地點。next＝下一次挑動心的人
  （開始後 1～3 個月；沒有合適的人就下個月再挑）。流傳滿一年沒人做就淡掉。
- 準備（READY）：住在流傳地的一個人動心了（沿用 domains.doer）。next＝他做儀式的那一夜（約一個月後）；
  沒人攔就出事（照 19-1：他重傷、困在做儀式的地方、三個月期限）。
- 主角：在源頭探索成功＝這一生知道正確玩法（known）；再寫燒、撕、刪、改＝斷根（準備中的人照樣準備，這一夜過了就結束）。
  準備中：交談成功＝勸住，潛行成功＋拿走、偷、藏＝延後一個月。當夜在場：知道正確玩法、寫出正確的收尾＝平安結束。
- NPC：準備中的人的親近的人每月可能勸住他；出事後，親近又境界夠的修士每月可能去救。
數字都是暫定。
"""
from __future__ import annotations

import random

from . import opinion
from .clock import SHICHEN_PER_MONTH, SHICHEN_PER_YEAR
from .tales import Tale, theme

SPREAD, READY, CUT, FADED, DONE = "流傳", "準備", "斷根", "淡掉", "出事"
STAGES = (SPREAD, READY, CUT, FADED, DONE)
ACTIVE = (SPREAD, READY)
TOWN_TYPES = ("城鎮", "村落")                 # 流傳地
SPREAD_MONTHS = (1, 3)
PREP = SHICHEN_PER_MONTH                      # 動心到做儀式
DELAY = SHICHEN_PER_MONTH                     # 道具被拿走，延後
LASTS = SHICHEN_PER_YEAR                      # 流傳多久沒人做就淡掉
CUT_WORDS = ("燒", "撕", "刪", "改")
TAKE_WORDS = ("拿走", "偷", "藏")
CLOSE = ("親人", "伴侶", "友人", "師父", "徒弟")   # 會勸他、會去救他的人
TALK_CHANCE = 0.1                              # 親近的人每月勸住：×（善念＋膽識）÷100
RESCUE_CHANCE, RESCUE_WIN = 0.1, 0.5           # 親近的修士每月去救；救成的機會
CALM_INSIGHT = 3                               # 當夜照正確玩法平安收尾的感悟
CALM = [opinion.hit(opinion.HELP, opinion.LIKE, opinion.BIG)]   # 當夜收尾：幫忙（大）


def make(rng: random.Random, *, tale: Tale, place: str, town: str, neighbors: dict[str, list[str]],
         clock_now: int) -> dict | None:
    """開始流傳。源頭＝流傳地相連的一個地點（不是做儀式的地方）；沒有就不流傳。"""
    sources = sorted(n for n in neighbors.get(town, []) if n != place)
    if not sources:
        return None
    return {"tale": tale.name, "town": town, "source": rng.choice(sources), "place": place, "stage": SPREAD,
            "person": "", "cut": False, "known": "", "created_shichen": clock_now, "ended_shichen": None,
            "next_shichen": clock_now + rng.randint(*SPREAD_MONTHS) * SHICHEN_PER_MONTH}


def town_of(place: dict, locations: list[dict]) -> str:
    """流傳地：做儀式的地方所在的城鎮或村落（它本身就是村落時就是它）。"""
    up = next((l for l in locations if l["name"] == place["parent"]), None)
    return up["name"] if up and up["type"] in TOWN_TYPES else place["name"]


def area(town: str, locations: list[dict]) -> set[str]:
    """流傳地與它底下的地點：住在這裡的人聽得到這個玩法。"""
    return {town} | {l["name"] for l in locations if l["parent"] == town}


def wrong(rite: dict) -> str:
    """流傳的（錯的）收尾方式：每個儀式型主題都有一條 always 規則。"""
    return next(r.text for r in theme(rite["tale"]).rules if r.always)


def right(rite: dict) -> str:
    return next(r.truth for r in theme(rite["tale"]).rules if r.always)


def finish(rite: dict) -> tuple[str, ...]:
    """正確收尾的字詞：主題破解最後一步的字詞。"""
    return theme(rite["tale"]).steps[-1].ways[0].words


def chance(p: float, months: int) -> float:
    """每月 p，跨過 months 個月至少發生一次。"""
    return 1 - (1 - p) ** max(0, months)


def talk_chance(p: dict) -> float:
    return TALK_CHANCE * (p["kindness"] + p["courage"]) / 100


def back_to_spread(rite: dict, clock_now: int) -> dict:
    """準備中的人放棄了（被勸住、當夜平安收尾）：斷了根的就結束，否則玩法照樣流傳，下個月再挑人。"""
    if rite["cut"]:
        return {**rite, "stage": CUT, "person": "", "ended_shichen": clock_now}
    return {**rite, "stage": SPREAD, "person": "", "next_shichen": clock_now + SHICHEN_PER_MONTH}


def end(rite: dict, stage: str, clock_now: int) -> dict:
    return {**rite, "stage": stage, "ended_shichen": clock_now}


def valid(r: dict, places: set[str], npc_names: set[str]) -> bool:
    """存檔檢查（known 由存檔另外檢查）。"""
    tale = theme(r["tale"]) if isinstance(r["tale"], str) else None
    return (tale is not None and bool(tale.doer) and all(r[k] in places for k in ("town", "source", "place"))
            and r["stage"] in STAGES and (r["person"] == "" or r["person"] in npc_names)
            and (r["stage"] != READY or r["person"]) and (r["stage"] != SPREAD or not r["person"])
            and isinstance(r["cut"], bool)
            and isinstance(r["next_shichen"], int) and not isinstance(r["next_shichen"], bool)
            and (r["ended_shichen"] is None) == (r["stage"] in ACTIVE))
