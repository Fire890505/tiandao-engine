"""亡者（第 11-2 步）：死者的後續——幽魂與屍變。純函式，不碰資料庫、不呼叫 AI。

規則（2026-10-06 與使用者一題一題定案，見 progress/WHITEPAPER.md 第 3 節「第 11 步」11-2，數字暫定）：
- 誰：前世的主角一定會（含退隱後才死的）；Lv3 以上的 NPC 死在荒野、秘境、廢墟一半、其他地方一成。同一地點最多一個。
- 形態：有執念（恩怨對象還活著、約定沒兌現）→ 幽魂；其他 → 屍變。等級不存，依生前境界 × 死了多久算。
- 平時是地點上的異象；在那裡探索、休息、閉關時可能現身（白天兩成、夜裡四成），現身後主角沒離開就一直在場。
- 交手照對 NPC 動手（傷勢 無恙 → 負傷 → 重傷 → 消散）；幽魂說出執念開線頭，了結就安息。
- 魂魄去處（第 7-5b 批，124-7、7-5-5 題）：變亡者＝留；沒變的 NPC 死時還有帳或羈絆（有結可接）進待投胎名單，
  其他直接入輪迴不留名；幽魂安息後才進名單，打散的不進；主角（含前世）不進。名單記在帳上，每州 CAP 人，滿了擠掉最舊的。
"""
from __future__ import annotations

from . import judgment as J
from . import realm, society
from .clock import SHICHEN_NAMES, SHICHEN_PER_DAY, SHICHEN_PER_YEAR
from .evolution import AWAY

GHOST, CORPSE = "幽魂", "屍變"
GRUDGE, PROMISE = "恩怨", "約定"
CONDITIONS = ("無恙", "負傷", "重傷", "消散")
GONE = CONDITIONS[-1]
NPC_LV = 3                                # NPC 要這個境界以上死去才可能變成亡者
WILD, WILD_CHANCE, TOWN_CHANCE = ("荒野", "秘境", "廢墟"), 0.5, 0.1
FOE_AT = -50                              # 前世主角的執念：好感這麼低（或記恨）的人還活著
# 屍變的等級：（名稱, 死後多久, 生前境界至少, 戰力修正）；條件不夠就停在前一級
RANKS = (("殘魂", 0, 0, -2), ("遊蕩魂", 90 * SHICHEN_PER_DAY, 0, -1), ("殭屍", SHICHEN_PER_YEAR, 1, 0),
         ("不化骨", 5 * SHICHEN_PER_YEAR, 3, 1), ("屍將", 10 * SHICHEN_PER_YEAR, 5, 1),
         ("屍皇", 30 * SHICHEN_PER_YEAR, 7, 2), ("屍仙", 60 * SHICHEN_PER_YEAR, 9, 2))
GHOST_BONUS = -1
DAY_CHANCE, NIGHT_CHANCE, NIGHT = 0.2, 0.4, "酉戌亥子丑寅"
SPITE, SPITE_MAGNITUDE = "怨念纏身", 40   # 強行打散還有執念的幽魂（一個月，比照心魔纏身）
REST_LAW, REST_INSIGHT = "頭七回魂", 10   # 幽魂安息的回報：魂系的那一條現象（新系改接對照第四節）
WORDS = ("亡者", "幽魂", "屍", "魂", "不化骨")   # 行動裡提到這些字（或生前的名字）就是對他
SIGNS = {CORPSE: "此地陰氣森森，有人夜裡見過遊蕩的影子", GHOST: "此地常有人夢見一個看不清面目的人，低聲訴說著什麼"}
CAP = 50                                  # 每州的待投胎名單（125-9）


def knotted(name: str, ledger: list[dict], bonds: list[dict]) -> bool:
    """死時還有結可接：帳上還有沒了的、或有血緣立約的羈絆（含跟主角的）。"""
    return (any(l["status"] == society.OPEN and name in (l["a"], l["b"]) for l in ledger)
            or any(b["type"] in society.BLOOD + society.PACT and name in (b["a"], b["b"]) for b in bonds))


def wait(name: str, state: str, died: int, when: int) -> dict:
    """待投胎名單的一筆（帳，甲乙＝那一州）。"""
    return {**society.owed(society.WAITING, state, state, when), "body": {"名": name, "死": died}}


def full(ledger: list[dict], state: str) -> list[str]:
    """這一州的名單超過 CAP 要擠掉的（最舊的）id。"""
    rows = sorted((l for l in ledger if l["kind"] == society.WAITING and l["a"] == state and l["status"] == society.OPEN),
                  key=lambda l: l["clock_shichen"])
    return [l["id"] for l in rows[:max(0, len(rows) - CAP)]]


def born(rng, *, name: str, lv: int, place: str, place_type: str, clock_now: int, sure: bool,
         grudge: tuple[str, str], haunted: set[str]) -> dict | None:
    """死者會不會變成亡者。sure：前世的主角；grudge：（執念種類, 對象），沒有是 ("", "")；haunted：已經有亡者的地點。
    死在遠方（沒有登錄的地點）的下落不明，不會變成亡者。有執念的不看境界（幽魂），沒執念的要 NPC_LV 以上（屍變；第十節第 3 題乙）。"""
    chance = WILD_CHANCE if place_type in WILD else TOWN_CHANCE
    if place in haunted or place == AWAY or not (sure or (grudge[0] or lv >= NPC_LV) and rng.random() < chance):
        return None
    return {"name": name, "form": GHOST if grudge[0] else CORPSE, "lv": lv, "died_shichen": clock_now, "place": place,
            "condition": CONDITIONS[0], "grudge": grudge[0], "grudge_on": grudge[1], "awake": False}


def protagonist_grudge(rival: str, relations: dict[str, dict], promised: list[str], alive: set[str]) -> tuple[str, str]:
    """前世主角的執念：宿敵還沒分勝負 > 好感最低的仇人還活著 > 答應的事還沒做到（對象還活著）。relations：名字 → 關係。"""
    foes = sorted((n for n, r in relations.items() if n in alive and (r["affinity"] <= FOE_AT or r["grudge"])),
                  key=lambda n: relations[n]["affinity"])
    owed = [n for n in promised if n in alive]
    if rival in alive:
        return GRUDGE, rival
    return (GRUDGE, foes[0]) if foes else (PROMISE, owed[0]) if owed else ("", "")


TIES = {"復仇": GRUDGE, "守護": PROMISE, "報恩": PROMISE, "追隨": PROMISE}   # 第十節第 3 題乙：守護、報恩、追隨算約定（把話帶給對象）


def npc_grudge(p: dict, alive: set[str]) -> tuple[str, str]:
    """NPC 的執念：目標是復仇、守護、報恩、追隨，對象還活著。"""
    kind = TIES.get(p["goal"], "")
    return (kind, p["goal_target"]) if kind and p["goal_target"] in alive else ("", "")


def here(undead: list[dict], place: str) -> dict | None:
    return next((u for u in undead if u["place"] == place and u["condition"] != GONE), None)


def rank(u: dict, clock_now: int) -> str:
    if u["form"] == GHOST:
        return GHOST
    name = RANKS[0][0]
    for r, after, min_lv, _ in RANKS:
        if clock_now - u["died_shichen"] < after or u["lv"] < min_lv:
            break
        name = r
    return name


def power(u: dict, clock_now: int) -> int:
    """戰力（當成對手的境界）：生前境界＋等級修正。"""
    now = rank(u, clock_now)
    bonus = GHOST_BONUS if u["form"] == GHOST else next(b for r, _, _, b in RANKS if r == now)
    return max(0, min(realm.MAX_LV, u["lv"] + bonus))


def label(u: dict, clock_now: int) -> str:
    return f"{u['name']}的{rank(u, clock_now)}"


def rises(rng, u: dict | None, *, action: str, retreating: bool, clock_now: int, boost: float = 1) -> bool:
    """這回合會不會現身：在他的地點探索、休息或閉關，還沒現身；夜裡（酉時到寅時）機會加倍。boost：命途的倍數。"""
    if u is None or u["awake"] or not (action in (J.EXPLORE, J.REST) or retreating):
        return False
    night = SHICHEN_NAMES[clock_now % SHICHEN_PER_DAY] in NIGHT
    return rng.random() < (NIGHT_CHANCE if night else DAY_CHANCE) * boost


def scene(u: dict, clock_now: int) -> str:
    """現身那回合給說書人的骨架。"""
    if u["form"] == GHOST:
        return (f"（亡者）{label(u, clock_now)}在恍惚中現身：不主動攻擊，只用夢境般的幻象訴說放不下的事（不要說破是什麼事）。"
                "只寫到他現身、主角還沒應對為止；choices 之一要是應對他（交談或觀察）")
    return (f"（亡者）陰氣聚攏，{label(u, clock_now)}現身，帶著生前的殘影撲向主角。"
            "只寫到他現身、主角還沒應對為止；choices 之一要是應對他（戰鬥或避開）")


def line(u: dict, clock_now: int) -> str:
    """聯絡簿裡的亡者（現身時）。"""
    trait = "不主動攻擊，有放不下的執念" if u["form"] == GHOST else "只剩本能，見人就撲"
    return (f"{label(u, clock_now)}（亡者，戰力約{realm.stage_name(power(u, clock_now), 0)}，{u['condition']}；{trait}）"
            "　※不是活人，不要以 npcs 或 npc_updates 提案")


def named(u: dict, player_input: str) -> bool:
    return u["name"] in player_input or any(w in player_input for w in WORDS)


def struck(u: dict, checks: list[tuple[str, str]], clock_now: int) -> tuple[dict, list[str]]:
    """交手：命中成功往下一階、大成功兩階（與對 NPC 動手相同），最後一階是消散。"""
    steps = sum({J.SUCCESS: 1, J.GREAT_SUCCESS: 2}.get(o, 0) for t, o in checks if t == J.STRIKE)
    if not steps:
        return u, []
    after = {**u, "condition": CONDITIONS[min(CONDITIONS.index(u["condition"]) + steps, len(CONDITIONS) - 1)]}
    return after, [f"{label(u, clock_now)}{after['condition']}"]


def wish(u: dict) -> str:
    """幽魂的執念說出口後開的線頭內容（也用來認出這條線頭）。"""
    what = f"了結與{u['grudge_on']}的恩怨" if u["grudge"] == GRUDGE else f"把話帶給{u['grudge_on']}"
    return f"替{u['name']}的幽魂{what}"


def settled(u: dict, *, dead: set[str], told: str, bearer: tuple[str, str] | None = None, rite: str = "") -> bool:
    """執念了結沒：恩怨＝對象死了（不論誰殺的）；約定＝主角跟該帶話的人社交成功（told，而且這一生開了線頭）。
    bearer：（人, 牌位）現在該帶給誰（第 8-4-5 題甲）——對象死了改後人，沒後人改牌位（rite：主角在那裡祭拜），都沒有就安息。"""
    if u["form"] != GHOST or u["condition"] == GONE:
        return False
    if u["grudge"] == GRUDGE:
        return u["grudge_on"] in dead
    who, tablet = bearer or (u["grudge_on"], "")
    return told == who if who else rite == tablet if tablet else True


def bearer_text(u: dict, bearer: tuple[str, str]) -> str:
    """約定的對象不在了，話改帶給誰（說書人看）。"""
    who, tablet = bearer
    return "" if who == u["grudge_on"] else f"{u['grudge_on']}已經不在了，話要改帶給{who}" if who \
        else f"{u['grudge_on']}已經不在了，只能到{tablet}祭拜告知" if tablet else ""


def valid(u: dict, places: set[str]) -> bool:
    """存檔檢查。"""
    return (u["form"] in (GHOST, CORPSE) and u["condition"] in CONDITIONS and u["place"] in places
            and u["grudge"] in ("", GRUDGE, PROMISE) and (u["grudge"] == "") == (u["form"] == CORPSE)
            and (u["grudge"] == "") == (u["grudge_on"] == "") and isinstance(u["awake"], bool))
