"""新生的人帶家人（WHITEPAPER 第 121-1 題丁，實作第一步 121-1 批）。純函式，不碰資料庫。

- 只給住在當地的凡人：事端角色、路線新來的人、奴隸的主人（使用者選甲）。
- 0～2 個家人（權重 4:4:2，平均 0.8）。未成年的只帶父母；成年的從父母、兄弟姊妹、伴侶、孩子挑，年紀合得上：
  父母大 18～40 歲、兄弟姊妹差 0～10 歲、伴侶差 -5～8 歲（都成年）、孩子小 18～40 歲。
- 家人都是凡人，同族同支系，跟他同姓（母親、伴侶另外擲姓；女人的孩子跟伴侶的姓），目標守護他，性格隨機。
  年紀超過凡人壽元的登錄成已故。
- 住處：新開一間住家「碧波驛羅家」（撞名加方位），他本人照舊住原處；奴隸的主人一家住他的宅子（home）。
- 關係：家人跟他是親人（伴侶是伴侶），家人之間：父母是伴侶、伴侶只跟孩子是親人、其他是親人。
"""
from __future__ import annotations

import random

from . import names, newcomer, npc, society, space
from .clock import SHICHEN_PER_YEAR

BY = "kin"                    # NPC 的 created_by：跟著新人一起生的家人
COUNT = {0: 4, 1: 4, 2: 2}    # 帶幾個家人的權重
PARENT, SIBLING, SPOUSE, CHILD = "父母", "兄弟姊妹", "伴侶", "孩子"
SPOTS = ("", "東頭", "西頭", "南邊", "北邊", "坡上", "河邊")


def kin(rng: random.Random, person: dict, *, town: str, clock_now: int, taken: set[str],
        home: str = "") -> tuple[dict | None, list[dict], list[dict]]:
    """回傳（要登錄的住家或 None, 家人, 關係）。taken：已用的人名、地名（會加進去）。"""
    age = npc.age(person, clock_now) or 0
    roles = _roles(age, person.get("gender", ""))
    picks = sorted(rng.sample(roles, min(_pick(rng), len(roles))), key=roles.index)
    race, line = person.get("race") or "人族", person.get("lineage", "")
    mine = names.surname_of(person["name"], race=race)
    other = next((f for f in (names.family(rng, race, line) for _ in range(20)) if f != mine), "")
    house = home or next((n for n in (f"{town}{s}{mine or person['name'][:1]}家" for s in SPOTS)
                          if n not in taken and len(n) <= 12), "")
    if not picks or not house:
        return None, [], []
    out = [p for p in (_person(rng, person, r, age, (mine, other), house, clock_now, taken, race, line) for r in picks) if p]
    if not any(p["status"] == "ALIVE" for p in out):   # 都已故：不開住家，記在村鎮
        return None, [{**p, "location": home or town} for p in out], _ties(person["name"], out, clock_now)
    taken.add(house)
    place = None if home else {"name": house, "description": space.NEW_PLACE_DESCRIPTION, "type": "住家", "scale": "家",
                               "parent": town, "danger": "", "discovered_turn": 0}
    return place, out, _ties(person["name"], out, clock_now)


def _roles(age: int, gender: str) -> list[str]:
    """照順序：父親、母親、兄弟姊妹、伴侶、孩子（未成年只有父母）。"""
    if age < npc.ADULT_AGE:
        return [PARENT + "1", PARENT + "2"]
    return ([PARENT + "1", PARENT + "2", SIBLING] + ([SPOUSE] if gender in npc.GENDERS else [])
            + ([CHILD] if age >= 20 else []))


def _pick(rng: random.Random) -> int:
    return rng.choices(list(COUNT), weights=list(COUNT.values()))[0]


def _person(rng, person, role, age, surnames, house, clock_now, taken, race, line) -> dict | None:
    """surnames：（他的姓, 伴侶那邊的姓）；母親另外擲。"""
    (mine, other), spouse_side = surnames, person.get("gender") == "女"
    if role == PARENT + "1":
        gender, years, surname = "男", age + rng.randint(18, 40), mine
    elif role == PARENT + "2":
        gender, years, surname = "女", age + rng.randint(18, 35), names.family(rng, race, line)
    elif role == SIBLING:
        gender, years, surname = rng.choice(npc.GENDERS), max(0, age + rng.randint(-10, 10)), mine
    elif role == SPOUSE:
        gender, years, surname = "男" if spouse_side else "女", max(npc.ADULT_AGE, age + rng.randint(-5, 8)), other
    else:
        gender, years, surname = rng.choice(npc.GENDERS), age - rng.randint(18, min(40, age)), other if spouse_side else mine
    name = next((n for n in (surname + names.given(rng, race, gender) for _ in range(20)) if n not in taken), "")
    if not name:
        return None
    taken.add(name)
    dead = years >= npc.lifespan_years(0, race)
    band = _band(years, race)
    job = newcomer.job(rng, band, npc.MORTAL, "住家")
    birth = clock_now - years * SHICHEN_PER_YEAR
    return {"name": name, "appearance": newcomer.looks(rng, band, gender, job, race=race), "profile": f"{person['name']}的{_label(role, gender, years, age)}。",
            "location": house, "status": "FALLEN" if dead else "ALIVE", "condition": npc.CONDITIONS[-1 if dead else 0],
            "ai_driven": True, "created_by": BY, "race": race, "lineage": line, "gender": gender, "birth_shichen": birth,
            "job": job, "profile_age": years, "goal": "守護", "goal_target": person["name"],
            **{t: rng.choice(list(npc.TRAIT_LEVELS.values())) for t in npc.TRAITS},
            "evolved_shichen": clock_now, "first_seen_turn": 0, "kin_role": role}


def _band(years: int, race: str) -> str:
    if years < npc.ADULT_AGE:
        return npc.CHILD if years < 13 else npc.TEEN
    share = years / npc.lifespan_years(0, race)
    return npc.YOUNG if share < 0.3 else npc.PRIME if share < 0.6 else npc.ELDER


def _label(role: str, gender: str, years: int, age: int) -> str:
    if role.startswith(PARENT):
        return "父親" if gender == "男" else "母親"
    if role == SIBLING:
        return ("哥哥" if years >= age else "弟弟") if gender == "男" else ("姊姊" if years >= age else "妹妹")
    if role == SPOUSE:
        return "丈夫" if gender == "男" else "妻子"
    return "兒子" if gender == "男" else "女兒"


def _ties(name: str, people: list[dict], clock_now: int) -> list[dict]:
    def tie(a, b, type_):
        return {"a_kind": society.NPC, "a": a, "b_kind": society.NPC, "b": b, "type": type_, "clock_shichen": clock_now, "turn_no": 0}
    out = [tie(p["name"], name, "伴侶" if p["kin_role"] == SPOUSE else "親人") for p in people]
    for i, x in enumerate(people):
        for y in people[i + 1:]:
            roles = {x["kin_role"], y["kin_role"]}
            if roles == {PARENT + "1", PARENT + "2"}:
                out.append(tie(x["name"], y["name"], "伴侶"))
            elif SPOUSE not in roles or CHILD in roles:
                out.append(tie(x["name"], y["name"], "親人"))
    return out
