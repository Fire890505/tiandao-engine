"""出身「奴隸」（2026-10-13，WHITEPAPER 16k 第 4 題追加、草稿批次三；數字暫定）。純函式。

- 建角沒指定身分時擲：一般 3%，他族生在敵對族的地盤 30%（也能在身分選單直接選）。
- 開局被押在坊市叫賣（市集），或在拍賣會的後台等著上台（拍賣會）；Python 先安排好買主——市集多是凡人富戶、
  拍賣會多是修士。買來做什麼看主人的善念：善念低的當爐鼎（閉關修煉的修為減半，被採補），其餘當僕人。
- 第一回合：潛行或戰鬥成功＝趁亂逃走（還沒賣出去，不算逃奴）；否則被買走，住進主人家。
- 脫身：贖身（說「贖身」，交出身價 ×2 的凡人錢；主人好感 60 以上＝立過功，不收錢）、
  逃跑（離主人家超過半日路程：蓄奴的國記「逃奴」通緝、主人親自找上門）、主人死去。不做奴印。
角色卡欄位 bondage：None＝自由；{owner, house, price, use, stage, where}。
"""
from __future__ import annotations

import random

from . import judgment as J
from . import names, newcomer, npc, races

SLAVE = "奴隸"
CHANCE, ENEMY_CHANCE = 0.03, 0.3
MARKET, AUCTION = "市集", "拍賣會"
FOR_SALE, OWNED, RUNAWAY = "待售", "為奴", "逃奴"
SERVANT, FURNACE = "僕人", "爐鼎"
CULTIVATOR_BUYER = {MARKET: 0.3, AUCTION: 0.7}
PRICE = (300, 800)          # 身價（凡人錢）
RANSOM, GRATEFUL = 2, 60
FURNACE_QI = 0.5
ESCAPE_KM = 20              # 半日路程（space.DISTANCE_TIERS）
RANSOM_WORDS = ("贖身", "贖回自由")
BY = "bondage"              # 主人的 created_by


def fields() -> dict:
    return {"bondage": None}


def chance(mine: str, land: str) -> float:
    return ENEMY_CHANCE if races.relation(mine, land) == "敵對" else CHANCE


def buyer(rng: random.Random, where: str, taken: set[str], land: str = races.HUMAN) -> dict:
    """買主（生成資料，service 寫入時用 npc.roll_profile）。"""
    cultivator, who = rng.random() < CULTIVATOR_BUYER[where], newcomer.roll(rng, land)
    name = (names.person_names(rng, taken, 1, **who) or [""])[0] if cultivator else names.mortal_name(
        rng, taken, young=False, old=False, **who)
    return {"name": name, **who, "profile": f"在{where}買下主角的{'修士' if cultivator else '凡人富戶'}。",
            "age_band": rng.choice((npc.PRIME, npc.ELDER)), "power_tier": npc.ADEPT if cultivator else npc.MORTAL,
            "goal": "逐利", "goal_target": "", **{t: rng.choice(list(npc.TRAIT_LEVELS.values())) for t in npc.TRAITS}}


def start(rng: random.Random, owner: dict, house: str, where: str) -> dict:
    use = FURNACE if npc.trait_level(owner["kindness"]) == "低" else SERVANT
    return {"owner": owner["name"], "house": house, "price": rng.randint(*PRICE), "use": use, "stage": FOR_SALE,
            "where": where}


def sale(sheet: dict, verdict: J.Judgment) -> tuple[dict, str]:
    """第一回合：趁亂逃走，或被買走帶回主人家。"""
    b = sheet["bondage"]
    won = {J.SUCCESS, J.GREAT_SUCCESS} & {c.outcome for c in verdict.all_checks}
    if verdict.action_type in (J.STEALTH, J.COMBAT) and won:
        return {**sheet, "bondage": None}, f"趁亂從{b['where']}逃了出來"
    return ({**sheet, "location": b["house"], "home": b["house"], "bondage": {**b, "stage": OWNED}},
            f"被{b['owner']}買走，帶回{b['house']}當{b['use']}")


def ransom(sheet: dict, words: str, affinity: int, deal: str | None = None) -> tuple[dict, str]:
    """贖身：主人好感夠高（立過功）不收錢；否則要有身價 ×2。deal：讀懂的買賣找人（3-4d），None＝舊鏈看字。"""
    b = sheet["bondage"]
    if not (deal == "付錢" if deal is not None else any(w in words for w in RANSOM_WORDS)):
        return sheet, ""
    if affinity >= GRATEFUL:
        return {**sheet, "bondage": None}, f"{b['owner']}念你有功，還了你自由"
    cost = b["price"] * RANSOM
    if sheet["money"] < cost:
        return sheet, f"贖身要 {cost}，身上的錢不夠"
    return {**sheet, "money": sheet["money"] - cost, "bondage": None}, f"交了 {cost} 贖回自由"


def qi(sheet: dict) -> float:
    """當爐鼎被採補：閉關修煉的修為減半。"""
    b = sheet["bondage"]
    return FURNACE_QI if b and b["stage"] == OWNED and b["use"] == FURNACE else 1


def prompt_line(sheet: dict) -> str:
    b = sheet["bondage"]
    if not b:
        return ""
    return {FOR_SALE: f"正被押在{b['where']}等著被賣，{b['owner']}看上了你",
            OWNED: f"是{b['owner']}買來的{b['use']}，住在{b['house']}（身價 {b['price']}）",
            RUNAWAY: f"從{b['owner']}家逃出來的奴隸，{b['owner']}正在找你"}[b["stage"]]


def valid(sheet: dict) -> bool:
    b = sheet["bondage"]
    return b is None or isinstance(b, dict) and set(b) == {"owner", "house", "price", "use", "stage", "where"} \
        and b["stage"] in (FOR_SALE, OWNED, RUNAWAY) and b["use"] in (SERVANT, FURNACE) and isinstance(b["price"], int)
