"""仙域的遭遇與戰事（16l 第 16 題丙；草稿 C3a）。純函式。

規則（2026-10-17 與使用者一題一題定案，見 progress/WHITEPAPER.md 16l，數字暫定）：
- 仙域處處可能開戰。仙宗弟子每回合照自己這一盟跟其他盟的關係擲遭遇（交戰 MEET[交戰]、冷戰 MEET[冷戰]），
  遇上的是那一盟某個仙宗名冊上的人（realms.draw）。
- 戰事：每個百日開始的 LASTS 天內，每一組交戰的盟有 1～3 件（圍山、伏擊、搶運靈脈），地點在兩盟交界的山門。
  用「仙域種子＋第幾個百日」推出來，不另外存；百日一開始在仙域傳開。人在戰事的地點、自己這一盟是其中一方
  ＝一定遇上對方的人；在那裡打贏，對方仙宗的帳上扣掉同樣的戰功（百日演進時算進實力）。
- 造化（C3b）：每個百日 1～3 處（immortal.boons：天材地寶、靈脈噴發、上古遺府、秘境），在某個仙宗的山門一帶，
  同樣只有前 LASTS 天。人在那裡一定遇上別的仙宗派來搶的人（不分敵我，散仙也會）；探索成功＝搶到（REWARDS），
  一處只能搶一次，記進骨架 claimed；下一個百日結算，搶到的歸你的仙宗、沒人搶的照實力擲，那個仙宗實力 +3。
"""
from __future__ import annotations

import random

from . import ascent, atlas, immortal, items
from . import judgment as J
from .clock import SHICHEN_PER_DAY

KINDS = ("圍山", "伏擊", "搶運靈脈")
COUNT = (1, 3)
LASTS = 30 * SHICHEN_PER_DAY
MEET = {atlas.WAR: 0.2, atlas.COLD: 0.05}
SECRET = "秘境"
ENTRY_MERIT, ENTRY_STONES = 30, 50
CLAIM_WORDS = ("搶", "奪", "造化")   # 沒說要搶的探索（例如預設的四處看看）不算
REWARDS = {"天材地寶": ("靈草", 0), "靈脈噴發": ("", 30), "上古遺府": (items.TECHNIQUE, 0), SECRET: (items.ARTIFACT, 30)}


def current(realm: dict, now: int) -> list[dict]:
    """這個百日的戰事 [{kind, place, sides}]；百日開始超過 LASTS 就沒有了。"""
    p = now // immortal.PERIOD
    if now - p * immortal.PERIOD >= LASTS:
        return []
    fronts: dict[tuple, set] = {}
    for a, b in sorted(immortal.neighbors(realm)):
        x, y = immortal._alliance(realm, a), immortal._alliance(realm, b)
        if immortal.at_war(realm, x, y):
            fronts.setdefault(tuple(sorted((x, y))), set()).update((a, b))
    rng = random.Random(f"{realm['seed']}:war:{p}")
    return [{"kind": rng.choice(KINDS), "place": rng.choice(sorted(gates)) + ascent.GATE, "sides": list(sides)}
            for sides, gates in sorted(fronts.items()) for _ in range(rng.randint(*COUNT))]


def boons(realm: dict, now: int) -> list[dict]:
    """這個百日還沒被搶走的造化 [{key, kind, sect, place}]；百日開始超過 LASTS 就沒有了。"""
    p = now // immortal.PERIOD
    if now - p * immortal.PERIOD >= LASTS:
        return []
    return [{**b, "place": b["sect"] + ascent.GATE} for b in immortal.boons(realm, p)
            if b["key"] not in realm.get("claimed", {})]


def news(realm: dict, now: int) -> list[str]:
    return ([f"{'與'.join(w['sides'])}在{w['place']}爆發{w['kind']}之戰" for w in current(realm, now)]
            + [f"{b['place']}一帶現出{b['kind']}，各宗聞風而動" for b in boons(realm, now)])


def claim(rng, sheet: dict, boon: dict, verdict, words: str) -> tuple[dict, list[str], bool]:
    """在造化的地點說要搶（CLAIM_WORDS 或造化的種類）、探索成功＝搶到。秘境要付戰功（仙宗弟子）或靈石（散仙）
    才進得去，搶到時才付。回傳（角色卡, 事實, 搶到了沒）。"""
    if verdict.action_type != J.EXPLORE or not any(w in words for w in CLAIM_WORDS + (boon["kind"],)) \
            or not any(c.outcome in (J.GREAT_SUCCESS, J.SUCCESS) for c in verdict.all_checks):
        return sheet, [], False
    facts = []
    if boon["kind"] == SECRET:
        field, need, unit = ("merit", ENTRY_MERIT, "點戰功") if sheet["sect"] else ("spirit_stones", ENTRY_STONES, "靈石")
        if sheet[field] < need:
            return sheet, [f"要 {need} {unit}才進得了秘境，只有 {sheet[field]}"], False
        sheet, facts = {**sheet, field: sheet[field] - need}, [f"付了 {need} {unit}進入秘境"]
    what, insight = REWARDS[boon["kind"]]
    if what:
        sheet, fact = items.grant(rng, sheet, what, sheet["realm_lv"])
        facts.append(fact)
    if insight:
        sheet = {**sheet, "cultivation": min(100, sheet["cultivation"] + insight)}
        facts.append(f"在{boon['kind']}中有所感悟，修為 +{insight}")
    return sheet, [f"搶到了{boon['place']}一帶的{boon['kind']}"] + facts, True


def at(realm: dict, now: int, place: str, mine: str) -> dict | None:
    """人在這裡的戰事（自己這一盟是其中一方的才算）。"""
    ally = _ally(realm, mine)
    return next((w for w in current(realm, now) if w["place"] == place and ally in w["sides"]), None)


def meet(realm: dict, rng: random.Random, now: int, place: str, mine: str) -> str:
    """這回合遇上哪個仙宗的人（沒遇上回傳空字串）。mine：自己的仙宗（散仙空字串，只在造化的地點遇得上）。"""
    ally = _ally(realm, mine)
    fight = at(realm, now, place, mine)
    if fight:
        return _pick(realm, rng, next(s for s in fight["sides"] if s != ally))
    if any(b["place"] == place for b in boons(realm, now)):   # 造化：各宗都派人來搶，不分敵我
        return rng.choice(sorted(s["name"] for s in realm["sects"] if s["name"] != mine))
    if not ally:
        return ""
    stances = immortal.stances(realm)
    for other in sorted({s["alliance"] for s in realm["sects"]} - {ally, ""}):
        if rng.random() < MEET.get(stances.get(atlas._key(ally, other)), 0):
            return _pick(realm, rng, other)
    return ""


def _ally(realm: dict, sect: str) -> str:
    return next((s["alliance"] for s in realm["sects"] if s["name"] == sect), "")


def _pick(realm: dict, rng: random.Random, alliance: str) -> str:
    return rng.choice(sorted(s["name"] for s in realm["sects"] if s["alliance"] == alliance))
