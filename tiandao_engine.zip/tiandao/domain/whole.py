"""整篇寫（大模型，2026-11-23）：Python 擲題目、挑兩篇同類的手寫範例，模型照範例的格式寫一整篇（連階段表、專屬牌）。
problems 照測試的可玩檢查把關（tests/test_plots、test_newplots、test_legends），沒過把錯給模型重寫。
手寫的照舊在池子裡；9b 照舊走 newplots、newtales、newlegends 的填空（service.big 才用這裡）。
存法跟模型寫的一樣（plots_m、tales_w、legends_w），事端加「來源｜模型｜整篇」讓它算模型寫的（先放、配勢力）。
"""
from __future__ import annotations

import random
import re

from . import cards, deck, judgment, legends, newlegends, newplots, newtales, opinion, plot, stage, tales
from .tales import CONTENT

WAY = "整篇"
TRIES = 3
MIN_CARDS = 6
KINDS = (*cards.MOTIFS, "機會", "命運", "小事", "事件")   # 走向牌的種類（turns.txt 的母型＋這幾種）
WHEN = ("", tales.NIGHT, tales.MIDNIGHT, tales.DAY)
COSTS = ("", tales.HURT1, tales.HURT2, tales.MARKED, tales.THING, tales.BOSS)
WHAT = {"plot": "事端", "tale": "規則怪談", "legend": "都市傳說"}
_KEY = re.compile(r"\{(\w+)\}")


def _comments(path, n: int) -> list[str]:
    return [l for l in path.read_text(encoding="utf-8").splitlines() if l.startswith("#")][:n]


CARD_NOTES = _comments(CONTENT / "cards.txt", 8)
STAGE_NOTES = _comments(CONTENT / "stages.txt", 4)


def topic(rng: random.Random, kind: str, era_now: str) -> dict:
    """這篇寫什麼：事端擲手段、遮掩、受害；怪談擲場所、扭法；傳說擲母題、綁在哪。"""
    if kind == "plot":
        way, cover, victim = (rng.choice(sorted(t)) for t in (newplots.WAYS, newplots.COVERS, newplots.VICTIMS))
        return {"text": f"手段：{way}｜遮掩：{cover}｜受害：{victim}｜時代：{era_now}"}
    if kind == "tale":
        place, twist = rng.choice(sorted(newtales.PLACES)), rng.choice(sorted(newtales.TWISTS))
        types, scale = newtales.PLACES[place][:2]
        return {"text": f"場所：{place}｜扭法：{twist}（{newtales.TWISTS[twist][0]}）｜開頭一行寫 規模:{scale} 地點:{types} 時代:古代"}
    motif = rng.choice(sorted(newlegends.MOTIFS))
    return {"text": f"母題：{motif}（{newlegends.MOTIFS[motif][0]}）｜時代：古代"}


def _hand(kind: str) -> list[tuple[str, str]]:
    """手寫的（名字, 全文）；亡者、客死異鄉這種另外生成的不當範例。"""
    if kind == "plot":
        return [(p.stem, p.read_text(encoding="utf-8")) for p in sorted((CONTENT / "plots").glob("*.txt"))]
    folder, parse = ("tales", tales.parse) if kind == "tale" else ("legends", legends.parse)
    out = []
    for p in sorted((CONTENT / folder).glob("*.txt")):
        text, t = p.read_text(encoding="utf-8"), parse(p.read_text(encoding="utf-8"))
        if t.name != tales.GHOST_TALE and not getattr(t, "ghost", False):
            out.append((t.name, text))
    return out


def example(kind: str, name: str, text: str) -> str:
    """一篇範例：手寫檔＋它在 stages.txt 的階段表、cards.txt 的專屬牌，改成寫在同一篇裡的樣子（跟 newplots._stages 同格式）。"""
    rows = [text.rstrip()]
    if kind == "plot":
        rows += ["｜".join([f, *r]) for (f, n), rs in stage.TABLE.items() if n == name for r in rs]
    rows += ["走向｜" + l for l in (CONTENT / "cards.txt").read_text(encoding="utf-8").splitlines()
             if l.startswith("｜") and f"路線:{name} " in l + " "]
    return "\n".join(rows)


def brief(rng: random.Random, kind: str, era_now: str) -> dict:
    """給提示詞的：寫什麼、兩篇範例、格式說明。"""
    pool = [x for x in _hand(kind) if kind != "plot" or plot.surfaces(plot.parse(x[1]), era_now)]   # 事端挑有這個時代表面的
    picks = rng.sample(pool, 2)
    notes = CARD_NOTES + (STAGE_NOTES if kind == "plot" else [])
    return {"what": WHAT[kind], "topic": topic(rng, kind, era_now)["text"], "examples": [example(kind, n, t) for n, t in picks],
            "notes": "\n".join(notes), "era": era_now}


def _bad(f):
    """檢查裡讀不成的（缺欄、欄數不對）一律算錯，回傳錯在哪。"""
    try:
        return f()
    except (KeyError, IndexError, ValueError, StopIteration, AssertionError, TypeError) as exc:
        return [f"格式讀不成：{type(exc).__name__} {exc}"[:120]]


def _cards(rows: list[list[str]], name: str, keys: set[str]) -> list[str]:
    out = []
    for r in rows:
        try:
            c = deck.card(r)
            deck.bare(c.result)
        except (AssertionError, ValueError, IndexError) as exc:
            out.append(f"走向牌讀不成：{'｜'.join(r)[:60]}（{exc}）"[:120])
            continue
        if c.kind not in KINDS:
            out.append(f"走向牌的種類要是 {'、'.join(KINDS)} 之一：{c.kind}")
        if c.who != "路線" or dict(c.need).get("路線") != name:
            out.append(f"走向牌的誰抽要寫「路線」、條件要有 路線:{name}：{c.text[:20]}")
        if left := set(_KEY.findall(c.text)) - keys:
            out.append(f"走向牌用了沒有的詞位 {sorted(left)}：{c.text[:20]}")
    if len(rows) < MIN_CARDS:
        out.append(f"專屬走向牌至少 {MIN_CARDS} 張，現在 {len(rows)} 張")
    return out


def _name(name: str, taken: set[str]) -> list[str]:
    return ([f"名字要 2～8 字：{name}"] if not 2 <= len(name) <= 8 else []) + ([f"名字跟世界上已有的撞了：{name}"] if name in taken else [])


def problems(kind: str, body: str, era_now: str, taken: set[str]) -> list[str]:
    """這篇能不能玩；空＝能。"""
    return _bad(lambda: {"plot": _plot, "tale": _tale, "legend": _legend}[kind](body, era_now, taken))


def _plot(body: str, era_now: str, taken: set[str]) -> list[str]:
    t, out = plot.parse(body), []
    name = plot.name(t)
    out += _name(name, taken)
    if t["牌"][0][1:3] != ["地方", "事端"]:
        out.append("開頭一行要是 牌｜名字｜地方｜事端｜地點:…｜｜")
    out += [f"缺「{f}」" for f in ("風聲", "真相", "表面", "處", "人物", "線索", "小事", "時間線", "結局", "轉向", "轉向線", "轉向結局", "轉折",
                                   "事", "素材", "立場", "階段") if f not in t]
    if out:
        return out
    faces = plot.surfaces(t, era_now)
    if not faces:
        out.append(f"沒有{era_now}的表面（古代不標，現代、未來寫「表面｜現代｜…」）")
    roles = {r[0] for r in t["人物"]} | {r[0] for r in t.get("旁人", [])}
    keys = {"村", "勢力", "事", *plot.WORDS, *(r[0] for r in t["處"]), *roles, *(p.split("=")[0] for f in faces for p in f)}
    used = {k for f, rows in t.items() if f not in ("牌", "表面", "走向") for row in rows for cell in row for k in _KEY.findall(cell)}
    if left := used - keys:
        out.append(f"用了沒定義的詞位 {sorted(left)}（要在表面、處、人物裡）")
    clues, turns = {r[0] for r in t["線索"]}, {r[0] for r in t["轉折"]}
    if bad := {b for r in t["線索"] for b in r[4].split("／")} - clues - {""}:
        out.append(f"線索的前置要是別的線索：{sorted(bad)}")
    if bad := {r[3] for r in t["轉折"]} - clues - turns - {""}:
        out.append(f"轉折的前置要是線索或轉折：{sorted(bad)}")
    for row in t["轉折"]:
        if len(row) != 9:
            out.append(f"轉折「{row[0]}」要 9 欄，現在 {len(row)} 欄")
        elif not any(w in row[5] for w in row[4].split("、")):
            out.append(f"轉折「{row[0]}」的選項要含觸發詞之一（{row[4]}）")
    if {r[1] for r in t["轉向"]} - roles or {r[0] for r in t["轉向"]} - roles:
        out.append("轉向的兩個角色都要在人物裡")
    if len(plot.ending(t, True)[2]) != 2:
        out.append("轉向結局要有兩種痕跡")
    rec = {"cast": {r: r for r in roles}}
    for f in ("時間線", "結局", "轉向線", "轉向結局", "轉折", "放下去"):
        for row in t.get(f, []):
            for _, _, k, value in plot.effects(rec, t, row[-1]):
                head = value.partition(":")[0]
                ok = (k in deck.RESULTS and (head in opinion.MOODS if k == "好感" else head in ("救命之恩", "人情", "欠情") if k == "帳"
                                             else head in deck.RESULTS[k].split()))
                if not ok:
                    out.append(f"{f}的結果「{k}:{value}」不在結果表上")
    if "地點" not in dict(deck.card(t["牌"][0]).need):
        out.append("開頭一行的條件要寫 地點:…")
    for face in faces[:1]:
        if long := [s for s in (plot.fill(r[1], dict(p.split("=") for p in face)) for r in t["處"]) if len(s) > 6]:
            out.append(f"處名最多 6 字：{long}")
    marks = clues | turns | {"查探", "社交", "動手"}
    steps = t["階段"]
    if len(steps) < 3 or steps[-1][2:3] not in ([], [""]):
        out.append("階段至少三階，最後一階（怎麼收場）條件留空")
    for r in steps[:-1]:
        for need in filter(None, r[2].split("、") if len(r) > 2 else ["?"]):
            if not (need in marks or re.fullmatch(r"(放著|暗線):\d+", need)):
                out.append(f"階段「{r[0]}」的條件「{need}」不是線索、轉折、查探／社交／動手、放著:N、暗線:N")
    return out + _cards(t.get("走向", []), name, keys | {"做法", "線索地", "傳聞"})


def _ways(steps, places: tuple[str, ...]) -> list[str]:
    out = [] if len(steps) == 3 else [f"了結要剛好三步，現在 {len(steps)} 步"]
    for i, s in enumerate(steps, 1):
        if not s.ways:
            out.append(f"第 {i} 步沒有做法")
        for w in s.ways:
            if w.place not in places or w.when not in WHEN or set(w.natures) - set(judgment.NATURES):
                out.append(f"第 {i} 步的做法有不認得的地、時段或行動")
    return out


def _tale(body: str, era_now: str, taken: set[str]) -> list[str]:
    t = tales.parse(body)
    out = _name(t.name, taken) + _ways(t.steps, (tales.HERE, tales.NEAR))
    if not t.scales or set(t.scales) - set(tales.SCALES):
        out.append(f"規模要是 {'、'.join(tales.SCALES)} 裡的")
    if len(t.rules) < t.draw:
        out.append(f"守則至少 {t.draw} 條（抽幾條），現在 {len(t.rules)} 條")
    if not any(r.fake for r in t.rules) or any(r.fake and not r.truth for r in t.rules):
        out.append("至少一條假的守則，假的都要寫 正解")
    for r in t.rules:
        if r.cost not in COSTS or r.when not in WHEN or set(r.natures) - set(judgment.NATURES) or set(r.scales) - set(t.scales):
            out.append(f"守則「{r.text[:16]}」的 犯了／時段／行動／規模 有不認得的值")
    text = "".join([t.rumor, *(r.text + r.scene + r.truth for r in t.rules), *(s.reveal + s.hint for s in t.steps)])
    if left := set(_KEY.findall(text)) - {"此地", "鄰地", "人"}:
        out.append(f"只能用 {{此地}}{{鄰地}}{{人}}：{sorted(left)}")
    return out + _cards(tales.parse_cards(body), t.name, {"此地", "鄰地", "人"})


def _legend(body: str, era_now: str, taken: set[str]) -> list[str]:
    g = legends.parse(body)
    out = _name(g.name, taken) + _ways(g.steps, (tales.HERE, tales.NEAR))
    if g.ghost:
        out.append("種類寫「傳說」")
    if not any(not s.true for s in g.sayings) or any(s.true != (s.truth == "") for s in g.sayings):
        out.append("說法至少一則錯的，錯的才寫 其實")
    if not g.good or g.when not in WHEN or set(g.natures) - set(judgment.NATURES):
        out.append("答對要寫字；碰上的時段、行動要是認得的值")
    text = g.line + "".join(s.reveal + s.hint for s in g.steps) + "".join(s.text + s.truth for s in g.sayings)
    if left := set(_KEY.findall(text)) - {"此地", "鄰地"}:
        out.append(f"只能用 {{此地}}{{鄰地}}：{sorted(left)}")
    return out + _cards(tales.parse_cards(body), g.name, {"此地", "鄰地"})


def record(kind: str, body: str, state: str) -> dict:
    """存成一篇：事端的 state 是時代，怪談、傳說是綁的州。"""
    rows = [l for l in body.strip().splitlines() if l.strip() and not l.startswith("來源｜")]
    if kind == "plot":
        rows.insert(1, f"來源｜{newplots.MODEL}｜{WAY}")
        t = plot.parse("\n".join(rows))
        return {"name": plot.name(t), "state": state, "body": "\n".join(rows), "source": newplots.MODEL}
    t = (tales.parse if kind == "tale" else legends.parse)("\n".join(rows), state)
    line = t.rumor if kind == "tale" else t.line
    return {"name": t.name, "state": state, "body": "\n".join(rows), "source": newlegends.MODEL, "line": line}


def mine(t: dict) -> bool:
    return bool(t.get("來源")) and t["來源"][0][1:2] == [WAY]
