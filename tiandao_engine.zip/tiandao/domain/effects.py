"""判定結果 → 狀態變化。純函式：不碰資料庫、不呼叫 AI。

回傳的 Delta 同時是：
1. 寫入資料庫的依據（新角色卡、時間推進）；
2. 交給 AI 的「已發生事實」，AI 只能描寫，不能更改。

第 4 步起，代價依「判定標的」計算（數值＋狀態標記），並加入瀕死：
氣血歸零先進入瀕死，傷勢值 0–100 隨行動與時間變化，降到 30 以下脫離、升到 100 才死亡；
瀕死時可以燃燒壽元或自損修為換命；撐過來有機會頓悟。規則見 progress/HANDOFF.md 第 4 步。
"""
from __future__ import annotations

import copy
import math
from dataclasses import dataclass, field

from . import breach, breakthrough, character, clock, crafting, heaven, laws, lineage, realm, retreat
from . import status as status_mod
from .incident import ESCORT, HUNT
from .judgment import (
    ALCHEMY, BREAKTHROUGH, BURN_LIFESPAN, COMBAT, CRAFTS, CULTIVATE, DISCOVER, ENDURE, ESCAPE, EXPLORE, FORGE,
    GREAT_FAILURE, GREAT_SUCCESS, HIDE, MOVE, OBSERVE, ORIENT, PERSUADE, PRACTICE, PRICE, PRY, REST,
    SACRIFICE_CULTIVATION, SOCIAL, STEALTH, STRIKE, STUDY, SUCCESS, TREAT, WITHSTAND, WORK, Judgment,
)

FAILURE = "失敗"

# 行動花費的時辰數（玩家沒寫時長時的預設值）。移動的時間依路程另算（judgment.travel）
TIME_COST = {CULTIVATE: 12, COMBAT: 1, EXPLORE: 2, SOCIAL: 1, STEALTH: 1, REST: 4, OBSERVE: 1, BREAKTHROUGH: 12,
             ENDURE: 1, PRICE: 1, MOVE: 0, WORK: clock.SHICHEN_PER_MONTH, STUDY: 12, ALCHEMY: 6, FORGE: 12}
QUICK_REFUSAL = (STUDY, *CRAFTS)      # 參悟、煉製做不了：當下就知道，只花 1 時辰
STRENUOUS = {COMBAT, STEALTH, MOVE}   # 瀕死時會加重傷勢的劇烈行動
TIMED_ACTIONS = {CULTIVATE, REST, WORK, STUDY}
TECHNIQUE_CULTIVATION = 0.1           # 主修功法：修煉的修為 +10%（第 3b-1 步，乘上功法效力）
REST_HEAL, DAILY_HEAL = 0.1, 0.02   # 每天回氣血上限的比例：靜養、其他（16m 第 6 題，原本休息固定 +20）

# 做工（第 8 步，WHITEPAPER 第 16 節，數字暫定）：不擲骰，每月 50 × 2 的境界次方，照實際時間按比例算。
# 經濟第二輪：工錢改發凡人錢（原本 5 靈石 × 匯率 10）。只在有人的地方做得了；其他地方 service 當成探索
WORK_WAGE = 50
WORK_PLACES = ("城鎮", "坊市", "客棧", "宗門", "村落", "住家")


@dataclass(frozen=True)
class Job:
    """營生（16o 第 2～5 題，數字暫定）。wage：工錢倍率（做工＝1）；monthly：途中遭遇每月機率；
    kind：遭遇只挑這一類事件（空＝照一般）；herb：每月採到一份靈材的機率。"""
    places: tuple[str, ...]
    where: str
    wage: float = 1
    monthly: float = 0.03
    kind: str = ""
    herb: float = 0


TOWN = "要到城鎮、坊市、客棧這類人多的地方"
JOBS = {"做工": Job(WORK_PLACES, TOWN), "採藥": Job(("荒野", "秘境"), "要在荒野或秘境", wage=0.5, herb=0.2),
        "打獵": Job(("荒野",), "要在荒野", monthly=0.06, kind=HUNT),
        "走鏢": Job(WORK_PLACES, TOWN, wage=2, monthly=0.09, kind=ESCORT)}


def job(text: str) -> str:
    """行動文字提到的營生名；其他做工的說法都算做工。"""
    return next((k for k in JOBS if k in text), "做工")


@dataclass(frozen=True)
class Outcome:
    """一個標的的一種結果帶來什麼。statuses：(名稱, 類型, 嚴重度, 持續時辰或 None)。"""
    mods: dict = field(default_factory=dict)
    statuses: tuple = ()
    event: str = ""
    extra_time: int = 0


_EXPOSED = ("行蹤暴露", status_mod.NEGATIVE, 40, 12)
_NO_DEAL = ("話不投機", status_mod.NEGATIVE, 30, 24)
# (標的, 結果) → 代價（暫定數值，與使用者討論的代價表）。修行的正收益會再依閉關時長放大
_OUTCOMES: dict[tuple[str, str], Outcome] = {
    (PRACTICE, GREAT_SUCCESS): Outcome({"cultivation": 25}, event="修為大進"),
    (PRACTICE, SUCCESS): Outcome({"cultivation": 12}, event="修為有所增長"),
    (PRACTICE, FAILURE): Outcome({"cultivation": 3}, event="修為幾乎沒有增長"),     # 16m 第 3 題：失敗也寫明結果
    (PRACTICE, GREAT_FAILURE): Outcome({"cultivation": -5, "hp": -15}, event="真氣走岔，修為倒退"),
    (STRIKE, GREAT_SUCCESS): Outcome({"spirit_stones": 5}, event="佔盡上風"),
    (STRIKE, SUCCESS): Outcome({"hp": -5}, event="佔上風"),
    (STRIKE, FAILURE): Outcome({"hp": -15}, event="落了下風"),
    (STRIKE, GREAT_FAILURE): Outcome({"hp": -35}, event="遭到重創"),
    (HIDE, GREAT_SUCCESS): Outcome(event="來去無蹤"),
    (HIDE, SUCCESS): Outcome(event="無人察覺"),
    (HIDE, FAILURE): Outcome(statuses=(_EXPOSED,), event="被人發現"),
    (HIDE, GREAT_FAILURE): Outcome({"hp": -10}, (_EXPOSED,), event="被人發現，還受了傷"),
    (DISCOVER, GREAT_SUCCESS): Outcome({"spirit_stones": 10}, event="大有所獲"),
    (DISCOVER, SUCCESS): Outcome({"spirit_stones": 3}, event="有所發現"),
    (DISCOVER, FAILURE): Outcome(event="一無所獲"),
    (DISCOVER, GREAT_FAILURE): Outcome({"hp": -10}, event="誤觸機關"),
    (ORIENT, GREAT_SUCCESS): Outcome(event="找到一條近路"),
    (ORIENT, SUCCESS): Outcome(event="認準了方向"),
    (ORIENT, FAILURE): Outcome(event="繞了遠路", extra_time=4),
    (ORIENT, GREAT_FAILURE): Outcome(statuses=(("迷路", status_mod.NEGATIVE, 50, 24),
                                               ("受驚", status_mod.NEGATIVE, 35, 6)), event="迷失方向", extra_time=4),
    (PERSUADE, GREAT_SUCCESS): Outcome(event="對方心悅誠服"),
    (PERSUADE, SUCCESS): Outcome(event="對方聽進去了"),
    (PERSUADE, FAILURE): Outcome(statuses=(_NO_DEAL,), event="這次沒談成"),
    (PERSUADE, GREAT_FAILURE): Outcome(statuses=(("對方起疑", status_mod.NEGATIVE, 60, 24),),
                                       event="弄巧成拙，關係惡化"),
    (PRY, GREAT_SUCCESS): Outcome(event="套出了意想不到的消息"),
    (PRY, SUCCESS): Outcome(event="打聽到消息"),
    (PRY, FAILURE): Outcome(statuses=(_NO_DEAL,), event="對方沒有多說"),
    (PRY, GREAT_FAILURE): Outcome(statuses=(("對方起疑", status_mod.NEGATIVE, 60, 24),), event="打草驚蛇，關係惡化"),
    (ESCAPE, GREAT_SUCCESS): Outcome(event="全身而退"),
    (ESCAPE, SUCCESS): Outcome(event="脫離險境"),
    (ESCAPE, FAILURE): Outcome({"hp": -10}, event="沒能脫身，挨了一下"),
    (ESCAPE, GREAT_FAILURE): Outcome({"hp": -20}, event="脫身不成，傷上加傷"),
    (WITHSTAND, GREAT_SUCCESS): Outcome(event="穩如磐石"),
    (WITHSTAND, SUCCESS): Outcome(event="撐住了"),
    (WITHSTAND, FAILURE): Outcome({"hp": -10}, event="沒能撐住"),
    (WITHSTAND, GREAT_FAILURE): Outcome({"hp": -25}, event="被壓垮"),
}

# ── 瀕死（數值暫定）──────────────────────────────────────────────────────────
WOUND_START, WOUND_PER_OVERFLOW, WOUND_START_CAP = 50, 2, 95
WOUND_RECOVERED, WOUND_FATAL = 30, 100
WOUND_PER_DAMAGE = 2                       # 瀕死時又受傷：傷勢 + 傷害×2
WOUND_STRENUOUS, WOUND_OTHER = 15, 5       # 劇烈行動（戰鬥、潛行）／其他行動
WOUND_TIME_DIVISOR = 4                     # 每 4 時辰失血 +1
TREAT_WOUND = {GREAT_SUCCESS: -35, SUCCESS: -20, FAILURE: 5, GREAT_FAILURE: 15}
BURN_YEARS, BURN_RELIEF = 10, 30
SACRIFICE_CULTIVATION_LOSS, SACRIFICE_RELIEF = 50, 25
RECOVERED_HP_RATIO = 0.1
INSIGHT_CULTIVATION = 20                   # 頓悟：修為 +20，機率＝悟性÷4 %
LINGERING = "傷勢未癒"

FIELD_LABELS = {"cultivation": "修為", "hp": "氣血", "spirit_stones": "靈石", "money": "凡人錢"}


WORDED_FIELDS = {"cultivation", "hp"}   # 給說書人時不給點數，只給增減方向與幅度（小模型會把點數寫進敘事）
AMOUNT_WORDS = ((5, "些微"), (15, "小幅"), (40, "明顯"))   # 變化量（點）以內 → 幅度；更大的是「大幅」


def describe_change(change: dict) -> str:
    """給說書人的一項變化：「修為：增加（小幅）」「靈石：5 → 8（增加 3）」。
    寫明增減方向，小模型才不會把增加讀成損失；修為、氣血只給幅度，靈石是可以數的東西，照實給數字。"""
    label, diff = FIELD_LABELS[change["field"]], change["to"] - change["from"]
    if change.get("reason") == "breakthrough":
        return f"{label}：突破境界後重新累積，不是損失"
    direction = "增加" if diff > 0 else "減少"
    if change["field"] in WORDED_FIELDS:
        amount = next((word for limit, word in AMOUNT_WORDS if abs(diff) <= limit), "大幅")
        return f"{label}：{direction}（{amount}）"
    return f"{label}：{change['from']} → {change['to']}（{direction} {abs(diff)}）"


def is_retreat(action: str, player_input: str) -> bool:
    """有寫時長的修煉、休養或做工（閉關三年、休養半年、做工三個月）：被人找上門時會被打斷。"""
    return action in TIMED_ACTIONS and retreat.parse(player_input) is not None


def retreat_multiplier(duration: retreat.Duration | None) -> float:
    """閉關收益隨時長遞減放大：1 + √月數。打坐一下 ×1、閉關三年 ×7、閉關百年 ×35.6。"""
    if duration is None:
        return 1.0
    return 1 + math.sqrt(duration.shichen / clock.SHICHEN_PER_MONTH)


@dataclass
class Delta:
    sheet: dict
    clock_advance: int
    changes: list[dict] = field(default_factory=list)
    events: list[str] = field(default_factory=list)
    marks: list[tuple[str, int]] = field(default_factory=list)   # 引起天道注視的事：[(來源, 點數)]（第 18-1 步）
    side: list[str] = field(default_factory=list)    # 旁支事實（最多三行）：送進【旁支】，不算【結果】（第 2-3 批第 5 題）
    aside: list[str] = field(default_factory=list)   # 擠掉的旁支事實：只留在回合紀錄，不寫進故事（第 2-1b 批）

    @property
    def fallen(self) -> bool:
        return self.sheet["status"] == "FALLEN"

    def facts(self) -> list[str]:
        """給 AI 的事實清單（中文）。"""
        lines = [describe_change(c) for c in self.changes]
        lines += self.events
        return lines

    def to_dict(self) -> dict:
        return {"clockAdvance": self.clock_advance, "changes": self.changes, "events": self.events, "side": self.side, "aside": self.aside}


def time_cost(action: str, player_input: str, sheet: dict | None = None,
              clock_now: int | None = None, cut_short: int | None = None) -> tuple[int, retreat.Duration | None, list[str]]:
    """這個行動花多少時辰。只有修煉與休息會依玩家寫的時長推進（「閉關三年」「休息三天」）。

    有給 sheet 與 clock_now 時，時長不得超過剩餘壽元。cut_short：閉關被打斷，實際只過了這麼多時辰（第 10c-2a 步）。
    回傳 (時辰, 時長, 事件)。
    """
    duration = retreat.parse(player_input) if action in TIMED_ACTIONS else None
    if duration is None:
        return TIME_COST[action], None, []
    if cut_short is not None and cut_short < duration.shichen:
        duration = retreat.Duration(max(1, cut_short), duration.phrase, False)
    events = [f"閉關時長超過上限，以 {retreat.MAX_RETREAT_YEARS} 年計"] if duration.capped else []
    remaining = character.remaining_life_shichen(sheet, clock_now) if sheet and clock_now is not None else None
    if remaining is not None and duration.shichen > remaining:
        duration = retreat.Duration(max(0, remaining), duration.phrase, True)
        events = ["閉關時長超過剩餘壽元，壽元將在閉關中耗盡"]
    return duration.shichen, duration, events


def apply(sheet: dict, judgment: Judgment, *, player_input: str = "", clock_before: int | None = None,
          cut_short: int | None = None, guard: bool = False, found_item: bool = False, place_type: str = "",
          qi: float = 1, plain: bool = False, bleed: float = 1, here: dict | None = None) -> Delta:
    """clock_before 有給時，會處理狀態到期、年齡與壽元，並附上時間流逝與季節變化的事實。
    cut_short：閉關被打斷時實際過了多少時辰（修為依實際時間算，第 10c-2a 步）。
    guard：用了護身符，這次判定受的傷減半（第 8 步）。
    found_item：探索大成功撿到的是靈材，不給那 10 靈石（第 8b 步；靈材由 service 給）。
    place_type：所在地類型（參悟在秘境有加成，第 3b-1 步）。
    qi：修煉的修為倍數（天氣、天變，16j）。
    plain：這裡有事端（16t），探索查的是線索，不給通用的靈石。
    bleed：判定扣的氣血倍數（羊刃，第 6-5d 批）。
    here：眼前的情況（service._scene，參悟的在場加成）；沒給就只看地點、季節、時辰。"""
    new = copy.deepcopy(sheet)
    new.setdefault("statuses", [])
    action = judgment.action_type
    was_dying = sheet.get("status") == "DYING"
    advance, duration, events = time_cost(action, player_input, sheet, clock_before, cut_short)
    if action in QUICK_REFUSAL and not judgment.rolled:
        advance, duration, events = 1, None, []
    changes: list[dict] = []
    marks: list[tuple[str, int]] = []
    hurt = {"overflow": 0}     # 氣血被扣到 0 以下的部分（進入瀕死的起點、瀕死時加重傷勢）

    if clock_before is not None:
        new["statuses"], gone = status_mod.expire(new["statuses"], clock_before)
        events += [f"「{name}」已消退" for name in gone]
    if judgment.note and not judgment.rolled and action != BREAKTHROUGH and judgment.note != laws.LOCK_NOTE:
        events.append(f"未能嘗試：{judgment.note}")

    if action == BREAKTHROUGH:
        _breakthrough(new, judgment, clock_before or 0, changes, events, hurt, marks)
    elif action == STUDY and not was_dying:
        _study(new, judgment, duration, here or laws.scene(new, place_type, clock_before or 0), changes, events, hurt, marks)
    elif action in CRAFTS and judgment.rolled:
        crafted, made, broken = crafting.outcome(new, action, judgment.recipe, judgment.outcome)
        new.update(crafted)
        events += made
        if broken:
            _apply_mods(new, {"hp": -max(0, min(round(new["hp_max"] * broken), new["hp"] - 1))}, changes, hurt)
    elif action == REST and not was_dying:   # 氣血在下面按天回
        new["statuses"], healed = status_mod.relieve(new["statuses"])
        events += [f"「{name}」已痊癒" for name in healed]
    elif action == WORK and not was_dying:
        months, name = advance / clock.SHICHEN_PER_MONTH, job(player_input)
        _apply_mods(new, {"money": round(WORK_WAGE * 2 ** new["realm_lv"] * months * JOBS[name].wage)}, changes, hurt)
        events.append(f"{name} {clock.format_span(advance)}，" + ("領到工錢" if JOBS[name].where == TOWN else "賣了換錢"))
    else:
        for check in judgment.all_checks:
            advance += _apply_check(new, check, duration, changes, events, hurt, clock_before, guard, found_item, qi, plain, bleed)
    advance += _move(new, judgment, events)
    # 16m 第 6 題：過了幾天就回幾天的氣血（靜養每天一成、照實際時間；其他每滿一天 2%）；瀕死與這回合被打到 0 的不回
    heal = int(new["hp_max"] * REST_HEAL * advance / clock.SHICHEN_PER_DAY) if action == REST \
        else int(new["hp_max"] * DAILY_HEAL * (advance // clock.SHICHEN_PER_DAY))
    if heal and not was_dying and new["hp"] > 0:
        _apply_mods(new, {"hp": heal}, changes, hurt)

    if was_dying:
        _dying_turn(new, judgment, advance, changes, events, hurt, marks)
    elif new["hp"] <= 0 and new["status"] == "ALIVE":
        new.update(status="DYING", hp=0,
                   wound=min(WOUND_START_CAP, WOUND_START + hurt["overflow"] * WOUND_PER_OVERFLOW))
        events.append(f"氣血耗盡，陷入瀕死（傷勢 {new['wound']}/100）")
        # 瀕死時天道會開口（第 18-1 步，game 層看狀態變化）；趁機落子留給第 18-2 步

    if clock_before is not None:
        clock_after = clock_before + advance
        remaining = character.remaining_life_shichen(new, clock_after)
        if remaining is not None and remaining <= 0 and new["status"] in ("ALIVE", "DYING"):
            new["status"] = "FALLEN"
            events.append(f"壽元耗盡（{character.lifespan(new)} 歲），坐化")
        events += clock.passage_facts(clock_before, clock_after)
    return Delta(sheet=new, clock_advance=advance, changes=changes, events=events, marks=marks)


DEVIATION_CHANCE = 0.2   # 閉關修煉被找上門打斷：走火入魔（小修清單第 4 題，數字暫定）
DEVIATION = ("心神受擾", status_mod.NEGATIVE, 45, 30 * clock.SHICHEN_PER_DAY)


def deviate(delta: Delta, clock_now: int) -> None:
    """走火入魔：得「心神受擾」、扣一成氣血（不致瀕死）。直接改 delta。"""
    loss = max(0, min(round(delta.sheet["hp_max"] * 0.1), delta.sheet["hp"] - 1))
    _apply_mods(delta.sheet, {"hp": -loss}, delta.changes, {"overflow": 0})
    name, kind, magnitude, span = DEVIATION
    status_mod.add(delta.sheet["statuses"], status_mod.make(name, kind, magnitude, clock_now + span))
    delta.events.append(f"閉關被打斷，真氣逆行，走火入魔（留下狀態「{name}」）")


def arrives(judgment: Judgment) -> bool:
    """這回合有沒有抵達目的地：沿已知路線移動一定抵達；前往未知地點要辨向成功；
    被領域的本體追著時，離開要脫身成功（第 19-1 步）。"""
    if not judgment.destination:
        return False
    if judgment.action_type == MOVE or judgment.spot:
        return True
    checks = judgment.all_checks
    return bool(checks) and checks[0].target in (ORIENT, ESCAPE) and checks[0].outcome in (SUCCESS, GREAT_SUCCESS)


def _move(new: dict, judgment: Judgment, events: list[str]) -> int:
    """抵達目的地，回傳路上花的時辰。"""
    if not arrives(judgment):
        return 0
    origin = new["location"]
    new["location"] = judgment.destination
    found = "" if judgment.action_type == MOVE or judgment.spot else "脫身而出，" if judgment.all_checks[0].target == ESCAPE else "找到了路，"
    fresh = "（初次到訪）" if judgment.new_place else ""
    cost = f"，路上花了 {judgment.travel} 時辰" if judgment.travel else ""   # 同一個村鎮裡走動不算時間（16t 第 3 題）
    events.append(f"{found}從「{origin}」抵達「{judgment.destination}」{fresh}{cost}")
    return judgment.travel


def _apply_check(new: dict, check, duration, changes, events, hurt, clock_before, guard: bool = False,
                 found_item: bool = False, qi: float = 1, plain: bool = False, bleed: float = 1) -> int:
    """套用一個標的的結果，回傳額外花費的時辰。guard：護身符擋下一半的傷；found_item：大有所獲的是靈材不是靈石。"""
    outcome = _OUTCOMES.get((check.target, check.outcome))
    if outcome is None:          # 療傷只在瀕死時擲，由 _dying_turn 處理
        return 0
    mods = dict(outcome.mods)
    if (found_item and (check.target, check.outcome) == (DISCOVER, GREAT_SUCCESS)) or (plain and check.target == DISCOVER):
        mods.pop("spirit_stones", None)
    if check.target == PRACTICE and mods.get("cultivation", 0) > 0:
        technique = 1 + TECHNIQUE_CULTIVATION * laws.technique_power(new)
        mods["cultivation"] = round(mods["cultivation"] * retreat_multiplier(duration) * technique * qi)
    if mods.get("hp", 0) < 0:   # 羊刃容易見血（第 6-5d 批，origins.bleed）
        mods["hp"] = round(mods["hp"] * bleed)
    if guard and mods.get("hp", 0) < 0:
        mods["hp"] = -(-mods["hp"] // 2)
        events.append("護身符擋下了一半的傷")
    _apply_mods(new, mods, changes, hurt)
    _gain_cultivation(new, mods.get("cultivation", 0), changes, events)
    if outcome.event:
        # 說服、套話只寫結果：「說服成功」會被說書人照抄進敘事（故事第 3 題）
        events.append(outcome.event if check.target in (PERSUADE, PRY) else f"{check.target}{check.outcome}：{outcome.event}")
    for name, kind, magnitude, hours in outcome.statuses:
        expires = None if hours is None or clock_before is None else clock_before + hours
        status_mod.add(new["statuses"], status_mod.make(name, kind, magnitude, expires))
        events.append(f"留下狀態「{name}」（嚴重度 {magnitude}）")
    return outcome.extra_time


def _study(new: dict, judgment: Judgment, duration, here: dict, changes, events, hurt, marks) -> None:
    """參悟一條現象（第 3b-1 步，規則見 domain/laws.py）。碰到天道鎖定的系：扣一成氣血（不致瀕死），不累積，天道注視上升。"""
    law = judgment.law
    if judgment.note == laws.LOCK_NOTE:
        loss = max(0, min(round(new["hp_max"] * laws.LOCKED_HP), new["hp"] - 1))
        _apply_mods(new, {"hp": -loss}, changes, hurt)
        events.append(f"參悟{law}，觸及天道之鎖，靈識被彈了回來")
        marks.append((heaven.LOCKED, heaven.GAIN[heaven.LOCKED]))
        if not new["laws_warned"]:
            events.append(laws.LOCK_NOTE)
            new["laws_warned"] = True
        return
    if not judgment.rolled:
        return
    p = laws.PHENOMENA[law]
    events.append(f"參悟的現象：{law}（{p.text}）")
    base = laws.STUDY_GAIN.get(judgment.outcome, 0)
    new["insight"] = {law: 0, **new["insight"]}   # 眼前看到的，參悟時順便算見過
    if not base:
        events.append(f"參悟{law}{judgment.outcome}：沒有所得")
        return
    found = laws.boosts(new, law, here)
    weak = lineage.WEAK_FACTOR if lineage.WEAK.get(new["lineage"]) == p.system else 1   # 盜墓世家參悟光系減半（第 5 步）
    amount = round(base * retreat_multiplier(duration) * (1 + sum(found.values())) * weak)
    word = next((w for limit, w in AMOUNT_WORDS if amount <= limit), "大幅")
    events.append(f"參悟{law}{judgment.outcome}：感悟加深（{word}）" + (f"，契合{'、'.join(found)}" if found else ""))
    new["insight"], reached = laws.gain(new, law, amount)
    events += reached


def gain(sheet: dict, mods: dict[str, int]) -> tuple[dict, list[dict], list[str]]:
    """判定以外的增減（第 9a 步事件）：氣血、靈石、修為，照判定結果的同一套規則。回傳（角色卡, 數值變化, 事件）。"""
    new, changes, events = copy.deepcopy(sheet), [], []
    _apply_mods(new, mods, changes, {"overflow": 0})
    _gain_cultivation(new, mods.get("cultivation", 0), changes, events)
    return new, changes, events


def _apply_mods(new: dict, mods: dict[str, int], changes: list[dict], hurt: dict) -> None:
    """氣血、靈石的增減（修為另外處理，因為要經過小境界推進與瓶頸）。"""
    for key, amount in mods.items():
        if key == "cultivation":
            continue
        before = new[key]
        raw = before + amount
        if key == "hp":
            hurt["overflow"] += max(0, -raw) if amount < 0 else 0
            after = max(0, min(new["hp_max"], raw))
        else:
            after = max(0, raw)
        if after != before:
            new[key] = after
            changes.append({"field": key, "from": before, "to": after})


STUCK = "修為卡在瓶頸，沒有再長"


def _gain_cultivation(new: dict, amount: int, changes: list[dict], events: list[str]) -> None:
    before = new["cultivation"]
    lv, stage, after, stages = realm.advance(new["realm_lv"], new["stage_index"], max(0, before + amount))
    if stages:
        changes.append({"field": "cultivation", "from": before, "to": after, "reason": "breakthrough"})
        events += [f"境界提升：晉入{name}" for name in stages]
    elif after != before:
        changes.append({"field": "cultivation", "from": before, "to": after})
    new.update(realm_lv=lv, stage_index=stage, cultivation=after)
    if amount > 0 and realm.at_bottleneck(lv, stage, after):   # 16n：剛到才寫完整一句，卡著的回合只寫短句
        events.append(f"修為已達瓶頸（{realm.stage_name(lv, stage)}圓滿），必須主動衝關才能再進" if after != before
                      else STUCK)
    elif amount > 0 and realm.at_gate(lv, stage, after):
        events.append(f"{realm.stage_name(lv, stage)}圓滿；再往前一步就是{realm.stage_name(lv, stage + 1)}，要主動踏入")


# ── 瀕死 ─────────────────────────────────────────────────────────────────────
def _dying_turn(new: dict, judgment: Judgment, advance: int, changes, events, hurt, marks) -> None:
    """瀕死中的這一回合：依行動、受傷、時間調整傷勢，再看是否脫離或死亡。以代價換命、頓悟會引起天道注視。"""
    before = new["wound"]
    wound = before
    if judgment.action_type == PRICE and judgment.price:
        relief = _pay_price(new, judgment.price, changes, events)
        wound -= relief
        if relief:
            marks.append((heaven.PRICE, heaven.GAIN[heaven.PRICE]))
    elif judgment.all_checks and judgment.all_checks[0].target == TREAT:
        wound += TREAT_WOUND[judgment.all_checks[0].outcome]
        events.append(f"療傷{judgment.all_checks[0].outcome}")
    elif judgment.action_type in STRENUOUS:
        wound += WOUND_STRENUOUS
        events.append("瀕死之身強行劇烈行動，傷勢加重")
    else:
        wound += WOUND_OTHER
    wound += hurt["overflow"] * WOUND_PER_DAMAGE + advance // WOUND_TIME_DIVISOR
    wound = max(0, min(WOUND_FATAL, wound))
    events.append(f"傷勢：{before} → {wound}")
    new["wound"] = wound
    if wound >= WOUND_FATAL:
        new.update(status="FALLEN", wound=WOUND_FATAL)
        events.append("傷勢過重，殞落")
    elif wound <= WOUND_RECOVERED:
        _recover(new, judgment, changes, events, marks)


def _pay_price(new: dict, price: str, changes, events) -> int:
    """以命換命：付了代價就一定生效（不擲骰）。回傳減輕的傷勢。"""
    if price == BURN_LIFESPAN:
        if character.lifespan(new) is None:
            events.append("已不受壽元所限，無壽元可燃")
            return 0
        new["lifespan_adjust"] -= BURN_YEARS
        events.append(f"燃燒壽元 {BURN_YEARS} 年，強壓傷勢")
        return BURN_RELIEF
    if price == SACRIFICE_CULTIVATION:
        before = (new["stage_index"], new["cultivation"])
        if new["cultivation"] >= SACRIFICE_CULTIVATION_LOSS:
            new["cultivation"] -= SACRIFICE_CULTIVATION_LOSS
        elif new["stage_index"] > 0:          # 修為不夠：跌落一個小境界補上
            new["stage_index"] -= 1
            new["cultivation"] += realm.PROGRESS_PER_STAGE - SACRIFICE_CULTIVATION_LOSS
            events.append(f"境界跌落：退回{realm.stage_name(new['realm_lv'], new['stage_index'])}")
        else:
            new["cultivation"] = 0
        if before[1] != new["cultivation"]:
            changes.append({"field": "cultivation", "from": before[1], "to": new["cultivation"]})
        events.append("散去修為，強壓傷勢")
        return SACRIFICE_RELIEF
    return 0


def _recover(new: dict, judgment: Judgment, changes, events, marks) -> None:
    hp = max(1, round(new["hp_max"] * RECOVERED_HP_RATIO))
    changes.append({"field": "hp", "from": new["hp"], "to": hp})
    status_mod.add(new["statuses"], status_mod.make(LINGERING, status_mod.NEGATIVE, new["wound"]))
    events.append(f"脫離瀕死，留下狀態「{LINGERING}」（嚴重度 {new['wound']}）")
    new.update(status="ALIVE", hp=hp, wound=0)
    if judgment.insight_roll and judgment.insight_roll <= new["attributes"]["wisdom"] // 4:
        events.append("生死之間有所頓悟")
        marks.append((heaven.INSIGHT, heaven.GAIN[heaven.INSIGHT]))
        _gain_cultivation(new, INSIGHT_CULTIVATION, changes, events)
        law = laws.insight_target(new) if new["realm_lv"] >= 1 else ""   # 第 3b-1 步：也加感悟
        if law:
            new["insight"], reached = laws.reward(new, law, INSIGHT_CULTIVATION)
            events.extend(reached)


# ── 大境界突破 ───────────────────────────────────────────────────────────────
def _breakthrough(new: dict, judgment: Judgment, now: int, changes: list[dict], events: list[str],
                  hurt: dict, marks: list) -> None:
    """大境界突破的結果。規則見 domain/breakthrough.py。成功會引起天道注視（第 18-1 步）。"""
    if judgment.note == realm.GATE_NOTE:   # 16l 第 6 題：主動踏入破格期
        new.update(breach.start(new, now), stage_index=new["stage_index"] + 1, cultivation=0)
        changes.append({"field": "cultivation", "from": realm.PROGRESS_PER_STAGE, "to": 0, "reason": "breakthrough"})
        events += [f"境界提升：踏入{realm.stage_name(new['realm_lv'], new['stage_index'])}", breach.START_EVENT]
        return
    if not judgment.rolled:
        events.append(f"尚未具備衝關條件：{judgment.note}")
        return
    lv, target = new["realm_lv"], new["realm_lv"] + 1
    if judgment.is_success:
        start = breakthrough.GREAT_SUCCESS_CULTIVATION if judgment.outcome == GREAT_SUCCESS else 0
        changes.append({"field": "cultivation", "from": new["cultivation"], "to": start, "reason": "breakthrough"})
        marks.append((heaven.BREAK, heaven.breakthrough_gain(target, new["realm_since"], now)))
        new.update(realm_lv=target, stage_index=0, cultivation=start, realm_since=now, breach=None,   # 破空：倒數結束
                   breakthrough_ready_at=now + breakthrough.cooldown_shichen(target + 1))
        events.append(f"大境界突破：踏入{realm.stage_name(target, 0)}")
        events.extend(laws.realm_up(new))
        span = character.lifespan(new)
        events.append(f"壽元上限延長至 {span} 歲" if span is not None else "從此不再受壽元所限")
        return

    great = judgment.outcome == GREAT_FAILURE
    new["breakthrough_ready_at"] = now + breakthrough.cooldown_shichen(target, doubled=great)
    hp_loss = round(new["hp_max"] * (breakthrough.GREAT_FAIL_HP_RATIO if great else breakthrough.FAIL_HP_RATIO))
    _apply_mods(new, {"hp": -hp_loss}, changes, hurt)
    loss = new["cultivation"] if great else breakthrough.FAIL_CULTIVATION_LOSS
    _gain_cultivation(new, -loss, changes, events)
    events.append("衝關大失敗，走火入魔" if great else "衝關失敗，修為倒退")
    if great and lv >= breakthrough.STAGE_DROP_FROM_LV and new["stage_index"] > 0:
        new["stage_index"] -= 1
        events.append(f"境界跌落：退回{realm.stage_name(lv, new['stage_index'])}")
    if great and lv >= breakthrough.LIFESPAN_HALVING_FROM_LV:
        remaining = character.remaining_life_shichen(new, now)
        if remaining is not None and remaining > 0:
            lost_years = remaining // clock.SHICHEN_PER_YEAR // 2
            new["lifespan_adjust"] -= lost_years
            events.append(f"道基崩毀：壽元折損 {lost_years} 年")
