"""世界層的純規則：新局的時間跨度。純函式。

規則（2026-10-04 與使用者討論定案，見 progress/DESIGN_OUTLINE.md 7.1）：
- 一個世界同一時間只有一局；這一局結束後，才能在同一世界開下一局。
- 在同一世界開新局時，玩家從幾個跨度選，確切年數由 Python 在範圍內隨機決定。
- 跳過的時間裡世界如何變化，由背景演化（第 10 步）推算；這裡只決定時間跳多久，O(1)。
"""
from __future__ import annotations

import random
from dataclasses import dataclass

from .clock import SHICHEN_PER_YEAR

ORIGIN, LANDED = "origin", "landed"   # 原初世界、副本落地的世界（第 12 步）
IMMORTAL = "immortal"                 # 仙域（16l）：每個玩家一個，同時可以有好幾個飛升上來的主角


@dataclass(frozen=True)
class Span:
    key: str
    label: str
    min_years: int
    max_years: int


SPANS: dict[str, Span] = {s.key: s for s in (
    Span("immediate", "緊接其後", 0, 1),
    Span("generation", "一代人之後", 20, 50),
    Span("century", "百年之後", 80, 150),
    Span("centuries", "數百年之後", 300, 800),
)}


def jump_shichen(rng: random.Random, span_key: str) -> int:
    """在跨度範圍內抽出要跳過幾年（以時辰計）。span_key 不存在時丟 KeyError，由呼叫端轉成 400。"""
    span = SPANS[span_key]
    return rng.randint(span.min_years, span.max_years) * SHICHEN_PER_YEAR
