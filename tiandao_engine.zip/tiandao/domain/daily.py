"""日常面板（16m 第 2 題）：修練、營生、靜養按一下就做。純函式。

規則（2026-10-29 與使用者定案，見 progress/WHITEPAPER.md 16m，時長暫定）：
- 面板的選擇換成一句行動（「閉關3年」），沿用現有的時長解析與判定；不經過分類。
- 沒事發生就不呼叫說書人，敘事由事實組成；中途有人上門、事件、天道開口時照常交給說書人（由 game 層判斷）。
"""
from __future__ import annotations

import re

from . import clock, effects, era, laws
from . import judgment as J
from .effects import JOBS, WORK_WAGE

# 種類 → (判定類型, 單位, 可選的數量)；營生（16o）都是做工
KINDS = {
    "吐納": (J.CULTIVATE, "個月", (1, 3, 6)),
    "參悟": (J.STUDY, "個月", (1, 3, 6)),
    "閉關": (J.CULTIVATE, "年", (1, 3, 10)),
    **{k: (J.WORK, "個月", (1, 3, 6)) for k in JOBS},
    "靜養": (J.REST, "天", (1, 7, 30)),
}


def action(body) -> tuple[str, str] | None:
    """面板送來的 {"kind", "count", "law"} → (行動的文字, 判定類型)；不是面板的回合回傳 None，不合法丟 ValueError。"""
    if not body:
        return None
    if not isinstance(body, dict):
        raise ValueError("日常面板的選項不對。")
    kind, count, law = body.get("kind"), body.get("count"), body.get("law") or ""
    if kind not in KINDS or count not in KINDS[kind][2] or (kind == "參悟" and law not in laws.SYSTEMS):
        raise ValueError("日常面板的選項不對。")
    nature, unit, _ = KINDS[kind]
    return f"{kind}{law}{count}{unit}", nature


def panel(place_type: str, realm_lv: int, foe: str = "", card: dict = era.DEFAULT, seen=()) -> dict:
    """畫面用：每種的可選數量；laws：見過現象、沒鎖的系（參悟只能挑這些）；jobs：各營生這裡做不了的原因（空字串＝做得了）；
    wage：各營生一個月的錢；names：各營生這個時代的叫法；foe：在場對峙的仇家（面板鎖住，16m 第 7 題）。"""
    return {"kinds": {k: list(v[2]) for k, v in KINDS.items()}, "units": {k: v[1] for k, v in KINDS.items()},
            "laws": [s for s in laws.OPEN_SYSTEMS if s in seen], "jobs": {k: "" if place_type in j.places else j.where for k, j in JOBS.items()},
            "wage": {k: round(WORK_WAGE * 2 ** realm_lv * j.wage) for k, j in JOBS.items()},
            "names": {k: era.job_text(k, card) for k in JOBS},
            "locked": f"{foe}還在這裡衝著你來，先處理他" if foe else ""}


NEWS = ("江湖大事：", "天災：", "國事：", "江湖傳聞：")   # 外面的事
TIME = ("時間流逝：", "歷經 ", "季節由", "四季輪轉")       # 時間另寫一句
PAID = ("領到工錢", "賣了換錢")                          # 營生的事實：錢與時間都另有一句
VERDICT = re.compile(r"^\S{1,4}?(?:大成功|成功|大失敗|失敗)：")   # 「修行失敗：修為幾乎沒有增長」→ 只留結果
SHOWN_NEWS = 3


def narrative(text: str, delta, *, start: int, end: int, money: str, near: tuple[str, ...] = ()) -> str:
    """沒事發生的日常不請說書人：結果一段、這段時間外面的事一段（16n 第 17 題）。
    near：所在地與所在的國、州，提到它們的外面的事排前面。"""
    news, own = [], []
    for e in delta.events + delta.side:
        if e.startswith(NEWS):
            news.append(e.split("：", 1)[1].removeprefix("聽說"))
        elif not e.startswith(TIME) and not e.endswith(PAID):
            own.append(VERDICT.sub("", e))
    if effects.STUCK in own:   # 卡在瓶頸時，判定那句「修為有所增長」不算數
        own = [e for e in own if e == effects.STUCK or not e.startswith("修為")]
    worded = any("修為" in e for e in own)   # 修煉的結果已有一句，不再寫「修為：增加（小幅）」
    net = {}   # 同一欄只寫淨變化：工錢進、賠款出併成一行（16o 第 11 題）
    for c in delta.changes:
        net[c["field"]] = {**c, "from": net.get(c["field"], c)["from"]}
    own = [effects.describe_change(c).replace("凡人錢", money) for c in net.values()
           if c["field"] != "hp" and c["from"] != c["to"] and not (worded and c["field"] == "cultivation")] + own
    s = delta.sheet
    if any(c["field"] == "hp" for c in delta.changes):
        own.append("氣血已經恢復" if s["hp"] >= s["hp_max"] else "傷勢好了一些"
                   if sum(c["to"] - c["from"] for c in delta.changes if c["field"] == "hp") > 0 else "受了些傷")
    elif text.startswith("靜養"):
        own.append("氣血本來就充足")
    if end - start >= clock.NOTABLE_PASSAGE:
        a, b = (f"第{d['year']}年{d['season']}" for d in (clock.describe(start), clock.describe(end)))
        own.append(f"過了{clock.format_span(end - start).replace(' ', '')}（{a if a == b else f'{a} → {b}'}）")
    news = sorted(dict.fromkeys(news), key=lambda n: not any(w in n for w in near))[:SHOWN_NEWS]
    return f"你{text}。" + "".join(f"{x}。" for x in own) + ("\n這段時間外面的事：" + "；".join(news) + "。" if news else "")
