"""搭配卡（WHITEPAPER 16u 外貌）：外貌不是各抽各的，先由 Python 配好一張卡，再寫成一段話。純函式。

素材在 rules/content/looks.txt，種族特徵在 peoples/。卡片存在角色卡的 look，長大、突破照同一張改寫。
抽靈感用句型版（text），開場請模型寫成一段；模型寫的過不了 usable 就用句型版。
"""
from __future__ import annotations

import random
import re

from ..config import PROJECT_ROOT
from . import inspiration, names

TABLE = names.read_table(PROJECT_ROOT / "rules" / "content" / "looks.txt")
MOODS = tuple(TABLE["氣質"])
COMMON = "凡人"       # 沒列到的身分
ADEPT, MASTER = "修士", "高手"   # 沒有職業的修士，衣著看境界
MAX_PICK = 20
CHILD_STYLES = ("雙丫髻",)      # 成年人不梳
TIED = ("簪成道髻", "編辮盤起", "披散不束", "凌亂不羈")   # 這幾種是動作，髮色後面要接「頭髮」
BALD = "剃度光頭"               # 沒有頭髮，不寫髮色
WRONG ={"女": ("少年", "男子", "漢子", "小夥"), "男": ("少女", "女子", "姑娘")}   # 寫錯性別的字眼
MINOR_WRONG = ("豐腴", "嬌媚", "媚態", "酥胸", "胸脯", "腰肢", "風情")             # 未成年不能用（底線）


def card(rng: random.Random, *, gender: str, minor: bool, origin: str = "", race: str = "", picks: dict | None = None) -> dict:
    """配一張卡。picks：玩家留下的項目（hair、style、clothes、mood），其他的抽。
    衣著和痕跡看身分或職業（origin），髮看性別和年紀，族風看種族，配件看性別。"""
    picks, skip = picks or {}, inspiration.skipped(gender, minor) + (() if minor else CHILD_STYLES)

    def pick(key: str, pool) -> str:
        chosen = str(picks.get(key) or "")[:MAX_PICK]
        return chosen or rng.choice([v for v in pool if v not in skip])

    def of(field: str) -> tuple:
        return TABLE[field].get(origin) or TABLE[field][COMMON]

    def fresh(pool, *worn: str) -> str:   # 同一個部位不寫兩次，看開頭的字（腰間、袖口）
        return rng.choice([v for v in pool if v[:1] not in {w[:1] for w in worn}] or ("",))

    mood = picks.get("mood") if picks.get("mood") in MOODS else rng.choice(MOODS)
    clothes = pick("clothes", of("衣著"))
    scar = fresh(of("痕跡"), clothes)
    trim = fresh(TABLE["族風"].get(race, ()), clothes, scar)
    return {"hair": pick("hair", inspiration.APPEARANCE["髮色"]), "style": pick("style", inspiration.APPEARANCE["髮型"]),
            "clothes": clothes, "mood": mood, "scar": scar, "trim": trim,
            "item": fresh(TABLE["配件"].get(gender, ()), clothes, scar, trim)}


def hair(c: dict) -> str:
    if c["style"] == BALD:
        return BALD
    return f"{c['hair']}頭髮{c['style']}" if c["style"] in TIED else c["hair"] + c["style"]


def parts(c: dict, mark: str) -> dict:
    def more(key: str) -> str:   # 舊角色的卡片沒有族風和配件
        return f"，{c[key]}" if c.get(key) else ""
    return {"衣著": c["clothes"] + more("trim"), "髮": hair(c), "神情": TABLE["氣質"][c["mood"]][0],
            "痕跡": c["scar"] + more("item"), "族徵": mark}


def line(c: dict, mark: str) -> str:
    """給說書人的卡片。"""
    return "｜".join(f"{k}：{v}" for k, v in parts(c, mark).items() if v)


def text(c: dict, mark: str) -> str:
    """句型版：同一張卡每次一樣。"""
    pattern = random.Random(f"{c['hair']}{c['clothes']}").choice(sorted(TABLE["句型"].values()))[0]
    filled = re.sub(r"\{(\w+)\}", lambda m: parts(c, mark)[m.group(1)], pattern)
    return re.sub(r"[。，]*。", "。", filled).strip("。，") + "。"


def usable(written: str, gender: str, minor: bool, features: tuple = ()) -> bool:
    """模型寫的能不能用：性別字眼對、未成年沒有不能用的字、最明顯的族徵有寫到。"""
    bad = WRONG.get(gender, ()) + (MINOR_WRONG if minor else ())
    return not any(w in written for w in bad) and all(f[-2:] in written for f in features[:2])
