"""事端（WHITEPAPER 16t）：地點帶的內容。純函式，不碰資料庫、不呼叫 AI。

模板是人寫的 TXT（rules/content/plots/，RuleBook.plots）：{欄位: [[內容, 內容], ...]}。
世界組合時挑一條，填入當地的人和地方（cast），之後不管玩家在不在都照時間線走到結局。
"""
from __future__ import annotations

import random
import re

from . import atlas, dark, deck, era, names, npc, pulse, route, space
from .clock import SHICHEN_PER_DAY
from .incident import WORLD
from .races import RACES

BY = "plot"                 # 事端的人物（npcs.created_by）
TRACE = "事端餘波"            # 結局留在地點上的狀況
SCOPE = "範圍"               # 第 116-1 題：條件寫「範圍:鄉鎮」；沒寫看地點本身的規模
SCOPES = ("村落", "鄉鎮", "城市", "國家")
TOWN = "城鎮"                # 村子算進最近的鎮（第 116-2 題）
MAIN = ("", "主")            # 處的「在」（第 116-9 題）：空、主＝主地點
SEATS = {"村": "村落", "鎮": TOWN, "宗門": "宗門"}   # 其他照地點種類挑；城、別州看州的主城
BREW_DAYS = (30, 120)              # 醞釀多久（第 11 題，暫定）：到期沒人來就走到結局
SMALL_CHANCE = 0.25          # 待在有事端的地方，每回合有多少機會發生一件小事（第 6 題，暫定）
OTHER_SHARE = 0.3            # 通用隨機事件的機率留下幾成（第 6 題，暫定）
POINT = "轉折"               # 走過的轉折點，和線索一起記在角色卡
REST = 30 * SHICHEN_PER_DAY        # 結束後隔多久放新的（暫定）
TRACE_LEN = 360 * SHICHEN_PER_DAY  # 痕跡留多久（暫定）
MAX_NAMES = 900              # 世界的人物、地點接近存檔上限（saves.MAX_WORLD_NAMES）就不再放
HOME_GOAL = "守護"           # 第 8 題：守護的人不會自己離開
EVIDENCE = "物證"            # 線索種類：另一種是「話」
KEY_ROLE = "隱瞞者"          # 他知道的事，要被物證逼問才說
VICTIM = "受害者"            # 同範圍的事端由他來請託（第 116-10 題）
CHAPTER = "章"               # 一般命的章（第 116c 批）：cast 多這一格「這一生:第幾章:宮:人:演的角色」，不佔範圍單位的名額
LAYERS = ("平時", "被問到", "被逼問")
LEFT = "探索、潛行"            # 人死了，線索留在他住的地方，要用搜的（16v 第 20 題）
HOW = {"交談": "問問", "社交": "問問", "探索": "查查", "潛行": "摸進", "戰鬥": "逼問"}   # 線索的行動，機會卡怎麼說
WORDS = names.words(names.HUMAN)   # 舊事端的 cast 沒有叫法：照人族的（16u 第 7 題）


def parse(text: str) -> dict[str, list[list[str]]]:
    """一條事端模板的全文（rules/content/plots/ 的檔、模型寫的 plots_m.body）：「欄位｜內容｜內容」一行一列，# 開頭是註解。"""
    out: dict[str, list[list[str]]] = {}
    for line in text.splitlines():
        if line.strip() and not line.startswith("#"):
            field, *rest = line.split("｜")
            out.setdefault(field, []).append(rest)
    return out


def name(t: dict) -> str:
    return t["牌"][0][0]


def truth(t: dict, cast: dict[str, str]) -> str:
    """真相；隱瞞者是勢力的人（模型寫的事端，第 5 題乙）多一句。"""
    return fill(t["真相"][0][0] + (t["勢力句"][0][0] if "勢力" in cast and t.get("勢力句") else ""), cast)


def ranged(t: dict) -> str:
    """模板寫的範圍，沒寫＝""。"""
    return dict(deck.card(t["牌"][0]).need).get(SCOPE, "")


def scope(t: dict, place: dict) -> str:
    return ranged(t) or place["scale"]


def surfaces(t: dict, era_now: str = era.ANCIENT) -> list[list[str]]:
    """這個時代的表面（第 8-6 批）：「表面｜現代｜糧=…｜…」標了時代的只在那個時代用，沒標的是古代。
    一個時代沒有表面＝這條在那個時代不出（只限古代的四條）；完全沒寫表面的算古代、沒有詞位。"""
    tagged = lambda r: r[0] if r and r[0] in era.ERAS else era.ANCIENT   # noqa: E731
    return [r[1:] if r and r[0] in era.ERAS else r for r in t.get("表面") or [[]] if tagged(r) == era_now]


def fits(t: dict, place: dict, race: str = "", unit: str = "", era_now: str = era.ANCIENT) -> bool:
    """開頭一行共用六欄的條件（第 4-4 題）：地點、族。race：這裡是哪一族的地盤，空＝不看；模板沒寫族是三族通用（16u 第 7 題）。
    unit：要放的範圍（第 116-1 題），空＝地點本身那一級；模板的範圍要對上。era_now：這個時代要有表面（第 8-6 批）。"""
    unit = unit or place["scale"]
    return unit in SCOPES and scope(t, place) == unit and bool(surfaces(t, era_now)) and deck.fits(
        deck.card(t["牌"][0]), {"地點": (place["type"],), "族": (race,) if race else RACES, SCOPE: (unit,)})


# ── 範圍單位（第 116-2、116-4、116-9 題）────────────────────────────────────
def units(locs: list[dict], conns: list[dict], sky: dict | None, here: str, states: dict | None = None) -> dict[str, str]:
    """這裡屬於哪幾個範圍單位：{範圍: 主地點}。村落、鄉鎮先算自己那一級，村子另算進最近的鎮（州內的路）；
    城市＝這一州的主城，國家＝這一國第一個生成了的州的主城；還沒生成的州不算。沒有骨架的舊世界只有村落、鄉鎮。"""
    by = {l["name"]: l for l in locs}
    p = by.get(space.town_of(locs, here))
    if not p:
        return {}
    out = {p["scale"]: p["name"]} if p["scale"] in SCOPES[:2] else {}
    far = space.distances_from([c for c in conns if c["tier"] not in space.STATE_ROADS], p["name"])
    town = min((n for n in far if by.get(n, {}).get("type") == TOWN), key=far.get, default="")
    if town:
        out.setdefault(SCOPES[1], town)
    if sky:
        states = atlas.state_map(sky, conns) if states is None else states
        mine = next(s for s in sky["states"] if s["name"] == states.get(p["name"], sky["start"]))
        if mine["built"]:
            seat = next(s for s in sky["states"] if s["nation"] == mine["nation"] and s["built"])
            out |= {SCOPES[2]: mine["capital"], SCOPES[3]: seat["capital"]}
    return out


def members(locs: list[dict], conns: list[dict], sky: dict | None, unit: str, main: str, states: dict | None = None) -> list[dict]:
    """範圍單位裡的地點（家級的子地點不算）。"""
    states = (atlas.state_map(sky, conns) if sky else {}) if states is None else states
    return [l for l in locs if l["scale"] != space.SCALES[0] and units(locs, conns, sky, l["name"], states).get(unit) == main]


def at(row: list[str]) -> str:
    """處的「在」欄（第 116-9 題）：五欄才有，舊的四欄＝主。"""
    return row[2] if len(row) > 4 else ""


def seat(rng: random.Random, where: str, main: str, near: list[dict], states: dict, sky: dict | None) -> str:
    """這一處放在哪個地點底下：範圍裡挑一個那種地點，挑不到放主地點。"""
    if where in MAIN:
        return main
    caps = {s["capital"] for s in (sky or {}).get("states", [])}
    ok = {"城": lambda l: l["name"] in caps,
          "別州": lambda l: l["name"] in caps and states.get(l["name"]) != states.get(main)}.get(where, lambda l: l["type"] == SEATS.get(where))
    found = sorted(l["name"] for l in near if ok(l) and l["name"] != main)
    return rng.choice(found) if found else main


# ── 角色找誰演（第 126-12、4-11-2～4-11-5 題）：人物行最後一欄是條件 ──────────────
NEW, TIE = "新來", "跟"            # 一律生新人；「跟某角色:羈絆種類」
SIDE, TEMPER = "身邊", "性子"       # 事端第二批 a：「身邊:受害者」先挑他身邊的人；「性子:膽識高、疑心高」兩種性格擇一
CLOSE = {"親人", "師徒", "伴侶", "結義", "主僕", "友人", "恩人"}   # 身邊的人（第二批第 5 題乙：家人、徒弟、夥計、熟人）
KEYS = ("職業", "目的", *npc.TRAIT_LABELS.values(), SIDE, TEMPER)
TRAIT_KEYS = {v: k for k, v in npc.TRAIT_LABELS.items()}
TIE_HITS = {"仇家": pulse.HOSTILE}  # 配到新人時補的原因（兩邊各記一筆）


def wants(row: list[str]) -> tuple[tuple[tuple[str, str], ...], dict[str, str], bool]:
    """人物行的條件 →（條件, {角色: 羈絆種類}, 新來）。"""
    words = row[-1].split()
    pairs = [tuple(w.split(":", 1)) for w in words if ":" in w]
    return (tuple(p for p in pairs if not p[0].startswith(TIE)), {k[len(TIE):]: v for k, v in pairs if k.startswith(TIE)}, NEW in words)


def facts(p: dict) -> dict[str, tuple[str, ...]]:
    traits = {v: npc.trait_level(p[k]) for k, v in npc.TRAIT_LABELS.items()}
    return {"職業": (p.get("job", ""),), "目的": (p["goal"],), **{v: (x,) for v, x in traits.items()},
            TEMPER: tuple(f"{v}{x}" for v, x in traits.items())}


def temper(need: dict[str, str]) -> dict[str, int]:
    """生新人時的性格：「野心:高」，「性子:膽識高、疑心高」取第一種。"""
    pairs = [(k, v) for k, v in need.items() if k in TRAIT_KEYS] + [(v[:2], v[2:]) for v in need.get(TEMPER, "").split("、")[:1] if v]
    return {TRAIT_KEYS[k]: npc.TRAIT_LEVELS[v] for k, v in pairs}


def _fill_roles(rng: random.Random, t: dict, pool: list[dict], ties: dict, first: set[str] = frozenset(),
                want: dict[str, tuple] | None = None) -> dict[str, str]:
    """用現成的人填角色：條件多的先填；條件對上，跟已經由現成的人填上的角色羈絆也對上（兩頭都查）。ties：{(甲, 乙): {種類}}。
    first：對得上就先挑的人（章那一宮的人，第 116-7 題）。want：結的人想先試的角色（domain/knot.TRY，第 7-4a 批），先試的先挑。"""
    want = want or {}
    got: dict[str, str] = {}
    back = {r: (row[0], kind) for row in t["人物"] for r, kind in wants(row)[1].items()}
    asked = {r for roles in want.values() for r in roles}   # 有人想演的角色先填（不然想演的人先被別的角色挑走）
    for row in sorted(t["人物"], key=lambda row: (SIDE in row[-1], row[0] not in asked, -len(row[-1].split()))):   # 「身邊」等那個角色先填
        need, tie, new = wants(row)
        side = dict(need).get(SIDE)
        need = tuple(p for p in need if p[0] != SIDE)
        tie |= dict([back[row[0]]]) if row[0] in back else {}
        ok = [p for p in pool if p["name"] not in got.values() and not new
              and all(any(x in facts(p).get(k, ()) for x in v.split("、")) for k, v in need)
              and all(r not in got or kind in ties.get((p["name"], got[r]), ()) for r, kind in tie.items())]
        near = [p for p in pool if side in got and p["name"] not in got.values() and not new
                and CLOSE & ties.get((p["name"], got[side]), set())]
        ok = near or ok   # 身邊的人不看其他條件；挑不到照其他條件
        rank = {p["name"]: want[p["name"]].index(row[0]) if row[0] in want.get(p["name"], ()) else 9 for p in ok}
        top = min(rank.values(), default=9)
        ok = [p for p in ok if rank[p["name"]] == top] if top < 9 else [p for p in ok if p["name"] in first and p["name"] not in want] or ok
        if ok:
            got[row[0]] = rng.choice(ok)["name"]
    return got


def choose(rng: random.Random, templates: list[dict], place: dict, last: str = "", race: str = "",
           pool: list[dict] = (), ties: dict | None = None, unit: str = "", first: set[str] = frozenset(),
           want: dict[str, tuple] | None = None, era_now: str = era.ANCIENT) -> tuple[dict | None, dict[str, str]]:
    """挑一條適合這裡的事端（上一條和這條一樣就換一條，只有這一條適合時才重複）：當地現成的人（pool）填得上最多角色的優先，
    同分隨機（第 126-12-1 題）。回傳（模板, {角色: 現成的人}）。unit：範圍（fits）。first：先算這些人演到幾個（第 116-7 題）。
    want：結的人先試的角色（_fill_roles）。"""
    fit = [t for t in templates if fits(t, place, race, unit, era_now)]
    tries = [(t, _fill_roles(rng, t, list(pool), ties or {}, first, want)) for t in [t for t in fit if name(t) != last] or fit]
    score = lambda g: (len(set(g.values()) & first), len(g))   # noqa: E731
    top = max((score(g) for _, g in tries), default=None)
    return rng.choice([x for x in tries if score(x[1]) == top]) if tries else (None, {})


def faces(rng: random.Random, t: dict, era_now: str = era.ANCIENT) -> dict[str, str]:
    """這次的表面（泉＝山泉），照這個時代挑。"""
    return dict(pair.split("=") for pair in rng.choice(surfaces(t, era_now)))


def spots(t: dict, town: str, cast: dict[str, str], parents: dict[str, str] | None = None) -> list[dict]:
    """這條事端的幾處（子地點）。名字用 cast 裡定好的（撞名時加了方位，plots._spot；處名可以有詞位）。parents：放在哪個地點底下（seat），沒寫＝主地點。"""
    return [{"name": cast.get(key, f"{town}{fill(short, cast)}"), "type": type_, "scale": "家", "parent": (parents or {}).get(key, town),
             "description": fill(text, cast), "danger": "", "discovered_turn": 0} for key, short, *_, type_, text in t["處"]]


def fill(text: str, cast: dict[str, str]) -> str:
    return re.sub(r"\{(\w+)\}", lambda m: cast.get(m.group(1)) or WORDS.get(m.group(1), m.group(0)), text)


def timeline(t: dict, turned: bool = False) -> list[tuple[int, str, str]]:
    """（第幾時辰, 事, 結果欄）。"""
    return sorted((int(hour), text, res) for hour, text, res in t.get("轉向線" if turned else "時間線", []))


def ending(t: dict, turned: bool = False) -> tuple[int, str, list[str], str]:
    """（第幾時辰, 結果, 痕跡, 結果欄）。轉向的結局有兩種痕跡：自然死的、玩家殺的。"""
    hour, result, *traces, res = t["轉向結局" if turned else "結局"][0]
    return int(hour), result, traces, res


# ── 結果欄（第 126-13、4-11-6～4-11-16 題）：[角色:[角色:]]類:值 ──────────────────
LAW, NEWS, KNOW = "法", "聞", "知情"
JAIL, EXILE, SPREAD, OLD, TRUTH = "抓", "流放", "傳開", "舊聞", "真相"
CHAT, RUMOR, DROP = "閒話", "謠", "撤"   # 事端第二批 a：放一則閒話；謠:記＝村鎮裡的人對受害者記「謠言」；撤:種類＝撤掉受害者那頭這種原因
HOSTAGE, KIN = "人質", {"親人", "伴侶"}   # 事端第二批 b：綁架的人質是受害者的家人（旁人）
LOCK, BACK, DIE = "關", "回", "死"       # 地:關＝搬進藏處、地:回＝搬回苦主家；死:撕票＝真的死
STASH, HOME = "藏處", "苦主家"
JAIL_SPOT = "牢房"          # 抓的人搬進這一處；模板沒有就自動多開一處（第 4-11-15 題）
MINE = ("好感", "帳", "財")   # 算在你身上的（轉折才有，回合裡結算）；你知道（知情沒寫角色）照樣由 write 記


def effects(rec: dict, t: dict, text: str) -> list[tuple[str, str, str, str]]:
    """結果欄 →（誰, 對誰, 類, 值）：開頭的角色換成人名，沒寫＝""（你；聞、地＝這個村鎮）。
    旁人（模型寫的事端：首領、仇家）也算角色；那一處沒有這個人（沒有勢力）時這筆不算。"""
    roles, out = {r[0] for r in t["人物"]} | {r[0] for r in t.get("旁人", [])}, []
    for token in text.split():
        parts = token.split(":")
        if any(p in roles and p not in rec["cast"] for p in parts[:2]):
            continue
        who = [rec["cast"][parts.pop(0)] for _ in range(2) if parts[0] in roles]
        out.append((*(who + ["", ""])[:2], parts[0], ":".join(parts[1:])))
    return out


def mine(e: tuple[str, str, str, str]) -> bool:
    """這一筆在回合裡結算：他對你的好感、帳，你的財。"""
    return e[2] in MINE and not e[1]


def outcomes(rec: dict, t: dict, stage: int, ended: bool) -> list[str]:
    """這次走過的時間線、結局帶的結果欄。"""
    turned = rec["turned_shichen"] is not None
    return [r[2] for r in timeline(t, turned)[rec["stage"]:stage]] + ([ending(t, turned)[3]] if ended else [])


def turning(t: dict, rec: dict, dead: set[str]) -> list[str] | None:
    """第 9 題：還沒轉向、模板寫了轉向的角色死了，回傳那一行（代號, 接手, 自然死的事實, 玩家殺的事實）。"""
    if rec["turned_shichen"] is not None:
        return None
    return next((row for row in t.get("轉向", []) if rec["cast"].get(row[0]) in dead), None)


def turn(rec: dict, row: list[str], killed: set[str], now: int) -> tuple[dict, str]:
    """事情轉向：回傳（轉向後的事端, 當下的事實）。"""
    by_player = rec["cast"][row[0]] in killed
    return {**rec, "turned_shichen": now, "killed": int(by_player), "stage": 0}, fill(row[3 if by_player else 2], rec["cast"])


def heir_dead(t: dict, rec: dict, dead: set[str]) -> bool:
    """接手的人也死了：事情提早了結。"""
    return rec["turned_shichen"] is not None and any(rec["cast"].get(row[1]) in dead for row in t.get("轉向", []))


def brew_until(rng: random.Random, now: int) -> int:
    return now + rng.randint(*BREW_DAYS) * SHICHEN_PER_DAY


def brewing(rec: dict) -> bool:
    """還在醞釀：玩家沒走進來過，關鍵人物也還活著（第 11 題）。"""
    return rec["lit_shichen"] is None and rec["turned_shichen"] is None


def _clock(rec: dict) -> int:
    """時間線從什麼時候算：轉向的時候，否則是爆發的時候。"""
    return rec["lit_shichen"] if rec["turned_shichen"] is None else rec["turned_shichen"]


def advance(rec: dict, t: dict, now: int) -> tuple[int, list[str], bool]:
    """走到 now：回傳（走到第幾步, 這次發生的事, 結束了沒）。"""
    turned = rec["turned_shichen"] is not None
    passed = now - _clock(rec)
    end = ending(t, turned)[0]
    steps = [text for hour, text, _ in timeline(t, turned) if hour <= min(passed, end)]
    return len(steps), [fill(s, rec["cast"]) for s in steps[rec["stage"]:]], passed >= end


def end_time(rec: dict, t: dict) -> int:
    return _clock(rec) + ending(t, rec["turned_shichen"] is not None)[0]


def room(rec: dict, t: dict, now: int) -> int:
    """離結局還有幾個時辰。還在醞釀算 0。"""
    return 0 if brewing(rec) else end_time(rec, t) - now


def half_gone(rec: dict, t: dict, now: int) -> bool:
    """時間線過半（16v 第 34 題）。"""
    return not brewing(rec) and now * 2 >= _clock(rec) + end_time(rec, t)


def result(rec: dict, t: dict) -> str:
    return fill(ending(t, rec["turned_shichen"] is not None)[1], rec["cast"])


def tag(rec: dict) -> str:
    """線索屬於哪一條事端（存在角色卡裡，匯入存檔後還認得）。"""
    return f"{rec['town']}:{rec['started_shichen']}"


def found(sheet: dict, rec: dict) -> list[dict]:
    return [c for c in sheet["clues"] if c["plot"] == tag(rec)]


def known_of(sheet: dict, rec: dict) -> set[str]:
    """查到的線索、走過的轉折，加上時間線走過幾行（「時:3」＝第三行過了；天災的爆發，domain/newdisasters.py）。"""
    return {c["key"] for c in found(sheet, rec)} | {f"時:{i}" for i in range(1, rec.get("stage", 0) + 1)}


def _met(before: str, known: set[str]) -> bool:
    """前置：空的不用，「甲／乙」查到一條就行（16v 第 72 題：不走單鏈）。"""
    return not before or any(b in known for b in before.split("／"))


def _reached(how: str, verdict) -> bool:
    """行動對得上這條線索：判定成功；問話沒擲骰也算（問了就答，判定失敗才沒問到）。"""
    action = verdict.action_type
    asked = action == "社交" and not verdict.rolled
    return action in how.replace("交談", "社交").split("、") and (verdict.is_success or asked)


def where(row: list[str], rec: dict, t: dict, dead: set[str], sheet: dict) -> tuple[str, str]:
    """線索在哪、怎麼查。暗線搬走的要去新地方搜。"""
    to = dark.moved(sheet, tag(rec)).get(row[0])
    if to:
        return to, LEFT
    place, how = fill(row[2], rec["cast"]), row[3]
    role = role_of(rec, t, place)
    return (rec["cast"][role[1]], LEFT) if role and place in dead else (place, how)


def search(rec: dict, t: dict, sheet: dict, here: str, who: str, verdict, dead: set[str] = frozenset(),
           skip: set[str] = frozenset(), high: bool = False) -> dict | None:
    """這回合查到哪一條線索（一回合最多一條）：地方或人對得上、行動對得上、前置查到了。skip：暗線擋住的（第 5-3 批）。
    high：境界不到這條的範圍，要角色開口的不算（第 116-11 題）。"""
    known = known_of(sheet, rec)
    for row in t["線索"]:
        key, kind, _, _, before, text, _ = row
        place, how = where(row, rec, t, dead, sheet)
        if key not in known | set(skip) and _at(place, here, who, high) and _reached(how, verdict) and _met(before, known):
            return {"plot": tag(rec), "key": key, "kind": kind, "text": fill(text, rec["cast"])}
    return None


def _at(place: str, here: str, who: str, high: bool) -> bool:
    """在這個地方，或眼前就是那個人（境界不到範圍時人不理你，第 116-11 題）。"""
    return place == here or place == who and not high


def _ready(row: list[str], rec: dict, known: set[str], here: str, who: str, high: bool = False) -> bool:
    """轉折點的條件湊齊了沒（不看這回合的行動）：地方或人對得上、前置查到了、還沒走過。"""
    key, where, _, before, *_ = row
    return key not in known and _at(fill(where, rec["cast"]), here, who, high) and _met(before, known)


def point(rec: dict, t: dict, sheet: dict, here: str, who: str, verdict, text: str, high: bool = False) -> list[str] | None:
    """第 5 題：這回合觸發哪個轉折點：條件湊齊，話裡提到關鍵字（點選項一定有），行動沒失敗。
    一列是（代號, 地方或人, 行動, 前置, 關鍵字, 選項, 事實, 收場的痕跡, 結果欄）。"""
    known = known_of(sheet, rec)
    for row in t.get("轉折", []):
        _, _, how, _, words, *_ = row
        spoken = any(w in text for w in fill(words, rec["cast"]).split("、"))
        if _ready(row, rec, known, here, who, high) and spoken and (_reached(how, verdict) if how else not verdict.rolled or verdict.is_success):
            return row
    return None


def offer(rec: dict, t: dict, sheet: dict, here: str, who: str, high: bool = False) -> str:
    """條件湊齊的轉折點放一個選項，打字沒認出時不會卡住。背景的事端不放（16v 第 5 題）。"""
    if route.busy(sheet, tag(rec)):
        return ""
    known = known_of(sheet, rec)
    return next((fill(row[5], rec["cast"]) for row in t.get("轉折", []) if _ready(row, rec, known, here, who, high)), "")


def layer(rec: dict, sheet: dict) -> int:
    """人物此刻的反應（第 7 題）：沒查到東西、查到線索、手上有物證。"""
    clues = found(sheet, rec)
    return 2 if any(c["kind"] == EVIDENCE for c in clues) else 1 if clues else 0


def role_of(rec: dict, t: dict, who: str) -> list[str] | None:
    return next((row for row in t["人物"] if rec["cast"].get(row[0]) == who), None)


TOO_HIGH = {"鄉鎮": "鎮上", "城市": "州裡", "國家": "朝堂"}   # 第 116-11 題：境界不到時那句「你這點修為也敢打聽……的事」


def person_note(rec: dict, t: dict, sheet: dict, who: str, high: str = "") -> str:
    """眼前的人是事端的人時：他的行為和這一層的反應。秘密不送（第 7 題）。
    high：境界不到的範圍，只回平時那層、不說他知道的（第 116-11 題）。"""
    row = role_of(rec, t, who)
    if not row:
        return ""
    role, _, acts, tell, *layers, knows, unknown, _need = row
    level = 0 if high else layer(rec, sheet)
    told = "" if high else knows if role != KEY_ROLE or level == 2 else ""
    return fill(f"。{acts}。破綻：{tell}。此刻的表現：{layers[level]}" + (f"。問到時知道：{told}" if told else "") + (f"。他不把你當回事：你這點修為也敢打聽{TOO_HIGH.get(high, high)}的事" if high else "")
                + f"。{unknown}他不知道，問到就說不知道", rec["cast"])


def scene_note(rec: dict, t: dict, sheet: dict) -> str:
    """手上有別條路線時這裡的事不送，主線只有一條（16v 第 83 題；兩條並排時模型會混線）。手上就是這條：主線是階段那一句，這裡只補查到什麼。"""
    if route.busy(sheet, tag(rec)):
        return ""
    clues = "；".join(c["text"] for c in found(sheet, rec))
    told = f"主角已查到：{clues}" if clues else ""
    return told if route.holds(sheet, tag(rec)) else fill(t["風聲"][0][0], rec["cast"]) + (f"　{told}" if told else "")


def next_clue(rec: dict, t: dict, sheet: dict) -> list[str] | None:
    known = known_of(sheet, rec)
    return next((r for r in t["線索"] if r[0] not in known and _met(r[4], known)), None)


def hint(rec: dict, t: dict, sheet: dict, dead: set[str] = frozenset()) -> dict:
    """機會卡指的路（16v 第 16 題）：下一條查得到的線索，{做法}{線索地}。"""
    row = next_clue(rec, t, sheet)
    if not row:
        return {}
    place, how = where(row, rec, t, dead, sheet)
    return {"做法": HOW.get(how.split("、")[0], "查查"), "線索地": place}


def names_of(rec: dict, t: dict) -> set[str]:
    """事端裡的人名、地名。"""
    return {rec["cast"][row[0]] for row in t["人物"] + t["處"]} | {fill(row[1], rec["cast"]) for row in t["處"]}


def trace_state(rec: dict, t: dict, now: int, place: str = "") -> dict:
    """結局留在村鎮上的痕跡，用地點狀況表現。place：範圍裡的其他地點（第 116-2 題），空＝主地點。"""
    traces = ending(t, rec["turned_shichen"] is not None)[2]
    text = rec.get("trace") or traces[rec["killed"] if rec["killed"] < len(traces) else 0]   # 轉折點收場有自己的痕跡
    return {"place": place or rec["town"], "name": TRACE, "text": fill(text, rec["cast"])[:80],
            "source": WORLD, "game": None, "started_shichen": now, "ends_shichen": now + TRACE_LEN}
