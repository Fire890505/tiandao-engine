"""牌組（WHITEPAPER 16v 第 10～17、19～22、29 題；數字暫定）：路線裡的節拍。純函式。

- 下一步是 Python 抽的牌，模型只把牌寫好。抽牌只決定發生什麼，不改判定。內容在 rules/content/cards.txt。
- 觸發只取得資格，照順序看：大成功抽機會、大失敗抽命運 → 事件（碰到線頭） → 走向（玩家對這件事有行動就抽，第 71 題） → 小事（兩成半）。
  對手盯著的地方（暗線在走、人在那裡、查探交談潛行），失敗、大失敗改成陷阱，有陷阱時大成功改成識破（game/traps.py，第 81-7 題）。
  有行動＝人在那裡而且查探、問話、動手。連續 5 回合沒推進：還在查抽機會，放著不管隔 3 回合抽一張走向。一回合最多一張，轉折那回合不抽。
- 牌看階段、行動、成敗（條件表和抽法在 domain/deck.py，第 4-1 批）；專屬牌用完或沒有對應，就抽動作牌（rules/content/actions.txt，第 75、91 題；第 4-3 題起同一個格式和抽法）。
- 走向分兩層（第 4-8 題甲）：先照母型表（rules/content/turns.txt）挑母型，再抽種類是這個母型的走向牌；沒有就抽母型對應的動作牌組。
  走向說明在 rules/content/guides.txt。同一條路線用過的句子不重複。
- 這回合已有別的事：大成功、大失敗的牌留著，最多等 3 回合；走向和小事跳過。
- 權重：最近 10 回合做得多的行動、重大紀錄，對到的牌 ×2。
- 抽到的牌留在場景 3 回合，只放一回合時下一回合只有 1/3 還記得。
角色卡欄位：card、card_turn（0＝這條路線還沒抽過）、card_wait（第 2-1a 批起不再留牌，一律 None）、card_used（這條路線用過的句子）、route_idle（幾回合沒推進）、route_tried（其中有幾回合在查）、acts、records。
"""
from __future__ import annotations

import random
from collections import Counter
from contextvars import ContextVar
from dataclasses import replace

from ..config import PROJECT_ROOT
from . import deck
from . import judgment as J
from .era import ANCIENT
from .incident import LOSE_HP

TURN, CHANCE, FATE, SMALL, EVENT = "走向", "機會", "命運", "小事", "事件"
CLUE, GAZE, ITEM = "線索", "注視", "物品:"
DOUBT, GUIDE, TERMS, OWE = "起疑", "指路", "條件", "欠情"
SEE, LIFT = "看破", "順勢"           # 機會牌（第 81-9 題）：識破陷阱或知道對手下一步；這件事的判定加分一陣子
LASTS = ("", CLUE, LOSE_HP, DOUBT, GUIDE, OWE)   # 留在場景的牌：其他抽到就結算，留著模型會再寫一次
KILLED, BROKE, SAVED = "殺過人", "背過約", "救過人"
GAP, STALL, STAY, RECENT, OFTEN = 3, 5, 3, 10, 3   # 隔幾回合、幾回合沒推進、留幾回合、看最近幾回合、幾次算做得多
SMALL_CHANCE = 0.25
DICE = {J.GREAT_SUCCESS: CHANCE, J.GREAT_FAILURE: FATE}
TAGS = {J.COMBAT: "動手", J.SOCIAL: "社交", J.EXPLORE: "查探", J.OBSERVE: "查探", J.STEALTH: "查探"}
WON, LOST, IDLE = "成", "敗", "無"
DICE_MOVES = {CHANCE: ("機會",), FATE: ("代價", "壓力")}


CONTENT = PROJECT_ROOT / "rules" / "content"
DECK = [replace(c, result=deck.bare(c.result)) for c in deck.read(CONTENT / "cards.txt")]
GUIDES = dict(line.split("｜") for line in (CONTENT / "guides.txt").read_text(encoding="utf-8").splitlines() if not line.startswith("#"))
# 動作牌（第 4-3 題改共用格式）：一個動作幾種寫法，每種寫法算一張；種類是組
MOVE_DECK = [replace(c, text=t, result=deck.bare(c.result)) for c in deck.read(CONTENT / "actions.txt") for t in c.text.split("／")]
SIDES = {"人敵": "敵", "人非敵": "非敵", "人非友": "非友"}
TURNS = deck.read(CONTENT / "turns.txt")   # 走向母型表（第 4-8 題）：名字＝母型，內容＝退回的動作牌組
MOTIFS = tuple(dict.fromkeys(c.name for c in TURNS))
_MINE: ContextVar[dict] = ContextVar("cards_world", default={})


def use(mine: list[deck.Card], kind: str = "plot") -> None:
    """這個世界模型寫的專屬牌（newplots、tales、legends 的 use 每回合各設自己那類；待辦 1、整篇寫）。"""
    _MINE.set({**_MINE.get(), kind: [replace(c, result=deck.bare(c.result)) for c in mine]})


def fields() -> dict:
    return {"card": None, "card_turn": 0, "card_wait": None, "card_used": [], "route_idle": 0, "route_tried": 0, "acts": [], "records": []}


def note(sheet: dict, action: str, records: list[str]) -> dict:
    """記下這回合的行動和重大紀錄。"""
    return {**sheet, "acts": [*sheet["acts"], TAGS.get(action, "")][-RECENT:], "records": sorted({*sheet["records"], *records})}


def progress(sheet: dict, moved: bool, looking: bool) -> dict:
    """路線有沒有推進。looking：這回合對這件事有行動，失敗也算（第 17 題：失敗也要往前走）。"""
    if moved:
        return {**sheet, "route_idle": 0, "route_tried": 0}
    return {**sheet, "route_idle": sheet["route_idle"] + 1, "route_tried": sheet["route_tried"] + looking}


def rested(sheet: dict, turn_no: int) -> bool:
    """離上一張牌夠久，或這條路線還沒抽過。"""
    return not sheet["card_turn"] or turn_no - sheet["card_turn"] >= GAP


def kind_for(sheet: dict, outcome: str, turn_no: int, event: bool = False, acting: bool = False) -> str:
    """命運、機會、事件和走向輪到哪一種，不抽回傳空字串。轉折那回合由呼叫的人擋掉。event：這回合碰到線頭。acting：這回合對這件事有行動。"""
    if outcome in DICE:
        return DICE[outcome]
    if event:
        return EVENT
    stuck = sheet["route_idle"] >= STALL
    if not acting and not (stuck and rested(sheet, turn_no)):
        return ""
    return CHANCE if stuck and sheet["route_tried"] * 2 >= sheet["route_idle"] else TURN


def motif(rng: random.Random, *, act: str, ok: bool, end: bool = False, close: bool = False, records: tuple = (),
          dark: bool = False) -> deck.Card:
    """這回合的走向母型（rules/content/turns.txt）：條件最多的那一層裡平均挑一個，同名幾行只算一次。
    act 空＝判定:無。end：走到最後一階。close：眼前的人親近。"""
    facts = {"判定": (IDLE if not act else WON if ok else LOST,), "行動": (act,), "收尾": ("是",) * end, "親近": ("在場",) * close,
             "紀錄": records, "暗線": ("在走",) * dark}
    top = {c.name: c for c in deck.pool(TURNS, facts)}
    return top[rng.choice(list(top))]


def pool(kind: str, decks: tuple, *, near: bool, hint: bool, records: tuple = (), gone: tuple = (), stage: str = "", act: str = "",
         ok: bool = True, used: tuple = (), dark: bool = False, stuck: bool = False, era_now: str = ANCIENT) -> list[deck.Card]:
    """抽得到的牌（條件表在 domain/deck.py）。decks：路線的種類、名字、零件（game/routes.part，可以空）。hint：有下一條線索可以指。records：主角的重大紀錄。
    gone：死了的角色（受害者、第三者），牌不寫他們。stage、act、ok：這條線走到哪、這回合的行動和成敗。dark：暗線在走。
    這條路線的專屬牌（路線:名字或零件，名字跟種類一樣的不算）沒用過的先抽，用完才抽共用的；stuck（卡住抽的機會牌）不分，條件多的先，讓線索牌出得來。"""
    facts = {"路線": decks, "地": ("路線",) * near, "階": (stage,), "判定": (WON if ok else LOST,), "行動": (act,), "紀錄": records,
             "線索": ("有",) * hint, "暗線": ("在走",) * dark, "時代": (era_now,)}
    ok = [c for c in [*DECK, *(c for cs in _MINE.get().values() for c in cs)] if c.kind == kind and c.text not in used and not any(f"{{{g}}}" in c.text for g in gone)]
    own = [c for c in ok if dict(c.need).get("路線") in decks[1:] and dict(c.need).get("路線") != decks[0]]
    return (not stuck and deck.pool(own, facts)) or deck.pool(ok, facts)


def moves(groups: tuple, act: str, have: set[str], used: tuple = (), era_now: str = ANCIENT) -> list[deck.Card]:
    """抽得到的動作牌。have：這回合有的字（decks._have）：成敗、人物地、人敵人非敵人非友、紀錄、身分窘境、記號:標籤、過（查過）。
    寫法裡有 {人}{物}{地} 的，要有這個素材。"""
    facts = {"判定": have, "素材": have, "紀錄": have, "處境": have, "查": have, "行動": (act,), "時代": (era_now,),
             "立場": {SIDES[h] for h in have if h in SIDES}, "記號": {h.split(":", 1)[1] for h in have if h.startswith("記號:")},
             "地位": {h.split(":", 1)[1] for h in have if h.startswith("地位:")}}
    return [c for c in MOVE_DECK if c.kind in groups and c.text not in used and deck.fits(c, facts)   # 不比條件多寡（第 4-3b 題甲）
            and all(f"{{{k}}}" not in c.text or k in have for k in "人物地")]


def pick(rng: random.Random, cards: list, sheet: dict) -> deck.Card:
    """最近做得多的行動、重大紀錄，對到的每條 ×2。"""
    done = Counter(sheet["acts"])
    hot = {t for t, n in done.items() if t and n >= OFTEN} | set(sheet["records"])
    return deck.pick(rng, cards, hot)


def play(sheet: dict, card, text: str, turn_no: int) -> dict:
    """打出去：小事只有這回合，不影響走向的間隔；其他留在場景。機會算補救過，卡住重算。事件之後下一回合就可以抽走向。"""
    if card.kind == SMALL:
        return sheet
    unstuck = {"route_idle": 0, "route_tried": 0} if card.kind == CHANCE else {}
    return {**sheet, "card": {"kind": card.kind, "text": text, "raw": card.text, "until": turn_no + (STAY if card.result in LASTS else 0)},
            "card_turn": 0 if card.kind == EVENT else turn_no, "card_used": [*sheet["card_used"], card.text], **unstuck}


def held(sheet: dict, turn_no: int) -> str:
    """還留在場景的牌（抽到的那回合在【主事】）。"""
    c = sheet["card"]
    return c["text"] if c and sheet["card_turn"] < turn_no <= c["until"] else ""


def valid(sheet: dict) -> bool:
    c = sheet["card"]
    w = sheet["card_wait"]
    fine = c is None or isinstance(c, dict) and isinstance(c.get("text"), str) and isinstance(c.get("until"), int)
    fine = fine and (w is None or isinstance(w, dict) and w.get("kind") in DICE.values() and isinstance(w.get("until"), int))
    return (fine and all(isinstance(sheet[k], int) for k in ("card_turn", "route_idle", "route_tried"))
            and all(isinstance(sheet[k], list) and all(isinstance(v, str) for v in sheet[k]) for k in ("acts", "records", "card_used")))
