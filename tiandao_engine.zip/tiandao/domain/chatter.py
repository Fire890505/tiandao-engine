"""NPC 之間的小事（第 7-2a 批，WHITEPAPER 121-5、7-2-1～7-2-5 題；數字暫定）。純函式，不碰資料庫。

- 村鎮、坊市、宗門各算一處（PLACES，子地點算在上層，space.town_of）；每處每月 0～2 件（權重 4:4:2）。
  你沒到的地方不算：你到了或打聽那裡的人時一次補完，最多 MAX_SEGMENTS 段、每段最多 2 件；第一次到補前一年。
- 從這處的人裡隨機挑兩個（甲做事、乙是對象），用甲對乙的好感層、合不合（match）、性格和目標篩牌
  （rules/content/chatter.txt），條件最多的那一層才抽（deck.pool）。敵視沒有牌，交給世界脈動的交手。
- 結果：好感、信任、怕的原因；法（被害人或在場的人告官才辦，照那國的輕重，第 7-2-4 題）；
  規（宗門照宗規記過，一筆留一年，滿 OUT_AT 筆除名）；約（戀人、伴侶）；聞（傳開；沒寫就看在場的人口風低不低）。
- 補完再看這一處有沒有聚成一群（第 7-5a 批，domain/gather.py）：結義或新勢力，一年一次；沒有朋友那群就看同行那群。
- 只有一方記好感的好事（甲或乙那方），另一方記一筆小的有來有往（第 7-5a 補，使用者「丙二+甲」）。
- 近況：約、法、規每件記；小事每人只記這段最新的一件（Claude主導盤點第八節，NPC 帶著畫面外的事出場）。
"""
from __future__ import annotations

import random
from dataclasses import dataclass, field

from ..config import PROJECT_ROOT
from ..util import new_id
from . import crime, deck, gather, memory, npc, opinion, rumors, society, space
from .clock import SHICHEN_PER_YEAR
from .evolution import months

PLACES = {"城鎮": "村鎮", "村落": "村鎮", "坊市": "坊市", "宗門": "宗門"}
COUNTS, WEIGHTS = (0, 1, 2), (4, 4, 2)
MAX_SEGMENTS = 12
FIRST = SHICHEN_PER_YEAR            # 第一次到：補前一年
HALF = SHICHEN_PER_YEAR // 2        # 戀人半年以上才可能成親
JAIL = SHICHEN_PER_YEAR             # 傷人關一年
ARREST, SLACK = 0.8, 0.5            # 告了官抓到的機會；附近沒有衙署或亂世再乘
OUT_AT = 3                          # 記過幾筆除名
MATCH_AT = 2                        # 合得來 ≥2、合不來 ≤−2
PAIRED = ("ambition", "kindness", "courage", "suspicion", "tolerance")   # 口風不算合不合
RIVAL, GUARD = ("逐利", "求名"), "守護"
LOVE, ROLES = ("戀人", "伴侶"), ("甲", "乙")
LABELS = {**npc.TRAIT_LABELS, **npc.TEMPER_LABELS}
SECT_OF = {crime.THEFT: crime.CHEAT_KIN, crime.HURT: crime.HURT_KIN}   # 在宗門裡犯的照宗規
RESULTS = {"法": tuple(SECT_OF), "規": tuple(SECT_OF.values()), "約": LOVE, "聞": ("傳開",)}
SIZE = {opinion.SMALL: 1, opinion.BIG: 2, opinion.GRAVE: 3}
HEAVY = 3                           # 約、法、規的份量（挑「聽說」那一件、要不要記近況）


def _ok(token: str) -> bool:
    parts = token.split(":")[1:] if token.split(":")[0] in ROLES else token.split(":")
    if parts[0] in opinion.AXES:
        return len(parts) == 3 and opinion.MOODS.get(parts[1], ("",))[0] == parts[0] and parts[2] in opinion.LEVELS
    return len(parts) == 2 and parts[1] in RESULTS.get(parts[0], ())


DECK = deck.read(PROJECT_ROOT / "rules" / "content" / "chatter.txt")
assert all(c.who == "一對" and _ok(t) for c in DECK for t in c.result.split()), "小事牌的結果寫錯了"


@dataclass
class Out:
    reasons: list[dict] = field(default_factory=list)
    bonds: list[dict] = field(default_factory=list)          # 新的戀人、伴侶
    unbonds: list[tuple] = field(default_factory=list)       # （甲, 乙, 種類）：成親拿掉戀人、除名拿掉成員
    ledger: list[dict] = field(default_factory=list)         # 關押、記過
    settled: list[str] = field(default_factory=list)         # 關滿放出來的
    fields: dict[str, dict] = field(default_factory=dict)    # 進牢、出牢、除名離開
    notes: list[dict] = field(default_factory=list)
    rumors: list[dict] = field(default_factory=list)
    told: list[tuple] = field(default_factory=list)          # （份量, 時刻, 句子, {甲, 乙}）
    factions: list[dict] = field(default_factory=list)       # 聚出來的新勢力（第 7-5a 批）


def match(p: dict, q: dict) -> str:
    """合不合（第 7-2-2 題）：五項性格同高同低 +1、一高一低 −1、中不算；同在一處都逐利或都求名 −1；守護同一人 +1。"""
    lv = [(npc.trait_level(p[t]), npc.trait_level(q[t])) for t in PAIRED]
    s = sum(1 if a == b else -1 for a, b in lv if "中" not in (a, b))
    s += (p["goal"] == q["goal"] == GUARD and p["goal_target"] == q["goal_target"] != "") - (p["goal"] == q["goal"] in RIVAL)
    return "合得來" if s >= MATCH_AT else "合不來" if s <= -MATCH_AT else "普通"


def facts(p: dict, q: dict, kind: str, bonds: list[dict], like, talks: list[dict], places: dict, now: int) -> dict:
    """甲（p）對乙（q）抽牌的條件。like：society.liking；talks：兩人之間的原因；places：名字 → 所在地。"""
    x, y = p["name"], q["name"]
    ours = {b["type"]: b for b in bonds if {b["a"], b["b"]} == {x, y}}
    taken = {n for b in bonds if b["type"] in LOVE for n in (b["a"], b["b"])}
    single = not {x, y} & taken and "親人" not in ours and not (npc.is_minor(p, now) or npc.is_minor(q, now))
    lover = ours.get("戀人")
    same = p["goal"] == q["goal"] and (p["goal"] != GUARD or p["goal_target"] == q["goal_target"])
    return {"層": (npc.tier(like(x, y), npc.AFFINITY_TIERS),), "合": (match(p, q),), "處": (kind,),
            "熟": ("熟人",) * (society.familiar(x, y, bonds, talks, places) in (society.KNOWN, society.KIN)),
            "甲": (*(f"{v}{npc.trait_level(p[k])}" for k, v in LABELS.items()), p["goal"]), "同": (p["goal"],) * same,
            "親": tuple(t for t in ("親人", "伴侶") if t in ours), "約": ("戀人",) * bool(lover),
            "戀": ("單身",) * single + ("半年",) * bool(lover and now - lover["clock_shichen"] >= HALF),
            "性": ("異性",) * ({p.get("gender"), q.get("gender")} == {"男", "女"})}


def slack(traits: list[crime.Trait], locations: list[dict], town: str) -> bool:
    """抓到的機會減半：那國是亂世，或這處沒有衙署。"""
    return any(t.name == "亂世" for t in traits) or not any(
        l["type"] == crime.COURT and space.town_of(locations, l["name"]) == town for l in locations)


def jail_of(locations: list[dict], town: str) -> str:
    """這處的牢房（事端開過就用那一處）。"""
    return next((l["name"] for l in locations if l["parent"] == town and l["name"].endswith("牢房")), f"{town}牢房")


def reports(w: dict) -> bool:
    """會不會告官：膽小或善念高的告，膽大的寧可自己報仇。"""
    c = npc.trait_level(w["courage"])
    return c != "高" and (c == "低" or npc.trait_level(w["kindness"]) == "高")


def settle(rng: random.Random, *, place: dict, locations: list[dict], npcs: list[dict], bonds: list[dict],
           reasons: list[dict], ledger: list[dict], factions: list[dict], laws: dict[str, int], loose: bool,
           start: int, end: int, turn_no: int) -> Out:
    """這一處從 start 補到 end。laws：那國每條罪的輕重（crime.code）；loose：抓到的機會減半（slack）。"""
    out, town, kind = Out(), place["name"], PLACES[place["type"]]
    bonds, reasons, ledger = list(bonds), list(reasons), list(ledger)
    here = [p for p in npcs if p["status"] == "ALIVE" and p["location"] != society.AWAY
            and space.town_of(locations, p["location"]) == town]
    hall = next((f for f in factions if f["type"] == "宗門" and f["location"] == town), None)
    cell = jail_of(locations, town)
    n = min(MAX_SEGMENTS, months(end) - months(start))

    def note(who: str, text: str, when: int) -> None:
        out.notes.append(memory.note(memory.NPC, who, memory.NEWS, text, clock_now=when, turn_no=turn_no))

    def owe(kind_: str, who: str, to: str, when: int, until: int) -> None:
        row = {**society.owed(kind_, who, to, when), "id": new_id("led"), "deadline_shichen": until}
        ledger.append(row)
        out.ledger.append(row)

    def feel(holder: str, toward: str, h: opinion.Hit, when: int) -> None:
        r = opinion.reason(holder, toward, h, when)
        reasons.append(r)
        out.reasons.append(r)

    def law(crime_: str, p: dict, q: dict, w: dict | None, when: int) -> bool:
        """犯了國法或宗規。回傳要不要傳開。"""
        x = p["name"]
        if kind == "宗門":
            member = hall and any(b["type"] in society.MEMBER_BONDS and b["a"] == x and b["b"] == hall["name"] for b in bonds)
            for _ in range(crime.code(crime.traits_of(hall), crime.SECT_RULES, OUT_AT)[SECT_OF.get(crime_, crime_)] if member else 0):
                owe(society.MARKED, x, hall["name"], when, when + SHICHEN_PER_YEAR)
            marks = sum(r["kind"] == society.MARKED and r["a"] == x and r["b"] == hall["name"] and r["status"] == society.OPEN
                        and r["deadline_shichen"] > when for r in ledger) if member else 0
            if marks >= OUT_AT:
                bonds[:] = [b for b in bonds if not (b["a"] == x and b["b"] == hall["name"] and b["type"] in society.MEMBER_BONDS)]
                out.unbonds.append((x, hall["name"], society.MEMBER_BONDS))
                out.fields[x] = {"location": society.AWAY, "away_since": when, "away_from": town}
                note(x, f"被{hall['name']}除名，離開了", when)
            return marks >= OUT_AT
        lv = laws.get(crime_, crime.BASE[crime_])
        if not lv or not any(reports(v) for v in (q, w) if v):
            return False
        if lv > crime.FINE_LEVEL and crime_ == crime.HURT and rng.random() < ARREST * (SLACK if loose else 1):
            owe(society.JAILED, x, town, when, when + JAIL)
            out.fields[x] = {"location": cell}
            note(x, f"因傷人被抓進{cell}", when)
        return True   # 罰金級：NPC 不記錢，只傳一句

    def play(p: dict, q: dict, w: dict | None, card: deck.Card, when: int) -> None:
        x, y = p["name"], q["name"]
        text = card.text.replace("{甲}", x).replace("{乙}", y)
        weight, spread = 0, bool(w and npc.trait_level(w["discretion"]) == "低")
        for token in card.result.split():
            parts = token.split(":")
            role = parts.pop(0) if parts[0] in ROLES else ""
            head, value = parts[0], parts[1:]
            if head in opinion.AXES:
                h, pairs = opinion.mood(*value), [(y, x)] if role == "乙" else [(x, y)] if role == "甲" else [(x, y), (y, x)]
                for a, b in pairs:
                    feel(a, b, h, when)
                if role and h[1] == opinion.LIKE and h[3] > 0:   # 好事兩邊都記：另一方記一筆小的有來有往（第 7-5a 補）
                    feel(pairs[0][1], pairs[0][0], opinion.mood(opinion.EVEN, opinion.SMALL), when)
                weight = max(weight, SIZE[value[1]])
                continue
            if head == "聞":
                spread = True
                continue
            weight = HEAVY
            if head == "約":
                if value[0] == "伴侶":
                    bonds[:] = [b for b in bonds if not (b["type"] == "戀人" and {b["a"], b["b"]} == {x, y})]
                    out.unbonds += [(x, y, ("戀人",)), (y, x, ("戀人",))]
                bond = {"a_kind": society.NPC, "a": x, "b_kind": society.NPC, "b": y, "type": value[0],
                        "clock_shichen": when, "turn_no": turn_no}
                bonds.append(bond)
                out.bonds.append(bond)
            else:
                spread |= law(value[0], p, q, w, when)
        if spread:
            out.rumors.append(rumors.make(rumors.CHAT, town, place=town, when=when, detail=text[:40]))
        if weight >= HEAVY:
            note(x, text, when)
            note(y, text, when)
        out.told.append((weight, when, text, {x, y}))

    def jailed() -> list[dict]:
        return [r for r in ledger if r["kind"] == society.JAILED and r["status"] == society.OPEN and r["id"] not in out.settled]

    for i in range(max(0, n)):
        when = start + (end - start) * (i + 1) // n
        for r in [r for r in jailed() if r["b"] == town and r["deadline_shichen"] <= when]:
            out.settled.append(r["id"])
            out.fields[r["a"]] = {"location": town}
            note(r["a"], f"關滿出了{cell}", when)
        for _ in range(rng.choices(COUNTS, WEIGHTS)[0]):
            held = {r["a"] for r in jailed()}
            people = [p for p in here if p["name"] not in held and out.fields.get(p["name"], {}).get("location") != society.AWAY]
            places = {p["name"]: out.fields.get(p["name"], {}).get("location", p["location"]) for p in people}
            if len(people) < 2:
                break
            p, q = rng.sample(people, 2)
            others = [o for o in people if o["name"] not in (p["name"], q["name"])]
            like = society.liking(npcs, bonds, reasons, when, factions)
            talks = [r for r in reasons if {r["holder"], r["toward"]} == {p["name"], q["name"]} and not r["session_id"]]
            cards = deck.pool(DECK, facts(p, q, kind, bonds, like, talks, places, when))
            if cards:
                play(p, q, rng.choice(others) if others else None, rng.choice(cards), when)
    light = {x: (when, text) for w, when, text, ws in out.told if w < HEAVY for x in sorted(ws)}   # 小事每人記最新一件近況（第八節）
    for x, (when, text) in light.items():
        note(x, text, when)
    if n > 0 and not gather.done(ledger, town, end):   # 聚（第 7-5a 批）：補完再看一次
        held = {r["a"] for r in jailed()}
        by = {p["name"]: p for p in here if p["name"] not in held and out.fields.get(p["name"], {}).get("location") != society.AWAY}
        group = (gather.biggest(gather.links(sorted(by), npcs, bonds, reasons, factions, end))
                 or gather.biggest(gather.peers([by[n] for n in sorted(by)], npcs, bonds, reasons, factions, end)))
        if group and not gather.joined(group, bonds):
            what, name, head = gather.form(rng, [by[n] for n in group], town, {f["name"] for f in factions} | {p["name"] for p in npcs} | {l["name"] for l in locations})
            out.ledger.append({**gather.row(town, group, what, end), "id": new_id("led")})
            out.bonds += gather.ties(group, what, name, head, bonds, end, turn_no)
            out.factions += [{"name": name, "type": what, "location": town, "traits": {}, "discovered_turn": turn_no}] * bool(name)
            text = gather.line(group, what, name, head, town)
            for x in group * bool(text):
                note(x, text[:memory.MEMORY_TEXT_LEN[1]], end)
            out.rumors += [rumors.make(rumors.CHAT, town, place=town, when=end, detail=text[:40])] if text else []
            out.told += [(HEAVY, end, text, set(group))] if text else []
    return out
