"""起始區域（第 16b 步）：新的原初世界建立時，依世界種子生成一個區域的骨幹。純函式，不碰資料庫。

規則見 progress/WHITEPAPER.md 第 3 節「16b」與 progress/WORLD_SKELETON.md 第 B 節（數字暫定）：
- 一座城鎮（鎮上有坊市、本山的武館）、2～3 個村落、2～3 處荒野、宗門本山（國家規模）。
- 家級建築（2026-10-07）：鎮上一間客棧、武館是家級；每個村落一座祠堂＋一戶大宅；一個荒野一座廢墟（破廟或義莊）。
  經濟第二輪：鎮上多一間當鋪（換錢）；身分與追捕：鎮上多一間衙署（繳罰金）。
- 本山的遠近由種子決定：三分之一在區域裡（穿過荒野半日可到），三分之二在區域外（從城鎮遠行）。
  區域外的本山路上有一個驛站（村落，底下一間客棧）：城鎮→驛站遠行、驛站→本山半日（地圖第二輪）。
- 勢力只生成本身（不生成成員、不定敵友）：本山、武館、城鎮裡一個凡人勢力、本山上屬的仙宗（玩家看不到）。
  仙宗 ← 本山 ← 武館，都用「從屬」。16h：這一區屬於一個國家（勢力類型「國家」，擲國法特徵）；本山擲門風，道統＝路子；
  本山、武館生成成員（"people"，domain/sect.py），本山底下看道統有丹房、煉器閣。
- 只定名字、類型、規模、相對位置；描述與人物留給遊戲當下。
"""
from __future__ import annotations

import random

from . import crime, names, society, space
from . import sect as sect_mod

NEAR_SECT_CHANCE = 1 / 3
VILLAGES, WILDS = (2, 3), (2, 3)
MORTAL_FACTIONS = ("家族", "幫派", "商會", "朝廷")
BIRTH_TYPES = ("城鎮", "村落", "荒野")   # 建角可選的出生地類型；宗門進不去（第 16b 第 6 題）
ERA = "古代"   # 區域一律用古代生成；現代、未來的叫法與改名在 domain/era.py（第 16e 節）
BUILDINGS = {"古代": {"inn": "客棧", "shrine": "祠堂", "house": "住家", "ruin": "廢墟"}}
SECT_LORE = {   # 依主角境界給說書人的那一行（宗門第 2 題）：拿不到就說不出來。{sect}、{immortal} 由世界資料填入
    2: "宗門背後另有上宗，宗門的興衰、規矩往往由上宗決定；上宗是誰，主角還不知道。",
    4: "「{sect}」是「{immortal}」在此界的分支；同屬一個仙宗的宗門彼此是宗會，互相照應也互相較勁。",
    6: "仙宗在仙域，互相合作的仙宗結為仙盟；破空之時，各仙宗以接引法陣爭奪人才，大戰場上以戰功論高下。",
}


def generate(rng: random.Random, *, town: str = "", race: str = "人族", avoid=frozenset()) -> dict:
    """回傳 {"locations", "connections", "factions", "bonds", "people"}，欄位與 repos 寫入時相同
    （描述由 service 補上；people 的境界、出生由 service 換算）。
    town、race：其他州（16k）用州的主城當城鎮，地名、機構叫法、人名都用那一族的（16u）。
    avoid：世界上已有的名字，撞名就抽別的字首；字首用完才撞名，由 service 處理。"""
    taken: set[str] = set()
    words = names.PEOPLES[race]

    def name(value: str) -> str:
        taken.add(value)
        return value

    def pick(prefixes, suffixes) -> str:
        return name(names.pick_unused(rng, prefixes, suffixes, taken, avoid) or names.pick_unused(rng, prefixes, suffixes, taken))

    path = rng.choice(tuple(names.SECT_PATHS))
    sect_suffixes, branch_suffixes = names.SECT_PATHS[path]
    town = name(town) if town else pick(names.TOWN_PREFIXES, names.TOWN_SUFFIXES)
    sect = pick(names.SECT_PREFIXES, sect_suffixes + names.SECT_COMMON)
    branch = name(sect[:2] + rng.choice(branch_suffixes))   # 宗門字首＋分支字尾（問劍武館）
    market = name(town + words["坊市"][0])
    other = names.RACE_PLACES.get(race)
    villages = [pick(*other) if other else name(names.village_name(rng, taken | set(avoid)) or names.village_name(rng, taken))
                for _ in range(rng.randint(*VILLAGES))]
    wilds = [pick(other[0] if other else names.WILD_PREFIXES, names.WILD_SUFFIXES) for _ in range(rng.randint(*WILDS))]
    immortal = pick(names.IMMORTAL_PREFIXES, names.IMMORTAL_SUFFIXES)
    mortal_kind = rng.choice(MORTAL_FACTIONS)
    mortal = name(names.mortal_faction_name(rng, mortal_kind, town, taken, race))

    def place(n: str, type_: str, scale: str, parent: str = "", danger: str = "") -> dict:
        return {"name": n, "type": type_, "scale": scale, "parent": parent, "danger": danger, "discovered_turn": 0}

    dangers = ["低", "中"] + [rng.choice(("低", "中")) for _ in wilds[2:]]
    locations = ([place(town, "城鎮", "鄉鎮"), place(market, "坊市", "鄉鎮", town), place(branch, "武館", "家", town)]
                 + [place(v, "村落", "村落") for v in villages]
                 + [place(w, "荒野", "村落", danger=d) for w, d in zip(wilds, dangers)]
                 + [place(sect, "宗門", "國家")])

    def road(a: str, b: str, tier: str) -> dict:
        return {"a": a, "b": b, "tier": tier, "distance_km": space.DISTANCE_TIERS[tier],
                "direction": rng.choice(space.DIRECTIONS), "discovered_turn": 0}

    near_places = [town] + villages
    connections = ([road(town, market, space.NEAR), road(town, branch, space.NEAR)]
                   + [road(town, v, rng.choice((space.NEAR, space.HALF_DAY))) for v in villages]
                   + [road(rng.choice(near_places), w, space.NEAR) for w in wilds])
    near_sect = rng.random() < NEAR_SECT_CHANCE
    if near_sect:   # 近：宗門腳下
        connections.append(road(wilds[-1], sect, space.HALF_DAY))

    factions = [{"name": sect, "type": "宗門", "location": sect, "discovered_turn": 0},
                {"name": branch, "type": "武館", "location": branch, "discovered_turn": 0},
                {"name": mortal, "type": mortal_kind, "location": town, "discovered_turn": 0},
                {"name": immortal, "type": society.IMMORTAL_SECT, "location": "", "discovered_turn": 0}]
    bonds = [_subordinate(sect, immortal), _subordinate(branch, sect)]

    def unique(base: str, near: str) -> str:   # 同名就冠上所在地的前兩個字（槐樹王氏祠堂）
        return name(base if base not in taken else near[:2] + base)

    # 家級建築（2026-10-07，WHITEPAPER 第 16d 節「家級的地方從哪裡來」）：城鎮一間客棧、每個村落一座祠堂＋一戶大宅、
    # 一個荒野一座廢墟；都和所在地有路相連
    b = BUILDINGS[ERA]
    homes = [place(pick(words["客棧字首"], words["客棧"]), b["inn"], "家", town)]
    for v in villages:
        line = names.main_line(v, race)   # 祠堂、大宅是當地大姓的（16u 第 6 題）；魔族沒有姓：用村名
        surname = names.local_clan(v, "村落", race, line) or names.family(rng, race, line) or v[:2]
        homes += [place(unique(surname + words["祠堂"][0], v), b["shrine"], "家", v),
                  place(unique(surname + words["大宅"][0], v), b["house"], "家", v)]
    wild = rng.choice(wilds)
    homes.append(place(unique(wild[:2] + rng.choice(words["廢墟"]), wild), b["ruin"], "家", wild, danger="低"))
    # 經濟第二輪：鎮上一間當鋪（換錢的地方）
    homes.append(place(pick(words["當鋪字首"], words["當鋪"]), "當鋪", "家", town))
    homes.append(place(name(town + words["衙署"][0]), "衙署", "家", town))   # 身分與追捕：繳罰金的地方
    connections += [road(h["parent"], h["name"], space.NEAR) for h in homes]
    if not near_sect:   # 遠：偏遠的分支，路上經過一個驛站（地圖第二輪）：城鎮遠行到驛站，驛站半日到本山
        station = pick(other[0] if other else names.TOWN_PREFIXES, ("驛",))
        inn = pick(words["客棧字首"], words["客棧"])
        homes += [place(station, "村落", "村落"), place(inn, b["inn"], "家", station)]
        connections += [road(town, station, "遠行"), road(station, sect, space.HALF_DAY), road(station, inn, space.NEAR)]
    # 16h：本山的道統（＝路子）與門風；這一區屬於一個國家，擲國法的三項特徵（換時代時重擲）
    factions[0]["traits"] = crime.roll_sect(rng, path)
    factions.append({"name": name(names.pick_unused(rng, names.NATION_PREFIXES, ("國",), taken)), "type": society.NATION,
                     "location": "", "discovered_turn": 0, "traits": crime.roll_nation(rng, ERA)})
    # 宗門第二批：本山底下的丹房、煉器閣（看道統）；宗門、武館的成員（境界由 service 寫入時換算）
    rooms = [place(name(sect[:2] + room), room, "家", sect) for room in sect_mod.rooms(rng, path)]
    connections += [road(sect, r["name"], space.NEAR) for r in rooms]
    people, member_bonds = sect_mod.cast(rng, [(sect, "宗門"), (branch, "武館")], taken, race)
    return {"locations": locations + homes + rooms, "connections": connections, "factions": factions,
            "bonds": bonds + member_bonds, "people": people}


def _subordinate(lower: str, upper: str) -> dict:
    """「lower 從屬於 upper」（society.describe：從 lower 看是「upper的從屬」）。"""
    return {"a_kind": society.FACTION, "a": lower, "b_kind": society.FACTION, "b": upper, "type": "從屬",
            "clock_shichen": 0, "turn_no": 0}


def birthplaces(locations: list[dict], atlas: dict | None = None) -> list[str]:
    """建角可選的出生地：系統生成的城鎮、村落、荒野（還沒生成的州的主城不算，16k）。
    舊世界沒有生成區域，回傳空清單（service 照舊用起始山道）。"""
    closed = {s["capital"] for s in (atlas or {}).get("states", []) if not s["built"]}
    return [l["name"] for l in locations if l["discovered_session_id"] == "" and l["type"] in BIRTH_TYPES
            and l["name"] not in closed and l["scale"] != space.SCALES[0]]   # 村鎮裡的小地點（事端的後巷、公倉）不算


def hidden_names(factions: list[dict]) -> set[str]:
    """玩家與說書人都不該看到的勢力名字（仙宗）。"""
    return {f["name"] for f in factions if f["type"] == society.IMMORTAL_SECT}


def sect_lore(factions: list[dict], bonds: list[dict], realm_lv: int) -> str:
    """依主角境界給說書人的宗門層級那一行。Lv0～1 不給；世界沒有生成本山（舊世界）也不給。"""
    tier = max((lv for lv in SECT_LORE if lv <= realm_lv), default=None)
    hidden = hidden_names(factions)
    pair = next(((b["a"], b["b"]) for b in bonds if b["type"] == "從屬" and b["b"] in hidden), None)
    if tier is None or pair is None:
        return ""
    return SECT_LORE[tier].format(sect=pair[0], immortal=pair[1])
