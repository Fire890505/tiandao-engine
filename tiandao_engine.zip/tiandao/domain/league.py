"""盟（16l 第 32、33 題；草稿 C5b3）：主角當宗主時投盟、結新盟、退盟、叛盟；當盟主時宣戰、停戰。純函式。

規則（2026-10-18 與使用者一題一題定案，見 progress/WHITEPAPER.md 16l，數字暫定）：
- 投盟：在某盟仙宗的山門說「投入某盟」，仙宗實力 JOIN_POWER 以上或你在這一帶威名遠近皆知就收；原本有盟＝叛盟，
  原盟跟新盟直接交戰。退盟：在自家山門說「退盟」。退盟、叛盟後一個百日內不能投盟、結盟（仙宗 left）。
- 結新盟：在地盤相鄰、沒有盟的仙宗山門說「結盟」（自己也要沒有盟），對方首領好感 OK 以上或你的實力不輸它就成；
  你當盟主（盟 head），說「盟名某某」取名，沒說照字首挑。
- 盟主：在自家山門說「向某盟宣戰」（地盤相鄰才行，盟內每宗實力 −COST，記進盟 wars）、「與某盟停戰」
  （對方盟主首領好感 OK 以上或本盟實力比對方強才答應，改成冷戰）。每個百日最多改一次盟與盟的關係（盟 changed）。
- 盟內人心：近 immortal.WAR_MEMORY 個百日宣戰越多，盟裡 NPC 仙宗叛盟機率越高，最多加倍（immortal._pull）。
- 回傳的是補丁 {alliances: {盟名: 整個盟}, stances: {有變的}, sects: {名字: 要改的欄位}}，交易裡套在最新的骨架上。
"""
from __future__ import annotations

import re

from . import ascent, atlas, immortal, names, opinion, pacts, reputation

JOIN_POWER = 30
COST = 2
OK = 20
NAME_WORDS = re.compile(r"盟名[「『]?([一-鿿]{1,4})")


def head_of(realm: dict, alliance: str) -> str:
    """盟主的仙宗（主角結的盟才有；那個宗不在盟裡了就沒有）。"""
    a = next((x for x in realm["alliances"] if x["name"] == alliance), {})
    return a.get("head", "") if any(s["name"] == a.get("head") and s["alliance"] == alliance for s in realm["sects"]) else ""


def act(rng, realm: dict, s: dict, *, words: str, here: str, now: int, levels: dict, regard: dict[str, int]):
    """宗主這回合對盟的動作。s：自己的仙宗（最新的）；levels：此地名聲；regard：仙宗 → 它的首領對你的好感。
    回傳（補丁或 None, 事實）。"""
    p, mine, ally = now // immortal.PERIOD, s["name"], s["alliance"]
    others = [a["name"] for a in realm["alliances"] if a["name"] != ally]
    target = next((a for a in sorted(others, key=len, reverse=True) if a in words), "")
    there = here[:-len(ascent.GATE)] if here.endswith(ascent.GATE) else ""
    home = there == mine
    stances, by = immortal.stances(realm), {x["name"]: x for x in realm["sects"]}
    cool = s.get("left", -1) >= p
    if home and "退盟" in words and ally:
        return _patch({}, {mine: {"alliance": "", "left": p}}), [f"率{mine}退出{ally}"]
    if home and target and ("宣戰" in words or "停戰" in words or "議和" in words):
        key, a = atlas._key(ally, target), next(x for x in realm["alliances"] if x["name"] == ally) if ally else {}
        if head_of(realm, ally) != mine:
            return None, ["只有盟主能決定宣戰、停戰"]
        if a.get("changed", -1) >= p:
            return None, ["這個百日已經改過盟與盟的關係"]
        if "宣戰" in words:
            if key not in immortal._bordering(realm) or stances.get(key) == atlas.WAR:
                return None, [f"{target}跟{ally}地盤不相鄰，或已在交戰"]
            paid = {x["name"]: {"power": max(0, x["power"] - COST)} for x in realm["sects"] if x["alliance"] == ally}
            return (_patch({key: atlas.WAR}, paid, {ally: {**a, "changed": p, "wars": a.get("wars", []) + [p]}},
                           _felt(ally, target, immortal.DECLARED, -1, now) + _felt(target, ally, immortal.DECLARED, -1, now), now),
                    [f"{ally}向{target}宣戰，盟內各宗實力 −{COST}"])
        if stances.get(key) != atlas.WAR:
            return None, [f"{ally}跟{target}並沒有在交戰"]
        theirs = head_of(realm, target) or max((x["name"] for x in realm["sects"] if x["alliance"] == target),
                                               key=lambda n: by[n]["power"], default="")
        strong = _power(realm, ally) > _power(realm, target)
        if regard.get(theirs, 0) < OK and not strong:
            return None, [f"{target}不肯停戰"]
        return (_patch({key: atlas.COLD}, {}, {ally: {**a, "changed": p}},
                       _felt(ally, target, pacts.PEACE, 1, now) + _felt(target, ally, pacts.PEACE, 1, now), now),
                [f"{ally}與{target}停戰"])
    if there and not home and target and "投" in words and by.get(there, {}).get("alliance") == target:
        if cool:
            return None, ["退盟、叛盟不久，這個百日還不能投盟"]
        if s["power"] < JOIN_POWER and levels.get(reputation.MIGHT) != reputation.FAMOUS:
            return None, [f"{target}看不上{mine}（實力不到 {JOIN_POWER}，你的威名也還不夠）"]
        war = {atlas._key(ally, target): atlas.WAR} if ally else {}   # 叛盟：原盟記仇（大壞），直接交戰
        return (_patch(war, {mine: {"alliance": target, **({"left": p} if ally else {})}}, {},
                       _felt(ally, target, immortal.DEFECTED, -1, now) if ally else [], now),
                [f"率{mine}" + (f"叛出{ally}，" if ally else "") + f"投入{target}"]
                + ([f"{ally}視{mine}為叛徒，與{target}開戰"] if ally else []))
    if there and not home and "結盟" in words:
        t = by.get(there, {})
        if ally or t.get("alliance") or tuple(sorted((mine, there))) not in immortal.neighbors(realm):
            return None, ["結新盟要雙方都沒有盟、地盤相鄰"]
        if cool:
            return None, ["退盟、叛盟不久，這個百日還不能結盟"]
        if regard.get(there, 0) < OK and s["power"] < t["power"]:
            return None, [f"{there}不肯跟{mine}結盟"]
        name = _name(rng, realm, words)
        if not name:
            return None, ["想不出沒人用過的盟名"]
        new = {"name": name, "creed": rng.choice(immortal.CREEDS), "head": mine}
        return (_patch({}, {mine: {"alliance": name}, there: {"alliance": name}}, {name: new}),
                [f"{mine}與{there}結為{name}，你是盟主"])
    return None, []


def _name(rng, realm: dict, words: str) -> str:
    taken = {a["name"] for a in realm["alliances"]}
    m = NAME_WORDS.search(words)
    if m and m.group(1).removesuffix("盟") + "盟" not in taken:
        return m.group(1).removesuffix("盟") + "盟"
    return names.pick_unused(rng, immortal.ALLIANCE_PREFIXES, ("盟",), taken)


def _power(realm: dict, alliance: str) -> int:
    return sum(x["power"] for x in realm["sects"] if x["alliance"] == alliance)


def _felt(x: str, y: str, kind: str, sign: int, now: int) -> list[dict]:
    """x 對 y 記一筆大的原因（7-3b3：盟主的決定也記原因，下個百日才不會被立約翻回去）。"""
    return [opinion.reason(x, y, opinion.hit(kind, opinion.LIKE, opinion.BIG, sign), now)]


def _patch(stances: dict, sects: dict, alliances: dict | None = None, felt: list = (), now: int = 0) -> dict:
    return {"stances": stances, "sects": sects, "alliances": alliances or {}, "reasons": list(felt),
            "since": {k: now for k in stances}}


def apply(realm: dict, patch: dict) -> dict:
    """把補丁套在最新的骨架上：盟（新的加進去、舊的換掉）、盟與盟的關係（和換的時刻）、原因、仙宗的欄位。"""
    old = {a["name"] for a in realm["alliances"]}
    alliances = [patch["alliances"].get(a["name"], a) for a in realm["alliances"]] \
        + [a for n, a in patch["alliances"].items() if n not in old]
    return {**realm, "alliances": alliances, "stances": {**realm.get("stances", {}), **patch["stances"]},
            "since": {**realm.get("since", {}), **patch["since"]}, "reasons": realm.get("reasons", []) + patch["reasons"],
            "sects": [{**x, **patch["sects"].get(x["name"], {})} for x in realm["sects"]]}
