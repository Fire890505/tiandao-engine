"""說書排程（WHITEPAPER 第 117、117-1、117-2 題，實作第 2-1a、2-1b 批）：各系統交候選，一回合挑一件當主事。

- 候選不改狀態；被挑中的才落實（run），沒中的留著下回合再比，只限這回合的（牌、事件、新面孔、追兵、天道落子）沒中就丟。
- 危險（找上門的仇家、好心訪客、亡者領域傳說儀式的當場情境、轉折、陷阱落下）照舊先算，已經拿走主事，這回合不挑。
- 回應的回合（上回合留了要你回的事）不插新主事（第 117-1 題，第 2-1b 批第 3 題）。
- 挑法：期限到了 → 急的（大成功大失敗的牌、追兵、天道落子、途中遭遇）→ 期限越近 → 等越久 → 事件、新面孔 → 平常的牌、在場的人的做法。
  等多久暫時用回合，第 2-2 批改世界時間。
- 旁支事實最多三行（痕跡 → 傳聞），擠掉的只留在回合紀錄（第 119-4 題，第 2-1b 批第 4 題）。
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

from . import stage
from .pending import NOW

ECHO, ASK, DEBT, ROUTE, CARD = "回音", "請託", "債", "路線", "牌"   # 暗線不再當候選（第 5-1-1 題）
EVENT, FACE, HUNT, HEAVEN = "事件", "新面孔", "追兵", "天道"
DEED = "做法"   # 在場的人對你的做法（第 7-2b 批，WHITEPAPER ㉖）：跟牌同一級
LOCAL = "地方"  # 你在的那處抽到的地方牌（第 7-3a 批）：跟牌同一級
FACTION = "勢力"  # 你所屬的勢力抽到的勢力牌（第 7-3b1a 批）：跟牌同一級
GATHER = "聚"     # 你那群有人提議拜把子（第 7-5a 批）：跟牌同一級
FACTS = 3   # 旁支事實寫進故事的行數


@dataclass(frozen=True)
class Ask:
    kind: str                      # 上面幾種之一
    wait: str                      # 在等什麼（第 117-2 題五種，domain/pending）
    since: int                     # 從第幾回合開始等
    run: Callable[[dict], dict]    # 落實：角色卡 → 角色卡，其他結果寫進那個系統自己的輸出
    due: int | None = None         # 期限（世界時間）
    urgent: bool = False           # 急：大成功大失敗的牌、追兵、天道落子


def here(kind: str, turn_no: int, urgent: bool = False) -> Ask:
    """當場的候選：落實由 service 照種類做。"""
    return Ask(kind, NOW, turn_no, lambda sheet: sheet, urgent=urgent)


def _rank(a: Ask) -> int:
    return 0 if a.urgent else 1 if a.wait != NOW else 3 if a.kind in (CARD, DEED, LOCAL, FACTION, GATHER) else 2


def pick(asks: list[Ask], *, taken: bool, now: int) -> Ask | None:
    """這回合的主事；危險或回應已經拿走就沒有。同分照候選的順序。"""
    if taken or not asks:
        return None
    return min(asks, key=lambda a: (a.due is None or a.due > now, _rank(a), a.due is None, a.due or 0, a.since))


def facts(lines: list[str]) -> tuple[list[str], list[str]]:
    """旁支事實（已照痕跡 → 傳聞排好）：（寫進故事的, 只留在紀錄的）。"""
    return lines[:FACTS], lines[FACTS:]


def answering(sheet: dict, last: dict, turn_no: int) -> bool:
    """回應的回合：上回合留了請託開口、應對型事件、對峙，或階段表的選項剛出現。"""
    r = sheet["route"]
    fresh = bool(r and stage.options(r) and r["moved"] == turn_no - 1)
    return bool(sheet["asking"] or (last.get("incident") or {}).get("answer") or sheet["standoff"] or fresh)
