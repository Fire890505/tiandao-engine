"""宗門差事（16l 第 28～30 題；草稿 C5a）：主角是仙宗弟子這一邊。純函式。

規則（2026-10-18 與使用者一題一題定案，見 progress/WHITEPAPER.md 16l，數字暫定）：
- 角色卡 errand：None，或 {kind, place, until, tier, need, done, sect, taken}；errand_period：上次擲派差事的百日。
- 四種：出戰（在本盟的戰事地點打退 need 個敵盟的人）、搶造化（搶到任一處）、鎮守（在本盟秘境待滿 need 個時辰）、
  傳訊（走到一座同盟或通商盟的山門）。出戰、搶造化跟著戰事與造化到百日開始後 war.LASTS 為止，其他 LASTS。
- 每個百日擲一次要不要派（CHANCE 看職位，本盟有戰事 +WAR 且優先出戰）；輕中重照職位擲。派下來要說「接下」，
  下回合沒說就算推掉。在自家山門說「請派差事」主動要一件（直接算接下）。宗主、太上長老不派。
- 辦成得戰功（PAY，重的 ×HEAVY，算進出戰誓）、算一場戰績；逾期或推掉記過一級，重的逾期再降一級職位。
- 誓言：「聽候差遣」、「鎮守秘境」（每個百日必派一件鎮守）的人不能推，派下來直接算接下；逾期＝違誓：離宗，
  service 照叛宗處理。
"""
from __future__ import annotations

from . import ascent, atlas, immortal, oath, sect, war
from .clock import SHICHEN_PER_DAY

FIGHT, BOON, GUARD, MESSAGE = KINDS = ("出戰", "搶造化", "鎮守", "傳訊")
TIERS = ("輕", "中", "重")
NEED = {FIGHT: (1, 2, 3), BOON: (1, 1, 1), GUARD: tuple(d * SHICHEN_PER_DAY for d in (10, 20, 30)), MESSAGE: (1, 1, 1)}
WEIGHTS = {sect.OUTER: (6, 3, 1), sect.INNER: (3, 4, 3), sect.CORE: (1, 3, 6)}
CHANCE = {sect.OUTER: 0.3, sect.INNER: 0.5, sect.CORE: 0.7}
WAR = 0.2
LASTS = 30 * SHICHEN_PER_DAY
PAY = {FIGHT: 30, BOON: 30, GUARD: 15, MESSAGE: 15}
HEAVY = 2
ASK_WORDS = ("請派差事", "領差事", "討差事")
TAKE_WORDS = ("接下", "領命", "遵命")
SERVE, KEEP = ascent.OATHS[3], ascent.OATHS[4]
KEYS = {"kind", "place", "until", "tier", "need", "done", "sect", "taken"}


def fields() -> dict:
    return {"errand": None, "errand_period": -1}


def pick(rng, realm: dict, sheet: dict, now: int, only: str = "") -> dict | None:
    """挑一件差事（only：只派這一種）；本盟有戰事優先出戰。沒得派回傳 None。"""
    mine = sheet["sect"]
    ally, st = war._ally(realm, mine), immortal.stances(realm)
    friends = sorted(s["name"] + ascent.GATE for s in realm["sects"] if ally and s["name"] != mine
                     and (s["alliance"] == ally or st.get(atlas._key(ally, s["alliance"])) == atlas.TRADE))
    places = {FIGHT: [w["place"] for w in war.current(realm, now) if ally and ally in w["sides"]],
              BOON: [""] if war.boons(realm, now) else [], GUARD: [s["name"] for s in immortal.secrets(realm, ally)],
              MESSAGE: friends}
    kinds = [k for k in KINDS if places[k] and (k == only or not only)]
    if not kinds:
        return None
    kind = FIGHT if FIGHT in kinds else rng.choice(kinds)
    tier = rng.choices(TIERS, WEIGHTS[sheet["sect_rank"]])[0]
    until = now // immortal.PERIOD * immortal.PERIOD + war.LASTS if kind in (FIGHT, BOON) else now + LASTS
    return {"kind": kind, "place": rng.choice(places[kind]), "until": until, "tier": tier,
            "need": NEED[kind][TIERS.index(tier)], "done": 0, "sect": mine, "taken": False}


def turn(rng, realm: dict, sheet: dict, *, here: str, words: str, fought: str, took: bool, elapsed: int,
         now: int) -> tuple[dict, list[str]]:
    """仙宗弟子的這回合：回覆派下的差事、算進度（fought：這回合在哪件戰事打退敵人；took：搶到造化；elapsed：
    這回合過了幾個時辰）、在山門請派、每個百日擲要不要派。宗主、太上長老不派。"""
    if sheet["sect_rank"] not in CHANCE:
        return sheet, []
    e, facts = sheet["errand"], []
    if e and e["sect"] != sheet["sect"]:   # 離宗了，差事作廢
        sheet, e = {**sheet, "errand": None}, None
    if e and not e["taken"]:
        if any(w in words for w in TAKE_WORDS):
            sheet, e = {**sheet, "errand": {**e, "taken": True}}, {**e, "taken": True}
            facts.append(f"接下差事：{_what(e)}")
        else:
            sheet, lost = _fail(sheet, e, "推掉了宗門派的差事", now, heavy=False)
            facts, e = facts + lost, None
    if e:
        done = e["done"] + {FIGHT: fought == e["place"], BOON: took, MESSAGE: here == e["place"],
                            GUARD: elapsed if here == e["place"] else 0}[e["kind"]]
        if done >= e["need"]:
            pay = PAY[e["kind"]] * (HEAVY if e["tier"] == TIERS[-1] else 1)
            sheet = oath.earn({**sheet, "errand": None, "merit": sheet["merit"] + pay, "feats": sheet["feats"] + 1}, pay)
            facts.append(f"辦成了{e['sect']}的差事（{_what(e)}），戰功 +{pay}")
        elif now >= e["until"]:
            sheet, lost = _fail(sheet, e, f"差事（{_what(e)}）逾期沒辦成", now, heavy=e["tier"] == TIERS[-1])
            facts += lost
        else:
            sheet = {**sheet, "errand": {**e, "done": done}}
    if sheet["sect"] and here == sheet["sect"] + ascent.GATE and any(w in words for w in ASK_WORDS):
        new = None if sheet["errand"] else pick(rng, realm, sheet, now)
        facts.append("手上已經有差事了" if sheet["errand"] else f"向{sheet['sect']}領了差事：{_what(new)}" if new
                     else f"{sheet['sect']}眼下沒有差事")
        sheet = {**sheet, "errand": {**new, "taken": True}} if new else sheet
    period = now // immortal.PERIOD
    if not sheet["sect"] or sheet["errand_period"] >= period:
        return sheet, facts
    sheet = {**sheet, "errand_period": period}
    keep = (sheet["sect_oath"] or {}).get("text") == KEEP
    ally = war._ally(realm, sheet["sect"])
    fights = any(ally and ally in w["sides"] for w in war.current(realm, now))
    if sheet["errand"] or not keep and rng.random() >= CHANCE[sheet["sect_rank"]] + WAR * fights:
        return sheet, facts
    new = pick(rng, realm, sheet, now, GUARD if keep else "")
    if not new:
        return sheet, facts
    sworn = keep or (sheet["sect_oath"] or {}).get("text") == SERVE   # 立了誓不能推：直接算接下
    return ({**sheet, "errand": {**new, "taken": sworn}},
            facts + [f"{sheet['sect']}派下差事：{_what(new)}"
                     + ("（有誓在身，不得推辭）" if sworn else "（說「接下」領命，不回就算推掉）")])


def _fail(sheet: dict, e: dict, why: str, now: int, *, heavy: bool) -> tuple[dict, list[str]]:
    """推掉或逾期：記過一級（重的再降一級）；立了聽候差遣、鎮守秘境（鎮守差事）的誓＝違誓，離宗。"""
    sheet, vow = {**sheet, "errand": None}, (sheet["sect_oath"] or {}).get("text")
    if vow == SERVE or vow == KEEP and e["kind"] == GUARD:
        return sect.leave(sheet, ban_until=sect.FOREVER), [f"{why}，違背了「{vow}」的誓言"]
    sheet, facts, _ = sect.mark(sheet, 1, why, now)
    if heavy and sheet["sect"] and sheet["sect_rank"] != sect.OUTER:
        sheet = {**sheet, "sect_rank": sect.RANKS[sect.RANKS.index(sheet["sect_rank"]) - 1]}
        facts.append(f"重差事辦砸，降為{sheet['sect_rank']}弟子")
    return sheet, facts


def _what(e: dict) -> str:
    what = {FIGHT: f"到{e['place']}出戰，打退 {e['need']} 個敵盟的人", BOON: "搶下一處造化",
            GUARD: f"鎮守{e['place']} {e['need'] // SHICHEN_PER_DAY} 天", MESSAGE: f"傳訊到{e['place']}"}[e["kind"]]
    return f"{what}（{e['tier']}）"


def text(sheet: dict, now: int) -> str:
    e = sheet["errand"]
    if not e:
        return ""
    day = SHICHEN_PER_DAY if e["kind"] == GUARD else 1
    return (f"差事：{_what(e)} {e['done'] // day}／{e['need'] // day}，剩 {max(0, e['until'] - now) // SHICHEN_PER_DAY} 天"
            + ("" if e["taken"] else "（說「接下」領命）"))


def valid(sheet: dict) -> bool:
    e = sheet["errand"]
    return isinstance(sheet["errand_period"], int) and (
        e is None or isinstance(e, dict) and set(e) == KEYS and e["kind"] in KINDS and e["tier"] in TIERS)
