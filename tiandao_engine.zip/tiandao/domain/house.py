"""說書立下、要程式執行的規矩（2026-11-23）。純函式。

大模型在敘事裡寫出住戶守則、村裡的禁忌、廟裡的忌諱，用提案 rules 登錄在那個地點（只記不擋）；
之後主角在那裡、時辰對得上，這條就列進第一段的【守則】，大模型逐條回照做／違反／沒碰到，違反就照後果算，寫進【結果】
（第 12 題小的那級：後果只有小的）。act、word 兩欄登錄時還收，判定不再用。
"""
from __future__ import annotations

WHEN = ("任何時候", "白天", "夜裡")
ANY_ACT = "任何行動"
COSTS = ("受傷", "失錢", "凶兆")      # 凶兆＝不扣東西，只是不祥（說書寫出來）
NIGHT = ("戌時", "亥時", "子時", "丑時", "寅時")
MAX_PER_PLACE = 6
TEXT_LEN = (4, 60)
HURT, LOSS = 0.2, 0.2                 # 受傷扣氣血上限的兩成（不致死）、失錢扣身上凡人錢的兩成


def valid(rules) -> bool:
    """存檔檢查：沒有或一串合格的規矩。"""
    return rules is None or isinstance(rules, list) and len(rules) <= MAX_PER_PLACE and all(
        isinstance(r, dict) and isinstance(r.get("text"), str) and r.get("when") in WHEN
        and isinstance(r.get("act"), str) and isinstance(r.get("word", ""), str) and r.get("cost") in COSTS for r in rules)


def now(rule: dict, shichen: str) -> bool:
    """這條規矩現在有沒有效（時辰對得上）。犯了沒由大模型第一段逐條回（Claude主導第 11、12 題，第九節 4c），不再比對原文。"""
    return rule["when"] == "任何時候" or (shichen in NIGHT) == (rule["when"] == "夜裡")


def apply(sheet: dict, rule: dict) -> tuple[dict, str]:
    """照後果改角色卡，回傳（角色卡, 給說書的一句事實）。"""
    if rule["cost"] == "受傷":
        lost = max(1, int(sheet["hp_max"] * HURT))
        sheet = {**sheet, "hp": max(1, sheet["hp"] - lost)}
        how = "受了傷"
    elif rule["cost"] == "失錢":
        lost = sheet["money"] // 5
        sheet = {**sheet, "money": sheet["money"] - lost}
        how = f"丟了 {lost} 凡人錢" if lost else "身上的錢沒少，卻總覺得被拿走了什麼"
    else:
        how = "沒有立刻出事，卻有一件不祥的事落在你身上"
    return sheet, f"犯了此地的規矩「{rule['text']}」：{how}"


def add(rules: list | None, rule: dict) -> list:
    """登錄一條；同一句不重複，太多就丟最舊的。"""
    kept = [r for r in rules or [] if r["text"] != rule["text"]]
    return [*kept, rule][-MAX_PER_PLACE:]
