"""角色卡。數值一律由 Python 擲出與維護，AI 只能讀，不能寫。"""
from __future__ import annotations

import random
from typing import Any

from ..errors import BadRequest, text_field
from . import (ascent, auction, bondage, breach, cards, dark, echo, lead, side, contest, crafting, errand, form, founding, heaven, hire, home, identity, items,
               laws, learn, lineage, market, merit, origins, party, paths, races, realm, rebirth, recruit, reputation, route, sect, stage, talk, visitors)
from . import era
from . import status as status_mod
from .clock import SHICHEN_PER_YEAR

ATTRIBUTES = ("physique", "wisdom", "root_bone", "perception", "charisma")
ATTRIBUTE_LABELS = {
    "physique": "體魄", "wisdom": "悟性", "root_bone": "根骨",
    "perception": "感知", "charisma": "氣度",
}
GENDERS = ("男", "女", "不明")
START_LOCATION = "青石鎮外的山道"
START_AGE = 16
SHEET_VERSION = 58  # v58：臨時路人（第 9c 批）；v57：命數找上過你的人（併章重設計）；v56：學識、專長（第 7-1c 批）；v55：要脅過的人（第 6-6c 批）；v54：覺醒、殘夢（第 6-6b2 批）；v53：前世（第 6-6b1 批）；v52：回音的期限（第 2-2 批）；v51：路線記換階的原因、伏筆見過幾次（16v 第 81-2、82-1 題）；v50：支線（16v 第 76 題）；v49：路線的人、回音具名（第 104 題）；v48：結局分成敗、回音（16v 第 92-3、95 題）；v47：階段表和結局（16v 第 71-1、73 題）；v46：NPC 的話（16v 第 65 題）；v45：暗線（16v 第 32 題）；v44：線頭（16v 第 28 題）；v43：留著的牌（16v 第 29 題）；v42：牌組（16v）；v41：路線（16v）；v40：族徵收放（16u 族徵）；v39：搭配卡（16u 外貌）；v38：姓和姓氏來歷（16u）；v37：查到的線索與物證（16t）； v2：年齡、突破冷卻、壽元折損（第 3 步）；v3：狀態清單、瀕死傷勢（第 4 步）；v4：外貌（第 10a 步）；
                    # v5：江湖傳言中的你（第 10c-3b 步）；v6：身上的物品（第 8 步）；v7：感悟與主修功法（第 3b-1 步）；
                    # v8：煉丹、煉器熟練度（第 3b-3 步）；v9：人族支系、靈根、諸天異端（第 5 步）；
                    # v10：天道注視（第 18-1 步）；v11：欠天道一手（第 18-2a 步）；v12：落腳處與家運（第 19 步）；
                    # v13：凡人錢、房租與欠租（經濟第二輪）；v14：化名、易容、通緝（身分與追捕）；
                    # v15：最近一次買賣的 requestId（小修清單）；v16：凡人身分、命途（16g）
                    # v17：注定的事改成記進度（16g 追加第 3 題）；v18：通緝記哪一國（16h 國法）
                    # v19：門派（16h 宗門第二批）；v20：記過、叛門的追殺（第三批）；v21：隨行的人（16i 同伴）；v22：黑市、贓物；v23：拍賣會、隨行的人記體質與出身
                    # v24：出身奴隸的主人、身價（16k）
                    # v25：破格期倒數、被天道抹殺（16l）；v26：接引、飛升（16l）；v27：戰功（16l C2）；v28：招攬、戰績、誓言（16l C4a）；v29：仙戰（C4b）；v30：受雇（C4c）；v31：宗主招收（C4d）；v32：宗門差事（C5a）；v33：道統；v34：道號
                    # v35：當面對峙的仇家、打退的人（16m 第 7 題）；v36：物品的叫法（16p）
APPEARANCE_MAX = 200
PLACE_NAME_MAX = 40
APPEARANCE_REWRITE = ("", "年歲漸長", "境界提升", "留下傷痕")   # 主角外貌要改寫的原因（Python 標記，AI 寫新描述）
LIFESPAN_WARNING_YEARS = 5
STATUSES = ("ALIVE", "DYING", "FALLEN")


BACKGROUND_MAX = 200   # 匯入的存檔也照這個截（3-7a 第 4 題）


def create_sheet(rng: random.Random, *, name: str, gender: str, background: str = "",
                 clock_now: int = 0, appearance: str = "", location: str = START_LOCATION) -> dict[str, Any]:
    """location：出生地（第 16b 步建角時選；舊世界一律是起始山道）。"""
    name = text_field(name, "角色名稱", "invalid_name")
    background = text_field(background, "背景描述", "invalid_background")
    appearance = valid_appearance(appearance)
    if not 1 <= len(name) <= 12:
        raise BadRequest("角色名稱需為 1 到 12 個字。", code="invalid_name")
    if gender not in GENDERS:
        raise BadRequest(f"性別只能是 {'、'.join(GENDERS)}。", code="invalid_gender")
    if len(background) > BACKGROUND_MAX:
        raise BadRequest(f"背景描述最多 {BACKGROUND_MAX} 字。", code="invalid_background")
    attributes = {key: rng.randint(30, 70) for key in ATTRIBUTES}
    hp_max = 60 + attributes["physique"]
    return _with_laws({
        "version": SHEET_VERSION,
        "name": name,
        "gender": gender,
        "race": "人族",
        "background": background,
        "realm_lv": 0,
        "stage_index": 0,
        "cultivation": 0,
        "attributes": attributes,
        "hp": hp_max,
        "hp_max": hp_max,
        "spirit_stones": rng.randint(0, 10),
        "money": rng.randint(0, 100),    # 凡人錢（經濟第二輪；名稱依時代，era.MONEY）
        "location": location,
        "status": "ALIVE",
        "birth_shichen": clock_now - START_AGE * SHICHEN_PER_YEAR,   # 可為負數：出生在紀元之前
        "breakthrough_ready_at": None,   # 下次可以嘗試大突破的時間（時辰）；None＝隨時
        "lifespan_adjust": 0,            # 壽元增減（年），例如道基崩毀折損、燃燒壽元
        "statuses": [],                  # 狀態（domain/status.py）
        "wound": 0,                      # 瀕死時的傷勢 0–100（status=DYING 時才有意義）
        **_appearance_fields(appearance, START_AGE if appearance else None),
        **_reputation_fields(),
        **_item_fields(),
        "craft_skill": crafting.new_skills(),   # 煉丹、煉器熟練度（第 3b-3 步）
        **lineage.fields(),                     # 支系、靈根、諸天異端（第 5 步；建角時由 lineage.assign 決定）
        **heaven.fields(),                      # 天道注視（第 18-1 步；諸天異端由 service 建角後補成 20）
        **home.fields(),                        # 落腳處與家運（第 19 步；建角時由 home.assign 決定）
        **identity.fields(),                    # 化名、易容、通緝（身分與追捕，WHITEPAPER 16e.1）
        **origins.fields(),                     # 凡人身分、命途（16g；建角時由 origins.apply 決定）
        **sect.fields(),                        # 門派（16h 宗門第二批）
        **party.fields(),                       # 隨行的人（16i）
        **market.fields(),                      # 黑市的暗號、黑名單、假路引（16i）
        **auction.fields(),                     # 這一季的拍賣會邀請函（16i）
        **bondage.fields(),                     # 出身奴隸：主人、身價（16k）
        **breach.fields(),                      # 破格期倒數、被天道抹殺（16l）
        **ascent.fields(),                      # 接引、飛升（16l）
        **merit.fields(),                       # 戰功（16l C2）
        **recruit.fields(),                     # 仙域的招攬、戰績、立的誓（16l C4a）
        **contest.fields(),                     # 正在打的仙戰（16l C4b）
        **hire.fields(),                        # 散仙受雇於哪個仙宗（16l C4c）
        **founding.fields(),                    # 宗主上次招收的百日（16l C4d）
        **errand.fields(),                      # 宗門派的差事（16l C5a）
        **paths.fields(),                       # 道統（16l 第 41～43 題）
        "dao": "",                              # 道號（16l 第 44 題；舊的記在化名，仙域回合裡搬過來）
        **visitors.fields(),                    # 當面對峙的仇家、打退的人（16m 第 7 題）
        **route.fields(),                       # 手上的路線、天道的鐘（16v）
        **cards.fields(),                       # 牌組（16v）
        **lead.fields(), **dark.fields(), **talk.fields(), **side.fields(), "passers": [],   # 線頭、暗線、NPC 的話、支線（16v）、臨時路人（9c）
        **rebirth.fields(),                     # 前世：說過了的事、信物（第 6-6b1 批）
        "learning": "", "knacks": [],           # 學識、專長（第 7-1c 批；建角時由 learn.of_me 擲）
    })


def carried(sheet: dict[str, Any], *, location: str, clock_now: int, was: int) -> dict[str, Any]:
    """飛升到仙域的同一個人（16l 第 4 題）：境界、法則、功法、物品、屬性、出身帶過去；原世界的落腳處、門派、隨行的人、
    通緝、黑市、狀態、天道注視（每一生一份）都不帶。was：原世界飛升那一刻（年齡照原本算）。"""
    return {**sheet, **_reputation_fields(), **home.fields(), **identity.fields(), **sect.fields(), **party.fields(),
            **market.fields(), **auction.fields(), **bondage.fields(), **breach.fields(), **ascent.fields(), **visitors.fields(),
            **heaven.fields(sheet["heretic"]), "realm_since": clock_now, "location": location,
            "birth_shichen": sheet["birth_shichen"] + clock_now - was, "hp": sheet["hp_max"], "status": "ALIVE",
            "wound": 0, "statuses": [], "breakthrough_ready_at": None, "pills_taken": [], "item_notes": [],
            "item_request": "", "stolen": {}}


def _with_laws(sheet: dict[str, Any]) -> dict[str, Any]:
    """感悟與主修功法（第 3b-1 步，domain/laws.py）：人人都會的《吐納法》不佔背包。"""
    return {**sheet, "insight": {n: 0 for n in laws.taught(items.BASIC_TECHNIQUE)},   # 現象 → 感悟（0–100）；吐納法帶靈地草盛
            "technique": items.BASIC_TECHNIQUE,   # 主修功法
            "laws_warned": False}             # 已經說過「此系為天道所鎖」


def _item_fields() -> dict[str, Any]:
    """身上的物品（第 8 步，domain/items.py）。"""
    return {"items": [],           # [{"name", "tier", "count"}]
            "pills_taken": [],     # 這回合吃過的丹藥（同一種一回合只能吃一顆）
            "item_notes": [],      # 買賣、服用的紀錄，下一回合交給說書人
            "item_request": "",    # 最近一次買賣、服用的 requestId（重送不重做，小修清單第 1 題）
            "stolen": {},          # 其中幾個是贓物：{"名字|品階": 幾個}（16i）
            "aka": {},             # 其中幾個是世界的新物品：{"底|品階": {"叫法": 幾個}}（16p）
            "clues": []}           # 查到的線索：[{"plot", "key", "kind", "text"}]，物證事端結束後留著（16t）


def _reputation_fields() -> dict[str, Any]:
    """江湖傳言中的你（第 10c-3b 步）：說書人依某地的名聲寫的一段話。玩家不能修改（那是別人怎麼說你）。"""
    return {"reputation": "",          # 傳言
            "reputation_place": "",    # 在哪裡聽來的
            "reputation_levels": {},   # 寫的時候那裡的名聲等級（跨過門檻就要改寫）
            "reputation_big": []}      # 寫的時候算進去的大事（傳聞 id；有新的大事傳到就要改寫）


def _appearance_fields(text: str, written_age: int | None) -> dict[str, Any]:
    """外貌（第 10a 步）：描寫，不帶來能力。空字串＝開場時請 AI 依靈感代寫。"""
    return {"appearance": text, "appearance_age": written_age,   # 寫於幾歲（相差 10 年以上要改寫）
            "look": {},                  # 搭配卡（16u 外貌，domain/looks.py）；舊角色、現代和未來世界是空的
            **form.fields(),             # 族徵收放（16u 族徵）
            "appearance_prev": "",       # 上一版（玩家可以改回）
            "appearance_rewrite": "",    # 要改寫的原因（APPEARANCE_REWRITE）；空＝不用
            "appearance_changed": False}  # 剛被改寫、還沒給玩家看過（畫面提示用）


def valid_appearance(text: Any) -> str:
    text = str(text or "").strip()
    if len(text) > APPEARANCE_MAX:
        raise BadRequest(f"外貌描述最多 {APPEARANCE_MAX} 字。", code="invalid_appearance")
    return text


def upgrade(sheet: dict[str, Any]) -> dict[str, Any]:
    """舊版角色卡補上新欄位。v1 的角色都是在紀元 0 建立的，所以出生於 -16 年。"""
    if sheet.get("version") == 1:
        sheet = {**sheet, "version": 2, "birth_shichen": -START_AGE * SHICHEN_PER_YEAR,
                 "breakthrough_ready_at": None, "lifespan_adjust": 0}
    if sheet.get("version") == 2:
        sheet = {**sheet, "version": 3, "statuses": [], "wound": 0}
    if sheet.get("version") == 3:
        sheet = {**sheet, "version": 4, **_appearance_fields("", None)}
    if sheet.get("version") == 4:
        sheet = {**sheet, "version": 5, **_reputation_fields()}
    if sheet.get("version") == 5:
        sheet = {**sheet, "version": 6, **_item_fields()}
    if sheet.get("version") == 6:
        sheet = {**_with_laws(sheet), "version": 7}
    if sheet.get("version") == 7:
        sheet = {**sheet, "version": 8, "craft_skill": crafting.new_skills()}
    if sheet.get("version") == 8:
        sheet = {**sheet, "version": 9, **lineage.fields()}
    if sheet.get("version") == 9:
        sheet = {**sheet, "version": 10, **heaven.fields(sheet.get("heretic") is True)}
    if sheet.get("version") == 10:
        sheet = {**sheet, "version": 11, "debt": None}
    if sheet.get("version") == 11:
        sheet = {**sheet, "version": 12, **home.fields()}
    if sheet.get("version") == 12:   # 舊的租房不知道在城鎮還是村落：照村落的租金
        sheet = {**sheet, "version": 13, "money": 0, "owed": 0,
                 "rent": home.RENT["村落"] if sheet["home_kind"] == home.RENTED else 0}
    if sheet.get("version") == 13:
        sheet = {**sheet, "version": 14, **identity.fields()}
    if sheet.get("version") == 14:
        sheet = {**sheet, "version": 15, "item_request": ""}
    if sheet.get("version") == 15:
        sheet = {**sheet, "version": 16, **origins.fields()}
    if sheet.get("version") == 16:
        sheet = {**sheet, "version": 17}   # 注定的事（fated）第 6-1 批拆掉
    if sheet.get("version") == 17:   # 舊的通緝不知道是哪一國：空＝哪一國都算
        sheet = {**sheet, "version": 18, "wanted": {k: {**v, "nation": ""} for k, v in sheet["wanted"].items()}}
    if sheet.get("version") == 18:
        sheet = {**sheet, "version": 19, **sect.fields()}
    if sheet.get("version") == 19:
        sheet = {"sect_demerit": None, "sect_hunt": None, **sheet, "version": 20}
    if sheet.get("version") == 20:
        sheet = {**sheet, "version": 21, **party.fields()}
    if sheet.get("version") == 21:
        sheet = {**sheet, "version": 22, "stolen": {}, **market.fields()}
    if sheet.get("version") == 22:
        sheet = {**sheet, "version": 23, **auction.fields(),
                 "party": [{"physique": "", "home": "", **m} for m in sheet["party"]]}
    if sheet.get("version") == 23:
        sheet = {**sheet, "version": 24, **bondage.fields()}
    if sheet.get("version") == 24:   # 已經在破格期的舊角色：從現在起算（service 補上，見 _breach_turn）
        sheet = {**sheet, "version": 25, **breach.fields()}
    if sheet.get("version") == 25:
        sheet = {**sheet, "version": 26, **ascent.fields()}
    if sheet.get("version") == 26:
        sheet = {**sheet, "version": 27, **merit.fields()}
    if sheet.get("version") == 27:
        sheet = {**sheet, "version": 28, **recruit.fields()}
    if sheet.get("version") == 28:
        sheet = {**sheet, "version": 29, **contest.fields()}
    if sheet.get("version") == 29:
        sheet = {**sheet, "version": 30, **hire.fields()}
    if sheet.get("version") == 30:
        sheet = {**sheet, "version": 31, **founding.fields()}
    if sheet.get("version") == 31:
        sheet = {**sheet, "version": 32, **errand.fields()}
    if sheet.get("version") == 32:   # 道統由回合裡照所屬宗門補上
        sheet = {**sheet, "version": 33, **paths.fields()}
    if sheet.get("version") == 33:
        sheet = {**sheet, "version": 34, "dao": ""}
    if sheet.get("version") == 34:
        sheet = {**sheet, "version": 35, **visitors.fields()}
    if sheet.get("version") == 35:
        sheet = {**sheet, "version": 36, "aka": {}}
    if sheet.get("version") == 36:
        sheet = {**sheet, "version": 37, "clues": []}
    if sheet.get("version") == 37:
        sheet = {**sheet, "version": 38, "surname": "", "surname_from": ""}
    if sheet.get("version") == 38:
        sheet = {**sheet, "version": 39, "look": {}}
    if sheet.get("version") == 39:
        sheet = {**sheet, "version": 40, **form.fields()}
    if sheet.get("version") == 40:
        sheet = {**sheet, "version": 41, **route.fields()}
    if sheet.get("version") == 41:
        sheet = {**sheet, "version": 42, **cards.fields(), "route": sheet["route"] and {"name": "", **sheet["route"]}}
    if sheet.get("version") == 42:
        sheet = {**sheet, "version": 43, "card_wait": None}
    if sheet.get("version") == 43:
        sheet = {**sheet, "version": 44, **lead.fields()}
    if sheet.get("version") == 44:
        sheet = {**sheet, "version": 45, **dark.fields()}
    if sheet.get("version") == 45:
        sheet = {**sheet, "version": 46, **talk.fields(), "route_cards": 0}
    if sheet.get("version") == 46:
        sheet = {**{k: v for k, v in sheet.items() if k != "route_cards"}, "version": 47, "card_used": [], "scars": [],
                 "route": sheet["route"] and {**stage.fields(), **sheet["route"]}}
    if sheet.get("version") == 47:
        sheet = {**sheet, "version": 48, **echo.fields(), "route": sheet["route"] and {**stage.fields(), **sheet["route"]}}
    if sheet.get("version") == 48:
        sheet = {**sheet, "version": 49, "echoes": [{"who": "", **e} for e in sheet["echoes"]],
                 "route": sheet["route"] and {**stage.fields(), **sheet["route"]}}
    if sheet.get("version") == 49:
        sheet = {**sheet, "version": 50, **side.fields(), "past": {**talk.fields()["past"], **sheet["past"]}, "echoes": [{"side": None, **e} for e in sheet["echoes"]],
                 "route": sheet["route"] and {**stage.fields(), **sheet["route"]}}
    if sheet.get("version") == 50:
        sheet = {**sheet, "version": 51, "route": sheet["route"] and {**stage.fields(), **sheet["route"]}}
    if sheet.get("version") == 51:   # 回音的期限（第 2-2 批）：舊的不過期
        sheet = {**sheet, "version": 52, "echoes": [{"until": None, **e} for e in sheet["echoes"]]}
    if sheet.get("version") == 52:
        sheet = {**sheet, "version": 53, **rebirth.fields()}
    if sheet.get("version") == 53:
        sheet = {**sheet, "version": 54, "rebirth": {**rebirth.fields()["rebirth"], **sheet["rebirth"]}}
    if sheet.get("version") == 54:
        sheet = {**sheet, "version": 55, "gripped": []}
    if sheet.get("version") == 55:
        sheet = {**sheet, "version": 56, "learning": "", "knacks": []}
    if sheet.get("version") == 56:
        sheet = {**sheet, "version": 57, "called": []}
    if sheet.get("version") == 57:
        sheet = {**sheet, "version": 58, "passers": []}
    return sheet


def age(sheet: dict[str, Any], clock_now: int) -> int:
    return (clock_now - sheet["birth_shichen"]) // SHICHEN_PER_YEAR


def lifespan(sheet: dict[str, Any]) -> int | None:
    base = realm.TIERS[sheet["realm_lv"]].lifespan   # 魔族 ×2.5、獸族 ×3.5（16k）
    return None if base is None else round(base * races.LIFESPAN[sheet["race"]]) + sheet["lifespan_adjust"]


def remaining_life_shichen(sheet: dict[str, Any], clock_now: int) -> int | None:
    """距離壽盡還有幾個時辰；不受壽元限制時回傳 None。"""
    span = lifespan(sheet)
    return None if span is None else sheet["birth_shichen"] + span * SHICHEN_PER_YEAR - clock_now


def validate_sheet(sheet: Any) -> dict[str, Any]:
    """讀檔時使用：拒絕結構不完整或數值越界的角色卡。回傳升級到最新版本的角色卡。"""
    if not isinstance(sheet, dict) or sheet.get("version") not in range(1, SHEET_VERSION + 1):
        raise BadRequest("角色卡格式不符。", code="invalid_save")
    sheet = upgrade(sheet)
    try:
        lv, stage = int(sheet["realm_lv"]), int(sheet["stage_index"])
        attrs = sheet["attributes"]
        ok = (
            lv in realm.TIERS and 0 <= stage <= realm.last_stage(lv)   # 負數索引在 Python 會取到最後一個，要明確擋
            and all(isinstance(attrs.get(k), int) and 1 <= attrs[k] <= 100 for k in ATTRIBUTES)
            and 0 <= int(sheet["cultivation"]) <= realm.PROGRESS_PER_STAGE
            and 0 <= int(sheet["hp"]) <= int(sheet["hp_max"]) <= 500
            and int(sheet["spirit_stones"]) >= 0
            and _is_int(sheet["money"]) and sheet["money"] >= 0
            and sheet["status"] in STATUSES
            and status_mod.valid(sheet["statuses"])
            and _is_int(sheet["wound"]) and 0 <= sheet["wound"] <= 100
            and (sheet["status"] != "DYING" or (sheet["hp"] == 0 and sheet["wound"] > 0))
            and sheet["gender"] in GENDERS
            and isinstance(sheet["clues"], list) and all(
                isinstance(c, dict) and all(isinstance(c.get(k), str) for k in ("plot", "key", "kind", "text")) for c in sheet["clues"])
            and isinstance(sheet["name"], str) and 1 <= len(sheet["name"]) <= 12
            and isinstance(sheet["location"], str) and 1 <= len(sheet["location"]) <= PLACE_NAME_MAX
            and isinstance(sheet["background"], str)
            and _is_int(sheet["birth_shichen"])
            and (sheet["breakthrough_ready_at"] is None or _is_int(sheet["breakthrough_ready_at"]))
            and _is_int(sheet["lifespan_adjust"]) and sheet["lifespan_adjust"] <= origins.LONGEST
            and isinstance(sheet["appearance"], str) and len(sheet["appearance"]) <= APPEARANCE_MAX
            and isinstance(sheet["appearance_prev"], str) and len(sheet["appearance_prev"]) <= APPEARANCE_MAX
            and (sheet["appearance_age"] is None or _is_int(sheet["appearance_age"]))
            and sheet["appearance_rewrite"] in APPEARANCE_REWRITE
            and isinstance(sheet["appearance_changed"], bool)
            and isinstance(sheet["look"], dict) and all(isinstance(v, str) for v in sheet["look"].values())
            and route.valid(sheet) and cards.valid(sheet) and lead.valid(sheet) and dark.valid(sheet) and talk.valid(sheet) and side.valid(sheet) and isinstance(sheet["passers"], list)
            and isinstance(sheet["shown"], bool) and sheet["form_mode"] in ("", races.SLIP, races.PILL) and _is_int(sheet["form_until"])
            and isinstance(sheet["reputation"], str) and len(sheet["reputation"]) <= APPEARANCE_MAX
            and isinstance(sheet["reputation_place"], str) and len(sheet["reputation_place"]) <= PLACE_NAME_MAX
            and isinstance(sheet["reputation_levels"], dict)
            and all(a in reputation.AXES and l in reputation.LEVELS for a, l in sheet["reputation_levels"].items())
            and isinstance(sheet["reputation_big"], list) and all(isinstance(i, str) for i in sheet["reputation_big"])
            and items.valid(sheet)
            and laws.valid(sheet)
            and crafting.valid(sheet)
            and lineage.valid(sheet)
            and heaven.valid(sheet)
            and home.valid(sheet)
            and identity.valid(sheet)
            and origins.valid(sheet)
            and sect.valid(sheet)
            and party.valid(sheet)
            and market.valid(sheet)
            and auction.valid(sheet)
            and bondage.valid(sheet)
            and breach.valid(sheet)
            and isinstance(sheet["ascended"], bool) and (sheet["ascent"] is None or isinstance(sheet["ascent"], dict))
            and _is_int(sheet["merit"]) and sheet["merit"] >= 0 and recruit.valid(sheet)
            and contest.valid(sheet) and hire.valid(sheet) and isinstance(sheet["enlisted"], int)
            and errand.valid(sheet) and paths.valid(sheet) and rebirth.valid(sheet) and learn.valid(sheet)
        )
    except (KeyError, TypeError, ValueError, AttributeError):   # 欄位缺了、或型別不對（例如屬性不是物件）
        ok = False
    if not ok:
        raise BadRequest("角色卡數值不合法。", code="invalid_save")
    return sheet


def _is_int(value) -> bool:
    return isinstance(value, int) and not isinstance(value, bool)


def summary(sheet: dict[str, Any], clock_now: int | None = None) -> dict[str, Any]:
    """給前端與提示詞用的可讀摘要。給了 clock_now 才會有年齡與剩餘壽元。"""
    extra: dict[str, Any] = {}
    if clock_now is not None:
        span = lifespan(sheet)
        years_left = None if span is None else span - age(sheet, clock_now)
        extra = {"age": age(sheet, clock_now), "lifespan": span,
                 "lifespanWarning": years_left is not None and years_left <= LIFESPAN_WARNING_YEARS,
                 "breachText": breach.text(sheet, clock_now),   # 破格期倒數（16l）
                 "ascentText": ascent.text(sheet["ascent"]["offers"]) if sheet["ascent"] else "",   # 等回答的接引
                 "meritText": merit.text(sheet),   # 戰功（16l C2）
                 "inviteText": recruit.text(sheet, clock_now),   # 招攬中（16l C4a）
                 "contestText": contest.text(sheet),   # 仙戰第幾輪（C4b）
                 "hireText": hire.text(sheet),   # 受雇於誰（C4c）
                 "errandText": errand.text(sheet, clock_now),   # 手上的差事（C5a）
                 "pathText": paths.text(sheet)}   # 道統
    return {
        **extra,
        "atBottleneck": (realm.at_bottleneck(sheet["realm_lv"], sheet["stage_index"], sheet["cultivation"])
                         or realm.at_gate(sheet["realm_lv"], sheet["stage_index"], sheet["cultivation"])),
        "name": sheet["name"],
        "gender": sheet["gender"],
        "background": sheet["background"],
        "race": sheet["race"],
        "lineage": lineage.label(sheet),
        "lineageText": lineage.prompt_line(sheet),
        "originText": origins.prompt_line(sheet),   # 凡人身分與命途（16g）
        "homeText": home.prompt_line(sheet),
        "surnameNote": home.SOURCE_NOTES.get(sheet["surname_from"], ""),
        "formNote": races.form_text(sheet),
        "heavenFeeling": heaven.feeling(sheet),   # 只給畫面，提示詞不放（第 18-1 步）
        "realm": realm.stage_name(sheet["realm_lv"], sheet["stage_index"]),
        "realmLv": sheet["realm_lv"],
        "cultivation": sheet["cultivation"],
        "hp": sheet["hp"],
        "hpMax": sheet["hp_max"],
        "spiritStones": sheet["spirit_stones"],
        "money": sheet["money"],
        "rentOwed": sheet["owed"],
        "items": items.carried_text(sheet),
        "laws": laws.panel(sheet),
        "lawsText": laws.prompt_text(sheet),
        "technique": sheet["technique"],
        "craftSkill": {c: {"level": v, "rank": crafting.rank(v)} for c, v in sheet["craft_skill"].items()},
        "location": sheet["location"],
        "status": sheet["status"],
        "wound": sheet["wound"],
        "statuses": [{"name": s["name"], "kind": s["kind"], "magnitude": s["magnitude"]}
                     for s in sheet["statuses"]
                     if clock_now is None or s["expires_at"] is None or s["expires_at"] > clock_now],
        "attributes": {ATTRIBUTE_LABELS[k]: v for k, v in sheet["attributes"].items()},
        "appearance": sheet["appearance"],
        "appearancePrev": sheet["appearance_prev"],
        "appearanceChanged": sheet["appearance_changed"],
    }


def flag_appearance(before: dict[str, Any], after: dict[str, Any]) -> dict[str, Any]:
    """這回合的變化要不要讓外貌改寫：大境界提升、陷入瀕死（留下傷痕）。已有標記就不覆蓋。"""
    if after["appearance_rewrite"] or not after["appearance"]:
        return after
    if after["realm_lv"] > before["realm_lv"]:
        return {**after, "appearance_rewrite": "境界提升"}
    if before["status"] != "DYING" and after["status"] == "DYING":
        return {**after, "appearance_rewrite": "留下傷痕"}
    return after


def apply_appearance(sheet: dict[str, Any], text: str, clock_now: int, *, by_player: bool = False) -> dict[str, Any]:
    """換上新的外貌描述（AI 改寫或玩家自己改）。舊的留一版可以改回；AI 改寫的會提示玩家看一下。"""
    return {**sheet, "appearance": text, "appearance_prev": sheet["appearance"],
            "appearance_age": age(sheet, clock_now), "appearance_rewrite": "",
            "appearance_changed": not by_player}


def apply_reputation(sheet: dict[str, Any], text: str, *, place: str, levels: dict, big: tuple) -> dict[str, Any]:
    """換上說書人新寫的「江湖傳言中的你」，記下在哪裡、當時的名聲等級、算進去的大事（下次要不要改寫看這些）。"""
    return {**sheet, "reputation": text, "reputation_place": place, "reputation_levels": dict(levels),
            "reputation_big": list(big)}


def lost(sheet: dict[str, Any], card: dict, clock_now: int) -> bool:
    """主角脫節（125-5、第 8-3 批）：這一生開局（出生＋開局年紀）早於這個時代開始，時代開始還不到一年。
    換一世跳躍當下換時代的新主角不算（開局＝時代開始）。"""
    since = card["since"]
    return card["era"] != era.ANCIENT and sheet["birth_shichen"] + START_AGE * SHICHEN_PER_YEAR < since <= clock_now < since + SHICHEN_PER_YEAR


def appearance_due(sheet: dict[str, Any], clock_now: int, card: dict | None = None) -> str:
    """主角外貌要不要改寫：Python 標記的原因（境界、傷痕）優先，其次是換時代滿一年（外貌寫於時代開始前，第 8-3 批），
    再其次是年紀差 10 年以上。"""
    if sheet["appearance_rewrite"]:
        return sheet["appearance_rewrite"]
    written = sheet["appearance_age"]
    if (card and card["era"] != era.ANCIENT and sheet["appearance"] and written is not None
            and sheet["birth_shichen"] + (written + 1) * SHICHEN_PER_YEAR <= card["since"] <= clock_now - SHICHEN_PER_YEAR):
        return "換了時代"
    if card and lost(sheet, card, clock_now):   # 脫節時不照年紀改寫：不然滿一年就不會照新時代重寫
        return ""
    if sheet["appearance"] and written is not None and age(sheet, clock_now) - written >= 10:
        return "年歲漸長"
    return ""
