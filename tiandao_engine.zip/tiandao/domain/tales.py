"""前期領域的主題（第 19-1 步）：規則表。內容在 rules/content/tales/（第 4-4 題，一篇一個檔）。內容照 progress/DOMAIN_TALES.md（Claude 起草；第一批使用者 2026-10-06 說照草稿，第二批 2026-10-07 說都收）。

文字裡的 {此地}、{鄰地}、{人}（亡者執念型另有 {亡者}、{仇人}）在用的時候換成當地的名字。
規則與破解步驟都寫成 Python 判斷得出來的積木（WHITEPAPER 第 16d 節第 2 題）：
- Rule：沒有 scene 的是「禁令」——時段、行動、字詞都對得上（空的不看）就犯規；
  有 scene 的是「情境」——Python 先讓它發生，下一回合玩家做了 natures 的行動、或寫了 words 的字（有一就算）就犯規，
  該寫的 good 一個都沒寫也犯規。
- Way：破解的一種走法——在哪裡（此地／鄰地）、時段、行動、字詞、是不是對{人}、要不要判定成功。
規模（第 10 題）：主題列出可能的規模（＝被籠罩地點的規模），規則標適用規模（空＝都用）。
規則只能往後加：已經存在的領域用編號記著抽中的守則。
儀式型（鄉野奇談，WHITEPAPER 第 16d 節）：主題有 doer（誰會照流傳的玩法去做）；錯的規則帶 truth（正確的做法，
破解第一步時揭穿）；always＝流傳的收尾方式，每次都抽到。
模型寫的主題（第 128 系列乙第二批，domain/newtales.py）存在 tales_w，只屬那個世界、只在那一州出現：每回合開頭 use 設一次，
讀主題一律用 theme（同 legends.theme）。
"""
from __future__ import annotations

from contextvars import ContextVar
from dataclasses import dataclass, field, fields

from ..config import PROJECT_ROOT
from . import deck, era

NIGHT, MIDNIGHT, DAY = "夜裡", "子時", "白天"
HURT1, HURT2, MARKED, THING, BOSS = "傷1", "傷2", "盯上", "規則之物", "本體"
HERE, NEAR = "此地", "鄰地"
HOME, VILLAGE, TOWN, CITY = "家", "村落", "鄉鎮", "城市"   # 與地點的規模（domain/space.SCALES）同名；生靈級在 19-2
SCALES = (HOME, VILLAGE, TOWN, CITY)
GHOST_TALE = "亡者執念"
GRUDGE, PROMISE = "恩怨", "約定"   # 與 domain/undead.py 相同
BRAVE, FORTUNE, MOURNER, GUARD = "膽大", "問前程", "思念亡者", "守護"   # 儀式型：誰會做（domains.doer 判斷）
LIE = "（這條是假的）"   # Rule.truth 的特別值：錯的規則沒有正確做法可寫（19-3 第 4 題）


@dataclass(frozen=True)
class Rule:
    text: str
    cost: str = ""                 # 犯了（或照假規則做了）的後果；空＝只是提示
    fake: bool = False
    when: str = ""
    natures: tuple[str, ...] = ()
    words: tuple[str, ...] = ()
    scene: str = ""                # 情境：Python 讓它發生的事
    good: tuple[str, ...] = ()     # 情境：該寫的字（一個都沒寫＝犯規）
    kind: str = ""                 # 亡者執念型：只用在這種執念（恩怨／約定）；空＝都用
    scales: tuple[str, ...] = ()   # 適用規模；空＝這個主題的每種規模都用
    truth: str = ""                # 錯的規則的正確做法（破解第一步時揭穿；LIE＝只標「這條是假的」）
    always: bool = False           # 儀式型：流傳的收尾方式，每次都抽到


@dataclass(frozen=True)
class Way:
    place: str = HERE
    when: str = ""
    natures: tuple[str, ...] = ()
    words: tuple[str, ...] = ()
    person: bool = False           # 對象要是{人}
    success: bool = True           # 要判定成功（不擲骰的行動不看）


@dataclass(frozen=True)
class Step:
    ways: tuple[Way, ...]
    reveal: str                    # 完成時揭露的事
    hint: str                      # 下一步的提示（完成這一步之後開的線頭）


@dataclass(frozen=True)
class Tale:
    name: str
    scales: tuple[str, ...]        # 可能的規模
    law: str                       # 破解得到的感悟
    relic: bool                    # 破解後有沒有來由主人留下的東西
    rumor: str                     # 出現時的傳聞（接在地名後面）
    notice: str                    # 守則寫在哪裡
    mood: str                      # 給說書人的氣氛
    boss: str                      # 來由的本體
    thing: str                     # 規則之物
    rules: tuple[Rule, ...]
    steps: tuple[Step, ...]
    draw: int = 5
    notices: dict = field(default_factory=dict)   # 某些規模的守則寫在別的地方（規模 → 文字）
    places: tuple[str, ...] = ()                  # 被籠罩的地點還要是這幾種類型（空＝不限；例：家級的客棧只能是客棧）
    doer: str = ""                                # 儀式型：誰會去做（BRAVE、FORTUNE……）；空＝不是儀式型
    eras: tuple[str, ...] = (era.ANCIENT,)        # 屬於哪些時代（第 16e 節）；其他時代只出現在 era.OLD_PLACES
    state: str = ""                               # 模型寫的綁一州（只在那一州出現）；手寫的空＝哪裡都有
    twist: str = ""                               # 模型寫的扭法（tale_parts.txt）：牌 路線:扭法 的零件套（待辦 3）；手寫的空

    def notice_at(self, scale: str) -> str:
        return self.notices.get(scale, self.notice)


CONTENT = PROJECT_ROOT / "rules" / "content"
RULE_KEYS = {"犯了": "cost", "假": "fake", "時段": "when", "行動": "natures", "詞": "words", "情境": "scene", "該寫": "good",
             "執念": "kind", "規模": "scales", "正解": "truth", "每次": "always"}
WAY_KEYS = {"地": "place", "時段": "when", "行動": "natures", "詞": "words", "對人": "person", "要成功": "success"}


def rows(path) -> list[list[str]]:
    """一篇一個檔（第 4-4 題，跟 plots/ 同一種寫法）：一行一列，照檔案裡的順序。"""
    return [line.split("｜") for line in path.read_text(encoding="utf-8").splitlines() if line and not line.startswith("#")]


def items(text: str) -> tuple[str, ...]:
    return tuple(text.split("、")) if text else ()


def make(cls, keys: dict, cols: list[str], **kw):
    """「字:值」欄 → 積木；tuple 欄用「、」分開，bool 欄寫「是」或「否」，沒寫照預設。"""
    defaults = {f.name: f.default for f in fields(cls)}
    for col in cols:
        k, v = col.split(":", 1)
        a = keys[k]
        kw[a] = items(v) if isinstance(defaults[a], tuple) else v == "是" if isinstance(defaults[a], bool) else v
    return cls(**kw)


def steps(rs: list[list[str]]) -> tuple[Step, ...]:
    """步驟｜揭露｜提示，底下接這一步的做法。"""
    out = []
    for field_, *rest in rs:
        if field_ == "步驟":
            out.append((rest[0], rest[1], []))
        elif field_ == "做法":
            out[-1][2].append(make(Way, WAY_KEYS, rest))
    return tuple(Step(tuple(ways), reveal, hint) for reveal, hint, ways in out)


def head(rs: list[list[str]]) -> tuple[deck.Card, dict, dict]:
    """開頭一行共用六欄 → （牌, 條件, 結果）。"""
    c = deck.card(next(r[1:] for r in rs if r[0] == "牌"))
    return c, dict(c.need), dict(x.split(":", 1) for x in c.result.split())


def parse(text: str, state: str = "") -> Tale:
    """一篇的全文（手寫檔、tales_w 的 body 同一種格式）→ 主題。"""
    rs = [line.split("｜") for line in text.splitlines() if line and not line.startswith("#")]
    c, need, res = head(rs)
    one = {r[0]: r[1] for r in rs if r[0] in ("傳聞", "守則寫在", "氣氛", "本體", "規則之物", "抽幾條", "扭法")}
    return Tale(c.name, items(need.get("規模", "")), res["感悟"], res["遺物"] == "有", one["傳聞"], one["守則寫在"], one["氣氛"],
                one["本體"], one["規則之物"], tuple(make(Rule, RULE_KEYS, r[2:], text=r[1]) for r in rs if r[0] == "守則"),
                steps(rs), int(one.get("抽幾條", 5)), {r[1]: r[2] for r in rs if r[0] == "守則另寫在"}, items(need.get("地點", "")),
                c.target, items(need["時代"]), state, one.get("扭法", ""))


TALES = {t.name: t for t in (parse(p.read_text(encoding="utf-8")) for p in sorted((CONTENT / "tales").glob("*.txt")))}   # 手寫的；檔名前的數字是順序
_WORLD: ContextVar[dict[str, Tale]] = ContextVar("tales_world", default={})


def use(mine: list[dict]) -> None:
    """每回合開頭設一次：這個世界模型寫的主題（tales_w 的列：name、state、body；同 legends.use）。"""
    _WORLD.set({r["name"]: parse(r["body"], r["state"]) for r in mine})


def theme(name: str) -> Tale | None:
    """讀主題一律用這個：先查這個世界模型寫的，再查手寫的。"""
    return _WORLD.get().get(name) or TALES.get(name)


def themes() -> list[Tale]:
    return [*TALES.values(), *_WORLD.get().values()]


def fill(text: str, names: dict[str, str]) -> str:
    for key, value in names.items():
        text = text.replace("{" + key + "}", value)
    return text
