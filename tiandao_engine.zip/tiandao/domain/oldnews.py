"""舊聞（第 8-4 批，progress/時代更替.md 125-6、第 8-4-1～3 題）：從資料算、不另存。純函式，不碰資料庫、不呼叫 AI。

- 來源（每句掛在一個地方）：過期的中、大事傳聞（大 3、中 2）、散掉的勢力（2，有人接手的帶上是誰）、重開的老招牌（2）、前朝（那一國的州城，3）、
  牽過很多結的死者（羈絆＋帳 MANY 條以上，2）、沉掉的 NPC 帳（死處，1）。每地輕重高、同重比較新的在前，取前 CAP 句。
- 走樣：事發早於這個時代開始擲一次，未來時代又早於這個時代開始 MODERN_MIN 年的再擲一次，每次 rumors.FAR_DISTORT。
  傳聞照 rumors.version；其他的年代誇大一倍或人記錯（換成同一處另一個死者）。種子＝這句的鍵＋第幾次，同一句每次一樣；
  沒走樣的就是真相（走樣次數 0）。
- 句子由 Python 寫，說書人可換成當地人的說法，人名、事情、年代不能改（第 8-4-2 題丙）。
"""
from __future__ import annotations

import random

from . import era, rumors, society
from .clock import SHICHEN_PER_YEAR as YEAR

CAP = 10                 # 每地最多幾句（125-6）
MANY = 3                 # 羈絆＋帳這麼多條以上的死者留成舊聞
MODERN_MIN = 200         # 現代最短幾年（era.GAP_YEARS）
DEAD = "FALLEN"
FELL, TAKEN, REOPEN = "覆滅", "接手", "重開"   # 同 game/factions.FELL、domain/lapse.py
OWED = {society.OWE: "{b}欠{a}的恩", society.DEBT: "{b}欠{a}的債", society.HIRED: "{a}受託要對付{b}"}
RULE = "舊聞（可以換成當地人的說法，人名、事情、年代不能改）"
DIGITS = "零一二三四五六七八九"


def ago(years: int | None) -> str:
    """年代（取整百年）。不知道多久的寫「當年」。"""
    if years is None:
        return "當年"
    if years < 100:
        return "前些年" if years < 20 else "幾十年前"
    q, r = divmod(round(years / 100), 10)
    return "約" + (f"{DIGITS[q] if q < 10 else q}千" if q else "") + (f"{DIGITS[r]}百" if r else "") + "年前"


def _item(key, place, weight, when, text, who="", rumor=None):
    return {"key": key, "place": place, "weight": weight, "when": when, "text": text, "who": who, "rumor": rumor}


def sources(rows: dict, clock_now: int) -> list[dict]:
    """全部的舊聞（還沒走樣）。text 裡的「＠年」「＠人」由 told 填。"""
    npcs = {p["name"]: p for p in rows.get("npcs", [])}
    out = [_item(f"r:{r['id']}", r["place"], 3 if r["size"] == rumors.BIG else 2, r["clock_shichen"], "", rumor=r)
           for r in rows["rumors"] if r["size"] != rumors.SMALL and r["place"] and not rumors.still_told(r, clock_now)]
    fs = [(f, f.get("traits") or {}) for f in rows.get("factions", [])]   # 接手、重開（第 8-2 丙，domain/lapse.py）
    out += [_item(f"f:{f['name']}", f["location"], 2, t[FELL], f"＠年，這裡有個{f['name']}，後來散了"
                  + (f"，地盤歸了{t[TAKEN]}" if t.get(TAKEN) else ""), f["name"]) for f, t in fs if isinstance(t.get(FELL), int)]
    out += [_item(f"o:{f['name']}", f["location"], 2, t[REOPEN], f"{f['name']}散過一回，＠年又有人重開了這塊老招牌", f["name"])
            for f, t in fs if isinstance(t.get(REOPEN), int) and not t.get(FELL)]
    capitals = {}
    for s in (rows.get("atlas") or {}).get("states", []):
        capitals.setdefault(s["nation"], []).append(s["capital"])
    for n, d in ((rows.get("atlas") or {}).get("dynasty") or {}).items():
        out += [_item(f"d:{n}:{name}", c, 3, i, f"這一帶從前是{name}朝的天下") for i, name in enumerate(d["past"]) for c in capitals.get(n, ())]
    ties = {}
    for x in rows.get("bonds", []) + [l for l in rows.get("ledger", []) if not l["session_id"]]:
        for k in ("a", "b"):
            ties[x[k]] = ties.get(x[k], 0) + 1
    out += [_item(f"p:{p['name']}", p["location"], 2, p.get("evolved_shichen"), f"聽說＠人＠年死在這裡", p["name"])
            for p in npcs.values() if p["status"] == DEAD and ties.get(p["name"], 0) >= MANY]
    for l in rows.get("ledger", []):
        gone = (l.get("body") or {}).get("沉")
        if gone and l["kind"] in OWED and gone in npcs:
            out.append(_item(f"l:{l['id']}", npcs[gone]["location"], 1, l["clock_shichen"],
                             "＠年，" + OWED[l["kind"]].format(a=l["a"], b=l["b"]) + "，後來就沒人提了"))
    return out


def told(item: dict, rows: dict, card: dict, clock_now: int, seed: str) -> str:
    """這句在這個時代傳成什麼樣子（同一句、同一個時代每次一樣）。"""
    when, since = item["when"], card["since"]
    times = 0 if when is None or card["era"] == era.ANCIENT else (when < since) + (card["era"] == era.FUTURE and when < since - MODERN_MIN * YEAR)
    years = None if when is None or item["key"].startswith("d:") else (clock_now - when) // YEAR
    who, v = item["who"], item["rumor"]
    for i in range(times):
        rng = random.Random(f"{seed}:old:{item['key']}:{i}")
        if v:
            v = rumors.version(v, None, rng)
        elif rng.random() < rumors.FAR_DISTORT:
            others = [p["name"] for p in rows["npcs"] if p["status"] == DEAD and p["location"] == item["place"] and p["name"] != who]
            if who and others and rng.random() < 0.5:
                who = rng.choice(sorted(others))
            elif years is not None:
                years *= 2
    text = f"＠年，{rumors.text(v)}" if v else item["text"]
    return text.replace("＠年", ago(years)).replace("＠人", who)


def here(rows: dict, place: str, clock_now: int) -> list[dict]:
    """這一處的舊聞：輕重高、同重比較新的在前，取前 CAP 句。"""
    mine = [x for x in sources(rows, clock_now) if x["place"] == place]
    return sorted(mine, key=lambda x: (-x["weight"], -(x["when"] or 0)))[:CAP]
