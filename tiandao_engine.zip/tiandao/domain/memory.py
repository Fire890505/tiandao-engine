"""長期記憶的純規則（第 17 步）。純函式，不碰資料庫。

規則（2026-10-04 與使用者討論定案，見 progress/WHITEPAPER.md 第 10 節）：
- 三層：狀態（Python 既有欄位）／記事（綁在人、地、主角身上，標出處）／線頭（承諾與懸念，有未了已了狀態）。
- 記事種類：Python 自動記（初遇、動手、關係轉折、生死、主角大事、失約、落空）；AI 提案的見聞只有說／做／見。
- 線頭：AI 提案開線與結線；綁定的 NPC 死了自動落空；10 年無進展擱置（再接觸時重新列出）；
  承諾有期限，「我的承諾」逾期＝失約（扣關係由 domain/npc 處理），「他人的承諾」逾期只標落空。
- 淡忘：記得多久＝記得的人的壽元 ÷ 10；過期的見聞與初遇變成「依稀記得」；生死、動手、失約、落空、關係轉折不淡忘。
- 聯絡簿：各段先拿保底，剩下的位置依重要度補到各段天花板，總額度 BUDGET 條。
"""
from __future__ import annotations

from dataclasses import dataclass, field

from . import npc
from .clock import SHICHEN_PER_DAY, SHICHEN_PER_YEAR

# ── 記事 ─────────────────────────────────────────────────────────────────
MEET, ATTACK, TURN, DEATH, MILESTONE, BROKEN, FAILED = "初遇", "動手", "關係轉折", "生死", "主角大事", "失約", "落空"
SAID, DID, SAW = "說", "做", "見"
NEWS, HEARD = "近況", "打聽"                       # 第 10b 步：NPC 不在場時的變化、主角打聽到的消息
RUMOR = "傳聞"                                     # 第 10c-3a 步：主角聽到的傳聞（記聽到的版本，可能走樣）
DEED = "舊事"                                      # 16v 第 93 題：路線結局留在地點上的事實，不屬於任何一生
PYTHON_KINDS = (MEET, ATTACK, TURN, DEATH, MILESTONE, BROKEN, FAILED, NEWS, HEARD, RUMOR, DEED)
NARRATOR_KINDS = (SAID, DID, SAW)
MEMORY_KINDS = PYTHON_KINDS + NARRATOR_KINDS
NPC, PLACE, SELF = "npc", "place", "self"          # 記事綁在誰身上
SUBJECT_KINDS = (NPC, PLACE, SELF)
PYTHON, NARRATOR = "python", "narrator"            # 出處
IMPORTANCE = {DEATH: 3, BROKEN: 3, FAILED: 3, ATTACK: 3, DEED: 3, TURN: 2, MILESTONE: 2, NEWS: 2,
              SAID: 1, DID: 1, SAW: 1, HEARD: 1, RUMOR: 1, MEET: 0}
THREAD_LINKED = 2                                  # 與未了線頭有關的記事，重要度至少這麼高
FADING_KINDS = {SAID, DID, SAW, MEET, HEARD, RUMOR}   # 會淡忘的種類
FADE_DIVISOR = 10                                  # 記得多久＝壽元 ÷ 10
MEMORY_TEXT_LEN = (4, 40)
FAINT = "（依稀記得）"

# ── 線頭 ─────────────────────────────────────────────────────────────────
MY_PROMISE, THEIR_PROMISE, MYSTERY = "我的承諾", "他人的承諾", "懸念"
THREAD_KINDS = (MY_PROMISE, THEIR_PROMISE, MYSTERY)
PROMISES = (MY_PROMISE, THEIR_PROMISE)
OPEN, RESOLVED, FAILED_STATUS, SHELVED, BROKEN_STATUS = "未了", "已了", "落空", "擱置", "失約"
THREAD_STATUSES = (OPEN, RESOLVED, FAILED_STATUS, SHELVED, BROKEN_STATUS)
ACTIVE = (OPEN, SHELVED)                            # 還沒結束的
DEADLINES = {"數日": 7 * SHICHEN_PER_DAY, "一月": 30 * SHICHEN_PER_DAY, "一年": 360 * SHICHEN_PER_DAY, "無期限": None}
CLOSE_RESULTS = {"兌現": RESOLVED, "解開": RESOLVED, "落空": FAILED_STATUS}
SHELVE_YEARS = 10
THREAD_TEXT_LEN = (4, 40)
MAX_ACTIVE_THREADS = 30                            # 同時未了的線頭上限（防止無限累積）
MAIN = "主線"                                      # 線頭的來源（origin）：路線開的放主線區，其他都是支線
MAX_SIDE = 3                                       # 手上的支線上限，承諾和懸念也算（16v 第 67、78 題）

# ── 聯絡簿 ───────────────────────────────────────────────────────────────
BUDGET = 25
PERSON = (2, 6)          # 每位在場人物的記事（保底, 天花板）
PAST_LIFE = (1, 1)       # 每位在場人物的前世往事
PLACE_NOTES = (2, 5)
THREADS = (3, 8)
SELF_NOTES = (2, 4)
PAST_LIFE_MIN_IMPORTANCE = 3


# ── 記事規則 ─────────────────────────────────────────────────────────────
def fade_shichen(lifespan_years: int | None) -> int | None:
    """記得多久（時辰）；不受壽元限制的人永遠記得。"""
    return None if lifespan_years is None else lifespan_years * SHICHEN_PER_YEAR // FADE_DIVISOR


def faded(note: dict, clock_now: int, lifespan_years: int | None) -> bool:
    if note["kind"] not in FADING_KINDS:
        return False
    span = fade_shichen(lifespan_years)
    return span is not None and clock_now - note["clock_shichen"] > span


def importance(note: dict, linked_subjects: set[str] = frozenset()) -> int:
    """重要度；綁定對象身上有未了線頭的記事，至少是 THREAD_LINKED。"""
    base = IMPORTANCE[note["kind"]]
    if note["subject"] in linked_subjects:
        base = max(base, THREAD_LINKED)
    return base


def relation_texts(protagonist: str, before: dict, after: dict) -> list[tuple[str, str]]:
    """關係轉折的記事（以 NPC 的角度）：態度、信任跨過分級，或剛記上仇。
    回傳 [(文字, 轉折後的態度)]；態度只有「態度」那一條才填，給背景演化判斷用（不必解析文字）。"""
    texts = []
    a0, a1 = npc.tier(before["affinity"], npc.AFFINITY_TIERS), npc.tier(after["affinity"], npc.AFFINITY_TIERS)
    if a0 != a1:
        texts.append((f"對{protagonist}的態度由{a0}轉為{a1}", a1))
    t0, t1 = npc.tier(before["trust"], npc.TRUST_TIERS), npc.tier(after["trust"], npc.TRUST_TIERS)
    if t0 != t1:
        texts.append((f"對{protagonist}的信任由{t0}轉為{t1}", ""))
    if after["grudge"] and not before["grudge"]:
        texts.append((f"記恨{protagonist}（{after['grudge']}）", ""))
    return texts


def note(subject_kind: str, subject: str, kind: str, text: str, *, clock_now: int, turn_no: int,
         source: str = PYTHON, thread_id: str | None = None, actor: str = "", attitude: str = "",
         rumor_id: str | None = None) -> dict:
    """actor：誰下的手（死於主角之手時填主角名字）；attitude：關係轉折後的態度；rumor_id：聽到的是哪一則傳聞。
    都是給程式判斷用的欄位。"""
    return {"subject_kind": subject_kind, "subject": subject, "kind": kind, "text": text[:MEMORY_TEXT_LEN[1] + 20],
            "source": source, "clock_shichen": clock_now, "turn_no": turn_no, "thread_id": thread_id,
            "actor": actor, "attitude": attitude, "rumor_id": rumor_id}


# ── 線頭規則 ─────────────────────────────────────────────────────────────
def sides(threads) -> list[dict]:
    """手上的支線。擱置的不算，不然十年前的懸念會佔著位子。"""
    return [t for t in threads if t["status"] == OPEN and t.get("origin") != MAIN]


@dataclass
class ThreadUpkeep:
    """一回合的線頭維護結果。changes：thread_id → 要改的欄位。"""
    changes: dict[str, dict] = field(default_factory=dict)
    broken: list[dict] = field(default_factory=list)     # 失約（我的承諾逾期）：要扣該 NPC 的關係
    failed: list[dict] = field(default_factory=list)     # 落空（他人逾期、NPC 死亡、主角死亡）
    events: list[str] = field(default_factory=list)


def upkeep(threads: list[dict], *, clock_now: int, session_id: str, here: str, present: set[str],
           dead: set[str], protagonist_fallen: bool) -> ThreadUpkeep:
    """依時間與生死整理線頭。threads 只含這一生看得到的（這一生的承諾＋世界的懸念）。

    順序：主角死亡 → NPC 死亡 → 逾期 → 再接觸（擱置的重新列出、未了的刷新最後接觸時間）→ 久無進展擱置。
    """
    result = ThreadUpkeep()
    for t in threads:
        if t["status"] not in ACTIVE:
            continue
        mine = t["session_id"] == session_id
        if t["kind"] in PROMISES and mine and protagonist_fallen:
            _close(result, t, FAILED_STATUS, clock_now, "主角殞落，未及兌現")
            result.failed.append(t)
        elif t["subject_kind"] == NPC and t["subject"] in dead:
            _close(result, t, FAILED_STATUS, clock_now, f"{t['subject']}已死")
            result.failed.append(t)
            result.events.append(f"線頭落空：{t['text']}（{t['subject']}已死）")
        elif t["kind"] in PROMISES and t["deadline_shichen"] is not None and clock_now > t["deadline_shichen"]:
            if t["kind"] == MY_PROMISE:
                _close(result, t, BROKEN_STATUS, clock_now, "逾期未兌現")
                result.broken.append(t)
                result.events.append(f"失約：{t['text']}（期限已過）")
            else:
                _close(result, t, FAILED_STATUS, clock_now, "對方逾期未兌現")
                result.failed.append(t)
                result.events.append(f"落空：{t['text']}（對方逾期）")
        elif t["subject"] in present or t["subject"] == here:
            result.changes[t["id"]] = {"status": OPEN, "touched_shichen": clock_now}
        elif t["status"] == OPEN and clock_now - t["touched_shichen"] > SHELVE_YEARS * SHICHEN_PER_YEAR:
            result.changes[t["id"]] = {"status": SHELVED}
    return result


def _close(result: ThreadUpkeep, t: dict, status: str, clock_now: int, note_text: str) -> None:
    result.changes[t["id"]] = {"status": status, "closed_shichen": clock_now, "result_note": note_text}


def remaining_text(t: dict, clock_now: int) -> str:
    if t["deadline_shichen"] is None:
        return ""
    left = max(0, t["deadline_shichen"] - clock_now)
    days = left // SHICHEN_PER_DAY
    if days >= 360:
        return f"剩約 {days // 360} 年"
    return f"剩 {days} 天" if days else f"剩 {left} 時辰"


# ── 聯絡簿挑選 ───────────────────────────────────────────────────────────
@dataclass
class Section:
    """聯絡簿的一段。items 已依「重要度、時間」由高到低排好；每個 item 是 (重要度, 時間, 內容)。"""
    key: str
    items: list[tuple[int, int, object]]
    floor: int
    ceiling: int


def assemble(sections: list[Section], budget: int = BUDGET) -> dict[str, list]:
    """保底＋共用：先給每段保底，剩下的位置依重要度（同級越近越前）補到各段天花板，總數不超過 budget。"""
    chosen: dict[str, list] = {s.key: [] for s in sections}
    used = 0
    for s in sections:
        take = s.items[:min(s.floor, len(s.items), max(0, budget - used))]
        chosen[s.key] = list(take)
        used += len(take)
    pool = sorted(((item, s) for s in sections for item in s.items[len(chosen[s.key]):]),
                  key=lambda pair: (pair[0][0], pair[0][1]), reverse=True)
    for item, s in pool:
        if used >= budget:
            break
        if len(chosen[s.key]) < s.ceiling:
            chosen[s.key].append(item)
            used += 1
    # 每段內維持原本的排序（重要度、時間）
    order = {s.key: {id(item): i for i, item in enumerate(s.items)} for s in sections}
    return {key: [x[2] for x in sorted(items, key=lambda it: order[key][id(it)])] for key, items in chosen.items()}


def ranked(notes: list[dict], *, clock_now: int, lifespan_years: int | None,
           linked_subjects: set[str] = frozenset()) -> list[tuple[int, int, dict]]:
    """把記事排成聯絡簿用的 (重要度, 時間, 記事)；淡忘的降到最後並標上 faint。"""
    out = []
    for n in notes:
        faint = faded(n, clock_now, lifespan_years)
        out.append((-1 if faint else importance(n, linked_subjects), n["clock_shichen"], {**n, "faint": faint}))
    return sorted(out, key=lambda x: (x[0], x[1]), reverse=True)


def thread_rank(t: dict, related: set[str]) -> tuple[int, int, dict]:
    """線頭在聯絡簿的排序：與在場的人或所在地有關的優先，其次期限越近越前（無期限最後）。"""
    deadline = t["deadline_shichen"]
    return (1 if t["subject"] in related else 0, -deadline if deadline is not None else -(10 ** 12), t)


def visible(threads: list[dict], session_id: str) -> list[dict]:
    """這一生看得到的線頭：自己的承諾＋世界裡所有的懸念（懸念跨世保留）。"""
    return [t for t in threads if t["kind"] == MYSTERY or t["session_id"] == session_id]
