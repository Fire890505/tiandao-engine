"""前期領域（第 19-1 步）：出現、守則、犯規、情境、破解。純函式，不碰資料庫、不呼叫 AI。

規則（2026-10-06 與使用者一題一題定案，見 progress/WHITEPAPER.md 第 16d 節，數字暫定）：
- 地圖上已知的地點被籠罩成領域；世界脈動每月 3%、同一個地方只有一個（籠罩的區域＝地點與它底下的子地點，
  2026-10-06 使用者改：原本同一時間只有一個）、不挑主角所在的地方；先傳出傳聞。
- 規模（第 10 題）＝被籠罩地點的規模（家、村落、鄉鎮、城市），決定出現多寡、強弱、遺物、感悟、傳聞大小。
- 進去就拿到守則（藏著假規則）；犯真規則、照假規則做都吃虧；第 3 次犯規本體現身追人（離開要脫身）。
- 破解＝照主題的步驟弄清來由、找到關鍵、了結；逃出什麼都沒有，進度與犯規次數留在這一生。
- 儀式型（鄉野奇談，2026-10-07）：有動機的 NPC 照流傳的玩法做了儀式才籠罩他所在的地方，他就是被困的人；
  三個月沒人收尾他就死在那裡（不變亡者，領域照舊）；流傳的玩法有錯，破解第一步揭穿、照正確的收尾。
- 16l 第 6-4～6-6 題：出現不看任何人的境界；領域裡雙方不算境界差、本體改用難度（困難）表現；技能（法則加成）加倍，
  跟怪談同系的歸零；境界比本體高一級以上可以硬解（打散＝散去，不算破解；代價在 game/zones.py）。
主題的內容在 domain/tales.py。
"""
from __future__ import annotations

from . import era, space
from . import judgment as J
from . import status as status_mod
from . import undead as undead_mod
from .clock import SHICHEN_NAMES, SHICHEN_PER_DAY, SHICHEN_PER_MONTH
from .effects import WOUND_START
from .tales import (BRAVE, CITY, DAY, FORTUNE, GHOST_TALE, GUARD, HOME, HURT1, HURT2, LIE, MIDNIGHT, MOURNER, NIGHT,
                    SCALES, TOWN, VILLAGE, Rule, Tale, fill, theme, themes)

ACTIVE, CLEARED, LIFTED = "籠罩", "破解", "散去"   # 散去：亡者執念型的幽魂被強行打散，籠罩跟著散（不算破解）
MONTHLY = 0.03                 # 世界脈動每個月出現領域的機率
SCENE_CHANCE = 0.4             # 在領域裡，每回合上演一條情境型規則的機率
STRIKES_FOR_BOSS = 3
# 規模（第 10 題，DOMAIN_TALES 第 0 節）：出現權重、規則之物戰力（本體再 +1；也當傳聞的 lv 決定大小）、
# 遺物品階、破解的感悟
WEIGHT = {HOME: 3, VILLAGE: 2, TOWN: 1, CITY: 1}
POWER = {HOME: 0, VILLAGE: 1, TOWN: 3, CITY: 4}
RELIC_TIER = {HOME: 0, VILLAGE: 1, TOWN: 2, CITY: 2}
INSIGHT = {HOME: 10, VILLAGE: 15, TOWN: 20, CITY: 25}
OLD_SCALE = {"打烊後的客棧": HOME}   # 補上規模之前（v19）的領域：客棧當家級（舊守則都合家級），其他都是村落級
HURTS = {HURT1: 0.1, HURT2: 0.2}
BOSS_HURT = 0.2
MARK, MARK_MAGNITUDE = "被盯上", 40   # 中度：直到離開領域
THREAD_HEAD = "的怪談："
NIGHT_NAMES = "酉戌亥子丑寅"
RITUAL_DEADLINE = 3 * SHICHEN_PER_MONTH   # 儀式型：做儀式的人撐多久（從領域出現算起）
BRAVE_AT = 80                              # 膽識這麼高才敢做
# NPC 陷在怪談裡（Claude主導第 14 題，第九節 4d；數字暫定）
CAUGHT = (("逃過", 5), ("受傷", 3), ("死", 1), ("帶走", 1))       # 在場的人違反真守則、照做假守則：擲一次
TOLL, TOLL_BOOST = 0.01, 1.5                                       # 畫面外：籠罩區裡的人每月出事的機率；膽大、疑心重（不信邪）、不識字各乘
TOLL_WAYS = (("受傷", 4), ("失蹤", 2), ("死", 1), ("搬走", 3))


def toll_odds(p: dict, lore: int) -> float:
    """畫面外每月出事的機率。lore：學識等級（learn.level；不識字＝0）。"""
    boost = (p.get("courage", 50) >= BRAVE_AT) + (p.get("suspicion", 50) >= BRAVE_AT) + (lore == 0)
    return TOLL * TOLL_BOOST ** boost
MOURNING = ("師父", "徒弟", "親人", "恩人", "友人", "戀人", "伴侶")
BOSS_DIFFICULTY = "困難"                   # 16l 第 6-5 題：本體的威脅
LAW_FACTOR = 2                             # 領域裡技能加倍；跟怪談同系的歸零
FORCE_GAP = 1                              # 硬解：境界比本體高幾級（注視見 heaven.FORCE）
FORCE_WORDS = ("打散", "強拆", "強行破", "硬破", "震碎", "破開")


# ── 出現 ───────────────────────────────────────────────────────────────────
def appears(rng, months: int) -> bool:
    """跨過 months 個月，這段期間有沒有出現領域（一次擲完）。"""
    return months > 0 and rng.random() < 1 - (1 - MONTHLY) ** months


def mourners(bonds: list[dict], dead: set[str]) -> set[str]:
    """與已經死去的人有親近羈絆（師徒、親人、恩人、友人、戀人、伴侶）的人：觀落陰想再見他一面。"""
    return {x for b in bonds if b["type"] in MOURNING for x, y in ((b["a"], b["b"]), (b["b"], b["a"])) if y in dead}


def doer(tale: Tale, p: dict, mourners: set[str]) -> bool:
    """儀式型：這個人會不會照流傳的玩法去做。mourners：與已經死去的人有羈絆的人。"""
    return {BRAVE: p["courage"] >= BRAVE_AT, FORTUNE: p["goal"] in ("逐利", "求名"), MOURNER: p["name"] in mourners,
            GUARD: p["goal"] == "守護"}.get(tale.doer, False)


def spawn(rng, *, locations: list[dict], neighbors: dict[str, list[str]], npcs: list[dict], undead: list[dict],
          blocked: set[str], clock_now: int, mourners: set[str] = frozenset()) -> dict | None:
    """挑一個地點籠罩：有路相連（{鄰地}）、不在 blocked 裡（主角所在的地方、已經被籠罩的地方，見 overlaps）。
    規模＝地點的規模，要是主題可能的規模（16l：不看任何人的境界）；規模越大越少見（WEIGHT）。有幽魂的地點用亡者執念型。
    儀式型要那裡、或住在它上一層（建築所在的村子、鎮上）有會去做的人（doer），被困的人就是他。"""
    picks = options(locations=locations, neighbors=neighbors, npcs=npcs, undead=undead,
                    blocked=blocked, mourners=mourners)
    if not picks:
        return None
    pick = rng.choices(picks, weights=[WEIGHT[s] for _, s, _ in picks])[0]
    return make(rng, pick, locations=locations, neighbors=neighbors, npcs=npcs, undead=undead, clock_now=clock_now,
                mourners=mourners)


def _ghosts(undead: list[dict]) -> dict[str, dict]:
    return {u["place"]: u for u in undead if u["form"] == undead_mod.GHOST and u["condition"] != undead_mod.GONE}


def _trapped(tale: Tale, place: str, locations: list[dict], npcs: list[dict], mourners: set[str]) -> list[str]:
    up = next((l.get("parent", "") for l in locations if l["name"] == place), "")
    return sorted(p["name"] for p in npcs if p["status"] == "ALIVE"
                  and (p["location"] == place or tale.doer and up and p["location"] == up)
                  and (not tale.doer or doer(tale, p, mourners)))


def options(*, locations: list[dict], neighbors: dict[str, list[str]], npcs: list[dict], undead: list[dict],
            blocked: set[str], mourners: set[str] = frozenset(),
            card: dict = era.DEFAULT, states: dict[str, str] | None = None) -> list[tuple[str, str, Tale]]:
    """可以出現的（地點, 規模, 主題）；權重是 WEIGHT[規模]（都市傳說另外加進來一起抽，見 game/zones.spawn）。
    地點類型與時代要對得上（era.fits：古蹟算廢墟，不屬於這個時代的主題只在古蹟、廢墟、村落）。
    states：地點 → 州；模型寫的只在它那一州（第 128 系列乙第二批）。"""
    ghosts, states = _ghosts(undead), states or {}
    return [(l["name"], l["scale"], t) for l in locations if l["name"] not in blocked and neighbors.get(l["name"])
            and l["scale"] in SCALES
            for t in themes() if (t.name == GHOST_TALE) == (l["name"] in ghosts) and l["scale"] in t.scales
            and (not t.state or states.get(l["name"]) == t.state)
            and era.fits(l["type"], t.places, t.eras, card)
            and (not t.doer or _trapped(t, l["name"], locations, npcs, mourners))]


def make(rng, pick: tuple[str, str, Tale], *, locations: list[dict], neighbors: dict[str, list[str]], npcs: list[dict],
         undead: list[dict], clock_now: int, mourners: set[str] = frozenset()) -> dict:
    place, scale, tale = pick
    ghost = _ghosts(undead).get(place)
    people = _trapped(tale, place, locations, npcs, mourners)
    return {"tale": tale.name, "scale": scale, "place": place, "neighbor": rng.choice(neighbors[place]),
            "person": rng.choice(people) if people else "", "ghost": ghost["name"] if ghost else "",
            "rules": draw(rng, tale, ghost["grudge"] if ghost else "", scale), "life": "", "step": 0, "strikes": 0,
            "staged": [], "chased": False, "status": ACTIVE, "created_shichen": clock_now, "solved_shichen": None}


def covers(parents: dict[str, str], place: str, spot: str) -> bool:
    """籠罩 place 的領域蓋不蓋得到 spot：領域籠罩的區域（地點與它底下的子地點）算同一個地方（2026-10-06 使用者）。"""
    return place in space.breadcrumb(parents, spot)


def overlaps(parents: dict[str, str], a: str, b: str) -> bool:
    """兩個地點算不算同一個地方（一個在另一個底下，或就是同一個）：同一個地方只能有一個領域。"""
    return covers(parents, a, b) or covers(parents, b, a)


def pool(tale: Tale, kind: str, scale: str) -> list[int]:
    """這個規模（亡者執念型還看執念種類）用得到的守則。"""
    return [i for i, r in enumerate(tale.rules) if r.kind in ("", kind) and (not r.scales or scale in r.scales)]


def draw(rng, tale: Tale, kind: str = "", scale: str = VILLAGE) -> list[int]:
    """抽守則：一定有一條假規則（儀式型是一定抽到的流傳收尾方式），其他隨機
    （只用這個規模的；亡者執念型只用合這種執念的）。"""
    pool_ = pool(tale, kind, scale)
    must = [i for i in pool_ if tale.rules[i].always] or [rng.choice([i for i in pool_ if tale.rules[i].fake])]
    return sorted([*must, *rng.sample([i for i in pool_ if i not in must], tale.draw - len(must))])


def rumor_text(d: dict) -> str:
    return theme(d["tale"]).rumor


def deadline(d: dict) -> int | None:
    """儀式型：做儀式的人撐到什麼時候。"""
    return d["created_shichen"] + RITUAL_DEADLINE if theme(d["tale"]).doer and d["person"] else None


# ── 名字與時段 ─────────────────────────────────────────────────────────────
def names(d: dict, ghost: dict | None) -> dict[str, str]:
    """{此地}{鄰地}{人}{亡者}{仇人} 換成什麼。沒有被困的人時寫成「村裡的人」。"""
    return {"此地": d["place"], "鄰地": d["neighbor"], "人": d["person"] or "這裡的人",
            "亡者": d["ghost"], "仇人": ghost["grudge_on"] if ghost else ""}


def period(clock_now: int) -> set[str]:
    name = SHICHEN_NAMES[clock_now % SHICHEN_PER_DAY]
    return {NIGHT, MIDNIGHT} if name == "子" else {NIGHT} if name in NIGHT_NAMES else {DAY}


def matches(c, *, when: set[str] | None, nature: str, text: str, names: dict) -> bool:
    words = [fill(w, names) for w in c.words]
    return ((when is None or not c.when or c.when in when) and (not c.natures or nature in c.natures)
            and (not words or any(w and w in text for w in words)))


def broken_bans(d: dict, *, when: set[str], nature: str, text: str, names: dict) -> list[int]:
    """這回合犯了哪幾條禁令（沒有情境、有後果、有條件的規則）。"""
    tale = theme(d["tale"])
    return [i for i in d["rules"] if not tale.rules[i].scene and tale.rules[i].cost
            and (tale.rules[i].natures or tale.rules[i].words)
            and matches(tale.rules[i], when=when, nature=nature, text=text, names=names)]


def broke_scene(rule: Rule, *, nature: str, text: str, names: dict) -> bool:
    """上回合上演的情境，玩家這回合怎麼應對：做了不該做的行動、或寫了不該寫的字（兩者有一就算），或該寫的一個都沒寫。"""
    words = [fill(w, names) for w in rule.words]
    return (nature in rule.natures or any(w and w in text for w in words)
            or bool(rule.good) and not any(w in text for w in rule.good))


def scene_rules(d: dict) -> list[int]:
    """還沒上演過的情境型規則。"""
    tale = theme(d["tale"])
    return [i for i in d["rules"] if tale.rules[i].scene and i not in d["staged"]]


def step_done(d: dict, *, at: str, when: set[str], nature: str, text: str, target: str, success: bool,
              alone: bool = False) -> bool:
    """這回合完成了目前這一步沒。at：主角在此地還是鄰地；success：判定成功（不擲骰的行動算成功）。
    alone：被困的人已經死了——要對他的路斷了，只有最後一步（要他親自收尾的）改成主角自己來。"""
    steps = theme(d["tale"]).steps
    if d["step"] >= len(steps):
        return False
    last = d["step"] == len(steps) - 1
    return any(w.place == at and (not w.success or success)
               and (not w.person or (last if alone else bool(d["person"]) and target == d["person"]))
               and matches(w, when=when, nature=nature, text=text, names={}) for w in steps[d["step"]].ways)


# ── 後果 ───────────────────────────────────────────────────────────────────
def hurt(sheet: dict, ratio: float, lethal: bool = False) -> tuple[dict, list[dict], list[str]]:
    """扣氣血上限的比例。一般的後果最多扣到剩 1；本體（lethal）可以打到瀕死。已經瀕死就不再扣。"""
    if sheet["status"] != "ALIVE":
        return sheet, [], []
    hp = sheet["hp"] - round(sheet["hp_max"] * ratio)
    if hp > 0 or not lethal:
        after = {**sheet, "hp": max(1, hp)}
        return after, [{"field": "hp", "from": sheet["hp"], "to": after["hp"]}], []
    return ({**sheet, "hp": 0, "status": "DYING", "wound": WOUND_START}, [{"field": "hp", "from": sheet["hp"], "to": 0}],
            [f"氣血耗盡，陷入瀕死（傷勢 {WOUND_START}/100）"])


def marked(sheet: dict, on: bool) -> dict:
    """被盯上（中度、直到離開領域）：on＝加上，否則拿掉。"""
    kept = [s for s in sheet["statuses"] if s["name"] != MARK]
    return {**sheet, "statuses": kept + ([status_mod.make(MARK, status_mod.NEGATIVE, MARK_MAGNITUDE)] if on else [])}


def power(d: dict, boss: bool = False) -> int:
    return POWER[d["scale"]] + (1 if boss else 0)


def forced(d: dict, realm_lv: int, verdict, text: str) -> bool:
    """硬解（16l 第 6-6 題）：境界比本體高 FORCE_GAP 級以上，說打散、強拆……而且命中成功。"""
    return (realm_lv >= power(d, boss=True) + FORCE_GAP and verdict.action_type == J.COMBAT
            and any(w in text for w in FORCE_WORDS)
            and any(c.target == J.STRIKE and c.outcome in (J.SUCCESS, J.GREAT_SUCCESS) for c in verdict.all_checks))


# ── 給說書人與畫面 ─────────────────────────────────────────────────────────
def lore(d: dict, names: dict) -> list[str]:
    """已經揭露的來由（完成的步驟）。"""
    return [fill(s.reveal, names) for s in theme(d["tale"]).steps[:d["step"]]]


def rules_text(d: dict, names: dict) -> list[str]:
    """守則。破解第一步之後，錯的規則揭穿：標「流傳有誤」並寫上正確做法；沒有正確做法的（LIE）標「這條是假的」。"""
    rules = [theme(d["tale"]).rules[i] for i in d["rules"]]
    return [fill(r.text, names) if not r.truth or d["step"] < 1
            else f"{LIE}{fill(r.text, names)}" if r.truth == LIE
            else f"（流傳有誤）{fill(r.text, names)}正確：{fill(r.truth, names)}。" for r in rules]


UNREAD = "你不識字，看不懂上面寫什麼，要找識字的人念給你聽"   # 第 7-1c 批


def prompt(d: dict, names: dict, doer_dead: bool = False, reader: str | None = "") -> str:
    """【領域】：氣氛、守則（沒揭穿的不標真假）、已經揭露的來由、做儀式的人、本體在不在追。真相在揭露之前不給。
    reader：誰念守則（第 7-1c 批）：空＝主角自己看得懂；名字＝他念給主角聽；None＝沒人念，守則不給。"""
    tale = theme(d["tale"])
    known = "；".join(lore(d, names))
    doer = (f"　{d['person']}照著流傳的玩法做了儀式才引出這一切，"
            + ("已經死在這裡" if doer_dead else "人還困在這裡，撐不了多久")) if tale.doer and d["person"] else ""
    return (f"{d['place']}被怪談籠罩（{tale.mood}），這裡的人都被規則困住了。{tale.notice_at(d['scale'])}寫著："
            + ("主角不識字，看不懂上面寫什麼（不要替主角念出守則）" if reader is None else (f"（主角不識字，由{reader}念給主角聽）" if reader else "")
               + " ".join(f"{n}. {r}" for n, r in enumerate(rules_text(d, names), 1))
               + "（沒標出的守則有真有假，不要點破哪一條是假的，也不要替主角說出來由）")
            + doer + (f"　已經查明：{known}" if known else "")
            + (f"　{fill(tale.boss, names)}正追著主角" if d["chased"] else ""))


def thread_text(place: str, hint: str) -> str:
    return f"{place}{THREAD_HEAD}{hint}"[:40]


def rescue_text(d: dict) -> str:
    """儀式型：救出做儀式的人的線頭（綁在他身上：他死了就落空）。"""
    return f"救出被困在{d['place']}的{d['person']}"[:40]


def valid(d: dict, places: set[str], npc_names: set[str]) -> bool:
    """存檔檢查。"""
    tale = theme(d["tale"]) if isinstance(d["tale"], str) else None
    rules = d["rules"]
    return (tale is not None and d["scale"] in tale.scales and d["place"] in places and d["neighbor"] in places
            and d["neighbor"] != d["place"] and isinstance(rules, list) and len(rules) == len(set(rules)) and 1 <= len(rules) <= tale.draw + 1   # 暗線多一條假規則、揭穿少一條
            and all(_index(i, tale) and (not tale.rules[i].scales or d["scale"] in tale.rules[i].scales)
                    for i in rules)   # 守則要合這個規模
            and d["person"] in ("", *npc_names) and isinstance(d["ghost"], str) and len(d["ghost"]) <= 12
            and (d["ghost"] != "") == (tale.name == GHOST_TALE)   # 只有亡者執念型借幽魂
            and isinstance(d["staged"], list)
            and all(i in rules for i in d["staged"]) and _index(d["step"], tale, len(tale.steps) + 1)
            and isinstance(d["strikes"], int) and not isinstance(d["strikes"], bool) and 0 <= d["strikes"] <= 99
            and isinstance(d["chased"], bool) and d["status"] in (ACTIVE, CLEARED, LIFTED))


def _index(i, tale: Tale, size: int | None = None) -> bool:
    return isinstance(i, int) and not isinstance(i, bool) and 0 <= i < (len(tale.rules) if size is None else size)
