"""世界痕跡（第 11-1 步）：一生的結局、退隱的舊主角、遺物、傳說。純函式，不碰資料庫、不呼叫 AI。

規則（2026-10-06 與使用者一題一題定案，見 progress/WHITEPAPER.md 第 3 節「第 11 步」，數字暫定）：
- 結局：殞落、坐化、退隱。從角色卡就看得出來（活著結束＝退隱；壽元耗盡＝坐化），不另存。
- 退隱的舊主角變成一般 NPC（目標隱居），照背景演化過活；他的關係轉成羈絆，身上的物品記在他名下。
- 遺物記在某個地點或某個 NPC 名下。死於具名 NPC 之手，他拿走最好的一件（法器優先），其餘留在死處。
  留在地上的每十年一半機會被人撿走：建立時就擲好能留多久（lasts），落地時記下時間（placed_shichen）。
- 傳說由欄位組出：名字、境界、結局與地點、這一生最大的兩件事；百年之後只剩名字與結局。
- 16l 第 6-1 題：一生沒越過 Lv0 的，傳說寫「以凡人之軀終老／殞落／退隱」。
"""
from __future__ import annotations

import math

from . import ascent, breach, character, items, npc, origins, realm, rumors
from .clock import SHICHEN_PER_YEAR

FELL, AGED, RETIRED = "殞落", "坐化", "退隱"
ERASED = breach.ERASED                 # 被天道抹殺（16l）
ASCENDED = ascent.ENDING               # 飛升（16l）
MORTAL, MORTAL_AGED = "以凡人之軀", "終老"   # 一生沒越過 Lv0（16l 第 6-1 題）
RETIRED_BY = "retired"                 # 前世的主角登錄成 NPC 時的 created_by（退隱；第 6-6a 批起死了的也是）
FRIEND_AT, FOE_AT = 50, -50            # 前世傳說的友人、仇家：好感 50 以上；−50 以下或有恩怨
RELIC_DECADE = 10 * SHICHEN_PER_YEAR   # 地上的遺物每十年一半機會被人撿走
LEGEND_FADE = 100 * SHICHEN_PER_YEAR   # 百年之後傳說只剩名字與結局
WIDE_LV = 4                            # 一方強者：到處都有人提
DEEDS = 2
ASK_PLACES = ("城鎮", "客棧", "坊市")   # 在這些地方打聽得到前人的傳說


def ending(sheet: dict, clock_end: int) -> str:
    """這一生怎麼結束的（只對已結束的一生有意義）。"""
    if sheet.get("ascended"):   # 16l：破空飛升，人去了仙域
        return ASCENDED
    if sheet["status"] != "FALLEN":
        return RETIRED
    if sheet.get("erased"):   # 16l：破格期的倒數到了
        return ERASED
    left = character.remaining_life_shichen(sheet, clock_end)
    return AGED if left is not None and left <= 0 else FELL


# ── 退隱 ───────────────────────────────────────────────────────────────────
def as_npc(sheet: dict, clock_now: int, turn_no: int, dead: bool = False) -> dict:
    """舊主角登錄成 NPC（repos.insert_npc 的欄位；性格沒寫的照預設「中」）。dead：死了的登錄成已故的人，在死處（第 6-6a 批）。"""
    age = character.age(sheet, clock_now)
    stage = realm.stage_name(sheet["realm_lv"], sheet["stage_index"])
    return {"name": sheet["name"], "appearance": sheet["appearance"], "profile": f"{'已故' if dead else '已退隱'}的{stage}修士。{sheet['background']}"[:200],
            "location": sheet["location"], "status": "FALLEN" if dead else "ALIVE", "ai_driven": True, "created_by": RETIRED_BY,
            "condition": npc.CONDITIONS[-1 if dead else 0],
            "race": sheet["race"], "gender": sheet["gender"], "lineage": sheet["lineage"],
            "birth_shichen": sheet["birth_shichen"], "realm_lv": sheet["realm_lv"],
            "stage_index": sheet["stage_index"], "cultivation": sheet["cultivation"], "goal": "" if dead else "隱居",
            "appearance_age": age if sheet["appearance"] else None, "profile_age": age,
            "evolved_shichen": clock_now, "first_seen_turn": turn_no,
            **{k: sheet.get(k) or origins.fields()[k] for k in origins.NPC_KEYS}}   # 帶著這一生的命（第 122a 批）


# ── 遺物 ───────────────────────────────────────────────────────────────────
def best(entries: list[dict]) -> dict | None:
    """最好的一件：法器優先，其次價錢高的。"""
    return max(entries, key=lambda e: (items.CATALOG[e["name"]].kind == items.ARTIFACT, items.price(e["name"], e["tier"])),
               default=None)


def lasts(rng) -> int:
    """落地後能留多久：每過十年擲一次、一半機會被撿走（一次擲完：幾何分布）。"""
    return RELIC_DECADE * (1 + math.floor(-math.log2(1 - rng.random())))


def leave(rng, sheet: dict, *, life: str, clock_now: int, holder: str = "") -> list[dict]:
    """一生結束時身上的物品變成遺物。life：哪一生；holder：殺死主角的人（拿走最好的一件，其餘留在死處）；
    退隱時傳主角自己的名字（全部帶走）。"""
    taken = best(sheet["items"]) if holder and holder != sheet["name"] else None

    def held(e):   # 退隱的人自己帶著的也記成遺物（owner＝holder），他死後才真的成了遺物
        return holder == sheet["name"] or e is taken
    return [{"life": life, "name": e["name"], "tier": e["tier"], "count": e["count"], "owner": sheet["name"],
             "holder": holder if held(e) else "", "place": "" if held(e) else sheet["location"],
             "placed_shichen": None if held(e) else clock_now, "lasts": lasts(rng)} for e in sheet["items"]]


def at(relics: list[dict], place: str, clock_now: int) -> list[dict]:
    """這個地點上還沒被人撿走的遺物。"""
    return [r for r in relics if r["place"] == place and clock_now < r["placed_shichen"] + r["lasts"]]


def held_by(relics: list[dict], name: str) -> list[dict]:
    return [r for r in relics if r["holder"] == name]


def label(relic: dict) -> str:
    return items.label(relic["name"], relic["tier"]) + (f"×{relic['count']}" if relic["count"] > 1 else "")


def held_text(relics: list[dict], name: str) -> str:
    """給說書人：「帶著張三的遺物：精鐵短刀（武者級）」。退隱者帶著的是自己的東西，不算遺物。"""
    mine = [r for r in held_by(relics, name) if r["owner"] != name]
    return "、".join(f"{r['owner']}的遺物{label(r)}" for r in mine)


# ── 傳說 ───────────────────────────────────────────────────────────────────
SIZE_RANK = {rumors.BIG: 2, rumors.MEDIUM: 1, rumors.SMALL: 0}


def deeds(all_rumors: list[dict], life: str) -> list[str]:
    """那一生最大的兩件事（先看大小、再看時間；殞落那則不算），用事發當地的版本（不走樣）。"""
    mine = [r for r in all_rumors if r["life"] == life and r["kind"] != rumors.FELL]
    mine.sort(key=lambda r: (SIZE_RANK[r["size"]], r["clock_shichen"]), reverse=True)
    return [rumors.text(r) for r in mine[:DEEDS]]


def told_ending(life: dict) -> str:
    """一生沒越過凡人（Lv0）的結局另外標出（16l 第 6-1 題）：以凡人之軀終老、以凡人之軀殞落。"""
    if life["lv"] > 0:
        return life["ending"]
    return MORTAL + (MORTAL_AGED if life["ending"] == AGED else life["ending"])


def legend(life: dict, clock_now: int) -> str:
    """life：{"name", "lv", "stage", "ending", "place", "end", "deeds"}。"""
    head = f"{life['name']}（{realm.stage_name(life['lv'], life['stage'])}）{told_ending(life)}於{life['place']}"
    if clock_now - life["end"] >= LEGEND_FADE or not life["deeds"]:
        return head
    return f"{head}；生前{'；'.join(life['deeds'])}"


def told(lives: list[dict], *, here: str, place_type: str, asked: bool, present: set[str], relics_here: list[dict],
         clock_now: int) -> str:
    """這回合說書人拿到哪一則傳說（最多一則）：死處或退隱處 > 遺物在這裡 > 他的友人仇家在場 > 打聽 > 一方強者；
    同樣相關挑最近的一生。lives 另有 "id"（哪一生）與 "ties"（友人、仇家的名字）。"""
    left_here = {r["life"] for r in relics_here}

    def rank(life):
        reasons = (life["place"] == here, life["id"] in left_here, bool(present & life["ties"]),
                   asked and place_type in ASK_PLACES, life["lv"] >= WIDE_LV)
        return next((i for i, yes in enumerate(reasons) if yes), None)
    ranked = [(rank(life), -life["end"], i) for i, life in enumerate(lives) if rank(life) is not None]
    return legend(lives[min(ranked)[2]], clock_now) if ranked else ""
