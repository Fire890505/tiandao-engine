"""仙域骨架（16l 第 5 題；草稿 B2）：每個玩家一份，所有世界共用。仙盟、仙宗、仙宗在各世界的分支。純函式。

規則（2026-10-14 與使用者一題一題定案，見 progress/WHITEPAPER.md 16l，數字暫定）：
- 第一次用到時生成第一紀元：舊專案的四盟，每盟 3～5 個仙宗（道統、門風、主收的種族、實力）。這只是起點，
  之後的百日演進（滅宗、立宗、盟的分合）在 C1。
- 下界生成本山時，上宗從仙域挑：種族、道統都相符的仙宗；挑不到就在該歸的盟裡新立一個（每盟最多 MAX_SECTS），
  盟滿了就挑那一盟裡的任一個。每個仙宗記著它在哪些世界有分支（{world, sect}）。
- 歸哪一盟看種族與道統：魔族或魔門、鬼修→魔氣先鋒；獸族→獸族自然契約；其餘人族道統→神氣正統。
  諸天異端隱匿不收一般的本山（它只對諸天異端開條件，見 B3 接引）。
- C1：地圖是方格，仙宗佔一到數格（第一格是山門），同盟的連成一片；盟與盟沿用天下骨架的四種關係（只有地盤相鄰的
  會交戰），交戰兩盟相鄰的仙宗就是大戰場。仙域百日一變（用到才補算，最多 20 次）：實力起伏、大戰場上打一場、
  實力歸零滅宗（地盤成無主之地，分支記進 fallen 等下界收到消息）、無主之地被吞併或有新宗立起、叛盟、散盟、併盟、結新盟。
- 7-3b3（WHITEPAPER (61)～(64)）：盟與盟不再擲骰，照好感立約（domain/pacts.py，一步＝一百日，壽元當 100 個百日）。
  原因存 realm 的 reasons（持有者、對象寫盟名），since、cd 同天下骨架；散了、併了的盟一起刪。
  原因的來源：大戰場輸得多的盟怕贏的盟（小）、造化之爭搶得最多的盟被相鄰的盟記小壞、你在大戰場的戰功讓敵盟記小壞、
  叛盟時原盟對新盟記大壞；盟主宣戰、停戰見 league.py。
"""
from __future__ import annotations

import random
import re

from collections import Counter

from ..config import PROJECT_ROOT
from . import atlas, crime, deck, names, opinion, pacts, races, roster
from .clock import SHICHEN_PER_DAY, SHICHEN_PER_YEAR

ORTHODOX, DEMONIC, BEASTS, HERETICS = "神氣正統", "魔氣先鋒", "獸族自然契約", "諸天異端隱匿"
FIRST_ERA = {   # 盟 → (宗旨, 主收的種族, 道統)；道統空＝不拘
    ORTHODOX: ("以神氣正道為本，護持諸界秩序", races.HUMAN, ("劍修", "丹道", "符籙", "佛門", "道觀", "體修")),
    DEMONIC: ("以魔氣破舊立新，強者為尊", races.DEMON, ("魔門", "鬼修")),
    BEASTS: ("守萬靈自然之約，不受人道拘束", races.BEAST, ()),
    HERETICS: ("收容諸天異類，隱於暗處觀局", "", ()),
}
RATIO = 360          # 天上一日，地上一年（16l 第 7 題）：下界 360 個時辰＝仙域 1 個時辰
SECTS = (3, 5)
MAX_SECTS = 8
POWER = (40, 60)
PREFIXES = names.IMMORTAL_PREFIXES + ("青華", "太清", "上清", "瑤池", "崑崙", "蓬萊", "方壺", "瀛洲", "廣寒", "兜率",
                                       "紫微", "北辰", "南明", "天璇", "玉衡", "搖光", "開陽", "天權", "赤霄", "碧霄",
                                       "金闕", "丹霞")   # 字首不重複用：最多 32 個仙宗


def generate(rng: random.Random, seed: str) -> dict:
    """第一紀元。"""
    realm = {"seed": seed, "era": 1, "day": 0, "alliances": [], "sects": []}
    for name, (creed, race, paths) in FIRST_ERA.items():
        realm["alliances"].append({"name": name, "creed": creed})
        for _ in range(rng.randint(*SECTS)):
            realm = _found(realm, rng, name, rng.choice(paths or tuple(names.SECT_PATHS)),
                           race or rng.choice(races.RACES))
    return realm


def alliance_for(path: str, race: str) -> str:
    if race == races.DEMON or path in FIRST_ERA[DEMONIC][2]:
        return DEMONIC
    return BEASTS if race == races.BEAST else ORTHODOX


def pick(realm: dict, rng: random.Random, path: str, race: str) -> tuple[dict, str]:
    """下界本山的上宗：回傳（仙域, 仙宗名）。"""
    fits = [s["name"] for s in realm["sects"] if s["path"] == path and s["race"] == race]
    if fits:
        return realm, rng.choice(fits)
    home = alliance_for(path, race)
    mine = [s["name"] for s in realm["sects"] if s["alliance"] == home]
    if len(mine) >= MAX_SECTS:
        return realm, rng.choice(mine)
    after = _found(realm, rng, home, path, race)
    if len(after["sects"]) == len(realm["sects"]):   # 名字用完了
        return realm, rng.choice(mine or [s["name"] for s in realm["sects"]])
    return after, after["sects"][-1]["name"]


def adopt(realm: dict, name: str, path: str, race: str) -> dict:
    """舊世界、匯入的存檔帶來仙域裡沒有的仙宗：照道統與種族歸盟。"""
    if any(s["name"] == name for s in realm["sects"]):
        return realm
    realm = {**realm, "sects": realm["sects"] + [_sect(name, alliance_for(path, race), path, race, POWER[0])]}
    return seat(realm, random.Random(f"{realm['seed']}:{name}"), name)


def branch(realm: dict, name: str, world: str, sect: str) -> dict:
    """記下仙宗在某個世界的分支（同一筆不重複）。"""
    entry = {"world": world, "sect": sect}
    return {**realm, "sects": [{**s, "branches": s["branches"] + [entry]}
                               if s["name"] == name and entry not in s["branches"] else s for s in realm["sects"]]}


def of_world(realm: dict, world: str) -> list[dict]:
    """在這個世界有分支的仙宗（存檔匯出用）。"""
    return [s for s in realm["sects"] if any(b["world"] == world for b in s["branches"])]


def _found(realm: dict, rng: random.Random, alliance: str, path: str, race: str, cell: list | None = None) -> dict:
    taken = {s["name"] for s in realm["sects"]} | {f["name"] for f in realm.get("fallen", [])}   # 覆滅的消息還沒傳完
    name = names.pick_unused(rng, PREFIXES, names.IMMORTAL_SUFFIXES, taken)
    if not name:
        return realm
    realm = {**realm, "sects": realm["sects"] + [_sect(name, alliance, path, race, rng.randint(*POWER),
                                                        rng.choice(crime.STYLES).name, [cell] if cell else [])]}
    return realm if cell else seat(realm, rng, name)


def _sect(name: str, alliance: str, path: str, race: str, power: int, style: str = "", cells: list = ()) -> dict:
    return {"name": name, "alliance": alliance, "path": path, "race": race, "style": style, "power": power,
            "branches": [], "cells": list(cells)}


# ── 地圖（C1，第 8 題）：仙宗佔方格上的一到數格（第一格是山門），同盟的連成一片 ─────────────────
STEPS = atlas.STEPS


def upgrade(realm: dict) -> dict:
    """C1 之前的骨架：仙宗補上地盤。"""
    if all("cells" in s for s in realm["sects"]):
        return realm
    realm = {**realm, "sects": [{"cells": [], **s} for s in realm["sects"]]}
    for s in realm["sects"]:
        realm = seat(realm, random.Random(f"{realm['seed']}:{s['name']}"), s["name"])
    return realm


def cells_of(realm: dict) -> dict[tuple, str]:
    return {tuple(c): s["name"] for s in realm["sects"] for c in s["cells"]}


def seat(realm: dict, rng: random.Random, name: str) -> dict:
    """還沒有地盤的仙宗：先挑盟裡地盤旁邊的無主之地，再挑盟的邊上，盟還沒有地盤就挑整張地圖的邊上。"""
    me = next(s for s in realm["sects"] if s["name"] == name)
    if me["cells"]:
        return realm
    at = cells_of(realm)
    mine = {c for c, n in at.items() if _alliance(realm, n) == me["alliance"]} if me["alliance"] else set()
    free = sorted(tuple(c) for c in realm.get("free", []))
    near = [c for c in free if _edge(mine) & {c}] or (free if not mine else [])
    around = sorted(_edge(mine) - set(at)) or sorted(_edge(set(at)))   # 盟的邊上都被佔了，就挑整張地圖的邊上
    cell = rng.choice(near) if near else rng.choice(around) if at else (0, 0)
    return {**realm, "free": [c for c in realm.get("free", []) if tuple(c) != cell],
            "sects": [{**s, "cells": [list(cell)]} if s["name"] == name else s for s in realm["sects"]]}


def _edge(cells) -> set[tuple]:
    return {(x + dx, y + dy) for x, y in cells for dx, dy in STEPS} - set(cells)


def _alliance(realm: dict, sect_name: str) -> str:
    return next(s["alliance"] for s in realm["sects"] if s["name"] == sect_name)


def neighbors(realm: dict) -> set[tuple[str, str]]:
    """地盤相鄰的兩個仙宗（名字排序過）。"""
    at = cells_of(realm)
    return {tuple(sorted((n, at[(x + dx, y + dy)]))) for (x, y), n in at.items() for dx, dy in STEPS
            if at.get((x + dx, y + dy), n) != n}


# ── 盟與盟（沿用天下骨架的四種關係；7-3b3 起照好感立約，_Pacts）──────────────────
OPPOSED = {frozenset({ORTHODOX, DEMONIC})}   # 開局比較容易交戰的兩盟；其他照「戒備」擲


def stances(realm: dict) -> dict[str, str]:
    """盟與盟的關係（atlas._key → 關係）；骨架裡還沒有就擲（同一個仙域每次一樣）。只有地盤相鄰的盟會交戰。"""
    names_ = sorted(a["name"] for a in realm["alliances"])
    old, near, out = realm.get("stances", {}), _bordering(realm), {}
    rng = random.Random(f"{realm['seed']}:stances")
    for i, a in enumerate(names_):
        for b in names_[i + 1:]:
            key = atlas._key(a, b)
            weights = atlas.START["敵對" if frozenset({a, b}) in OPPOSED else "戒備"]
            pick = old.get(key) or rng.choices(list(weights), weights=list(weights.values()))[0]
            out[key] = atlas.COLD if pick == atlas.WAR and key not in near else pick
    return out


LOST, BOON_FIGHT, MERITED, DEFECTED, DECLARED = "戰敗", "造化之爭", "戰功", "叛盟", "宣戰"   # 盟與盟的原因（7-3b3）
DECK = deck.read(PROJECT_ROOT / "rules" / "content" / "league.txt")   # 盟事牌（(62)）
assert all(c.who == "盟" and all(t.split(":")[0] in pacts.RESULTS for t in c.result.split()) for c in DECK), "盟事牌的結果寫錯了"


class _Pacts(pacts.Pacts):
    """盟與盟的立約：一步＝一百日；正魔兩盟基底 -40，其他（含新結的盟）-20；盟事牌的「宿敵」＝正魔兩盟。"""
    WED = "聯姻"

    def __init__(self, realm: dict):
        super().__init__([a["name"] for a in realm["alliances"]], stances(realm), realm.get("since", {}), _bordering(realm),
                         realm.get("reasons", []), realm.get("cd", {}), PERIOD, DECK)

    def base(self, x: str, y: str) -> int:
        return -40 if frozenset({x, y}) in OPPOSED else -20

    def pair(self, k: str, f: str, g: str, t: int) -> set[str]:
        return ({"是"} if frozenset({f, g}) in OPPOSED else set()) if k == "宿敵" else super().pair(k, f, g, t)


def _keep(realm: dict, t: int) -> dict:
    """散了、併了的盟的原因、since、冷卻一起刪；淡掉的原因不留。"""
    alive = {a["name"] for a in realm["alliances"]}
    years = pacts.LIFE * PERIOD / SHICHEN_PER_YEAR
    return {**realm, "since": {k: v for k, v in realm.get("since", {}).items() if k in realm["stances"]},
            "reasons": [{**r, "id": ""} for r in realm.get("reasons", [])   # id 用不到，清掉才每次一樣
                        if {r["holder"], r["toward"]} <= alive and opinion.alive(r, years, t)],
            "cd": {k: v for k, v in realm.get("cd", {}).items() if k.split("|")[0] in alive and v > t}}


def _bordering(realm: dict) -> set[str]:
    return {atlas._key(_alliance(realm, a), _alliance(realm, b)) for a, b in neighbors(realm)
            if _alliance(realm, a) and _alliance(realm, b) and _alliance(realm, a) != _alliance(realm, b)}


def at_war(realm: dict, a: str, b: str) -> bool:
    """兩個盟在交戰（沒有盟的散宗不算）。"""
    return bool(a and b and a != b) and stances(realm).get(atlas._key(a, b)) == atlas.WAR


def front(realm: dict) -> set[str]:
    """大戰場：地盤跟交戰中的敵盟相鄰的仙宗（它們的山門就是大戰場）。停戰就消失。"""
    return {n for pair in neighbors(realm) if at_war(realm, *(_alliance(realm, x) for x in pair)) for n in pair}


# ── 百日演進（C1，第 5 題、第 7-1 題）────────────────────────────────────
PERIOD = 100 * SHICHEN_PER_DAY   # 仙域百日一變
MAX_PERIODS = 20
DRIFT = 5                        # 實力每百日的起伏
BATTLE = (8, 4)                  # 交戰邊界上打一場：輸的 −8、贏的 +4
ANNEX, FOUND = 0.5, 0.2          # 無主之地被鄰宗吞併、有人在那裡立宗的機會
DEFECT, DISBAND, MERGE, FORM = 0.03, 0.2, 0.05, 0.2   # 叛盟、只剩一宗的盟散了、同盟的兩盟合併、散宗結新盟
WAR_MEMORY = 4                   # C5b3：盟主近幾個百日的宣戰算進盟內人心
MERIT_PER_POWER = 10             # C2：百日演進時，每 10 點戰功讓所屬仙宗實力 +1
ALLIANCE_PREFIXES = ("天元", "玄黃", "萬象", "九幽", "乾坤", "星河", "赤焰", "皓月", "鴻鈞", "無極")
CREEDS = ("以戰止戰，諸宗互保", "共分秘境，同進同退", "守望相助，不問出身", "破舊立新，強者為尊", "隱忍待時，伺機而動")


BOON_KINDS = ("天材地寶", "靈脈噴發", "上古遺府", "秘境")   # 造化（C3b，第 16 題丙）
BOONS = (1, 3)
BOON_POWER = 3                   # 下一個百日結算：搶得最多的仙宗實力 +3
RECRUITS = 2                     # C4b：每場仙戰被收走的 NPC 散仙


def boons(realm: dict, p: int) -> list[dict]:
    """第 p 個百日的造化 [{key, kind, sect}]：現在某個仙宗的地盤上（地點是它的山門）。用種子推，不另外存。"""
    rng, sects = random.Random(f"{realm['seed']}:boon:{p}"), sorted(s["name"] for s in realm["sects"])
    return [{"key": f"{p}:{i}", "kind": rng.choice(BOON_KINDS), "sect": rng.choice(sects)}
            for i in range(rng.randint(*BOONS))] if sects else []


def evolve(realm: dict, until: int) -> tuple[dict, list[str]]:
    """仙域演進到 until（仙域時辰）：跨過的每一個百日擲一次（最多最近 MAX_PERIODS 次）。回傳（仙域, 大事）。"""
    done, target, news = realm.get("evolved", 0) // PERIOD, until // PERIOD, []
    for p in range(max(done + 1, target - MAX_PERIODS + 1), target + 1):
        realm, more = _period(realm, p)
        news += more
    return ({**realm, "evolved": until} if target > done else realm), news


def _period(realm: dict, p: int) -> tuple[dict, list[str]]:
    rng, news, t = random.Random(f"{realm['seed']}:period:{p}"), [], p * PERIOD
    pa = _Pacts(realm)   # 盟與盟先立約（7-3b3）；新的一對（開局、新結的盟）先補原因
    pa.open([k for k in pa.st if k not in pa.since], t)
    pa.pacts(t)
    news += [s for _, s in pa.news]
    realm = {**realm, "stances": pa.st, "since": pa.since}
    home = {s["name"]: s["alliance"] for s in realm["sects"]}
    foes = lambda a: [b for b in pa.names if b != a and pa.st.get(atlas._key(a, b)) == atlas.WAR]
    won = realm.get("merit", {})   # C2：這段期間玩家在大戰場替各仙宗打下的戰功；敵盟記小壞
    for b, a in sorted({(b, home[n]) for n in won if home.get(n) for b in foes(home[n])}):
        pa.feel(b, a, MERITED, opinion.SMALL, -1, t)
    power = {s["name"]: s["power"] + rng.randint(-DRIFT, DRIFT) + won.get(s["name"], 0) // MERIT_PER_POWER
             for s in realm["sects"]}
    claimed, envy = realm.get("claimed", {}), set()   # C3b：上一個百日的造化，玩家搶到的歸他的仙宗，其他照實力擲
    for b in boons(realm, p - 1):
        best = claimed.get(b["key"]) or rng.choices(sorted(power), weights=[max(1, power[n]) for n in sorted(power)])[0]
        if best in power:
            power[best] += BOON_POWER
            news.append(f"{b['sect']}一帶的{b['kind']}之爭，{best}所得最多")
            owner = home.get(b["sect"], "")
            envy |= {(owner, home[best])} if owner and home[best] and owner != home[best] else set()
    for x, y in sorted(envy):   # 造化長在自家地盤卻被外盟搶走：地主那盟記小壞，一個百日一對一筆
        pa.feel(x, y, BOON_FIGHT, opinion.SMALL, -1, t)
    realm = {**realm, "merit": {}, "claimed": {}}
    for a in sorted(x["name"] for x in realm["alliances"]):   # C4b：上一個百日的仙戰落幕，散仙被收走、魁首傳開
        realm, took = roster.enlist(realm, rng, sorted(s["name"] for s in realm["sects"] if s["alliance"] == a), RECRUITS)
        best = realm.get("champions", {}).get(f"{p - 1}:{a}") or (took[0] if took else "")
        news += [f"{a}仙戰落幕，{best}奪得魁首" + (f"，{'、'.join(took)}被收入門下" if took else "")] if best else []
    realm = {**realm, "champions": {}}
    lost = Counter()
    for a, b in sorted(neighbors(realm)):   # 大戰場：交戰兩盟的邊界上打一場
        if at_war(realm, _alliance(realm, a), _alliance(realm, b)):
            win, lose = (a, b) if rng.random() < 0.5 + (power[a] - power[b]) / 200 else (b, a)
            power[lose], power[win] = power[lose] - BATTLE[0], power[win] + BATTLE[1]
            lost[(home[lose], home[win])] += 1
    for (x, y), n in sorted(lost.items()):   # 這個百日輸得多的盟怕贏的盟
        if n > lost[(y, x)]:
            pa.feel(x, y, LOST, opinion.SMALL, 1, t, opinion.FEAR)
    realm = {**realm, "sects": [roster.resize({**s, "power": max(0, min(100, power[s["name"]]))})   # 名冊跟著增減（C0）
                                for s in realm["sects"]]}
    realm, news = _fall(realm, news)
    realm, news = _wilds(realm, rng, news)
    realm, news = _alliances(realm, rng, news, p, pa)
    realm = _keep({**realm, "reasons": pa.rs, "cd": pa.cd}, t)
    cards = _Pacts(realm)   # 盟事牌：散、併、結新盟之後，每盟抽一張
    for a in cards.names:
        cards.draw(rng, a, t)
    return {**realm, "reasons": [{**r, "id": ""} for r in cards.rs], "cd": cards.cd}, news + [s for _, s in cards.told]


def _fall(realm: dict, news: list[str]) -> tuple[dict, list[str]]:
    """實力歸零＝滅宗：地盤變成無主之地；它在各世界的分支記進 fallen，等那個世界有人玩時才收到消息。"""
    dead = [s for s in realm["sects"] if s["power"] <= 0]
    news += [f"{s['name']}覆滅，山門化為無主之地" for s in dead]
    realm = roster.scatter(realm, dead) if dead else realm   # 門人一半戰死、一半流落成散仙（C0）
    realm = {**realm, "ruins": {**realm.get("ruins", {}), **{s["name"]: s["cells"][0] for s in dead if s["cells"]}},
             "lost": {**realm.get("lost", {}), **{s["name"]: s["alliance"] for s in dead}}}   # 滅宗清算用（覆滅時的盟）
    return ({**realm, "sects": [s for s in realm["sects"] if s["power"] > 0],
             "free": realm.get("free", []) + [c for s in dead for c in s["cells"]],
             "fallen": realm.get("fallen", []) + [{"name": s["name"], "branches": s["branches"]}
                                                  for s in dead if s["branches"]]}, news)


def _wilds(realm: dict, rng: random.Random, news: list[str]) -> tuple[dict, list[str]]:
    """無主之地：相鄰的仙宗裡最強的一半機會吞併；沒被吞的，有機會讓新的仙宗在那裡立宗（歸鄰宗的盟，或沒有盟）。"""
    for cell in sorted(tuple(c) for c in realm.get("free", [])):
        at = cells_of(realm)
        around = sorted({at[(cell[0] + dx, cell[1] + dy)] for dx, dy in STEPS if (cell[0] + dx, cell[1] + dy) in at})
        strong = max(around, key=lambda n: (next(s["power"] for s in realm["sects"] if s["name"] == n), n), default="")
        free = [c for c in realm["free"] if tuple(c) != cell]
        if strong and rng.random() < ANNEX:
            realm = {**realm, "free": free, "sects": [{**s, "cells": s["cells"] + [list(cell)]} if s["name"] == strong
                                                      else s for s in realm["sects"]]}
            news.append(f"{strong}佔下了一片無主之地")
        elif rng.random() < FOUND:
            after = _found({**realm, "free": free}, rng, _alliance(realm, strong) if strong else "",
                           rng.choice(tuple(names.SECT_PATHS)), rng.choice(races.RACES), list(cell))
            if len(after["sects"]) > len(realm["sects"]):
                realm = after
                news.append(f"{after['sects'][-1]['name']}在無主之地立宗")
    return realm, news


def _alliances(realm: dict, rng: random.Random, news: list[str], p: int, pa: _Pacts) -> tuple[dict, list[str]]:
    """叛盟、散盟、併盟、結新盟；新盟照宗旨取名。叛盟時原盟對新盟記大壞（7-3b3）。"""
    sects = realm["sects"]
    for pair in sorted(neighbors(realm)):   # 叛盟：投向地盤相鄰的另一個盟
        a, b = (next(s for s in sects if s["name"] == n) for n in pair)
        if b["alliance"] and a["alliance"] != b["alliance"] and rng.random() < DEFECT * _pull(realm, a, b, p):
            news.append(f"{a['name']}叛出{a['alliance'] or '散宗之列'}，投入{b['alliance']}")
            if a["alliance"]:
                pa.feel(a["alliance"], b["alliance"], DEFECTED, opinion.BIG, -1, p * PERIOD)
            sects = [{**s, "alliance": b["alliance"]} if s["name"] == a["name"] else s for s in sects]
    count = {a["name"]: sum(s["alliance"] == a["name"] for s in sects) for a in realm["alliances"]}
    gone = {n for n, c in count.items() if c == 0 or c == 1 and rng.random() < DISBAND}
    news += [f"{n}散盟" for n in sorted(gone) if count[n]]
    sects = [{**s, "alliance": ""} if s["alliance"] in gone else s for s in sects]
    alliances = [a for a in realm["alliances"] if a["name"] not in gone]
    st = {k: v for k, v in realm["stances"].items() if not set(k.split("|")) & gone}
    for key, v in sorted(st.items()):   # 併盟：結盟的兩盟，小的併進大的
        x, y = key.split("|")
        if v == atlas.ALLY and rng.random() < MERGE and {x, y} <= {a["name"] for a in alliances}:
            big, small = sorted((x, y), key=lambda n: (-sum(s["alliance"] == n for s in sects), n))
            news.append(f"{small}併入{big}")
            view = {**realm, "sects": sects, "alliances": alliances}   # 小盟的秘境改名成「大盟秘境・二」（第 45 題）
            kept = {s["name"]: {"anchor": s["anchor"], "was": s["was"]} for s in secrets(view, big)}
            for s in secrets(view, small)[:len(SECRET_NO) - len(kept) + 1]:
                kept[f"{big}{SECRET}・{SECRET_NO[len(kept) - 1]}"] = {"anchor": s["anchor"], "was": s["name"]}
            alliances = [{**a, "secrets": kept} if a["name"] == big else a for a in alliances]
            sects = [{**s, "alliance": big} if s["alliance"] == small else s for s in sects]
            alliances = [a for a in alliances if a["name"] != small]
    free = {s["name"] for s in sects if s["alliance"] == "" and not s.get("founder")}   # 主角的宗自己決定（C5b3）
    loose = sorted({n for pair in neighbors({**realm, "sects": sects}) for n in pair if set(pair) <= free})
    if len(loose) >= 2 and rng.random() < FORM:   # 結新盟：地盤相鄰的散宗
        name = names.pick_unused(rng, ALLIANCE_PREFIXES, ("盟",), {a["name"] for a in alliances})
        if name:
            alliances.append({"name": name, "creed": rng.choice(CREEDS)})
            sects = [{**s, "alliance": name} if s["name"] in loose else s for s in sects]
            news.append(f"{'、'.join(loose)}結為{name}")
    realm = {**realm, "sects": sects, "alliances": alliances,
             "stances": {k: v for k, v in st.items() if set(k.split("|")) <= {a["name"] for a in alliances}}}
    return {**realm, "stances": stances(realm)}, news


SECRET, SECRET_NO = "秘境", "二三四五六七八九十"
SECRET_NAME = re.compile(rf".+{SECRET}(・[{SECRET_NO}])?$")


def secrets(realm: dict, alliance: str) -> list[dict]:
    """這個盟的秘境 [{name, anchor（連著哪個仙宗的山門）, was（改名前的地名）}]，主秘境在最前面：anchor 實力最強的那處
    （anchor 不在盟裡的排後面）。沒記過的盟只有「某盟秘境」一處，連著盟裡第一個仙宗（C4b、第 45 題）。"""
    a = next((x for x in realm["alliances"] if x["name"] == alliance), None)
    if not a:
        return []
    power = {s["name"]: s["power"] for s in realm["sects"] if s["alliance"] == alliance}
    found = [{"name": n, **v} for n, v in a.get("secrets", {}).items()] or [
        {"name": alliance + SECRET, "anchor": next(iter(power), ""), "was": ""}]
    return sorted(found, key=lambda s: -power.get(s["anchor"], -1))


def _pull(realm: dict, a: dict, b: dict, p: int) -> float:
    """a 投向 b 的盟的機率倍數：主角的宗不動（C5b3 由宗主決定）；動盪中加倍、分裂出的宗不投原宗的盟、
    原宗的盟的敵盟來拉攏加倍（C5b2）；盟主近 WAR_MEMORY 個百日每宣戰一次 +0.5，最多加倍（C5b3）。"""
    if a.get("founder"):
        return 0
    wars = next((x.get("wars", []) for x in realm["alliances"] if x["name"] == a["alliance"]), [])
    k = (2 if a.get("unrest", -1) >= p else 1) * (1 + min(1, sum(w > p - WAR_MEMORY for w in wars) / 2))
    home = next((s["alliance"] for s in realm["sects"] if s["name"] == a.get("origin")), "")
    if home and home == b["alliance"]:
        return 0
    return k * 2 if home and stances(realm).get(atlas._key(home, b["alliance"])) in (atlas.WAR, atlas.COLD) else k


def feud(realm: dict, x: str, y: str) -> bool:
    """分裂出的宗跟原宗、原宗的盟算冷戰（C5b2）。"""
    by = {s["name"]: s for s in realm["sects"]}

    def hates(a: str, b: str) -> bool:
        origin = by.get(a, {}).get("origin", "")
        home = by.get(origin, {}).get("alliance", "")
        return bool(origin) and (b == origin or bool(home) and by.get(b, {}).get("alliance") == home)
    return hates(x, y) or hates(y, x)


def valid_sect(s) -> bool:
    """存檔帶的仙宗（地盤在匯入時重新安排，B2 的存檔沒有 cells）。"""
    optional = {"cells", "roster", "founder", "elders", "deeds", "errands", "neglect", "unrest", "origin", "left"}   # C5b
    return (isinstance(s, dict)
            and set(s) - optional == {"name", "alliance", "path", "race", "style", "power", "branches"}
            and isinstance(s["name"], str) and 1 <= len(s["name"]) <= 12 and isinstance(s["alliance"], str)
            and len(s["alliance"]) <= 20 and (s["path"] in names.SECT_PATHS) and s["race"] in races.RACES
            and isinstance(s["style"], str) and isinstance(s["power"], int) and 0 <= s["power"] <= 100
            and isinstance(s["branches"], list) and all(
                isinstance(b, dict) and set(b) == {"world", "sect"} and all(isinstance(v, str) for v in b.values())
                for b in s["branches"]))
