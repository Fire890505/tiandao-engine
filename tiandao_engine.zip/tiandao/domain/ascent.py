"""破空與接引（16l 第 3、4 題；草稿 B3）：衝到 Lv7 那一刻接引法陣降下，下一回合選好就飛升。純函式。

規則（2026-10-14 與使用者一題一題定案，見 progress/WHITEPAPER.md 16l，數字暫定）：
- 有宗門的：自家上宗接引，進去當外門弟子。散修：仙域擲 1～3 個仙宗來搶人，各開條件（位置、要立的誓）；
  諸天異端隱匿只對諸天異端開條件。也能全部拒絕、自己撕開虛空成為散仙。
- 角色卡 ascent：None，或 {"offers": [{"sect", "rank", "oath"}]}——還在等回答（這時不能做別的事）；
  ascended：這一生在原世界以「飛升」結局收尾。
- 飛升：原世界的這一生結束；同一個人在仙域開一局，角色卡承接境界、法則、功法、物品、屬性，
  原世界的關係、落腳處、門派、隨行的人、通緝、天道注視（每一生一份）都不帶過去。
"""
from __future__ import annotations

from . import immortal, paths, realm, sect

LV = realm.ASCEND_LV
OFFERS = (1, 3)
WEAK_BELOW = 50                    # 實力不到這個數的仙宗開內門搶人，其他開外門
OATHS = ("百年之內替宗門出戰大戰場", "以本命精血立誓，永不叛宗", "不得私收他宗弟子為徒", "三百年內聽候宗門差遣",
         "替宗門鎮守一處秘境百年")
REJECT_WORDS = ("拒絕", "散仙", "撕開虛空", "都不去", "一個都不")
FREE = "散仙"
VOID = "虛空裂隙"                   # 散仙落進仙域的地方
GATE = "山門"                      # 仙宗在仙域的落點：仙宗名＋山門
ENDING = "飛升"


def fields() -> dict:
    return {"ascent": None, "ascended": False}


def offers(rng, realm: dict, *, upper: str, heretic: bool, sheet: dict | None = None) -> list[dict]:
    """接引：有宗門而且上宗在仙域的，只有自家上宗（外門）；散修 1～3 個仙宗開條件（同道統的權重加倍、修鬼道的正道不來）。"""
    if upper and any(s["name"] == upper and not (sheet and paths.problem(sheet, s["path"])) for s in realm["sects"]):
        return [{"sect": upper, "rank": sect.OUTER, "oath": ""}]
    pool = sorted((s for s in realm["sects"] if heretic or s["alliance"] != immortal.HERETICS), key=lambda s: s["name"])
    picks = paths.pick(rng, pool, rng.randint(*OFFERS), sheet)
    return [{"sect": s["name"], "rank": sect.INNER if s["power"] < WEAK_BELOW else sect.OUTER, "oath": rng.choice(OATHS)}
            for s in picks]


def text(found: list[dict]) -> str:
    lines = "、".join(f"{o['sect']}（{o['rank']}" + (f"；要立誓：{o['oath']}" if o["oath"] else "") + "）" for o in found)
    return f"接引法陣自天而降：{lines}。說出要投入哪一宗，或全部拒絕，自己撕開虛空成為散仙（可以順便說「道號某某」）"


def choose(found: list[dict], words: str) -> dict | None:
    """玩家的回答：投入的那一宗；全部拒絕＝散仙（sect 空字串）；都沒說到回傳 None。"""
    pick = next((o for o in found if o["sect"] in words), None)
    if pick:
        return pick
    return {"sect": "", "rank": "", "oath": ""} if any(w in words for w in REJECT_WORDS) else None


def landing(pick: dict) -> str:
    return pick["sect"] + GATE if pick["sect"] else VOID


def arrival(sheet: dict) -> str:
    """仙域開場給說書人的事實。"""
    if sheet["sect"]:
        return f"主角剛從下界飛升，被{sheet['sect']}的接引法陣接進仙域，成了{sheet['sect_rank']}弟子"
    return "主角剛從下界飛升，拒絕了所有接引，自己撕開虛空落進仙域，成了沒有靠山的散仙"
