"""三族（2026-10-13，WHITEPAPER 16k 第 4～6 題、草稿批次二；數字暫定）。純函式。

- 壽元倍數：人族 1、魔族 2.5、獸族 3.5。魔族閉關被打斷走火的機率加倍、不能參悟光系。
- 獸族化形：金丹（Lv3）以前外貌帶獸徵，只能靠外物遮；金丹起族徵能收能放（16u 族徵，收放的規則在 domain/form.py）。
- 認出：獸族露著就看得出來；魔族初見時三分之一被看出（依名字定，同一個人每次一樣），金丹起斂住氣息降到十分之一；
  藏著的時候同族和高手看得穿；易容遮得住。
  被認出時初見好感照種族關係（敵對 −20、戒備 −10）；所在國的國法「包容」不扣。
- 新人物：九成是這一州的種族，一成是別族。
"""
from __future__ import annotations

import random

HUMAN, DEMON, BEAST = "人族", "魔族", "獸族"
RACES = (HUMAN, DEMON, BEAST)
WEIGHTS = {HUMAN: 60, DEMON: 15, BEAST: 25}   # 建角沒選時（WORLD_MATERIALS 第 3 節）
LIFESPAN = {HUMAN: 1, DEMON: 2.5, BEAST: 3.5}
DEVIATION = {DEMON: 2}
BANNED = {DEMON: ("光系",)}
FULL_FORM_LV = 3
DEMON_SHOWS, DEMON_HIDDEN = 1 / 3, 1 / 10
SLIP, PILL = "失控", "化形丹"                     # 角色卡 form_mode：暫時壓過玩家的選擇
FOX, SENIOR = "青丘狐族", 10                      # 同族看尾數知輩分：尾巴比對方多，初見好感 +10（16u 族徵第 5 題）
TAIL_WORDS = "一二三四五六七八九"
RELATIONS = {frozenset({HUMAN, DEMON}): "敵對", frozenset({HUMAN, BEAST}): "戒備", frozenset({DEMON, BEAST}): "中立"}
FIRST_VIEW = {"敵對": -20, "戒備": -10}
LOCAL = 0.9                                     # 新人物、出生地是本族的機率
TOLERANT, HOSTILE = "包容", "排外"               # 國法「他族」那一項（domain/crime.py）


def relation(a: str, b: str) -> str:
    return "同族" if a == b else RELATIONS[frozenset({a, b})]


def visible(who: dict) -> bool:
    """族徵露著嗎：失控、化形丹優先，再看玩家的選擇；金丹以前藏不住。NPC 沒有這些欄位：金丹起收著。"""
    if who.get("form_mode"):
        return who["form_mode"] == SLIP
    return who.get("shown", False) or who.get("realm_lv", 0) < FULL_FORM_LV


def shown(who: dict, *, viewer: str, life: str, disguised: bool, sharp: bool = False) -> bool:
    """主角的族徵在 viewer 面前露出來了沒。sharp：對方是同族或高手，藏著也看得穿。"""
    race = who["race"]
    if race == HUMAN or disguised:
        return False
    if sharp or who.get("form_mode") == SLIP:
        return True
    if race == BEAST:
        return visible(who)
    return random.Random(f"{life}:{viewer}").random() < (DEMON_SHOWS if visible(who) else DEMON_HIDDEN)


def tails(realm_lv: int) -> int:
    """狐尾數：武者以前一條，之後一個大境界一條，最多九條。"""
    return min(max(realm_lv, 1), len(TAIL_WORDS))


def senior(who: dict, other: dict) -> int:
    """同族的狐看到尾巴比自己多的人，會客氣一點；收起來就看不到。"""
    fox = who.get("lineage") == other.get("lineage") == FOX and visible(who)
    return SENIOR if fox and tails(who["realm_lv"]) > tails(other.get("realm_lv", 0)) else 0


def first_view(mine: str, theirs: str, *, seen: bool, tolerant: bool) -> int:
    """初見時好感因為種族而扣多少（0＝不扣）。"""
    return 0 if not seen or tolerant else FIRST_VIEW.get(relation(mine, theirs), 0)


def local(rng: random.Random, race: str) -> str:
    """這裡的新人物是哪一族。"""
    return race if rng.random() < LOCAL else rng.choice([r for r in RACES if r != race])


def form_text(who: dict) -> str:
    """給說書人的一句（外貌），面板也用。"""
    race, full = who["race"], who["realm_lv"] >= FULL_FORM_LV
    if race == HUMAN:
        return ""
    if who.get("form_mode") == SLIP:
        return "壓不住，族徵現了出來"
    if race == DEMON:
        return "族徵露著，情緒激動時藏不住" if visible(who) else "斂住了氣息，一般人看不出來"
    if who.get("form_mode") == PILL:
        return "服了化形丹，暫時是人形，藥效過了就會現形"
    if not full:
        return "還沒能完全化形，外貌帶著獸徵"
    return "現在露著族徵，能隨時收起" if visible(who) else "已化成人形，族徵收著"
