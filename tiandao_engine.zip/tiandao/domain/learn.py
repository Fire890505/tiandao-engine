"""學識（第 7-1c 批，WHITEPAPER 第 7-1-8、7-1-12 題甲）：讀過多少書，五級＋1～2 個專長，存著。純函式。

- 照時代、出身擲，不看性別：古代一般人家約三成識字；宗門出身往上兩級，帳房、大夫這類人家往上一級，
  農戶、奴婢往下一級；現代、未來多半讀過書。專長從家業、職業來，沒有的讀過書以上擲一個。
- 接：怪談守則（不識字要人念，game/zones）、查典故認東西的查探、對讀書人講道理的說服、宗門考核（武試不看）。
- 主角存在角色卡（learning、knacks），至少識字（第 7-1-15 題甲）；NPC 存在 npcs 兩欄；還沒擲的（空字串）當識字。數字暫定。
"""
from __future__ import annotations

import random

from . import era
from . import judgment as J

LEVELS = ("不識字", "識字", "讀過書", "飽學", "博通")
NONE, READ, LEARNED = 0, 1, 2
ODDS = {era.ANCIENT: (70, 20, 7, 3, 0), era.MODERN: (2, 8, 70, 15, 5), era.FUTURE: (2, 8, 70, 15, 5)}
KNACKS = {   # 專長 → 查探時用得上的字
    "醫": ("藥", "病", "毒", "傷口"), "律": ("律", "案", "狀紙", "官文"), "算": ("帳", "數目"),
    "地理": ("地形", "山勢", "水路", "地圖"), "風水": ("風水", "墓", "地脈", "龍脈"),
    "古文": ("古", "碑", "銘", "篆"), "方術": ("陣", "符", "咒", "法器"),
    "兵法": ("兵", "陣勢", "埋伏"), "經商": ("貨", "價", "行情"), "異族語": ("獸族", "魔族", "異族")}
TRADES = {"大夫": "醫", "藥童": "醫", "帳房": "算", "掌櫃": "經商", "小販": "經商", "朝奉": "經商", "書吏": "律", "衙役": "律",
          "鏢師": "地理", "趟子手": "地理", "獵戶": "地理", "守祠人": "風水", "武師": "兵法"}
UP = ("帳房", "大夫", "書吏", "朝奉")             # 家裡做這行：往上一級
DOWN = ("農戶", "獵戶", "牧人", "腳夫", "奴隸")   # 往下一級
SECT_UP, SECT_KNACK = 2, "方術"                  # 宗門出身
ME = {   # 主角的凡人身分 → （往上幾級, 專長）
    "沒落世家旁支": (2, "古文"), "書院雜役": (1, ""), "醫館學徒": (0, "醫"), "小商販": (0, "算"), "獵戶": (-1, "地理"),
    "農戶子弟": (-1, ""), "坊市孤兒": (-1, ""), "逃難者": (-1, ""), "奴隸": (-1, ""), "墓匠後人": (0, "風水"),
    "宮廟子弟": (0, "方術"), "大學生": (1, ""), "守林人": (0, "地理"), "夜市攤販": (0, "經商"), "雜貨店的孩子": (0, "算"),
    "地下診所學徒": (0, "醫"), "義體維修工": (0, "算"), "退役傭兵之後": (0, "兵法"), "廢土拾荒者": (-1, ""), "數據黑戶": (0, "算")}
LORE = ("古物", "陣紋", "典故", "碑文", "出處", "古籍", "銘文", "來歷", "卷軸", "認出")   # 查探要靠知識的字
STEP, EXAM = 10, 5   # 查探每高識字一級、專長、說服：10；考核每高識字一級：5
BEHIND = 2           # 不合時宜的人讀這個時代的字降兩級（第 8-3-4 題乙；查典故、認古物照舊）


def roll(rng: random.Random, era_now: str, *, up: int = 0, knacks: tuple = ()) -> dict:
    """擲一個人的學識：{"learning", "knacks"}。"""
    lv = max(NONE, min(len(LEVELS) - 1, rng.choices(range(len(LEVELS)), weights=ODDS.get(era_now, ODDS[era.ANCIENT]))[0] + up))
    own = list(dict.fromkeys(k for k in knacks if k))[:2]
    return {"learning": LEVELS[lv], "knacks": own or ([rng.choice(list(KNACKS))] if lv >= LEARNED else [])}


def of_npc(rng: random.Random, p: dict, era_now: str, sect: bool) -> dict:
    """NPC：出身句裡的家業、職業、在不在宗門。"""
    said = p.get("origin", "") + p["job"]
    up = SECT_UP if sect else 1 if any(w in said for w in UP) else -1 if any(w in said for w in DOWN) else 0
    return roll(rng, era_now, up=up, knacks=(TRADES.get(p["job"], ""), *(v for k, v in TRADES.items() if k in said),
                                             SECT_KNACK if sect else ""))


def of_me(rng: random.Random, sheet: dict, era_now: str) -> dict:
    """主角至少識字（第 7-1-15 題甲：看不懂守則等於玩家看不到內容）。"""
    up, knack = ME.get(sheet["origin"], (0, ""))
    got = roll(rng, era_now, up=up, knacks=(knack,))
    return {**sheet, **got, "learning": LEVELS[max(READ, LEVELS.index(got["learning"]))]}


def level(x: dict) -> int:
    return LEVELS.index(x["learning"]) if x.get("learning") in LEVELS else READ


def bonus(me: dict, *, nature: str, words: str, target: dict | None = None, persuade: bool = False, exam: bool = False) -> int:
    """判定加減：宗門考核每高識字一級 +5（武試不看）；查探要靠知識的（認古物、陣紋、典故）每高識字一級 +10、
    有用得上的專長再 +10；對讀過書以上的人講道理，學識比他高 +10。"""
    lv = level(me)
    if exam:
        return 0 if nature == J.COMBAT else (lv - READ) * EXAM
    if nature in (J.EXPLORE, J.OBSERVE) and any(w in words for w in LORE):
        return (lv - READ) * STEP + STEP * any(w in words for k in me.get("knacks", ()) for w in KNACKS.get(k, ()))
    if persuade and target and level(target) >= LEARNED and lv > level(target):
        return STEP
    return 0


def text(x: dict) -> str:
    """面板：「識字（醫、算）」；還沒擲的空字串。"""
    return x["learning"] + (f"（{'、'.join(x['knacks'])}）" if x["knacks"] else "") if x.get("learning") else ""


def valid(x: dict) -> bool:
    return x["learning"] in ("", *LEVELS) and isinstance(x["knacks"], list) and len(x["knacks"]) <= 2 and all(k in KNACKS for k in x["knacks"])
