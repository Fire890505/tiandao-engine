"""陷阱（WHITEPAPER 16v 第 81-6～81-10 題）：對手在擋玩家，不算對手的一步、不推主線。純函式。內容在 rules/content/traps.txt。

- 對手盯著：暗線在走、人在路線那裡、這回合查探、社交或潛行。不在盯著的地方照舊：大成功抽機會、大失敗抽命運。
- 失敗埋一張（露苗頭），最多埋 MAX 張；大失敗加強版當場落下（取代命運牌），代價重一級；大成功識破最早那張，沒有就照舊抽機會。
- 埋著的陷阱：苗頭還在時去查（問模型）就識破，得到識破句；不然玩家下一次在那裡行動時落下，給兩種應付法，沒選算第一個。
- 換階不拿掉，路線收場才跟著暗線一起沒了（第 81-11 題）。這回合已經有別的事就不落下，大失敗改成先埋；同一條暗線用過的不再抽，抽完照舊只有代價牌（第 81-15 題）。陷阱不能把路堵死：代價只有受傷、失錢、處境、拖延、假線索。
暗線欄位：traps（埋著的：苗頭、哪回合埋的）、sprung（落下等回話的）、decoy（假線索指的地方）。
"""
from __future__ import annotations

import random
from dataclasses import dataclass

from ..config import PROJECT_ROOT
from . import deck as cards
from . import judgment as J

COMMON = "通用"
BURY, STRONG, SEE = "埋", "強", "破"
MAX = 2
HURT, MONEY, SPOT, DELAY, DECOY = "受傷", "失錢", "處境", "拖延", "假線索"
ACTS = {J.EXPLORE: "查探", J.OBSERVE: "查探", J.SOCIAL: "社交", J.STEALTH: "潛行"}


@dataclass(frozen=True)
class Card:
    deck: str
    step: str        # 專屬牌：暗線第幾步抽得到（0～2）；通用牌空著
    means: str
    act: str         # 通用牌：哪種行動失敗才抽
    sign: str
    fall: str
    seen: str
    ways: tuple      # ((應付法, 代價), (應付法, 代價))
    card: cards.Card | None = None   # 第 4-5 題：traps.txt 那一行，options 用它的條件篩


def _card(c: cards.Card) -> Card:
    """共用格式（第 4-5 題）：條件 路線、步（專屬）或 行動（通用）；內容欄 苗頭｜落下｜識破句｜應付｜應付。"""
    need, (fall, seen, *ways) = dict(c.need), c.more
    return Card(need.get("路線", COMMON), need.get("步", ""), c.kind, need.get("行動", ""), c.text, fall, seen,
                tuple((way, cards.bare(cost)) for way, cost in (w.split(":", 1) for w in ways)), c)


DECK = [_card(c) for c in cards.read(PROJECT_ROOT / "rules" / "content" / "traps.txt")]


def fields() -> dict:
    return {"traps": [], "sprung": None, "decoy": "", "spent": []}


def plan(d: dict, outcome: str, watched: bool) -> str:
    """這回合對手怎麼出手：埋、強（當場落下）、破（大成功識破），沒有是空字串。"""
    if not watched or d["sprung"]:
        return ""
    if outcome == J.GREAT_SUCCESS:
        return SEE if d["traps"] else ""
    if outcome == J.GREAT_FAILURE:
        return STRONG
    return BURY if outcome == J.FAILURE and len(d["traps"]) < MAX else ""


def options(line: str, step: int, act: str, used: set[str], place: bool) -> list[Card]:
    """line：路線（副）。專屬牌照暗線第幾步，條件比通用牌（看哪種行動失敗）多一條，對得上就先抽（deck.pool，第 4-5 題）。
    這條暗線用過的不再抽；沒有地方可指就不抽寫了{地}的。"""
    ok = [c for c in DECK if c.sign not in used and (place or "{地}" not in c.fall + c.seen + str(c.ways))]
    top = set(cards.pool([c.card for c in ok], {"路線": (line,), "步": (str(min(step, 2)),), "行動": (act,)}))
    return [c for c in ok if c.card in top]


def pick(rng: random.Random, line: str, step: int, act: str, used: set[str], place: bool) -> Card | None:
    found = options(line, step, act, used, place)
    return rng.choice(found) if found else None


def card(sign: str) -> Card:
    return next(c for c in DECK if c.sign == sign)


def answer(ways: tuple, text: str) -> tuple[str, str]:
    """玩家怎麼應付（填好空的兩種）：說到第二種就是第二種，沒選算第一個。"""
    return ways[1] if ways[1][0] in text else ways[0]


def valid(d: dict) -> bool:
    return isinstance(d.get("traps"), list) and all(isinstance(t, dict) and set(t) == {"sign", "at", "words"} for t in d["traps"]) \
        and (d.get("sprung") is None or isinstance(d["sprung"], dict)) and isinstance(d.get("decoy"), str) and isinstance(d.get("spent"), list)
