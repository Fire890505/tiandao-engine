"""事件（第 9 步）：世界主動丟給你的狀況。純函式，不碰資料庫、不呼叫 AI。

規則（2026-10-05 與使用者一題一題定案，見 progress/WHITEPAPER.md 第 15 節，數字暫定）：
- Python 定骨架、AI 寫血肉：這回合有沒有事件、哪一類、牽涉誰、能帶來什麼後果由 Python 決定，AI 只寫情節。
- 每回合擲一次、最多一件；機率看行動，剛發生過減半，連續沒事慢慢升高。
- 9 類，權重照舊專案；地點、季節對得上加權；境界過濾；條件不成立的那一類不抽。
- 應對型：這回合只起頭，下一回合行動類型對得上 → 判定成功得獎、失敗受損；做別的事＝放過。當下型：當場結算。
- 天道：事件記來源與棋局編號；天道落的子（骨架、勝負、獎懲）在 domain/games.py（第 18-2a 步）。
- 第 9b 步：有後續的接到現有機制，不另存「進行中的事件」——地點狀況（帶結束時間）、線頭（照線頭的規則）。
- 第 4-2 題：遭遇在 rules/content/encounters.txt（牌的共用格式，domain/deck.py），種類的權重、境界、加成在 kinds.txt。
"""
from __future__ import annotations

import dataclasses
import random
from dataclasses import dataclass

from ..config import PROJECT_ROOT
from . import deck
from . import judgment as J
from . import memory as m
from .clock import SHICHEN_PER_DAY

# ── 種類與權重 ───────────────────────────────────────────────────────────
DAILY, CULTIVATION, SECT, MARKET, WILDERNESS = "日常", "修行", "宗門", "坊市", "歷練"
AFFECTION, RUINS, SEASON, FESTIVAL = "好感", "秘境", "季節", "節日"
ROAD = "路上"   # 地圖第二輪：移動的回合只從這一類挑（不看境界、地點）；其他回合不會抽到
ESCORT, HUNT = "押貨", "獵場"   # 16o 第 4、5 題：走鏢、打獵的途中遭遇只挑這兩類；其他回合不會抽到
PLACE_BOOST, SEASON_BOOST = 1.5, 1.4
CONTENT = PROJECT_ROOT / "rules" / "content"


def _list(text: str) -> tuple[str, ...]:
    return tuple(text.split("、")) if text else ()


@dataclass(frozen=True)
class Kind:
    """種類表的一行（第 4-2 題，rules/content/kinds.txt）。realms 空＝只有指定這一類時才抽。"""
    weight: int
    realms: frozenset
    places: tuple
    seasons: tuple


def _realms(text: str) -> frozenset:   # 「0～2、5～6」
    return frozenset(lv for a, _, b in (p.partition("～") for p in _list(text)) for lv in range(int(a), int(b or a) + 1))


KINDS = {k: Kind(int(w), _realms(lv), _list(p), _list(s)) for k, w, lv, p, s in (
    line.split("｜") for line in (CONTENT / "kinds.txt").read_text(encoding="utf-8").splitlines()
    if line and not line.startswith("#"))}
WEIGHTS = {k: v.weight for k, v in KINDS.items()}

# ── 多常發生 ─────────────────────────────────────────────────────────────
CHANCE = {J.MOVE: 0.4, J.EXPLORE: 0.35, J.SOCIAL: 0.2, J.OBSERVE: 0.2, J.STEALTH: 0.2, J.CULTIVATE: 0.1, J.REST: 0.1,
          J.WORK: 0.2,   # 做工在人群裡，有寫時長也照樣會遇到事（第 8 步）
          J.STUDY: 0.1,  # 參悟比照修煉（第 3b-1 步）
          J.ALCHEMY: 0.1, J.FORGE: 0.1}   # 煉丹、煉器也比照修煉（第 3b-3 步）
ROUTINE_MONTHLY = 0.03                # 日常面板的途中遭遇：每個月 3%（16n 第 16 題；一年約 31%）
ROUTINE_CAP = 0.5                     # 最多一半：長閉關才跳得過衝關間隔（16n 第 19 題）
AFTER_ONE = 0.5                       # 剛發生過的下一回合減半
QUIET_STEP, QUIET_MAX = 0.05, 0.25    # 連續沒事：每回合 +5%，最多 +25%
ROAD_ODDS = {3: 0.25, 20: 1.0, 80: 1.5}   # 這回合走的路程（公里，同 space.DISTANCE_TIERS）→ 機率倍數；更遠的照遠行

# ── 後果（依境界分級）─────────────────────────────────────────────────────
GAIN_STONES, LOSE_STONES, GAIN_CULTIVATION, LOSE_HP = "得靈石", "失靈石", "長修為", "受傷"
GAIN_FAVOUR, LOSE_FAVOUR = "好感上升", "好感下降"
SAVED = "救命之恩"            # 16v 第 113 題：好感上升，他欠你一份救命之恩
GAIN_ITEM = "得物品"          # 第 8b 步：給 Seed.item 那件東西（品階跟著主角境界）
GAIN_MONEY, LOSE_MONEY = "得錢", "失錢"   # 經濟第二輪：凡人的事給、扣凡人錢（靈石的數目 × MONEY_RATE）
LOSE_CARGO, LOSE_PAY = "賠貨款", "少工錢"
CARGO = {LOSE_CARGO: 300, LOSE_PAY: 150}   # 16o 第 8、9 題：走鏢賠 3 個月工錢、雇主少給一半，× 2 的境界次方，賠到 0 為止
MONEY_RATE = 10               # 與 items.RATE 相同
JOIN = "入門"                 # 16h：應對成功就入門（入門考核由 service 照 domain/sect.py 處理，這裡不給東西）
STONES = (2, 4)               # × 2 的境界次方：凡人 2～4、築基 8～16；失去的是一半
INSIGHT = (3, 8)              # 修為（小境界內的百分比）
HURT_SHARE = 0.1              # 最多扣一成氣血，不致瀕死
DAILY_FLOOR = 0.3             # 日常小傷（奔波疲憊）最多扣到三成，不會卡在不能衝關（16m 第 6 題）

KNOWN, NEW = "認識的人", "新面孔"   # 牽涉誰：在場的熟人、安排新人物登場
WORLD, TIANDAO = "世界", "天道"     # 來源


@dataclass(frozen=True)
class Seed:
    """事件骨架。answer 空＝當下型（now 是當場的結果）；有＝應對型（win／lose 是下一回合判定成敗的結果）。
    scene 裡的 {who} 換成牽涉的人。where：只在這些地點類型發生（空＝哪裡都行）。
    第 9b 步：days／state＝留在地點上的狀況與天數（事件發生時就開始）；
    thread＝（線頭種類, 文字, 期限）：當下型當場開，應對型應對成功才開；文字裡的 {me} 換成主角。
    第 8b 步：item＝（物品名或種類, 最少, 最多），結果是 GAIN_ITEM 時給這個。"""
    kind: str
    name: str
    scene: str
    answer: tuple[str, ...] = ()
    win: str = ""
    lose: str = ""
    now: str = ""
    who: str = ""
    needs_sect: bool = False
    season: str = ""
    where: tuple[str, ...] = ()
    days: int = 0
    state: str = ""
    thread: tuple[str, str, str] = ()
    item: tuple = ()
    base: str = ""   # 16p：世界的新事件借的底（事件表裡的名字）；基本款是空的
    land: str = ""   # 16u 第 7 題：只在這一族的地盤發生；空＝三族都有
    alien: bool = False   # 16u 第 7 題：主角在外族地盤、又看得出來時才發生
    card: deck.Card | None = None   # 第 4-2 題：encounters.txt 的那一行，choose 用它的條件篩


def _seed(c: deck.Card) -> Seed:
    """encounters.txt 的一行 → 骨架。"""
    answer, days, state, thread, item, _ = c.more
    need, res = dict(c.need), dict(r.split(":") for r in deck.bare(c.result).split())
    return Seed(c.kind, c.name, c.text, _list(answer), res.get("成", ""), res.get("敗", ""), res.get("當場", ""),
                c.target, "宗門" in need, need.get("季節", ""), _list(need.get("地點", "")), int(days or 0), state,
                tuple(thread.split("／")) if thread else (),
                tuple(int(x) if x.isdigit() else x for x in item.split("／")) if item else (),
                "", need.get("族", ""), "外族" in need, c)


# 底空的是遭遇本身；有底的是「換句話說」，開新世界時放進世界清單（game/rules.py）
SEEDS = tuple(_seed(c) for c in deck.read(CONTENT / "encounters.txt") if not c.more[-1])


def chance(action: str, *, retreating: bool, dying: bool, last_had: bool, quiet: int, trip_km: int = 0) -> float:
    """這回合有事件的機率。戰鬥、衝擊瓶頸、瀕死、閉關中不發生。quiet：之前連續幾回合沒事。
    trip_km：這回合走了多遠（0＝沒移動），移動的回合照路程乘上倍數。"""
    base = 0.0 if (retreating and action != J.WORK) or dying else CHANCE.get(action, 0.0)
    odds = base * AFTER_ONE if not base or last_had else base + min(QUIET_MAX, QUIET_STEP * quiet)
    if not trip_km:
        return odds
    return odds * next((x for km, x in ROAD_ODDS.items() if trip_km <= km), ROAD_ODDS[max(ROAD_ODDS)])


def routine_chance(months: float, monthly: float = ROUTINE_MONTHLY) -> float:
    """日常面板做了這麼多個月，途中遇到事的機率（閉關也算）；monthly：每月機率（營生各不同，16o）。"""
    return min(ROUTINE_CAP, 1 - (1 - monthly) ** months)


def choose(rng: random.Random, *, realm_lv: int, place_type: str, season: str, known_here: bool, sect_near: bool,
           can_add: bool, active: frozenset[str] = frozenset(), only: str = "",
           boost: dict | None = None, new: tuple | list = (), land: str = "人族", stranger: bool = False) -> Seed | None:
    """先按權重抽種類（地點、季節對得上加權），再從那一類用得上的骨架裡抽一個。都用不上回傳 None。
    active：此地還在持續的狀況（事件名稱），同一件不會再發生一次。only：只挑這一類，不看境界（移動、走鏢、打獵）。
    boost：天變、命途讓某些種類比較常發生（16j；16g，origins.kind_boost）。new：世界的新事件（16p），抽到那一類時兩成改用。
    land：這裡是哪一族的地盤；stranger：主角在外族地盤又看得出來（16u 第 7 題）。"""
    kinds = (only,) if only else tuple(k for k, v in KINDS.items() if realm_lv in v.realms)
    facts = {"地點": (place_type,), "季節": (season,), "宗門": ("近",) * sect_near, "族": (land,),
             "外族": ("是",) * stranger, "目標": (KNOWN,) * known_here + (NEW,) * can_add}

    def fits(s: Seed) -> bool:
        return s.kind in kinds and s.name not in active and deck.fits(s.card, facts)

    usable = [s for s in SEEDS if fits(s)]
    weights = {k: KINDS[k].weight * (PLACE_BOOST if place_type in KINDS[k].places else 1)
               * (SEASON_BOOST if season in KINDS[k].seasons else 1) * (boost or {}).get(k, 1)
               for k in {s.kind for s in usable}}
    if not weights:
        return None
    kinds = sorted(weights)   # 固定順序：同一個種子抽到同一件
    kind = rng.choices(kinds, weights=[weights[k] for k in kinds])[0]
    fresh = [s for s in new if s.kind == kind and fits(s)]
    return rng.choice(fresh if fresh and rng.random() < NEW_SHARE else [s for s in usable if s.kind == kind])


# 世界的新事件（16p，數字暫定）：借一個底，類別、應對方式、獎懲全部照底，只換名字與場景
NEW_SHARE, ASK_SHARE, SHOWN_BASES = 0.2, 0.1, 4
SCENE_LEN = (10, 80)
BASES = {s.name: s for s in SEEDS if JOIN not in (s.win, s.now) and not s.state and not s.days
         and not s.land and not s.alien}


def bases(rng: random.Random) -> tuple[Seed, ...]:
    """這回合請說書人寫新事件時給的底；空＝這回合不請。"""
    return tuple(rng.sample(list(BASES.values()), SHOWN_BASES)) if rng.random() < ASK_SHARE else ()


def from_row(row: dict) -> Seed:
    """資料庫裡的新事件 → 骨架。"""
    return dataclasses.replace(BASES[row["base"]], name=row["name"], scene=row["scene"], base=row["base"])


def possible(action: str, *, retreating: bool, dying: bool) -> bool:
    """這回合可不可能有事件（天道落子也照這個，第 18-2a 步）。"""
    return chance(action, retreating=retreating, dying=dying, last_had=False, quiet=0) > 0


def record(seed: Seed, who: str = "", source: str = WORLD, game: str | None = None) -> dict:
    """記進回合紀錄的事件（不另存一份）：下一回合要結算應對時讀這裡。"""
    return {"kind": seed.kind, "name": seed.name, "answer": list(seed.answer), "win": seed.win, "lose": seed.lose,
            "now": seed.now, "who": who, "thread": list(seed.thread), "source": source, "game": game,
            "item": list(seed.item), "base": seed.base}


def valid_record(rec) -> bool:
    """存檔裡回合紀錄的世界事件（匯入時檢查，下一回合結算要讀它）：除了牽涉誰，其他欄位都要跟事件表一致。
    第 9a 步的紀錄沒有 thread、item，缺了就當作事件表的值；經濟第二輪以前，凡人的事記的是得、失靈石；
    16h 以前，宗門考核過了是得靈石。"""
    base = rec.get("base") if isinstance(rec, dict) else ""
    seed = next((s for s in SEEDS if isinstance(rec, dict) and s.name == (base or rec.get("name"))), None)
    if seed is None or not isinstance(rec.get("who"), str) or not isinstance(rec.get("name"), str):
        return False
    expected = record(seed, rec["who"], WORLD)
    if base:   # 16p：世界的新事件，只有名字和底不同
        expected = {**expected, "name": rec["name"], "base": base}
    old = {(GAIN_STONES, GAIN_MONEY), (LOSE_STONES, LOSE_MONEY), (GAIN_STONES, JOIN)}
    return set(rec) <= set(expected) and all(
        rec.get(k, v) == v or isinstance(rec.get(k), str) and (rec[k], v) in old for k, v in expected.items())


def scene(seed: Seed, who: str = "") -> str:
    return seed.scene.replace("{who}", who)


def place_state(seed: Seed, rec: dict, *, place: str, clock_now: int) -> dict | None:
    """留在地點上的狀況（第 9b 步）：誰到那裡都看得到，時間到自動消失。這件事沒有就回傳 None。"""
    if not seed.days:
        return None
    return {"place": place, "name": seed.name, "text": seed.state, "source": rec["source"], "game": rec["game"],
            "started_shichen": clock_now, "ends_shichen": clock_now + seed.days * SHICHEN_PER_DAY}


def thread(rec: dict, *, me: str, place: str, clock_now: int, turn_no: int) -> dict | None:
    """事件開的線頭（第 9b 步），之後照線頭的規則逾期、提醒、結線。有牽涉的人就綁在他身上，否則綁在地點。"""
    if not rec.get("thread"):   # 第 9a 步的回合紀錄沒有這一欄
        return None
    kind, text, deadline = rec["thread"]
    who = rec["who"]
    if kind in m.PROMISES and not who:
        return None
    span = m.DEADLINES[deadline]
    return {"kind": kind, "subject_kind": m.NPC if who else m.PLACE, "subject": who or place,
            "text": text.replace("{who}", who).replace("{me}", me), "status": m.OPEN,
            "deadline_shichen": None if span is None else clock_now + span,
            "opened_shichen": clock_now, "opened_turn": turn_no, "touched_shichen": clock_now, "origin": ""}


def answered(rec: dict | None, verdict: J.Judgment) -> bool | None:
    """上回合的應對型事件這回合有沒有應對：行動類型對得上 → 判定成功 True、失敗 False；對不上（放過）None，
    走鏢、打獵的事放過算失敗（16o 第 7 題）。"""
    if not rec or not rec["answer"]:
        return None
    if verdict.action_type not in rec["answer"] or not verdict.rolled:
        return False if rec["kind"] in (ESCORT, HUNT) else None
    return verdict.outcome in (J.SUCCESS, J.GREAT_SUCCESS)


def amounts(result: str, sheet: dict, rng: random.Random, floor: float = 0, hurt: int = 0) -> dict[str, int]:
    """結果換成角色卡的增減，依境界分級。受傷最多一成氣血，不會把氣血扣到 0；
    floor：最多扣到氣血上限的這個比例（日常小傷 DAILY_FLOOR，16m 第 6 題）；
    hurt：應對時判定已經造成的傷，事件只補不足的部分（16o 第 10 題）。好感由遊戲流程處理。"""
    lv = sheet["realm_lv"]
    if result in CARGO:
        return {"money": -min(sheet["money"], CARGO[result] * 2 ** lv)}
    if result in (GAIN_STONES, LOSE_STONES, GAIN_MONEY, LOSE_MONEY):
        field, rate = ("spirit_stones", 1) if result in (GAIN_STONES, LOSE_STONES) else ("money", MONEY_RATE)
        amount = rng.randint(*STONES) * 2 ** lv * rate
        return {field: amount} if result in (GAIN_STONES, GAIN_MONEY) else {field: -min(sheet[field], amount // 2)}
    if result == GAIN_CULTIVATION:
        return {"cultivation": rng.randint(*INSIGHT)}
    if result == LOSE_HP:
        keep = max(1, round(sheet["hp_max"] * floor))
        return {"hp": -max(0, min(max(1, round(sheet["hp_max"] * HURT_SHARE)) - hurt, sheet["hp"] - keep))}
    return {}
