"""天道的眼睛與聲音（第 18-1 步）：天道注視、甦醒階段、人格卡、出聲時機與台詞驗證。純函式。

規則（2026-10-06 與使用者一題一題定案，見 progress/WHITEPAPER.md 第 13 節「第 18-1 步」，數字暫定）：
- 注視 0–100，每一生各一份。只算 Python 看得到的事：突破大境界、頓悟、以代價換命、殺死境界比自己高的人、
  參悟碰到天道鎖定的系；諸天異端開局 20 且不降到 20 以下。時間回落：每月 −1，閉關期間每月 −2。
- 甦醒階段由境界決定，注視 80 以上提前一階。玩家看不到數字，只看到一句感受。
- 沉默階段完全不出聲；第一次開口＝進到看螻蟻的那一刻。之後在突破大境界、瀕死、殞落、坐化時出聲，一回合最多一次。
- 人格卡：建立世界時擲來歷、個性、說話風格、執念；第一次開口時請 AI 潤色一次，審核不過就永遠用條列。
  執念在意的那一類注視 ×1.5。看螻蟻階段的態度由個性決定。
- 第 18-2a 步：棋局分勝負那回合開口揭曉（排在殞落之後）；這一生勝負差 3 盤以上，態度改成忌憚或輕蔑。棋局本身在 games.py。
"""
from __future__ import annotations

import re

from .clock import SHICHEN_PER_MONTH, SHICHEN_PER_YEAR

# ── 注視 ───────────────────────────────────────────────────────────────────
BREAK, INSIGHT, PRICE, SLAY, LOCKED = "突破", "頓悟", "代價", "殺上", "鎖定"   # 注視的來源
FORCE = "強拆"                           # 16l 第 6-6 題：強行打散怪談
ROUTE = "解局"                           # 16v 第 7 題：解掉天道發的路線
GAIN = {INSIGHT: 3, PRICE: 5, LOCKED: 2, FORCE: 3, ROUTE: 3}
BREAK_PER_LV, FAST_BONUS = 3, 5          # 突破：新境界 × 3；在原境界待不到 1 年再 +5
SLAY_PER_LV = 5                          # 殺死境界比自己高的人：每差一個大境界 +5
MAX_GAZE, HERETIC_GAZE, AWAKE_AT = 100, 20, 80
COOL, RETREAT_COOL = 1, 2                # 每月回落；閉關期間
OBSESSION_FACTOR = 1.5

# ── 甦醒階段 ───────────────────────────────────────────────────────────────
STAGES = ("沉默", "看螻蟻", "警覺", "棋子", "對手")
STAGE_FROM_LV = (0, 0, 0, 1, 1, 1, 2, 2, 3, 3, 4)   # 境界 Lv0–10；更高一律是對手
FEELINGS = ("天地無感", "偶覺冥冥中有目光掠過", "如芒在背", "天威壓頂")
FEELING_FROM = (20, 50, 80)              # 注視到這些值，感受往上一段
AWAKE_POINTS = ("", "第一次注意到主角", "開始警覺主角可能壞了它的局", "想收編主角為己所用", "第一次把主角當成對面的棋手")
STAGE_ATTITUDES = ("", "", "警覺", "想收編你", "當成對手")   # 看螻蟻階段由個性決定
SCORE_SWING = 3                          # 這一生勝負差到 3 盤，態度改成忌憚或輕蔑（第 18-2a 步）

# ── 人格卡素材（使用者 2026-10-06：先照草稿）───────────────────────────────
ORIGINS = ("以劍證道的劍修，一劍斬斷舊天", "丹道宗師，以萬靈為藥、天地為爐", "上古巫祝，以血祭換得天命",
           "凡人帝王，以人間秩序壓過眾神", "隱世散修，獨行千年，無師無友", "魔道巨擘，屠盡同代才登天位",
           "苦行僧人，坐化前一念成天", "陣法宗師，把天地布成一局棋")
TEMPERS = {"冷峻、重規矩": "輕蔑", "慵懶而好奇": "興味", "傲慢、視眾生如塵": "輕蔑", "悲憫卻無情": "興味",
           "多疑、善算計": "輕蔑", "暴烈易怒": "輕蔑", "寂寞而話少": "興味", "戲謔、愛捉弄人": "興味"}
STYLES = ("句子極短", "愛用反問", "喜歡拿棋局作比喻", "文言濃、愛引古語", "像長輩訓誡晚輩",
          "自言自語，不直接對你說", "語帶笑意", "只陳述，從不評價")
OBSESSIONS = {"秩序": LOCKED, "輪迴": PRICE, "尊卑": SLAY, "天機": INSIGHT, "循序": BREAK}

# ── 台詞與潤色的驗證 ───────────────────────────────────────────────────────
LINE_MAX, LINE_SENTENCES = 80, 3
POLISH_MIN, POLISH_MAX = 80, 200
_DIGIT = re.compile(r"[0-9０-９]")
_DECLARE = re.compile(r"你(獲得|得到|失去|損失|增加|減少)")


def fields(heretic: bool = False) -> dict:
    """角色卡的天道欄位（每一生各一份）：注視、進入目前大境界的時間、天道已開口過的最高階段、
    收下天道之餌的時間（欠天道一手，第 18-2a 步；None＝沒有）。"""
    return {"gaze": float(HERETIC_GAZE if heretic else 0), "realm_since": None, "heaven_seen": 0, "debt": None}


def stage(lv: int, gaze: float) -> int:
    """甦醒階段（STAGES 的索引）：境界決定，注視 80 以上提前一階。"""
    base = STAGE_FROM_LV[min(lv, len(STAGE_FROM_LV) - 1)]
    return min(len(STAGES) - 1, base + (gaze >= AWAKE_AT))


def feeling(sheet: dict) -> str:
    """面板上的一句感受：依注視分四段，甦醒到看螻蟻以上再往上提一段。"""
    band = sum(sheet["gaze"] >= v for v in FEELING_FROM) + (stage(sheet["realm_lv"], sheet["gaze"]) >= 1)
    return FEELINGS[min(band, len(FEELINGS) - 1)]


def breakthrough_gain(lv: int, since: int | None, now: int) -> int:
    """突破到 lv 加多少注視：新境界 × 3，在原境界待不到 1 年再 +5（舊角色沒有紀錄就不加）。"""
    fast = since is not None and now - since < SHICHEN_PER_YEAR
    return lv * BREAK_PER_LV + (FAST_BONUS if fast else 0)


def slay_gain(their_lv: int, my_lv: int) -> int:
    return max(0, their_lv - my_lv) * SLAY_PER_LV


def watch(sheet: dict, card: dict, marks: list[tuple[str, int]], shichen: int, retreat: bool) -> dict:
    """一回合結束：先依經過的時間回落，再加上這回合的事（執念在意的 ×1.5）。marks：[(來源, 點數)]。"""
    months = shichen / SHICHEN_PER_MONTH
    gaze = sheet["gaze"] - months * (RETREAT_COOL if retreat else COOL)
    care = OBSESSIONS.get(card.get("obsession"))
    gaze += sum(points * (OBSESSION_FACTOR if source == care else 1) for source, points in marks)
    floor = HERETIC_GAZE if sheet["heretic"] else 0
    return {**sheet, "gaze": round(max(floor, min(MAX_GAZE, gaze)), 2)}


# ── 出聲 ───────────────────────────────────────────────────────────────────
def occasion(before: dict, after: dict, aged: bool, reveal: str = "", retired: bool = False) -> tuple[str, str]:
    """這回合天道要不要出聲：回傳（時機, 要點），不出聲回傳 ("", "")。aged：壽元耗盡（坐化）。
    reveal：這回合分出勝負的棋局（第 18-2a 步，例「心魔之局，主角勝」）；retired：主角退隱（第 11-1 步）。
    沉默階段一律不出聲；優先順序：殞落、坐化、退隱 > 揭曉 > 甦醒程度改變 > 瀕死 > 突破大境界。"""
    now = stage(after["realm_lv"], after["gaze"])
    if now == 0:
        return "", ""
    if after["status"] == "FALLEN":
        if after.get("erased"):   # 16l：破格期的倒數到了
            return "抹殺", "主角撐不過抹殺之劫，被天道親手抹去"
        return ("坐化", "主角壽元耗盡，坐化") if aged else ("殞落", "主角殞落")
    if retired:
        return "退隱", "主角退隱，自己走下了棋盤"
    if reveal:
        return "揭曉", f"揭曉這一局是它的安排：{reveal}"
    if now > after["heaven_seen"]:
        return "甦醒", AWAKE_POINTS[now]
    if after.get("breach") and not before.get("breach"):   # 16l 第 2 題：照人格開口——你該走了
        return "破格", "主角踏入破格期，這方天地開始排斥他；三百年內不走，天道必親自抹殺"
    if before["status"] == "ALIVE" and after["status"] == "DYING":
        return "瀕死", "主角瀕死，生死一線"
    if after["realm_lv"] > before["realm_lv"]:
        return "突破", "主角剛突破大境界"
    return "", ""


def seen(sheet: dict, when: str) -> dict:
    """天道因甦醒程度改變而開口：記下已經開口過的階段（同一階段只說一次「注意到你」）。"""
    return {**sheet, "heaven_seen": stage(sheet["realm_lv"], sheet["gaze"])} if when == "甦醒" else sheet


def attitude(card: dict, lv: int, gaze: float, score: tuple[int, int] = (0, 0)) -> str:
    """看螻蟻階段：這一生勝比負多 3 盤以上＝忌憚、負比勝多 3 盤以上＝輕蔑，其餘照個性（第 18-2a 步）。"""
    now = stage(lv, gaze)
    if now != 1:
        return STAGE_ATTITUDES[now]
    lead = score[0] - score[1]
    return "忌憚" if lead >= SCORE_SWING else "輕蔑" if lead <= -SCORE_SWING else TEMPERS[card["temper"]]


def roll_card(rng) -> dict:
    """建立世界時擲人格卡。text：AI 潤色的人設（空＝用條列）；polished：已經請 AI 潤色過（不論成敗都不再請）。"""
    return {"origin": rng.choice(ORIGINS), "temper": rng.choice(list(TEMPERS)), "style": rng.choice(STYLES),
            "obsession": rng.choice(list(OBSESSIONS)), "text": "", "polished": False}


def card_lines(card: dict) -> str:
    return (f"來歷：{card['origin']}；個性：{card['temper']}；說話風格：{card['style']}；"
            f"執念：{card['obsession']}（最在意世人{OBSESSIONS[card['obsession']]}之事）")


def card_text(card: dict) -> str:
    """給說書人的人設：有潤色過的就用潤色，否則用條列。"""
    return card["text"] or card_lines(card)


def voice_task(card: dict, lv: int, gaze: float, point: str, score: tuple[int, int] = (0, 0), record: str = "") -> str:
    """【天道開口】的內容：人設、態度、要點（附這一生的戰績）與寫法限制。"""
    return (f"這回合天道會開口，寫在 heaven 欄位：1 到 {LINE_SENTENCES} 句、{LINE_MAX} 字以內，不寫數字，"
            f"不宣告主角獲得或失去任何東西，不改變任何事實。天道是上一個紀元的勝天者。"
            f"人設：{card_text(card)}。態度：{attitude(card, lv, gaze, score)}。要點：{point}"
            + (f"（{record}）" if record else "") + "。")


def check_line(text: str) -> str:
    """驗證天道的台詞，合格回傳整理過的台詞，不合格回傳空字串（這回合就不出聲）。"""
    text = (text or "").strip().removeprefix("【天道】").strip()
    sentences = [s for s in re.split(r"[。！？!?]", text) if s.strip()]
    if not text or len(text) > LINE_MAX or len(sentences) > LINE_SENTENCES or _DIGIT.search(text) \
            or _DECLARE.search(text):
        return ""
    return text


def check_polish(text: str) -> str:
    """驗證 AI 潤色的人設：長度 80–200 字、不得含數字。不合格回傳空字串（永遠用條列）。"""
    text = (text or "").strip()
    return text if POLISH_MIN <= len(text) <= POLISH_MAX and not _DIGIT.search(text) else ""


def valid_card(card) -> bool:
    return (isinstance(card, dict) and card.get("origin") in ORIGINS and card.get("temper") in list(TEMPERS)
            and card.get("style") in STYLES and card.get("obsession") in list(OBSESSIONS)   # list：不可雜湊的值也不會出錯
            and isinstance(card.get("polished"), bool) and isinstance(card.get("text"), str)
            and (card["text"] == "" or check_polish(card["text"]) == card["text"]))


def valid(sheet: dict) -> bool:
    gaze, seen = sheet["gaze"], sheet["heaven_seen"]
    return (isinstance(gaze, (int, float)) and not isinstance(gaze, bool) and 0 <= gaze <= MAX_GAZE
            and _moment(sheet["realm_since"]) and _moment(sheet["debt"])
            and isinstance(seen, int) and not isinstance(seen, bool) and 0 <= seen < len(STAGES))


def _moment(value) -> bool:
    """時間欄位：None 或整數時辰。"""
    return value is None or (isinstance(value, int) and not isinstance(value, bool))
