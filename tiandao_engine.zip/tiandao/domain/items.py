"""物品與經濟（第 8 步）：物品表、身上的物品、商店、服用丹藥、符籙與法器的判定加成。純函式。

規則（2026-10-05 與使用者一題一題定案，見 progress/WHITEPAPER.md 第 16 節，數字暫定）：
- 只有這張 Python 物品表；商店、獎勵都從表裡出，AI 只描寫。
- 經濟第二輪（WHITEPAPER 16.1）：坊市收靈石，其他店收凡人錢（× RATE × 地點倍率）；藥鋪、鐵匠鋪、當鋪開店，當鋪能換錢。
- 品階＝適用境界。價格：基本價 × 2 的品階次方，賣出拿一半。
  高品階的低境界不能用；低品階給高境界用，每差一級效果減半。
- 買賣、服用不算回合、不呼叫 AI；做過的事記在角色卡，下一回合交給說書人當事實。
- 同一種丹藥一回合只能吃一顆（丹毒未化）。
- 功法（第 3b-1 步）：品階固定，每本帶 1～2 系親和（domain/laws.py 用）；同時只主修一本，「修習」就換。
  人人都會的《吐納法》是預設的主修（沒有親和，不佔背包）；主修中的功法不能賣。
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

from ..errors import BadRequest, Conflict
from . import form, identity, market, races, realm
from .judgment import (COMBAT, DISCOVER, ENDURE, ESCAPE, EXPLORE, HIDE, ORIENT, PERSUADE, PRY, SOCIAL, STRIKE, TARGET_ATTRS,
                       WITHSTAND)
from .status import NEGATIVE

PILL, TALISMAN, ARTIFACT, MATERIAL, TECHNIQUE, CONTRABAND = "丹藥", "符籙", "法器", "靈材", "功法", "違禁品"
HEAL_PILL, QI_PILL, LIFE_PILL, BREAK_PILL, CALM_PILL = "回氣丹", "聚氣丹", "續命丹", "破境丹", "清心丹"
MASK_PILL = "易容丹"
RARE_PILL, FORM_PILL = "秘藥", "化形丹"   # 秘藥不算一般丹藥：一般的店不賣，隨機也不掉（16u 族徵第 6 題）
GUARD_TALISMAN = "護身符"
BASIC_TECHNIQUE = "吐納法"
PAPERS = "假路引"
HERB, ORE = "藥材", "器材"


@dataclass(frozen=True)
class Item:
    name: str
    kind: str
    price: int                                  # 凡人級的基本價（靈石）
    bonus: dict = field(default_factory=dict)   # 判定加成：標的 → 點數（符籙、法器）
    affinity: tuple = ()                        # 功法親和的法則系
    tier: int | None = None                     # 品階固定（功法）；None＝什麼品階都有
    group: str = ""                             # 靈材分藥材（煉丹）、器材（煉器），第 3b-3 步
    rite: str = ""                              # 違禁品：施這種邪術時，那次判定每個標的都加 RITE_BONUS（16i）
    side: str = ""                              # 功法的正邪：正、邪、中（16i 第 10-10 題；不影響善惡）
    breaker: bool = False                       # 破境道具：用上時境界差少算一級（16l 第 6-2 題）


CATALOG = {i.name: i for i in (
    Item(HEAL_PILL, PILL, 6),                      # 回三成氣血
    Item(QI_PILL, PILL, 10),                       # 修為加一小段
    Item(LIFE_PILL, PILL, 20),                     # 瀕死時減輕傷勢
    Item(BREAK_PILL, PILL, 30),                    # 衝擊瓶頸時算一個契機（breakthrough.PILL_BONUS），自動用掉
    Item(CALM_PILL, PILL, 12),                     # 解除最重的一個負面狀態（經濟第二輪）
    Item(MASK_PILL, PILL, 15),                     # 易容 7 天（身分與追捕，domain/identity.py）
    Item(FORM_PILL, RARE_PILL, 40, tier=0),        # 獸族暫時化形 3 天（domain/form.py）
    Item("疾行符", TALISMAN, 5, {ESCAPE: 15}),
    Item("隱身符", TALISMAN, 5, {HIDE: 15}),
    Item(GUARD_TALISMAN, TALISMAN, 5),             # 這次判定受的傷減半
    Item("雷火符", TALISMAN, 5, {STRIKE: 15}),
    Item("定心符", TALISMAN, 5, {WITHSTAND: 15}),
    Item("引路符", TALISMAN, 5, {ORIENT: 15}),
    Item("精鐵短刀", ARTIFACT, 25, {STRIKE: 5}),
    Item("明目鏡", ARTIFACT, 25, {DISCOVER: 5}),
    Item("護心鏡", ARTIFACT, 25, {WITHSTAND: 5}),
    Item("輕身靴", ARTIFACT, 25, {ESCAPE: 5}),
    Item("斂息珮", ARTIFACT, 25, {HIDE: 5}),
    Item("羅盤", ARTIFACT, 25, {ORIENT: 5}),
    Item("靈草", MATERIAL, 2, group=HERB),          # 靈材：商店不賣；可以賣，也可以拿來煉丹、煉器
    Item("妖丹", MATERIAL, 6, group=HERB),
    Item("獸骨", MATERIAL, 5, group=ORE),
    Item("靈礦", MATERIAL, 8, group=ORE),
    Item(BASIC_TECHNIQUE, TECHNIQUE, 0, tier=0),   # 預設的主修，不會出現在背包、商店、戰利品
    Item("烈陽訣", TECHNIQUE, 20, affinity=("火系", "光系"), tier=1, side="正"),   # 武者級 40 靈石，坊市有賣
    Item("玄水訣", TECHNIQUE, 20, affinity=("水系", "冰系"), tier=1, side="中"),
    Item("厚土訣", TECHNIQUE, 20, affinity=("土系", "金系"), tier=1, side="正"),
    Item("青木訣", TECHNIQUE, 20, affinity=("木系", "生系"), tier=1, side="正"),
    Item("驚雷訣", TECHNIQUE, 20, affinity=("雷系", "風系"), tier=1, side="中"),
    Item("幽影訣", TECHNIQUE, 20, affinity=("暗系", "毒系"), tier=1, side="邪"),
    Item("觀心訣", TECHNIQUE, 30, affinity=("神系", "情系"), tier=2, side="中"),   # 築基級 120，只從戰利品來
    Item("縮地訣", TECHNIQUE, 30, affinity=("空系",), tier=2, side="中"),
    # 違禁品（16i 第 10-14 題，progress/CONTRABAND.md）：只在黑市買賣；跟符籙一樣在行動裡點名、用掉一個
    Item("迷魂香", CONTRABAND, 8, {PERSUADE: 15, PRY: 15}, tier=0),
    Item("鶴頂紅", CONTRABAND, 10, {STRIKE: 15}, tier=0, breaker=True),
    Item(market.TOKEN, CONTRABAND, 20, tier=0),    # 修士黑市的門路（16l 第 6-4 題），帶著就有效
    Item(PAPERS, CONTRABAND, 15, tier=0),         # 直接使用：7 天內追捕者找不到你、易容破了也不算易容入城
    Item("百寶囊", CONTRABAND, 6, {HIDE: 15}, tier=0),
    Item("黑火藥", CONTRABAND, 12, {STRIKE: 20}, tier=1, breaker=True),
    Item("假腰牌", CONTRABAND, 15, {PERSUADE: 15}, tier=1),
    Item("招魂幡", CONTRABAND, 20, tier=2, rite="招魂"),
    Item("屍油", CONTRABAND, 15, tier=2, rite="煉屍"),
    Item("血煞陣盤", CONTRABAND, 30, tier=3, rite="血祭"),
    Item("噬靈散", CONTRABAND, 15, {STRIKE: 15}, tier=2, breaker=True),
    Item("斂魂符", CONTRABAND, 10, {HIDE: 15}, tier=2),
    Item("搜魂釘", CONTRABAND, 30, {PRY: 25}, tier=3),
)}
RITE_BONUS = 15
ERA_NAMES = {   # 凡人違禁品依時代換名（修士的東西不換名）
    "迷魂香": {"現代": "迷藥", "未來": "神經抑制劑"}, "鶴頂紅": {"現代": "氰化物", "未來": "神經毒素"},
    PAPERS: {"現代": "假證件", "未來": "偽造身分晶片"}, "百寶囊": {"現代": "開鎖工具", "未來": "電子解碼器"},
    "黑火藥": {"現代": "炸藥", "未來": "電漿炸彈"}, "假腰牌": {"現代": "假警徽", "未來": "偽造執法令"}}
TIER_LABELS = {0: "凡人級", 1: "武者級", 2: "築基級", 3: "金丹級", 4: "元嬰級"}   # 品階＝適用境界；做到元嬰

HEAL_RATIO = 0.3          # 回氣丹：回三成氣血上限
PILL_CULTIVATION = 15     # 聚氣丹：修為 +15（一個小境界 100）
LIFE_PILL_WOUND = 25      # 續命丹：傷勢 −25
MAX_COUNT = 99            # 一次最多買賣幾個
MAX_NOTES = 10            # 角色卡最多留幾則還沒交給說書人的紀錄


def _of_kinds(*kinds: str) -> tuple[str, ...]:
    return tuple(i.name for i in CATALOG.values() if i.kind in kinds)


def tiers_of(name: str) -> tuple[int, ...]:
    fixed = CATALOG[name].tier
    return tuple(TIER_LABELS) if fixed is None else (fixed,)


# 世界長出來的新物品（16p，數字暫定）：借一個底的效果與價格，新名字只是叫法，背包仍以底計算
BASES = _of_kinds(PILL, TALISMAN, ARTIFACT, MATERIAL)
BASE_KINDS = {EXPLORE: (MATERIAL, PILL), COMBAT: (ARTIFACT, TALISMAN), SOCIAL: (PILL, TALISMAN, ARTIFACT)}   # 這種回合給哪幾類當底
SHOWN_BASES = 6
NEW_SHARE = 0.2   # 發物品時兩成改用新物品的叫法
ASK_SHARE = 0.2   # 用得上的回合，兩成請說書人寫一件新物品（第 8 題：不主動要，模型不會用這個欄位）
SHELF = 3         # 一家店最多擺幾件新物品


def bases(rng, action: str) -> tuple[str, ...]:
    """這回合請說書人寫新物品時給的底（第 6 題：只送一小段）；空＝這回合不請。"""
    pool = _of_kinds(*BASE_KINDS.get(action, ()))
    return tuple(rng.sample(pool, min(SHOWN_BASES, len(pool)))) if pool and rng.random() < ASK_SHARE else ()


# 哪裡有店（依地點類型）：賣這些東西；有店的地方都收購。其他地方沒有店
SHOP_TECHNIQUES = tuple(i.name for i in CATALOG.values() if i.kind == TECHNIQUE and i.tier == 1)
STOCK = {"坊市": _of_kinds(PILL, TALISMAN, ARTIFACT) + SHOP_TECHNIQUES, "城鎮": _of_kinds(PILL, TALISMAN),
         "客棧": _of_kinds(PILL, TALISMAN), "村落": (HEAL_PILL,),
         "藥鋪": _of_kinds(PILL), "鐵匠鋪": _of_kinds(ARTIFACT), "當鋪": (),   # 當鋪不賣、什麼都收、能換錢
         # 黑市（16i）：賣違禁品與高一階的丹藥符籙法器；凡人黑市的集團跟本山有私交才有法器（service 另外加）
         market.MORTAL: tuple(i.name for i in CATALOG.values() if i.kind == CONTRABAND and i.tier <= 1)
         + _of_kinds(PILL, TALISMAN, RARE_PILL),
         market.CULTIVATOR: tuple(i.name for i in CATALOG.values() if i.kind == CONTRABAND and i.tier >= 2)
         + _of_kinds(PILL, TALISMAN, ARTIFACT, RARE_PILL)}
FORM_SHOPS = ("藥鋪", "坊市")   # 獸族地盤的這兩種店賣化形丹，人族地盤買不到
# 凡人錢（經濟第二輪，WHITEPAPER 16.1）：坊市收靈石，其他有店的地方收凡人錢（靈石價 × RATE × 地點倍率）
STONES, MONEY = "spirit_stones", "money"
RATE = 10                                  # 1 靈石＝10 凡人錢；當鋪照這個換，不收手續費
MARKUP = {"客棧": 1.2, "村落": 1.5, market.MORTAL: 1.5, market.CULTIVATOR: 1.5}   # 只影響買價
REACH = {market.MORTAL: 2, market.CULTIVATOR: 2}   # 貨架列到境界 +幾（其他店 +1）
SELL_SHARE = {"贓物": 0.7, CONTRABAND: 0.9}        # 黑市收贓物、違禁品的成數（其他東西照常五成）
EXCHANGE = "當鋪"


# ── 價格與效果 ───────────────────────────────────────────────────────────
def price(name: str, tier: int) -> int:
    return CATALOG[name].price * 2 ** tier


def sell_price(name: str, tier: int) -> int:
    return max(1, price(name, tier) // 2)


def coin(place_type: str) -> str:
    """這裡的店收哪一種錢。"""
    return STONES if place_type in ("坊市", market.CULTIVATOR) else MONEY


def local_price(name: str, tier: int, place_type: str, surge: float = 1) -> int:
    """surge：天災期間凡人店漲價（16j）；收靈石的店不受影響。"""
    rate = 1 if coin(place_type) == STONES else RATE * surge
    return round(price(name, tier) * rate * MARKUP.get(place_type, 1))


def local_sell(name: str, tier: int, place_type: str, stolen: bool = False) -> int:
    """黑市收贓物七成、違禁品九成（16i），其他照五成。"""
    share = SELL_SHARE.get(CONTRABAND if CATALOG[name].kind == CONTRABAND else "贓物" if stolen else "", 0) \
        if place_type in market.TYPES else 0
    each = max(1, round(price(name, tier) * share)) if share else sell_price(name, tier)
    return each * (1 if coin(place_type) == STONES else RATE)


def strength(tier: int, realm_lv: int) -> float:
    """效果的比例：品階高於境界不能用（0）；低一級減半、低兩級剩四分之一。"""
    return 0.0 if tier > realm_lv else 0.5 ** (realm_lv - tier)


def label(name: str, tier: int, era_now: str = "") -> str:
    return f"{shown(name, era_now)}（{TIER_LABELS[tier]}）"


def shown(name: str, era_now: str = "") -> str:
    """這個時代的叫法（凡人違禁品，16i）。"""
    return ERA_NAMES.get(name, {}).get(era_now, name)


# ── 身上的物品：[{"name", "tier", "count"}]；贓物另記 stolen：{"名字|品階": 幾個}（16i）────────
def count(sheet: dict, name: str, tier: int) -> int:
    return next((e["count"] for e in sheet["items"] if e["name"] == name and e["tier"] == tier), 0)


def stolen(sheet: dict, name: str, tier: int) -> int:
    return sheet["stolen"].get(f"{name}|{tier}", 0)


def mark_stolen(sheet: dict, name: str, tier: int, n: int) -> dict:
    """搶來、偷來的東西（從別人身上拿到的戰利品）記成贓物。"""
    key = f"{name}|{tier}"
    return {**sheet, "stolen": {**sheet["stolen"], key: min(count(sheet, name, tier), stolen(sheet, name, tier) + n)}}


def _clamp_stolen(sheet: dict, name: str, tier: int, n: int | None = None) -> dict:
    """少了東西：贓物最後才用掉（n＝這次用掉幾個贓物；None＝不超過剩下的數量就好）。"""
    key, left = f"{name}|{tier}", count(sheet, name, tier)
    now = min(left, stolen(sheet, name, tier) - (n or 0))
    return {**sheet, "stolen": {k: v for k, v in {**sheet["stolen"], key: now}.items() if v > 0}}


def add(sheet: dict, name: str, tier: int, n: int = 1) -> dict:
    have = count(sheet, name, tier)
    rest = [e for e in sheet["items"] if not (e["name"] == name and e["tier"] == tier)]
    return {**sheet, "items": rest + [{"name": name, "tier": tier, "count": have + n}]}


def remove(sheet: dict, name: str, tier: int, n: int = 1, alias: str = "") -> dict:
    """alias：用掉的是有這個叫法的那幾個（點名的新物品，第 128-10 題）；沒給就先扣沒有叫法的。"""
    if alias in aka(sheet, name, tier):
        sheet = named(sheet, name, tier, alias, -min(n, aka(sheet, name, tier)[alias]))
    left = count(sheet, name, tier) - n
    rest = [e for e in sheet["items"] if not (e["name"] == name and e["tier"] == tier)]
    sheet = {**sheet, "items": rest + ([{"name": name, "tier": tier, "count": left}] if left > 0 else [])}
    return _clamp_aka(_clamp_stolen(sheet, name, tier) if stolen(sheet, name, tier) else sheet, name, tier)


def aka(sheet: dict, name: str, tier: int) -> dict[str, int]:
    """這一疊裡有叫法的：{"寒潭丹": 2}（16p）。"""
    return sheet["aka"].get(f"{name}|{tier}", {})


def _clamp_aka(sheet: dict, name: str, tier: int) -> dict:
    """少了東西：先扣沒有叫法的，叫法的總數不超過剩下的。"""
    key, left, kept = f"{name}|{tier}", count(sheet, name, tier), {}
    for other, n in aka(sheet, name, tier).items():
        if left > 0 and n > 0:
            kept[other] = min(n, left)
            left -= kept[other]
    rest = {k: v for k, v in sheet["aka"].items() if k != key}
    return {**sheet, "aka": {**rest, key: kept} if kept else rest}


def noted(sheet: dict, *texts: str) -> dict:
    """記下買賣、服用的事，下一回合交給說書人。"""
    return {**sheet, "item_notes": (sheet["item_notes"] + list(texts))[-MAX_NOTES:]}


def new_turn(sheet: dict) -> tuple[dict, list[str]]:
    """回合開始：丹毒化開、交出上回合之後的紀錄。回傳（角色卡, 給說書人的事實）。"""
    facts = [f"上回合之後：{t}" for t in sheet["item_notes"]]
    return {**sheet, "pills_taken": [], "item_notes": []}, facts


def valid(sheet: dict) -> bool:
    """讀檔檢查（character.validate_sheet 呼叫）。"""
    entries = sheet["items"]
    stacks = {f"{e.get('name')}|{e.get('tier')}": e.get("count") for e in entries if isinstance(e, dict)}
    return (isinstance(entries, list)
            and all(isinstance(e, dict) and e.get("name") in CATALOG and _is_tier(e.get("tier"))
                    and e["tier"] in tiers_of(e["name"])
                    and isinstance(e.get("count"), int) and 1 <= e["count"] for e in entries)
            and len({(e["name"], e["tier"]) for e in entries}) == len(entries)
            and isinstance(sheet["pills_taken"], list) and set(sheet["pills_taken"]) <= set(_of_kinds(PILL, RARE_PILL))
            and isinstance(sheet["item_notes"], list) and all(isinstance(t, str) for t in sheet["item_notes"])
            and isinstance(sheet["item_request"], str) and len(sheet["item_request"]) <= 64
            and isinstance(sheet["stolen"], dict) and all(isinstance(v, int) and 1 <= v <= stacks.get(k, 0)
                                                           for k, v in sheet["stolen"].items())
            and isinstance(sheet["aka"], dict) and all(
                isinstance(v, dict) and all(isinstance(n, int) and n >= 1 for n in v.values())
                and sum(v.values()) <= stacks.get(k, 0) for k, v in sheet["aka"].items()))


# ── 買、賣、服用 ─────────────────────────────────────────────────────────
def _unit(field: str, money_name: str) -> str:
    return "靈石" if field == STONES else money_name


def buy(sheet: dict, place_type: str, name, tier, n=1, money_name: str = "銀兩", *, extra: tuple = (),
        fake: bool = False, era_now: str = "", surge: float = 1) -> dict:
    """money_name：這個時代凡人錢的名稱（era.MONEY），只用在紀錄的文字。
    extra：這裡另外有賣的（凡人黑市的法器）；fake：買到假貨（黑市，16i），錢花了、東西沒到手。"""
    if name not in STOCK.get(place_type, ()) + extra or not _is_tier(tier) or tier not in tiers_of(name):
        raise Conflict("這裡買不到這樣東西。", code="not_sold_here")
    n = _amount(n)
    field, unit = coin(place_type), _unit(coin(place_type), money_name)
    cost = local_price(name, tier, place_type, surge) * n
    if sheet[field] < cost:
        raise Conflict(f"{unit}不夠：要 {cost}，身上只有 {sheet[field]}。", code="not_enough_money")
    sheet = {**sheet, field: sheet[field] - cost}
    if fake:
        return noted(sheet, f"花了 {cost} {unit}買{label(name, tier, era_now)}，拿到手才發現是假貨")
    return noted(add(sheet, name, tier, n), f"買了{label(name, tier, era_now)}×{n}，花了 {cost} {unit}")


def sell(sheet: dict, place_type: str, name, tier, n=1, money_name: str = "銀兩", era_now: str = "") -> dict:
    """贓物、違禁品只有黑市收（16i）；黑市先收贓物。"""
    if place_type not in STOCK:
        raise Conflict("這裡沒有店可以收購。", code="no_shop")
    n = _amount(n)
    if not _is_tier(tier) or count(sheet, name, tier) < n:
        raise Conflict("身上沒有這麼多。", code="no_item")
    if name == sheet["technique"]:
        raise Conflict("這是你正在主修的功法，不能賣。", code="cannot_sell")
    black = place_type in market.TYPES
    if not black and (CATALOG[name].kind == CONTRABAND or count(sheet, name, tier) - stolen(sheet, name, tier) < n):
        raise Conflict("這裡不收違禁品、贓物，只有黑市收。", code="cannot_sell")
    hot = min(n, stolen(sheet, name, tier)) if black else 0
    field = coin(place_type)
    gain = local_sell(name, tier, place_type, stolen=True) * hot + local_sell(name, tier, place_type) * (n - hot)
    sheet = _clamp_stolen({**sheet, field: sheet[field] + gain}, name, tier, hot)
    sheet = remove(sheet, name, tier, n)
    return noted(sheet, f"賣了{label(name, tier, era_now)}×{n}，得到 {gain} {_unit(field, money_name)}")


def exchange(sheet: dict, place_type: str, to: str, n=1, money_name: str = "銀兩") -> dict:
    """當鋪換錢：to＝STONES（n 靈石，付 n × RATE 凡人錢）或 MONEY（n 靈石換成凡人錢）。"""
    if place_type != EXCHANGE or to not in (STONES, MONEY):
        raise Conflict("只有當鋪能換錢。", code="no_exchange")
    n = _amount(n)
    pay, get, cost, gain = (MONEY, STONES, n * RATE, n) if to == STONES else (STONES, MONEY, n, n * RATE)
    if sheet[pay] < cost:
        raise Conflict(f"{_unit(pay, money_name)}不夠：要 {cost}，身上只有 {sheet[pay]}。", code="not_enough_money")
    return noted({**sheet, pay: sheet[pay] - cost, get: sheet[get] + gain},
                 f"在當鋪用 {cost} {_unit(pay, money_name)}換了 {gain} {_unit(get, money_name)}")


def use(sheet: dict, name, tier, clock_now: int = 0) -> tuple[dict, dict]:
    """服用丹藥。回傳（角色卡, 要交給 effects.gain 的氣血或修為增減）。續命丹直接減傷勢，清心丹直接解狀態，
    易容丹直接易容（從 clock_now 起算）。"""
    problem = use_problem(sheet, name, tier)
    if problem:
        raise Conflict(problem, code="cannot_use")
    if name == PAPERS:   # 假路引（16i）：不是丹藥，沒有丹毒
        return market.papers(noted(remove(sheet, name, tier), f"帶上了{label(name, tier)}"), clock_now), {}
    power = strength(tier, sheet["realm_lv"])
    sheet = remove({**sheet, "pills_taken": sheet["pills_taken"] + [name]}, name, tier)
    sheet = noted(sheet, f"服下{label(name, tier)}")
    if name == LIFE_PILL:   # 傷勢留在 1 以上：脫離瀕死照舊在下一回合判斷
        return {**sheet, "wound": max(1, sheet["wound"] - round(LIFE_PILL_WOUND * power))}, {}
    if name == CALM_PILL:   # 最重的一個負面狀態（品階不影響：解了就是解了）
        worst = max((s for s in sheet["statuses"] if s["kind"] == NEGATIVE), key=lambda s: s["magnitude"])
        return noted({**sheet, "statuses": [s for s in sheet["statuses"] if s is not worst]},
                     f"「{worst['name']}」化開了"), {}
    if name == MASK_PILL:
        return identity.disguise(sheet, tier, clock_now), {}
    if name == FORM_PILL:
        return form.take(sheet, clock_now), {}
    if name == HEAL_PILL:
        return sheet, {"hp": round(sheet["hp_max"] * HEAL_RATIO * power)}
    return sheet, {"cultivation": round(PILL_CULTIVATION * power)}


def learn(sheet: dict, name, tier) -> dict:
    """修習一本功法＝換成主修。換功法不扣東西；已累積的感悟留著，書上寫的現象記成見過（laws.taught）。"""
    from . import laws   # 放這裡避開循環引用：laws → items
    problem = learn_problem(sheet, name, tier)
    if problem:
        raise Conflict(problem, code="cannot_learn")
    return noted({**sheet, "technique": name, "insight": laws.learn(sheet, name)}, f"改為主修《{name}》")


def learn_problem(sheet: dict, name, tier) -> str:
    if not isinstance(name, str) or name not in CATALOG or CATALOG[name].kind != TECHNIQUE or count(sheet, name, tier) < 1:
        return "身上沒有這本功法。"
    if name == sheet["technique"]:
        return "已經在主修這本功法。"
    if tier > sheet["realm_lv"]:
        return "品階太高，以你的境界參不透。"
    return ""


def use_problem(sheet: dict, name, tier) -> str:
    """不能服用的原因；空字串＝可以。畫面上的按鈕也用這個決定能不能按。"""
    if name not in (HEAL_PILL, QI_PILL, LIFE_PILL, CALM_PILL, MASK_PILL, FORM_PILL, PAPERS) or not _is_tier(tier):
        return "這樣東西不能直接服用。"
    if count(sheet, name, tier) < 1:
        return "身上沒有這樣東西。"
    if name == FORM_PILL and sheet["race"] != races.BEAST:
        return "這是給獸族吃的丹藥。"
    if tier > sheet["realm_lv"]:
        return "品階太高，以你的境界承受不住。"
    if name in sheet["pills_taken"]:
        return "丹毒還沒化開，同一種丹藥這回合不能再吃。"
    if name == CALM_PILL and not any(s["kind"] == NEGATIVE for s in sheet["statuses"]):
        return "身上沒有需要化解的狀態。"
    if name == QI_PILL and realm.at_bottleneck(sheet["realm_lv"], sheet["stage_index"], sheet["cultivation"]):
        return "修為已圓滿，要先衝關。"
    dying = sheet["status"] == "DYING"
    if name == LIFE_PILL and not dying:
        return "續命丹只有瀕死時才能用。"
    if name != LIFE_PILL and dying:
        return "瀕死之身，只能用續命丹。"
    return ""


# ── 判定時的加成 ─────────────────────────────────────────────────────────
@dataclass(frozen=True)
class Gear:
    bonus: dict = field(default_factory=dict)   # 標的 → 成功率加成
    guard: bool = False                         # 護身符：這次判定受的傷減半
    used: tuple = ()                            # 用掉的符籙（名字, 品階）
    breaker: bool = False                       # 用上的是破境道具
    alias: str = ""                             # 點名的是新物品的叫法：用掉那一張（第 128-10 題）
    side: str = ""                              # 那一張的副作用標的


SIDE_SHARE = 0.4   # 模型寫的物品：副作用＝主作用的四成（第 128-10 題甲，暫定）


def _bonus(item: Item, alias: str, perks: dict) -> dict:
    """一件的加成：底的主作用（在產地的地勢用乘倍數），加上零件詞的副作用。perks：newitems.perks 算的。"""
    side, times = perks.get(alias, ("", 1))
    out = {t: p * times for t, p in item.bonus.items()}
    if side and item.bonus:
        out[side] = out.get(side, 0) + max(item.bonus.values()) * SIDE_SHARE
    return out


def gear(sheet: dict, player_input: str, era_now: str = "", perks: dict | None = None) -> Gear:
    """法器帶著就有效（同一種標的取最好的一件；同一疊裡有叫法的各算一件）；
    符籙、違禁品要在行動裡點名（這個時代的叫法、新物品的叫法也算），用掉一個。"""
    lv, bonus, said, perks = sheet["realm_lv"], {}, player_input or "", perks or {}
    for e in sheet["items"]:
        item = CATALOG[e["name"]]
        if item.kind == ARTIFACT:
            for alias in ("", *aka(sheet, e["name"], e["tier"])):
                for target, points in _bonus(item, alias, perks).items():
                    bonus[target] = max(bonus.get(target, 0), int(points * strength(e["tier"], lv)))
    called = {(e["name"], e["tier"]): next((a for a in aka(sheet, e["name"], e["tier"]) if a in said), "") for e in sheet["items"]}
    named = [e for e in sheet["items"] if CATALOG[e["name"]].kind in (TALISMAN, CONTRABAND) and e["tier"] <= lv
             and (e["name"] in said or shown(e["name"], era_now) in said or called[e["name"], e["tier"]])
             and _ready(e["name"], said)]
    if not named:
        return Gear(bonus)
    best = max(named, key=lambda e: e["tier"])
    item, alias = CATALOG[best["name"]], called[best["name"], best["tier"]]
    for target, points in ({t: RITE_BONUS for t in TARGET_ATTRS} if item.rite else _bonus(item, alias, perks)).items():
        bonus[target] = bonus.get(target, 0) + int(points * strength(best["tier"], lv))
    return Gear(bonus, guard=best["name"] == GUARD_TALISMAN, used=(best["name"], best["tier"]), breaker=item.breaker,
                alias=alias, side=perks.get(alias, ("", 1))[0])


def _ready(name: str, said: str) -> bool:
    """點名了也要用得上：邪術的違禁品要真的在施那種邪術（每個標的都加）；假路引是直接使用的。"""
    item = CATALOG[name]
    return item.rite in said.replace(name, "") if item.rite else bool(item.bonus) or name == GUARD_TALISMAN   # 招魂幡≠招魂


def useful(name: str, targets: set[str], action: str, side: str = "") -> bool:
    """點名的符籙這回合用不用得上（用得上才用掉，小修清單第 3 題）：判定裡有它的標的（side：新物品的副作用也算）；
    護身符看有沒有會扣血的判定。"""
    if name == GUARD_TALISMAN:
        return action in (COMBAT, ENDURE) and bool(targets)
    return bool((set(TARGET_ATTRS) if CATALOG[name].rite else {*CATALOG[name].bonus, side}) & targets)


# ── 撿到與戰利品（第 8b 步，WHITEPAPER 第 16 節，數字暫定）──────────────
FOUND_CHANCE, FOUND_PLACES = 0.5, ("荒野", "秘境", "廢墟")   # 探索大成功：一半機率撿到靈材（取代 +10 靈石）
FOUND_WEIGHTS = {"靈草": 5, "獸骨": 3, "靈礦": 2, "妖丹": 2}
LOOT_CHANCE = 0.5                                           # 把對手打到重傷或殞落：一半機率拿到一件
LOOT_WEIGHTS = {HEAL_PILL: 4, TALISMAN: 4, ARTIFACT: 2, TECHNIQUE: 1, "妖丹": 2}   # 物品名，或種類（從那一種裡隨機挑）


def grant(rng, sheet: dict, what: str, tier: int, n: int = 1, world: list | tuple = ()) -> tuple[dict, str]:
    """給一件物品。what：物品名或種類；品階超過物品表的最高品階就用最高的。回傳（角色卡, 給說書人的事實）。
    功法的品階是固定的：從那個品階（至少武者級）的功法裡挑，不會給《吐納法》。
    world：這個世界的新物品（16p）：發到它們的底時，兩成改用它們的叫法。"""
    tier = min(tier, max(TIER_LABELS))
    if what == TECHNIQUE:
        what = technique(rng, tier)
    name = what if what in CATALOG else rng.choice(_of_kinds(what))
    tier = CATALOG[name].tier if CATALOG[name].tier is not None else tier
    sheet, shown_name = add(sheet, name, tier, n), label(name, tier)
    pool = [i["name"] for i in world if i["base"] == name]
    if pool and rng.random() < NEW_SHARE:
        new = rng.choice(pool)
        sheet, shown_name = named(sheet, name, tier, new, n), f"{new}（{TIER_LABELS[tier]}）"
    return sheet, f"得到{shown_name}" + (f"×{n}" if n > 1 else "")


def named(sheet: dict, name: str, tier: int, new: str, n: int) -> dict:
    """這一疊裡 n 個記成新物品的叫法（16p）。"""
    names = {**aka(sheet, name, tier), new: aka(sheet, name, tier).get(new, 0) + n}
    return {**sheet, "aka": {**sheet["aka"], f"{name}|{tier}": names}}


def technique(rng, tier: int) -> str:
    """這個品階（至少武者級）的一部功法。"""
    arts = [i for i in CATALOG.values() if i.kind == TECHNIQUE and i.tier >= 1]
    tier = max((i.tier for i in arts if i.tier <= max(1, tier)), default=1)   # 物品表裡最高只到築基級
    return rng.choice([i.name for i in arts if i.tier == tier])


def lucky_find(rng, place_type: str) -> bool:
    """這回合探索若大成功，會不會撿到靈材（只在荒野、秘境、廢墟）。判定前就擲好，effects 保持純函式。"""
    return place_type in FOUND_PLACES and rng.random() < FOUND_CHANCE


def find(rng, sheet: dict, world: list | tuple = ()) -> tuple[dict, str]:
    return grant(rng, sheet, _weighted(rng, FOUND_WEIGHTS), sheet["realm_lv"], world=world)


def loot(rng, sheet: dict, foe_lv: int, hot: bool = False, world: list | tuple = ()) -> tuple[dict, str] | None:
    """戰利品：品階跟著對手的境界。沒拿到回傳 None。hot：從人身上搶來的，記成贓物（16i）。"""
    if rng.random() >= LOOT_CHANCE:
        return None
    got, fact = grant(rng, sheet, _weighted(rng, LOOT_WEIGHTS), foe_lv, world=world)
    new = next(e for e in got["items"] if e["count"] > count(sheet, e["name"], e["tier"]))
    return (mark_stolen(got, new["name"], new["tier"], 1) if hot else got), fact


def _weighted(rng, weights: dict) -> str:
    return rng.choices(list(weights), weights=list(weights.values()))[0]


def has_breakthrough_pill(sheet: dict) -> bool:
    """破境丹要跟目前境界同品階才算契機。"""
    return count(sheet, BREAK_PILL, sheet["realm_lv"]) > 0


# ── 畫面 ─────────────────────────────────────────────────────────────────
def panel(sheet: dict, place_type: str, era_now: str = "", extra: tuple = (), surge: float = 1,
          world: list | tuple = ()) -> dict:
    """背包與商店面板：身上的東西（能不能服用、賣多少、幾個是贓物、幾個有叫法）、這裡賣什麼、收哪種錢（coin）、能不能換錢。
    extra：這裡另外有賣的（凡人黑市的法器，16i）；world：這個世界的新物品（16p，叫法的描述）。"""
    shop, black = place_type in STOCK, place_type in market.TYPES
    about = {i["name"]: i["description"] for i in world}
    carried = [{"name": e["name"], "tier": e["tier"], "label": label(e["name"], e["tier"], era_now),
                "aka": [{"name": k, "count": n, "description": about.get(k, "")}
                        for k, n in aka(sheet, e["name"], e["tier"]).items()],
                "kind": CATALOG[e["name"]].kind, "count": e["count"], "stolen": stolen(sheet, e["name"], e["tier"]),
                "sellPrice": local_sell(e["name"], e["tier"], place_type, stolen=stolen(sheet, e["name"], e["tier"]) > 0)
                if shop and e["name"] != sheet["technique"] and (black or CATALOG[e["name"]].kind != CONTRABAND
                                                                 and stolen(sheet, e["name"], e["tier"]) < e["count"])
                else None,
                "useProblem": use_problem(sheet, e["name"], e["tier"]),
                "affinity": list(CATALOG[e["name"]].affinity), "main": e["name"] == sheet["technique"],
                "group": CATALOG[e["name"]].group, "side": CATALOG[e["name"]].side,
                "learnProblem": learn_problem(sheet, e["name"], e["tier"])} for e in sheet["items"]]
    goods = [{"name": name, "tier": tier, "label": label(name, tier, era_now), "kind": CATALOG[name].kind,
              "price": local_price(name, tier, place_type, surge)}
             for name in STOCK.get(place_type, ()) + extra for tier in tiers_of(name)
             if tier <= sheet["realm_lv"] + REACH.get(place_type, 1)]   # 只列到境界 +1（黑市 +2；品階延到元嬰後清單太長）
    sold = STOCK.get(place_type, ()) + extra
    tier = min(sheet["realm_lv"], max(TIER_LABELS))
    goods += [{"name": i["base"], "tier": tier, "aka": i["name"], "label": f"{i['name']}（{TIER_LABELS[tier]}）",
               "kind": CATALOG[i["base"]].kind, "price": local_price(i["base"], tier, place_type, surge)}
              for i in [i for i in world if i["base"] in sold][-SHELF:]]   # 貨架：最新的幾件，價格照底
    return {"shop": shop, "carried": carried, "goods": goods, "coin": coin(place_type),
            "exchange": place_type == EXCHANGE, "rate": RATE}


CLAIM = re.compile(r"(?:用(?![力心手腳拳掌全盡計話餐飯功])|喝掉|吃掉|服下|穿上|戴上|拿出(?!來)|掏出(?!來)|舉起|揮舞|拔出|抽出)"
                   r"(?:背包裡的|懷裡的|身上的)?[那這]?[瓶把件塊顆張枚根碗杯]?"
                   r"([^\s，。、！？的]{2,6}?)(?=打|砍|刺|丟|砸|報|給|向|對|$|[，。、！？])")
EVERYDAY = ("衣", "鞋", "褲", "帽", "袍", "飯", "水")   # 身上本來就有、不算物品


def claimed(text: str) -> str:
    """玩家話裡說要用的東西（打字第 9 題）：「用鈍棍打他」→ 鈍棍；沒有回傳空字串。"""
    found = CLAIM.search(text)
    return found.group(1) if found and not any(w in found.group(1) for w in EVERYDAY) else ""


def carried_text(sheet: dict, era_now: str = "") -> str:
    """給說書人：「回氣丹（凡人級）×2（其中寒潭丹×1）、精鐵短刀（凡人級）」。"""
    def named(e: dict) -> str:
        names = "、".join(f"{k}×{n}" for k, n in aka(sheet, e["name"], e["tier"]).items())
        return f"（其中{names}）" if names else ""
    return "、".join([*(label(e["name"], e["tier"], era_now) + (f"×{e['count']}" if e["count"] > 1 else "") + named(e)
                       for e in sheet["items"]),
                      *(c["key"] for c in sheet.get("clues", ()) if c["kind"] == "物證")])   # 查到的物證（16t）


def _is_tier(tier) -> bool:
    return isinstance(tier, int) and not isinstance(tier, bool) and tier in TIER_LABELS


def _amount(n) -> int:
    if not isinstance(n, int) or isinstance(n, bool) or not 1 <= n <= MAX_COUNT:
        raise BadRequest(f"數量需為 1 到 {MAX_COUNT}。", code="invalid_count")
    return n
