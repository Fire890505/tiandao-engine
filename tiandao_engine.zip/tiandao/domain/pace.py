"""節奏的事實（Claude 主導第十一節，N1～N4 甲）：程式不算緊張度，只把鬆緊的事實列給第一段，要不要牌由 Claude 決定。

- 最近：最近幾回合各一個標籤（主事、怪談、動手、受傷、判定失敗、要過牌；都沒有＝安靜），連著安靜幾回合，上次要牌幾回合前。
- 快到的：這一生帳上有期限、還沒了的事（請託、債、回音、破格……）和答應過的事，期限最近的兩件，只寫還有多久。
- 上回合沒記上（第九節 5d）：上回合第一段擋下的、第二段退回或換名的提案，兩段都看得到。
純函式，資料由 service 讀好給。
"""
from __future__ import annotations

from . import judgment as J
from . import memory, society

TURNS, SOON, MISSED = 5, 2, 5
QUIET = "安靜"
SKIP = ("風聲",)   # 傳聞淡掉不算壓力
LOST = (J.FAILURE, J.GREAT_FAILURE)


def tags(turn: dict) -> list[str]:
    """一回合的標籤（回合紀錄的 delta、judgment）。"""
    d, j = turn.get("delta") or {}, turn.get("judgment") or {}
    got = [d["main"]] if d.get("main") else []
    got += ["怪談"] if d.get("domain") or d.get("legend") or d.get("rite") else []
    got += ["動手"] if j.get("action_type") == J.COMBAT else []
    got += ["受傷"] if any(c["field"] == "hp" and c["to"] < c["from"] for c in d.get("changes", [])) else []
    got += [f"判定{j['outcome']}"] if j.get("rolled") and j.get("outcome") in LOST else []
    got += [f"要了{d['card']}"] if d.get("card") else []
    return got or [QUIET]


def recent(turns: list[dict]) -> str:
    """【最近】那一行：turns 舊到新（開場不算）。"""
    acts = [t for t in turns if t.get("kind") == "action"]
    if not acts:
        return ""
    marks = [(t["turn_no"], tags(t)) for t in acts]
    still = next((i for i, (_, m) in enumerate(reversed(marks)) if m != [QUIET]), len(marks))
    asked = next((i for i, t in enumerate(reversed(acts), 1) if (t.get("delta") or {}).get("card")), 0)
    lines = "；".join(f"第{n}回合 {'、'.join(m)}" for n, m in marks[-TURNS:])
    return (f"【最近】（舊到新）{lines}。連著安靜 {still} 回合；"
            + (f"上次要牌是 {asked} 回合前" if asked else f"最近 {len(acts)} 回合沒要過牌"))


def missed(turns: list[dict]) -> str:
    """【上回合沒記上】那一行（第九節 5d）：上一回合擋下、退回、換名的，最多 MISSED 條；沒有就空字串。"""
    last = (turns[-1].get("delta") or {}).get("missed") if turns else None
    return "【上回合沒記上】" + "；".join(last[:MISSED]) if last else ""


def due(ledger: list[dict], threads: list[dict], life: str, now: int) -> str:
    """【快到的】那一行：期限最近的兩件；沒有就空字串。"""
    who = lambda r: next((f"：{w}" for w in (r["a"], r["b"]) if w and w != life), "")   # noqa: E731
    owed = [(r["deadline_shichen"], r["kind"] + who(r)) for r in ledger
            if r["session_id"] == life and r["status"] == society.OPEN and r["deadline_shichen"] is not None and r["kind"] not in SKIP]
    owed += [(t["deadline_shichen"], f"答應的事：{t['text'][:20]}") for t in memory.visible(threads, life)
             if t["status"] in memory.ACTIVE and t["deadline_shichen"] is not None]
    left = lambda at: "到了" if at <= now else memory.remaining_text({"deadline_shichen": at}, now)   # noqa: E731
    soon = sorted(owed)[:SOON]
    return "【快到的】" + "；".join(f"{what}（{left(at)}）" for at, what in soon) if soon else ""
