"""壓力（WHITEPAPER 16v 第 93～98、103 題；第 7-3a 批 ㉟～㊷）：世界記每個村鎮怎麼樣了。純函式。

- 五條，-2 到 2，0 是尋常。兩端算到盡頭。
- 世界的卡：{村鎮或勢力: {"t": 算到的時辰, "cd": {牌: 冷卻到期的時辰},
  壓力: {"v": 級, "at": 上次變動, "why": [因, 原因], "ev": [級, 到期, 原因(, 根)]}}}。尋常又沒有事件外因的那條不記。
- 每月朝目標走一級（month，㉟）：目標＝推力加總夾 ±2（㊶），往那個方向推最大的那項當原因；
  機會 min(CAP, STEP × 離上次變動的月數)。同地單向牽動 CHAIN（㊱）：上游不是 0 推下游 ±1；靈氣自成一條。
- 事件結局（apply）推一級，同時留一年的事件外因，同一條只留最新的一個（㊷）。
"""
from __future__ import annotations

import random

from .clock import SHICHEN_PER_MONTH, SHICHEN_PER_YEAR

LEVELS = {"人心": ("民怨", "不穩", "尋常", "安定", "擁戴"), "興衰": ("蕭條", "冷清", "尋常", "興旺", "繁榮"),
          "凶險": ("太平", "平靜", "尋常", "不靖", "凶險"), "糧食": ("短缺", "吃緊", "尋常", "充足", "豐足"),
          "靈氣": ("枯竭", "稀薄", "尋常", "充沛", "濃郁"),
          "聲勢": ("衰微", "式微", "尋常", "興盛", "鼎盛")}   # 勢力的（第 7-3b1a 批，㊽）：鍵是勢力名，game/factions.py
LABEL = {"人心": "人心", "興衰": "市面", "凶險": "地面", "糧食": "糧食", "靈氣": "靈氣", "聲勢": "聲勢"}
EDGE = 2
CHAIN = (("糧食", "人心", 1), ("人心", "凶險", -1), ("凶險", "興衰", -1))   # 上游, 下游, 同向 1／反向 -1（凶險越高越壞）
STEP, CAP = 0.3, 0.9
EVENT, EVENT_WHY = "事件", "出了那件事之後"
RUMOR = {("人心", True): "{地}的人最近心裡踏實了些", ("人心", False): "{地}的人最近不太安心",
         ("興衰", True): "{地}最近熱鬧起來了", ("興衰", False): "{地}最近冷清了不少",
         ("凶險", True): "{地}一帶最近不太平", ("凶險", False): "{地}一帶最近安靜了",
         ("糧食", True): "{地}今年糧食不用愁", ("糧食", False): "{地}的糧食有點吃緊",
         ("靈氣", True): "修行的人說{地}的靈氣變濃了", ("靈氣", False): "修行的人說{地}的靈氣變稀了",
         ("聲勢", True): "{地}最近風頭正盛", ("聲勢", False): "{地}最近不太行了"}


def _read(token: str) -> tuple[str, int]:
    return token[:2], int(token[2:])


def _clip(v: int) -> int:
    return max(-EDGE, min(EDGE, v))


def known(token: str) -> bool:
    return token[:2] in LEVELS and token[2:3] in ("+", "-") and token[3:].isdigit()


def levels(card: dict, town: str) -> dict[str, int]:
    return {k: p["v"] for k, p in card.get(town, {}).items() if k in LEVELS and p["v"]}


def _clean(row: dict, now: int) -> dict:
    """事件外因到期就拿掉；尋常又沒外因的那條不記；冷卻到期的牌拿掉。"""
    out = {}
    for k, x in row.items():
        if k == "cd":
            x = {n: w for n, w in x.items() if w > now}
        elif k in LEVELS:
            x = {a: b for a, b in x.items() if a != "ev" or b[1] > now}
            x = x if x["v"] or "ev" in x else None
        if x or k == "t":
            out[k] = x
    return out


def put(card: dict, town: str, row: dict) -> dict:
    return {**{k: v for k, v in card.items() if k != town}, **({town: row} if row else {})}


def apply(card: dict, town: str, tokens: list[str], now: int, why: str = "", root: str = "") -> dict:
    """事件結局推動一個村鎮的壓力（㊷）：推一級，同時留一年的事件外因。root：因果鏈的根（ev 第四格，domain/chains）。"""
    row, why = dict(card.get(town, {})), why or EVENT_WHY
    for name, by in map(_read, tokens):
        p = row.get(name, {"v": 0})
        row[name] = {**p, "v": _clip(p["v"] + by), "at": now, "why": [EVENT, why],
                     "ev": [_clip(by), now + SHICHEN_PER_YEAR, why] + ([root] if root else [])}
    return put(card, town, _clean(row, now))


def month(row: dict, t: int, pushes: list[tuple], rng: random.Random) -> tuple[dict, list[tuple]]:
    """一處過一個月（㉟、㊱、㊶）。pushes：外因 [(壓力, 級, 因, 原因)]。回傳（新的一處, 往外換級的 [(壓力, 新級, 因, 原因)]）。"""
    row = _clean(row, t)
    got = {k: [p[1:] for p in pushes if p[0] == k] for k in LEVELS}
    for k in LEVELS:
        ev = row.get(k, {}).get("ev")
        got[k] += [(ev[0], EVENT, ev[2])] if ev else []
    for up, down, sign in CHAIN:
        v = row.get(up, {}).get("v", 0)
        got[down] += [(sign * (1 if v > 0 else -1), *row[up].get("why", ("", "")))] if v else []
    out, moved = dict(row), []
    for k, ps in got.items():
        p, goal = row.get(k, {"v": 0}), _clip(sum(q[0] for q in ps))
        months = (t - p["at"]) / SHICHEN_PER_MONTH if "at" in p else 99
        if goal == p["v"] or rng.random() >= min(CAP, STEP * months):
            continue
        d = 1 if goal > p["v"] else -1
        top = max((q for q in ps if q[0] * d > 0), key=lambda q: abs(q[0]), default=(0, "", ""))
        out[k] = {**p, "v": p["v"] + d, "at": t, "why": list(top[1:])}
        moved += [(k, p["v"] + d, *top[1:])] if abs(p["v"] + d) > abs(p["v"]) else []
    return _clean({**out, "t": t}, t), moved


def words(card: dict, town: str) -> list[str]:
    """給玩家和說書人：「人心不穩（自從旱災之後）」。只列不是尋常的；原因照 98 題帶一句。"""
    return [f"{LABEL[k]}{LEVELS[k][p['v'] + EDGE]}" + (f"（{p['why'][1]}）" if p.get("why", ("", ""))[1] else "")
            for k, p in card.get(town, {}).items() if k in LEVELS and p["v"]]


def rumor(town: str, token: str) -> str:
    name, by = _read(token)
    return RUMOR[name, by > 0].format(地=town)


def _n(v) -> bool:
    return isinstance(v, int) and not isinstance(v, bool)


def _ok(k: str, x) -> bool:
    if k == "t":
        return _n(x)
    if k == "cd":
        return isinstance(x, dict) and all(isinstance(n, str) and _n(w) for n, w in x.items())
    return (k in LEVELS and isinstance(x, dict) and set(x) <= {"v", "at", "why", "ev"} and _n(x.get("v")) and abs(x["v"]) <= EDGE
            and (x["v"] != 0 or "ev" in x) and _n(x.get("at", 0))
            and (lambda w: isinstance(w, list) and len(w) == 2 and all(isinstance(s, str) for s in w))(x.get("why", ["", ""]))
            and (lambda e: e is None or isinstance(e, list) and len(e) in (3, 4) and _n(e[0]) and _n(e[1])
                 and all(isinstance(s, str) for s in e[2:]))(x.get("ev")))


def valid(card) -> bool:
    return isinstance(card, dict) and all(
        isinstance(t, str) and isinstance(row, dict) and row and all(_ok(k, x) for k, x in row.items()) for t, row in card.items())
