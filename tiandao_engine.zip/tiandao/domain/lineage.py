"""三族的支系（第 5 步；16k 批次二加上魔族、獸族）：出身、靈根（法則親和）、諸天異端、屬性加成。純函式。

規則（2026-10-06 與使用者一題一題定案，見 progress/WHITEPAPER.md 第 16c 節、16k 第 5 題，數字暫定）：
- 建角可選或依權重隨機（人族：修仙世家 20、盜墓世家 15、魔法學者 15、普通人族 10；魔族 15；獸族 25）；
  支系決定種族。族的共同特性在 domain/races.py。
- 支系的親和就是靈根：參悟時算一項契合（+50%）。盜墓世家參悟光系收益減半；魔法學者建角擲一系（沒鎖的 34 系）；普通人族沒有靈根。
- 諸天異端（第五種靈能宗系）：建角擲一次（人族 2%、魔法學者 5%），多一組另一個支系的靈根；天道注視開局 20（domain/heaven.py）。
- 屬性：擲完再加，每個支系共 +10。
- 舊角色升級成普通人族：沒有靈根、不補加屬性、不追溯擲諸天異端。
"""
from __future__ import annotations

from dataclasses import dataclass

from ..errors import BadRequest, text_field
from . import names, races
from .races import BEAST, DEMON, HUMAN


@dataclass(frozen=True)
class Lineage:
    weight: int
    roots: tuple            # 靈根（固定的親和）；魔法學者建角時擲
    attrs: tuple            # 加 5 的屬性；普通人族另外任選一項
    lore: str               # 給說書人的一句話（舊設定）
    race: str = HUMAN


P, W, R, S, C = "physique", "wisdom", "root_bone", "perception", "charisma"
CULTIVATOR, TOMB, SCHOLAR, COMMON = "修仙世家", "盜墓世家", "魔法學者", "普通人族"
FOX = "青丘狐族"
LINEAGES = {
    CULTIVATOR: Lineage(20, ("靈系", "空系"), (R, W), "靈根覺醒率高，藏有上古功法殘篇，修煉體系最完整的人族支系"),
    TOMB: Lineage(15, ("死系", "封系"), (P, S), "傳承摸金秘術，辨穴識墓，屍氣、陰氣親和遠超常人"),
    SCHOLAR: Lineage(15, (), (W, S), "融合東西神秘學，創「符文－靈陣」混合術，靈能屬性因人而異"),
    COMMON: Lineage(10, (), (C,), "根骨平庸卻悟性無雙，三大靈能宗系都能修，是唯一能自由切換修煉路線的人"),
    # 16k 批次二：魔族、獸族（出生權重、親和、族徵沿用舊專案；屬性挑最突出的兩項各 +5）
    "鬼族": Lineage(6, ("魂系", "鬼系"), (S, W), "半陰半陽體，能讀取亡者記憶、驅使守墓冥靈，情報能力最強，肉體偏弱", DEMON),
    "血魔族": Lineage(5, ("身系", "生系", "魂系"), (P, R), "以鮮血為媒介施法，吸取生命力，繼承死者的血脈記憶", DEMON),
    "屍族": Lineage(4, ("死系", "身系"), (P, R), "肉體強橫、感知衰退換取絕對防禦，能驅使低階殭屍", DEMON),
    "子鼠": Lineage(2, ("暗系", "神系"), (S, W), "偵查、情報、刺客，三族中最優秀的間諜", BEAST),
    "丑牛": Lineage(1, ("土系",), (P, R), "地脈感知最強，盜墓最天然的嚮導", BEAST),
    "寅虎": Lineage(4, ("金系", "戰系"), (P, R), "純粹戰鬥型，以殺意引導法則，近戰破壞力最高", BEAST),
    "卯兔": Lineage(2, ("木系", "生系"), (W, S), "療癒與生命感知型，能精準避開高危的屍氣", BEAST),
    "辰龍": Lineage(3, ("水系", "雲雨系", "空系"), (R, P), "地脈王者，水系親和延伸到空間系", BEAST),
    "巳蛇": Lineage(2, ("毒系", "情系"), (W, C), "擅長情感操控與慢性削弱", BEAST),
    "午馬": Lineage(2, ("雷系", "風系"), (P, S), "速度型，「閃電即是速度」，機動性三族最高", BEAST),
    "未羊": Lineage(1, ("生系", "業系", "願系"), (C, W), "唯一以佛心為主修的獸族，極少走戰鬥路線", BEAST),
    "申猴": Lineage(2, ("神系", "言系"), (W, S), "智謀型，思維高速運轉，走火入魔也多", BEAST),
    "酉雞": Lineage(1, ("光系", "神系"), (W, S), "預言與洞察型，最可靠的謊言探測器", BEAST),
    "戌狗": Lineage(2, ("魂系", "封系"), (P, S), "忠誠與守護型，亡靈感知距離三族最遠", BEAST),
    "亥豬": Lineage(1, ("土系", "水系"), (P, R), "晚成型的隱藏強者，後期上限極高", BEAST),
    FOX: Lineage(4, ("夢系", "慾系"), (C, W), "幻術欺騙為核心，尾數對應修為，非十二生肖正脈", BEAST),
}
WEAK = {TOMB: "光系"}                     # 參悟這一系收益減半
WEAK_FACTOR = 0.5
HERETIC_CHANCE = {SCHOLAR: 0.05, FOX: 0.05}   # 其餘 2%
DEFAULT_HERETIC_CHANCE = 0.02
ATTR_BONUS = 5
ATTRIBUTES = ("physique", "wisdom", "root_bone", "perception", "charisma")   # 與 character.ATTRIBUTES 相同


def fields() -> dict:
    """角色卡的支系欄位；建角時沒有走 assign（或舊角色升級）就是普通人族。"""
    return {"lineage": COMMON, "roots": [], "heretic": False}


def pick(rng, chosen=None) -> str:
    """建角的支系（16k：三族都能選）：玩家選的，或依出生權重隨機（人 60、魔 15、獸 25）。"""
    chosen = text_field(chosen, "出身", "invalid_lineage")
    if chosen and chosen not in LINEAGES:
        raise BadRequest(f"出身只能選：{'、'.join(LINEAGES)}。", code="invalid_lineage")
    pool = list(LINEAGES)
    return chosen or rng.choices(pool, weights=[LINEAGES[n].weight for n in pool])[0]


def assign(rng, sheet: dict, name: str, extra_attr=None) -> dict:
    """建角：照 pick 定好的支系決定種族、靈根、諸天異端，並加屬性。"""
    from . import laws   # 放這裡避開循環引用：era → newcomer → lineage → laws → items → crime → era
    extra_attr = text_field(extra_attr, "屬性", "invalid_attribute")
    if extra_attr and extra_attr not in ATTRIBUTES:
        raise BadRequest("另加的屬性不在清單裡。", code="invalid_attribute")
    line = LINEAGES[name]
    roots = list(line.roots) or ([rng.choice(laws.OPEN_SYSTEMS)] if name == SCHOLAR else [])
    heretic = rng.random() < HERETIC_CHANCE.get(name, DEFAULT_HERETIC_CHANCE)
    if heretic:
        other = rng.choice([n for n, x in LINEAGES.items() if x.race == line.race and n not in (name, COMMON)])
        extra = LINEAGES[other].roots or (rng.choice(laws.OPEN_SYSTEMS),)
        roots += [s for s in extra if s not in roots and s not in races.BANNED.get(line.race, ())]
    raised = line.attrs + ((extra_attr or rng.choice(ATTRIBUTES)),) if name == COMMON else line.attrs
    attrs = dict(sheet["attributes"])
    for key in raised:
        attrs[key] += ATTR_BONUS
    hp_max = sheet["hp_max"] + attrs["physique"] - sheet["attributes"]["physique"]
    return {**sheet, "race": line.race, "lineage": name, "roots": roots, "heretic": heretic, "attributes": attrs,
            "hp_max": hp_max, "hp": hp_max}


def banned(sheet: dict, law: str) -> str:
    """參悟不了的系（魔族不能參悟光系）；空字串＝可以。"""
    return f"{sheet['race']}的魔氣與{law}相剋，參悟不了" if law in races.BANNED.get(sheet["race"], ()) else ""


def valid(sheet: dict) -> bool:
    from . import laws   # 同 assign
    roots = sheet["roots"]
    return (sheet["lineage"] in LINEAGES and LINEAGES[sheet["lineage"]].race == sheet["race"]
            and isinstance(roots, list) and len(roots) <= 5
            and len(set(roots)) == len(roots) and all(s in laws.OPEN_SYSTEMS for s in roots)
            and isinstance(sheet["heretic"], bool))


def label(sheet: dict) -> str:
    """畫面：「修仙世家｜靈根：光、空間」（他族前面加族名；諸天異端另外標出）。"""
    roots = "、".join(s.removesuffix("系") for s in sheet["roots"]) or "無"
    race = "" if sheet["race"] == HUMAN else f"{sheet['race']}・"
    return f"{race}{sheet['lineage']}{'・諸天異端' if sheet['heretic'] else ''}｜靈根：{roots}"


def features(who: dict) -> tuple:
    """看得見的族徵（16u 外貌）：魔族一直有；獸族收起來只留一樣小特徵；人族沒有。who：角色卡或 NPC；毛色照髮色。"""
    line = LINEAGES.get(who.get("lineage", ""))
    if not line:
        return ()
    hair, lv = (who.get("look") or {}).get("hair", ""), who.get("realm_lv", 0)
    field = "小特徵" if line.race == races.BEAST and not races.visible(who) else "特徵"
    return tuple(f.replace("{毛色}", hair).replace("{尾數}", races.TAIL_WORDS[races.tails(lv) - 1])
                 for f in names.PEOPLES[line.race].get(field, {}).get(who["lineage"], ()))


def mark(who: dict) -> str:
    return "、".join(features(who))


def roll(rng, race: str) -> str:
    """NPC 的支系（16u 第 6 題）：他族照出生權重；人族不分，空字串。"""
    pool = [n for n, x in LINEAGES.items() if x.race == race != HUMAN]
    return rng.choices(pool, weights=[LINEAGES[n].weight for n in pool])[0] if pool else ""


def local(rng, race: str, town: str = "") -> str:
    """當地人的支系：七成跟聚落的主要支系（16u 第 6 題，沿用姓氏村的比例）。"""
    main = names.main_line(town, race) if town else ""
    return main if main and rng.random() < names.CLAN_SHARE else roll(rng, race)


def who(p: dict, short: bool = False) -> str:
    """NPC 是什麼人：「女，鐵匠，獸族・青丘狐族（狐耳、狐尾……）」；人族沒有族名，舊世界的人可能是空字串。short：面板只列兩項。"""
    race, seen = p.get("race", HUMAN), "、".join(features(p)[:2 if short else None])
    kind = "" if race == HUMAN else race + (f"・{p['lineage']}" if p.get("lineage") else "") + (f"（{seen}）" if seen else "")
    return "，".join(x for x in (p.get("gender", ""), p.get("job", ""), kind) if x)


def prompt_line(sheet: dict) -> str:
    """給說書人：「修仙世家（靈根：光、空間）——靈根覺醒率高……」；他族加族名與化形、族徵。"""
    line = LINEAGES[sheet["lineage"]]
    roots = "、".join(s.removesuffix("系") for s in sheet["roots"])
    race = "" if line.race == HUMAN else f"{line.race}・"
    text = race + sheet["lineage"] + (f"（靈根：{roots}）" if roots else "") + f"——{line.lore}"
    form, seen = races.form_text(sheet), mark(sheet)
    text += f"；{form}" + (f"（{seen}）" if seen else "") if form else ""
    return text + ("；天生雙脈靈能（諸天異端），極為罕見" if sheet["heretic"] else "")
