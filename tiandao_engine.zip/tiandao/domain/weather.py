"""天氣與氣候（2026-10-13，WHITEPAPER 16j 第 1、2 題；第 9 組草稿批次一）。純函式。

- 氣候：每個國家一種（溫和、寒冷、濕熱、乾燥、高山），由國名決定，不必存（多國時各國不同；存檔讀回來世界種子會換，國名不會）。
- 天氣：由國名＋日期決定（同一天同一個天氣），依季節的權重擲、再照氣候調整。
- 效果（室內不受影響）：雨、霧 → 匿蹤 +5、辨向 −5；大雪、暴雨 → 趕路時間 × 1.5；修煉的修為：雷雨 +10%、大雪與暴雨 −10%。
"""
from __future__ import annotations

import random

from . import judgment as J
from .clock import SHICHEN_PER_DAY, season_of

CLIMATES = {"溫和": "四季分明，寒暑有度", "寒冷": "北地苦寒，冬長夏短", "濕熱": "溽暑多雨，草木瘋長",
            "乾燥": "風沙漫天，終年少雨", "高山": "山高霧重，雪線低垂"}
DEFAULT_CLIMATE = "溫和"
CLEAR, RAIN, FOG, STORM, DOWNPOUR, SNOW, BLIZZARD = "晴", "雨", "霧", "雷雨", "暴雨", "雪", "大雪"
BY_SEASON = {"春": {CLEAR: 5, RAIN: 3, FOG: 2}, "夏": {CLEAR: 5, STORM: 3, DOWNPOUR: 2},
             "秋": {CLEAR: 5, RAIN: 3, FOG: 2}, "冬": {CLEAR: 4, SNOW: 4, BLIZZARD: 2}}
CLIMATE_MOD = {"寒冷": {BLIZZARD: 2, DOWNPOUR: 0.5}, "濕熱": {RAIN: 2, DOWNPOUR: 2},
               "乾燥": {RAIN: 0.5, DOWNPOUR: 0.5, FOG: 0}, "高山": {FOG: 2, SNOW: 2}}
BONUS = {RAIN: {J.HIDE: 5, J.ORIENT: -5}, FOG: {J.HIDE: 5, J.ORIENT: -5}}
SLOW, SLOW_BY = (BLIZZARD, DOWNPOUR), 1.5
QI = {STORM: 0.1, BLIZZARD: -0.1, DOWNPOUR: -0.1}
INDOORS = ("住家", "客棧", "藥鋪", "當鋪", "鐵匠鋪", "丹房", "煉器閣", "衙署", "黑市", "修士黑市", "拍賣場")


def climate(nation: str) -> str:
    return random.Random(f"climate:{nation}").choice(list(CLIMATES))


def today(nation: str, climate_: str, clock_now: int) -> str:
    weights = {w: n * CLIMATE_MOD.get(climate_, {}).get(w, 1) for w, n in BY_SEASON[season_of(clock_now)].items()}
    rng = random.Random(f"{nation}:weather:{clock_now // SHICHEN_PER_DAY}")
    return rng.choices(list(weights), weights=list(weights.values()))[0]


def bonus(weather: str, place_type: str) -> dict:
    return {} if place_type in INDOORS else BONUS.get(weather, {})


def slow(weather: str, place_type: str) -> float:
    return SLOW_BY if weather in SLOW and place_type not in INDOORS else 1


def qi(weather: str, place_type: str) -> float:
    """修煉的修為倍數。"""
    return 1 if place_type in INDOORS else 1 + QI.get(weather, 0)


def text(weather: str, climate_: str) -> str:
    return f"今天{weather}；{CLIMATES.get(climate_, '')}"
