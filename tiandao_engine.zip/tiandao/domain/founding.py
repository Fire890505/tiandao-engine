"""散仙立宗與宗主招收（16l 第 25 題丁；草稿 C4d）。純函式。

規則（2026-10-18 與使用者一題一題定案，見 progress/WHITEPAPER.md 16l，數字暫定）：
- 立宗：散仙在遺址說「立宗」；要大羅金仙、此地威名遠近皆知、COST 靈石、FOLLOWERS 個追隨者（同伴，或在場、
  好感親近、沒有宗門的人）。遺址的方格要還是無主之地（骨架 ruins 記著覆滅仙宗的山門方格）。
  那一格立起新仙宗：沒有盟、實力 POWER、founder＝這一生；主角是宗主（職位記真傳），追隨者成了長老。
- 招收：宗主在自家山門說「招收」，散仙名單裡還沒入宗的人收進你的名冊，每個百日一次、最多 ENLIST 人。
- 投盟、結盟、指派門人出戰在 C5。
"""
from __future__ import annotations

from . import crime, immortal, names, recruit, reputation

WORDS = ("立宗", "開宗")
ENLIST_WORDS = ("招收",)
COST, FOLLOWERS, POWER, ENLIST = 1000, 3, 20, 3
AFFINITY = 60   # 好感「親近」


def fields() -> dict:
    return {"enlisted": -1}


def problem(sheet: dict, levels: dict, followers: list[str], cell) -> str:
    """不能立宗的原因（空字串＝可以）。"""
    if sheet["sect"]:
        return "已經是仙宗弟子"
    if (sheet["realm_lv"], sheet["stage_index"]) < recruit.TALENT:
        return "境界還不到大羅金仙"
    if levels.get(reputation.MIGHT) != reputation.FAMOUS:
        return "在這一帶的威名還不夠"
    if sheet["spirit_stones"] < COST:
        return f"要 {COST} 靈石，只有 {sheet['spirit_stones']}"
    if len(followers) < FOLLOWERS:
        return f"要 {FOLLOWERS} 個追隨者，只有 {len(followers)} 個"
    return "" if cell is not None else "這處遺址的地盤已經有主了"


def cell_of(realm: dict, ruin: str, suffix: str):
    """遺址對應的方格（還是無主之地才算）；不是覆滅仙宗的山門遺址回傳 None。"""
    cell = realm.get("ruins", {}).get(ruin[:-len(suffix)] if ruin.endswith(suffix) else "")
    return cell if cell and any(tuple(c) == tuple(cell) for c in realm.get("free", [])) else None


def plan(rng, realm: dict, sheet: dict, cell, life: str) -> dict:
    """新仙宗（還沒寫進骨架）：名字照仙宗的字首字尾挑沒用過的；道統隨機、主收主角的種族。"""
    taken = {s["name"] for s in realm["sects"]} | set(realm.get("ruins", {})) | {f["name"] for f in realm.get("fallen", [])}
    name = names.pick_unused(rng, immortal.PREFIXES, names.IMMORTAL_SUFFIXES, taken)
    return {**immortal._sect(name, "", rng.choice(tuple(names.SECT_PATHS)), sheet["race"], POWER,
                             rng.choice(crime.STYLES).name, [list(cell)]), "founder": life} if name else {}
