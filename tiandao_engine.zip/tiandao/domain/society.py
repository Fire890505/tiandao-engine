"""人物之間、人物與勢力、勢力之間的關係（第 10a 步）。純規則，不碰資料庫。

羈絆一律寫成「甲對乙而言是〔種類〕」：例如 {甲: 守碑老人, 乙: 阿桃, 種類: 師父} ＝守碑老人是阿桃的師父。
勢力是最小版：名字、類型、所在地；強弱由成員境界推算，不另存數值（WHITEPAPER 第 14 節）。

關係分四類（第 121-4、121-7、121-8 題，實作第 1-3 批）：血緣（親人，不斷）、立約（事件成立和斷）存下來；
看好感（友人、仇家）、看帳（恩人）不存，每回合讀的時候由 derived 算出；同門就是同一宗門的成員（sect.members），不另列。
血緣、立約、同門照種類固定加減好感（bonus，第 1-3b 批）。主角也當關係的一方（第 121-6 題）：那方的 kind 寫 PLAYER、
名字寫那一生（session id，會改名、取道號）；service 讀的時候分開，NPC 之間那份照舊給其他模組。
"""
from __future__ import annotations

from . import opinion, races
from .clock import SHICHEN_PER_YEAR

NPC, FACTION, PLAYER = "npc", "faction", "主角"
AWAY = "（遠方）"            # 去了沒有登錄的遠方：括號不是合法地名，不會與任何地點相同
BLOOD = ("親人",)
PACT = ("師父", "徒弟", "戀人", "伴侶", "結義", "奴", "僕")   # 人物之間的立約；奴、僕＝甲是乙的奴、僕
BY_LIKE = ("友人", "仇家")
BY_LEDGER = ("恩人", "同門")
DERIVED = BY_LIKE + BY_LEDGER                    # 算出來的，不存
PERSON_BONDS = BLOOD + PACT + DERIVED
ADULT_ONLY_BONDS = ("戀人", "伴侶")            # 雙方都必須成年（未成年底線）
MEMBER_BONDS = ("首領", "成員")                 # 人物對勢力（立約）
FACTION_BONDS = ("盟友", "敵對", "從屬")        # 勢力對勢力（立約）
BOND_TYPES = PERSON_BONDS + MEMBER_BONDS + FACTION_BONDS
FACTION_TYPES = ("宗門", "武館", "家族", "幫派", "朝廷", "商會")   # AI 也能提案的種類（與 ai/contract 一致）
IMMORTAL_SECT = "仙宗"   # 宗門的上宗，在仙域：只有 Python 生成，玩家與說書人都看不到名字（第 16b 步）
NATION = "國家"          # 國法的主人（16h）：只有 Python 生成，特徵在勢力的 traits
SYMMETRIC = {"親人", "同門", "仇家", "友人", "戀人", "伴侶", "結義", "盟友", "敵對"}   # 甲乙對調意思相同
INVERSE = {"師父": "徒弟", "徒弟": "師父", "奴": "主人", "僕": "主人"}
FRIEND_AT, FOE_AT = 20, -50   # 友善以上、敵視（npc.AFFINITY_TIERS）
BONUS = {"親人": 60, "伴侶": 60, "結義": 60, "師父": 30, "徒弟": 30, "戀人": 30}   # 固定加減（121-4）；奴、僕 0：名分不代表喜歡
SAME_HALL = 10                                     # 同門：同一個宗門、武館、仙宗的成員
HALLS = ("宗門", "武館", IMMORTAL_SECT)
STRANGER, MET, KNOWN, KIN = "陌生", "認識", "熟人", "親人"   # 熟不熟（第 120-6 題）
CLOSE = BLOOD + ("伴侶", "師父", "徒弟", "結義")             # 自家人：人情不記帳（第 120-2、121-7 題）
TALKS = 2                     # 往來過幾次（不同時候的原因）算熟人；初見的名聲不算
# 帳（第 1-4 批再補齊）：恩＝甲是乙的恩人、受託＝甲答應替人對付乙（借刀、懸賞）、債＝乙欠甲錢。
# 主角的人情（domain/favour.py）也記在帳上，session_id＝那一生，主角那方寫那一生（第 1-4a 批）
OWE, HIRED, DEBT, OPEN, DONE = "恩", "受託", "債", "未了", "已了"   # NPC 之間的帳一方死了就已了（第 1-4c 批）
PASSED = (OWE, HIRED, DEBT)   # NPC 之間的帳一方死了傳給接手的人一次，再死就沉（第 8-4-4 題甲）
HEIRS = {"b": ("親人", "徒弟"), "a": ("親人", "師父")}   # 羈絆「甲對乙而言是〔種類〕」：死者是乙時甲接手、死者是甲時乙接手


def heir(bonds: list[dict], name: str, alive: set[str]) -> str:
    """死者的帳、要帶的話由誰接：活著的親人或徒弟（第 108、125-2 題；第 8-4 批）。"""
    return next((b[k] for b in bonds for k, other in (("a", "b"), ("b", "a"))
                 if b[other] == name and b["type"] in HEIRS[other] and b[k] in alive), "")
FEUD, HUNT = "血仇", "追查兇手"   # 甲對乙（那一生）；event_id 指向那件事（第 121-2 題，實作第 1-5b 批）
JAILED, MARKED = "關押", "記過"   # NPC 小事（第 7-2a 批）：甲關在乙（村鎮）的牢房、甲在乙（宗門）記一過；期限到就算了
HUSH = "封口"                     # 甲收了你的封口費、替你瞞那件事（第 120-2 題，實作第 1-5d 批）
WATCH = "報信"                    # 甲替你留意，帶敵意的人上門前先捎信，用一次就了（第 4-10-1 題）
DEED = "做法"                     # 甲對你做了一種做法（第 7-2b 批，game/deeds.py）：body 做＝哪種，一年一次；通風的期限＝那一個月
GATHERED = "聚過"                 # 聚（第 7-5a 批，domain/gather.py）：NPC 那群甲乙＝那一處、期限一年；你那群甲＝開口的人、乙＝那一處、帶那一生
WAITING = "待投胎"               # 待投胎名單（第 7-5b 批，domain/undead.py）：甲乙＝那一州，body 名＝死者、死＝死的時刻
WORRY = "心事"                   # 心事小表抽到的那條（第 9e-2 批，domain/worry.py）：甲＝他、乙＝對象（人名或照寫的身分）；body 說、舉、級、隱、條
CALLED = "找上你"             # 命數找上你（併章重設計，game/service._faced）：甲＝他、乙＝那一生、已了；body 空＝來過一次，勸＝你勸他那章怎麼收
ABOUT = (FEUD, HUNT, HUSH)        # 綁著一件事的帳
_FROM_LEDGER = {OWE: "恩人", HIRED: "仇家"}


def allowed(type_: str, a_kind: str, b_kind: str) -> bool:
    """這種羈絆能不能存在這兩種對象之間（算出來的不能存；主角那方照 NPC）。"""
    a_kind, b_kind = (NPC if k == PLAYER else k for k in (a_kind, b_kind))
    if a_kind == NPC and b_kind == NPC:
        return type_ in BLOOD + PACT
    if a_kind == NPC and b_kind == FACTION:
        return type_ in MEMBER_BONDS
    if a_kind == FACTION and b_kind == FACTION:
        return type_ in FACTION_BONDS
    return False


def kin_call(x: dict, y: dict) -> str:
    """x 叫親人 y 什麼：差 15 歲以上是爹娘或兒女，不然兄弟姊妹（第 9-19 題的 {稱呼}；重逢喪親也用，第 9f-2 批）。"""
    if x.get("birth_shichen") is None or y.get("birth_shichen") is None:
        return "家裡的"
    gap, male = (x["birth_shichen"] - y["birth_shichen"]) / SHICHEN_PER_YEAR, y.get("gender") == "男"
    return ("爹" if male else "娘") if gap >= 15 else ("兒子" if male else "女兒") if gap <= -15 else \
        ("哥" if male else "姊") if gap > 0 else ("弟" if male else "妹")


def owed(kind: str, a: str, b: str, now: int) -> dict:
    """一筆帳（ledger 表）。"""
    return {"session_id": "", "kind": kind, "a": a, "b": b, "event_id": "", "settle": "", "deadline_shichen": None,
            "waiting": "", "status": OPEN, "era": "", "body": {}, "clock_shichen": now}


def familiar(x: str, y: str, bonds: list[dict], talks: list[dict], places: dict[str, str]) -> str:
    """熟不熟：親人；立約、同住一地、同勢力、往來過 TALKS 次是熟人；有過原因是認識。
    talks：這兩人之間（兩個方向）的原因；places：名字 → 所在地（遠方的不放）。"""
    mine = [b for b in bonds if {b["a"], b["b"]} == {x, y}]
    if any(b["type"] in BLOOD for b in mine):
        return KIN
    def halls(n): return {b["b"] for b in bonds if b["a"] == n and b["type"] in MEMBER_BONDS}
    if (any(b["type"] in PACT for b in mine) or places.get(x) and places.get(x) == places.get(y) or halls(x) & halls(y)
            or len({r["clock_shichen"] for r in talks if r["kind"] not in (opinion.FAME, opinion.RANK)}) >= TALKS
            or any(r["kind"] == opinion.KNEW for r in talks)):   # 認出轉世直接算熟人（第 6-6b1 批）
        return KNOWN
    return MET if talks else STRANGER


def circle(life: str, name: str, bonds: list[dict], talks: list[dict], owed: bool = False) -> str:
    """主角這邊的三套規矩（第 120-2 題，實作第 1-4b 批）：自家人 KIN、熟人 KNOWN、外人 STRANGER。
    同住一地不算熟；owed：帳上有恩也算熟人（一回生二回熟）。"""
    if any(b["type"] in CLOSE and {b["a"], b["b"]} == {life, name} for b in bonds):
        return KIN
    return KNOWN if owed or familiar(life, name, bonds, talks, {}) == KNOWN else STRANGER


def bonus(bonds: list[dict], factions: list[dict]):
    """關係種類的固定加減（只加好感）：回傳 f(甲, 乙)，兩人之間的血緣、立約相加，同門再 +SAME_HALL。
    主角那方傳那一生的 id。"""
    halls = {f["name"] for f in factions if f["type"] in HALLS}
    pact: dict[frozenset, int] = {}
    member: dict[str, set[str]] = {}
    for b in bonds:
        if b["type"] in BONUS:
            k = frozenset((b["a"], b["b"]))
            pact[k] = pact.get(k, 0) + BONUS[b["type"]]
        elif b["type"] in MEMBER_BONDS and b["b"] in halls:
            member.setdefault(b["a"], set()).add(b["b"])
    return lambda x, y: pact.get(frozenset((x, y)), 0) + (SAME_HALL if member.get(x, set()) & member.get(y, set()) else 0)


def liking(npcs: list[dict], bonds: list[dict], reasons: list[dict], now: int, factions: list[dict] = (), axis: str = opinion.LIKE):
    """NPC 對 NPC 的好感（或信任）：回傳 f(甲, 乙)。好感加固定加減，沒有原因的只剩固定加減（第 1-5b 批）。"""
    by, plus, pairs = {p["name"]: p for p in npcs}, bonus(bonds, factions), {}
    for r in reasons:
        if not r["session_id"] and r["axis"] == axis:
            pairs.setdefault((r["holder"], r["toward"]), []).append(r)

    def f(x: str, y: str) -> int:
        p = by.get(x, {})
        return opinion.total(pairs.get((x, y), []), opinion.lifespan(p.get("realm_lv", 0), p.get("race") or races.HUMAN), now,
                             plus(x, y) if axis == opinion.LIKE else 0)
    return f


def derived(npcs: list[dict], bonds: list[dict], reasons: list[dict], ledger: list[dict], now: int,
            factions: list[dict] = ()) -> list[dict]:
    """算出來的關係（不存）：NPC 之間任一方敵視＝仇家，雙方友善以上又是熟人＝友人（沒有原因的那方不看，
    例如退隱的前世主角；已經是血緣、立約的不另算友人）；帳上沒了結的恩＝恩人、受託＝仇家。
    好感＝原因加上固定加減（bonus）。時間＝最近一筆原因或那筆帳。"""
    by, plus = {p["name"]: p for p in npcs}, bonus(bonds, factions)
    places = {n: p["location"] for n, p in by.items() if p["location"] != AWAY}
    pairs: dict[tuple[str, str], list[dict]] = {}
    for r in reasons:
        if not r["session_id"] and r["holder"] in by and r["toward"] in by:
            pairs.setdefault((r["holder"], r["toward"]), []).append(r)
    like = {k: opinion.total([r for r in v if r["axis"] == opinion.LIKE], opinion.lifespan(
        by[k[0]].get("realm_lv", 0), by[k[0]].get("race") or races.HUMAN), now, plus(*k)) for k, v in pairs.items()}
    tied = {frozenset((b["a"], b["b"])) for b in bonds if b["type"] in BLOOD + PACT}
    out = []
    for x, y in sorted({tuple(sorted(k)) for k in pairs}):
        sides = [like[k] for k in ((x, y), (y, x)) if k in like]
        talks = pairs.get((x, y), []) + pairs.get((y, x), [])
        kind = ("仇家" if min(sides) <= FOE_AT else "友人" if min(sides) >= FRIEND_AT and frozenset((x, y)) not in tied
                and familiar(x, y, bonds, talks, places) == KNOWN else "")
        if kind:
            out.append(_tie(x, y, kind, max(r["clock_shichen"] for r in talks)))
    return out + [_tie(l["a"], l["b"], _FROM_LEDGER[l["kind"]], l["clock_shichen"]) for l in ledger
                  if l["status"] == OPEN and l["kind"] in _FROM_LEDGER and not l["session_id"]]   # 主角的人情不算


def _tie(a: str, b: str, kind: str, when: int) -> dict:
    return {"session_id": "", "a_kind": NPC, "a": a, "b_kind": NPC, "b": b, "type": kind, "clock_shichen": when, "turn_no": 0}


def same_bond(x: dict, y: dict) -> bool:
    """兩筆羈絆是不是同一件事（對稱的種類甲乙可以對調；師父／徒弟互為反向）。"""
    if (x["a"], x["b"], x["type"]) == (y["a"], y["b"], y["type"]):
        return True
    reverse = (x["b"], x["a"])
    return (y["a"], y["b"]) == reverse and (y["type"] == x["type"] and x["type"] in SYMMETRIC
                                             or INVERSE.get(x["type"]) == y["type"])


def describe(bond: dict, viewpoint: str) -> str | None:
    """從某人的角度描述一筆羈絆：「阿桃的師父」「青雲宗的首領」。與他無關回傳 None。"""
    if bond["a"] == viewpoint:
        return f"{bond['b']}的{bond['type']}"
    if bond["b"] == viewpoint:
        if bond["type"] in SYMMETRIC:
            return f"{bond['a']}的{bond['type']}"
        if bond["type"] in INVERSE:
            return f"{bond['a']}的{INVERSE[bond['type']]}"
        if bond["type"] in MEMBER_BONDS:
            return f"{bond['type']}：{bond['a']}"
        if bond["type"] == "從屬":
            return f"附屬於它的：{bond['a']}"
        return f"{bond['a']}是其{bond['type']}"
    return None
