"""散仙當傭兵（16l 第 24 題；草稿 C4c）。純函式。

規則（2026-10-18 與使用者一題一題定案，見 progress/WHITEPAPER.md 16l，數字暫定）：
- 散仙在仙宗山門說「受雇」：接下那一宗正在打的一件戰事（war.current），角色卡 hire：{sect, place, until}。
- 受雇期間算僱主那一邊：遭遇時僱主的敵盟當你是敵人（realms.encounter 用僱主的仙宗擲）；在那件戰事的地點打退敵盟的人
  得 PAY 靈石、戰功記在僱主的帳上（對方仙宗照扣），也算一場戰績。戰事結束（until）就解約。
"""
from __future__ import annotations

from . import ascent, immortal, war

WORDS = ("受雇", "受僱", "應募")
PAY = 20


def fields() -> dict:
    return {"hire": None}


def side(sheet: dict) -> str:
    """這個人替哪個仙宗打：仙宗弟子是自己的仙宗，受雇的散仙是僱主。"""
    return sheet["sect"] or (sheet["hire"] or {}).get("sect", "")


def take(realm: dict, sheet: dict, here: str, words: str, clock_now: int) -> tuple[dict, list[str]]:
    """在山門說要受雇；已經到期的先解約。"""
    h = sheet["hire"]
    if h and clock_now >= h["until"]:
        sheet, facts = {**sheet, "hire": None}, [f"{h['place']}的戰事結束，跟{h['sect']}解約"]
    else:
        facts = []
    hall = here[:-len(ascent.GATE)] if here.endswith(ascent.GATE) else ""
    if sheet["sect"] or sheet["hire"] or not hall or not any(w in words for w in WORDS):
        return sheet, facts
    ally = next((s["alliance"] for s in realm["sects"] if s["name"] == hall), "")
    fight = next((w for w in war.current(realm, clock_now) if ally and ally in w["sides"]), None)
    if not fight:
        return sheet, facts + [f"{hall}眼下沒有戰事要雇人"]
    until = clock_now // immortal.PERIOD * immortal.PERIOD + war.LASTS
    return ({**sheet, "hire": {"sect": hall, "place": fight["place"], "until": until}},
            facts + [f"受雇於{hall}，去{fight['place']}打{fight['kind']}之戰，在那裡打退一個敵人 {PAY} 靈石"])


def text(sheet: dict) -> str:
    h = sheet["hire"]
    return f"受雇於{h['sect']}" if h else ""


def valid(sheet: dict) -> bool:
    h = sheet["hire"]
    return h is None or isinstance(h, dict) and set(h) == {"sect", "place", "until"}
