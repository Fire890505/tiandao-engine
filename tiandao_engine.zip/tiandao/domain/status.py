"""角色狀態（buff／debuff）。純函式。

沿用舊專案 rules.py 的狀態設計（使用者原本的設計）：
- 類型：負面（休養會減輕）、正面（增益）、永久（例如斷肢、重大詛咒，休養不會好）。
- 嚴重度 0–100：1–30 輕微（不影響行動）、31–60 中度（行動受限）、61–100 嚴重（幾乎無法主動出擊）。
刻意不同：舊版狀態由 AI 回報、AI 填嚴重度；這裡一律由 Python 依判定結果產生（第 4 步，總綱第 4 節）。
"""
from __future__ import annotations

NEGATIVE, POSITIVE, PERMANENT = "負面", "正面", "永久"
KINDS = (NEGATIVE, POSITIVE, PERMANENT)
MODERATE, SEVERE = 31, 61                  # 嚴重度分級的下限
PENALTY = {MODERATE: -10, SEVERE: -25}     # 中度、嚴重對「主動出擊類」判定的成功率影響（暫定）
REST_RELIEF = 20                           # 休養一次，負面狀態嚴重度減少多少
MAX_NAME_CHARS = 12


def make(name: str, kind: str, magnitude: int, expires_at: int | None = None) -> dict:
    return {"name": name, "kind": kind, "magnitude": max(0, min(100, magnitude)), "expires_at": expires_at}


def add(statuses: list[dict], new: dict) -> list[dict]:
    """同名狀態取較嚴重的嚴重度與較晚的期限，不重複堆疊。"""
    for s in statuses:
        if s["name"] == new["name"]:
            s["magnitude"] = max(s["magnitude"], new["magnitude"])
            if s["expires_at"] is not None:
                s["expires_at"] = None if new["expires_at"] is None else max(s["expires_at"], new["expires_at"])
            return statuses
    statuses.append(dict(new))
    return statuses


def expire(statuses: list[dict], clock_now: int) -> tuple[list[dict], list[str]]:
    """移除到期的狀態，回傳（剩下的, 到期的名稱）。"""
    kept = [s for s in statuses if s["expires_at"] is None or s["expires_at"] > clock_now]
    return kept, [s["name"] for s in statuses if s not in kept]


def relieve(statuses: list[dict], amount: int = REST_RELIEF) -> tuple[list[dict], list[str]]:
    """休養：負面狀態嚴重度下降，降到 0 就痊癒。永久與正面狀態不受影響。回傳（剩下的, 痊癒的名稱）。"""
    kept, healed = [], []
    for s in statuses:
        if s["kind"] == NEGATIVE:
            s = {**s, "magnitude": s["magnitude"] - amount}
            if s["magnitude"] <= 0:
                healed.append(s["name"])
                continue
        kept.append(s)
    return kept, healed


def penalty(statuses: list[dict]) -> int:
    """取最嚴重的一個負面／永久狀態決定影響，不累加（避免多個輕微狀態疊成重傷）。"""
    worst = max((s["magnitude"] for s in statuses if s["kind"] != POSITIVE), default=0)
    if worst >= SEVERE:
        return PENALTY[SEVERE]
    if worst >= MODERATE:
        return PENALTY[MODERATE]
    return 0


EDGE = {"順勢": 10, "處境不利": -10, "處境險惡": -20}   # 機會牌、陷阱留下的處境（16v 第 81-7、81-9 題）：每種判定都算


def edge(statuses: list[dict]) -> int:
    return sum(EDGE.get(n, 0) for n in {s["name"] for s in statuses})


def valid(statuses) -> bool:
    if not isinstance(statuses, list):
        return False
    for s in statuses:
        if not (isinstance(s, dict) and isinstance(s.get("name"), str) and 1 <= len(s["name"]) <= MAX_NAME_CHARS
                and s.get("kind") in KINDS and _is_int(s.get("magnitude")) and 0 <= s["magnitude"] <= 100
                and (s.get("expires_at") is None or _is_int(s["expires_at"]))):
            return False
    return True


def _is_int(value) -> bool:
    return isinstance(value, int) and not isinstance(value, bool)
