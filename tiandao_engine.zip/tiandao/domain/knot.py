"""交會（第 7-4a 批，WHITEPAPER (69)～(69)-7，草稿 progress/交會草稿.md）。純函式。

- 開章抽到的宮裡那人（不分一般命、特殊命）和你，照兩人命的類（origins.Fate.kind）挑結：同類挑一個＝對撞，異類兩類各挑一個（他的類先）。
- 挑到的人排在宮裡那人後面先挑角色，照 TRY 先試哪個角色（plot.choose 的 want）；條件對不上不硬塞（第 116-7 題）。
- 親＝家人師徒、情＝戀人伴侶、眾生＝所屬勢力的人、幽冥＝已故親人還活著的家人（亡者給說書人提）、己身＝宮裡那人自己；
  物與地不挑人，受害者住的那一處放在他住的村鎮（在範圍裡才放，game/plots.place）。先找他身上的，再找你身上的。
- 記在事端 cast[KNOT]：一個結一段「類:誰:演的角色:誰的:關係:亡者:開章好感」，「、」接起來；說書人一句（say）。
- 收場（第 7-4b 批）：章收了，同類照 judge 判護、損、平，異類記「異」，接在那章紀錄最後一欄（game/fated._mark）；死後命盤回顧一行（review）。
"""
from __future__ import annotations

import random

from . import origins, plot, society
from .evolution import SWING

KNOT = "結"
HOLD, LOSS, EVEN, BOTH = "護", "損", "平", "異"   # 收場：護壓過、損壓過、平手、異類（只牽進來，不比）
LAND, DEAD, SELF, CREW = "物與地", "幽冥", "己身", "眾生"
KIN, LOVE = ("親人", "師父", "徒弟"), ("戀人", "伴侶")
TRY = {"親": ("受害者", "第三者"), "情": ("受害者", "知情者", "第三者"), CREW: ("隱瞞者", "第三者"),
       SELF: ("第三者",), DEAD: ("受害者", "第三者")}
WORD = {"親人": "家人"}
YOU = "你"


def kind(p: dict) -> str:
    f = origins.FATES.get(p.get("fate") or "")
    return f.kind if f else ""


def _ties(bonds: list[dict], who: str, types: tuple) -> list[tuple[str, str]]:
    """（對方, 對方是 who 的什麼）。"""
    return [(b["a"], b["type"]) if b["b"] == who else (b["b"], society.INVERSE.get(b["type"], b["type"]))
            for b in bonds if b["type"] in types and who in (b["a"], b["b"])]


def _find(bonds: list[dict], alive: set[str], dead: set[str], who: str, k: str, used: set[str]) -> list[dict]:
    if k in ("親", "情"):
        return [{"who": x, "as": WORD.get(t, t)} for x, t in _ties(bonds, who, KIN if k == "親" else LOVE) if x in alive - used]
    if k == CREW:
        halls = {b["b"] for b in bonds if b["a"] == who and b["type"] in society.MEMBER_BONDS}
        return [{"who": b["a"], "as": b["b"]} for b in bonds if b["b"] in halls and b["type"] in society.MEMBER_BONDS and b["a"] in alive - used]
    return [{"who": x, "as": WORD.get(t, t), "dead": d} for d, _ in _ties(bonds, who, KIN) if d in dead
            for x, t in _ties(bonds, d, KIN) if x in alive - used]


def pick(rng: random.Random, bonds: list[dict], alive: set[str], dead: set[str], me: str, him: str, mine: str, his: str) -> list[dict]:
    """結：[{kind, who, of, as, dead, try}]；物與地只有 kind、of。alive、dead：活著、已故的 NPC。mine、his：兩人命的類，有一邊空就不交會。"""
    out, used = [], {me, him}
    for k in dict.fromkeys((his, mine)) if mine and his else ():
        if k == LAND:
            out.append({"kind": k, "of": him})
        elif k == SELF:
            out.append({"kind": k, "who": him, "of": him, "try": TRY[k]})
        else:
            got = next(((side, c) for side in (him, me) if (c := _find(bonds, alive, dead, side, k, used))), None)
            if got:
                x = rng.choice(sorted(got[1], key=lambda c: c["who"]))
                used.add(x["who"])
                out.append({**x, "kind": k, "of": YOU if got[0] == me else got[0], "try": TRY[k]})
    return out


def record(knots: list[dict], got: dict[str, str], land: str = "") -> str:
    """真的演進去的結 → cast[KNOT]。己身、物與地不用演到；land：受害者那一處放到的村鎮。like：開章時結的人對你的好感（7-4b 判定用）。"""
    role = {v: r for r, v in got.items()}
    keep = [k for k in knots if k["kind"] in (SELF, LAND) or k["who"] in role]
    return "、".join(f"{k['kind']}:{land if k['kind'] == LAND else k['who']}:{role.get(k.get('who'), '')}:{k['of']}:{k.get('as', '')}:{k.get('dead', '')}"
                     f":{k.get('like', '')}" for k in keep)


def read(cast: dict) -> list[dict]:
    keys = ("kind", "who", "role", "of", "as", "dead", "like")
    return [dict(zip(keys, part.split(":"))) for part in cast.get(KNOT, "").split("、") if part]


def of(plots: list[dict], life: str, n: int) -> dict | None:
    """這一生第 n 章那條有結的事端。"""
    return next((p for p in plots if p["cast"].get(plot.CHAPTER, "").startswith(f"{life}:{n}:") and p["cast"].get(KNOT)), None)


# ── 收場（第 7-4b 批，(69)-2、(69)-4～(69)-6）────────────────────────────
def face(fate: str, reading: int = 0) -> str:
    """這條命對結是護還是損；特殊命照真的那一讀。"""
    f = origins.FATES.get(fate)
    return (f.face[-1] if reading == 2 else f.face[0]) if f else ""


def judge(k: dict, p: dict | None, like: int, rec: dict, early: bool = False, killed: set[str] = frozenset()) -> str:
    """同類的結怎麼收：護、損、平。p：結的人現在的樣子；like：他現在對你的好感；early：事端被你的轉折提早收掉。
    親、情、幽冥看人（死、被抓、走了、好感降 SWING＝損，其他＝護）；眾生、物與地看事端（走到結局＝損，你扭過來＝護，轉向、還在走＝平）；
    己身看好感升降。"""
    if k["kind"] in (LAND, CREW):
        return EVEN if rec["turned_shichen"] is not None or rec["ended_shichen"] is None else HOLD if early else LOSS
    d = like - int(k.get("like") or 0)
    if k["kind"] == SELF:
        return HOLD if d >= SWING else LOSS if d <= -SWING else EVEN
    gone = not p or p["status"] != "ALIVE" or p["name"] in killed or plot.JAIL_SPOT in p["location"] or p["location"] == society.AWAY
    return LOSS if gone or d <= -SWING else HOLD


def review(n: int, mine: tuple[str, int], his: tuple[str, int], him: str, cast: dict, verdict: str) -> str:
    """死後回顧一行（草稿第五節，接在因果鏈下面）。mine、his：（命, 讀）；verdict：那章紀錄最後一欄。"""
    on = "、".join("你們兩人" if k["kind"] == SELF else k["who"] + ("一帶" if k["kind"] == LAND else "") for k in read(cast))
    if not on or not verdict:
        return ""
    head = f"第{n}章：{mine[0]}撞上{his[0]}（{him}），"
    if verdict == BOTH:
        return head + f"{on}{'都' if '、' in on else ''}牽了進來。"
    if verdict == EVEN:
        return head + f"落在{on}身上，誰也沒壓過誰。"
    won = [f for f in (mine, his) if face(*f) == verdict]
    tail = f"，{won[0][0]}壓過{(his if won[0] is mine else mine)[0]}" if len(won) == 1 else ""
    return head + f"落在{on}身上，最後{on}{'擋住了' if verdict == HOLD else '沒擋住'}{tail}。"


def say(cast: dict, told: str = "") -> str:
    """說書人那一句（開章那回合【主事】，當下不點破）。told：前面那句已經點名的人不再說，幽冥只留提起亡者。"""
    parts = []
    for k in read(cast):
        if k["kind"] == LAND and k["who"]:
            parts.append(f"這件事落在{k['who']}一帶")
        elif k["kind"] in ("親", "情", CREW, DEAD) and k["who"] in told:
            parts += [f"有人提起過世的{k['dead']}"] if k["kind"] == DEAD else []
        elif k["kind"] == CREW:
            parts.append(f"這件事也牽到{k['who']}（{k['of']}那邊{k['as']}的人）")
        elif k["kind"] == DEAD:
            parts.append(f"這件事也牽到{k['who']}（過世的{k['dead']}的{k['as']}），有人提起{k['dead']}")
        elif k["kind"] != SELF and k["kind"] != LAND:
            parts.append(f"這件事也牽到{k['who']}（{k['of']}的{k['as']}）")
    return "；".join(parts) + "。" if parts else ""
