"""因果鏈（第 7-3c2 批，WHITEPAPER (68)、(68)-1、(68)-2；句型 progress/因果鏈句型草稿.md）。純函式。

連結都記「根」＝你那件事（events 表的殺人、傷人、救命）的 id；只有追得到根的才記：
- 你的事算到勢力的原因、縣衙往國算的原因：event_id 寫根（game/factions.deeds、game/nations.rollup）。
- 開戰（勢力、國）：世界事件 WAR，兩方之間還在的壞原因有根的那筆最重的當根（blame）。
- 壓力到盡頭：世界事件 TOP（detail 多 key、v、why）；推到盡頭的那項是有根的交戰、或有根的事件外因（pressure 的 ev 第四格）。
- 兩種世界事件都記你那份佔幾成（mine，百分比）和你以外最重那筆怎麼說（also）：不過半時句子寫「加上…，」（(68)-2）。
世界事件不屬於哪一生（session_id 空字串），讀 events 表的其他地方只看這一生、hearsay.KINDS，碰不到。
回顧（review）：命盤死了才有，從根往後每站取最早一筆，挑站多、牽動多的最多 MAX 條。
"""
from __future__ import annotations

from . import disaster, hearsay, opinion, pressure
from .clock import SHICHEN_PER_YEAR as YEAR
from ..util import new_id

WAR, TOP = "開戰", "到頭"
KINDS = (WAR, TOP)
MAX, NEAR_YEARS, HALF = 5, 10, 50
ROOT = {hearsay.KILL: "你在{地}殺了{人}", hearsay.HURT: "你在{地}打傷了{人}", hearsay.SAVE: "你在{地}救了{人}"}
WORDS = {opinion.ATTACK: "成員之間動手", opinion.ROB: "成員之間偷搶", opinion.BETRAY: "背盟"}   # 原因種類怎麼說；其他照種類（多半是牌名）


def event(kind: str, actor: str, target: str, place: str, root: str, now: int, turn_no: int, **detail) -> dict:
    return {"id": new_id("evt"), "session_id": "", "kind": kind, "actor": actor, "target": target, "place": place,
            "detail": {"from": root, **detail}, "secret": 0, "era": "", "clock_shichen": now, "turn_no": turn_no}


def _rooted(r: dict) -> bool:
    return r["event_id"].startswith("evt_")   # 舊恨的 event_id 是原因的 id，不算


def blame(rs: list[dict], x: str, y: str, t: int, years: float, say=lambda r: WORDS.get(r["kind"], r["kind"])) -> dict:
    """x、y 之間還在的壞原因 → {"from": 根, "mine": 你那份佔幾成, "also": 你以外最重那筆怎麼說}；沒有根是 {}。"""
    bad = [r for r in rs if {r["holder"], r["toward"]} == {x, y} and r["value"] < 0 and r["axis"] == opinion.LIKE
           and opinion.alive(r, years, t)]
    mine = [r for r in bad if _rooted(r)]
    if not mine:
        return {}
    root = min(mine, key=lambda r: r["value"])["event_id"]
    rest = [r for r in bad if r["event_id"] != root]
    share = round(100 * sum(r["value"] for r in bad if r["event_id"] == root) / sum(r["value"] for r in bad))
    return {"from": root, "mine": share, "also": say(min(rest, key=lambda r: r["value"])) if rest else ""}


def war_root(events: list[dict], x: str, y: str) -> str:
    """x、y 最近一次開戰的根。"""
    return next((e["detail"]["from"] for e in reversed(events) if e["kind"] == WAR and {e["actor"], e["target"]} == {x, y}), "")


def bare(why: str) -> str:
    """「自從旱災之後」→「旱災」（句子裡「加上旱災」）。"""
    return why.removeprefix("自從").removesuffix("之後")


def tops(moved: list[tuple], row: dict, pushes: list[tuple], war) -> list[tuple[str, int, dict, str]]:
    """這個月推到盡頭、追得到根的那幾條 → [(壓力, 級, {"from", "mine", "also"}, 原因)]。war()＝這處在打的仗的根。"""
    out = []
    for k, v, cause, why in moved:
        ev = row.get(k, {}).get("ev", [])
        root = (ev[3] if len(ev) > 3 else "") if cause == pressure.EVENT else war() if cause == "交戰" else ""
        if abs(v) != pressure.EDGE or not root:
            continue
        ps = [p for p in [q[1:] for q in pushes if q[0] == k] + ([(ev[0], pressure.EVENT, ev[2])] if ev else []) if p[0] * v > 0]
        rest = [p for p in ps if p[1] != cause]
        mine = sum(abs(p[0]) for p in ps if p[1] == cause)
        out.append((k, v, {"from": root, "mine": round(100 * mine / max(1, mine + sum(abs(p[0]) for p in rest))),
                           "also": bare(max(rest, key=lambda p: abs(p[0]))[2]) if rest else ""}, why))
    return out


def _also(d: dict) -> str:
    return f"加上{d['also']}，" if d.get("also") and d.get("mine", 100) <= HALF else ""


def review(rows: dict, nations: set[str], state_of: dict[str, str]) -> list[str]:
    """一生結束的因果鏈（(68)）：rows 要 happened、npc_reasons、place_states、life、era；state_of：村鎮 → 州。"""
    life, era, happened = rows["life"], rows.get("era", {}).get("era", ""), rows.get("happened", [])
    roots = {e["id"]: e for e in happened if e["session_id"] == life and e["kind"] in ROOT}
    if not roots:
        return []
    steps: dict[str, dict[int, tuple]] = {r: {} for r in roots}   # 根 → 站 → (時刻, 一句, 牽動的)

    def add(root: str, stage: int, t: int, text: str, *who: str) -> None:
        if root in steps and (stage not in steps[root] or t < steps[root][stage][0]):
            steps[root][stage] = (t, text, set(who))

    for r in rows["npc_reasons"]:
        h, w, bad = r["holder"], r["toward"], r["value"] < 0
        if h in nations:
            add(r["event_id"], 1, r["clock_shichen"], f"{h}跟著對{w}{'交惡' if bad else '交好'}", h, w)
        else:
            add(r["event_id"], 0, r["clock_shichen"], f"{h}記恨上了{w}" if bad else f"{h}念著{w}的好", h, w)
    tops_ = []
    for e in happened:
        d, t = e["detail"], e["clock_shichen"]
        if e["kind"] == WAR:
            add(d["from"], 2, t, f"{_also(d)}{e['actor']}與{e['target']}開戰", e["actor"], e["target"])
        elif e["kind"] == TOP:
            word = pressure.LEVELS[d["key"]][d["v"] + pressure.EDGE]
            add(d["from"], 3, t, f"{_also(d)}{e['target']}從此{pressure.LABEL[d['key']]}{word}", e["target"])
            tops_.append(e)
    for s in rows.get("place_states", []):   # 天災：同州、到盡頭之後十年內、那條對得上（disaster.LEAN）
        lean = disaster.LEAN.get(s["name"])
        for e in tops_ if lean else ():
            d, place = e["detail"], state_of.get(e["place"], "")
            if (d["key"], d["v"] > 0) == (lean[:2], lean[2] == "+") and place and s["place"] in (place, e["place"]) \
                    and 0 <= s["started_shichen"] - e["clock_shichen"] <= NEAR_YEARS * YEAR:
                add(d["from"], 4, s["started_shichen"], f"{place}鬧起了{disaster.label(s['name'], era)}", place)
    out = []
    for root, got in steps.items():
        if got:
            e = roots[root]
            head = ROOT[e["kind"]].format(地=e["place"], 人=e["detail"].get("name") or e["target"])
            frame = e["detail"].get("frame")
            chain = sorted((t, k, text) for k, (t, text, _) in got.items())
            out.append((-len(got), -len(set().union(*(w for _, _, w in got.values()))), e["clock_shichen"],
                        " → ".join([head + (f"，栽給了{frame}" if frame else "")] + [text for _, _, text in chain])))
    return [line for *_, line in sorted(out)[:MAX]]
