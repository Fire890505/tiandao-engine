"""暗線（WHITEPAPER 16v 第 32～36、42、46 題；數字暫定）：路線背後有人在動，只有 Python 知道。純函式。

- 跟著路線，一條路線一次：事端、怪談、傳說，命途寫了專屬牌的才有（龍脈的礦主，第 81-3 題）。啟動條件見 game/darks.py。
- 有階段表的路線：玩家推動換階，對手欠一步（第 81-2 題）；大失敗不欠步，改成陷阱（第 81-7 題，domain/trap.py）。沒有階段表的照舊：玩家推進一次欠一步。
  上次推進或走一步之後過了 PACE（5 天）也走一步，隔得久一次走幾步（第 114-1、126-6 題），最多 STEPS 步。第幾步抽第幾階的隱藏牌（rules/content/dark.txt）。
- 對手走一步，階段表寫了「暗線:N」就往前一階；第三步推到最後一階，走完不另外收尾（第 81-1、81-5 題）。
- 欠了就在回合結尾走，不跟別的事搶主事、不等上一步的破綻（第 5-1-1 題）。每一步留一個破綻（tells），路線結束前都在；
  人在那裡查到其中一條就打斷，暗線停住、拿到把柄，已經發生的不還原。最後一步之後再過 PACE 才算走完。
- 破綻不比關鍵字：查探或問話時問模型這句是不是在查它（第 53-2 題）；敘事寫完由模型改寫一句帶進去（第 53-3 題）。
- 人不在路線那裡照樣走，回到那裡才寫成旁人說的（第 81-10、5-1-1 題）。
- 對手（foe，第 5-1-3 題）：事端＝隱瞞者，命途＝立場寫「敵」的角色，怪談、傳說＝幕後勢力的首領，沒有就空字串（不察覺）。
- 每張牌針對一個門路（草稿 3-1，第 5-2 批）：事端由 game/darks.py 挑，對手知道你碰過的優先，不堵最後一條；
  破綻記下動了哪個門路、碰到時那句、兩種解法。
- 擋路、看見、補回來、反撲（第 5-3 批，game/darks.py 的 held、stall）：碰到被動過的門路出碰到時那句（第一次整句，之後只寫 SAME）；
  被擋過再碰到，行動對得上解法、本來判定成功就補回來；第一次補回來對手要反撲（back：下一步一定出牌，打在這條路上）。
- 反咬（第 5-4a 批）：打斷時有對手，問要當眾揭穿還是私下要脅（WINDOW 回合，過了只剩把柄）。揭穿補回人、名，要脅補回物、證、地；
  之後第一次離開那裡，對手的人當場出手一張陷阱（大典第 32 條，game/traps.py 的 after）。
- 反撲補強（第 5-4b 批）：同一道門路再被動，上次補回來用的行動那個解法拿掉（大典第 9 條）；三步走完以後（走完的也算）補回來，
  再抽一張第三階，不算步數、不推主線，這張的破綻補回來不再反撲（第 5-4-7 題）。打斷、收買之後不反撲。
- 支線（第 5-4c 批）：請託寫「暗線:門路」的，對手動過那道門路才開口，辦成就補回來（moved_gate、mend；game/sides.py）。
- 案中案（第 5-5a 批）：打斷而且解開才翻（link），下一層和翻面在 game/chains.py；下一層的暗線一開始就啟動、沿用幕後（game/darks.py）。
角色卡欄位：dark、chain（陷阱的欄位見 domain/trap.py）。
"""
from __future__ import annotations

from dataclasses import dataclass

from ..config import PROJECT_ROOT
from . import deck as cards
from . import route, trap
from .clock import SHICHEN_PER_DAY

KINDS = (route.PLOT, route.ZONE, route.LEGEND)
RUN, CUT, BOUGHT, DONE = "在走", "打斷", "收買", "走完"
STEPS, WINDOW = 3, 3                # 最多幾步；收買要在幾回合內回
PACE = 5 * SHICHEN_PER_DAY         # 對手自己動的間隔（第 114-1 題）
HUNCH = "總覺得背後有人在看著"      # 被對手的人看到的那回合（第 114-2 題）：不說是誰、看到什麼
LATE = 7 * SHICHEN_PER_DAY         # 怪談、傳說拖多久算拖得久（第 54 題）
GAZE_BAND = 2                      # 注視到第幾段，路線一開始就啟動
EARLY = 12                         # 提前幾個時辰（第 35 題）
EARLY_LEFT = 6                     # 提前後至少留幾個時辰，不把案子弄到解不開
NO_MARK = "一個沒見過的記號"
MOVE, SEND, KILL, BRIBE, RUSH = "移證", "送走", "滅口", "塞錢", "提前"   # 塞錢：對你的（第 35-1 題）
SCARE, BUY, SMEAR, GRAB = "嚇住", "收買", "放話", "搶證"           # 第 5-2 批新加，擋路在 5-3
SWAY = "說動"   # 不知情的幫兇（第 5-5c3 批）：只挑喜歡對手那一方的人；說破（問）翻臉吐破綻，不說破（查）不反撲
SAME = "那邊還是一樣"              # 第二次起碰到同一道門路（第 5-3-3 題）
HURT = 4                           # 血少於幾分之一算重傷（第 5-3-1 題：補回來的人再比一次）
FAKE, WATCH, TAKE_AWAY = "假規則", "盯上", "帶走"
SHIFT, LIE, HAUNT = "移動", "錯說法", "纏上"
TAKE, REFUSE = "收下這袋銀子", "把銀子退回去"
TAKE_WORDS, REFUSE_WORDS = ("收下", "收了"), ("退回", "退了", "拒絕", "不收")
PAID = "收過錢"                    # 重大紀錄（第 35-1 題）
BRIBE_MONEY = 300                  # 收買的錢，× 2 的境界次方（第 48-2 題）
TOWN, IN_PERSON, HEARD = "村鎮", "在場", "傳聞"   # 牌的場景（第 53、64 題）
PEOPLE = ("隱瞞者", "人")           # 在場的牌，看這些人在不在
FILLED = ("證人", "新地", "記號")    # Python 填的空
WILD = ("荒野", "秘境", "廢墟", "古蹟")
LEFT = "東西留在原處，主角只是看到，沒有拿走"   # 第 49 題
RETURNED = "整袋退回，手上什麼都沒留"
EXPOSE, THREATEN = "當眾揭穿他", "私下拿這個要脅他"        # 反咬（第 5-4-1～5-4-3 題）：打斷時有對手才問，WINDOW 回合內回
EXPOSE_WORDS, THREATEN_WORDS = ("揭穿", "說出去"), ("要脅", "威脅")
EXPOSED, GRIPPED = ("人", "名"), ("物", "證", "地")          # 揭穿、要脅各補回哪幾類門路
RECALL = {BUY: "收過背後的人的錢", SCARE: "被背後的人嚇住過", SEND: "被背後的人送去外地"}   # 路線結束記事（第 5-4-5 題）：不寫對手的名字


@dataclass(frozen=True)
class Card:
    deck: str
    tier: int
    effect: str
    scene: str
    aim: str          # 針對：人、物、證、名、地；命途寫「種類:是誰」
    tell: str         # 破綻
    found: str        # 查到時
    trace: str        # 記號句
    hit: str          # 碰到時
    fixes: tuple      # 解一、解二：「行動:做法:結果」


CONTENT = PROJECT_ROOT / "rules" / "content"
# 共用格式（第 4-5 題）：條件 路線、步（暗線已經走了幾步，抽第 步+1 階）、場景；目標欄＝針對；內容欄 破綻｜查到時｜記號｜碰到時｜解一｜解二
DECK = [Card(need["路線"], int(need["步"]) + 1, c.kind, need.get("場景", ""), c.target, c.text, *c.more[:3], tuple(filter(None, c.more[3:])))
        for c in cards.read(CONTENT / "dark.txt") for need in (dict(c.need),)]
_ENDS = [line.split("｜") for line in (CONTENT / "dark_ends.txt").read_text(encoding="utf-8").splitlines() if not line.startswith("#")]
ENDS = {r[1]: r[2] for r in _ENDS if r[0] == "走完"}
MARKS = {r[1]: r[2] for r in _ENDS if r[0] == "記號"}
FLIPS = {r[1]: r[2] for r in _ENDS if r[0] == "翻面"}   # 案中案翻面那句：信、人名、帳（第 5-5-2 題）
LAYERS = 2                                            # 案中案最多再接幾層（第 13、42-3 題）


def fields() -> dict:
    """chain：案中案的下一層（第 5-5 批）。翻面前 key 是空字串，翻面後是下一層路線的 key，那條的暗線一開始就啟動。"""
    return {"dark": None, "chain": None}


def link(d: dict | None, r: dict, place: str, people: list[str], turn_no: int, now: int) -> dict | None:
    """案中案（第 40、5-5-5 題）：暗線打斷了、這條又解開，而且是事端、怪談、傳說才翻，下一回合翻；最多再接 LAYERS 層。
    from：這一層；people：這一層的人（下一層有同一個人就寫人名）；since：這時以後新放的事端算錢流過去（帳）；
    foe：下一層的對手，翻面時定（宿敵或首領，第 5-5-6、5-5-7 題），空的照舊挑；
    witness：這一層的對手，翻面時下一層換了人就揭出他是被推出來頂的（第 5-5-11～5-5-13 題），不然清掉。"""
    if not d or d["state"] != CUT or r["kind"] not in KINDS or d["layer"] >= LAYERS:
        return None
    return {"key": "", "from": r["key"], "place": place, "by": d["by"], "mark": d["mark"], "foe": "", "witness": d["foe"], "layer": d["layer"] + 1,
            "people": people, "due": turn_no + 1, "since": now}


def start(key: str, by: str, mark: str, foe: str, now: int, layer: int = 0, witness: str = "") -> dict:
    """by：幕後，沒有就空字串。foe：對手。last：上次推進或走一步的時候。moved：搬走的線索 → 新地方。
    tells：每一步留下的破綻，連同動了哪個門路（gate、aim＝人物證名地）、碰到時那句（hit）、兩種解法（fixes）、
    碰到幾次（hits）、補回來沒（fixed）、反撲過沒（back）、用哪種行動補回來的（used，大典第 9 條）、手段（means，第 5-4-5 題記事用）。back：要反撲的門路（第 5-3-5 題）。
    offer：在走時是收買，打斷後是反咬（只有 until）。hunt：反咬過，第一次離開那裡對手的人出手（大典第 32 條）。layer：案中案第幾層。
    witness：上一層被推出來頂的人，找他交談吐一條破綻，吐了就清掉（第 5-5-13 題）。"""
    return {"key": key, "by": by, "mark": mark, "foe": foe, "state": RUN, "step": 0, "last": now, "owed": False, "tells": [],
            "offer": None, "moved": {}, "back": "", "hunt": False, "layer": layer, "witness": witness, **trap.fields()}


def reveal(d: dict) -> tuple[dict, str]:
    """浮出最早一條還沒看見的破綻，回傳它的文字；都看見過就是空字串（假線索、回到那裡聽說、被推出來頂的人開口）。"""
    t = next((t for t in d["tells"] if not t["seen"]), None)
    return ({**d, "tells": [{**x, "seen": True} if x is t else x for x in d["tells"]]}, t["text"]) if t else (d, "")


def due(d: dict, moved: bool, now: int) -> int:
    """這回合對手該走幾步：玩家推進了欠一步，隔了幾個 PACE 再加幾步；之前欠著沒走的至少一步。"""
    n = int(moved) + (now - d["last"]) // PACE
    return min(STEPS - d["step"], max(n, int(d["owed"])))


def deck_of(r: dict) -> str:
    """這條路線抽哪一副：有專屬的用專屬的（命途，第 81-3 題），不然用這類路線的那副；命途沒寫就沒有暗線。"""
    if any(c.deck == r["name"] for c in DECK):
        return r["name"]
    return r["kind"] if r["kind"] in KINDS else ""


def tier(d: dict, deck: str) -> list[Card]:
    return [c for c in DECK if c.deck == deck and c.tier == d["step"] + 1]


def moved(sheet: dict, key: str) -> dict:
    """這條事端搬走的線索。"""
    d = sheet.get("dark")
    return d["moved"] if d and d["key"] == key else {}


def moved_gate(sheet: dict, key: str, gate: str) -> bool:
    """這條路線的對手動過這道門路、還沒補回（支線條件「暗線:門路」，第 5-4-4 題）。"""
    d = sheet.get("dark")
    return bool(d and d["key"] == key and any(t["gate"] == gate and not t["fixed"] for t in d["tells"]))


def mend(d: dict, gate: str, act: str) -> dict:
    """那道門路還沒補回的破綻都補回來，記用哪種行動；第一次補回來對手要反撲（同 game/darks.py 的 _meet）。"""
    hit = [t for t in d["tells"] if t["gate"] == gate and not t["fixed"]]
    d = {**d, "owed": True, "back": gate} if any(not t["back"] for t in hit) else d
    return {**d, "tells": [{**t, "fixed": True, "back": True, "used": act} if t in hit else t for t in d["tells"]]}


def recall(d: dict | None, me: str) -> dict[str, str]:
    """路線結束時，玩家碰過或補回來的「人」門路各記一句（第 5-4-5 題）：補回來＝說服過他（蓋過別的），沒補回照手段；滅口的不寫。"""
    tells = sorted(d["tells"] if d else [], key=lambda t: t["fixed"])
    return {t["gate"]: f"{me}說服過他" if t["fixed"] else RECALL[t["means"]] for t in tells
            if t["aim"] == "人" and (t["hits"] or t["fixed"]) and (t["fixed"] or t["means"] in RECALL)}


def valid(sheet: dict) -> bool:
    d, c = sheet["dark"], sheet.get("chain")
    if c is not None and not (isinstance(c, dict) and all(isinstance(c.get(k), str) for k in ("key", "from", "place", "by", "mark", "foe", "witness"))
                              and all(isinstance(c.get(k), int) for k in ("layer", "due", "since"))
                              and isinstance(c.get("people"), list) and all(isinstance(p, str) for p in c["people"])):
        return False
    return d is None or isinstance(d, dict) and d.get("state") in (RUN, CUT, BOUGHT, DONE) \
        and all(isinstance(d.get(k), str) for k in ("key", "by", "mark", "foe", "witness")) and isinstance(d.get("step"), int) \
        and isinstance(d.get("layer"), int) \
        and isinstance(d.get("last"), int) and isinstance(d.get("owed"), bool) and isinstance(d.get("moved"), dict) \
        and isinstance(d.get("back"), str) and isinstance(d.get("hunt"), bool) and isinstance(d.get("tells"), list) \
        and all(isinstance(t, dict) and all(isinstance(t.get(k), str) for k in ("text", "found", "trace", "gate", "aim", "hit", "used", "means"))
                                                       and all(isinstance(t.get(k), bool) for k in ("seen", "fixed", "back"))
                                                       and isinstance(t.get("hits"), int) and isinstance(t.get("fixes"), list)
                                                       and all(isinstance(f, str) for f in t["fixes"]) for t in d["tells"]) \
        and (d.get("offer") is None or isinstance(d["offer"], dict)) and trap.valid(d)
