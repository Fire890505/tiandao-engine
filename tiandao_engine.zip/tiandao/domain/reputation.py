"""名聲（第 10c-3b 步）：旁人眼中的你。純函式，不碰資料庫、不呼叫 AI。

規則（2026-10-05 與使用者一題一題定案，見 progress/WHITEPAPER.md 第 14 節「10c-3 傳聞與名聲的細節」，數字暫定）：
- 名聲＝傳到當地、還沒過時、關於你的傳聞（當地聽到的版本，走樣照算）的加總；不另存名聲數字。
  做事的人傳成「不知是誰」的不算：沒人知道是你。
- 四個方向各自分級；初見時依此地的名聲 × 對方的性格定下關係的起點（最多 ±20）。
- 找上門的機率乘上名聲（看四個方向裡最高的一級）。
"""
from __future__ import annotations

from dataclasses import dataclass

from . import npc, rumors

CRUEL, HONOUR, KIND, MIGHT = "狠辣", "信義", "仁善", "威名"
AXES = (CRUEL, HONOUR, KIND, MIGHT)
UNKNOWN, HEARD, FAMOUS, FAITHLESS = "沒人提起", "小有耳聞", "遠近皆知", "背信之名"
LEVELS = (UNKNOWN, HEARD, FAMOUS, FAITHLESS)
FLOORS = ((50, FAMOUS), (20, HEARD))
FAITHLESS_BELOW = -20                       # 信義 −20 以下
TOLD = 3                                    # 給說書人最重要的幾則

# 初見：小有耳聞 5、遠近皆知 10（「半」＝一半，取整）；背信之名好感 −10；加總後好感最多 ±20、信任最多 +20
STEP = {HEARD: 5, FAMOUS: 10}
FAITHLESS_AFFINITY = -10
FIRST_CAP = 20
# 找上門：看最高的一級（背信之名比照小有耳聞）
FIND_BOOST = {UNKNOWN: 1, HEARD: 1.25, FAMOUS: 1.5}
SLANDER = {CRUEL: 5, HONOUR: -10, KIND: -5}   # 壞話一則（第 7-2b 批，㉘）


@dataclass(frozen=True)
class Fame:
    """你在某地的名聲。"""
    levels: dict                    # 方向 → 等級
    told: tuple[str, ...] = ()      # 最重要的幾則（當地版本的句子）
    big: tuple[str, ...] = ()       # 傳到這裡的、關於你的大事（傳聞 id）


def points(v: dict) -> dict[str, int]:
    """一則關於你的傳聞（當地版本）讓各方向加多少。殺比你弱的人（境界比你低或凡人）最重。"""
    kind, lv, mine = v["kind"], v["lv"], v["subject_lv"]
    if kind == rumors.KILL:
        if lv == 0 or lv < mine:
            return {CRUEL: 20, KIND: -5}
        return {CRUEL: 10, MIGHT: 15} if lv > mine else {CRUEL: 10}
    if kind in (rumors.HURT, rumors.WOUND):
        return {CRUEL: 3}
    if kind in (rumors.RISE, rumors.LEAP):
        return {MIGHT: 20 if lv >= rumors.HIGH_RISE_LV else 10}
    if kind == rumors.SLANDER:   # 壞話（第 7-2b 批，㉘）：照他恨你最重的那件事
        return {v["detail"]: SLANDER.get(v["detail"], 0)}
    return {rumors.KEPT: {HONOUR: 5}, rumors.BROKE: {HONOUR: -10}, rumors.FAVOUR: {KIND: 3},
            rumors.DISPEL: {MIGHT: 10},                  # 打散亡者（第 11-2 步，暫定）
            rumors.RELIEF: {KIND: 10},                   # 救災（16j 第 5 題）
            rumors.FORCED: {MIGHT: 5, CRUEL: 5},          # 強拆怪談：霸道（16l 第 6-6 題）
            rumors.CLEARED: {MIGHT: 5, KIND: 5}}.get(kind, {})   # 破了怪談（第 19-1 步，暫定）


def level(axis: str, score: int) -> str:
    if axis == HONOUR and score <= FAITHLESS_BELOW:
        return FAITHLESS
    return next((name for floor, name in FLOORS if score >= floor), UNKNOWN)


def tally(heard: list[dict]) -> Fame:
    """heard：關於你、傳到這裡的傳聞（當地版本）。"""
    known = [v for v in heard if v["subject"]]
    scores = dict.fromkeys(AXES, 0)
    for v in known:
        for axis, n in points(v).items():
            scores[axis] += n
    top = sorted(known, key=lambda v: (-rumors.SIZES.index(v["size"]), -v["clock_shichen"]))[:TOLD]
    return Fame({axis: level(axis, s) for axis, s in scores.items()}, tuple(rumors.text(v) for v in top),
                tuple(v["id"] for v in known if v["size"] == rumors.BIG))


def heard_of(fame: Fame) -> bool:
    """此地有沒有人聽過你：任一方向小有耳聞以上，或有關於你的大事傳到這裡。"""
    return any(l != UNKNOWN for l in fame.levels.values()) or bool(fame.big)


def line(levels: dict) -> str:
    """給說書人的【你在此地的名聲】：只列有人提起的方向；都沒有回傳空字串。"""
    return "、".join(f"{axis}（{l}）" for axis, l in levels.items() if l != UNKNOWN)


def find_boost(levels: dict) -> float:
    return max(FIND_BOOST[HEARD if l == FAITHLESS else l] for l in levels.values())


def first_view(levels: dict, p: dict) -> tuple[int, int]:
    """初見時依名聲 × 對方性格的（好感, 信任）起點。
    信任從 0 起算、不會是負的，所以壞名聲一律扣好感（2026-10-05 使用者選 A）；初見只會讓信任往上。"""
    ambition, kindness, courage, suspicion = (npc.trait_level(p[t]) for t in npc.TRAITS)
    affinity = trust = 0
    s = STEP.get(levels[CRUEL], 0)
    if kindness == "高":                     # 善念高：提防（原本好感、信任各扣，信任那份也改扣好感）
        affinity -= 2 * s
    elif ambition == "高":                   # 野心高、善念不高：慕強
        affinity += s // 2
    else:
        affinity -= s // 2
    if levels[HONOUR] == FAITHLESS:
        affinity += FAITHLESS_AFFINITY
    else:
        s = STEP.get(levels[HONOUR], 0)
        trust += s // 2 if suspicion == "高" else s
    s = STEP.get(levels[KIND], 0)
    if kindness == "高":
        affinity += s
    elif ambition == "高" and kindness == "低":   # 覺得好欺負
        affinity -= s // 2
    else:
        affinity += s // 2
    s = STEP.get(levels[MIGHT], 0)
    if courage == "中":                      # 敬重
        affinity += s // 2
    elif courage == "高":                    # 想挑戰；膽識低改成怕（first_fear）
        affinity -= s // 2
    return npc.clamp(affinity, (-FIRST_CAP, FIRST_CAP)), min(trust, FIRST_CAP)


def first_fear(levels: dict, p: dict) -> int:
    """初見時的怕（第 121-10 題）：膽識低的人聽過你的威名（有人提起 +10、名聲響亮 +20，記成最接近的一級）。"""
    return 2 * STEP.get(levels[MIGHT], 0) if npc.trait_level(p["courage"]) == "低" else 0


def talk_due(sheet: dict, fame: Fame) -> bool:
    """這回合要不要請說書人改寫「江湖傳言中的你」：此地有人聽過你，而且名聲任一方向跨過門檻
    （跟上次寫的時候不同），或有上次寫的時候還沒算進去的大事。"""
    if not heard_of(fame):
        return False
    return fame.levels != sheet["reputation_levels"] or not set(fame.big) <= set(sheet["reputation_big"])


def levels_text(levels: dict) -> str:
    return "；".join(f"{axis}：{l}" for axis, l in levels.items())
