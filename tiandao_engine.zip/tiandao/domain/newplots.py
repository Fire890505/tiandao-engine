"""模型寫的事端（progress/模型生成內容.md 第八節，13 題＋11-1）。純函式，不呼叫模型。

- plan：照 rules/content/plot_parts.txt 擲手段、遮掩、受害、三個破綻媒介（兩個入口、一個收尾）、表面的詞、處名、載體（第 3～6、9、10 題）。
- 共通骨架（第 2 題甲）：隱瞞者、受害者、第三者；四處；線索 入口一、入口二 → 中段（第三者說漏）→ 收尾；轉折 揭穿、逼問、入夥、作證＋手段專屬。
  有邏輯的整句（真相、說漏、線索指向、轉折、時間線、結局、轉向）Python 拼；模型分三段只寫短欄（第 1 題乙、第 12 題甲）：
  blind 不知道真相的（提示裡沒有真相）、known 知道真相的、close 收場（名字、痕跡）。
- faults：逐欄審長短、中文、時代、代稱、洩底（第 8 題甲）、撞名。record：拼成跟 rules/content/plots/ 一樣格式的全文（plots_m）。
- 人在放事端時才挑（game/plots.place：先挑合條件的現成的人，挑不到照條件生；那處有勢力就讓隱瞞者加入，第 11-1 題乙）。
"""
from __future__ import annotations

import random
from contextvars import ContextVar

from . import cards, checks, clauses, deck, newlegends, plot, stage
from .tales import CONTENT

MODEL = newlegends.MODEL
OPENING, MORE_CHANCE, MAX_PER_WORLD = 2, newlegends.MORE_CHANCE, newlegends.MAX_PER_WORLD   # 第 8 題甲：開局 2 條、補寫 1 條
PARTS = ("blind", "known", "close")
SPANS = {"rumor": (6, 30), "act": (4, 30), "say": (6, 40), "spot": (10, 40), "clue": (4, 30), "small": (8, 30),   # spot 至少 10 字：地點描述的下限，存檔會擋
         "trace": (8, 40), "name": (2, 8)}
UNLABEL = {"主事的人": "那人", "主事者": "那人", "幫手": "那個幫忙的人"}   # 模型照抄代稱時換掉（第二輪量測：痕跡常寫「幫手」）
LABELS = {"受害者": "苦主", "隱瞞者": "主事的人", "第三者": "幫手", "仇家": "他的仇家", "勢力": "背後的勢力", "首領": "勢力的頭頭", "村": "這裡",
          plot.HOSTAGE: "被綁的家人"}

_rows = [l.split("｜") for l in (CONTENT / "plot_parts.txt").read_text(encoding="utf-8").splitlines() if l and not l.startswith("#")]
WAYS: dict[str, dict[str, list[list[str]]]] = {}
for _r in _rows:
    if _r[0] == "手段":
        WAYS.setdefault(_r[1], {}).setdefault(_r[2], []).append(_r[3:])
POOL = {}
for _r in _rows:
    if _r[0] in ("詞", "處詞", "載體"):
        POOL.setdefault((_r[0], _r[1], _r[2]), []).append(_r[3:] if _r[0] == "詞" else _r[3].split("、"))
_table = lambda k: {r[1]: r[2:] for r in _rows if r[0] == k}   # noqa: E731
MEDIA, COVERS, VICTIMS = _table("媒介"), _table("遮掩"), _table("受害")
SPOTS = [r[1:] for r in _rows if r[0] == "處"]   # 代號、詞位、地點類型、在
COMMON = [r[1:] for r in _rows if r[0] == "轉折"]
_one = lambda k: next(r[1:] for r in _rows if r[0] == k)   # noqa: E731
TRACED, END, KILLED, TURN_LINE, TURN_END = _one("痕跡")[0].split("、"), _one("結局"), _one("轉向被殺")[0], _one("轉向線"), _one("轉向結局")
FACTION_LINE, SMALL = _one("勢力句")[0], _one("小事")[0]
STAGES, CLOSING, SIDE, CARD_RULES = [r[1:] for r in _rows if r[0] == "階段"], _one("收場"), _one("立場")[0], _table("牌條件")   # 待辦 1
SHOWN = {"隱瞞處": "主事的人的{隱處}", "公共處": "{公處}", "苦主家": "苦主的{苦處}", "藏處": "{藏地}"}   # 給模型看的處


def _w(way: str, key: str) -> str:
    return WAYS[way][key][0][0]


def _opt(way: str, key: str, default: str = "") -> str:
    """第二批 a 多的欄，沒寫的手段照舊。"""
    return _w(way, key) if key in WAYS[way] else default


def _entries(rng: random.Random, closer: str) -> list[tuple[str, str]]:
    """兩個入口：（媒介, 放哪），不重複、放在不同的地方（第 6 題甲）。"""
    while True:
        a, b = rng.sample([m for m in sorted(MEDIA) if m != closer], 2)
        pa = rng.choice(MEDIA[a][1].split("、"))
        pb = [p for p in MEDIA[b][1].split("、") if p != pa]
        if pb:
            return [(a, pa), (b, rng.choice(pb))]


def plan(rng: random.Random, era_now: str, n: int) -> list[dict]:
    """要寫哪幾條：每條擲手段、遮掩、受害、媒介、詞（照時代）。"""
    out = []
    for _ in range(n):
        way = rng.choice([w for w in sorted(WAYS) if ("詞", w, era_now) in POOL])   # 沒寫這個時代的詞就擲不到（養鬼只在古代）
        cover = rng.choice(_opt(way, "遮掩").split("、") if _opt(way, "遮掩") else sorted(COVERS))   # 第二批第 2 題甲：手段指定遮掩
        victim = rng.choice(sorted(VICTIMS))
        words = dict(p.split("=") for p in rng.choice(POOL[("詞", way, era_now)]))
        words |= {slot: rng.choice(rng.choice(POOL[("處詞", slot, era_now)])) for _, slot, *_ in SPOTS}
        closer = rng.choice([m for m in sorted(MEDIA) if MEDIA[m][4]])
        entries = _entries(rng, closer)
        carry = {m: _w(way, "藏物") if m == "物證" and i == 2 else rng.choice(rng.choice(POOL[("載體", m, era_now)]))
                 for i, m in enumerate([*(m for m, _ in entries), closer])}
        out.append({"way": way, "cover": cover, "victim": victim, "era": era_now, "words": words, "entries": entries,
                    "closer": closer, "carry": carry, "end_at": "藏處" if closer == "物證" else "隱瞞處"})
    return out


def _show(slot: dict, text: str) -> str:
    """給模型看的字：角色換成代稱、處換成它的樣子、表面的詞填好。"""
    return plot.fill(plot.fill(text, {**LABELS, **SHOWN}), slot["words"])


def _clue(where: str) -> str:
    return SHOWN.get(where) or f"{LABELS[where]}身上"


def brief(slot: dict, part: str) -> dict:
    """叫 bits 時的 slot：what、era、brief（這一段的背景；blind 不給真相）。"""
    w, c = WAYS[slot["way"]], COVERS[slot["cover"]]
    lines = [f"時代：{slot['era']}。主事的人身分不明；苦主是被害的那一方；幫手是{_w(slot['way'], '第三者是')}。",
             f"大家看到的：{_w(slot['way'], '表象')}。外頭的說法：{c[0]}。"]
    if part != "blind":
        lines.append(f"真相（只有主事的人、幫手知道）：{w['真相'][0][0]}")
    if part == "close":
        lines.append(f"沒人插手的話：{w['結局'][0][0]}。幫手死了的話：{c[2]}，{c[4]}。")
    return {"what": "一件人為的事端", "era": slot["era"], "brief": _show(slot, "\n".join(lines))}


def asks(slot: dict, part: str) -> list[dict]:
    """這一段要模型寫的欄：key、ask（一行）、span、leak（要查洩底）。"""
    w, c, s = WAYS[slot["way"]], COVERS[slot["cover"]], slot
    say = lambda who, what: f"寫{who}{what}，用「說」開頭"   # noqa: E731
    end = lambda fact, how="街坊怎麼說": (f"事情是這樣收場的：「{fact.replace('{收}', s['carry'][s['closer']])}」。"   # noqa: E731
                                          f"寫過了一陣子留下的樣子、{how}，要跟收場對得上")
    look = lambda where, m: (f"在{_clue(where)}查到「{s['carry'][m]}」：寫它看起來怎樣，不要說是誰的、不要說它代表什麼"   # noqa: E731
                             if MEDIA[m][0] == plot.EVIDENCE else
                             f"在{_clue(where)}注意到「{s['carry'][m]}」：寫是怎麼注意到的（一個情形），不要說是誰、不要說它代表什麼")
    out = {
        "blind": [("rumor", f"接在「{_w(s['way'], '表象')}，」後面，寫附近的人看到或聽到的一個情形，不要說是誰做的", "rumor", True),
                  ("v_act", "寫苦主平常的一個小動作，看得出他現在的處境", "act", True),
                  ("v_calm", say("苦主平時對外人說的話", f"（他只知道：{_w(s['way'], '受害者知道')}）"), "say", True),
                  ("v_asked", say("有人問起這件事時苦主說的話", "，多說一點細節"), "say", True),
                  ("v_pressed", "寫苦主被逼急了的反應，像是求人、哭訴", "say", True),
                  ("pub", f"寫{_show(s, '{公處}')}看得到的樣子，大家在議論這件事，不要說是誰做的", "spot", True),
                  ("home", f"寫苦主住的{_show(s, '{苦處}')}看得到的樣子", "spot", True),
                  *((f"e{i}", look(where, m), "clue", True) for i, (m, where) in enumerate(s["entries"], 1)),
                  ("small1", "寫這幾天附近發生的一件跟這事有關的小事，不要說是誰做的", "small", True),
                  ("small2", "再寫一件這幾天附近發生的小事，跟上一件不一樣", "small", True)],
        "known": [("k_act", "寫主事的人平常的一個小動作，外人看了不會起疑", "act", True),
                  ("k_calm", say("主事的人平時對外人說的話", "，裝得什麼事都沒有，不能說出真相"), "say", True),
                  ("k_asked", say("主事的人被問起時說的話", f"，照他對外的說法（{_show(s, c[1])}）講，不能說出真相"), "say", True),
                  ("k_pressed", "寫主事的人被逼問時的反應，冷下臉或威脅人，不能認", "say", False),
                  ("t_act", f"寫幫手的一個小動作，{_opt(s['way'], '第三者樣子', '看得出他心虛，但看不出他做了什麼')}", "act", True),
                  ("t_calm", say("幫手平時對外人說的話", _opt(s["way"], "第三者平時", "，撇清自己")), "say", True),
                  ("t_asked", say("幫手被問起時說的話", "，不小心露出一點破綻，但不說出真相"), "say", False),
                  ("hide", f"寫{_show(s, SHOWN['隱瞞處'])}看得到的樣子", "spot", False),
                  ("stash", f"寫{_show(s, SHOWN['藏處'])}看得到的樣子，看不出裡頭藏了什麼", "spot", True),
                  ("closer", look(s["end_at"], s["closer"]), "clue", False)],
        "close": [("name", "替這件事取一個名字（像「一箱石頭」「借糧的帳」），不要用人名、地名", "name", False),
                  ("tr_expose", end("有人當眾揭穿了主事的人，" + COMMON[0][6]), "trace", False),
                  ("tr_witness", end(COMMON[3][6]), "trace", False),
                  ("tr_own", end(f"有人{w['轉折'][0][4]}，{w['轉折'][0][5]}"), "trace", False),
                  ("tr_end", end(_w(s["way"], "結局")), "trace", False),
                  ("tr_turn1", end(f"{c[2]}，{c[4]}", "街坊覺得幫手死得可惜"), "trace", False),
                  ("tr_turn2", end(f"{c[2]}，{c[4]}", "街坊覺得幫手死得太巧"), "trace", False)],
    }[part]
    return [{"key": k, "ask": _show(s, a), "span": SPANS[kind], "leak": leak} for k, a, kind, leak in out]


def faults(slot: dict, part: str, got: dict, taken: set[str], era_now: str) -> dict[str, str]:
    """逐欄查：沒過的 → 原因（只重寫這幾欄）。taken：已有的事端名、地名。"""
    lies = [plot.fill(x, slot["words"]) for x in _w(slot["way"], "洩底").split("、")]
    out = {}
    for x in (x for x in asks(slot, part) if x["key"] in got):
        text = _tidy(slot, x["key"], got[x["key"]])
        reason = (checks.basic([(text, x["span"])], era_now)
                  or ("洩底" if x["leak"] and any(w in text for w in lies) else "")
                  or ("撞名" if x["key"] == "name" and checks.clash(text, taken) else ""))
        if reason:
            out[x["key"]] = reason
    return out


def _tidy(slot: dict, key: str, text) -> str:
    """模型寫的字：clauses.bit，拿掉引號（9b 常只開不關）、「說：」的冒號；照抄的代稱換成一般說法（苦主本來就是常用詞，留著）。"""
    text = clauses.bit(text).replace("「", "").replace("」", "").replace("說：", "說")
    for label, plain in UNLABEL.items():
        text = text.replace(label, plain)
    return clauses.bit(text)


def _trace(text: str) -> str:
    return text if text.endswith("。") else f"{text}。"


def record(slot: dict, got: dict) -> dict:
    """存成一條（plots_m）：Python 的骨架＋模型的短欄，組成跟 rules/content/plots/ 一樣格式的全文。got：{段: {欄: 字}}。"""
    g = {k: _tidy(slot, k, v) for part in got.values() for k, v in part.items()}
    s, way, w, c, v = slot, slot["way"], WAYS[slot["way"]], COVERS[slot["cover"]], VICTIMS[slot["victim"]]
    carry = lambda text, m: text.replace("{載}", s["carry"][m])   # noqa: E731
    closer = s["carry"][s["closer"]]
    rows = [f"牌｜{g['name']}｜地方｜事端｜地點:{_w(way, '地點')}｜｜",
            f"來源｜{MODEL}｜{way}｜{s['cover']}｜{s['victim']}",
            f"風聲｜{_w(way, '表象')}，{g['rumor']}。{c[0]}。",
            f"真相｜{w['真相'][0][0]}", f"勢力句｜{FACTION_LINE}。",
            "｜".join(["表面", s["era"], *(f"{k}={x}" for k, x in s["words"].items())]),
            *(f"處｜{code}｜{{{slot_}}}｜{at}｜{kind}｜{g[key]}" for (code, slot_, kind, at), key
              in zip(SPOTS, ("hide", "pub", "home", "stash"))),
            f"人物｜隱瞞者｜隱瞞處｜{_w(way, '隱瞞者目的')}｜{g['k_act']}｜{g['k_calm']}｜{g['k_asked']}｜{g['k_pressed']}"
            f"｜{_w(way, '隱瞞者知道')}｜{_w(way, '隱瞞者想知道')}｜{_w(way, '隱瞞者')}",
            f"人物｜受害者｜苦主家｜{_w(way, '受害者目的')}｜{g['v_act']}｜{g['v_calm']}｜{g['v_asked']}｜{g['v_pressed']}"
            f"｜{_w(way, '受害者知道')}｜{_w(way, '受害者想知道')}｜{v[0] or _w(way, '受害者')}",
            f"人物｜第三者｜公共處｜{_w(way, '第三者目的')}｜{g['t_act']}｜{g['t_calm']}｜{g['t_asked']}｜慌了，說{_w(way, '說漏')}"
            f"｜{_w(way, '第三者知道')}｜{_w(way, '第三者想知道')}｜{_w(way, '第三者')}",
            "旁人｜首領｜隱瞞者", "旁人｜苦主首領｜受害者", f"勢力｜隱瞞者｜{_w(way, '勢力')}",
            *([f"旁人｜刀首領｜第三者", f"勢力｜第三者｜{_opt(way, '刀勢力')}"] if _opt(way, "刀勢力") else []),   # 借刀：刀是另一個勢力的人
            *([f"勢力｜受害者｜{v[1]}"] if v[1] else []),
            *([f"放下去｜{_opt(way, '放下去')}"] if _opt(way, "放下去") else []),
            *([f"旁人｜{plot.HOSTAGE}｜受害者"] if f"{{{plot.HOSTAGE}}}" in w["表象"][0][0] else []),   # 綁架：人質是受害者的家人
            *(["旁人｜仇家｜"] if "{仇家}" in "".join(c) else []),
            *(f"線索｜入口{n}｜{MEDIA[m][0]}｜{{{where}}}｜{MEDIA[m][2]}｜｜{g[f'e{i}']}，{carry(MEDIA[m][3], m)}｜{{第三者}}"
              for i, ((m, where), n) in enumerate(zip(s["entries"], "一二"), 1)),
            f"線索｜中段｜話｜{{第三者}}｜社交｜入口一／入口二｜{{第三者}}說漏了嘴：{_w(way, '說漏')}｜{{{s['end_at']}}}",
            f"線索｜收尾｜物證｜{{{s['end_at']}}}｜潛行、探索｜中段｜{g['closer']}，{carry(MEDIA[s['closer']][4], s['closer'])}｜{{隱瞞者}}",
            f"小事｜{g['small1']}", f"小事｜{g['small2']}", f"小事｜{SMALL}",
            *("｜".join(["時間線", *r]) for r in w["時間線"]),
            f"結局｜{END[0]}｜{_w(way, '結局')}｜{_trace(g['tr_end'])}｜{' '.join(filter(None, (END[1], v[2], _opt(way, '結局多'))))}",
            f"轉向｜第三者｜隱瞞者｜{c[2]}｜{KILLED}", f"轉向線｜6｜{c[3]}｜", "｜".join(["轉向線", *TURN_LINE]),
            f"轉向結局｜{TURN_END[0]}｜{c[4]}｜{_trace(g['tr_turn1'])}｜{_trace(g['tr_turn2'])}｜{TURN_END[1]}"]
    traces = {"揭穿": g["tr_expose"], "作證": g["tr_witness"]}
    more = lambda res: " ".join(filter(None, (res, _opt(way, "揭開多"))))   # noqa: E731  讓人知道真相的轉折多加的
    for key, where, how, before, words, option, fact, res in COMMON:
        rows.append("｜".join(["轉折", key, where, how, before, words, option.replace("{收}", closer), fact.replace("{收}", closer),
                               _trace(traces[key]) if key in TRACED else "", more(res) if key in TRACED else res]))
    for i, (key, where, how, words, option, fact, res, *pre) in enumerate(w["轉折"]):   # 第二個以後（交贖金）：不寫痕跡、不算揭開
        before = (pre[0] if pre else _opt(way, "前置", "中段")).replace("無", "")
        rows.append("｜".join(["轉折", key, where, how, before, words, option.replace("{收}", closer),
                               fact.replace("{收}", closer), "" if i else _trace(g["tr_own"]), res if i else more(res)]))
    return {"name": g["name"], "state": s["era"], "body": "\n".join(rows + _stages(s, g["name"])), "source": MODEL}


def _stages(s: dict, name: str) -> list[str]:
    """階段表和專屬牌（待辦 1：第 1 題乙、第 2 題甲）：條件、判定欄照共用的，句子照手段；格式同 stages.txt、cards.txt。"""
    w = WAYS[s["way"]]
    need = lambda k: " ".join(filter(None, (f"路線:{name}", CARD_RULES[k][1])))   # noqa: E731
    return [f"事｜{_w(s['way'], '事')}", f"素材｜{'、'.join(s['words'][k] for k in ('劣', '渣', '苦處', '公處') if k in s['words'])}",
            f"立場｜{SIDE}", *(f"階段｜{n}｜{line}｜{cond}" for (n, cond), line in zip(STAGES, w["階段"][0])), f"階段｜{'｜'.join(CLOSING)}｜",
            *(f"走向｜｜路線｜{CARD_RULES[k][0]}｜{need(k)}｜｜{CARD_RULES[k][2]}｜{text}" for k, text in w["牌"])]


_WORLD: ContextVar[list[dict]] = ContextVar("plots_world", default=[])


def use(mine: list[dict]) -> None:
    """每回合開頭設一次：這個世界模型寫的事端（plots_m 的列：name、state、body；同 tales.use）。階段表、專屬牌一起設（待辦 1）。"""
    ts = [plot.parse(r["body"]) for r in mine]
    _WORLD.set(ts)
    stage.use({(f, plot.name(t)): t[f] for t in ts for f in ("事", "素材", "立場", "階段") if f in t})
    cards.use([deck.card(c) for t in ts for c in t.get("走向", [])])


def templates(base: list[dict]) -> list[dict]:
    """手寫的＋這個世界模型寫的。"""
    return [*base, *_WORLD.get()]


def model(t: dict) -> bool:
    return bool(t.get("來源"))
