"""NPC 作息（Claude主導盤點第八節）：職業組 × 時段 → 在、出、睡和在做什麼（rules/content/routine.txt）。純函式。

時段照地圖第 4 題：早上卯辰巳、下午午未申、晚上酉戌亥、深夜子丑寅。出＝這段不在場；睡＝在場但睡著，叫醒是一個行動。
"""
from __future__ import annotations

from ..config import PROJECT_ROOT
from .clock import SHICHEN_PER_DAY

BANDS = ("早上", "下午", "晚上", "深夜")
IN, OUT, SLEEP = "在", "出", "睡"
OTHER = "其他"
ASLEEP = "睡著了，叫醒才會理人"


def _read() -> dict[str, tuple[str, ...]]:
    rows = [l.split("｜") for l in (PROJECT_ROOT / "rules" / "content" / "routine.txt").read_text(encoding="utf-8").splitlines()
            if l.strip() and not l.startswith("#")]
    return {who: tuple(r[2:6]) for r in rows for who in r[1].split()}


TABLE = _read()
assert all(len(v) == 4 and all(c == SLEEP or c[:2] in (IN + ":", OUT + ":") for c in v) for v in TABLE.values()), "作息表寫錯了"


def band(now: int) -> str:
    """子丑寅＝深夜，卯辰巳＝早上，午未申＝下午，酉戌亥＝晚上。"""
    return BANDS[(now % SHICHEN_PER_DAY // 3 - 1) % 4]


def state(who: str, now: int) -> tuple[str, str]:
    """（在／出／睡, 在做什麼）。who：職業或修行身分那一組；表上沒有照「其他」。"""
    cell = TABLE.get(who, TABLE[OTHER])[BANDS.index(band(now))]
    return (SLEEP, ASLEEP) if cell == SLEEP else tuple(cell.split(":", 1))
