"""時代演進（2026-10-11 定案，WHITEPAPER 第 16e 節）。純函式。

- 世界過了幾年到門檻就進下一個時代：古代 → 現代 → 未來（數字暫定）；進未來時擲走向（光明或賽博朋克）。
- 每進一個時代擲一次修士的處境（隱世、並存、打壓），權重依時代。
- 地點類型在資料裡一律記古代的叫法（程式各處的比對不用改）；給玩家看、給說書人時用 label 換成這個時代的叫法，
  AI 用新時代的叫法提案時用 base 換回來。地名裡的類型字（客棧、老屋……）換時代時真的改名（game/service 改所有記地名的欄位）。
- 世界的時代卡：{"era", "future", "stance", "since"（這個時代從何時開始）, "next"（下一個門檻；最後的時代是 None）}，
  隱世時可能多一個 "exposure"（曝光度，domain/identity.py；換時代就歸零）。
"""
from __future__ import annotations

import random

from . import newcomer, npc
from .clock import SHICHEN_PER_YEAR
from ..config import PROJECT_ROOT
from ..util import swap

ANCIENT, MODERN, FUTURE = "古代", "現代", "未來"
ERAS = (ANCIENT, MODERN, FUTURE)
BRIGHT, CYBER = "光明", "賽博朋克"
HIDDEN, OPEN, HUNTED = "隱世", "並存", "打壓"
GAP_YEARS = {ANCIENT: (1200, 1800), MODERN: (200, 400)}   # 在這個時代待多久才進下一個（暫定）
LONG = SHICHEN_PER_YEAR            # 一回合過了一年以上＝長時間不在場，到門檻就換（125-12、第 8-1-1 題甲）
DELAY = 50 * SHICHEN_PER_YEAR      # 一般回合到門檻順延，最多延 50 年（125-12，暫定）
ODD = 0.1                          # 隱世時脫節的人在凡人地方，每回合讓曝光 +1 的機率（第 8-3-2 題甲）
LOST = "主角還是舊時代的樣子：穿著、說話、習慣照舊，看不懂這個時代的東西，在凡人面前引人側目。"
STANCES = {MODERN: {HIDDEN: 6, HUNTED: 2, OPEN: 1}, BRIGHT: {OPEN: 6, HIDDEN: 2, HUNTED: 1},
           CYBER: {HUNTED: 6, HIDDEN: 2, OPEN: 1}}
MONEY = {ANCIENT: "銀兩", MODERN: "元", FUTURE: "信用點"}   # 凡人的錢（第 9 題：這一步只給說書人）
TYPES = {   # 古代的類型 → 這個時代的叫法（沒列的不換：宗門、公會、祠堂、秘境、廢墟、荒野）
    MODERN: {"客棧": "旅館", "坊市": "市場", "藥鋪": "藥局", "鐵匠鋪": "五金行", "衙署": "警局", "鏢局": "保全公司",
             "村落": "小鎮", "城鎮": "市區", "住家": "公寓"},
    FUTURE: {"客棧": "膠囊旅館", "坊市": "商城", "藥鋪": "生技診所", "當鋪": "二手交易所", "鐵匠鋪": "改裝廠",
             "武館": "格鬥館", "衙署": "治安局", "鏢局": "保全公司", "村落": "聚落", "城鎮": "城區", "住家": "居住艙"},
}
BASE = {new: old for table in TYPES.values() for old, new in table.items()}
_rows = [l.split("｜") for l in (PROJECT_ROOT / "rules" / "content" / "era_words.txt").read_text(encoding="utf-8").splitlines()
         if l and not l.startswith("#")]
PAIRS = {e: sorted(((a, b) for r in _rows for a, b in zip(r[0].split("、"), r[i].split("、"))), key=lambda p: -len(p[0]))
         for i, e in ((1, MODERN), (2, FUTURE))}   # 時代詞表（125-8、第 8-1 批）：長的先換
WORDS = {ANCIENT: ("客棧", "老屋", "賃屋", "大宅"), MODERN: ("旅館", "老公寓", "租屋", "大樓"),
         FUTURE: ("膠囊旅館", "舊居住艙", "租賃艙", "塔樓")}   # 地名裡跟著換的字（小屋、祠堂、廟、村名不換）
JOB_NAMES = {MODERN: {"走鏢": "押運"}, FUTURE: {"走鏢": "武裝護送", "打獵": "狩獵", "採藥": "採集"}}   # 沒列的不換
MAX_NAME = 12                       # 與 game/proposals.NAME_RE 相同
RELIC, RUIN = "古蹟", "廢墟"
RELIC_CHANCE = 1 / 3
RELIC_FROM = ("客棧", "大宅")       # 起始區域生成的家級舊建築（地名結尾），換時代時三分之一留成古蹟
OLD_PLACES = (RELIC, RUIN, "村落", "荒野", "秘境")   # 不屬於這個時代的怪談只出現在這些地方（山野不太受時代影響）
SHOWY = ("戰鬥", "突破", "煉丹", "煉器")   # 在凡人面前看得出是修士的行動（第 6 題）
QUIET_TYPES = ("宗門", "秘境", "荒野", RUIN)   # 這些地方沒有凡人看著
SPOT_CHANCE = 0.3
OFFICIAL_BY = "official"   # 追捕者登錄成 NPC 時的 created_by：國法裡算官差（16h）
OLD_WORDS = "不要寫銀兩、元寶、算盤、竹簾、油燈"   # 小模型愛寫的古代用品（16o 第 12 題）
LOOK = {
    MODERN: f"城市有高樓、汽車、手機與網路；付錢用手機或現金，屋裡是鐵門、電燈、冷氣；{OLD_WORDS}",
    BRIGHT: f"科技昌明，飛行器、全息投影、人工智慧隨處可見；付錢刷信用點，門窗自動開關，屋裡是智慧家電；{OLD_WORDS}",
    CYBER: f"高樓與霓虹底下是貧民窟，大企業掌控一切，義體與改造人遍地；付錢刷信用點，屋裡是金屬門、霓虹燈、終端機；{OLD_WORDS}",
}
FACTION_LOOKS = {   # 延續的勢力在這個時代的樣子（125-4、第 8-2-3 題甲；名字照舊）；宗門照處境
    MODERN: {"武館": "武館", "家族": "家族企業", "幫派": "黑幫", "商會": "公司", "朝廷": "政府"},
    FUTURE: {"武館": "格鬥館", "家族": "財閥家族", "幫派": "地下組織", "商會": "財團", "朝廷": "聯合政府"},
}
SECT_LOOKS = {HIDDEN: "會館", OPEN: "門派", HUNTED: "地下門派"}
STANCE_LOOK = {
    HIDDEN: "修士隱於世，凡人不知道修仙的存在；宗門化身低調的門派、會館或家族企業",
    OPEN: "修士公開存在、與科技並存，有修士的身分與規矩",
    HUNTED: "科技壓過修士，修士要登記、會被追捕與研究；宗門轉入地下",
}


DEFAULT = {"era": ANCIENT, "future": "", "stance": "", "since": 0, "next": None}   # 沒給時代卡時當古代（測試、舊呼叫）


def new(rng: random.Random, since: int = 0) -> dict:
    """新世界（或還沒有時代卡的舊世界）：古代，從 since 開始。"""
    return {"era": ANCIENT, "future": "", "stance": "", "since": since, "next": since + _gap(rng, ANCIENT)}


def _gap(rng: random.Random, era: str) -> int:
    return rng.randint(*GAP_YEARS[era]) * SHICHEN_PER_YEAR


def due(card: dict, clock_now: int, long: bool = True) -> bool:
    """到門檻了沒：長時間不在場（換一世、一回合過了一年以上）到了就換；一般回合順延，延滿 DELAY 才換（125-12）。"""
    return card["next"] is not None and clock_now >= card["next"] + (0 if long else DELAY)


def advance(card: dict, rng: random.Random, until: int | None = None, lean: dict[str, float] | None = None) -> dict:
    """進下一個時代；給了 until 就一路走到 until 那時的時代（一次跳過兩個門檻就直接走到最後的時代）。
    lean：修士處境 → 權重倍數（上一個時代的累積，7-3c1 (67)，game/factions.era_lean）。"""
    while True:
        era = ERAS[ERAS.index(card["era"]) + 1]
        future = rng.choice((BRIGHT, CYBER)) if era == FUTURE else ""
        stances = {k: w * (lean or {}).get(k, 1) for k, w in STANCES[future or era].items()}
        since = card["next"]
        card = {"era": era, "future": future, "since": since,
                "stance": rng.choices(list(stances), weights=list(stances.values()))[0],
                "next": since + _gap(rng, era) if era in GAP_YEARS else None}
        if until is None or not due(card, until):
            return card


def start(card: dict, rng: random.Random, era: str) -> dict:
    """開世界時選的起始時代（第 10 題）：從古代的時代卡一路換到 era，世界年數從那個時代的門檻開始。"""
    while card["era"] != era:   # 最多兩次
        card = advance(card, rng)
    return card


def label(place_type: str, card: dict) -> str:
    """這個時代的叫法。"""
    return TYPES.get(card["era"], {}).get(place_type, place_type)


def job_text(text: str, card: dict) -> str:
    """文字裡的營生名換成這個時代的叫法（16o 第 6 題）。"""
    for old, new in JOB_NAMES.get(card["era"], {}).items():
        text = text.replace(old, new)
    return text


def pairs(card: dict) -> list[tuple[str, str]]:
    """這個時代的詞表（古代的詞 → 這時代的說法）；古代是空的。"""
    return PAIRS.get(card["era"], [])


def words(text: str, card: dict, keep=()) -> str:
    """文字裡古代的詞照時代詞表換（「」裡的不換，判詞照舊，125-8）；keep：不換的名字。"""
    return swap(text, pairs(card), keep)


def base(place_type: str) -> str:
    """任何時代的叫法換回資料裡記的（古代的）類型。"""
    return BASE.get(place_type, place_type)


def rename(name: str, old: str, new_era: str) -> str:
    """地名裡的類型字換成新時代的；換完超過地名上限（12 字）就不換。"""
    new_name = name
    for a, b in zip(WORDS[old], WORDS[new_era]):
        new_name = new_name.replace(a, b)
    return new_name if len(new_name) <= MAX_NAME else name


def relics(rng: random.Random, locations: list[dict]) -> set[str]:
    """換時代時留成古蹟的舊建築：起始區域生成的客棧、大宅，三分之一。"""
    return {l["name"] for l in sorted(locations, key=lambda l: l["name"])
            if l["discovered_session_id"] == "" and l["name"].endswith(RELIC_FROM) and l["type"] != RELIC
            and rng.random() < RELIC_CHANCE}


def fits(place_type: str, places: tuple, eras: tuple, card: dict) -> bool:
    """怪談主題能不能出現在這種地點（第 7 題）：古蹟算廢墟；不屬於這個時代的主題只出現在 OLD_PLACES。"""
    kind = RUIN if place_type == RELIC else place_type
    return (not places or kind in places) and (card["era"] in eras or place_type in OLD_PLACES)


def spotted(rng: random.Random, card: dict, *, action: str, place_type: str, realm_lv: int) -> str:
    """在凡人面前施展修為被看見了沒（第 6 題）。回傳被看見時的處境（隱世或打壓），沒被看見＝空。"""
    if card["stance"] not in (HIDDEN, HUNTED) or realm_lv < 1 or action not in SHOWY \
            or place_type in QUIET_TYPES or not place_type:
        return ""
    return card["stance"] if rng.random() < SPOT_CHANCE else ""


def hunter(rng: random.Random, player_lv: int, *, protagonist: str, place: str, place_type: str,
           taken: set[str], errand: str = "是官府派來追捕主角的人", by: str = OFFICIAL_BY, land: str = "人族") -> dict | None:
    """安排一個追捕者登場（實力照主角的境界）：官府的追捕者，或宗門派來追殺、討公道的人（16h，errand、by）。
    目標記成向主角「復仇」，之後由背景演化的「找上門」接手。"""
    p = newcomer.make(rng, place=place, place_type=place_type, taken=taken, land=land)
    if p is None:
        return None
    tiers = [t for t, lv in npc.POWER_TIERS.items() if lv is not None]
    return {**p, "age_band": rng.choice((npc.YOUNG, npc.PRIME)), "power_tier": tiers[max(0, min(player_lv, len(tiers) - 1))],
            "goal": "復仇", "goal_target": protagonist, "errand": errand, "created_by": by}


def text(card: dict) -> str:
    """畫面上的時代：「古代」「現代（隱世）」「未來・賽博朋克（打壓）」。"""
    return card["era"] + (f"・{card['future']}" if card["future"] else "") + (f"（{card['stance']}）" if card["stance"] else "")


def behind(p: dict, card: dict) -> bool:
    """不合時宜（125-5、第 8-3-a 題甲）：描述都寫於這個時代開始以前（出生＋寫於幾歲推回去）、又沒標「換時代」
    ＝換時代那時不在世上（遠方、仙域、封印）。從資料算、不另記；年紀不詳、還沒描述的不算。"""
    ages = [p.get(f"{k}_age") for k in ("appearance", "profile") if p.get(k)]
    born = p.get("birth_shichen")
    return (card["era"] != ANCIENT and p.get("rewrite_reason") != npc.NEW_ERA and born is not None and bool(ages)
            and all(a is not None and born + (a + 1) * SHICHEN_PER_YEAR <= card["since"] for a in ages))


def prompt(card: dict, changed: bool = False, slow: bool = False, lost: bool = False) -> str:
    """給說書人的【時代】。古代沒有這一行；changed：剛換時代，多一句「世界變了」；slow：一般回合延滿才換（125-12）；
    lost：主角脫節（第 8-3 批，character.lost）。"""
    if card["era"] == ANCIENT:
        return ""
    head = ("這些年世道一點一點變了，已經不是從前的樣子。" if slow else "世界變了，已經不是從前的樣子。") if changed else ""
    names = "、".join(f"{a}＝{b}" for a, b in TYPES[card["era"]].items())
    looks = "、".join(f"{a}＝{b}" for a, b in {"宗門": SECT_LOOKS[card["stance"]], **FACTION_LOOKS[card["era"]]}.items())
    return (f"{head}{text(card)}：{LOOK[card['future'] or card['era']]}；{STANCE_LOOK[card['stance']]}；"
            f"凡人用{MONEY[card['era']]}。地點照這個時代的叫法寫（{names}），提案也可以用這些叫法。"
            f"勢力名字照舊，樣子照這個時代寫（{looks}）。" + (LOST if lost else ""))


def valid(card) -> bool:
    """exposure（曝光度，domain/identity.py）可有可無：舊時代卡沒有＝0。"""
    if not isinstance(card, dict) or set(card) - {"exposure"} != {"era", "future", "stance", "since", "next"} \
            or not isinstance(card.get("exposure", 0), int) or card.get("exposure", 0) < 0:
        return False
    era, future, stance = card["era"], card["future"], card["stance"]
    return (era in ERAS and (future in (BRIGHT, CYBER) if era == FUTURE else future == "")
            and (stance == "" if era == ANCIENT else stance in STANCES[future or era])
            and isinstance(card["since"], int) and card["since"] >= 0
            and (card["next"] is None if era == FUTURE else isinstance(card["next"], int) and card["next"] > card["since"]))
