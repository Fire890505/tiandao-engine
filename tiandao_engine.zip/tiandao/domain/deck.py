"""牌的共用格式和抽法（第 117-3、127-5、127-7 題）。純函式。

- 一行一張：名字｜誰抽｜種類｜條件｜目標｜結果｜內容欄……（第一個內容欄是 text，其餘在 more）。# 開頭是註解。
- 條件空格分開，每條「字:值」，字要在條件表 NEED 裡。手上的情況寫成 {字: 一組值}。
- 篩：每條都要對上；pool 只留篩的條件最多的那一層（Valve 式，第 4-3b 題：路線牌用，動作牌、遭遇只用 fits）；
  權重：值在 hot 裡的每個 ×2（「、」列的每個值各算一次）；標：只是標記，抽牌不看。
"""
from __future__ import annotations

import random
from dataclasses import dataclass

NEED = {          # 條件表：字 → 怎麼用
    "路線": "篩",          # 這條路線的名字或種類
    "地": "篩",            # 地:路線＝人在路線那裡
    "階": "篩",            # 路線走到這一階
    "判定": "篩",          # 成、敗；走向母型表多一個 無（這回合沒對這件事行動，第 4-8 題）
    "行動": "篩 權重",     # 這回合的行動：查探、社交、動手；潛行只有陷阱牌用（其他牌組潛行算查探）
    "常": "權重",          # 最近做得多的行動，不篩
    "紀錄": "篩 權重",     # 重大紀錄：殺過人、背過約、救過人
    "線索": "篩",          # 有：有下一條線索可以指
    "暗線": "篩",          # 在走
    "地點": "篩",          # 地點種類（第 4-2 題起是遭遇的條件）
    "季節": "篩",
    "宗門": "篩",          # 近：附近有宗門
    "族": "篩",            # 這裡是哪一族的地盤
    "外族": "篩",          # 是：主角在外族地盤、又看得出來
    "素材": "篩",          # 人、物、地：這回合有這個素材（第 4-3 題起是動作牌的條件）
    "立場": "篩",          # 敵、非敵、非友：眼前的人的立場
    "處境": "篩",          # 身分、窘境
    "地位": "篩",          # 主角在這裡的地位：賤、平民、體面、士紳、權貴（第 7-1c 批，domain/rank.py）
    "記號": "篩",          # 主角身上記號的標籤
    "家運": "篩",          # 話題牌（第 4-3 題）：往事看家運
    "職業": "篩",          # 話題牌：職業日常看那個人的職業
    "修行": "篩",          # 話題牌：修士的修行身分那一組、小孩（第 7-1a 批，domain/profile.GROUPS）
    "圈": "篩",            # 話題牌（第 9 步，消息圈草稿 9-11）：那個人的消息圈：山野、市井、路上、官面、修行
    "有": "篩",            # 常識牌：這份資料這裡有才抽（怪談、災、通緝……）
    "羈絆": "篩",          # 人際牌（羈絆話題草稿 9-19）：他跟那人的羈絆
    "帳": "篩",            # 人際牌：他跟那人的帳（債……）
    "原因": "篩",          # 人際牌：最近一筆原因的方向：好、壞
    "可信": "篩",          # 人際牌：是＝他對你可信以上，私密的才講（9-20）
    "打聽": "篩",          # 人際牌：是＝你在打聽某人，講那人的羈絆
    "查": "篩",            # 過：主角已經查過、問過這件事（動作牌裡「和你查到的」那種，2026-11-23 回報）
    "規模": "篩",          # 怪談（第 4-4 題）：被籠罩地點的規模
    "範圍": "篩",          # 事端（第 116-1 題）：村落、鄉鎮、城市、國家；沒寫看地點本身的規模
    "時代": "篩 不分層",   # 怪談、傳說：屬於哪些時代；路線牌、動作牌：古代口吻的整句（待辦 2），不算進條件多寡
    "步": "篩",            # 陷阱、隱藏牌（第 4-5 題）：暗線已經走了幾步
    "場景": "篩",          # 隱藏牌：村鎮、在場、傳聞（game/darks 判斷）
    "往事": "篩",          # 支線：往事的家運序號
    "目的": "篩",          # 支線：請託看 NPC 的目標
    "收尾": "篩",          # 走向母型表（第 4-8 題）：是＝走到階段表最後一階
    "親近": "篩",          # 走向母型表：在場＝眼前的人好感親近以上
    "層": "篩",            # NPC 小事（第 7-2a 批，domain/chatter.py）：甲對乙的好感層
    "合": "篩",            # 小事：合得來、普通、合不來
    "熟": "篩",            # 小事：熟人
    "甲": "篩",            # 小事：甲的性格（膽識高……）或目標
    "同": "篩",            # 小事：兩人同一個目標（守護要同一人）
    "處": "篩",            # 小事：村鎮、坊市、宗門
    "親": "篩",            # 小事：親人、伴侶
    "戀": "篩",            # 小事：單身、半年
    "約": "篩",            # 小事：戀人
    "性": "篩",            # 小事：異性
    "怕": "篩",            # 做法牌（第 7-2b 批，game/deeds.py）：忌憚、畏懼、不怕
    "知": "篩",            # 做法牌：他知道你的罪、秘密、仇家、線索
    "宮": "篩",            # 命數找上你（併章重設計）：他那章落的宮；支線請託、做法牌都用
    "心事": "篩",          # 支線（第 9e-3 批）：心事開口求你，名字對上心事接的支線
    "壓": "篩",            # 地方牌（第 7-3a 批，game/local.py）：剛換到的那一級（人心-1）
    "因": "篩",            # 地方牌：原因的種類（旱災、苛政、鄰……）
    "勢": "篩",            # 勢力牌（第 7-3b1a 批，game/factions.py）：自己的聲勢門檻（-1＝≤ -1）
    "對勢": "篩",          # 勢力牌：目標的聲勢門檻；比我低
    "好": "篩",            # 勢力牌：自己對目標的好感層（友善、親近以上；冷淡、敵視以下）
    "首": "篩",            # 勢力牌：首領的野心、善念門檻（野心60）
    "員": "篩",            # 勢力牌：有成員野心到門檻、境界不低於首領
    "型": "篩",            # 勢力牌：勢力類型
    "戰": "篩",            # 勢力牌：是＝正在交戰
    "從": "篩",            # 勢力牌：是＝自己是附庸
    "盟": "篩",            # 國事牌（第 7-3b2 批，game/nations.py）：是＝自己有盟國
    "族對": "篩",          # 國事牌：自己跟目標國的種族關係（同族、中立、戒備、敵對）
    "宿敵": "篩",          # 盟事牌（第 7-3b3 批，domain/immortal.py）：是＝跟目標是正魔兩盟
    "人": "篩",            # 人物層牌（第 9f 批，domain/reunion.py）：成年、老、修士、凡人
    "母型": "標",          # 標記（第 4-8 題）：只拿來檢查缺哪種牌，不篩、不加權、不算優先；遭遇發生什麼（第 4-d 題）
    "對象": "標",          # 機會、命運、陷阱作用在什麼（第 4-h 題）：情報、資源、人際、局勢、身心、命運
}


MARKS = {         # 標記的值（第 4-d、4-h 題）；讀檔時照這裡檢查
    "母型": "撿到 撿到不該撿的 失物 高人指點 修行關口 路阻 攔路 路旁求救 獵物與獵人 交易機會 門內差事 節慶 異象 押貨變故 熟人",
    "對象": "情報 資源 人際 局勢 身心 命運",
}


RESULTS = {       # 結果表（第 4-k、4-7 題）：類 → 這一類的字；結果欄寫「類:值」，值的第一段要在這一類
    "身": "受傷 長修為", "財": "得錢 失錢 得靈石 失靈石 得物品 物品 少工錢 賠貨款", "帳": "欠情 救命之恩 人情",
    "好感": "好感上升 好感下降 起疑 好感", "路": "指路", "名": "入門", "線頭": "條件", "地": "壓 走 關 回",
    "知情": "線索 看破 假線索 真相", "勢": "順勢 處境 拖延 衰", "命": "注視 記號",
    "法": "抓 流放 關押", "聞": "傳開 舊聞 閒話",
    "業": "改行", "住": "鄰地 遠方", "境": "突破", "目標": "換", "親": "成親 生子 喪親 拜師 收徒",   # 人物層牌（第 9f 批）   # 事端結果欄（第 4-11-6 題）；事端的好感值寫 opinion.MOODS 的種類
    "謠": "記", "撤": "謠言 借刀",   # 模型寫的事端第二批 a（plot.RUMOR、plot.DROP）
    "死": "撕票",                    # 第二批 b：綁架到期（plot.DIE）
    "亡": "安息 散 怒",              # 模型寫的舊亡魂（domain/newghosts.py）：改亡者那筆；安息還給頭七回魂的感悟
    "災": "減 短",                # 模型寫的天災（domain/newdisasters.py）：減＝看轉折算，不用結算；短＝剩下的時間減半；勢:衰＝隱瞞者的勢力聲勢降一格
}
_KIND = {w: k for k, ws in RESULTS.items() for w in ws.split()}
TIMES = ("成", "敗", "當場")   # 遭遇：應對成功、失敗、當下型


def bare(text: str) -> str:
    """結果欄 → 拿掉「類:」的值（各副牌照舊結算）。空格分開幾段，段前可以有 成:／敗:／當場:，一段裡「、」分開幾個。"""
    out = []
    for token in text.split():
        head, _, rest = token.partition(":")
        items = rest if head in TIMES else token
        values = []
        for item in items.split("、"):
            kind, _, value = item.partition(":")
            assert _KIND.get(value.split(":")[0]) == kind, f"結果的類不對：{item}"
            values.append(value)
        out.append((f"{head}:" if head in TIMES else "") + "、".join(values))
    return " ".join(out)


@dataclass(frozen=True)
class Card:
    name: str
    who: str
    kind: str
    need: tuple       # ((字, 值), …)
    target: str
    result: str
    text: str         # 第一個內容欄
    more: tuple = ()  # 其餘內容欄（各牌組自己定）


def card(cols: list[str]) -> Card:
    """切開的一行 → 牌；內容欄可以沒有（事端、怪談、傳說檔的開頭一行，第 4-4 題）。"""
    name, who, kind, need, target, result, *rest = cols
    pairs = tuple(tuple(n.split(":", 1)) for n in need.split())
    assert all(k in NEED and (NEED[k] != "標" or v in MARKS[k].split()) for k, v in pairs), cols
    return Card(name, who, kind, pairs, target, result, rest[0] if rest else "", tuple(rest[1:]))


def read(path) -> list[Card]:
    return [card(line.split("｜")) for line in path.read_text(encoding="utf-8").splitlines() if line and not line.startswith("#")]


def _uses(c: Card, use: str) -> list[str]:
    return [v for k, v in c.need if use in NEED[k]]


def fits(c: Card, facts: dict) -> bool:
    """篩的條件每條都對上（值用「、」列好幾個時對上一個就算）；目標有寫的話，facts["目標"] 裡要有。"""
    return all(any(x in facts.get(k, ()) for x in v.split("、")) for k, v in c.need if "篩" in NEED[k]) \
        and (not c.target or c.target in facts.get("目標", ()))


def pool(cards: list[Card], facts: dict) -> list[Card]:
    """對得上的牌，只留篩的條件最多的那一層（第 4-3b 題）。"""
    ok = [c for c in cards if fits(c, facts)]
    top = max((len(_uses(c, "篩")) - len(_uses(c, "不分層")) for c in ok), default=0)
    return [c for c in ok if len(_uses(c, "篩")) - len(_uses(c, "不分層")) == top]


def weight(c: Card, hot: set) -> int:
    return 2 ** sum(x in hot for v in _uses(c, "權重") for x in v.split("、"))


def pick(rng: random.Random, cards: list[Card], hot: set) -> Card:
    return rng.choices(cards, weights=[weight(c, hot) for c in cards])[0]
