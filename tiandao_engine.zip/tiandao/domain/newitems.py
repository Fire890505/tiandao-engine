"""世界的新物品從哪來、在哪拿得到（第 128 系列，progress/模型生成內容.md 第六節）。純函式，不呼叫模型。

- 來源（第 128-5 題乙）：手寫（rules/content/items.txt，建世界時抄進來）、模型（建世界時一次寫）、說書人（敘事時提案）。
- 產地（第 128-6 題乙）：模型寫的綁一州，只在那一州的店賣、那一州掉落；手寫、說書人的沒有產地，哪裡都有。
- 建世界時（第 128-2、128-3 題）：plan 定每州寫幾件、哪個底、地勢、物產詞、零件詞（第 128-8 題乙，詞一個世界只用一次）；
  模型只寫名字、一句外觀（要用上零件詞）、一句來歷（要用上物產詞）；review 審四項（第 128-4 題乙）、record 存成一件。
- 第 128-13 題：plan 另擲來歷、怪處各一（quirks.txt，內容母型 v2 第 19 副），只影響文字，不審；名字不准有品階字。
"""
from __future__ import annotations

import random

from ..config import PROJECT_ROOT
from . import checks
from . import items as items_mod

HAND, MODEL, TELLER = "手寫", "模型", "說書人"
SOURCES = (HAND, MODEL, TELLER)
PER_STATE = 1                                          # 每州寫幾件（暫定）
NAME_LEN, LOOK_LEN, ORIGIN_LEN = (2, 8), (8, 40), (8, 50)
SAME_HEAD = 2   # 同一批外觀同樣開頭兩字最多幾件（第 128-6 題乙；名字結尾字改成照 forms.txt，第 128-11 題）
PARTS_OF = {items_mod.PILL: ("草藥",), items_mod.TALISMAN: ("符材",), items_mod.ARTIFACT: ("礦石", "獸材"),
            "靈草": ("草藥",), "靈礦": ("礦石",), "獸骨": ("獸材",), "妖丹": ("獸材",)}   # 底 → 零件詞的類（靈材照名字，其他照種類）


def _read(name: str) -> dict[str, list[str]]:
    lines = (PROJECT_ROOT / "rules" / "content" / name).read_text(encoding="utf-8").splitlines()
    return {k: v.split("、") for k, v in (l.split("｜") for l in lines if l and not l.startswith("#"))}


LANDS, FORMS = _read("lands.txt"), _read("forms.txt")   # FORMS：底 → 名字可以用的結尾字（第 128-11 題甲）
PARTS = {k: [w.split(":")[0] for w in v] for k, v in _read("parts.txt").items()}
SIDE = dict(w.split(":") for v in _read("parts.txt").values() for w in v if ":" in w)   # 零件詞 → 副作用的標的（第 128-10 題甲）
HOME = 2                                               # 在產地那種地勢用，主作用加倍（第 128-10 題乙，暫定）
QUIRKS = _read("quirks.txt")                           # 來歷、怪處（內容母型 v2 第 19 副，第 128-13 題）：只影響文字
GRADE_WORDS = ("上品", "中品", "下品", "極品", "神品", "仙品", "神器", "仙器", "聖器", "至寶")   # 名字不准有品階字（v2 審核，品階由 Python 給）


def perks(items: list[dict], seed: str, state: str) -> dict[str, tuple[str, float]]:
    """模型寫的物品：名字 → （副作用的標的, 主作用倍數）。state：你現在在哪一州；seed：天下骨架的種子。"""
    here = land(seed, state) if state else ""
    return {i["name"]: (SIDE.get(i["part"], ""), HOME if here and i.get("state") and land(seed, i["state"]) == here else 1)
            for i in items if i.get("part")}


def local(items: list[dict], state: str) -> list[dict]:
    """這一州拿得到的新物品：沒綁產地的，加上綁在這一州的。"""
    return [i for i in items if not i.get("state") or i["state"] == state]


def told(items: list[dict]) -> int:
    """說書人提案的有幾件（每一生的上限只算這些，proposals.MAX_PER_SESSION）。"""
    return sum(i.get("source") in ("", None, TELLER) for i in items)


def land(seed: str, state: str) -> str:
    """這一州的地勢（不存，照骨架種子和州名算）。"""
    return random.Random(f"{seed}:地勢:{state}").choice(sorted(LANDS))


def plan(rng: random.Random, seed: str, states: list[str], bases: list[str], per: int = PER_STATE) -> list[dict]:
    """要寫哪幾件：每州 per 件，底從 bases 抽，物產詞照那州地勢、零件詞照底的類，一個世界一個詞只用一次；詞用完那件就不寫。"""
    used, out = set(), []
    for state in states:
        where = land(seed, state)
        for base in (rng.choice(bases) for _ in range(per)):
            kinds = PARTS_OF.get(base) or PARTS_OF[items_mod.CATALOG[base].kind]
            made = [w for w in LANDS[where] if w not in used]
            part = [w for w in PARTS[rng.choice(kinds)] if w not in used]
            if made and part:
                slot = {"state": state, "base": base, "land": where, "made": rng.choice(made), "part": rng.choice(part),
                        "ends": FORMS.get(base, [base[-1]]), "from": rng.choice(QUIRKS["來歷"]), "odd": rng.choice(QUIRKS["怪處"])}
                used |= {slot["made"], slot["part"]}
                out.append(slot)
    return out


def review(slot: dict, got: dict, taken: set[str], batch: list[dict], era_now: str) -> str:
    """四項（第 128-4 題乙）：合格回傳空字串，不然回傳原因。taken：世界裡已有的名字（物品、地名）；batch：這批已經收下的（record 過的）。
    長度、中文、時代、撞名、重複是共用的關卡（domain/checks.py）。"""
    name, look, origin = (str(got.get(k, "")).strip() for k in ("name", "look", "origin"))
    if reason := checks.basic([(name, NAME_LEN), (look, LOOK_LEN), (origin, ORIGIN_LEN)], era_now):
        return reason
    if slot["part"] not in look or slot["made"] not in origin:
        return "詞沒用上"
    if name[-1] not in slot["ends"]:
        return "跟底不合"   # 第 128-11 題甲：結尾字照 forms.txt，看得出是哪一類東西
    if any(w in name for w in GRADE_WORDS):
        return "品階字"
    if slot.get("odd", "沒有") != "沒有" and slot["odd"][-2:] in name:
        return "怪處進名字"   # 糯米隱身說話符（第 128-13 題）：會說話→說話、有靈→有靈
    if checks.clash(name, taken | set(items_mod.CATALOG) | {b["name"] for b in batch}):
        return "撞名"
    if checks.same_head(look, [b["description"] for b in batch]) >= SAME_HEAD:
        return "重複"
    return ""


def record(slot: dict, got: dict) -> dict:
    """存成一件（items_w）：外觀接來歷寫進描述，綁那一州。"""
    look, origin = str(got["look"]).strip(), str(got["origin"]).strip()
    return {"name": str(got["name"]).strip(), "base": slot["base"], "discovered_turn": 0, "source": MODEL, "state": slot["state"], "part": slot["part"],
            "description": look + ("" if look.endswith(("。", "！", "？")) else "。") + origin}
