"""重逢（第 9f 批，第 89、9-21、9-22、9-23f 題，progress/重逢草稿.md）：你認識的人隔半年以上再見，補抽人物層牌。純函式。

- 隔多久：從 npcs.life_shichen（你跟他同處、抽過牌時更新）算到現在；半年起一張，之後每滿一年多一張，最多 MAX 張。
- 對得上的牌裡隨機抽（deck.fits，rules/content/reunion.txt），同一次的結果類不重複；這段時間演化、小事已經改過的那一類不抽（taken）。
  做不到的（沒有鄰地、境界到頂、挑不到人……）換別張。
- 結果真的改他的狀態；近況那句記成他身上的記事（memory.NEWS），時刻平均排在這段時間裡。
- 牽到別人的（第 9f-2 批）：成親、拜師、收徒、入門先挑現成的人或勢力；只有生子、收徒（挑不到）新登錄一個人。
  喪親只挑你不認識、沒有特殊命的親人（不讓你認識的人死在牌裡）。成親照現在的伴侶羈絆，婚俗（121-13）之後再接。
"""
from __future__ import annotations

import random
from dataclasses import dataclass, field

from ..config import PROJECT_ROOT
from ..util import new_id
from . import deck, family, memory, names, newcomer, npc, realm, society
from .clock import SHICHEN_PER_MONTH, SHICHEN_PER_YEAR

HALF, MAX = SHICHEN_PER_YEAR // 2, 3
JAIL = 3 * SHICHEN_PER_MONTH        # 關幾個月
OLD, FERTILE = 0.6, 0.5             # 過了壽元六成算老；兩人都不到壽元一半才生
HIGH = 3                            # 境界高：金丹以上
PUPIL_AGE = (12, 17)                # 收徒挑不到人：新登錄的徒弟幾歲
TOWNS = ("城鎮", "村落", "坊市")     # 搬去的地方
SKIP = {"location": "住", "realm_lv": "境", "stage_index": "境", "goal": "目標", "condition": "身", "job": "業"}   # 欄位 → 結果類
NEW_GOAL = {"逐利": "做點買賣", "求名": "出去闖個名堂", "隱居": "找個清靜地方過日子"}   # 換目標照性格挑，{新目標}

DECK = deck.read(PROJECT_ROOT / "rules" / "content" / "reunion.txt")
assert all(c.who == "人" and deck.bare(c.result) for c in DECK), "人物層牌寫錯了"


@dataclass
class Ctx:
    """抽牌看的世界。town：他住的村鎮；near、far：可以搬去的鄰地、遠方；jobs：當地職業表；town_of：地點 → 村鎮；
    known：你認識的人；taken：用掉的名字。npcs、bonds 會跟著抽到的結果更新（同一回合後面的人看得到）。"""
    town: str
    near: list[str]
    far: list[str]
    jobs: tuple
    npcs: dict[str, dict] = field(default_factory=dict)
    bonds: list[dict] = field(default_factory=list)
    factions: list[dict] = field(default_factory=list)
    town_of: dict[str, str] = field(default_factory=dict)
    known: set[str] = field(default_factory=set)
    taken: set[str] = field(default_factory=set)


@dataclass
class Out:
    fields: dict = field(default_factory=dict)          # 他的
    others: dict = field(default_factory=dict)          # 別人的欄位（死去的親人、跟來的徒弟）
    notes: list[dict] = field(default_factory=list)
    ledger: list[dict] = field(default_factory=list)    # 關押（已到期，寫進去就了結）
    bonds: list[dict] = field(default_factory=list)
    unbonds: list[tuple] = field(default_factory=list)  # （甲, 乙, 種類）
    born: list[dict] = field(default_factory=list)      # 新登錄的人（孩子、徒弟）
    dead: set[str] = field(default_factory=set)
    moved: list[str] = field(default_factory=list)      # 搬走那句（你到他原本那處時「聽說」）


def draws(gap: int) -> int:
    return 0 if gap < HALF else min(MAX, 1 + (gap - HALF) // SHICHEN_PER_YEAR)


def ties(name: str, bonds: list[dict], kind: str) -> list[str]:
    """他的某種羈絆的對方；師父、徒弟照方向（甲是乙的師父）。"""
    if kind in society.INVERSE:
        return [b["a"] for b in bonds if b["type"] == kind and b["b"] == name] + \
               [b["b"] for b in bonds if b["type"] == society.INVERSE[kind] and b["a"] == name]
    return [b["b"] if b["a"] == name else b["a"] for b in bonds if b["type"] == kind and name in (b["a"], b["b"])]


def _alive(ctx: Ctx, names_: list[str]) -> list[dict]:
    return [ctx.npcs[n] for n in names_ if ctx.npcs.get(n, {}).get("status") == "ALIVE"]


def _sect(ctx: Ctx, name: str) -> bool:
    kinds = {f["name"]: f["type"] for f in ctx.factions}
    return any(b["a"] == name and b["type"] in society.MEMBER_BONDS and kinds.get(b["b"]) == "宗門" for b in ctx.bonds)


def facts(p: dict, now: int, ctx: Ctx | None = None) -> dict:
    tags = {"修士" if p["realm_lv"] else "凡人"}
    if p["realm_lv"] >= HIGH:
        tags.add("高境")
    if not npc.is_minor(p, now):
        tags.add("成年")
    if (npc.age(p, now) or 0) >= OLD * npc.lifespan_years(p["realm_lv"], p.get("race") or "人族"):
        tags.add("老")
    if ctx:
        name = p["name"]
        tags.add("有伴侶" if _alive(ctx, ties(name, ctx.bonds, "伴侶")) else "沒伴侶")
        tags |= {"有親人"} if _alive(ctx, ties(name, ctx.bonds, "親人")) else set()
        tags |= set() if ties(name, ctx.bonds, "師父") else {"沒師父"}
        tags |= set() if _sect(ctx, name) else {"沒宗門"}
    return {"目的": {p["goal"]}, "人": tags}


def _goal(rng: random.Random, p: dict) -> str:
    """照性格挑：野心高多想揚名，膽小多想隱居。"""
    w = {"逐利": 1, "求名": 1 + (npc.trait_level(p["ambition"]) == "高"), "隱居": 1 + (npc.trait_level(p["courage"]) == "低")}
    w.pop(p["goal"], None)
    return rng.choices(list(w), list(w.values()))[0]


def _bond(a: str, b: str, kind: str, when: int, turn_no: int, b_kind: str = society.NPC) -> dict:
    return {"a_kind": society.NPC, "a": a, "b_kind": b_kind, "b": b, "type": kind, "clock_shichen": when, "turn_no": turn_no}


def _new(rng: random.Random, ctx: Ctx, p: dict, *, years: int, when: int, turn_no: int, surname: str, profile: str) -> dict | None:
    """新登錄一個凡人（孩子、徒弟），跟 p 住一起；欄位照 family._person。"""
    race, gender = p.get("race") or "人族", rng.choice(npc.GENDERS)
    name = next((n for n in (surname + names.given(rng, race, gender) for _ in range(20)) if n not in ctx.taken), "")
    if not name:
        return None
    ctx.taken.add(name)
    band = npc.CHILD if years < 13 else npc.TEEN
    return {"name": name, "appearance": newcomer.looks(rng, band, gender, race=race), "profile": profile.format(性="兒子" if gender == "男" else "女兒"),
            "location": p["location"], "status": "ALIVE", "condition": "無恙", "ai_driven": True, "created_by": family.BY, "race": race,
            "lineage": p.get("lineage", ""), "gender": gender, "birth_shichen": when - years * SHICHEN_PER_YEAR, "job": "",
            "profile_age": years, "goal": "", "goal_target": "", **{t: rng.choice(list(npc.TRAIT_LEVELS.values())) for t in npc.TRAITS},
            "evolved_shichen": when, "life_shichen": None, "first_seen_turn": turn_no}


def _kin(ctx: Ctx, name: str) -> set[str]:
    return {name, *ties(name, ctx.bonds, "親人"), *ties(name, ctx.bonds, "伴侶")}


def _local(ctx: Ctx, q: dict, towns: set[str]) -> bool:
    return q["status"] == "ALIVE" and ctx.town_of.get(q["location"], q["location"]) in towns


def _people(rng: random.Random, c: deck.Card, p: dict, when: int, ctx: Ctx, out: Out, turn_no: int) -> tuple[dict, dict] | None:
    """牽到別人的：回傳（他改的欄位, 填字）；別人的變化直接記進 out。"""
    kind, value, name = *c.result.split(":"), p["name"]
    pick = lambda xs: rng.choice(sorted(xs, key=lambda q: q["name"])) if xs else None
    if value == "成親":
        lover = _alive(ctx, ties(name, ctx.bonds, "戀人"))
        q = pick(lover or [q for q in ctx.npcs.values() if _local(ctx, q, {ctx.town}) and q["name"] not in _kin(ctx, name)
                           and {q.get("gender"), p.get("gender")} == set(npc.GENDERS) and not npc.is_minor(q, when)
                           and not ties(q["name"], ctx.bonds, "伴侶") and not ties(q["name"], ctx.bonds, "戀人")])
        if not q:
            return None
        out.unbonds += [(name, q["name"], ("戀人",)), (q["name"], name, ("戀人",))]
        out.bonds.append(_bond(name, q["name"], "伴侶", when, turn_no))
        return {}, {"名字": q["name"]}
    if value == "生子":
        q = pick([q for q in _alive(ctx, ties(name, ctx.bonds, "伴侶")) if all(
            (npc.age(x, when) or 99) < FERTILE * npc.lifespan_years(x["realm_lv"], x.get("race") or "人族") for x in (p, q))])
        dad = p if p.get("gender") == "男" else q
        child = q and _new(rng, ctx, p, years=0, when=when, turn_no=turn_no, profile=f"{p['name']}的{{性}}。",
                           surname=names.surname_of(dad["name"], race=dad.get("race") or "人族"))
        if not child:
            return None
        out.born.append(child)
        out.bonds += [_bond(child["name"], name, "親人", when, turn_no), _bond(child["name"], q["name"], "親人", when, turn_no)]
        return {}, {"名字": child["name"]}
    if value == "喪親":
        kin = [q for q in _alive(ctx, ties(name, ctx.bonds, "親人")) if q["name"] not in ctx.known and not q.get("hidden")]
        q = min(kin, key=lambda q: (q.get("birth_shichen") or 0, q["name"]), default=None)
        if not q:
            return None
        out.others.setdefault(q["name"], {}).update(status="FALLEN", condition=npc.CONDITIONS[-1])
        out.dead.add(q["name"])
        out.notes.append(memory.note(memory.NPC, q["name"], memory.DEATH, "病故", clock_now=when, turn_no=turn_no))
        call = society.kin_call(p, q)
        return {}, {"稱呼": "家裡的人" if call == "家裡的" else call}
    if value == "拜師":
        q = pick([q for q in ctx.npcs.values() if _local(ctx, q, {ctx.town, *ctx.near}) and q["realm_lv"] > p["realm_lv"]
                  and q["name"] not in _kin(ctx, name) and not npc.is_minor(q, when)])
        if not q:
            return None
        out.bonds.append(_bond(q["name"], name, "師父", when, turn_no))
        return {"location": q["location"]}, {"名字": q["name"], "地": ctx.town_of.get(q["location"], q["location"])}
    if value == "收徒":
        q = pick([q for q in ctx.npcs.values() if _local(ctx, q, {ctx.town}) and q["realm_lv"] < p["realm_lv"] and q["name"] not in _kin(ctx, name)
                  and not ties(q["name"], ctx.bonds, "師父") and PUPIL_AGE[0] <= (npc.age(q, when) or 0) <= 30])
        if q:
            out.others.setdefault(q["name"], {}).update(location=p["location"])
        else:
            q = _new(rng, ctx, p, years=rng.randint(*PUPIL_AGE), when=when, turn_no=turn_no, profile=f"{p['name']}收的徒弟。",
                     surname=names.family(rng, p.get("race") or "人族", p.get("lineage", "")))
            if not q:
                return None
            out.born.append(q)
        out.bonds.append(_bond(name, q["name"], "師父", when, turn_no))
        return {}, {"名字": q["name"]}
    if kind == "名":   # 入門：凡人進當地的勢力，修士進附近的宗門
        mine = {b["b"] for b in ctx.bonds if b["a"] == name and b["type"] in society.MEMBER_BONDS}
        sect = p["realm_lv"] > 0
        f = pick([f for f in ctx.factions if (f["type"] == "宗門") == sect and f["name"] not in mine
                  and ctx.town_of.get(f["location"], f["location"]) in ({ctx.town, *ctx.near} if sect else {ctx.town})])
        if not f:
            return None
        out.bonds.append(_bond(name, f["name"], "成員", when, turn_no, society.FACTION))
        return ({"location": f["location"]}, {"宗門": f["name"]}) if sect else ({}, {"勢力": f["name"]})
    return None


def _play(rng: random.Random, c: deck.Card, p: dict, when: int, start: int, ctx: Ctx, out: Out, turn_no: int) -> tuple[dict, dict] | None:
    """一張牌 →（他改的欄位, 填字）；做不到回 None。"""
    kind, value = c.result.split(":")
    if kind == "業":
        left = [j for j in ctx.jobs if j != p.get("job")]
        return ({"job": (j := rng.choice(left))}, {"新職業": j}) if left else None
    if kind == "住":
        left = ctx.near if value == "鄰地" else ctx.far
        return ({"location": (x := rng.choice(left))}, {value: x}) if left else None
    if kind == "身":
        return ({"condition": "負傷"}, {}) if p["condition"] == "無恙" else None
    if kind == "境":
        return ({"stage_index": p["stage_index"] + 1, "cultivation": 0}, {}) if p["stage_index"] < realm.last_stage(p["realm_lv"]) else None
    if kind == "目標":
        g = _goal(rng, p)
        return {"goal": g, "goal_target": "", "rewrite_reason": "性情轉變"}, {"新目標": NEW_GOAL[g]}
    if kind == "財":
        n = p.get("fortune", 0) + (1 if value == "得錢" else -1)
        return ({"fortune": n}, {}) if abs(n) <= 1 else None
    if kind == "法":   # 關押：關滿了才算
        if when - JAIL < start:
            return None
        out.ledger.append({**society.owed(society.JAILED, p["name"], ctx.town, when - JAIL), "id": new_id("led"), "deadline_shichen": when})
        return {}, {}
    return _people(rng, c, p, when, ctx, out, turn_no)


def settle(rng: random.Random, p: dict, ctx: Ctx, *, start: int, end: int, taken: set[str], turn_no: int) -> Out:
    """p 從 start 補到 end。taken：這段時間已經改過的結果類。"""
    out, p, taken, n = Out(), dict(p), set(taken), draws(end - start)
    for i in range(n):
        when = start + (end - start) * (i + 1) // (n + 1)
        cards = [c for c in DECK if deck.fits(c, facts(p, when, ctx)) and c.result.split(":")[0] not in taken]
        rng.shuffle(cards)
        for c in cards:
            mark = len(out.bonds), len(out.unbonds), len(out.born)
            got = _play(rng, c, p, when, start, ctx, out, turn_no)
            if not got:
                continue
            fields, words = got
            p.update(fields)
            out.fields.update(fields)
            ctx.bonds += out.bonds[mark[0]:]
            cut = {(a, b, t) for a, b, ts in out.unbonds[mark[1]:] for t in ts}
            ctx.bonds[:] = [b for b in ctx.bonds if (b["a"], b["b"], b["type"]) not in cut]
            ctx.npcs.update({q["name"]: q for q in out.born[mark[2]:]})
            ctx.npcs.update({who: {**ctx.npcs[who], **f} for who, f in out.others.items() if who in ctx.npcs})
            ctx.npcs[p["name"]] = p
            taken |= {c.result.split(":")[0], *(["住"] if "location" in fields else [])}
            text = c.text.format(**words)[:memory.MEMORY_TEXT_LEN[1]]
            out.notes.append(memory.note(memory.NPC, p["name"], memory.NEWS, text, clock_now=when, turn_no=turn_no))
            out.moved += [text] * ("location" in fields)
            break
    return out
