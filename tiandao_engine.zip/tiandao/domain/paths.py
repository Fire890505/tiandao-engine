"""主角的道統（16l 第 41～43 題；草稿「道統」）。純函式。

規則（2026-10-19 與使用者一題一題定案，見 progress/WHITEPAPER.md 16l，數字暫定）：
- 角色卡 path（道統）、path_lv（入這個道統時的大境界）、path_old（兼修的舊道統）。
- 記上：所屬宗門的道統跟 path 不同就換（舊的改兼修，更早的兼修丟掉）；沒宗門、還沒道統，就照師父所屬宗門的道統。
- 加成（BASE）：主道統＝基本＋（現在大境界 − path_lv）×成長（判定 GROW_POINTS、比例 GROW_RATIO）；兼修＝基本的一半。
  佛門的走火入魔減免不成長。
- 風險：魔門（主或兼）殺人天道注視 +KILL_GAZE；鬼修（主或兼）佛門、道觀道統的宗門不收、接引也不來。
- 上門拜入不同道統的宗門考核 EXAM；接引、主動招攬時同道統的仙宗加倍權重。
"""
from __future__ import annotations

from . import names
from . import judgment as J

GHOST, BODY, QI, CALM = "亡者", "氣血", "修為", "心魔"   # 加成的種類（另外三種直接用行動類型）
BASE = {"劍修": (J.COMBAT, 5), "魔門": (J.COMBAT, 10), "丹道": (J.ALCHEMY, 5), "符籙": (J.FORGE, 5),
        "鬼修": (GHOST, 15), "體修": (BODY, 0.2), "道觀": (QI, 0.1), "佛門": (CALM, 0.5)}
GROW_POINTS, GROW_RATIO = 1, 0.02
EXAM = -10
KILL_GAZE, SOURCE = 5, "魔道"   # 天道注視
RIGHTEOUS = ("佛門", "道觀")


def fields() -> dict:
    return {"path": "", "path_lv": 0, "path_old": ""}


def has(sheet: dict, path: str) -> bool:
    return path in (sheet["path"], sheet["path_old"])


def bonus(sheet: dict, kind: str) -> float:
    """這一種加成：判定點數（呼叫端取整數）或比例。"""
    total = 0.0
    for path, main in ((sheet["path"], True), (sheet["path_old"], False)):
        k, base = BASE.get(path, ("", 0))
        if k == kind:
            step = GROW_POINTS if isinstance(base, int) else GROW_RATIO
            grow = step * max(0, sheet["realm_lv"] - sheet["path_lv"]) if kind != CALM else 0
            total += base + grow if main else base / 2
    return total


def sync(before: dict, sheet: dict, hall_path: str, master_path: str) -> tuple[dict, list[str]]:
    """回合結束前：照宗門（沒宗門照師父）記上道統；體修的氣血上限照加成前後的比例調整。before：回合開始的角色卡。"""
    path = hall_path or (master_path if not sheet["sect"] and not sheet["path"] else "")
    facts = []
    if path in BASE and path != sheet["path"]:
        old = sheet["path"]
        sheet = {**sheet, "path": path, "path_lv": sheet["realm_lv"], "path_old": old}
        facts.append(f"從此修{path}一道" + (f"，{old}改為兼修" if old else ""))
    ratio = (1 + bonus(sheet, BODY)) / (1 + bonus(before, BODY))
    if ratio != 1:
        hp_max = min(500, round(sheet["hp_max"] * ratio))
        sheet = {**sheet, "hp_max": hp_max, "hp": min(sheet["hp"], hp_max)}
    return sheet, facts


def exam(sheet: dict, hall_path: str) -> int:
    """上門拜入不同道統的宗門：考核判定修正。"""
    return EXAM if sheet["path"] and hall_path and not has(sheet, hall_path) else 0


def problem(sheet: dict, hall_path: str) -> str:
    return f"修鬼道的人，{hall_path}的宗門不收" if has(sheet, "鬼修") and hall_path in RIGHTEOUS else ""


def pick(rng, pool: list[dict], n: int, sheet: dict | None) -> list[dict]:
    """從仙宗裡挑 n 個（接引、招攬）：同道統的權重加倍；修鬼道的不挑正道。沒有道統照原本的隨機挑。"""
    if not sheet or not (sheet["path"] or sheet["path_old"]):
        return rng.sample(pool, min(len(pool), n))
    pool = [s for s in pool if not problem(sheet, s["path"])]
    return sorted(pool, key=lambda s: -rng.random() ** (1 / (2 if has(sheet, s["path"]) else 1)))[:n]


def text(sheet: dict) -> str:
    return (f"道統：{sheet['path']}" + (f"（兼修{sheet['path_old']}）" if sheet["path_old"] else "")) if sheet["path"] else ""


def valid(sheet: dict) -> bool:
    return (sheet["path"] in ("", *names.SECT_PATHS) and sheet["path_old"] in ("", *names.SECT_PATHS)
            and isinstance(sheet["path_lv"], int))
