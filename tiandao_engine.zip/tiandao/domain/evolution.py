"""背景演化：個別 NPC 的惰性演算（第 10b 步）。純函式，不碰資料庫。

規則（2026-10-04／05 與使用者討論定案，見 progress/WHITEPAPER.md 第 14 節，數字暫定）：
- 平常凍結；玩家再遇到（在場）或打聽時，才把「上次演算之後」到現在這段時間一次補算完。
  不滿一個月不算（也不推進演算時間）；亂數種子＝世界種子＋名字＋起點，同一段時間只會有一種結果。
- 長時間切成最多 MAX_SEGMENTS 段，每段的參數固定；修為、突破嘗試都依「跨過幾個曆月」計算，
  切幾段、分幾次算，結果都一樣（不逐年迭代，舊專案 B-06）。好感不在這裡回歸：原因自己淡掉（domain/opinion.py）。
- 每種變化一個函式：療傷、修煉與突破、老死、移動、性格漂移、目標轉換。
- 目標、性格的變化不寫進玩家看得到的文字（玩家要打聽才知道目標）。
"""
from __future__ import annotations

import math
import random
from collections.abc import Callable
from dataclasses import dataclass, field

from . import breach, era, favour, memory, npc, origins, palace, realm, route, space, stage, truth
from .clock import SHICHEN_PER_DAY, SHICHEN_PER_MONTH, SHICHEN_PER_YEAR
from .society import AWAY, FEUD, MEMBER_BONDS   # 去了沒有登錄的遠方；血仇；勢力成員

MIN_SPAN = SHICHEN_PER_MONTH
MAX_SEGMENTS = 12

# ── 修煉與突破 ───────────────────────────────────────────────────────────
STAGE_SHARE = 10            # 一個小境界約需「這一層壽元 ÷ 10」年（再依目標與野心調整）
GOAL_PACE = {"求道": 1.0, "求名": 0.7, "復仇": 0.7, "隱居": 0.6, "守護": 0.5, "報恩": 0.5, "追隨": 0.5,
             "尋物": 0.5, "逐利": 0.3}
AMBITION_PACE = {"低": 0.5, "中": 1.0, "高": 1.5}
MORTAL_SEEKERS = ("求道",)  # 凡人只有求道、或野心高的才會踏上修行
# 每次衝關的成功率（千分比）：越往上越難，勝天（Lv11）極為罕見
BREAKTHROUGH_PERMILLE = {1: 300, 2: 250, 3: 150, 4: 100, 5: 60, 6: 40, 7: 25, 8: 15, 9: 10, 10: 5, 11: 5}
GREAT_FAILURE_PERMILLE = 50  # 衝關失敗中最糟的 5%：重傷
FAILURE_LOSS = 30
MAX_ATTEMPTS_PER_SEGMENT = 3

# ── 移動 ─────────────────────────────────────────────────────────────────
MOBILITY = {"求道": 0.25, "逐利": 0.3, "求名": 0.3, "尋物": 0.3, "隱居": 0.2, "報恩": 0.5, "追隨": 0.5,
            "守護": 0.0, "復仇": 0.0}   # 每年離開的機率；復仇者追著仇人走留到第 10c 步（世界脈動）
PLACE_PREFERENCE = {"求道": ("宗門", "秘境"), "逐利": ("坊市", "城鎮"), "求名": ("城鎮", "宗門", "坊市"),
                    "尋物": ("秘境", "廢墟", "坊市"), "隱居": ("荒野",)}
MAX_MOVE_CHANCE = 0.9

# ── 從遠方回來（第 10c-2b 步）─────────────────────────────────────────────
HOME_SHARE, HOME_MAX_YEARS = 10, 100   # 保底：在外待了壽元的十分之一（最多 100 年）就回到當初離開的地方
DEAREST = ("師父", "徒弟", "親人", "戀人", "伴侶")   # 這些人死了一定趕回來奔喪
DEAR = ("友人", "恩人")                             # 這些人死了一半的機會趕回來（同門不是羈絆，第 1-3 批）
LEADER_HEIR_RETURN, LEADER_MEMBER_RETURN = 1.0, 0.3   # 勢力首領死了：該繼位的人一定回、其他成員 30%

# ── 性格與目標 ───────────────────────────────────────────────────────────
CLOSE_BONDS = ("師父", "徒弟", "親人", "恩人", "友人", "戀人", "伴侶", "結義")   # 被殺會想報仇的羈絆
DRIFT_BROKEN = {"suspicion": 10}
DRIFT_ATTACKED = {"suspicion": 5, "kindness": -5}
DRIFT_BEREAVED = {"kindness": -10}
DRIFT_WARMED = {"kindness": 5}
DRIFT_SOURED = {"suspicion": 5}
DRIFT_BREAKTHROUGH = {"courage": 5}
DRIFT_RANGE = npc.TRAIT_RANGE
PERSONAL_GOALS = ("復仇", "守護", "報恩", "追隨")     # 對象死了就會失去意義的目標
SWAYABLE_GOALS = ("求道", "逐利", "求名", "隱居", "尋物")  # 會被你的恩情打動而改變的目標
GRUDGE_AFFINITY = npc.GRUDGE_BELOW
GRATITUDE = (60, 20)          # 好感親近、信任可信以上：想報恩或追隨（信任改 -100～100，第 120-6 題）

GOAL_PHRASES = {"求道": "一心求道", "守護": "守護{t}", "逐利": "汲汲於名利錢財", "求名": "想要揚名立萬",
                "復仇": "想找{t}報仇", "報恩": "想報答{t}的恩情", "追隨": "想追隨{t}", "隱居": "想要隱居避世",
                "尋物": "在尋找{t}"}
_TARGET_FALLBACK = {"守護": "一方", "復仇": "仇人", "報恩": "恩人", "追隨": "某人", "尋物": "某樣東西"}


@dataclass
class World:
    """演算需要的世界資料（唯讀）。"""
    places: list[dict]                     # 地點：name、type
    npcs: dict[str, dict]                  # 名字 → NPC（看對象在哪、是否還活著）
    bonds: list[dict]
    notes: list[dict]                      # 這個 NPC 的記事（全世界的，依時間）
    protagonist: str
    gone: frozenset[str] = frozenset()     # 已不在人世的名字（死去的 NPC、前幾生的主角）
    factions: dict[str, str] = field(default_factory=dict)   # 勢力 → 所在地（首領死了，成員趕回去）
    my_lv: int = 0                         # 這一生的你的境界（怕的境界差，第 121-10 題）
    fate: tuple = truth.NONE               # 主角的特殊命（真相分法，第 6-5c 批，domain/truth.py）
    like: Callable[[str, str, int], int] = lambda x, y, when: 0   # 甲在某時刻對乙的好感（特殊命 NPC 的章，第 122c 批）
    mine: list[dict] = field(default_factory=list)   # 主角這一生的羈絆、好感算出的友人仇家（主角那方寫名字，NPC 分宮用）
    near: dict[str, int] = field(default_factory=dict)   # 地點 → 離主角幾公里（找上你看腳程）
    here: str = ""                         # 主角所在
    my_open: str = ""                      # 主角開著的那章的人（他的章也以你為命主就併章，第 7-4c 批）
    my_palace: str = ""                    # 主角開著的那章落的宮（你的章落在他身上，他開同宮的章，併章重設計）
    calls: dict[str, list[int]] = field(default_factory=dict)   # 這一生命數找上你的時刻（名字 → 時刻）
    waiting: frozenset[str] = frozenset()  # 找上你的事還在等你回話或辦的人
    advice: dict[str, tuple[int, str]] = field(default_factory=dict)   # 你勸過、他聽的：名字 →（時刻, 結局）
    card: dict | None = None               # 時代卡（脫節的人慢慢適應，第 8-3 批）


@dataclass
class Outcome:
    npc: dict                              # 演算後的 NPC
    fields: dict = field(default_factory=dict)       # 要寫回的欄位
    notes: list[dict] = field(default_factory=list)  # 新記事（近況、生死）
    died_at: int | None = None
    moved_from: str = ""
    stages: list[str] = field(default_factory=list)  # 這段時間突破到的境界
    fated: list[tuple[int, str]] = field(default_factory=list)   # 這段時間收場的章：（時刻, 傳聞那句）
    visits: list[tuple[str, bool]] = field(default_factory=list)   # 他的章找上你：（宮, 人到了你那）
    owed: list[str] = field(default_factory=list)     # 以你為命主的章收了：結局（順著欠你小恩、抗著記恨）


def months(shichen: int) -> int:
    return shichen // SHICHEN_PER_MONTH


def monthly_total(start: int, end: int, rate: float) -> int:
    """從 start 到 end 累積的整數量（每月 rate）。用曆月計算：分幾次算加起來都一樣，不會因為四捨五入而流失。"""
    return math.floor(rate * months(end)) - math.floor(rate * months(start))


def evolve(p: dict, *, rng: random.Random, start: int | None, end: int, world: World,
           relation: dict | None = None, turn_no: int = 0) -> Outcome:
    """把 NPC 從 start 演算到 end。start 為 None（第 10b 步之前登錄）：只記下時間，不回溯。"""
    out = Outcome(npc=dict(p))
    gone = p["status"] != "ALIVE" or p.get("goal") == npc.ASCENDED   # 飛升的人不在此界（16l）
    if start is None or end - start < MIN_SPAN or gone:
        if start is None or gone:
            out.fields["evolved_shichen"] = end
            out.npc["evolved_shichen"] = end
        return out
    window = [n for n in world.notes if start <= n["clock_shichen"] < end]   # 半開區間：每條記事只算一次
    apply_memories(out, window, world)
    goal_from_relation(out, relation, world.protagonist, world.my_lv)
    n = min(MAX_SEGMENTS, max(1, months(end) - months(start)))
    plus, risk = truth.npc(world.fate, p, relation)
    for i in range(n):
        a, b = start + (end - start) * i // n, start + (end - start) * (i + 1) // n
        heal(out, rng, a, b)
        if risk and out.npc["condition"] == "無恙" and rng.random() < risk * (b - a) / SHICHEN_PER_YEAR:   # 情劫：遭了一劫
            out.npc.update(condition="重傷", rewrite_reason="重傷")
            _note(out, memory.NEWS, "遭了一劫，身受重傷", b, turn_no)
        grow(out, rng, a, b, world, turn_no, plus)
        chapter(out, rng, a, b, world, turn_no)
        if old_age(out, a, b, turn_no) or erased(out, rng, a, b, turn_no):
            break
        if not come_back(out, rng, a, b, world, turn_no):
            move(out, rng, a, b, world, turn_no)
        adapt(out.npc, rng, a, b, world.card)
    if out.died_at is not None and out.npc.get("opened"):   # 命者死了：當場收、算放著（第 122c-7 題）
        close(out.npc, stage.LEFT)
    out.npc["evolved_shichen"] = end
    out.fields = changed_fields(p, out.npc)
    return out


def changed_fields(before: dict, after: dict) -> dict:
    """演算改了哪些欄位（要寫回資料庫的）。"""
    return {k: after[k] for k in WRITABLE if after.get(k) != before.get(k)}


WRITABLE = ("location", "status", "condition", "realm_lv", "stage_index", "cultivation", "goal", "goal_target",
             "ambition", "kindness", "courage", "suspicion", "rewrite_reason", "evolved_shichen", "away_since",
             "away_from", "chapters", "opened")


def _note(out: Outcome, kind: str, text: str, when: int, turn_no: int) -> None:
    out.notes.append(memory.note(memory.NPC, out.npc["name"], kind, text, clock_now=when, turn_no=turn_no))


# ── 療傷 ─────────────────────────────────────────────────────────────────
def heal(out: Outcome, rng: random.Random, a: int, b: int) -> None:
    """負傷滿一個月痊癒；重傷每年約好一階（不足一年依比例的機率）。"""
    p = out.npc
    if p["condition"] == "負傷":
        p["condition"] = "無恙"
    elif p["condition"] == "重傷" and rng.random() < min(1.0, (b - a) / SHICHEN_PER_YEAR):
        p["condition"] = "負傷"


# ── 修煉與突破 ───────────────────────────────────────────────────────────
def years_per_stage(realm_lv: int) -> float:
    return npc.lifespan_years(realm_lv) / STAGE_SHARE


def pace(p: dict) -> float:
    """每個月得到的修為（一個小境界 100）。凡人沒有求道之心、野心也不高的不修行。"""
    if p["realm_lv"] == 0 and p["goal"] not in MORTAL_SEEKERS and npc.trait_level(p["ambition"]) != "高":
        return 0.0
    factor = GOAL_PACE.get(p["goal"], 0.5) * AMBITION_PACE[npc.trait_level(p["ambition"])]
    if p["condition"] == "重傷":
        factor /= 2
    return realm.PROGRESS_PER_STAGE / (years_per_stage(p["realm_lv"]) * 12) * factor


def attempt_months(next_lv: int) -> int:
    """多久衝關一次：沿用突破冷卻年數（至少一年）。"""
    return max(1, realm.TIERS[next_lv].cooldown_years) * 12


def grow(out: Outcome, rng: random.Random, a: int, b: int, world: World, turn_no: int, plus: int = 0) -> None:
    """plus：衝關千分比多加（真相分法：旺人、情劫讀二）。"""
    p = out.npc
    rate = pace(p)
    if rate <= 0:
        return
    cultivation = p.get("cultivation", 0) + monthly_total(a, b, rate)
    lv, stage, cultivation, _ = realm.advance(p["realm_lv"], p["stage_index"], cultivation, gated=False)
    p.update(realm_lv=lv, stage_index=stage, cultivation=cultivation)
    if not realm.at_bottleneck(lv, stage, cultivation):
        return
    if npc.is_minor(p, b) and lv + 1 > npc.MINOR_MAX_LV:
        return
    every = attempt_months(lv + 1)
    attempts = min(MAX_ATTEMPTS_PER_SEGMENT, months(b) // every - months(a) // every)
    for _ in range(attempts):
        roll = rng.randint(1, 1000)
        if roll <= BREAKTHROUGH_PERMILLE[p["realm_lv"] + 1] + plus:
            p.update(realm_lv=p["realm_lv"] + 1, stage_index=0, cultivation=0, rewrite_reason="境界提升")
            name = realm.stage_name(p["realm_lv"], 0)
            out.stages.append(name)
            _drift(out, DRIFT_BREAKTHROUGH)
            text = "身合大道，天道易主" if p["realm_lv"] == realm.MAX_LV else f"突破至{name}"
            if p["realm_lv"] == realm.ASCEND_LV:   # 破空（16l B3b）：去了仙域，從此不在此界（搬不搬上去由 game/realms 決定）
                p.update(location=AWAY, away_since=b, away_from=p["location"], goal=npc.ASCENDED, goal_target="",
                         heaven_role="")
                text = "破空飛升，從此不在此界"
            _note(out, memory.NEWS, text, b, turn_no)
            return
        p["cultivation"] = max(0, p["cultivation"] - FAILURE_LOSS)
        if roll > 1000 - GREAT_FAILURE_PERMILLE:
            p.update(condition="重傷", rewrite_reason="重傷")
            _note(out, memory.NEWS, "衝關失敗，身受重傷", b, turn_no)
            return
        if p["condition"] == "無恙":
            p["condition"] = "負傷"
        return


# ── 老死 ─────────────────────────────────────────────────────────────────
# ── 命途的章（第 122-2 題，第 122b 批）──────────────────────────────────────
ENDS = (stage.ALONG, stage.AGAINST, stage.LEFT)
LEAN = {stage.ALONG: "kindness", stage.AGAINST: "courage", stage.LEFT: "suspicion"}   # 第 122-2-1 題甲：低中高多 0、1、2 份
SPAN, SWING, PUSH = SHICHEN_PER_YEAR, 10, 2   # 章開一年；收章時好感升降 10 以上，那個結局多 2 份（第 122c-2 題甲，暫定）
REACH = 15 * SHICHEN_PER_DAY                  # 腳程幾天內到得了才找上你（第 122c-5 題甲）
CALLS, CALL_GAP = 3, SHICHEN_PER_YEAR // 4    # 一章最多找你幾次、上一件處理完隔多久再來（併章重設計第 4 題甲，暫定）
MIRROR = {"父母": "子女", "子女": "父母"}      # 你的章落在他身上，他那章同宮、父母子女對調（併章重設計第 8 題甲）
TIED = "併"   # opened 第六欄：跟你開著的章併成同一條事端，你的章收了他才收（第 7-4c 批）
END_NOTE = {stage.ALONG: "他順著走，跟{人}牽扯更深了", stage.AGAINST: "他跟{人}翻了臉，這筆帳還沒完",
            stage.LEFT: "他沒理會，{人}那頭的事越鬧越大"}
END_RUMOR = {stage.ALONG: "{名}跟{人}的牽扯越來越深", stage.AGAINST: "{名}跟{人}翻了臉", stage.LEFT: "{名}躲著{人}那頭的事"}
OUTSIDER = "一個外人"   # 宮裡沒人：命主照模板新來，背景不登錄


def chapter(out: Outcome, rng: random.Random, a: int, b: int, world: World, turn_no: int) -> None:
    """特殊命 NPC 的章（第 122-2、129-9 題；第 122c-2 題甲改成一段時間）。opened＝「開章時刻:境界:命主:宮:開章好感」。
    到了新範圍開章：從他的角度分宮（你的羈絆也算，沒算帳）、照 129-2、129-3 抽宮，命主＝上一章抗著（或順著又落同宮）的人，
    不然宮裡的人；記一筆宮那句。命主是你：同一時間只一章（第 122c-3 題）；你開著的章也是他＝併章（第 7-4c 批，opened 多一欄 TIED），你的章收了他才收。
    併章重設計（progress/併章草稿.md）：你的章落在他身上、他手上沒章，就當場開一章命主是你、同宮（MIRROR），記 TIED，不看他的範圍；
    命主是你的章開章找你一次，之後上一件你處理完（world.waiting 沒他）、隔 CALL_GAP 再來，一章最多 CALLS 次。
    一年後或他再突破就收；命主死了照 122-3 換人，沒人接就收。收章他自己擲：性格份數＋開章到收章對命主的好感升降
    （外人、命主死了只看性格）；你這章勸過、他聽了（world.advice）就照你勸的收；記事一筆，傳聞由 pulse.outcome_events 出；命主是你的記進 out.owed。"""
    p, me = out.npc, world.protagonist
    if not p.get("hidden"):
        return
    dead = set(world.gone) | {n for n, q in world.npcs.items() if q["status"] != "ALIVE"}
    if p.get("opened"):
        since, lv, boss, where, like, *tied = p["opened"].split(":")
        if boss in dead and (h := heir(boss, world.bonds, set(world.npcs) - dead - {p["name"], me})):
            boss, like = h, world.like(p["name"], h, b)
        both = boss == me and p["name"] == world.my_open   # 併章（第 7-4c 批）：你開著的章也是他，兩章同一條事端
        tied = tied or ([TIED] if both else [])
        p["opened"] = ":".join([since, lv, boss, where, str(like), *tied])
        if boss not in dead and (both if tied else b - int(since) < SPAN) and p["realm_lv"] <= int(lv):
            if boss and boss == me and not out.visits and due(p["name"], int(since), b, world):
                visit(out, world, where)
            return
        d = world.like(p["name"], boss, b) - int(like) if boss and boss not in dead else None
        lean = "" if d is None else stage.ALONG if d >= SWING else stage.AGAINST if d <= -SWING else stage.LEFT
        told = world.advice.get(p["name"]) if boss and boss == me else None
        end = told[1] if told and told[0] >= int(since) else \
            rng.choices(ENDS, [1 + ("低", "中", "高").index(npc.trait_level(p[LEAN[e]])) + PUSH * (e == lean) for e in ENDS])[0]
        note, rumor = close(p, end)
        _note(out, memory.NEWS, note, b, turn_no)
        out.fated.append((b, rumor))
        out.owed += [end] if boss and boss == me else []
    done = p.get("chapters") or []
    taken = any(q.get("opened", "").split(":")[2:3] == [me] for n, q in world.npcs.items() if n != p["name"])
    if p["name"] == world.my_open and world.my_palace and not taken and len(done) < len(stage.LADDER):   # 你的章牽動他（併章重設計第 8 題甲）
        boss, where, tied = me, MIRROR.get(world.my_palace, world.my_palace), ":" + TIED
    elif len(done) >= route.scope(p["realm_lv"]):
        return
    else:
        board = palace.split(p["name"], world.bonds + world.mine, [], {n: q.get("birth_shichen") for n, q in world.npcs.items()}, dead)
        last, _, who, was = route.last({"chapters": done})
        where = palace.draw(rng, board, stage.palaces(p["hidden"], len(done) + 1) or list(palace.PALACES), p["hidden"], palace.boost(last, was, ""))
        ok = lambda n: n not in dead and (n != me or not taken)
        held = who and ok(who) and (last == stage.AGAINST or last == stage.ALONG and where == was)
        boss, tied = who if held else next((n for n in palace.who(board, where) if ok(n)), ""), ""
    p["opened"] = f"{b}:{p['realm_lv']}:{boss}:{where}:{world.like(p['name'], boss, b) if boss else 0}{tied}"
    _note(out, memory.NEWS, stage.palace_line(p["hidden"], where).replace("你", "他"), b, turn_no)
    if boss and boss == me:
        visit(out, world, where)


def due(name: str, since: int, b: int, world: World) -> bool:
    """再找你一次（併章重設計第 4 題甲）：上一件你處理完了（不在等你回話、辦事）、隔 CALL_GAP，這章不到 CALLS 次。"""
    came = [t for t in world.calls.get(name, ()) if t >= since]
    return name not in world.waiting and len(came) < CALLS and b - max(came, default=since) >= CALL_GAP


def visit(out: Outcome, world: World, where: str) -> None:
    """他的章以你為命主，找上你（第 122c-1 題、併章重設計第 2 題甲）：腳程 REACH 內、沒重傷就人到你那，不然託人帶話。
    帶什麼事、怎麼開口由 game/service._faced 照宮和好感定。"""
    p = out.npc
    km = world.near.get(p["location"])
    came = km is not None and space.travel_shichen(km, p["realm_lv"]) <= REACH and p["condition"] != "重傷"
    if came:
        p["location"] = world.here
    out.visits.append((where, came))


def close(p: dict, end: str) -> tuple[str, str]:
    """收章：記進 chapters（跟主角同格式「結局:0:命主:宮」，NPC 不信哪一讀）、清掉 opened。回傳（記事, 傳聞那句）。"""
    boss, where = p["opened"].split(":")[2:4]
    p.update(chapters=[*(p.get("chapters") or []), f"{end}:0:{boss}:{where}"], opened="")
    return END_NOTE[end].format(人=boss or OUTSIDER), END_RUMOR[end].format(名=p["name"], 人=boss or OUTSIDER)


def heir(who: str, bonds: list[dict], alive: set[str]) -> str:
    """命主死了誰接手（第 122-3 題）：他的親人師徒伴侶，不然同勢力的人；都沒有回傳空字串。"""
    halls = {b["b"] for b in bonds if b["a"] == who and b["type"] in MEMBER_BONDS}
    near = [b["a"] if b["b"] == who else b["b"] for b in bonds if who in (b["a"], b["b"]) and b["type"] in DEAREST]
    return next((n for n in near + [b["a"] for b in bonds if b["b"] in halls and b["type"] in MEMBER_BONDS] if n in alive), "")


def chapters_ok(v) -> bool:
    """存檔檢查：NPC 走過的章，最多五章（村落到世界）。"""
    parts = [c.split(":") for c in v] if isinstance(v, list) and all(isinstance(c, str) for c in v) else None
    return parts is not None and len(parts) <= len(stage.LADDER) and all(
        len(c) == 4 and c[0] in ENDS and c[1] == "0" and c[3] in palace.PALACES for c in parts)


def opened_ok(v) -> bool:
    """存檔檢查：開著的章（空＝沒開）。"""
    c = v.split(":") if isinstance(v, str) else []
    return v == "" or len(c) in (5, 6) and c[0].isdigit() and c[1].isdigit() and c[3] in palace.PALACES and c[4].lstrip("-").isdigit() \
        and c[5:] in ([], [TIED])


def death_time(p: dict) -> int | None:
    if realm.TIERS[p["realm_lv"]].lifespan is None or p.get("birth_shichen") is None:
        return None
    return p["birth_shichen"] + (npc.lifespan_years(p["realm_lv"], p.get("race", "人族")) + origins.years(p)) * SHICHEN_PER_YEAR


def old_age(out: Outcome, a: int, b: int, turn_no: int) -> bool:
    """壽元在這一段之內耗盡：坐化（死亡不可逆）。"""
    p = out.npc
    when = death_time(p)
    if when is None or when >= b:
        return False
    when = max(a, when)
    place = "遠方" if p["location"] == AWAY else p["location"]
    p.update(status="FALLEN", condition=npc.CONDITIONS[-1])
    out.died_at = when
    _note(out, memory.DEATH, f"於{place}壽終坐化", when, turn_no)
    return True


def erased(out: Outcome, rng: random.Random, a: int, b: int, turn_no: int) -> bool:
    """在破格期的人被天道抹殺（16l）：沒有存踏入的時刻，每年 breach.NPC_YEARLY 的機會。"""
    p = out.npc
    if realm.GATES.get(p["realm_lv"]) != p["stage_index"] or rng.random() >= 1 - (1 - breach.NPC_YEARLY) ** (
            (b - a) / SHICHEN_PER_YEAR):
        return False
    place = "遠方" if p["location"] == AWAY else p["location"]
    p.update(status="FALLEN", condition=npc.CONDITIONS[-1])
    out.died_at = b
    _note(out, memory.DEATH, f"於{place}被天道抹殺", b, turn_no)
    return True


# ── 移動 ─────────────────────────────────────────────────────────────────
def move(out: Outcome, rng: random.Random, a: int, b: int, world: World, turn_no: int) -> None:
    """依目標移動：求道 → 宗門或秘境、逐利 → 坊市或城鎮、隱居 → 荒野、守護留在原地、報恩與追隨 → 對象所在。
    沒有合適的已知地點時去了遠方（使用者 2026-10-05 決定 A）。重傷的人不遠行。"""
    p = out.npc
    if p["condition"] == "重傷":
        return
    chance = MOBILITY.get(p["goal"], 0.0) * (b - a) / SHICHEN_PER_YEAR
    if p["goal"] not in ("報恩", "追隨"):
        chance *= AMBITION_PACE[npc.trait_level(p["ambition"])]
    if chance <= 0 or rng.random() >= min(MAX_MOVE_CHANCE, chance):
        return
    destination = _destination(p, rng, world)
    if not destination or destination == p["location"]:
        return
    origin = p["location"]
    out.moved_from = out.moved_from or origin
    p["location"] = destination
    # 去遠方時記下時間與家鄉（保底回家用）；回來了就清掉
    p["away_since"], p["away_from"] = (b, origin) if destination == AWAY else (None, "")
    if destination == AWAY:
        text = f"離開{origin}，去了遠方"
    elif origin == AWAY:
        text = f"從遠方來到{destination}"
    else:
        text = f"離開{origin}，前往{destination}"
    _note(out, memory.NEWS, text, b, turn_no)


def _destination(p: dict, rng: random.Random, world: World) -> str:
    if p["goal"] in ("報恩", "追隨"):
        target = world.npcs.get(p["goal_target"])
        if target and target["status"] == "ALIVE" and target["location"] != AWAY:
            return target["location"]
        return ""                         # 對象是主角：跟著主角走留到第 10c 步
    wanted = PLACE_PREFERENCE.get(p["goal"])
    if not wanted:
        return ""
    here = next((x for x in world.places if x["name"] == p["location"]), {})
    if here.get("type") in wanted:
        return ""                         # 已經在想去的那種地方了（宗門裡求道、荒野裡隱居）
    choices = sorted(x["name"] for x in world.places if x.get("type") in wanted and x["name"] != p["location"])
    return rng.choice(choices) if choices else AWAY


# ── 從遠方回來（第 10c-2b 步）─────────────────────────────────────────────
def come_back(out: Outcome, rng: random.Random, a: int, b: int, world: World, turn_no: int) -> bool:
    """在遠方的人這一段會不會回來：倉促趕回（出了事）優先，其次保底（在外太久）。
    約定、跟你有關的人由 domain/visitors 處理；想去的地方有了照 move()。回傳是否回來了。重傷的人不遠行。"""
    p = out.npc
    if p["location"] != AWAY or p["condition"] == "重傷":
        return False
    if p.get("away_since") is None:      # 第 10c-2b 步之前就去了遠方：從第一次演算開始計時
        p["away_since"] = a
    destination = urgent_return(p, rng, a, b, world)
    hasty = bool(destination)
    if not destination and b - p["away_since"] >= home_after(p):
        destination = _home(p, rng, world)
    if not destination or destination == AWAY:
        return False
    p.update(location=destination, away_since=None, away_from="")
    out.moved_from = out.moved_from or AWAY
    _note(out, memory.NEWS, f"從遠方{'趕回' if hasty else '回到'}{destination}", b, turn_no)
    return True


def adapt(p: dict, rng: random.Random, a: int, b: int, card: dict | None) -> None:
    """脫節的人回到世上，照這段時間擲（時間 ÷ 一年），平均一年左右適應：改標「換時代」照新時代重寫（第 8-3-1 題乙）。"""
    if card and p["location"] != AWAY and era.behind(p, card) and rng.random() < (b - a) / SHICHEN_PER_YEAR:
        p["rewrite_reason"] = npc.NEW_ERA


def home_after(p: dict) -> int:
    """保底：在外待了壽元的十分之一就回家（不受壽元限制的最多 HOME_MAX_YEARS 年）。"""
    return int(min(HOME_MAX_YEARS, npc.lifespan_years(p["realm_lv"]) / HOME_SHARE) * SHICHEN_PER_YEAR)


def urgent_return(p: dict, rng: random.Random, a: int, b: int, world: World) -> str:
    """他離開之後、這一段裡出了事 → 趕回出事的地方。只看記事的種類與欄位，不解析文字。
    親近的人死了（奔喪）、自己勢力的首領死了、守護的人被攻擊或重傷。"""
    me = p["name"]
    ties = {bd["b"] if bd["a"] == me else bd["a"]: bd["type"] for bd in world.bonds
            if bd["a_kind"] == bd["b_kind"] == "npc" and me in (bd["a"], bd["b"])}
    for n in world.notes:
        if not max(a, p["away_since"]) <= n["clock_shichen"] < b:
            continue
        who = n["subject"]
        where, chance = "", 0.0
        if n["kind"] == memory.DEATH and ties.get(who) in DEAREST + DEAR:
            where, chance = world.npcs.get(who, {}).get("location", ""), 1.0 if ties[who] in DEAREST else 0.5
        elif n["kind"] == memory.DEATH and (faction := _led_faction(who, me, world)):
            where = world.factions.get(faction, "")
            chance = LEADER_HEIR_RETURN if _is_heir(me, faction, world) else LEADER_MEMBER_RETURN
        elif p["goal"] == "守護" and who == p["goal_target"] and (n["kind"] == memory.ATTACK or n.get("actor")):
            where, chance = world.npcs.get(who, {}).get("location", ""), 1.0
        if where and where != AWAY and rng.random() < chance:
            return where
    return ""


def _led_faction(leader: str, member: str, world: World) -> str:
    """leader 是 member 所屬勢力的首領：回傳那個勢力，否則空字串。"""
    led = {bd["b"] for bd in world.bonds if bd["a"] == leader and bd["type"] == "首領"}
    return next((bd["b"] for bd in world.bonds if bd["a"] == member and bd["type"] == "成員" and bd["b"] in led), "")


def _is_heir(me: str, faction: str, world: World) -> bool:
    """是不是該繼位的人：活著的成員裡境界最高的（與世界脈動的繼位規則相同）。"""
    members = [world.npcs[bd["a"]] for bd in world.bonds if bd["b"] == faction and bd["type"] == "成員"
               and world.npcs.get(bd["a"], {}).get("status") == "ALIVE"]
    best = max(members, key=lambda x: (x["realm_lv"], x["stage_index"], x["cultivation"]), default=None)
    return best is not None and best["name"] == me


def _home(p: dict, rng: random.Random, world: World) -> str:
    """當初離開的地方；不知道（第 10c-2b 步之前去的）或那裡不在了，就回到隨便一個已知的地方。"""
    places = sorted(x["name"] for x in world.places)
    if p.get("away_from") in places:
        return p["away_from"]
    return rng.choice(places) if places else ""


# ── 性格漂移與目標轉換（依這段時間的記事）─────────────────────────────────
def _drift(out: Outcome, change: dict) -> None:
    p = out.npc
    for trait, delta in change.items():
        before = npc.trait_level(p[trait])
        p[trait] = npc.clamp(p[trait] + delta, DRIFT_RANGE)
        if npc.trait_level(p[trait]) != before and p.get("rewrite_reason") != "重傷":
            p["rewrite_reason"] = "性情轉變"


def close_ones(name: str, bonds: list[dict]) -> set[str]:
    """與這個人有親近羈絆的人（師徒、親人、恩人、友人、戀人、伴侶、結義）。"""
    return {b["b"] if b["a"] == name else b["a"] for b in bonds
            if b["type"] in CLOSE_BONDS and b["a_kind"] == "npc" and b["b_kind"] == "npc" and name in (b["a"], b["b"])}


def apply_memories(out: Outcome, window: list[dict], world: World) -> None:
    """這段時間發生在他身上與他在乎的人身上的事：性格漂移、目標轉換。只看記事的種類與欄位，不解析文字。"""
    me = out.npc["name"]
    dear = close_ones(me, world.bonds)
    killers: set[str] = set()
    for n in window:
        if n["subject"] == me and n["kind"] == memory.BROKEN:
            _drift(out, DRIFT_BROKEN)
        elif n["subject"] == me and n["kind"] == memory.ATTACK:
            _drift(out, DRIFT_ATTACKED)
        elif n["subject"] == me and n["kind"] == memory.TURN and n.get("attitude") == "親近":   # 例如被你救了
            _drift(out, DRIFT_WARMED)
        elif n["subject"] == me and n["kind"] == memory.TURN and n.get("attitude") == "敵視":
            _drift(out, DRIFT_SOURED)
        elif n["subject"] in dear and n["kind"] == memory.DEATH:
            _drift(out, DRIFT_BEREAVED)
            # NPC 殺的照舊直接知道兇手；你殺的要知道是你才報（血仇，第 121-2 題，game/news._learn）；兇手已死就不報
            if n.get("actor") and n["actor"] not in world.gone and n["actor"] != world.protagonist:
                killers.add(n["actor"])
    change_goal(out, killers, world)


def change_goal(out: Outcome, killers: set[str], world: World) -> None:
    """對象已不在人世的目標失去意義；親近的人被殺 → 找兇手復仇（膽小又心善的人改為避世）。"""
    p = out.npc
    before = (p["goal"], p["goal_target"])
    if p["goal"] in PERSONAL_GOALS and p["goal_target"] in world.gone:
        _set_goal(p, "求道" if npc.trait_level(p["ambition"]) != "低" else "隱居", "")
    if killers:
        timid = npc.trait_level(p["courage"]) == "低" and npc.trait_level(p["kindness"]) == "高"
        _set_goal(p, "隱居", "") if timid else _set_goal(p, "復仇", sorted(killers)[0])
    if (p["goal"], p["goal_target"]) != before and p.get("rewrite_reason") != "重傷":
        p["rewrite_reason"] = "性情轉變"


def goal_from_relation(out: Outcome, relation: dict | None, protagonist: str, my_lv: int = 0) -> None:
    """他對你的感情改變了他想做的事：恨你入骨 → 復仇；感激又沒野心 → 追隨；欠你大恩以上 → 報恩（16v 第 113 題）。
    畏懼你（第 121-10 題）：血仇不敢報改隱居，其他仇不找你報（告官、雇人還沒做）。"""
    if not relation:
        return
    p = out.npc
    before = (p["goal"], p["goal_target"])
    grateful = relation["affinity"] >= GRATITUDE[0] and relation["trust"] >= GRATITUDE[1]
    awed = npc.dread(relation, p, my_lv) == npc.AWED
    if relation["grudge"] == FEUD and awed and p["goal"] != "隱居":
        _set_goal(p, "隱居", "")
    elif relation["grudge"] and relation["affinity"] <= GRUDGE_AFFINITY and p["goal"] != "復仇" \
            and npc.trait_level(p["courage"]) != "低" and not awed:
        _set_goal(p, "復仇", protagonist)
    elif grateful and p["goal"] in SWAYABLE_GOALS and npc.trait_level(p["ambition"]) == "低":
        _set_goal(p, "追隨", protagonist)
    elif favour.top(relation.get("favours", [])) in (favour.BIG, favour.LIFE) and p["goal"] in SWAYABLE_GOALS:
        _set_goal(p, "報恩", protagonist)
    if (p["goal"], p["goal_target"]) != before and p.get("rewrite_reason") != "重傷":
        p["rewrite_reason"] = "性情轉變"


def _set_goal(p: dict, goal: str, target: str) -> None:
    p["goal"], p["goal_target"] = goal, target


# ── 打聽 ─────────────────────────────────────────────────────────────────
def goal_phrase(p: dict, protagonist: str) -> str:
    target = p["goal_target"] or _TARGET_FALLBACK.get(p["goal"], "")
    if target == protagonist:
        target = "你"
    return GOAL_PHRASES.get(p["goal"], p["goal"]).format(t=target)


HEARD_OUTCOMES = ("成功", "大成功")


def inquiry_text(p: dict, outcome: str, protagonist: str, news: str = "") -> tuple[str, str]:
    """打聽某人得到的消息。回傳（消息, 打聽到的目標；沒打聽到為空字串）。
    成功：下落、生死、狀況、目標；大成功：再加境界與最近的近況。失敗：什麼也沒問到。"""
    name = p["name"]
    if outcome not in HEARD_OUTCOMES:
        return f"打聽不到{name}的消息", ""
    if p["status"] != "ALIVE":
        return f"{name}已不在人世" + (f"（{news}）" if news else ""), ""
    where = "去了遠方，下落不明" if p["location"] == AWAY else f"如今在{p['location']}"
    health = "" if p["condition"] == "無恙" else f"，{p['condition']}"
    goal = goal_phrase(p, protagonist)
    text = f"{name}{where}{health}，{goal}"
    if outcome == "大成功":
        power = "深不可測" if p["hidden_power"] else f"修為約在{realm.stage_name(p['realm_lv'], p['stage_index'])}"
        text += f"；{power}" + (f"；近來{news}" if news else "")
    return text, goal
