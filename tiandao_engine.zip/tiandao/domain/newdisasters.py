"""模型寫的天災（progress/模型生成內容.md 第九節「天災」八題、零件草稿；第十節「天災要不要改」三處）。純函式，不呼叫模型。

- 天災＝一種模型事端：plan 擲骨架（種類那一行、動機、轉機、處名、風味），record 照 rules/content/disaster_parts.txt「骨」那張
  拼成跟 rules/content/plots/ 一樣格式的全文（plots_m），放事端、線索、轉折、時間線、階段表都用事端那一套。
- 兩種骨架：勢＝當地有勢力（隱瞞者＝壓下消息的人、第三者＝替他辦事的人）；獨＝沒有勢力（沒有反派，第三者＝記得上回的人，
  收尾是前兆的證據、拿給大家看就是說服）。受害者＝最早發現的人。
- 模型照 newplots 的三段只寫短欄（「問」那張）；沒寫好、還沒寫完的欄用零件表的通用句（第 6 題甲），一定拼得出來。
- 「來源｜模型｜天災｜鑰匙」認得是哪一場（key：天災名@開始時刻@地方）。
"""
from __future__ import annotations

import random
import re

from . import checks, disaster, newplots, plot
from . import era as era_mod
from .clock import SHICHEN_PER_MONTH, SHICHEN_PER_YEAR
from .tales import CONTENT

WAY = "天災"
SEASON = 3 * SHICHEN_PER_MONTH   # 前兆一律提前一季（第 8 題）
EASE = ("傳話", "揭穿", "說服")   # 爆發前做到這幾個轉折：罹難、物價漲幅減半（第 5 題甲）
_rows = [l.split("｜") for l in (CONTENT / "disaster_parts.txt").read_text(encoding="utf-8").splitlines() if l and not l.startswith("#")]
_all = lambda k: [r[1:] for r in _rows if r[0] == k]   # noqa: E731
_for = lambda kinds, bone: kinds == "全" or bone in kinds.split("、")   # noqa: E731
KINDS = {r[0]: r[1:] for r in _all("種類")}            # 天災名 → 職業、發現的人是、前兆、倒處、轉機、前兆的證據、來的樣子
MOTIVES = _all("動機")                                  # 勢力種類、為什麼壓、第三者職業、第三者是、物證（古、現、未）
TURNS = {r[0]: r[1:] for r in _all("轉機")}             # 類 → 行動、關鍵字、選項、事實
WORDS = {r[0]: r[1] for r in _all("處詞")}
WHO, ASKS, BONES, FALLBACK = _all("誰"), _all("問"), _all("骨"), dict(_all("通用"))
FLAVORS = [l.split("｜") for l in (CONTENT / "flavors.txt").read_text(encoding="utf-8").splitlines() if l and not l.startswith("#")]
SHOWN = {"公共處": "{公處}", "苦主家": "發現的人住的{苦處}", "隱瞞處": "壓消息的人的{隱處}", "倒處": "{倒處}"}
LIES = ("壓下", "壓著", "封口", "瞞著")   # 不知道真相的欄不准出現（洩底）


def motive(ftype: str) -> list[str]:
    """勢力種類 → 動機那一行；沒有勢力或種類不在表上，是最後那一行（獨，沒有反派）。"""
    return next((m for m in MOTIVES if ftype and ftype in m[0].split("、")), MOTIVES[-1])


def bone(slot: dict) -> str:
    return "勢" if slot["motive"][0] else "獨"


def plan(rng: random.Random, kind: str, era_now: str, ftype: str, key: str, n: int, world_seed: str) -> dict:
    """這一場要寫的骨架。n：這個世界已經寫過幾場（風味照世界的順序輪流，擲完才重複，甲第 3 題）。"""
    job, who, signs, falls, turns, proof, come = KINDS[kind]
    m = motive(ftype)
    mine = [f for f in FLAVORS if WAY in f[2].split("、")]
    flavor = random.Random(f"{world_seed}:flavors").sample(mine, len(mine))[n % len(mine)]
    words = {w: rng.choice(v.split("、")) for w, v in WORDS.items()} | {"倒處": rng.choice(falls.split("、"))}
    words |= {"災": disaster.label(kind, era_now), "證": m[4 + era_mod.ERAS.index(era_now)] if m[0] else proof}
    return {"kind": kind, "key": key, "era": era_now, "motive": m, "turn": rng.choice(turns.split("、")), "words": words,
            "flavor": flavor[:2], "job": job, "who": who, "signs": signs, "come": come}


def labels(slot: dict) -> dict[str, str]:
    return {"村": "這裡", **{role: tag for kinds, role, tag in WHO if _for(kinds, bone(slot))}}


def _show(slot: dict, text: str) -> str:
    m = slot["motive"]
    text = text.replace("{動機}", m[1]).replace("{幫手是}", m[3]).replace("{轉機}", slot["turn"]).replace("{來勢}", slot["come"])
    return plot.fill(plot.fill(plot.fill(text, {**labels(slot), **SHOWN}), slot["words"]), slot["words"])


def brief(slot: dict, part: str) -> dict:
    """叫 bits 時的 slot（同 newplots.brief）：blind 不給「有人壓消息」這件事。"""
    m, (name, trait) = slot["motive"], slot["flavor"]
    tags = "、".join(f"「{t}」" for t in labels(slot).values() if t != "這裡")
    lines = [f"時代：{slot['era']}。{{災}}就要來了，發現的人是{slot['who']}，他注意到的前兆是：{slot['signs']}。",
             f"風味：{name}（{trait}），照這個傳統的味道寫。不要寫{tags}這幾個代稱。"]
    if part != "blind":
        lines.append(f"真相（只有壓消息的人、幫手知道）：壓消息的人早就知道{{災}}要來，{m[1]}；幫手是{m[3]}。" if m[0] else
                     f"真相：大家都不信發現的人；記得上回的人是{m[3]}，他知道上回{{災}}來之前也是這樣。")
    return {"what": f"一場{slot['words']['災']}來之前的事", "era": slot["era"], "brief": _show(slot, "\n".join(lines))}


def asks(slot: dict, part: str) -> list[dict]:
    """這一段要模型寫的欄：key、ask、span、leak（同 newplots.asks）。"""
    return [{"key": key, "ask": _show(slot, ask), "span": newplots.SPANS[span], "leak": leak == "查"}
            for kinds, p, key, span, leak, ask in ASKS if p == part and _for(kinds, bone(slot))]


def faults(slot: dict, part: str, got: dict, era_now: str) -> dict[str, str]:
    """逐欄查：沒過的 → 原因（只重寫這幾欄）。代稱照抄的也退。"""
    out = {}
    for x in (x for x in asks(slot, part) if x["key"] in got):
        text = newplots._tidy(slot, x["key"], got[x["key"]])
        reason = (checks.basic([(text, x["span"])], era_now) or ("洩底" if x["leak"] and any(w in text for w in LIES) else "")
                  or ("代稱" if any(w in text for w in labels(slot).values() if w != "這裡") else "")
                  or ("沒有你" if x["key"] in ("burst", "after") and "你" not in text else ""))   # 牌是寫給玩家看的
        if reason:
            out[x["key"]] = reason
    return out


def hours(kind: str) -> dict[str, int]:
    """時間線的時刻（從前兆算）：爆發＝一季後，結束＝爆發加天災長度，結局＝結束後一年（第 8 題）。"""
    over = SEASON + disaster.BY_NAME[kind].months * SHICHEN_PER_MONTH
    return {"爆發": SEASON, "結束": over, "結局": over + SHICHEN_PER_YEAR}


def record(slot: dict, got: dict, name: str) -> dict:
    """存成一條（plots_m）。got：{欄: 字}，沒有的用通用句。骨那張的 [欄] 換成模型寫的、{動機}等換成這一場的。"""
    g = {k: newplots._tidy(slot, k, got.get(k) or v) for k, v in FALLBACK.items()}
    g |= {k: newplots._trace(g[k]) if g[k][-1] not in "？！。" else g[k] for k in ("rumor", "tr_end")}
    m, t, at = slot["motive"], TURNS[slot["turn"]], hours(slot["kind"])
    put = {"{動機}": m[1], "{勢力種類}": m[0], "{幫手職業}": m[2], "{職業}": slot["job"], "{前兆}": slot["signs"],
           "{路線}": f"路線:{name}", "{時3}": str(SEASON * 3 // 10), "{時6}": str(SEASON * 6 // 10),
           **{f"{{時{k}}}": str(v) for k, v in at.items()},
           "{機行動}": t[0], "{機字}": t[1], "{機選項}": t[2], "{機事實}": t[3].replace("{機}", g["turn"])}
    body = "\n".join("｜".join(row) for kinds, *row in BONES if _for(kinds, bone(slot)))
    body = re.sub(r"\[(\w+)\]", lambda x: g[x.group(1)], re.sub("|".join(map(re.escape, put)), lambda x: put[x.group(0)], body))
    rows = [f"牌｜{name}｜地方｜事端｜｜｜", f"來源｜{newplots.MODEL}｜{WAY}｜{slot['key']}",
            "｜".join(["表面", slot["era"], *(f"{k}={x}" for k, x in slot["words"].items())]), body]
    return {"name": name, "state": slot["era"], "body": "\n".join(rows), "source": newplots.MODEL}


def mine(t: dict) -> bool:
    """這條模板是模型寫的天災（不給一般事端挑）。"""
    return bool(t.get("來源")) and t["來源"][0][1:2] == [WAY]


def key_of(t: dict) -> str:
    return t["來源"][0][2] if mine(t) else ""


def key(state: dict) -> str:
    """一場天災的鑰匙：天災名@開始時刻@地方（地點狀況那一筆）。"""
    return f"{state['name']}@{state['started_shichen']}@{state['place']}"


def placed(plots: list[dict], templates: list[dict]) -> dict[str, dict]:
    """已經放了前兆的天災：{鑰匙: 那條事端}。"""
    by_name = {plot.name(t): t for t in templates if mine(t)}
    return {key_of(by_name[r["name"]]): r for r in plots if r["name"] in by_name}


def name(state: str, kind: str, era_now: str, taken: set[str]) -> str:
    """「雲州旱災」，撞名加二、三……（第 3 處補的：名字 Python 拼）。"""
    base = f"{state[:3]}{disaster.label(kind, era_now)}"
    return next(n for n in (base, *(base + c for c in "二三四五六七八九十")) if n not in taken)
