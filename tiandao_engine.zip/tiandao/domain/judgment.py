"""行動判定：行動性質 × 判定標的，d100。純函式：同樣的輸入與亂數種子，永遠得到同樣的結果。

規則（2026-10-04 與使用者討論定案，第 4 步，見 progress/HANDOFF.md）：
- 兩個維度（參考舊專案 judgment_targets.py）：性質＝你在做什麼，決定候選標的；
  標的＝這次擲骰在回答什麼問題，決定屬性與代價。一回合最多 2 個標的，判斷不出時用該性質的預設標的。
- 分類由誰判斷（混合）：點選項時用 AI 預先標好的性質與難度；自己打字時先用這裡的關鍵字（detect），
  判斷不出才由 game 層請 AI 從固定清單選（Python 只接受清單內的值）。
- 難度：基礎 50＋主次屬性＋任務難易（容易 +20、普通 0、困難 −15、極難 −30）＋狀態影響，限制在 5–95。
  舊版「境界越高做什麼都越容易」拿掉，境界差改在對手／環境上比較（第 6、7 步接上）。
- 結果：骰值 ≤ 成功率÷10 大成功；大失敗一般 5%，成功率低於 30% 時逐步上升，成功率 5% 時為 25%。
"""
from __future__ import annotations

import random
from dataclasses import asdict, dataclass, field, replace

from . import breakthrough, npc, realm, retreat, space
from . import status as status_mod

# ── 行動性質（名稱沿用第一階段，避免已存的回合紀錄與畫面要轉換）──────────────
CULTIVATE, COMBAT, EXPLORE, SOCIAL, STEALTH, REST, OBSERVE, BREAKTHROUGH = (
    "修煉", "戰鬥", "探索", "社交", "潛行", "休息", "觀察", "突破",
)
ENDURE, PRICE, MOVE = "抗性", "代價", "移動"   # 代價：瀕死時以壽元或修為換命；移動：沿已知路線前往（第 7 步）
WORK = "做工"                                  # 第 8 步：花時間換靈石，不擲骰
STUDY = "參悟"                                 # 第 3b-1 步：觀察現象累積感悟（domain/laws.py）
ALCHEMY, FORGE = "煉丹", "煉器"                 # 第 3b-3 步：技藝（domain/crafting.py）
NATURES = (COMBAT, STEALTH, EXPLORE, SOCIAL, CULTIVATE, ENDURE, REST, OBSERVE, WORK, STUDY, ALCHEMY, FORGE,
           BREAKTHROUGH, PRICE, MOVE)
NO_ROLL = {REST, OBSERVE, MOVE, WORK}  # 平時不擲骰（瀕死時休息改為擲「療傷」）
CRAFTS = (ALCHEMY, FORGE)

# ── 判定標的 ─────────────────────────────────────────────────────────────────
STRIKE, HIDE, DISCOVER, ORIENT, PERSUADE, PRY, ESCAPE, WITHSTAND, TREAT, PRACTICE, COMPREHEND = (
    "命中", "匿蹤", "發現", "辨向", "說服", "套話", "脫身", "硬撐", "療傷", "修行", "感悟",
)
FIRE_CONTROL, SMITH = "火候", "鍛打"
TARGET_ATTRS = {   # 標的 → (主屬性, 次屬性)
    STRIKE: ("physique", "root_bone"), HIDE: ("perception", "physique"), DISCOVER: ("perception", "wisdom"),
    ORIENT: ("wisdom", "perception"), PERSUADE: ("charisma", "wisdom"), PRY: ("wisdom", "charisma"),
    ESCAPE: ("physique", "perception"), WITHSTAND: ("physique", "root_bone"), TREAT: ("physique", "wisdom"),
    PRACTICE: ("root_bone", "wisdom"), COMPREHEND: ("wisdom", "perception"),
    FIRE_CONTROL: ("wisdom", "perception"), SMITH: ("physique", "wisdom"),
}
NATURE_TARGETS = {   # 性質 → 候選標的（第一個是預設）
    COMBAT: (STRIKE, ESCAPE), STEALTH: (HIDE, DISCOVER), EXPLORE: (DISCOVER, ORIENT),
    SOCIAL: (PERSUADE, PRY), CULTIVATE: (PRACTICE,), ENDURE: (WITHSTAND,), REST: (TREAT,), STUDY: (COMPREHEND,),
    ALCHEMY: (FIRE_CONTROL,), FORGE: (SMITH,),
}
ACTIVE_TARGETS = {STRIKE, HIDE, ESCAPE}          # 受狀態嚴重度影響的「主動出擊類」
DANGER_TARGETS = {STRIKE, HIDE, ESCAPE, WITHSTAND}   # 受所在地危險度影響（第 7 步）
REALM_DIFF_TARGETS = {STRIKE, HIDE, ESCAPE}          # 受與對手境界差影響（第 6 步）
AFFINITY_TARGETS = {PERSUADE, PRY}                   # 受對手好感影響（第 6 步）
MAX_CHECKS = 2

DIFFICULTY = {"容易": 20, "普通": 0, "困難": -15, "極難": -30}
NORMAL = "普通"
BURN_LIFESPAN, SACRIFICE_CULTIVATION = "燃燒壽元", "自損修為"

GREAT_SUCCESS, SUCCESS, FAILURE, GREAT_FAILURE = "大成功", "成功", "失敗", "大失敗"
CHANCE_RANGE = (5, 95)
BASE_GREAT_FAILURE, MAX_GREAT_FAILURE, RECKLESS_BELOW = 5, 25, 30

# ── 關鍵字（第一階段：找出性質）。強詞直接決定；弱詞只在沒有任何強詞時才採用 ──────────
# 單字容易誤中（「打」→「打聽」），所以戰鬥詞不收「打」「戰」「刺」。
_BREAKTHROUGH_WORDS = ("突破", "衝關", "破境", "衝擊瓶頸", "衝破瓶頸", "結丹")
_NOT_BREAKTHROUGH = ("突破重圍", "突破包圍", "突破防線", "突破封鎖", "突破口")
_ESCAPE_WORDS = ("逃", "撤退", "脫身", "突圍", "拔腿", "溜走", "跑路", "突破重圍")
_AMBUSH_WORDS = ("偷襲", "暗算", "趁其不備", "出其不意", "背後下手", "突襲")
_PRICE_WORDS = {BURN_LIFESPAN: ("燃燒壽元", "燃燒精血", "以壽元", "折壽"),
                SACRIFICE_CULTIVATION: ("散去修為", "自損修為", "自廢修為", "散功")}
_STRONG = {
    REST: ("休息", "睡", "歇", "療傷", "調息", "包紮", "止血", "靜養"),
    CULTIVATE: ("修煉", "修行", "打坐", "吐納", "閉關", "練功"),
    COMBAT: ("攻擊", "出手", "拔劍", "揮劍", "殺", "打鬥", "交手", "迎戰", "戰鬥", "砍", "出拳", "一拳", "一掌",
             "劈", "斬", "反擊", "格擋"),
    STEALTH: ("潛行", "偷", "躲", "藏", "跟蹤", "潛入", "潛進", "摸進", "溜進", "隱匿"),
    SOCIAL: ("交談", "攀談", "請教", "打聽", "說服", "勸", "套話", "探聽", "試探", "求救", "求情", "拜託", "談判"),
    ENDURE: ("硬撐", "撐住", "忍住", "咬牙", "頂住", "扛住", "抵抗"),
    OBSERVE: ("觀察", "看看", "環顧", "端詳", "打量"),
    EXPLORE: ("探索", "搜", "查看", "調查", "探查", "認路", "辨認方向", "尋"),
    WORK: retreat.WORK_VERBS,
    STUDY: retreat.STUDY_VERBS,
    ALCHEMY: ("煉丹", "煉藥", "開爐"),
    FORGE: ("煉器", "鍛造", "鑄造"),
}
_WEAK = {SOCIAL: ("說", "問", "談", "招呼"), EXPLORE: ("找", "前往", "走", "去")}
_NOT_KEYWORDS = ("拿出手", "掏出手", "伸出手", "出手相助", "出手闊綽", "殺價", "砍價", "殺魚", "殺雞", "殺時間", "砍柴", "劈柴",
                 "斬斷", "斬草除根", "躲雨", "藏好", "收藏", "偷懶", "偷笑", "偷閒")   # 含關鍵字但意思不同的詞：先拿掉再比對（打字第 5、6 題）
_CHAT_WORDS = ("？", "?", "問", "招呼", "謝", "寒暄", "聊", "說說")   # 只是問話、打招呼（故事第 3 題）
_ALLOWED_COMBOS = {frozenset({STEALTH, EXPLORE}): STEALTH,   # 潛進去找東西：匿蹤＋發現
                   frozenset({STUDY, CULTIVATE}): STUDY,     # 閉關參悟雷霆三年
                   frozenset({STUDY, OBSERVE}): STUDY}       # 觀察火焰，參悟其中變化

# 第二階段：同一性質下，依關鍵字挑出實際要判定的標的
_TARGET_WORDS = {
    DISCOVER: ("找", "搜", "偷", "取", "拿", "翻", "尋", "查"),
    ORIENT: ("路", "方向", "辨認", "認路", "迷"),
    PRY: ("打聽", "套話", "探聽", "試探", "問出", "消息"),
}


@dataclass(frozen=True)
class Intent:
    """要判定什麼。source：choice（AI 標好的選項）／keyword／ai／default。

    destination／travel：移動的目的地與路上花的時辰（由 game 層依已知路線算好）。
    移動到已知地點時 nature=移動、不擲骰；前往未知地點時 nature=探索、標的=辨向，成功才抵達。
    """
    nature: str
    targets: tuple[str, ...] = ()
    difficulty: str = NORMAL
    source: str = "keyword"
    price: str = ""
    destination: str = ""
    travel: int = 0
    new_place: bool = False
    spot: bool = False        # 走進上一回合提過的小地方（第 9g 批）：一定到、照常擲查探
    target_npc: str = ""      # 對象 NPC（第 6 步，由 game 層從名字或選項標註認出）
    blocked: str = ""         # 不能嘗試的原因（例如對象不在場）
    inquiry_npc: str = ""     # 打聽的對象：不在場的 NPC（第 10b 步；判定照樣是套話）
    law: str = ""             # 參悟的法則系（第 3b-1 步，由 game 層從字面認出）
    recipe: str = ""          # 煉丹、煉器的產物（第 3b-3 步，由 game 層從字面認出）
    said: str = ""            # 讀懂照保守值走時畫面上那一行（3-3 第 12 題，reading.said）
    reply: str = ""           # 讀懂挑的回應哪一個（3-4a，game/replies.py；都不是＝空）
    look: str = ""            # 讀懂挑的在查哪一個（3-4b，darks.clues；都不是＝空）
    deal: str = ""            # 讀懂的買賣找人（3-4c：買、賣、付錢、找人；都不是＝空）
    task: str = ""            # 讀懂挑的在辦哪件請託（3-4b，sides.tasks；都不是＝空）
    past: str = ""            # 讀懂挑的說出前世的事（第 6-6b1 批，rebirths.offers；都不是＝空）
    ploy: str = ""            # 讀懂挑的勢力之間：挑撥、撮合、調停、嫁禍（第 7-3b1b2 批；都不是＝空）
    faction: str = ""         # 讀懂挑的說到哪個勢力
    amount: str = ""          # 讀懂抄的數字（3-5 估價用）
    aim: str = ""             # 3-6a 讀懂的對著什麼、做法、用什麼、主角說的話（沒有、不挑、清單外＝空；舊鏈都空）
    way: str = ""
    tool: str = ""
    speech: str = ""


@dataclass(frozen=True)
class Opponent:
    """對象 NPC 影響成功率的部分。prep：佈局、破境道具算了幾項準備（偷襲在 judge 裡看匿蹤）；breaker：有破境道具；
    awed：你威脅他、他畏懼你（說服 +AWE_BONUS，第 121-10 題）。"""
    realm_lv: int
    affinity: int
    prep: int = 0
    breaker: bool = False
    awed: bool = False


AWE_BONUS = 30


@dataclass(frozen=True)
class Check:
    target: str
    roll: int
    chance: int
    outcome: str
    great_failure: int


@dataclass(frozen=True)
class Judgment:
    """一回合的判定。頂層的 roll／target／outcome 是第一個標的（相容第一階段的欄位與遙測）。"""
    action_type: str
    rolled: bool
    roll: int = 0
    target: int = 0
    outcome: str = ""
    note: str = ""            # 突破：不符合的前提或採用的契機；其他：未能嘗試的原因
    great_failure: int = 0
    difficulty: str = NORMAL
    checks: tuple[Check, ...] = field(default_factory=tuple)
    insight_roll: int = 0     # 脫離瀕死時的頓悟擲骰（預先擲好，effects 保持純函式）
    price: str = ""
    destination: str = ""     # 移動或尋路的目的地
    travel: int = 0           # 抵達要花的時辰
    new_place: bool = False   # 目的地是不是新地點（尋路成功時才登錄）
    spot: bool = False        # 小地方（第 9g 批）：一定抵達
    target_npc: str = ""      # 對象 NPC
    law: str = ""             # 參悟的法則系
    recipe: str = ""          # 煉丹、煉器的產物

    @property
    def is_success(self) -> bool:
        return self.outcome in (GREAT_SUCCESS, SUCCESS)

    @property
    def all_checks(self) -> tuple[Check, ...]:
        """只填了頂層欄位的判定（第一階段的寫法）視為該性質預設標的的一次擲骰。"""
        if self.checks or not self.rolled or self.action_type not in NATURE_TARGETS:
            return self.checks
        return (Check(NATURE_TARGETS[self.action_type][0], self.roll, self.target, self.outcome, self.great_failure),)

    def to_dict(self) -> dict:
        return asdict(self)


# ── 分類 ─────────────────────────────────────────────────────────────────────
def detect(player_input: str) -> Intent | None:
    """關鍵字分類。判斷不出（沒有命中或多個性質衝突）時回傳 None，交給 game 層請 AI 分類。"""
    text = player_input or ""
    for word in _NOT_KEYWORDS:
        text = text.replace(word, "")
    if any(w in text for w in _BREAKTHROUGH_WORDS) and not any(w in text for w in _NOT_BREAKTHROUGH):
        return Intent(BREAKTHROUGH)
    for price, words in _PRICE_WORDS.items():
        if any(w in text for w in words):
            return Intent(PRICE, price=price)
    if any(w in text for w in _ESCAPE_WORDS):
        return Intent(COMBAT, (ESCAPE,))
    if any(w in text for w in _AMBUSH_WORDS):   # 偷襲：先判匿蹤，藏住了命中時境界差少算一級
        return Intent(COMBAT, (HIDE, STRIKE))
    natures = {n for n, words in _STRONG.items() if any(w in text for w in words)}
    if not natures:
        natures = {n for n, words in _WEAK.items() if any(w in text for w in words)}
    if len(natures) == 1:
        return intent_for(natures.pop(), text)
    if frozenset(natures) in _ALLOWED_COMBOS:
        return intent_for(_ALLOWED_COMBOS[frozenset(natures)], text)
    return None


def classify(player_input: str) -> str:
    """只要性質（判斷不出時視為探索）。"""
    intent = detect(player_input)
    return intent.nature if intent else EXPLORE


def intent_for(nature: str, text: str, difficulty: str = NORMAL, source: str = "keyword") -> Intent:
    """給定性質，依第二階段關鍵字挑標的；都沒命中就用預設標的。難度不在清單內視為普通。"""
    candidates = NATURE_TARGETS.get(nature, ())
    picked = [t for t in candidates[1:] if any(w in text for w in _TARGET_WORDS.get(t, ()))]
    if nature == STEALTH:
        picked = [HIDE] + picked              # 潛行一定判匿蹤，有找東西再加判發現
    elif not picked and candidates:
        picked = [candidates[0]]
    return Intent(nature, tuple(picked[:MAX_CHECKS]), difficulty if difficulty in DIFFICULTY else NORMAL, source)


def asking(text: str) -> bool:
    return "？" in text or "?" in text


def chat(intent: Intent, text: str) -> Intent:
    """沒點名的問話、打招呼不判成敗（沒有標的）。點了名或明說要請教、打聽、說服的照常擲骰：
    約定、儀式、同行這些都靠對人交談成功，而且名字裡的字（謝三）不能算成閒聊。"""
    plain = (intent.nature == SOCIAL and not intent.target_npc and PRY not in intent.targets
             and not any(w in text for w in _STRONG[SOCIAL]))
    return replace(intent, targets=()) if plain and any(w in text for w in _CHAT_WORDS) else intent


# ── 成功率與結果 ─────────────────────────────────────────────────────────────
def chance_for(sheet: dict, target: str, difficulty: str = NORMAL, danger: str = "",
               opponent: Opponent | None = None, bonus: dict | None = None) -> int:
    """bonus：符籙與法器的加成（標的 → 點數，第 8 步 items.gear）。"""
    primary, secondary = TARGET_ATTRS[target]
    attrs = sheet["attributes"]
    chance = 50 + (attrs[primary] - 50) // 2 + (attrs[secondary] - 50) // 5 + DIFFICULTY.get(difficulty, 0)
    chance += (bonus or {}).get(target, 0) + status_mod.edge(sheet.get("statuses", []))
    if target in ACTIVE_TARGETS:
        chance += status_mod.penalty(sheet.get("statuses", []))
    if target in DANGER_TARGETS:
        chance += space.danger_modifier(danger)
    if opponent and target in REALM_DIFF_TARGETS:
        chance += npc.realm_diff_modifier(sheet["realm_lv"], opponent.realm_lv, opponent.prep, opponent.breaker)
    if opponent and target in AFFINITY_TARGETS:
        chance += npc.affinity_modifier(opponent.affinity)
    if opponent and opponent.awed and target == PERSUADE:
        chance += AWE_BONUS
    return max(CHANCE_RANGE[0], min(CHANCE_RANGE[1], chance))


def success_target(sheet: dict, nature_or_target: str) -> int:
    """性質（取預設標的）或標的的成功率。"""
    target = NATURE_TARGETS[nature_or_target][0] if nature_or_target in NATURE_TARGETS else nature_or_target
    return chance_for(sheet, target)


def great_failure_chance(chance: int) -> int:
    """成功率 30% 以上固定 5%；越低越高，成功率 5% 時 25%。不與成功區間重疊。"""
    if chance >= RECKLESS_BELOW:
        rate = BASE_GREAT_FAILURE
    else:
        span = RECKLESS_BELOW - CHANCE_RANGE[0]
        rate = BASE_GREAT_FAILURE + round((RECKLESS_BELOW - chance) * (MAX_GREAT_FAILURE - BASE_GREAT_FAILURE) / span)
    return min(rate, 100 - chance)


def roll_check(rng: random.Random, target: str, chance: int) -> Check:
    gf = great_failure_chance(chance)
    roll = rng.randint(1, 100)
    if roll <= chance:
        outcome = GREAT_SUCCESS if roll <= max(1, chance // 10) else SUCCESS
    elif roll > 100 - gf:
        outcome = GREAT_FAILURE
    else:
        outcome = FAILURE
    return Check(target, roll, chance, outcome, gf)


# ── 判定 ─────────────────────────────────────────────────────────────────────
def judge(rng: random.Random, sheet: dict, intent: Intent | str,
          breakthrough_ctx: breakthrough.Context | None = None, danger: str = "",
          opponent: Opponent | None = None, bonus: dict | None = None) -> Judgment:
    """intent 可以直接給玩家輸入（字串），這時用關鍵字分類、判斷不出視為探索。
    danger：所在地的危險度；opponent：對象 NPC 的境界與好感；bonus：符籙與法器的加成。"""
    if isinstance(intent, str):
        intent = detect(intent) or intent_for(EXPLORE, intent, source="default")
    if intent.blocked:
        return Judgment(intent.nature, False, note=intent.blocked, law=intent.law, recipe=intent.recipe)
    dying = sheet.get("status") == "DYING"
    trip = {"destination": intent.destination, "travel": intent.travel, "new_place": intent.new_place, "spot": intent.spot,
            "target_npc": intent.target_npc, "law": intent.law, "recipe": intent.recipe}
    if intent.nature == MOVE:
        return Judgment(MOVE, False, insight_roll=rng.randint(1, 100) if dying else 0, **trip)
    if intent.nature == BREAKTHROUGH:
        if dying:
            return Judgment(BREAKTHROUGH, False, note="瀕死之身，無法衝關")
        return judge_breakthrough(rng, sheet, breakthrough_ctx or breakthrough.Context(clock_now=0))
    if intent.nature == PRICE:
        if not dying:
            return Judgment(PRICE, False, note="只有瀕死時才會以命相搏、付出這種代價")
        return Judgment(PRICE, False, price=intent.price, insight_roll=rng.randint(1, 100))
    if dying and intent.nature in (CULTIVATE, WORK, STUDY, *CRAFTS):
        return Judgment(intent.nature, False, note=f"瀕死之身，無法{intent.nature}", insight_roll=rng.randint(1, 100))
    if intent.nature in (OBSERVE, WORK) or (intent.nature == REST and not dying) or (intent.nature == SOCIAL and not intent.targets):
        return Judgment(intent.nature, False, insight_roll=rng.randint(1, 100) if dying else 0)

    checks = []
    for t in intent.targets[:MAX_CHECKS]:
        foe = opponent
        if foe and t == STRIKE and any(c.target == HIDE and c.outcome in (SUCCESS, GREAT_SUCCESS) for c in checks):
            foe = replace(foe, prep=foe.prep + 1)   # 偷襲：先藏住了，對手沒察覺（16l 第 6-2 題）
        checks.append(roll_check(rng, t, chance_for(sheet, t, intent.difficulty, danger, foe, bonus)))
    checks = tuple(checks)
    first = checks[0]
    return Judgment(intent.nature, True, first.roll, first.chance, first.outcome, great_failure=first.great_failure,
                    difficulty=intent.difficulty, checks=checks, insight_roll=rng.randint(1, 100) if dying else 0,
                    **trip)


def judge_breakthrough(rng: random.Random, sheet: dict, ctx: breakthrough.Context) -> Judgment:
    """前提不符時不擲骰（note 寫明缺什麼）；符合時依 breakthrough.odds 擲 d100。破格期是主動踏入，不擲骰。"""
    if realm.at_gate(sheet["realm_lv"], sheet["stage_index"], sheet["cultivation"]):
        return Judgment(action_type=BREAKTHROUGH, rolled=False, note=realm.GATE_NOTE)
    o = breakthrough.odds(sheet, ctx)
    if not o.ready:
        return Judgment(action_type=BREAKTHROUGH, rolled=False, note="；".join(o.missing))
    roll = rng.randint(1, 100)
    if roll <= o.success:
        outcome = GREAT_SUCCESS if roll <= max(1, o.success // 10) else SUCCESS
    elif roll > 100 - o.great_failure:
        outcome = GREAT_FAILURE
    else:
        outcome = FAILURE
    return Judgment(action_type=BREAKTHROUGH, rolled=True, roll=roll, target=o.success, outcome=outcome,
                    note="、".join(o.opportunities + o.burdens), great_failure=o.great_failure)
