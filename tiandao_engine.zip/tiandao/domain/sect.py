"""宗門本體（2026-10-12，WHITEPAPER 16h 第 1～4、6～8 題；宗門草案第二批）。純函式。

- 入門三條路走同一個考核：上門（宗門、武館地點交談，說要拜入）、事件「開山收徒」「宗門考核」、武館「比武選拔」
  （事件或比武期間在武館戰鬥）。門檻：通緝 2 級以上、沒修為又超過 30 歲、一年內在這裡考過沒上、已經有門派。
  有靈根判定 +10。大成功（比武奪魁）進內門、成功外門、失敗一年內不再收。武館照同一套。
- 入門後：每月月例靈石；住在宗門（不付房租）；得一部本門功法（記在 sect_art）；
  同門好感 +10（角色卡的 sect 存檔時寫成「成員」關係，固定加減在 society.bonus，除名就拿掉）；
  每 180 天要回去一次（淡泊的門風加倍），太久沒回除名；築基升內門、金丹升真傳；提前得知仙宗一層。
- 辭別：在自己門派的地點交談說要辭別，好聚好散。
- 宗規（第三批，條目與輕重在 domain/crime.py）：記過累計 1～3 級，一年降一級；1 級停月例、2 級降一等（外門就除名）、
  3 級除名。要有同門看見（同門在場、人在自己門派的地方，或被害的同門還活著）。
- 叛門（另外判）：輕叛（盜宗門寶物、私投敵派）逐出、永不再收；重叛（殺同門、對宗主長老出手）再加追殺——
  宗門派人找上門（哪裡都可能），十年降一級；被追殺的人打成瀕死就廢掉本門功法。
- 護短的門風：外人打傷它的人，宗門派一個人討公道。
- 角色卡欄位：sect（門派名）、sect_rank、sect_back（上次回去的時間）、sect_bans（門派 → 到何時都不收）、
  sect_art（本門功法）、lore_tier（知道仙宗的哪一層，見 region.SECT_LORE）、
  sect_demerit（{"level", "since"}）、sect_hunt（重叛的追殺：{"hall", "level", "since", "art"（還沒廢的本門功法）}）。
"""
from __future__ import annotations

import random

from . import crime, items, names, newcomer, npc, society
from . import judgment as J
from .clock import SHICHEN_PER_DAY, SHICHEN_PER_YEAR

OUTER, INNER, CORE = "外門", "內門", "真傳"
RANKS = (OUTER, INNER, CORE)
LORD = "宗主"                                 # 仙域裡自己立的宗（16l C5b1）：不會除名、不受門規、不升降
RETIRED = "太上長老"                          # 傳位之後（C5b2）：真傳的月例、不會除名、不升降
PROMOTE = {2: INNER, 3: CORE}               # 境界 → 至少升到哪一級
STIPEND = {OUTER: 5, INNER: 15, CORE: 40}   # 每月月例靈石（暫定）
BACK_DAYS = 180                             # 每隔多久要回去一次（淡泊加倍）
MORTAL_AGE = 30                             # 沒修為的人超過這個歲數不收
ROOT_BONUS = 10                             # 有靈根，考核判定 +10
LORE = {OUTER: 2, CORE: 4}                  # 入門提前一層：外門起知道有上宗、真傳知道上宗是誰（region.SECT_LORE）
HALLS = ("宗門", "武館")                     # 能拜入的勢力
JOIN_WORDS = ("拜入", "拜師", "入門", "拜進", "投入門下", "求入")
LEAVE_WORDS = ("辭別師門", "辭別宗門", "退出師門", "退出宗門", "離開師門", "脫離師門")
EXAMS = ("開山收徒", "宗門考核", "比武選拔")   # 應對成功就入門的事件（domain/incident.py）
TOURNEY = "比武選拔"                         # 期間在武館戰鬥也算考核
MEMBER_BY = "sect"                           # 開世界時生成的成員：NPC 的 created_by
MAX_MEMBERS = {"宗門": 12, "武館": 6}
RECRUIT_CHANCE = 0.6                         # 在宗門、武館登場的新人物加入的機率
ROOMS = {"丹房": J.ALCHEMY, "煉器閣": J.FORGE}   # 本山底下的煉製地點（第 7 題）
ROOM_PATHS = {"丹房": ("丹道",), "煉器閣": ("劍修", "體修")}   # 這些道統一定有；其他道統各五成
ROOM_BONUS = {OUTER: 20, INNER: 25, CORE: 25}
CAST = {   # 開世界時生成的成員：（身分, 年齡層, 實力, 人數）；宗主、館主是首領（第 6 題）
    "宗門": (("宗主", npc.ELDER, npc.POWERFUL, 1), ("長老", npc.ELDER, npc.ADEPT, 2), ("弟子", npc.YOUNG, npc.NOVICE, 3)),
    "武館": (("館主", npc.PRIME, npc.ADEPT, 1), ("弟子", npc.YOUNG, npc.NOVICE, 2)),
}
LEADERS = ("宗主", "館主")
ELDER_LV = 2                                 # 這個境界以上的同門算長老（對他出手＝重叛）
MAX_DEMERIT, MAX_HUNT = 3, 3
HUNT_YEARS = 10                              # 追殺十年降一級
HUNT_CHANCE = {1: 0.1, 2: 0.2, 3: 0.3}       # 每回合被追殺的人找上門的機率
FOREVER = 10 ** 15                           # 叛門：永不再收
HUNTER_BY = "sect_hunter"                    # 宗門派來追殺、討公道的人：NPC 的 created_by


def fields() -> dict:
    return {"sect": "", "sect_rank": "", "sect_back": 0, "sect_bans": {}, "sect_art": "", "lore_tier": 0,
            "sect_demerit": None, "sect_hunt": None}


# ── 開世界：成員與煉製地點 ───────────────────────────────────────────────
def cast(rng: random.Random, halls: list[tuple[str, str]], taken: set[str], land: str = "人族") -> tuple[list[dict], list[dict]]:
    """宗門與武館的成員（年齡層、實力還沒換算成境界，service 寫入時用 npc.roll_profile）與羈絆。
    halls：[(勢力名, 類型)]，勢力的所在地與名字相同。land：這裡是哪一族的地盤。"""
    people, bonds = [], []
    for hall, kind in halls:
        for role, age_band, power, count in CAST[kind]:
            for who in (newcomer.roll(rng, land) for _ in range(count)):
                name = next(iter(names.person_names(rng, taken, 1, **who)), "")
                if not name:
                    continue
                taken.add(name)
                people.append({"name": name, **who, "job": role, "profile": f"{hall}的{role}。", "location": hall, "age_band": age_band,
                               "power_tier": power, "goal": "求道", "goal_target": "",
                               **{t: rng.choice(list(npc.TRAIT_LEVELS.values())) for t in npc.TRAITS}})
                bonds.append(member_bond(name, hall, role in LEADERS))
    return people, bonds


def member_bond(name: str, hall: str, leader: bool = False) -> dict:
    return {"a_kind": society.NPC, "a": name, "b_kind": society.FACTION, "b": hall,
            "type": "首領" if leader else "成員", "clock_shichen": 0, "turn_no": 0}


def rooms(rng: random.Random, path: str) -> list[str]:
    return [room for room, paths in ROOM_PATHS.items() if path in paths or rng.random() < 0.5]


def members(bonds: list[dict], hall: str) -> set[str]:
    return {b["a"] for b in bonds if b["b"] == hall and b["type"] in society.MEMBER_BONDS and b["a_kind"] == society.NPC}


def recruit(rng: random.Random, factions: list[dict], bonds: list[dict], name: str, place: str) -> dict | None:
    """在宗門、武館登場的新人物有六成加入（滿了就不收）。回傳要寫入的羈絆。"""
    hall = hall_at(factions, place)
    if hall is None or len(members(bonds, hall["name"])) >= MAX_MEMBERS[hall["type"]] or rng.random() >= RECRUIT_CHANCE:
        return None
    return member_bond(name, hall["name"])


# ── 入門 ─────────────────────────────────────────────────────────────────
def hall_at(factions: list[dict], place: str) -> dict | None:
    """這裡還在的宗門、武館（散了的不算：同一處可能有後來接手的，第 8-2 丙）。"""
    return next((f for f in factions if f["location"] == place and f["type"] in HALLS and not (f.get("traits") or {}).get("覆滅")), None)


def main_sect(factions: list[dict]) -> dict | None:
    """事件收徒、武館比武挑的是這個世界的本山。"""
    return next((f for f in factions if f["type"] == HALLS[0]), None)


def exam(factions: list[dict], *, place: str, action: str, words: str, last: dict | None, tourney: bool) -> str:
    """這回合是不是在考入門：回傳考哪個門派（空＝不是）。
    last：上一回合的事件紀錄；tourney：此地正在比武選拔。"""
    if last and last.get("name") in EXAMS and action in last.get("answer", ()):
        return (main_sect(factions) or {}).get("name", "")
    if tourney and action == J.COMBAT:
        return (main_sect(factions) or {}).get("name", "")
    hall = hall_at(factions, place)
    return hall["name"] if hall and action == J.SOCIAL and any(w in words for w in JOIN_WORDS) else ""


def problem(sheet: dict, hall: str, clock_now: int, wanted: int) -> str:
    """不收的原因（空字串＝可以考）。wanted：現在的通緝等級。"""
    if sheet["sect"]:
        return f"已經是{sheet['sect']}的弟子"
    if sheet["sect_bans"].get(hall, -1) > clock_now:
        return f"{hall}永不再收你" if sheet["sect_bans"][hall] >= FOREVER else f"{hall}一年內不再收你"
    if wanted >= 2:
        return "通緝在身"
    if sheet["realm_lv"] == 0 and (clock_now - sheet["birth_shichen"]) // SHICHEN_PER_YEAR > MORTAL_AGE:
        return "年紀太大，又沒有修為"
    return ""


def join(rng: random.Random, sheet: dict, hall: str, outcome: str, clock_now: int) -> tuple[dict, list[str]]:
    """考核過了：大成功內門、成功外門；得一部本門功法。回傳（角色卡, 事實）。"""
    rank = INNER if outcome == J.GREAT_SUCCESS else OUTER
    art = items.technique(rng, sheet["realm_lv"])
    sheet, fact = items.grant(rng, sheet, art, sheet["realm_lv"])
    sheet = {**sheet, "sect": hall, "sect_rank": rank, "sect_back": clock_now, "sect_art": art,
             "lore_tier": max(sheet["lore_tier"], LORE[OUTER])}
    return sheet, [f"拜入{hall}，成了{rank}弟子", f"{fact}（本門功法）"]


def fail(sheet: dict, hall: str, clock_now: int) -> dict:
    return {**sheet, "sect_bans": {**sheet["sect_bans"], hall: clock_now + SHICHEN_PER_YEAR}}


def leave(sheet: dict, *, ban_until: int | None = None) -> dict:
    """離開門派（辭別、除名）。ban_until：之後到何時都不收。"""
    bans = sheet["sect_bans"] if ban_until is None else {**sheet["sect_bans"], sheet["sect"]: ban_until}
    return {**sheet, **fields(), "sect_bans": bans, "lore_tier": sheet["lore_tier"],   # 知道的事不會忘
            "sect_hunt": sheet["sect_hunt"]}                                          # 追殺不會因為離開就停


def leaving(sheet: dict, *, place: str, factions: list[dict], action: str, words: str) -> bool:
    """在自己門派的地點交談，說要辭別。"""
    hall = hall_at(factions, place)
    return bool(sheet["sect"]) and hall is not None and hall["name"] == sheet["sect"] and action == J.SOCIAL \
        and any(w in words for w in LEAVE_WORDS)


# ── 入門之後 ─────────────────────────────────────────────────────────────
def style_of(factions: list[dict], hall: str) -> str:
    """門派的門風（武館照所屬本山的；本山就是這個世界唯一的宗門）。"""
    f = next((f for f in factions if f["name"] == hall), None) or {}
    owner = f if f.get("type") == HALLS[0] else main_sect(factions) or {}
    return owner.get("traits", {}).get("門風", "")


def back_days(style: str) -> int:
    return BACK_DAYS * (2 if style == "淡泊" else 1)


def upkeep(sheet: dict, *, months: int, place: str, factions: list[dict], clock_now: int,
           merit_ranks: dict | None = None, lord_pay: int = 0) -> tuple[dict, list[str], bool]:
    """每回合：在門派的地點就算回去過；升等；跨過的月份發月例；太久沒回除名。回傳（角色卡, 事實, 被除名了沒）。
    merit_ranks：仙域的仙宗升等看戰功（等級 → 要幾點，16l C2），不看境界。lord_pay：宗主每月的月例（16l C5b1）。"""
    if not sheet["sect"]:
        return sheet, [], False
    hall = next((f for f in factions if f["name"] == sheet["sect"]), None)
    if hall is None:   # 門派不在了
        return leave(sheet), [f"{sheet['sect']}已經不在了"], False
    facts = []
    if place == hall["location"]:
        sheet = {**sheet, "sect_back": clock_now}
    if sheet["sect_rank"] in (LORD, RETIRED):
        pay = (lord_pay if sheet["sect_rank"] == LORD else STIPEND[CORE]) * months
        return {**sheet, "spirit_stones": sheet["spirit_stones"] + pay}, [f"領了 {pay} 塊靈石月例"] * (pay > 0), False
    if clock_now - sheet["sect_back"] > back_days(style_of(factions, sheet["sect"])) * SHICHEN_PER_DAY:
        return leave(sheet, ban_until=clock_now + SHICHEN_PER_YEAR), [f"太久沒回{sheet['sect']}，被除名了"], True
    rank = (max((r for r, need in merit_ranks.items() if sheet["merit"] >= need), key=RANKS.index, default=OUTER)
            if merit_ranks is not None else
            max((r for lv, r in PROMOTE.items() if sheet["realm_lv"] >= lv), key=RANKS.index, default=OUTER))
    if RANKS.index(rank) > RANKS.index(sheet["sect_rank"]) and demerit(sheet, clock_now) < 2:   # 降等期間不升
        sheet = {**sheet, "sect_rank": rank, "lore_tier": max(sheet["lore_tier"], LORE.get(rank, 0))}
        facts.append(f"升為{sheet['sect']}的{rank}弟子")
    if months > 0 and demerit(sheet, clock_now):
        facts.append("記過在身，月例停發")
    elif months > 0:
        pay = STIPEND[sheet["sect_rank"]] * months
        sheet = {**sheet, "spirit_stones": sheet["spirit_stones"] + pay}
        facts.append(f"領了 {pay} 塊靈石月例")
    return sheet, facts, False


def room_bonus(sheet: dict, craft: str, place: dict) -> int:
    """在自己宗門的丹房煉丹、煉器閣煉器：弟子 +20、內門以上 +25。"""
    ok = sheet["sect"] and ROOMS.get(place.get("type", "")) == craft and place.get("parent") == sheet["sect"]
    return ROOM_BONUS[sheet["sect_rank"]] if ok else 0


def own_room(sheet: dict, place: dict) -> bool:
    """自己宗門的丹房、煉器閣：潛行進去不算闖入。"""
    return bool(sheet["sect"]) and place.get("type") in ROOMS and place.get("parent") == sheet["sect"]


# ── 宗規與叛門（第三批）───────────────────────────────────────────────────
def demerit(sheet: dict, clock_now: int) -> int:
    """現在記過幾級：一年沒事降一級。"""
    d = sheet["sect_demerit"]
    return max(0, d["level"] - (clock_now - d["since"]) // SHICHEN_PER_YEAR) if d else 0


def owner(factions: list[dict], bonds: list[dict], hall: str) -> str:
    """門派所屬的本山（武館從屬本山；本山就是自己）。"""
    up = next((b["b"] for b in bonds if b["a"] == hall and b["type"] == "從屬" and b["a_kind"] == society.FACTION), "")
    f = next((f for f in factions if f["name"] == hall), None) or {}
    return hall if f.get("type") == HALLS[0] or not up else up


def family(factions: list[dict], bonds: list[dict], hall: str) -> set[str]:
    """同一個本山與它旗下的武館（門派名＝所在地名）。"""
    if not hall:
        return set()
    top = owner(factions, bonds, hall)
    return {top} | {b["a"] for b in bonds if b["b"] == top and b["type"] == "從屬" and b["a_kind"] == society.FACTION}


def kin(factions: list[dict], bonds: list[dict], hall: str) -> set[str]:
    """同門：同一個本山與它旗下武館的成員。"""
    return set().union(*(members(bonds, h) for h in family(factions, bonds, hall)))


def enemies(factions: list[dict], bonds: list[dict], hall: str) -> set[str]:
    """跟本山敵對的勢力的成員（跟他們結交到親近＝私投敵派）。"""
    top = owner(factions, bonds, hall)
    foes = {b["a"] if b["b"] == top else b["b"] for b in bonds if b["type"] == "敵對" and top in (b["a"], b["b"])}
    return set().union(*(members(bonds, f) for f in foes))


def elder(person: dict, bonds: list[dict]) -> bool:
    """宗主、館主或長老（境界 ELDER_LV 以上的同門）。"""
    return person["realm_lv"] >= ELDER_LV or any(b["a"] == person["name"] and b["type"] == "首領" for b in bonds)


def offences(*, hit: bool, killed: bool, defending: bool, kin_target: bool, elder_target: bool, cheat: bool,
             loot: bool, national: list[str], disgraced: bool, defected: bool) -> list[str]:
    """這回合犯了哪些宗規、叛門（service 已經看過有沒有同門看見）。national：這回合犯的國法。"""
    found = [crime.KILL_KIN if killed else crime.REBEL if elder_target else crime.HURT_KIN] \
        if hit and kin_target and not defending else []
    return found + [c for c, on in ((crime.CHEAT_KIN, cheat and kin_target), (crime.LOOT, loot),
                                    (crime.SLAUGHTER, crime.KILL in national and not kin_target),
                                    (crime.DARK_ART, crime.DARK in national), (crime.DISGRACE, disgraced),
                                    (crime.DEFECT, defected)) if on]


def punish(sheet: dict, found: list[str], traits: list, clock_now: int) -> tuple[dict, list[str], str]:
    """照宗規、叛門罰。回傳（角色卡, 事實, 結果：""、"除名"、"輕叛"、"重叛"）。traits：本山的道統與門風。"""
    hall = sheet["sect"]
    if sheet["sect_rank"] == LORD:   # 宗主不受自家門規（16l C5b1）
        return sheet, [], ""
    treason = max((crime.code(traits, crime.TREASON, crime.HEAVY)[c] for c in found if c in crime.TREASON), default=0)
    if treason:
        heavy = treason >= crime.HEAVY
        hunt = {"hall": hall, "level": MAX_HUNT, "since": clock_now, "art": sheet["sect_art"]} if heavy else None
        sheet = {**leave(sheet, ban_until=FOREVER), "sect_hunt": hunt or sheet["sect_hunt"]}
        return sheet, [f"犯了{'、'.join(c for c in found if c in crime.TREASON)}，"
                       + (f"被{hall}視為叛徒，派人追殺" if heavy else f"被{hall}逐出門牆，永不再收")], \
            "重叛" if heavy else "輕叛"
    rules = crime.code(traits, crime.SECT_RULES, MAX_DEMERIT)
    broke = [c for c in found if rules.get(c)]
    if not broke:
        return sheet, [], ""
    return mark(sheet, sum(rules[c] for c in broke), f"犯了{hall}的門規（{'、'.join(broke)}）", clock_now)


def mark(sheet: dict, n: int, why: str, clock_now: int) -> tuple[dict, list[str], str]:
    """記過 n 級：滿了除名、剛到 2 級降一級（外門直接除名）。回傳（角色卡, 事實, ""或"除名"）。"""
    hall, before = sheet["sect"], demerit(sheet, clock_now)
    lv = min(MAX_DEMERIT, before + n)
    sheet = {**sheet, "sect_demerit": {"level": lv, "since": clock_now}}
    facts = [f"{why}，記過 {lv} 級"]
    if lv >= MAX_DEMERIT or (lv >= 2 > before and sheet["sect_rank"] == OUTER):
        return leave(sheet, ban_until=clock_now + SHICHEN_PER_YEAR), facts + [f"被{hall}除名"], "除名"
    if lv >= 2 > before and sheet["sect_rank"] in RANKS:
        sheet = {**sheet, "sect_rank": RANKS[RANKS.index(sheet["sect_rank"]) - 1]}
        facts.append(f"降為{sheet['sect_rank']}弟子")
    return sheet, facts, ""


def hunt_level(sheet: dict, clock_now: int) -> int:
    h = sheet["sect_hunt"]
    return max(0, h["level"] - (clock_now - h["since"]) // (HUNT_YEARS * SHICHEN_PER_YEAR)) if h else 0


def hunted(rng: random.Random, sheet: dict, clock_now: int) -> str:
    """這回合宗門派的人找不找上門：回傳哪個門派（空＝沒有）。"""
    lv = hunt_level(sheet, clock_now)
    return sheet["sect_hunt"]["hall"] if lv and rng.random() < HUNT_CHANCE[lv] else ""


def cripple(sheet: dict) -> tuple[dict, str]:
    """被追殺的人打成瀕死：廢掉本門功法（背包裡的、正在主修的）。只廢一次。"""
    art = (sheet["sect_hunt"] or {}).get("art", "")
    if not art:
        return sheet, ""
    return ({**sheet, "items": [e for e in sheet["items"] if e["name"] != art],
             "technique": items.BASIC_TECHNIQUE if sheet["technique"] == art else sheet["technique"],
             "sect_hunt": {**sheet["sect_hunt"], "art": ""}}, f"被{sheet['sect_hunt']['hall']}的人廢去了《{art}》")


def protected(factions: list[dict], bonds: list[dict], person: str, own: str) -> str:
    """打傷的人屬於護短的門派（不是自己的）：回傳要派人討公道的門派。"""
    hall = next((b["b"] for b in bonds if b["a"] == person and b["type"] in society.MEMBER_BONDS
                 and b["b_kind"] == society.FACTION), "")
    if not hall or (own and owner(factions, bonds, own) == owner(factions, bonds, hall)):
        return ""
    return hall if style_of(factions, hall) == "護短" else ""


# ── 畫面與說書人 ─────────────────────────────────────────────────────────
def text(sheet: dict, factions: list[dict], clock_now: int) -> str:
    """給說書人的【師門】：門派、等級、道統與門風各一句、多久要回去。"""
    if not sheet["sect"]:
        return ""
    f = next((f for f in factions if f["name"] == sheet["sect"]), None) or {}
    owner = f if f.get("type") == HALLS[0] else main_sect(factions) or {}
    traits = "；".join(f"{t.name}（{t.line}）" for t in crime.traits_of(owner))
    left = back_days(style_of(factions, sheet["sect"])) - (clock_now - sheet["sect_back"]) // SHICHEN_PER_DAY
    marks = demerit(sheet, clock_now)
    if sheet["sect_rank"] == LORD:
        return f"主角是{sheet['sect']}的宗主" + (f"；{traits}" if traits else "")
    return (f"主角是{title(sheet)}" + (f"；{traits}" if traits else "")
            + (f"；記過 {marks} 級" if marks else "") + f"；{left} 天內要回{sheet['sect']}一次，否則除名")


def title(sheet: dict) -> str:
    """某宗的宗主、某宗的內門弟子。"""
    return f"{sheet['sect']}的{sheet['sect_rank']}" + ("" if sheet["sect_rank"] in (LORD, RETIRED) else "弟子")


def hunt_text(sheet: dict, clock_now: int) -> str:
    """給說書人：叛出的門派還在追殺主角。"""
    return f"主角叛出了{sheet['sect_hunt']['hall']}，被宗門派人追殺" if hunt_level(sheet, clock_now) else ""


def panel(sheet: dict, factions: list[dict], clock_now: int) -> dict:
    hunt = sheet["sect_hunt"]["hall"] if hunt_level(sheet, clock_now) else ""
    if not sheet["sect"]:
        return {"sect": "", "sectRank": "", "sectDays": 0, "sectDemerit": 0, "sectHunt": hunt}
    left = back_days(style_of(factions, sheet["sect"])) - (clock_now - sheet["sect_back"]) // SHICHEN_PER_DAY
    return {"sect": sheet["sect"], "sectRank": sheet["sect_rank"], "sectDays": left,
            "sectDemerit": demerit(sheet, clock_now), "sectHunt": hunt}


def valid(sheet: dict) -> bool:
    bans, d, h = sheet["sect_bans"], sheet["sect_demerit"], sheet["sect_hunt"]
    return (isinstance(sheet["sect"], str) and (sheet["sect_rank"] in (*RANKS, LORD, RETIRED)) == bool(sheet["sect"])
            and sheet["sect_rank"] in ("", *RANKS, LORD, RETIRED) and isinstance(sheet["sect_back"], int)
            and isinstance(sheet["sect_art"], str) and sheet["lore_tier"] in (0, *LORE.values())
            and isinstance(bans, dict) and all(isinstance(k, str) and isinstance(v, int) for k, v in bans.items())
            and (d is None or isinstance(d, dict) and set(d) == {"level", "since"}
                 and all(isinstance(v, int) for v in d.values()) and 0 <= d["level"] <= MAX_DEMERIT)
            and (h is None or isinstance(h, dict) and set(h) == {"hall", "level", "since", "art"}
                 and isinstance(h["hall"], str) and isinstance(h["art"], str)
                 and isinstance(h["level"], int) and isinstance(h["since"], int) and 0 <= h["level"] <= MAX_HUNT))
