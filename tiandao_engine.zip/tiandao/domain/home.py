"""主角的落腳處與家人（2026-10-07，WHITEPAPER 第 16d 節「家級的地方從哪裡來」第 3～7 題）。純函式，不碰資料庫。

- 建角三題：落腳處（老家／租的房）、家裡有誰、家運；玩家指定優先，沒指定就隨機（同出身）。
  租的房只在城鎮、村落；出生在荒野只有老家（山裡的小屋）。租的房沒有家人登錄。
- 落腳處＝出生地底下的家級子地點（類型住家），主角從這裡開場。名字不用主角的名字：一生結束後不必改名
  （改地名會牽動遺物、傳聞、記事）；舊居留在地圖上。
- 家人登錄成凡人 NPC（目標守護主角），跟主角這一生是親人（固定 +60）；起始關係看家運（數字暫定）。兄弟姊妹先不做（可能未成年）。
- 房租（經濟第二輪）：租的房每月付凡人錢，付不出來記欠，欠滿三個月被趕走。
"""
from __future__ import annotations

import random

from ..errors import BadRequest, text_field
from . import era, lineage, names, npc, opinion, races, society, talk
from .clock import SHICHEN_PER_YEAR

OLD_HOME, RENTED = "老家", "租的房"
KINDS = (OLD_HOME, RENTED)
FAMILIES = {"雙親": ("父親", "母親"), "只有父親": ("父親",), "只有母親": ("母親",), "養父母": ("養父", "養母"), "無父無母": ()}
FORTUNES = {   # 家運 → (好感, 信任, 舊怨, 給說書人的一句, 隨機的權重)
    "和睦": (60, 70, "", "家人和樂，彼此疼惜", 3), "平淡": (20, 40, "", "家人之間不冷不熱", 3),
    "疏離": (0, 10, "", "和家人很少說話，各過各的", 1.5), "不和": (-30, 0, "", "和家人常起爭執，互相提防", 1.5),
    "虧欠": (-60, 0, "舊怨", "和家人之間有一筆算不清的舊帳", 1)}
RENT_TYPES = ("城鎮", "村落")
RENT = {"城鎮": 30, "村落": 10}   # 每月房租（凡人錢，經濟第二輪 WHITEPAPER 16.1 第 3 題，暫定）
EVICT_MONTHS = 3                  # 欠滿幾個月被房東趕走
SPOTS = ("", "東頭", "西頭", "南邊", "北邊", "坡上", "河邊")   # 同一個地方第二間起冠上方位
PARENT_YEARS = (18, 40)   # 家人比主角大幾歲
FAMILY_BY = "family"      # NPC 的 created_by：建角時登錄的家人
# 姓氏來歷（16u 第 2 題）：家裡有誰 → 可選的來歷；隨機的權重（暫定）；誰和主角同姓；給說書人的一句
SOURCES = {"雙親": ("隨父", "隨母"), "只有父親": ("隨父",), "只有母親": ("隨母",), "養父母": ("養父給的", "留本姓")}
SOURCE_ODDS = {"隨父": 9, "隨母": 1, "養父給的": 6, "留本姓": 4}
CARRIER = {"隨父": "父親", "隨母": "母親", "養父給的": "養父"}
SOURCE_NOTES = {"隨母": "隨母姓（父親入贅）", "養父給的": "這個姓是養父給的", "留本姓": "留著本姓，和養父母不同姓"}
MAX_SURNAME = 4


def fields() -> dict:
    """rent：每月房租（0＝不用付）；owed：欠了多少房租。surname：姓或氏（魔族沒有）；surname_from：姓氏來歷。"""
    return {"home": "", "home_kind": "", "family": "", "fortune": "", "rent": 0, "owed": 0, "surname": "", "surname_from": ""}


def surname(sheet: dict, chosen) -> dict:
    """建角：定主角的姓。"""
    chosen = text_field(chosen, "姓", "invalid_surname")
    if len(chosen) > MAX_SURNAME or not names.is_chinese(chosen):
        raise BadRequest(f"姓要是中文，最多 {MAX_SURNAME} 個字。", code="invalid_surname")
    return {**sheet, "surname": names.surname_of(sheet["name"], chosen, sheet["race"])}


def source(rng: random.Random, sheet: dict, chosen, land: str) -> dict:
    """建角：定姓氏來歷。選的和家裡有誰對不上就隨機；當地是魔族時養父沒有姓可給。"""
    chosen = text_field(chosen, "姓氏來歷", "invalid_surname")
    if chosen and chosen not in SOURCE_ODDS:
        raise BadRequest("姓氏來歷只能從選項裡挑。", code="invalid_surname")
    fit = [s for s in SOURCES.get(sheet["family"], ()) if s != "養父給的" or names.has_family(land)]
    if not sheet["surname"] or not fit:
        return sheet
    return {**sheet, "surname_from": chosen if chosen in fit else rng.choices(fit, [SOURCE_ODDS[s] for s in fit])[0]}


def assign(rng: random.Random, sheet: dict, *, kind, family, fortune, place_type: str, boost: dict | None = None) -> dict:
    """建角時定落腳處、家裡有誰、家運（落腳處的地名由 place_name 另外定）。boost：命途讓某些家運比較容易擲到（16g）。"""
    kind, family, fortune = (text_field(v, label, "invalid_home") for v, label in
                             ((kind, "落腳處"), (family, "家裡有誰"), (fortune, "家運")))
    if kind and kind not in KINDS or family and family not in FAMILIES or fortune and fortune not in FORTUNES:
        raise BadRequest("落腳處、家裡有誰、家運只能從選項裡挑。", code="invalid_home")
    if kind == RENTED and place_type not in RENT_TYPES:
        raise BadRequest("租的房只在城鎮、村落；出生在荒野只有老家。", code="invalid_home")
    kind = kind or (rng.choice(KINDS) if place_type in RENT_TYPES else OLD_HOME)
    if kind == RENTED:
        return {**sheet, "home_kind": kind, "family": "", "fortune": "", "rent": RENT[place_type]}
    family, picks = family or rng.choice(list(FAMILIES)), list(FORTUNES)
    weights = [FORTUNES[f][4] * (boost or {}).get(f, 1) for f in picks]
    fortune = "" if not FAMILIES[family] else fortune or rng.choices(picks, weights=weights)[0]
    return {**sheet, "home_kind": kind, "family": family, "fortune": fortune}   # 無父無母沒有家運


def place_name(sheet: dict, birthplace: str, place_type: str, taken: set[str], era_now: str = era.ANCIENT) -> str:
    """落腳處的地名：「青石鎮的老屋」「槐樹村東頭的賃屋」（現代是老公寓、租屋，第 16e 節）；
    都被用掉了回傳空字串（不登錄落腳處）。去掉「的」就撞名的也跳過（「柳樹屯老屋」已是暗線苦主家，away 警告第 2 條）。"""
    noun = era.rename("小屋" if place_type == "荒野" else "老屋" if sheet["home_kind"] == OLD_HOME else "賃屋",
                      era.ANCIENT, era_now)
    return next((n for n in (f"{birthplace}{s}的{noun}" for s in SPOTS) if not {n, n.replace("的", "")} & taken and len(n) <= 12), "")


def parents(rng: random.Random, sheet: dict, *, clock_now: int, taken: set[str], land: str = races.HUMAN,
            town: str = "") -> list[dict]:
    """家人（repos.insert_npc 的欄位）。家人配合主角的姓：姓氏來歷指到的人同姓，其他人另外擲（16u 第 2 題）。
    親生的和主角同族同支系，養父母是當地那一族（16u 第 4 題）。"""
    carrier, mine = CARRIER.get(sheet["surname_from"], ""), sheet["surname"]
    out = []
    for role in FAMILIES.get(sheet["family"], ()):
        gender = "男" if role in ("父親", "養父") else "女"
        race, line = (land, lineage.local(rng, land, town)) if role.startswith("養") else (sheet["race"], sheet["lineage"])
        family_name = mine if role == carrier else next(
            (f for f in (names.family(rng, race, line) for _ in range(20)) if not f or f != mine), "")
        name = next((n for n in (family_name + names.given(rng, race, gender) for _ in range(20)) if n not in taken), "")
        if not name:
            continue
        taken.add(name)
        birth = sheet["birth_shichen"] - rng.randint(*PARENT_YEARS) * SHICHEN_PER_YEAR
        out.append({"name": name, "appearance": "", "profile": f"{sheet['name']}的{role}。", "location": sheet["home"],
                    "status": "ALIVE", "ai_driven": True, "created_by": FAMILY_BY, "race": race, "lineage": line,
                    "gender": gender, "birth_shichen": birth,
                    "job": talk.ORIGIN_JOB.get(sheet.get("origin"), ""), "profile_age": (clock_now - birth) // SHICHEN_PER_YEAR, "goal": "守護", "goal_target": sheet["name"],
                    **{t: rng.choice(list(npc.TRAIT_LEVELS.values())) for t in npc.TRAITS},
                    "evolved_shichen": clock_now, "first_seen_turn": 0})
    return out


def relation(sheet: dict) -> tuple[list, str]:
    """家人對主角的起點（看家運）：不淡的「家運」兩筆，好感記跟親人固定 +60 差多少（和睦不記）、信任照家運；舊怨。"""
    affinity, trust, grudge, _, _ = FORTUNES[sheet["fortune"]]
    hits = [(opinion.HOME, opinion.LIKE, opinion.GRAVE, affinity - society.BONUS["親人"]),
            (opinion.HOME, opinion.TRUST, opinion.GRAVE, trust)]
    return [h for h in hits if h[3]], grudge


def ties(people: list[dict], life: str, clock_now: int) -> list[dict]:
    """雙親、養父母之間是伴侶；家人跟主角這一生是親人（第 1-3b 批）。"""
    kin = [p["name"] for p in people if p["created_by"] == FAMILY_BY]
    def tie(a, b_kind, b, type_):
        return {"a_kind": society.NPC, "a": a, "b_kind": b_kind, "b": b, "type": type_, "clock_shichen": clock_now, "turn_no": 0}
    couple = [tie(kin[0], society.NPC, kin[1], "伴侶")] if len(kin) == 2 else []
    return couple + [tie(n, society.PLAYER, life, "親人") for n in kin]


def prompt_line(sheet: dict) -> str:
    """給說書人的【落腳處】：住哪、家裡有誰、家運（開場照著寫背景）。"""
    if not sheet.get("home") or not sheet["home_kind"]:   # 奴隸住主人家（16k，寫在身分那一行）
        return ""
    if sheet["home_kind"] == RENTED:
        return f"住在{sheet['home']}（自己租的房）"
    roles = FAMILIES[sheet["family"]]
    if not roles:
        return f"住在{sheet['home']}（老家）；無父無母，守著父母留下的老屋"
    note = SOURCE_NOTES.get(sheet["surname_from"], "")
    return f"住在{sheet['home']}（老家）；家裡有{'、'.join(roles)}；{FORTUNES[sheet['fortune']][3]}" + (f"；{note}" if note else "")


def pay_rent(sheet: dict, months: int, money_name: str = "銀兩") -> tuple[dict, list[str]]:
    """過了幾個月就付幾個月的房租（先還欠的）；付不出來記欠，欠滿 EVICT_MONTHS 個月被趕走（落腳處清空）。
    回傳（角色卡, 事件）。"""
    if not sheet["rent"] or not sheet["home"] or months <= 0:
        return sheet, []
    due = sheet["owed"] + sheet["rent"] * months
    paid = min(sheet["money"], due)
    sheet = {**sheet, "money": sheet["money"] - paid, "owed": due - paid}
    if sheet["owed"] >= sheet["rent"] * EVICT_MONTHS:
        return ({**sheet, "home": "", "home_kind": "", "rent": 0, "owed": 0},
                [f"欠了 {due - paid} {money_name}房租，被房東趕出了{sheet['home']}"])
    return sheet, [f"付了 {paid} {money_name}房租"] + ([f"還欠房東 {sheet['owed']} {money_name}"] if sheet["owed"] else [])


def valid(sheet: dict) -> bool:
    return (isinstance(sheet["home"], str) and len(sheet["home"]) <= 40 and sheet["home_kind"] in ("", *KINDS)
            and isinstance(sheet["rent"], int) and isinstance(sheet["owed"], int) and 0 <= sheet["owed"]
            and (sheet["rent"] > 0) == (sheet["home_kind"] == RENTED)
            and sheet["family"] in ("", *FAMILIES) and sheet["fortune"] in ("", *FORTUNES)
            and isinstance(sheet["surname"], str) and len(sheet["surname"]) <= MAX_SURNAME
            and sheet["surname_from"] in ("", *SOURCE_ODDS)
            and (sheet["fortune"] == "" or bool(FAMILIES.get(sheet["family"]))))   # 有家人才有家運
