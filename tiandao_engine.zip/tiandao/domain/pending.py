"""等你處理的事（WHITEPAPER 第 119-1、120-7 ② 題，實作第 1-6 批）：回音、請託、風聲、暗線、破格倒數從角色卡搬進帳。

- 一件一列（ledger）：種類、甲＝誰（沒有人是空字串）、乙＝那一生、在等什麼（第 117-2 題五種）、期限、狀態、內容（body＝原本那一件）。
- 只換存取層：存角色卡時拆出來（split），讀的時候組回角色卡（join），各模組照舊讀 sheet["echoes"] 這些欄位。
- 等太久怎麼收照舊各模組自己的規則；期限欄：風聲、破格、回音（第 2-2 批：等不到的期限，債上門是債的到期）。
"""
from __future__ import annotations

from . import breach, society

ECHO, ASK, LEAD, DARK, BREACH = "回音", "請託", "風聲", "暗線", "破格"
NOW, THERE, PERSON, DUE, NEWS = "只限這回合", "等你到那裡", "等那個人", "有期限", "世界消息"   # 第 117-2 題
FIELDS = {"echoes": (ECHO, PERSON, True), "asking": (ASK, DUE, False), "leads": (LEAD, NEWS, True),
          "dark": (DARK, THERE, False), "breach": (BREACH, DUE, False)}   # 角色卡欄位 →（種類, 在等什麼, 是不是清單）
KINDS = tuple(k for k, _, _ in FIELDS.values())


def _row(kind: str, wait: str, x: dict, life: str, now: int) -> dict:
    who = x.get("who", "") if kind in (ECHO, ASK) else x.get("by", "") if kind == DARK else ""
    due = breach.deadline({"breach": x}) if kind == BREACH else x.get("due", x["until"]) if kind in (LEAD, ECHO) else None   # 回音的期限（第 2-2 批）
    return {**society.owed(kind, who, life, now), "session_id": life, "waiting": wait, "deadline_shichen": due, "body": x}


def split(sheet: dict, life: str, now: int) -> tuple[dict, list[dict]]:
    """角色卡 →（拿掉這五個欄位的角色卡, 帳上的列）。"""
    rows = [_row(kind, wait, x, life, now) for f, (kind, wait, many) in FIELDS.items() if f in sheet
            for x in (sheet[f] if many else [sheet[f]] if sheet[f] else [])]
    return {k: v for k, v in sheet.items() if k not in FIELDS}, rows


def join(sheet: dict, rows: list[dict]) -> dict:
    """帳上的列（照寫入的順序）組回角色卡；角色卡裡還有這個欄位的（第 1-6 批之前存的）照舊。"""
    out = dict(sheet)
    for f, (kind, _, many) in FIELDS.items():
        if f not in out:
            got = [r["body"] for r in rows if r["kind"] == kind]
            out[f] = got if many else got[0] if got else None
    return out
