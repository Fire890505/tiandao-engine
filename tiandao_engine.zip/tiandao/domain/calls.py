"""Claude 出題、程式出數（Claude主導盤點第六節第 8～10 題，第九節 4a）。純函式。

第一段每個判定寫：擲不擲、擋在前面的、靠哪兩個數值、專長、有利／不利（點事實編號）、成功和失敗各會怎樣（動作表 acts）。
- 驗（problem）：擋的、點的事實、專長都要在清單上；後果過 acts.problem；失敗至少一項代價。
- 一定擲（forced，第 9 題）：擋的是人、帳上有危險。突破、修煉、煉製這類系統行動不走這裡（照原系統）。
- 算（chance）：數值底（同 judgment.chance_for：主 ÷2、次 ÷5）＋點的事實各 ±10（情境算一條，佔名額）＋專長 +10
  ＋靠學識每高識字一級 +10 ＋帳上自動項（game 層算好給 auto：狀態、危險度、境界差、好感、法器、法則……），夾 5～95。
- 後果（results）：照擲出來的結果挑成功或失敗那組；大成功、大失敗升一級；沒危險最多中（acts.cap）。
"""
from __future__ import annotations

from dataclasses import dataclass

import random

from . import acts, judgment as J, learn, npc, space, status as status_mod
from .acts import Act
from .judgment import CHANCE_RANGE, GREAT_FAILURE, GREAT_SUCCESS, SUCCESS

ATTRS = {"體魄": "physique", "悟性": "wisdom", "根骨": "root_bone", "感知": "perception", "魅力": "charisma"}
ROLL, SURE, NOPE = WAYS = ("擲", "直接成", "直接不成")
SCENE, SELF, NONE, LEAN = "環境", "自己", "沒有", "情境"
FACT, FACTS_MAX, KNACK = 10, 2, learn.STEP
BODY = ("physique", "root_bone", "perception")   # 主數值是這幾個：擋的人看境界差；其他看好感
SYSTEM = (J.BREAKTHROUGH, J.PRICE, J.CULTIVATE, J.STUDY, J.WORK, J.REST, J.MOVE, *J.CRAFTS)   # 有自己算法的，照原系統（第 9 題）
OLD = SYSTEM   # 照原本的判定（對亡者、怪談動手也照舊：haunts.fight、領域脫身看打擊、脫身那一擲，game 層另外擋）


@dataclass(frozen=True)
class Call:
    what: str                 # 這一擲在做什麼（寫進判定紀錄）
    roll: str = ROLL
    against: str = SCENE
    main: str = "體魄"
    second: str = "感知"
    knack: str = NONE
    lore: bool = False        # 靠學識
    good: tuple = ()          # 事實編號或「情境」
    bad: tuple = ()
    why: str = ""             # 情境理由
    win: tuple = ()           # 成功的後果（Act）
    lose: tuple = ()


def problem(c: Call, *, facts: int, present: set[str], things: set[str], knacks: set[str],
            carried: set[str] = frozenset()) -> str:
    """擋下的原因（空字串＝可以）。facts：事實有幾條；things：登錄過的東西（環境物）。"""
    marks = [x for x in (*c.good, *c.bad) if x != LEAN]
    why = next((acts.problem(a, carried=carried, present=present) for a in (*c.win, *c.lose)
                if acts.problem(a, carried=carried, present=present)), "")
    return ("擲不擲不在清單裡" if c.roll not in WAYS
            else "擋的不在清單裡" if c.against not in present | things | {SCENE, SELF}
            else "靠什麼不是那五個數值" if c.main not in ATTRS or c.second not in ATTRS
            else "主角沒有這個專長" if c.knack not in knacks | {NONE}
            else f"有利、不利各最多 {FACTS_MAX} 條" if len(c.good) > FACTS_MAX or len(c.bad) > FACTS_MAX
            else "點的事實不在清單裡" if not all(x.isdigit() and 0 < int(x) <= facts for x in marks)
            else "用了情境要寫理由" if LEAN in (*c.good, *c.bad) and not c.why
            else "失敗至少要有一項代價" if c.roll != SURE and not c.lose
            else why)


def forced(c: Call, *, present: set[str], danger: bool) -> bool:
    """第 9 題：擋的是人、帳上有危險，程式一定擲。"""
    return c.against in present or danger


def chance(sheet: dict, c: Call, *, auto: int = 0) -> int:
    a = sheet["attributes"]
    base = 50 + (a[ATTRS[c.main]] - 50) // 2 + (a[ATTRS[c.second]] - 50) // 5
    base += FACT * (len(c.good) - len(c.bad)) + KNACK * (c.knack != NONE)
    base += (learn.level(sheet) - learn.READ) * learn.STEP if c.lore else 0
    return max(CHANCE_RANGE[0], min(CHANCE_RANGE[1], base + auto))


def auto(sheet: dict, c: Call, *, danger: str = "", foes: dict | None = None, extra: int = 0) -> int:
    """帳上自動算的項（第 10 題：點了也不重複加）：狀態、所在地危險度；擋的是人時，主數值是身手（BODY）看境界差，
    其他看好感（他畏懼你、主魅力再加）。extra：game 層算好的其他加成（法則、天氣、道統、命途……）。"""
    st, body = sheet.get("statuses", []), ATTRS[c.main] in BODY
    pts = extra + status_mod.edge(st) + (status_mod.penalty(st) if body else 0) + space.danger_modifier(danger)
    foe = (foes or {}).get(c.against)
    if foe and body:
        pts += npc.realm_diff_modifier(sheet["realm_lv"], foe.realm_lv, foe.prep, foe.breaker)
    elif foe:
        pts += npc.affinity_modifier(foe.affinity) + J.AWE_BONUS * (foe.awed and c.main == "魅力")
    return pts


def judge(rng: random.Random, sheet: dict, intent: J.Intent, *, present: set[str], danger: bool, place_danger: str = "",
          foes: dict | None = None, extra: int = 0) -> J.Judgment:
    """照 Claude 出的題擲（intent.calls 已經過 problem）：要擲的擲，直接成的記成功那組，直接不成的不記後果。"""
    checks, done, nope = [], [], []
    for c in intent.calls:
        if c.roll == ROLL or forced(c, present=present, danger=danger):
            check = J.roll_check(rng, c.what, chance(sheet, c, auto=auto(sheet, c, danger=place_danger, foes=foes, extra=extra)))
            checks.append(check)
            done += results(c, check.outcome, danger=danger)
        elif c.roll == SURE:
            done += results(c, SUCCESS, danger=danger)
        else:
            nope.append(c.what)
    first = checks[0] if checks else J.Check("", 0, 0, "", 0)
    lean = "；".join(f"{c.what}：{c.why}" for c in intent.calls if c.why)
    return J.Judgment(intent.nature, bool(checks), first.roll, first.chance, first.outcome, great_failure=first.great_failure,
                      checks=tuple(checks), note="" if checks or not nope else f"{'、'.join(nope)}做不到",
                      destination=intent.destination, travel=intent.travel, new_place=intent.new_place, spot=intent.spot,
                      target_npc=intent.target_npc, lean=lean, declared=True, acts=tuple(done))


def hits(v: J.Judgment, name: str) -> list[tuple[str, str]]:
    """出題時給 npc.consequences 的（標的, 結果）：寫了「在場的人：受傷」照命中的成功、大成功算；動了手沒傷到算命中失敗（照樣記仇）。"""
    hurt = next((a for a in v.acts if (a.kind, a.way, a.name) == (acts.CAST, "受傷", name)), None)
    return [("命中", acts.HURT_STEPS[hurt.level])] if hurt else [("命中", J.FAILURE)] if v.action_type == J.COMBAT else []


def struck(v: J.Judgment) -> bool:
    """這回合有沒有對人出手（殺人傷人罪、誰知道、誰殺了主角看這個）：照標的的有打擊那一擲，出題的是戰鬥。"""
    return any(c.target == J.STRIKE for c in v.all_checks) or (v.declared and v.action_type == J.COMBAT)


def results(c: Call, outcome: str, *, danger: bool) -> tuple[Act, ...]:
    """這個結果要記的後果：成功那組或失敗那組，大成功大失敗升一級，再照危險封頂。"""
    pick = c.win if outcome in (GREAT_SUCCESS, SUCCESS) else c.lose
    big = outcome in (GREAT_SUCCESS, GREAT_FAILURE)
    level = lambda a: acts.up(a.level) if big else a.level   # noqa: E731
    return tuple(Act(a.kind, acts.cap(level(a), danger) if a.kind in acts.CAPPED else level(a), a.way, a.name) for a in pick)
