"""仙域名冊（16l 第 15 題丁；草稿 C0）：仙宗的人不先建成 NPC，見面才成形。純函式。

規則（2026-10-17 與使用者一題一題定案，見 progress/WHITEPAPER.md 16l，數字暫定）：
- 每個仙宗只存 roster [起, 迄]：活著的是第幾號到第幾號。第 i 號的名字、境界、出身、性格用「仙域種子＋宗名＋i」推算，
  每次推出來都一樣。長度＝實力 // PER_POWER；百日演進實力掉了起點後移（戰死）、漲了終點後移（招新）。
- 下界 NPC 破空不論有沒有關係都記進 ascended（名字＋原世界＋上宗，沒宗門的上宗空＝散仙），成形時從原世界搬。
- 滅宗：名冊一半戰死、一半（雙號）流落成散仙，記進 loose；飛升上來的也一樣，單數位置的戰死。
- 仙戰（C4b）：散仙名單的那一筆記上 to（收走他的仙宗），抽人時算那個仙宗的；那個仙宗覆滅就又是散仙。
- 宗主、長老用負號（C3a：不佔名冊，小宗才不會被抽完）；名冊抽完了往後的號碼當新面孔。
- 成形：先挑飛升上來的（有真實來歷），再挑名冊號碼；名字已經在仙域裡、或跟飛升上來的人同名的跳過（已經成形或撞名）。
"""
from __future__ import annotations

import random

from . import names, newcomer, npc, realm
from .clock import SHICHEN_PER_YEAR

PER_POWER = 10
LEADERS = ("宗主", "長老", "長老")   # 仙宗第一次有人到的時候就成形；之後首領的繼任照背景演化
MEMBER = "弟子"
LOOSE = "散仙"
LV = {"宗主": 8, "長老": 7, MEMBER: 7, LOOSE: 7}
LOST_WORLD = "已湮滅的下界"   # 沒有下宗的仙宗，推算出來的人出身寫這個
MAX_LOOSE = 60
EXTRA = 50


def span(sect: dict) -> list[int]:
    """活著的號碼範圍；還沒擲過百日演進的仙宗照實力從 0 號起算。"""
    return sect.get("roster") or [0, sect["power"] // PER_POWER]


def resize(sect: dict) -> dict:
    lo, hi = span(sect)
    n = sect["power"] // PER_POWER
    return {**sect, "roster": [hi - n, hi] if hi - lo > n else [lo, lo + n]}


def scatter(realm_: dict, dead: list[dict]) -> dict:
    """滅宗：名冊雙號、飛升上來的雙數位置流落成散仙，其他戰死。"""
    gone = {s["name"] for s in dead}
    loose = [{"sect": s["name"], "i": i} for s in dead for i in range(*span(s)) if i % 2 == 0]
    kept, k = [], 0
    for a in realm_.get("ascended", []):
        if a["sect"] in gone:
            kept += [{**a, "sect": ""}] if k % 2 == 0 else []
            k += 1
        else:
            kept.append(a)
    back = [{"sect": x["sect"], "i": x["i"]} if x.get("to") in gone else x for x in realm_.get("loose", [])]
    return {**realm_, "loose": (back + loose)[-MAX_LOOSE:], "ascended": kept}


def enlist(realm_: dict, rng: random.Random, sects: list[str], n: int) -> tuple[dict, list[str]]:
    """散仙名單裡還沒入宗的 n 個人被這些仙宗收走（記上 to；仙戰 C4b、宗主招收 C4d）。回傳（仙域, 名字）。"""
    free = [k for k, x in enumerate(realm_.get("loose", [])) if "to" not in x][:n] if sects else []
    loose = [{**x, "to": rng.choice(sects)} if k in free else x for k, x in enumerate(realm_.get("loose", []))]
    return {**realm_, "loose": loose}, [name_of(realm_["seed"], loose[k]["sect"], loose[k]["i"]) for k in free]


def gender_of(seed: str, sect: str, i: int) -> str:
    return random.Random(f"{seed}:{sect}:{i}:gender").choice(npc.GENDERS)


def name_of(seed: str, sect: str, i: int) -> str:
    """名冊上的人只記號碼，名字推算得回來；名字一律是人族的（只有號碼，推不出仙宗的種族）。"""
    return names.person_names(random.Random(f"{seed}:{sect}:{i}"), set(), 1, gender=gender_of(seed, sect, i))[0]


def next_up(realm_: dict, sect: str, taken: set[str], leaders: bool = False):
    """下一個可以成形的人：飛升上來的回傳那一筆（dict），名冊上的回傳 (宗名, 號碼)；都沒有回傳 None。
    sect 空字串＝散仙。leaders：宗主、長老用名冊外的負號，不佔名冊、不挑飛升上來的。
    名冊抽完了，往後 EXTRA 個號碼當作臨時遇上的新面孔（之後招新招到的就是他們）。"""
    if not leaders:
        moved = {(a["world"], a["name"]) for a in realm_.get("arrived", [])}   # 已經搬上來的（可能改了道號）
        for a in realm_.get("ascended", []):
            if a["sect"] == sect and a["name"] not in taken and (a["world"], a["name"]) not in moved:
                return a
    s = next((x for x in realm_["sects"] if x["name"] == sect), None) if sect else None
    taken_in = [(x["sect"], x["i"]) for x in realm_.get("loose", []) if x.get("to", "") == sect]   # 仙戰收走的散仙
    if leaders:
        nums = [(sect, -k) for k in range(1, len(LEADERS) + 1)]
    elif s:
        lo, hi = span(s)
        nums = taken_in + [(sect, i) for i in range(lo, hi + EXTRA)]
    else:
        nums = taken_in
    taken = taken | {a["name"] for a in realm_.get("ascended", [])} | set(realm_.get("daos", []))   # 留給飛升的人、主角道號
    return next((n for n in nums if name_of(realm_["seed"], *n) not in taken), None)


def person(seed: str, sect: str, i: int, *, rank: str, origins: list[str], race: str, clock_now: int) -> dict:
    """推算第 i 號（NPC 欄位，地點與登場回合由呼叫端補）。origins：這個仙宗下宗所在的「世界名的宗門名」。"""
    rng = random.Random(f"{seed}:{sect}:{i}:person")
    lv = LV[rank]
    years = round(npc.lifespan_years(lv, race) * rng.uniform(0.1, 0.6))
    where = rng.choice(origins) if origins else LOST_WORLD
    who = f"散仙，原是{sect}門下" if rank == LOOSE else f"{sect}的{rank}"
    name = name_of(seed, sect, i)
    return {"name": name, "race": race, **newcomer.kin({"name": name, "race": race, "gender": gender_of(seed, sect, i)}),
            "profile": f"{who}，出身{where}。",
            "status": "ALIVE", "ai_driven": True, "appearance": "",
            "birth_shichen": clock_now - years * SHICHEN_PER_YEAR, "profile_age": years, "realm_lv": lv,
            "stage_index": rng.randint(0, realm.last_stage(lv)), "cultivation": rng.randint(0, 80),
            "evolved_shichen": clock_now, "goal": "求道", "goal_target": "",
            **{t: rng.choice(list(npc.TRAIT_LEVELS.values())) for t in npc.TRAITS}}
