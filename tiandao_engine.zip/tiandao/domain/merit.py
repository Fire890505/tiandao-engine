"""戰功（16l 第 9 題；草稿 C2，C0 改規則）：打贏敵盟的人得戰功，同一個數字用在兩處。純函式。

規則（2026-10-14 與使用者一題一題定案，見 progress/WHITEPAPER.md 16l，數字暫定）：
- 第 16 題（2026-10-17）：「大戰場」只是說法，仙域處處可能開戰。主角是仙宗弟子，對交戰或冷戰中的敵盟的人動手、
  命中成功＝戰功（大成功 20、成功 10），不看地點。
- 個人：仙域裡的仙宗升內門、真傳看戰功不看境界（人人都是 Lv7 以上）；在自家山門說「兌換」某樣東西，用戰功換
  （丹藥、符籙、法器、功法；戰功＝靈石價的一半，至少 5）。秘境資格在 C3。
- 版圖：玩家拿到的戰功也記在所屬仙宗的帳上，百日演進時每 PER_POWER 點讓仙宗實力 +1，算完歸零。
- 角色卡 merit：這一生累積到現在還沒花掉的戰功。
"""
from __future__ import annotations

from . import ascent, atlas, immortal, items, sect, society
from . import judgment as J

WIN = {J.GREAT_SUCCESS: 20, J.SUCCESS: 10}
HOSTILE = (atlas.WAR, atlas.COLD)   # 交戰、冷戰的盟才算敵盟
RANKS = {sect.OUTER: 0, sect.INNER: 100, sect.CORE: 300}   # 仙域裡的仙宗升等看戰功
PER_POWER = immortal.MERIT_PER_POWER
WORDS = ("兌換",)
KINDS = (items.PILL, items.TALISMAN, items.ARTIFACT, items.TECHNIQUE)
MIN_COST = 5


def fields() -> dict:
    return {"merit": 0}


def sect_at(place: str) -> str:
    """這個地方是哪個仙宗的山門（不是山門回傳空字串）。"""
    return place[:-len(ascent.GATE)] if place.endswith(ascent.GATE) else ""


def sect_of(realm: dict, bonds: list[dict], name: str) -> str:
    """這個人在仙域屬於哪個仙宗（首領或成員）；不是仙宗的人回傳空字串。"""
    sects = {s["name"] for s in realm["sects"]}
    return next((b["b"] for b in bonds if b["a"] == name and b["type"] in society.MEMBER_BONDS and b["b"] in sects), "")


def foe(realm: dict, mine: str, theirs: str) -> bool:
    """對方的仙宗屬於跟自己這一盟交戰或冷戰的盟（C0：不看地點，仙域處處是戰場）；分裂出的宗跟原宗的盟也算（C5b2）。"""
    ally = {s["name"]: s["alliance"] for s in realm["sects"]}
    a, b = ally.get(mine, ""), ally.get(theirs, "")
    return (bool(a and b and a != b) and immortal.stances(realm).get(atlas._key(a, b)) in HOSTILE
            or immortal.feud(realm, mine, theirs))


def gain(verdict) -> int:
    """這回合的戰鬥打贏了多少戰功（呼叫端先確定對手是敵盟的人）。"""
    if verdict.action_type != J.COMBAT:
        return 0
    return max((WIN.get(c.outcome, 0) for c in verdict.all_checks if c.target == J.STRIKE), default=0)


def cost(name: str, tier: int) -> int:
    return max(MIN_COST, items.price(name, tier) // 2)


def exchange(sheet: dict, words: str) -> tuple[dict, list[str]]:
    """在自家山門用戰功換東西：行動裡點名物品表裡的一樣（品階照境界，物品表最高到元嬰級）。"""
    if not any(w in words for w in WORDS):
        return sheet, []
    name = next((i.name for i in items.CATALOG.values() if i.kind in KINDS and i.name in words
                 and i.name != items.BASIC_TECHNIQUE), "")
    if not name:
        return sheet, ["想用戰功兌換，但沒說要換什麼（丹藥、符籙、法器、功法）"]
    tier = items.CATALOG[name].tier if items.CATALOG[name].tier is not None else min(sheet["realm_lv"],
                                                                                         max(items.TIER_LABELS))
    need = cost(name, tier)
    if sheet["merit"] < need:
        return sheet, [f"戰功不夠：{items.label(name, tier)}要 {need} 點，只有 {sheet['merit']} 點"]
    return ({**items.add(sheet, name, tier), "merit": sheet["merit"] - need},
            [f"用 {need} 點戰功兌換了{items.label(name, tier)}"])


def text(sheet: dict) -> str:
    return f"戰功 {sheet['merit']} 點" if sheet["merit"] else ""
