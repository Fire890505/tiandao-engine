"""NPC 的身分（第 7-1a 批，WHITEPAPER 第 7-1-1～7-1-5 題甲）：出身一句、如今一句、修行身分。純函式。

- 出身：登錄後補一次、存著不改（npcs.origin，game/people.ensure_now）：地方＋家業＋排行套句型；種族跟當地主要的不同才寫。
- 如今：不存，當場組：修士寫修行身分、凡人寫職業、小孩寫跟著誰過日子。
- 修行身分：不存，當場算。有勢力照種類＋首領＋境界；沒勢力的修士照目標對一種，不擲。
- 話題組：修行身分併成 9 組，小孩一組（talk.txt 條件「修行:組名」）。
模板寫好身分（profile）的人照舊，出身和如今接在前面給說書人。
"""
from __future__ import annotations

import random

from . import era, npc, sect, society

KID = "小孩"
LEAD = {"宗門": "宗主", "武館": "館主", "家族": "家主", "幫派": "幫主", "朝廷": "供奉", "商會": "會首"}
STAFF = {"家族": "供奉", "幫派": "打手", "朝廷": "供奉", "商會": "護衛"}   # 勢力裡的修士；凡人照職業
FREE = {"求道": "散修", "隱居": "隱修", "逐利": "遊方", "求名": "遊俠", "守護": "坐鎮一方"}   # 沒勢力的修士；其他目標＝行路人
ROAMER = "行路人"
COVER = {"宗主": "會長", "長老": "理事", "內門弟子": "會員", "外門弟子": "學員"}   # 隱世時宗門的人對外的身分（宗門＝會館，era.SECT_LOOKS）
GROUPS = {"宗主": "宗門上層", "長老": "宗門上層", "內門弟子": "宗門弟子", "外門弟子": "宗門弟子", "館主": "武館", "武館弟子": "武館",
          **{r: "辦事" for r in ("家主", "幫主", "堂主", "打手", "供奉", "會首", "護衛")},
          "散修": "散修", "隱修": "隱修", "遊方": "遊方", "遊俠": "遊俠", "坐鎮一方": "行路", ROAMER: "行路"}
RANK = {"男": ("獨子", "老大", "老二", "老三", "么兒"), "女": ("獨女", "長女", "二女兒", "三女兒", "么女")}
SAID = ("{地}{業}家的{排}", "生在{地}一戶{業}人家，是家裡的{排}", "{地}人，家裡世代是{業}，{排}",
        "打小在{地}長大，爹娘是{業}，家裡的{排}", "{地}{業}家出身，{排}")
PLAIN = "{地}人，家裡的{排}"   # 沒有家業


def calling(p: dict, bonds: list[dict], factions: list[dict]) -> tuple[str, str]:
    """修行身分：（稱呼, 勢力名）。勢力裡的凡人、沒勢力的凡人是空稱呼（照職業）。"""
    kinds, lv = {f["name"]: f["type"] for f in factions}, p["realm_lv"]
    hall, lead = next(((b["b"], b["type"] == "首領") for b in bonds
                       if b["a"] == p["name"] and b["type"] in society.MEMBER_BONDS and b["b"] in kinds), ("", False))
    kind, adept = kinds.get(hall, ""), lv > 0 or p["hidden_power"]
    if kind == "宗門":
        role = "宗主" if lead else "長老" if lv >= sect.ELDER_LV else "內門弟子" if lv else "外門弟子"
    elif kind == "武館":
        role = "館主" if lead else "武館弟子"
    elif kind:
        role = LEAD[kind] if lead and adept else "堂主" if kind == "幫派" and lv >= sect.ELDER_LV else STAFF[kind] if adept else ""
    else:
        role = FREE.get(p["goal"], ROAMER) if adept else ""
    return role, hall


def _kid(p: dict, now: int) -> bool:
    """知道歲數、還沒成年（年紀不詳的不算：npc.is_minor 是保護用的，當成未成年）。"""
    years = npc.age(p, now)
    return years is not None and years < npc.ADULT_AGE


def group(p: dict, bonds: list[dict], factions: list[dict], now: int) -> str:
    """話題組：小孩、修行身分那一組；凡人空字串（照職業）。"""
    return KID if _kid(p, now) else GROUPS.get(calling(p, bonds, factions)[0], "")


def origin(rng: random.Random, p: dict, *, town: str, trade: str, jobs: tuple, land: str) -> str:
    """出身一句。trade：家人的職業（沒有就從這個村鎮的職業表 jobs 擲）；land：當地主要的種族。"""
    trade = trade or (rng.choice(jobs) if jobs else "")
    rank = rng.choice(RANK.get(p["gender"], RANK["男"]))
    line = (rng.choice(SAID) if trade else PLAIN).format(地=town, 業=trade, 排=rank)
    return (f"{p['race']}，" if p["race"] != land else "") + line


def now(p: dict, bonds: list[dict], factions: list[dict], clock_now: int, kin: str = "", stance: str = "") -> str:
    """如今一句：小孩跟著誰過日子；修士寫修行身分；凡人寫職業。都沒有回傳空字串。kin：家人的名字。
    stance：修士處境（古代是空字串）。隱世時宗門的人對外有凡人身分、打壓時修士在躲（第 8-3-3 題乙）。"""
    if _kid(p, clock_now):
        return f"跟著{kin}過日子" if kin else "還是個孩子"
    role, hall = calling(p, bonds, factions)
    if role:
        cover = (f"，對外是{era.SECT_LOOKS[era.HIDDEN]}的{COVER[role]}" if stance == era.HIDDEN and role in COVER
                 else "，躲著官府的登記" if stance == era.HUNTED else "")
        return (f"如今是{hall}的{role}" if hall else f"如今是個{role}") + cover
    return f"如今是個{p['job']}" if p["job"] else ""
