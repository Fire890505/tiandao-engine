"""眼前的環境物（16r）：地點上玩家能利用的東西。純函式。

規則（2026-11-05 與使用者定案，見 progress/WHITEPAPER.md 16r，數字暫定）：
- 第一次到訪時請說書人列 3～5 樣，存在地點上；沒列夠就用類型表補。
- 玩家的話提到環境物、用途對上這次的判定標的，成功率加一點。
- 一直在的想用幾次都行；用了就沒的（once）用一次就從清單拿掉。
"""
from __future__ import annotations

from .judgment import DISCOVER, ESCAPE, HIDE, STRIKE

COVER, THROW, BLOCK, CLIMB = "掩蔽", "投擲", "阻擋", "攀高"
USES = {COVER: HIDE, THROW: STRIKE, BLOCK: ESCAPE, CLIMB: DISCOVER}   # 用途 → 判定標的
BONUS = 10
LISTED = (3, 5)   # 一個地點幾樣


# 第 3 題：小模型的用途、用了就沒常標錯，看名字的最後一個字判斷；判斷不出來才用它標的
BY_TAIL = {"樹": (COVER, CLIMB), "叢": (COVER,), "林": (COVER,), "牆": (COVER,), "角": (COVER,), "碑": (COVER,),
           "石": (THROW,), "磚": (THROW,), "頭": (THROW,), "凳": (THROW,), "棍": (THROW,), "竿": (THROW,), "燈": (THROW,),
           "笆": (BLOCK,), "籬": (BLOCK,), "門": (BLOCK,), "板": (BLOCK,), "欄": (BLOCK,), "杆": (BLOCK,), "渠": (BLOCK,),
           "弄": (BLOCK,), "巷": (BLOCK,), "頂": (CLIMB,), "坡": (CLIMB,), "梯": (CLIMB,), "柱": (CLIMB,)}
ONCE_TAILS = ("堆", "燈", "竿", "凳", "簾", "笆")


def _uses(feature: dict) -> tuple[str, ...]:
    return BY_TAIL.get(feature["name"][-1], (feature["use"],))


def once(feature: dict) -> bool:
    """用一次就沒了。"""
    return feature["once"] or feature["name"][-1] in ONCE_TAILS


def _f(name: str, use: str, once: bool = False) -> dict:
    return {"name": name, "use": use, "once": once}


TOWN = (_f("人群", COVER), _f("巷弄", BLOCK), _f("屋頂", CLIMB), _f("竹竿", THROW, True))
RUINS = (_f("斷牆", COVER), _f("碎石", THROW), _f("殘柱", CLIMB))
BY_TYPE = {"荒野": (_f("大樹", COVER), _f("草叢", COVER), _f("石頭", THROW), _f("土坡", CLIMB)),
           "城鎮": TOWN, "坊市": TOWN, "秘境": RUINS, "廢墟": RUINS,
           "村落": (_f("老樹", CLIMB), _f("籬笆", BLOCK), _f("柴堆", BLOCK, True), _f("石頭", THROW))}
INDOORS = (_f("牆角", COVER), _f("板凳", THROW, True), _f("門板", BLOCK))   # 其他地方都當室內


def of(place: dict) -> list[dict]:
    """這個地點眼前有什麼。還沒列過（None）就先看類型表。"""
    listed = place.get("features")
    return list(BY_TYPE.get(place.get("type", ""), INDOORS)) if listed is None else listed


def filled(listed: list[dict], place_type: str) -> list[dict]:
    """說書人列的，不夠就用類型表補到 3 樣。"""
    names = {f["name"] for f in listed}
    extra = [f for f in BY_TYPE.get(place_type, INDOORS) if f["name"] not in names]
    return (listed + extra[:max(0, LISTED[0] - len(listed))])[:LISTED[1]]


def hits(features: list[dict], text: str) -> list[dict]:
    """玩家話裡提到的環境物。名字的最後一個字就算（「躲到樹後」算提到老槐樹）。"""
    return [f for f in features if f["name"] in text or f["name"][-1] in text]


def bonus(found: list[dict]) -> dict[str, int]:
    """判定標的 → 加成。同一個標的不疊加。"""
    return {USES[use]: BONUS for f in found for use in _uses(f)}


def used(found: list[dict], targets: set[str]) -> list[dict]:
    """這次判定真的用上的：用途對上有擲的標的。"""
    return [f for f in found if any(USES[use] in targets for use in _uses(f))]


def valid(features) -> bool:
    """讀檔檢查：None＝還沒列過。"""
    return features is None or isinstance(features, list) and len(features) <= LISTED[1] and all(
        isinstance(f, dict) and isinstance(f.get("name"), str) and 1 <= len(f["name"]) <= 8
        and f.get("use") in USES and isinstance(f.get("once"), bool) for f in features)
