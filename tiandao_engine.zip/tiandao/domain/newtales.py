"""模型寫的規則怪談（第 128 系列乙第二批，progress/模型生成內容.md「規則怪談要定的題」「再次設計」「乙：守則的種類」）。純函式，不呼叫模型。

- 判定欄由 Python 照 rules/content/tale_parts.txt 擲：場所、寫守則的人、六個不重複的禁忌（一個假的）、犯了的後果、扭法、語氣、感悟。
- 再次設計（2026-11-19）：有邏輯的整句由 Python 照語氣句型拼（六條守則、正解、情境、了結第二三步），本體、規則之物從場所的物件組；
  模型分三段寫：story（名字、傳聞、氣氛、了結的揭露、正解的原因）、bits（每條守則的條件、後面的小段，分不出哪條是假的）、
  是非題（questions：每段通不通順）。
- 乙（2026-11-19）：守則分型（禁止、應對、確認、時限、數量、身分），扭法有型的那篇多兩條那型、一真一假；「有例外」兩條加「除非」。
  意象兩個：第一個＝規則之物，第二個從詞池擲（故事要寫到、身分型的特徵從它來）。情境型的條件交給模型寫（bits 的 c 欄）。
- 「守則寫在」由 Python 組（場所的語氣）。綁一州、開局 3 篇、補寫 1/3、上限 12，都照傳說。只有古代、只有地方型。
"""
from __future__ import annotations

import random

from . import checks, clauses, newlegends, tales
from .tales import BOSS, CONTENT, HURT1, HURT2, MARKED, THING

MODEL = newlegends.MODEL
OPENING, MORE_CHANCE, MAX_PER_WORLD = newlegends.OPENING, newlegends.MORE_CHANCE, newlegends.MAX_PER_WORLD
RULES = 6
COSTS = (MARKED, MARKED, HURT1, HURT2, THING)   # 五條真的（第 2 題）；假的那條規則之物或本體
STORY = ("name", "rumor", "mood", "found1", "found2", "end", "why")
SPANS = {"name": (2, 8), "rumor": (6, 40), "mood": (4, 30), "found1": (8, 60), "found2": (8, 60), "end": (8, 60),
         "why": clauses.FORMS["正解"][1]}
HINTS = {MARKED: "會被它盯上", HURT1: "會受點傷", HURT2: "會受重傷", THING: "{thing}會出怪事"}   # 真的守則犯了會怎樣（給模型的提示）
BAN, EXCEPT, NUMS = "禁止", "例外", "一二三四五六七"

_rows = [l.split("｜") for l in (CONTENT / "tale_parts.txt").read_text(encoding="utf-8").splitlines() if l and not l.startswith("#")]
_table = lambda k: {r[1]: r[2:] for r in _rows if r[0] == k}   # noqa: E731
PLACES, TABOOS, WRITERS, TWISTS = _table("場所"), _table("禁忌"), _table("寫的人"), _table("扭法")
TONES = {k: {"no": v[0].split("、"), "do": v[1].split("、"), "hurt": v[2].split("、"), "gain": v[3].split("、"),
             "forms": v[4].replace("{接縫}，", "{接縫}").split("／"), "sep": "，" if "{接縫}，" in v[4] else "",
             "span": clauses.span(v[5])} for k, v in _table("語氣").items()}
TYPES = {k: {"taboos": v[0].split("、"), "true": v[1].split("／"), "fake": v[2].split("／")} for k, v in _table("型").items()}
CONFIRMS, LIMITS, ANSWERS = _table("確認"), _table("時限"), {k: v[0].split("、") for k, v in _table("答句").items()}
RUMORS = next(r[1].split("／") for r in _rows if r[0] == "傳聞例句")
# PLACES：類型、規模、你是誰、日常規矩、接點、物件、人；TABOOS：時段、行動、詞、情境方向、該寫、小段不准有、來源、條件、時機、做法
# WRITERS：為什麼、誘導什麼、假規則的禁忌、了結、本體的類、打聽什麼；TWISTS：做法、型；CONFIRMS：確認的說法、該寫


def _types(taboo: str) -> list[str]:
    return [BAN] + [k for k, v in TYPES.items() if taboo in v["taboos"]]


def _picks(rng: random.Random, pool: list[str], kind: str) -> list[tuple[str, str, bool]]:
    """六條的（禁忌, 型, 假不假），順序已打亂（假的第幾條由 Python 擲，v2 鎖定）。扭法有型：那型一真一假，假的先照寫的人
    （乙第 6 題甲）；其他條的型盡量不重複（每篇至少三型）。"""
    if kind in TYPES:
        fits = TYPES[kind]["taboos"]
        fake = rng.choice([t for t in pool if t in fits] or fits)
        out = [(fake, kind, True), (rng.choice([t for t in fits if t != fake]), kind, False)]
    else:
        fake = rng.choice(pool)
        out = [(fake, rng.choice(_types(fake)), True)]
        if kind == EXCEPT:   # 兩條有時段的真的禁止型，加「除非」
            out += [(t, BAN, False) for t in rng.sample([t for t, row in sorted(TABOOS.items()) if row[0] and t != fake], 2)]
    used = {k for _, k, _ in out}
    for t in rng.sample([t for t in sorted(TABOOS) if t not in {x[0] for x in out}], RULES - len(out)):
        k = rng.choice([k for k in _types(t) if k not in used] or _types(t))
        used.add(k)
        out.append((t, k, False))
    rng.shuffle(out)
    return out if len({k for _, k, _ in out}) >= 3 else _picks(rng, pool, kind)


def plan(rng: random.Random, seed: str, states: list[str], n: int) -> list[dict]:
    """要寫哪幾篇：每篇擲一州、所有判定欄，照型和語氣拼好整句（{條件}{段} 留給模型）。
    seed：天下骨架的種子，跟傳說同一個介面（service._lore），怪談綁的是地點類型、不看地勢，用不到。"""
    out, egs = [], rng.sample(RUMORS, len(RUMORS))   # 傳聞例句一批輪流（2026-11-19 使用者選乙）
    for j in range(n):
        place, writer, twist, tone = (rng.choice(sorted(t)) for t in (PLACES, WRITERS, TWISTS, TONES))
        why, lure, pool, end, kinds, ask = WRITERS[writer]
        types, scale, who, daily, hooks, objs, people = PLACES[place]
        objs, people = objs.split("、"), people.split("、")
        thing, boss_obj = rng.sample(objs, 2)
        image = rng.choice(sorted(clauses.IMAGES))
        feature = clauses.FEATURES.get(image) or rng.choice(sorted(clauses.FEATURES.values()))
        k = rng.randrange(2, 5)   # 數量型：一篇同一個數，只有 k+1 個、看見第 k+2 個
        t, costs, rules, excepts = TONES[tone], iter(rng.sample(COSTS, len(COSTS))), [], 2 if TWISTS[twist][1] == EXCEPT else 0
        for i, (taboo, kind, fake) in enumerate(_picks(rng, pool.split("、") if pool else sorted(TABOOS), TWISTS[twist][1])):
            row, cf = TABOOS[taboo], CONFIRMS.get(taboo, ["", ""])
            form, act, scene = rng.choice(t["forms"] if kind == BAN else TYPES[kind]["fake" if fake else "true"]), row[9], bool(row[3])
            if excepts and kind == BAN and not fake and row[0]:
                act, excepts = f"{act}，除非{rng.choice(clauses.EXCEPTS)}", excepts - 1
            mine = bool(row[7]) and not row[8] and ("{條件}" in form or scene)   # 條件模型寫（第 7 題甲）；禁忌自己有時機的照舊
            r = {"taboo": taboo, "type": kind, "fake": fake, "cost": rng.choice((THING, BOSS)) if fake else next(costs), "scene": scene,
                 "words": row[5].split("、"), "act": act.replace("{物件}", rng.choice(objs)), "example": clauses.condition(rng, *row[6:9]),
                 "answer": rng.choice(ANSWERS[writer]), "check": cf[1]}
            r["cond"] = "{條件}" if mine else r["example"]
            r["text"] = clauses.fill(form, 條件=r["cond"], 做=r["act"], n=NUMS[i], 禁=rng.choice(t["do" if fake and kind == BAN else "no"]),
                                     要=rng.choice(t["do"]), 接縫=rng.choice(t["gain" if fake else "hurt"]) + t["sep"], 答=r["answer"],
                                     確認=rng.choice(cf[0].split("／")), 回=LIMITS.get(taboo, [""])[0], 誰=who.split("、")[0],
                                     特徵=feature, 數=NUMS[k], 第=NUMS[k + 1])
            rules.append(r)
        f = next(r for r in rules if r["fake"])
        end = end or rng.choice(sorted(newlegends.ENDS))
        word, boss = rng.choice(newlegends.ENDS[end][0].split("、")), clauses.boss(rng, kinds, boss_obj)
        out.append({"state": rng.choice(states), "place": place, "types": types, "scale": scale, "who": who, "daily": daily,
                    "hooks": hooks, "writer": writer, "why": why, "lure": lure, "twist": twist, "how": TWISTS[twist][0],
                    "tone": tone, "rules": rules, "rumor_eg": egs[j % len(egs)], "boss": boss, "thing": thing, "images": [thing, image], "end": end,
                    "end_words": newlegends.ENDS[end][0], "law": rng.choice(newlegends.LAWS),
                    "truth": clauses.fill(rng.choice(clauses.FORMS["正解"][0]), 做=f["act"]),
                    "next1": f"到{{鄰地}}找{people[0]}打聽{ask}", "next2": clauses.ending(word, boss, thing, people[1])})
    return out


def asks(slot: dict, got: dict) -> list[dict]:
    """bits 段要模型寫的：情境型的條件（c）、每條守則後面的小段（r）、情境那一幕的細節（s）。問法不帶真假：真的問犯了會怎樣、
    假的問照做的好處。got["bits"]：已經寫好的（重寫時條件用模型寫過的）。cond：整句裡的 {條件} 換哪一欄。"""
    t, out, done = TONES[slot["tone"]], [], got.get("bits", {})
    cond = lambda i: f"「{clauses.bit(done[f'c{i}'])}」" if f"c{i}" in done else f"第{i}條開頭的情境（上面寫的）"   # noqa: E731
    for i, r in enumerate(slot["rules"], 1):
        mine = r["cond"] == "{條件}"
        if mine:   # 填空式（2026-11-19 使用者選甲）：整句給模型看，規矩已經在了，它才不會自己補一條
            whole = r["text"].replace("{條件}", "＿＿").replace("{段}", "……")
            where = f"在「{whole}」的＿＿寫" if "＿＿" in whole else f"寫「{whole}」這條會在什麼"
            out.append({"key": f"c{i}", "ask": f"{where}情境：只寫什麼時候、看到或聽到什麼（像「{r['example']}」），"
                        f"可以用上「{slot['images'][1]}」；規矩已經寫好了，不要再寫該怎麼做", "text": "", "cond": "",
                        "span": clauses.FORMS["條件"][1], "words": r["words"], "fake": False})
        before = r["text"].split("{段}")[0].replace("{條件}", "……")
        what = "照做之後的好處" if r["fake"] else f"犯了之後會怎樣（{HINTS[r['cost']].format(thing=slot['thing'])}）"
        out.append({"key": f"r{i}", "ask": f"接在「{before}」後面，寫{what}", "text": r["text"], "cond": f"c{i}" if mine else "",
                    "span": t["span"], "words": r["words"], "fake": r["fake"]})
    for i, r in enumerate(slot["rules"], 1):
        if r["scene"]:
            form, span_ = clauses.FORMS["情境"]
            out.append({"key": f"s{i}", "ask": f"接在{cond(i)}後面，寫一個看得到或聽得到的細節", "text": form[0], "cond": f"c{i}",
                        "span": span_, "words": r["words"], "fake": False})
    return out


def review(part: str, slot: dict, got: dict, taken: set[str], batch: list[dict], era_now: str) -> str:
    """一段合格回傳空字串，不然回傳原因。part：story／bits；got：各段的輸出（這段是剛寫的）。
    taken：世界裡已有的名字（怪談、地名）；batch：這批已經收下的（record 過的）。"""
    if part == "bits":
        return next(iter(faults(slot, got, era_now).values()), "")
    g = {k: clauses.clean(v) for k, v in got[part].items()}
    if reason := checks.basic([(newlegends.plain(clauses.bit(g[k]) if k == "why" else g[k]), SPANS[k]) for k in STORY], era_now):
        return reason
    if not clauses.hit("".join(g[k] for k in STORY), slot["images"][1:]):
        return "沒寫到意象"
    if checks.clash(g["name"], taken | {t.name for t in tales.themes()} | {b["name"] for b in batch}):
        return "撞名"
    return "重複" if checks.same_head(g["rumor"], [b["line"] for b in batch]) else ""


def faults(slot: dict, got: dict, era_now: str) -> dict[str, str]:
    """bits 逐欄查：沒過的 → 原因（GameService._write 只重寫這幾欄）。"""
    return {x["key"]: r for x in asks(slot, got)
            if (r := clauses.bit_ok(clauses.bit(got["bits"][x["key"]]), x["span"], x["words"], x["fake"], era_now))}


def _full(slot: dict, got: dict) -> dict[str, str]:
    """拼好的整句：每條守則、情境（key 同 asks）、正解（truth）。"""
    b = {k: clauses.bit(v) for k, v in got["bits"].items()}
    out = {x["key"]: x["text"].replace("{條件}", b.get(x["cond"], "")).replace("{段}", b[x["key"]]) for x in asks(slot, got) if x["text"]}
    return {**out, "truth": slot["truth"].replace("{段}", clauses.bit(got["story"]["why"]))}


def questions(slot: dict, got: dict) -> list[dict]:
    """是非題（再次設計第 6 題乙）：只問模型寫的字通不通順——每段條件、小段、正解的原因、故事的自由欄；不給 Python 的整句，
    9b 才不會因為假的那條是壞建議而擋。want：答「是」才對；key：答錯重寫哪一欄。"""
    s = {k: clauses.bit(v) for k, v in got["story"].items()}
    return [*({"q": clauses.ask_ok(clauses.bit(got["bits"][x["key"]])), "want": True, "part": "bits", "key": x["key"]}
              for x in asks(slot, got)),
            *({"q": clauses.ask_ok(s[k]), "want": True, "part": "story", "key": k} for k in ("why", "rumor", "found1", "found2", "end"))]


def _rule(r: dict, text: str, seen: str, truth: str) -> str:
    """判定欄照禁忌表；真的應對、確認型：只看該寫（答句、確認的字），不看詞（答「…」本身就有「答」）。"""
    when, natures, words, direction, good = TABOOS[r["taboo"]][:5]
    if not r["fake"] and r["type"] in ("應對", "確認"):
        words, good = "", r["answer"] if r["type"] == "應對" else r["check"]
    cols = [f"犯了:{r['cost']}", r["fake"] and "假:是", when and f"時段:{when}", natures and f"行動:{natures}",
            words and f"詞:{words}", direction and f"情境:{seen}", good and f"該寫:{good}", r["fake"] and f"正解:{truth}"]
    return "｜".join(["守則", text, *filter(None, cols)])


def record(slot: dict, got: dict) -> dict:
    """存成一篇（tales_w）：Python 的判定欄、整句＋模型的小段和故事欄，組成跟 rules/content/tales/ 一樣格式的全文。"""
    g, full = {k: clauses.clean(v) for k, v in got["story"].items()}, _full(slot, got)
    body = [f"牌｜{g['name']}｜地方｜怪談｜規模:{slot['scale']} 地點:{slot['types']} 時代:古代｜｜感悟:{slot['law']} 遺物:無",
            f"傳聞｜{g['rumor']}", f"守則寫在｜{slot['place']}的{slot['tone']}", f"氣氛｜{g['mood']}", f"本體｜{slot['boss']}",
            f"規則之物｜{slot['thing']}", f"抽幾條｜{RULES}", f"扭法｜{slot['twist']}",
            *(_rule(r, full[f"r{i}"], full.get(f"s{i}", ""), full["truth"]) for i, r in enumerate(slot["rules"], 1)),
            *newlegends.ending({**g, "next1": slot["next1"], "next2": slot["next2"]}, slot["end_words"])]
    return {"name": g["name"], "state": slot["state"], "body": "\n".join(body), "source": MODEL, "line": g["rumor"]}
