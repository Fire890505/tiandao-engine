"""都市傳說（第 19-2 步）：主題、出現、碰上、應對、移動、了結。純函式，不碰資料庫、不呼叫 AI。

規則（2026-10-07 與使用者一題一題定案，WHITEPAPER「19-2 都市傳說」，數字暫定）：
- 每個傳說有中心地點，出沒範圍＝中心＋相連的地點；不籠罩、不給守則。中心偶爾移動（害了人之後、或每半年三分之一的機會），
  根源（root）不動。
- 世界上只流傳「流傳的說法」（有對有錯）；了結的第一步揭穿錯的。
- 主角在範圍內、隱藏條件符合，每回合 ENCOUNTER 碰上；被纏上的不限範圍、每回合 HAUNT_CHANCE。碰上＝說書人只寫到它開口，
  下一回合看應對：對了它離開；第一次錯＝受傷＋纏上一年；第二次錯＝本體追殺（離開要脫身）；動手它就逃。
- 跟領域共用每月那一次擲骰（生靈級，權重比照家級）；客死異鄉（前世主角死在遠方）另外生成，依執念分三種模板。
主題內容照 progress/URBAN_LEGENDS.md（使用者 2026-10-07 都收），在 rules/content/legends/（第 4-4 題，一篇一個檔）。
模型寫的主題（第 128 系列乙，domain/newlegends.py）存在 legends_w，只屬那個世界、只在那一州出現：每回合開頭 use 設一次，
讀主題一律用 theme（先查這個世界的、再查手寫的；progress/模型生成內容.md 第七節，19 處讀主題的做法甲）。
"""
from __future__ import annotations

from contextvars import ContextVar
from dataclasses import dataclass

from . import cards, deck, era
from . import judgment as J
from .clock import SHICHEN_PER_MONTH, SHICHEN_PER_YEAR
from .tales import CONTENT, HERE, NEAR, Step, fill, head, items, parse_cards, steps

ACTIVE, CLEARED = "流傳", "了結"
ENCOUNTER, HAUNT_CHANCE = 0.3, 0.2
HAUNT_YEARS = 1
MOVE_EVERY, MOVE_CHANCE = 6 * SHICHEN_PER_MONTH, 1 / 3
WEIGHT = 3                 # 跟領域一起抽的權重（生靈級，比照家級）
POWER = 1                  # 本體的戰力（脫身判定的對手境界）
INSIGHT = 10               # 了結的感悟（同家級）
ANSWER_INSIGHT = 3         # 每一生第一次答對的感悟（19-3 第 5 題）
HOME_AT, ANYWHERE = "老家", "何處"   # 了結步驟的地點：除了此地（根源）、鄰地，還有死者的老家、哪裡都行
GRUDGE, PROMISE, HOMESICK = "尋仇的旅人", "托話的人", "問路的人"   # 客死異鄉的三種模板（依執念）
THREAD_HEAD = "的傳說："


@dataclass(frozen=True)
class Saying:
    text: str
    true: bool
    truth: str = ""        # 錯的說法：其實是怎樣（了結第一步時揭穿）


@dataclass(frozen=True)
class Legend:
    name: str
    law: str
    relic: bool
    places: tuple[str, ...]          # 中心可以是哪幾種地點（客死異鄉的不看）
    mood: str
    line: str                        # 碰上時發生的事（它開口）
    when: str                        # 隱藏條件：時段（空＝不看）
    natures: tuple[str, ...]         # 隱藏條件：這回合做的行動
    good: tuple[str, ...]            # 對的應對（一個都沒寫＝錯）
    bad: tuple[str, ...]             # 寫了就錯的字
    sayings: tuple[Saying, ...]
    steps: tuple[Step, ...]
    boss: str
    wrong: tuple[str, ...] = ()      # 做了就錯的行動
    lost: bool = False               # 隱藏條件：判定失敗（迷路）時才碰上
    ghost: bool = False              # 客死異鄉的模板
    eras: tuple[str, ...] = (era.ANCIENT,)   # 屬於哪些時代（第 16e 節）；其他時代只出現在 era.OLD_PLACES
    state: str = ""                  # 模型寫的綁一州（只在那一州出現）；手寫的空＝哪裡都有
    motif: str = ""                  # 模型寫的母題（legend_parts.txt）：牌 路線:母題 的零件套（待辦 3）；手寫的空


def parse(text: str, state: str = "") -> Legend:
    """一篇的全文（手寫檔、legends_w 的 body 同一種格式）→ 主題。"""
    rs = [line.split("｜") for line in text.splitlines() if line and not line.startswith("#")]
    c, need, res = head(rs)
    one = {r[0]: r[1] for r in rs if r[0] in ("氣氛", "開口", "答對", "答錯", "做了就錯", "本體", "母題")}
    meet = dict(x.split(":", 1) for x in next(r[1:] for r in rs if r[0] == "碰上"))
    sayings = tuple(Saying(r[1], len(r) < 3, r[2].split(":", 1)[1] if len(r) > 2 else "") for r in rs if r[0] == "說法")
    return Legend(c.name, res["感悟"], res["遺物"] == "有", items(need.get("地點", "")), one["氣氛"], one["開口"],
                  meet.get("時段", ""), items(meet.get("行動", "")), items(one["答對"]), items(one["答錯"]), sayings, steps(rs),
                  one["本體"], items(one.get("做了就錯", "")), meet.get("迷路") == "是", c.kind == "客死異鄉", items(need["時代"]),
                  state, one.get("母題", ""))


LEGENDS = {g.name: g for g in (parse(p.read_text(encoding="utf-8")) for p in sorted((CONTENT / "legends").glob("*.txt")))}   # 手寫的；檔名前的數字是順序
_WORLD: ContextVar[dict[str, Legend]] = ContextVar("legends_world", default={})


def use(mine: list[dict]) -> None:
    """每回合開頭設一次：這個世界模型寫的主題（legends_w 的列：name、state、body）。整篇寫的專屬牌一起設。"""
    _WORLD.set({r["name"]: parse(r["body"], r["state"]) for r in mine})
    cards.use([deck.card(c) for r in mine for c in parse_cards(r["body"])], "legend")


def theme(name: str) -> Legend | None:
    return _WORLD.get().get(name) or LEGENDS.get(name)


def themes() -> list[Legend]:
    return [*LEGENDS.values(), *_WORLD.get().values()]


# ── 出現 ───────────────────────────────────────────────────────────────────
def options(locations: list[dict], neighbors: dict[str, list[str]], legends: list[dict], blocked: set[str],
            card: dict = era.DEFAULT, states: dict[str, str] | None = None) -> list:
    """可以出現的（中心地點, 主題）：地點類型與時代對（era.fits）、有鄰地、那裡還沒有傳說的中心、不是主角所在。
    states：地點 → 州；模型寫的只在它那一州。"""
    centers, states = {g["center"] for g in legends if g["status"] == ACTIVE}, states or {}
    return [(l["name"], g) for l in locations if l["name"] not in centers | blocked and neighbors.get(l["name"])
            for g in themes() if not g.ghost and (not g.state or states.get(l["name"]) == g.state)
            and era.fits(l["type"], g.places, g.eras, card)]


def make(rng, place: str, legend: Legend, neighbors: dict[str, list[str]], clock_now: int, **ghost) -> dict:
    """新的傳說紀錄。ghost：客死異鄉的 dead、target、home。"""
    return {"theme": legend.name, "center": place, "root": place, "neighbor": rng.choice(neighbors[place]),
            "dead": "", "target": "", "home": "", **ghost, "met": "", "step": 0, "misses": 0, "chased": False,
            "haunts": "", "haunt_until": None, "status": ACTIVE, "created_shichen": clock_now, "moved_shichen": clock_now,
            "solved_shichen": None, "rewarded": ""}


def told(rng, g: dict) -> list[str]:
    """出現時傳開的說法：2～3 條，至少一條是錯的。"""
    sayings = list(theme(g["theme"]).sayings)
    false = rng.choice([s for s in sayings if not s.true])
    picked = [false, *rng.sample([s for s in sayings if s is not false], min(len(sayings) - 1, rng.randint(1, 2)))]
    return [fill(s.text, names(g)) for s in picked]


def ghost_kind(grudge: tuple[str, str], home: str) -> tuple[str, str]:
    """客死異鄉依執念挑模板（同 11-2 幽魂的判斷）：回傳（模板, 對象）。"""
    kind, target = grudge
    return (GRUDGE, target) if kind == "恩怨" else (PROMISE, target) if kind == "約定" else (HOMESICK, home)


# ── 名字與條件 ─────────────────────────────────────────────────────────────
def names(g: dict) -> dict[str, str]:
    return {"此地": g["root"], "鄰地": g["neighbor"], "亡者": g["dead"], "對象": g["target"], "老家": g["home"]}


def in_range(g: dict, place: str, neighbors: dict[str, list[str]]) -> bool:
    return place == g["center"] or place in neighbors.get(g["center"], ())


def haunting(g: dict, life: str, clock_now: int) -> bool:
    return g["haunts"] == life and g["haunt_until"] is not None and clock_now < g["haunt_until"]


def meets(g: dict, *, when: set[str], nature: str, failed: bool) -> bool:
    """隱藏條件（玩家看不到）：時段、行動、迷路。"""
    legend = theme(g["theme"])
    return (not legend.when or legend.when in when) and nature in legend.natures and (not legend.lost or failed)


def answer(g: dict, *, nature: str, text: str) -> str:
    """上回合碰上了，這回合怎麼應對：動手＝逃走（"fled"）；做了不該做的、寫了不該寫的、該寫的一個都沒寫＝錯（"wrong"）。"""
    legend, n = theme(g["theme"]), names(g)
    if nature == J.COMBAT and J.COMBAT not in legend.wrong:
        return "fled"
    good, bad = [fill(w, n) for w in legend.good], [fill(w, n) for w in legend.bad]
    wrong = nature in legend.wrong or any(w and w in text for w in bad) or not any(w and w in text for w in good)
    return "wrong" if wrong else "right"


def miss(g: dict, life: str, clock_now: int) -> dict:
    """答錯：第一次纏上一年，第二次本體追殺。"""
    misses = g["misses"] + 1
    return {**g, "misses": misses, "haunts": life, "haunt_until": clock_now + HAUNT_YEARS * SHICHEN_PER_YEAR,
            "chased": misses >= 2}


def step_done(g: dict, *, here: str, when: set[str], nature: str, text: str, target: str, success: bool,
              matches) -> bool:
    """了結：這回合完成了目前這一步沒。地點：此地＝根源、鄰地、老家、何處；person＝對象要是{對象}。
    matches：domains.matches（時段、行動、字詞的判斷）。"""
    steps = theme(g["theme"]).steps
    if g["step"] >= len(steps):
        return False
    at = {HERE: g["root"], NEAR: g["neighbor"], HOME_AT: g["home"] or g["root"]}
    return any((w.place == ANYWHERE or at[w.place] == here) and (not w.success or success)
               and (not w.person or target == g["target"])
               and matches(w, when=when, nature=nature, text=text, names=names(g)) for w in steps[g["step"]].ways)


def moves(rng, g: dict, start: int, end: int) -> bool:
    """每半年三分之一的機會換中心（跨過幾個半年就擲幾次，一次擲完）。"""
    spans = end // MOVE_EVERY - start // MOVE_EVERY
    return spans > 0 and rng.random() < 1 - (1 - MOVE_CHANCE) ** spans


# ── 給說書人與畫面 ─────────────────────────────────────────────────────────
def lore(g: dict) -> list[str]:
    """已經查明的（完成的步驟）；第一步之後揭穿錯的說法。"""
    legend, n = theme(g["theme"]), names(g)
    found = [fill(s.reveal, n) for s in legend.steps[:g["step"]]]
    if g["step"] >= 1:
        found += [f"「{fill(s.text, n)}」是錯的：{fill(s.truth, n)}" for s in legend.sayings if not s.true]
    return found


def scene(g: dict) -> str:
    return f"（傳說）{fill(theme(g['theme']).line, names(g))}。只寫到它開口、主角還沒應對為止"


def prompt(g: dict) -> str:
    """【傳說】：主角在出沒範圍或被纏上時的氣氛與已經查明的事；隱藏條件與對錯不給。"""
    legend = theme(g["theme"])
    known = "；".join(lore(g))
    return (f"這一帶流傳著「{legend.name}」的傳說（{legend.mood}）。不要替主角說出它挑人的條件、也不要點破哪個說法是錯的"
            + (f"　已經查明：{known}" if known else "")
            + (f"　{fill(legend.boss, names(g))}正追著主角" if g["chased"] else ""))


def hint(g: dict) -> str:
    """暗線的把柄（16v 第 36 題）：一條隱藏條件。"""
    legend = theme(g["theme"])
    return (f"{legend.name}只在迷路的人面前出現" if legend.lost else f"{legend.name}只在{legend.when}出現" if legend.when
            else f"{legend.name}找上的是在{'、'.join(legend.natures)}的人")


def thread_text(g: dict, hint: str) -> str:
    return f"{g['theme']}{THREAD_HEAD}{fill(hint, names(g))}"[:40]


def valid(g: dict, places: set[str]) -> bool:
    """存檔檢查。"""
    legend = theme(g["theme"]) if isinstance(g["theme"], str) else None
    return (legend is not None and g["center"] in places and g["root"] in places and g["neighbor"] in places
            and (g["dead"] != "") == legend.ghost and all(isinstance(g[k], str) and len(g[k]) <= 40
                                                           for k in ("dead", "target", "home", "met", "haunts", "rewarded"))
            and (not g["home"] or g["home"] in places)
            and isinstance(g["step"], int) and not isinstance(g["step"], bool) and 0 <= g["step"] <= len(legend.steps)
            and isinstance(g["misses"], int) and not isinstance(g["misses"], bool) and 0 <= g["misses"] <= 99
            and isinstance(g["chased"], bool) and (g["haunt_until"] is None or isinstance(g["haunt_until"], int))
            and g["status"] in (ACTIVE, CLEARED))
