"""黑市與奴隸商人（2026-10-13，WHITEPAPER 16i 第 9、10-1～10-4、10-12～10-14 題；第 8 組批次二）。純函式。

- 黑市一開始不在地圖上：在城鎮、坊市打聽黑市，套話成功就拿到今年的暗號，入口登上地圖（城裡的凡人黑市；
  修士另外問到修士黑市）。暗號每年換；到門口暗號不對、被列黑名單、凡人想進修士黑市，都被擋在門外。
- 經營的集團（第一次進去時生成）：凡人黑市一半機會是城裡的幫派、商會暗中經營，不然另生一個地下幫派；
  一半機會跟本山有私交（凡人黑市就有法器流入）。修士黑市整個世界一個集團。集團的 traits 記著它經營哪些黑市。
  每個黑市一個護衛（凡人黑市武者、修士黑市金丹）。
- 黑市不歸國法管（crime.LAWLESS）。在裡面動手、偷東西＝護衛壓制、趕出去、一年進不去。
- 風險：凡人黑市每回合可能被官府突襲（趕出去）；出了黑市可能被人跟上搶走兩成錢（黑吃黑）；買東西可能買到假貨。
- 奴隸商人：販賣人口無罪的國家在坊市，有罪的國家只在黑市。賣俘虜、僕人換錢；買一個成年的僕人。
- 假路引（違禁品）：7 天內追捕者找不到你，易容破了也不算易容入城。
- 16l 第 6-4 題：修士黑市看門路，不看境界——自己是修士、宗門武館的人、身上有信物（凡人黑市買得到）、
  或身邊有修士同行；沒有門路的打聽黑市只聽說有修士黑市，進不去。
- 角色卡欄位：codes（黑市 → 暗號是哪一年的）、market_bans（黑市 → 到何時都進不去）、papers（假路引到何時）。
"""
from __future__ import annotations

import random

from . import crime, names, newcomer, npc, society
from . import judgment as J
from .clock import SHICHEN_PER_DAY, SHICHEN_PER_YEAR

MORTAL, CULTIVATOR, HOUSE = "黑市", "修士黑市", "拍賣場"
TYPES = (MORTAL, CULTIVATOR)
ALL = TYPES + (HOUSE,)                                        # 拍賣場在修士黑市底下（批次三，domain/auction.py）
ASK_PLACES = ("城鎮", "坊市")
WORD = "黑市"
GUARD_POWER = {MORTAL: npc.NOVICE, CULTIVATOR: npc.POWERFUL}   # 比門檻高一階：武者、金丹
SCALE = "城市"                                                 # 地點規模（護衛的境界上限）
GANGS = ("幫派", "商會")
SYNDICATES = ("萬象樓", "無影閣", "黑蓮會", "千面堂")
KEY = "黑市"                                                   # 集團 traits 的鍵：經營的黑市（修士黑市記 CULTIVATOR＝全部）
RAID, ROBBED, FAKE = 0.05, 0.1, 0.1
ROB_SHARE = 0.2
BY = "black_market"                                            # 護衛、買來的人：NPC 的 created_by
SELL_WORDS, BUY_WORDS = ("賣給", "賣掉", "賣了"), ("買下", "買一個", "買個")
SLAVE_WORDS = ("奴隸", "僕人", "俘虜", "人牙子")
PRICE_MORTAL, PRICE_STONES, BUY_COST = 100, 20, 200            # 賣一個凡人（凡人錢）、修士（靈石 × 2^(境界−1)）、買一個僕人
PAPERS_DAYS = 7
TOKEN = "修士黑市信物"                                         # 門路之一（items 物品表裡的違禁品）


def fields() -> dict:
    return {"codes": {}, "market_bans": {}, "papers": 0}


def papers(sheet: dict, clock_now: int) -> dict:
    return {**sheet, "papers": clock_now + PAPERS_DAYS * SHICHEN_PER_DAY}


def papered(sheet: dict, clock_now: int) -> bool:
    return sheet["papers"] > clock_now


def year(clock_now: int) -> int:
    return clock_now // SHICHEN_PER_YEAR


def way_in(sheet: dict, guides: list[int]) -> bool:
    """修士黑市的門路。guides：隨行的人的境界。"""
    return (sheet["realm_lv"] >= 1 or bool(sheet["sect"]) or any(e["name"] == TOKEN for e in sheet["items"])
            or any(lv >= 1 for lv in guides))


def places(city: str, way: bool) -> list[dict]:
    """打聽到的黑市（地點欄位）：凡人黑市；有門路的還有修士黑市與底下的拍賣場。"""
    found = [{"name": f"{city}{MORTAL}", "type": MORTAL, "parent": city}]
    if way:
        found += [{"name": f"{city}{CULTIVATOR}", "type": CULTIVATOR, "parent": city},
                  {"name": f"{city}{HOUSE}", "type": HOUSE, "parent": f"{city}{CULTIVATOR}"}]
    return [{**p, "scale": SCALE, "danger": ""} for p in found]


def asking(verdict, place_type: str, words: str) -> bool:
    """這回合在城鎮、坊市套話打聽黑市，而且成功了。"""
    return place_type in ASK_PLACES and WORD in words and any(
        c.target == J.PRY and c.outcome in (J.SUCCESS, J.GREAT_SUCCESS) for c in verdict.all_checks)


def learn(sheet: dict, markets: list[str], clock_now: int) -> dict:
    return {**sheet, "codes": {**sheet["codes"], **{m: year(clock_now) for m in markets}}}


def gate(sheet: dict, place: dict, clock_now: int, way: bool = True) -> str:
    """進不去的原因（空＝可以進）。way：有沒有門路（way_in）。"""
    name = place["name"]
    if place["type"] == CULTIVATOR and not way:
        return "沒有門路，進不了修士黑市"
    if sheet["market_bans"].get(name, -1) > clock_now:
        return f"你被{name}列入黑名單，進不去"
    if sheet["codes"].get(name) != year(clock_now):
        return f"暗號不對，被擋在{name}門外"
    return ""


def brawl(action: str, words: str) -> bool:
    """在黑市裡動手、偷東西。"""
    return action == J.COMBAT or action == J.STEALTH and any(w in words for w in crime.WORDS[crime.THEFT])


def ban(sheet: dict, market: str, clock_now: int) -> dict:
    return {**sheet, "market_bans": {**sheet["market_bans"], market: clock_now + SHICHEN_PER_YEAR}}


def robbed(sheet: dict) -> tuple[dict, str]:
    """黑吃黑：被搶走兩成的錢與靈石。"""
    money, stones = int(sheet["money"] * ROB_SHARE), int(sheet["spirit_stones"] * ROB_SHARE)
    if not money and not stones:
        return sheet, "出了黑市被人跟上，對方搜不到值錢的東西，悻悻走了"
    return ({**sheet, "money": sheet["money"] - money, "spirit_stones": sheet["spirit_stones"] - stones},
            f"出了黑市被人跟上，搶走了 {money} 凡人錢、{stones} 塊靈石")


# ── 經營的集團與護衛（第一次進去時生成）────────────────────────────────────
def operator(factions: list[dict], place: dict) -> dict | None:
    key = CULTIVATOR if place["type"] == CULTIVATOR else place["name"]
    return next((f for f in factions if key in f.get("traits", {}).get(KEY, ())), None)


def found(rng: random.Random, place: dict, factions: list[dict], main_sect: str, taken: set[str], clock_now: int,
          land: str = "人族") -> tuple[list[dict], list[dict], list[dict], list[tuple[str, dict]]]:
    """還沒有人經營的黑市：生成（或指派）集團、私交、護衛。
    回傳（新勢力, 新羈絆, 新 NPC 的生成資料, 要改 traits 的舊勢力 [(名字, traits)]）。"""
    new_factions, bonds, retrait = [], [], []
    if place["type"] == CULTIVATOR:
        name = next((n for n in SYNDICATES if n not in taken), "")
        boss = {"name": name, "type": "商會", "location": "", "traits": {KEY: [CULTIVATOR]}}
        new_factions.append(boss)
    else:
        gangs = [f for f in factions if f["type"] in GANGS and f["location"] == place["parent"] and not f["traits"]]
        if gangs and rng.random() < 0.5:
            boss = gangs[0]
            retrait.append((boss["name"], {KEY: [place["name"]]}))
        else:
            boss = {"name": f"{place['parent']}地下幫", "type": "幫派", "location": place["parent"],
                    "traits": {KEY: [place["name"]]}}
            new_factions.append(boss)
        if main_sect and rng.random() < 0.5:
            bonds.append(_bond(society.FACTION, boss["name"], main_sect, "盟友", clock_now))
    who = newcomer.roll(rng, land)
    guard = names.person_names(rng, taken | {boss["name"]}, 1, **who)[0]
    people = [{"name": guard, **who, "job": "護衛", "profile": f"{place['name']}的護衛。", "location": place["name"], "age_band": npc.PRIME,
               "power_tier": GUARD_POWER[place["type"]], "goal": "逐利", "goal_target": "",
               **{t: rng.choice(list(npc.TRAIT_LEVELS.values())) for t in npc.TRAITS}}]
    bonds.append(_bond(society.NPC, guard, boss["name"], "成員", clock_now))
    return new_factions, bonds, people, retrait


def _bond(a_kind: str, a: str, b: str, type_: str, clock_now: int) -> dict:
    return {"a_kind": a_kind, "a": a, "b_kind": society.FACTION, "b": b, "type": type_, "clock_shichen": clock_now,
            "turn_no": 0}


def allied(factions: list[dict], bonds: list[dict], place: dict, main_sect: str) -> bool:
    """凡人黑市的集團跟本山有私交：法器會流進來。"""
    boss = operator(factions, place)
    return bool(boss and main_sect) and place["type"] == MORTAL and any(
        b["type"] == "盟友" and {b["a"], b["b"]} == {boss["name"], main_sect} for b in bonds)


# ── 奴隸商人 ─────────────────────────────────────────────────────────────
def slavers(place_type: str, legal: bool) -> bool:
    """這裡有沒有奴隸商人：販賣人口無罪的國家在坊市，有罪的國家只在黑市。"""
    return place_type in TYPES or legal and place_type == "坊市"


def trading(action: str, words: str, deal: str | None = None) -> str:
    """這回合跟奴隸商人做什麼：賣、買、或沒有。deal：讀懂的買賣找人（3-4d），None＝舊鏈看字。"""
    if action != J.SOCIAL or not any(w in words for w in SLAVE_WORDS):
        return ""
    if deal is not None:
        return deal if deal in ("買", "賣") else ""
    return "賣" if any(w in words for w in SELL_WORDS) else "買" if any(w in words for w in BUY_WORDS) else ""


def price(realm_lv: int) -> tuple[int, int]:
    """賣一個人得多少（凡人錢, 靈石）。"""
    return (PRICE_MORTAL, 0) if realm_lv == 0 else (0, PRICE_STONES * 2 ** (realm_lv - 1))


def bought(rng: random.Random, place: str, taken: set[str], land: str = "人族") -> dict:
    """從奴隸商人手上買來的人（生成資料，service 寫入時用 npc.roll_profile）：成年凡人。"""
    who = newcomer.roll(rng, land)
    return {"name": names.mortal_name(rng, taken, young=False, old=False, **who), **who,
            "profile": "從奴隸商人手上買來的人。", "location": place,
            "age_band": rng.choice((npc.YOUNG, npc.PRIME)), "power_tier": npc.MORTAL, "goal": "求道", "goal_target": "",
            **{t: rng.choice(list(npc.TRAIT_LEVELS.values())) for t in npc.TRAITS}}


def valid(sheet: dict) -> bool:
    return all(isinstance(d, dict) and all(isinstance(k, str) and isinstance(v, int) for k, v in d.items())
               for d in (sheet["codes"], sheet["market_bans"])) and isinstance(sheet["papers"], int)
