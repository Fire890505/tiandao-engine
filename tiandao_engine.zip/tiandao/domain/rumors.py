"""傳聞（第 10c-3a 步）：大事變成傳聞，依距離傳開、會走樣、會過時。純函式，不碰資料庫、不呼叫 AI。

規則（2026-10-05 與使用者一題一題定案，見 progress/WHITEPAPER.md 第 14 節「10c-3 傳聞與名聲的細節」，數字暫定）：
- 每則傳聞只記一次（哪裡、何時、多大、誰對誰做了什麼）；某地聽不聽得到，需要時才用「距離 ÷ 每天 20 公里」算，不逐日模擬。
- 傳聞記成欄位，聽到的句子當下由欄位組出（不解析文字）。走樣也是改欄位：結果誇大或縮小、兇手模糊、地點模糊。
- 「傳聞＋地點」決定版本：同一個地方聽到的固定，不同地方可能不同；事發當地不走樣。
"""
from __future__ import annotations

import math
import random

from .clock import SHICHEN_PER_DAY, SHICHEN_PER_YEAR

SMALL, MEDIUM, BIG = "小", "中", "大"
SIZES = (SMALL, MEDIUM, BIG)
KILL, WOUND, HURT, OLD_AGE, RISE, SUCCEED, NEW_HEAVEN = "殺人", "重傷", "傷人", "坐化", "突破", "繼位", "天道易主"
KEPT, BROKE, FAVOUR, FELL = "守約", "失約", "受恩", "殞落"
DISPEL = "打散"                  # 第 11-2 步：打散亡者（target＝「某某的殭屍」）
TALE, CLEARED = "怪談", "破怪談"  # 第 19-1 步：某地被怪談籠罩（subject＝地點、detail＝傳言）、某人破了某地的怪談
LEGEND = "傳說"                  # 第 19-2 步：都市傳說流傳的說法（subject＝中心地點、detail＝說法；生靈級，傳不遠）
ODD, WANTED = "怪事", "通緝"       # 第 16e 節：在凡人面前施展修為被看見（隱世＝怪事、打壓＝通緝；subject＝主角）
RITE, PREP = "玩法", "張羅"        # 19-3 儀式型：某地流傳的玩法（subject＝流傳地、detail＝錯的玩法）；有人在準備（subject＝他、detail＝主題）
DISASTER, RELIEF = "天災", "賑災"     # 16j：某地（或整個區域）鬧天災（subject＝地點、detail＝狀況的一句）；某人在災地救災
AFFAIRS = "國事"                    # 16k：國與國開戰、議和、結盟（subject＝國、detail＝一句）；傳遍天下
FORCED = "強拆怪談"                  # 16l 第 6-6 題：某人仗著境界強行打散某地的怪談
ASCENDED = "飛升"                    # 16l：某人破空飛升；傳遍天下
AFTERMATH = "餘波"                   # 16v 第 28 題：線頭過期的收場（subject＝地點、detail＝一句）
FATED = "命事"                       # 第 122b 批：特殊命 NPC 的章收場（subject＝他住的地方、detail＝一句）；小事，傳不遠
CHAT = "閒話"                        # 第 7-2a 批：村鎮小事傳開（subject＝那一處、detail＝一句）；傳不遠
LOCAL = "地方"                       # 第 7-3a 批：地方牌（subject＝那一處、detail＝一句）
SLANDER = "壞話"                     # 第 7-2b 批（㉘）：某人說你的壞話（subject＝你、target＝說的人、detail＝名聲的方向）；小事
FACTION = "勢力"                     # 第 7-3b1a 批：立約、勢力牌（subject＝勢力、detail＝一句）
KINDS = (KILL, WOUND, HURT, OLD_AGE, RISE, SUCCEED, NEW_HEAVEN, KEPT, BROKE, FAVOUR, FELL, DISPEL, TALE, CLEARED, LEGEND,
         ODD, WANTED, RITE, PREP, DISASTER, RELIEF, AFFAIRS, FORCED, ASCENDED, AFTERMATH, FATED, CHAT, SLANDER, LOCAL, FACTION)
CIRCLES = ("山野", "市井", "路上", "官面", "修行")   # 消息圈（第 9b 批，domain/circles.py）：每種傳聞歸一個圈（第 9-12 題）
_BY = {"山野": (TALE, CLEARED, DISPEL, LEGEND, RITE, PREP, ODD), "市井": (CHAT, SLANDER, FAVOUR, KEPT, BROKE, LOCAL, FATED),
       "路上": (AFFAIRS, DISASTER, AFTERMATH), "官面": (KILL, WOUND, HURT, WANTED, RELIEF),
       "修行": (RISE, SUCCEED, OLD_AGE, FELL, ASCENDED, NEW_HEAVEN, FORCED, FACTION)}
CIRCLE = {k: c for c, ks in _BY.items() for k in ks}
PACE = {"路上": 0.5, "市井": 2}   # 第 9-10 題丙：路上的事快一倍；市井的事出了鎮慢一倍、TOWN_KM 內當天就到
TOWN_KM = 3
LEAP = "連破"                    # 只出現在走樣的版本：「突破一層」傳成「連破兩層」
STRONG_LV, HIGH_RISE_LV = 4, 5   # 一方強者（被殺、坐化算得比較大）；突破到這一層以上算大事

# ── 傳多遠、多快、多久 ───────────────────────────────────────────────────
KM_PER_DAY = 20
REACH_KM = {SMALL: 50, MEDIUM: 300, BIG: None}          # None＝傳遍天下
FAR_DAYS = 30                                            # 兩地沒有路線相連：當成很遠，只有大事、30 天
LIFETIME_YEARS = {SMALL: 0.5, MEDIUM: 3, BIG: 30}        # 過了就沒人在講
LISTENING = {**{t: SIZES for t in ("城鎮", "坊市", "客棧", "宗門")},
             **{t: (MEDIUM, BIG) for t in ("村落", "住家")},
             **{t: (BIG,) for t in ("荒野", "秘境", "廢墟")}}
DEFAULT_LISTENING = (MEDIUM, BIG)                        # 還沒分類的地點：比照村落

# ── 走樣 ─────────────────────────────────────────────────────────────────
DISTORT = ((0, 0.0), (3, 0.1), (20, 0.25))               # 事發當地不走樣、鄰近 10%、半日路程 25%
FAR_DISTORT = 0.4                                        # 更遠
SWAPPED = {KILL: WOUND, WOUND: KILL, HURT: WOUND, RISE: LEAP}   # 結果誇大或縮小
HAS_TARGET = (KILL, WOUND, HURT, KEPT, BROKE, FAVOUR, DISPEL)


def make(kind: str, subject: str, *, place: str, when: int, target: str = "", detail: str = "", lv: int = 0,
         subject_lv: int = 0, life: str = "") -> dict:
    """一則新傳聞。lv：被殺或受傷者的境界、突破後的境界、坐化者的境界（決定大小，名聲也用）；
    subject_lv：做事的人的境界；life：做事的是哪一生的主角（NPC 之間的事是空字串）。"""
    return {"kind": kind, "subject": subject, "target": target, "place": place, "detail": detail, "lv": lv,
            "subject_lv": subject_lv, "life": life, "size": size_of(kind, lv), "clock_shichen": when}


def size_of(kind: str, lv: int) -> str:
    if kind in (NEW_HEAVEN, AFFAIRS, ASCENDED):
        return BIG
    if kind == KILL:
        return BIG if lv >= STRONG_LV else MEDIUM
    if kind in (OLD_AGE, DISPEL):
        return MEDIUM if lv >= STRONG_LV else SMALL
    if kind in (TALE, CLEARED, FORCED):   # 領域（第 19-1 步）：lv＝規模的戰力（家 0、村落 1、鄉鎮 3、城市 4）
        return BIG if lv >= 3 else MEDIUM if lv >= 1 else SMALL
    if kind == RISE:
        return BIG if lv >= HIGH_RISE_LV else MEDIUM
    return MEDIUM if kind in (SUCCEED, FELL, WANTED, DISASTER, RELIEF, AFTERMATH, LOCAL, FACTION) else SMALL


# ── 傳到了沒 ─────────────────────────────────────────────────────────────
def arrival(rumor: dict, km: int | None) -> int | None:
    """傳到距離 km 公里的地方的時刻；傳不到回傳 None。km 為 None＝兩地沒有路線相連（或事發在遠方）。
    消息圈（第 9-10 題丙）：修行的事傳的範圍多一檔；快慢照 PACE。"""
    c = CIRCLE.get(rumor["kind"])
    size = SIZES[min(SIZES.index(rumor["size"]) + 1, 2)] if c == "修行" else rumor["size"]
    if km is None:
        return rumor["clock_shichen"] + FAR_DAYS * SHICHEN_PER_DAY if size == BIG else None
    reach = REACH_KM[size]
    if reach is not None and km > reach:
        return None
    pace = 0 if c == "市井" and km <= TOWN_KM else PACE.get(c, 1)
    return rumor["clock_shichen"] + math.ceil(km * pace / KM_PER_DAY) * SHICHEN_PER_DAY


def still_told(rumor: dict, clock_now: int) -> bool:
    return clock_now - rumor["clock_shichen"] <= LIFETIME_YEARS[rumor["size"]] * SHICHEN_PER_YEAR


def audible(rumor: dict, place_type: str) -> bool:
    """這種地方聽不聽得到這麼大的事：城鎮坊市消息靈通，荒野只聽得到大事。"""
    return rumor["size"] in LISTENING.get(place_type, DEFAULT_LISTENING)


# ── 走樣與句子 ───────────────────────────────────────────────────────────
def distort_chance(km: int | None) -> float:
    if km is None:
        return FAR_DISTORT
    return next((chance for limit, chance in DISTORT if km <= limit), FAR_DISTORT)


def version(rumor: dict, km: int | None, rng: random.Random) -> dict:
    """在距離 km 的地方聽到的版本。rng 由「傳聞＋地點」決定，所以同一個地方聽到的固定。
    走樣時三選一：結果誇大或縮小、做事的人變模糊、地點變模糊；選到的不適用就換下一種。"""
    if rng.random() >= distort_chance(km):
        return dict(rumor)
    ways = ["result", "who", "where"]
    start = rng.randrange(3)
    for way in ways[start:] + ways[:start]:
        if way == "result" and rumor["kind"] in SWAPPED:
            return {**rumor, "kind": SWAPPED[rumor["kind"]]}
        if way == "who" and rumor["kind"] in HAS_TARGET:
            return {**rumor, "subject": ""}
        if way == "where" and rumor["place"]:
            return {**rumor, "place": ""}
    return dict(rumor)


AWAY_WORD, SOMEWHERE = "遠方", "某處"


def text(v: dict) -> str:
    """把一個版本組成一句話。做事的人不明時改用被動句。"""
    s, t, d = v["subject"], v["target"], v["detail"]
    place = SOMEWHERE if not v["place"] else AWAY_WORD if v["place"].startswith("（") else v["place"]
    if not s:
        return {KILL: f"{t}在{place}被人殺了，不知是誰下的手", WOUND: f"{t}在{place}被人打成重傷",
                HURT: f"{t}在{place}遭人出手所傷", KEPT: f"有人兌現了對{t}的承諾", BROKE: f"有人失信於{t}",
                FAVOUR: f"{t}在{place}受了旁人的恩惠", DISPEL: f"{place}的{t}被人打散了"}[v["kind"]]
    return {KILL: f"{s}在{place}殺了{t}", WOUND: f"{s}在{place}重創了{t}", HURT: f"{s}在{place}出手傷了{t}",
            OLD_AGE: f"{s}在{place}壽終坐化", RISE: f"{s}突破至{d}", LEAP: f"{s}連破兩層境界",
            SUCCEED: f"{s}繼任{d}首領", NEW_HEAVEN: f"{s}身合大道，天道易主", KEPT: f"{s}兌現了對{t}的承諾",
            BROKE: f"{s}失信於{t}", FAVOUR: f"{t}在{place}受了{s}的恩惠", FELL: f"{s}殞落於{place}",
            DISPEL: f"{s}在{place}打散了{t}", TALE: f"聽說{s}{d}", CLEARED: f"{s}破了{place}的怪談",
            LEGEND: f"聽說{s}一帶：{d}", ODD: f"聽說{place}有人施展了凡人做不到的手段",
            WANTED: f"{s}在{place}{d or '被看出是修士'}，正被官府通緝", RITE: f"聽說{s}一帶流傳一個玩法：{d}",
            PREP: f"{s}最近在張羅{d}要用的東西", DISASTER: f"聽說{s}{d}", RELIEF: f"{s}在{place}賑濟災民",
            AFFAIRS: f"聽說{d}", FORCED: f"{s}仗著修為，強行打散了{place}的怪談",
            ASCENDED: f"{s}在{place}破空飛升，從此不在此界", AFTERMATH: f"聽說{d}", FATED: f"聽說{d}", CHAT: f"聽說{d}", LOCAL: f"聽說{d}", FACTION: f"聽說{d}", SLANDER: f"{t}到處說{s}的不是"}[v["kind"]]
