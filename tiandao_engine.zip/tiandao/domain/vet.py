"""3-7b：玩家寫的長期文字（背景、外貌、搭配卡、退隱心願）交給說書人以前查一次：夾指令、把能力寫成既定事實就退回。
收尾甲：9B 分不出指令和既定事實，合成一欄「有沒有問題」，退回的話也只有一種。"""
from __future__ import annotations

import re


def joined(fields: dict[str, str]) -> str:
    """送去檢查的一段：每欄一行「欄名：內容」，空的不送。"""
    return "\n".join(f"{k}：{v}" for k, v in fields.items() if v)


def _found(line: str, text: str) -> bool:
    """抄出的句子在不在原文（模型會自己加空格，比的時候去掉）。"""
    bare = lambda s: re.sub(r"\s", "", s)   # noqa: E731
    return bool(bare(line)) and bare(line) in bare(text)


def problem(sheet: dict, fields: dict[str, str]) -> str:
    """模型的答案 → 退回的話；空＝放行。抄出的那句不在原文就只給一般說法。"""
    if sheet.get("有沒有問題") != "有":
        return ""
    line = (sheet.get("哪一句") or "").strip()
    return f"這句不能寫進設定：「{line}」，請改寫。" if _found(line, joined(fields)) else "有些地方不能寫進設定（下指令，或把境界、寶物、別人聽命寫成已經成真），請改寫。"


def blamed(sheet: dict, fields: dict[str, str]) -> list[str]:
    """匯入用：被擋下的欄；抄的句子對不上哪一欄就全部算。"""
    line = (sheet.get("哪一句") or "").strip()
    return ([k for k, v in fields.items() if v and _found(line, f"{k}：{v}")] or [k for k, v in fields.items() if v]) \
        if problem(sheet, fields) else []
