"""Python 安排的新人物登場（WHITEPAPER 12.6 方案甲）。純函式，不碰資料庫、不呼叫 AI。

小模型不太會在敘事裡替新人物取名，所以改由 Python 決定「這回合有誰登場」，連同年紀、實力、目標、性格一起準備好，
當成事實交給說書人；AI 只寫外貌、身分個性、說話風格。規則（2026-10-05 定案，數字暫定）：
- 只在探索、社交、觀察、移動的回合；機率依地點類型；一回合最多 1 人；在場已有 MAX_PRESENT 人以上不安排。
- 目標只抽不需要對象的幾種（守護的對象＝登場地點）；復仇、報恩、追隨、尋物由經歷產生（第 10b 步）。
"""
from __future__ import annotations

import random

from . import inspiration, judgment, lineage, looks as outfit, names, npc, races

NATURES = (judgment.EXPLORE, judgment.SOCIAL, judgment.OBSERVE, judgment.MOVE)
BUSY_PLACES = ("城鎮", "坊市", "客棧", "宗門", "武館", "衙署", "鏢局", "公會", "藥鋪", "當鋪", "鐵匠鋪")
QUIET_PLACES = ("村落", "住家")
WILD_PLACES = ("荒野", "秘境", "廢墟")
CHANCE = {**{t: 0.4 for t in BUSY_PLACES}, **{t: 0.25 for t in QUIET_PLACES}, **{t: 0.1 for t in WILD_PLACES}}
DEFAULT_CHANCE = 0.2          # 還沒分類的地點
MAX_PRESENT = 4

AGE_WEIGHTS = {npc.YOUNG: 35, npc.PRIME: 35, npc.ELDER: 20, npc.TEEN: 7, npc.CHILD: 3}
POWER_WEIGHTS = {npc.MORTAL: 55, npc.NOVICE: 25, npc.ADEPT: 13, npc.POWERFUL: 6, npc.UNFATHOMABLE: 1}
GOALS = ("求道", "逐利", "求名", "隱居", "守護")
FAVOURED_GOAL = {"宗門": "求道", **{t: "逐利" for t in ("坊市", "城鎮", "客棧", "藥鋪", "當鋪", "鐵匠鋪")},
                 **{t: "隱居" for t in WILD_PLACES}}
FAVOUR = 3                    # 地點對味的目標，權重 ×3


def chance(nature: str, place_type: str, present: int) -> float:
    """這回合安排新人物登場的機率。"""
    if nature not in NATURES or present >= MAX_PRESENT:
        return 0.0
    return CHANCE.get(place_type, DEFAULT_CHANCE)


def arrange(rng: random.Random, *, nature: str, place: str, place_type: str, present: int,
            taken: set[str], sure: bool = False, land: str = races.HUMAN, town: dict | None = None) -> dict | None:
    """擲骰決定有沒有人登場；有的話回傳他的資料（欄位與 AI 提案審核後的人物相同，描述留空）。
    sure：玩家在找人而這裡沒人（故事第 2 題），不用擲骰。"""
    if not sure and rng.random() >= chance(nature, place_type, present):
        return None
    return make(rng, place=place, place_type=place_type, taken=taken, land=land, town=town)


def roll(rng: random.Random, land: str = races.HUMAN, town: str = "") -> dict:
    """一個當地人的種族、性別、支系（取名前要先知道）。九成本族（16k）；town：本族的人七成跟這個聚落的主要支系。"""
    race = races.local(rng, land)
    return {"race": race, "gender": rng.choice(npc.GENDERS), "lineage": lineage.local(rng, race, town if race == land else "")}


def make(rng: random.Random, *, place: str, place_type: str, taken: set[str], land: str = races.HUMAN,
         town: dict | None = None, age: str = "", role: str = "", gender: str = "", shun: frozenset[str] = frozenset()) -> dict | None:
    """準備一個登場的人（不擲機率：事件需要新面孔時也用這個）。名字用完了回傳 None。
    名字的語感看實力（第 16b 步）：凡人用凡俗的名字（當地大姓七成同姓），修士用修行的名字。
    land：這裡是哪一族的地盤，名字照這個人的種族和性別取；town：所在的聚落，家級的地方看它（16u）。
    age、role、gender：路線定好的人，年齡層、職業、性別照寫（性別空著就隨機），是有身分的凡人，名字只用姓加名。"""
    where, kind = (town["name"], town["type"]) if town else (place, place_type)
    age, power, who = age or _pick(rng, AGE_WEIGHTS), npc.MORTAL if role else _pick(rng, POWER_WEIGHTS), roll(rng, land, where)
    who = {**who, "gender": gender or who["gender"]}
    if power == npc.MORTAL:
        name = names.mortal_name(rng, taken, young=age in (npc.CHILD, npc.TEEN), old=age in (npc.PRIME, npc.ELDER),
                                 clan=names.local_clan(where, kind, who["race"], who["lineage"]), plain=bool(role), shun=shun, **who)
    else:
        name = next(iter(names.person_names(rng, taken, 1, **who)), "")
    if not name:
        return None
    goal = _pick(rng, {g: FAVOUR if FAVOURED_GOAL.get(place_type) == g else 1 for g in GOALS})
    trade = role or job(rng, age, power, place_type, kind)
    return {"name": name, **who, "age_band": age, "power_tier": power, "job": trade,
            "goal": goal, "goal_target": place if goal == "守護" else "",
            "looks": looks(rng, age, who["gender"], trade, power, who["race"]),
            **{t: npc.TRAIT_LEVELS[rng.choice(tuple(npc.TRAIT_LEVELS))] for t in npc.TRAITS}}


def job(rng: random.Random, age: str, power: str, *places: str) -> str:
    """職業（16u 外貌第二批）：成年的凡人照所在地抽；前面的地點優先。修士和小孩沒有。"""
    table = outfit.TABLE["職業"]
    pool = next((table[p] for p in places if p in table), ())
    return rng.choice(pool) if pool and power == npc.MORTAL and age not in (npc.CHILD, npc.TEEN) else ""


def kin(p: dict) -> dict:
    """這個人的性別和支系（16u）：有定的照用，沒定的照名字擲，同一個名字每次一樣。"""
    rng = random.Random(f"{p['name']}:kin")
    return {"gender": p.get("gender") or rng.choice(npc.GENDERS),
            "lineage": p.get("lineage") or lineage.roll(rng, p.get("race", lineage.HUMAN))}


OLD_HAIR = ("灰白", "銀白", "花白")


def looks(rng: random.Random, age: str, gender: str = "", trade: str = "", power: str = npc.MORTAL, race: str = races.HUMAN) -> str:
    """16m 第 4 題：外貌由 Python 定、存起來（說書人照著寫，不會把青年寫成老農）。
    16u 外貌第二批：和玩家共用搭配卡，存句型版；衣著看職業，沒有職業的看實力。族徵由 lineage.who 另外給。"""
    minor = age in (npc.CHILD, npc.TEEN)
    skip = inspiration.skipped(gender, minor)
    body, eyes = ([v for v in inspiration.APPEARANCE[dim] if v not in skip] for dim in ("身形", "眼"))
    rank = "" if power == npc.MORTAL else outfit.MASTER if power in (npc.POWERFUL, npc.UNFATHOMABLE) else outfit.ADEPT
    card = outfit.card(rng, gender=gender, minor=minor, origin=trade if trade in outfit.TABLE["衣著"] else rank, race=race,
                       picks={"hair": rng.choice(OLD_HAIR)} if age == npc.ELDER else None)
    return f"{rng.choice(body)}，{rng.choice(eyes)}。{outfit.text(card, '')}"


def describe(p: dict) -> str:
    """給說書人的設定：「曹舊，老年，凡人，目標：隱居；性情：野心低、善念高……」。未成年要標明（底線）。"""
    minor = "，未成年" if p["age_band"] in (npc.CHILD, npc.TEEN) else ""
    goal = p["goal"] + (f"（{p['goal_target']}）" if p["goal_target"] else "")
    hostile = ("；對主角帶著一股說不清來由的敵意" if p.get("heaven_role")   # 天道派來的宿敵（第 18-2b 步，不明說）
               else f"；{p['errand']}" if p.get("errand") else "")   # 追捕者、宗門派來的人（16e.1、16h）
    kind = lineage.who(p)   # 性別、他族（16k、16u）
    face = f"；外貌：{p['looks']}（照這個寫）" if p.get("looks") else ""
    return (f"{p['name']}{'，' + kind if kind else ''}，{p['age_band']}{minor}，{p['power_tier']}，目標：{goal}；性情：{npc.traits_text(p)}"
            f"{face}{hostile}")


def _pick(rng: random.Random, weights: dict[str, int]) -> str:
    return rng.choices(list(weights), weights=list(weights.values()))[0]
