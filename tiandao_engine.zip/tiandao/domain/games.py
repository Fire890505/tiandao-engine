"""天道的棋局（第 18-2a 步）：劫、小劫數、心魔、餌。要不要落子、骨架、勝負、獎懲、戰績。純函式。

規則（2026-10-06 與使用者一題一題定案，見 progress/WHITEPAPER.md 第 13 節「第 18-2 步」，數字暫定）：
- 劫：衝擊大境界就是渡劫；注視越重劫越重（breakthrough.odds），突破成敗＝勝負，不另加獎懲。
- 平時：看螻蟻以上每回合擲「注視 ÷ 10 %」，落子就蓋過這回合的一般事件；同一時間最多一盤，分勝負後冷卻一個月。
- 小劫數、心魔是天道的應對型事件，放過＝輸。餌：寫收下＝輸、寫拒絕＝贏、觀察成功＝識破也贏、做別的＝放過＝輸。
- 贏：修為 +10～20、主修親和系感悟 +10、注視 +3（不乘執念）。輸：小劫數扣兩成氣血（不致瀕死）、
  心魔留下「心魔纏身」、收下餌＝得到東西並欠天道一手（注視 +10，下一盤不擲機率、一個月內必落、輸了 ×1.5）。
- 宿敵（第 18-2b 步）：第四種手段，另外算（同時最多一個、分勝負後一年才有下一個）。先挑這一生結怨的人，
  沒有就安排新人物；擊敗或化解＝勝、跟他交手陷入瀕死或殞落＝負、他另因別的原因死了＝作廢。勝的獎勵重一級。
"""
from __future__ import annotations

import random
from dataclasses import dataclass

from . import items, laws
from . import judgment as J
from . import status as status_mod
from . import newcomer, npc, opinion
from .clock import SHICHEN_PER_MONTH, SHICHEN_PER_YEAR
from .incident import Seed

TRIAL, CALAMITY, DEMON, BAIT, RIVAL = "渡劫", "小劫數", "心魔", "餌", "宿敵"
ERASE = "抹殺之劫"                   # 16l：破格期的倒數到了（domain/breach.py），當場分勝負
WIN, LOSE, VOID = "勝", "負", "作廢"
WEIGHTS = {CALAMITY: 4, DEMON: 3, BAIT: 3, RIVAL: 2}
RIVAL_COOLDOWN = SHICHEN_PER_YEAR    # 宿敵分勝負後，過一年才會有下一個（第 18-2b 步）
RIVAL_FRIENDLY = 20                  # 好感升到「友善」：化解
RIVAL_START = [opinion.hit(opinion.HEAVEN, opinion.LIKE, opinion.BIG, -1)]   # 天道派來的新人物：起點冷淡，不看名聲
RIVAL_DOWN = ("重傷", "殞落")         # 交手把他打成這樣：擊敗
REWARDS = {RIVAL: ((20, 40), 20, 5)}  # 勝的獎勵（修為, 感悟, 注視）；其他手段用 WIN_*
GAZE_PER_PERCENT = 10          # 每回合落子機率：注視 ÷ 10 %
COOLDOWN = SHICHEN_PER_MONTH   # 一盤分勝負後，過一個月才落下一盤
DEBT_CHANCE, DEBT_SPAN, DEBT_FACTOR = 0.5, SHICHEN_PER_MONTH, 1.5
WON, OWED = "破局", "因果"     # 注視的來源（不在執念表裡，不乘倍率）
NUMERALS = "零一兩三四五六七八九十"   # 戰績寫成中文：給說書人的要點不放阿拉伯數字（台詞不得含數字）
WIN_CULTIVATION, WIN_INSIGHT, WIN_GAZE = (10, 20), 10, 3
CALAMITY_HP, DEMON_STATUS, DEMON_MAGNITUDE, OWED_GAZE = 0.2, "心魔纏身", 40, 10
STONES = (2, 4)                # 餌的靈石：一般事件的 5 倍（× 2 的境界次方）
BAIT_STONES_FACTOR = 5
TAKE = ("收下", "接受", "拿走", "收了", "接過")
REFUSE = ("拒絕", "婉拒", "不要", "不收", "謝絕", "推辭")

SEEDS = (
    Seed(CALAMITY, "天雷擦身", "晴空裡毫無來由地劈下一道雷，擦著你的肩頭落地，餘威還在身上亂竄", (J.ENDURE,)),
    Seed(CALAMITY, "靈氣逆沖", "體內的靈氣忽然倒轉，逆著經脈往回沖，像要把你從裡面撕開", (J.CULTIVATE, J.ENDURE)),
    Seed(CALAMITY, "無妄之災", "頭頂的山石無端崩落，碎石如雨，退路也被堵住了一半", (J.COMBAT, J.ENDURE)),
    Seed(DEMON, "心魔叩門", "心底有個聲音一遍遍數落你的過往，句句都戳在最痛的地方", (J.ENDURE,)),
    Seed(DEMON, "舊夢纏身", "閉眼就是舊日的夢，夢裡的人一個個回頭問你，為何要走這條路", (J.ENDURE,)),
    Seed(BAIT, "路遇贈丹", "路旁一位看不清面目的人含笑遞來{what}，說是與你有緣", (J.OBSERVE,)),
    Seed(BAIT, "古洞遺卷", "山壁的裂縫裡露出一處古洞，石台上端端正正擺著{what}，像在等人來取", (J.OBSERVE,)),
    Seed(BAIT, "天降橫財", "腳下的土裡露出一角錦囊，裡頭是{what}，四下卻一個人也沒有", (J.OBSERVE,)),
)
BAIT_SEEDS = {"路遇贈丹": "丹", "古洞遺卷": "功法", "天降橫財": "靈石"}
REPLY = {"天雷擦身": ("咬牙硬撐雷勁", J.ENDURE), "靈氣逆沖": ("運功壓住逆沖的靈氣", J.CULTIVATE),
         "無妄之災": ("硬扛落石殺出一條路", J.COMBAT), "心魔叩門": ("守住心神，不為所動", J.ENDURE),
         "舊夢纏身": ("咬牙撐過舊夢", J.ENDURE)}
OMENS = ("天色無端一暗", "風聲裡夾著一聲輕笑", "遠處的鳥雀同時噤聲", "地上的影子慢了半拍才跟上",
         "一片落葉懸在半空，久久不落", "耳邊響起若有若無的落子聲")


@dataclass(frozen=True)
class Move:
    """天道這一手：事件骨架（宿敵沒有，為 None）、異兆、餌的內容（{"name", "tier", "count"} 或 {"stones"}）、
    是不是討因果（輸了 ×1.5）。"""
    seed: Seed | None
    omen: str
    bait: dict | None = None
    heavy: bool = False

    @property
    def kind(self) -> str:
        return self.seed.kind if self.seed else RIVAL

    def extra(self) -> dict:
        """記進回合紀錄的事件（incident.record）要多帶的欄位。"""
        return {"omen": self.omen, "bait": self.bait, "heavy": self.heavy}


def move(rng: random.Random, sheet: dict, stage: int, *, can: bool, open_game: bool, last_end: int | None,
         clock_now: int, rival_ok: bool = False, calamity: float = 1) -> Move | None:
    """天道這回合要不要落子（看螻蟻以上，或欠了因果）。can：這回合能不能有事件（閉關、戰鬥、瀕死等不行）。
    open_game、last_end 只管一般棋局；宿敵另外算（rival_ok：沒有宿敵、上個宿敵分勝負滿一年，第 18-2b 步）。
    calamity：小劫數的權重倍數（16l：破格期最後三成時間）。"""
    if not can:
        return None
    debt = sheet["debt"]
    if debt is not None and not open_game:
        if clock_now - debt < DEBT_SPAN and rng.random() >= DEBT_CHANCE:
            return None
        kind = rng.choice((CALAMITY, DEMON))
    else:
        cooling = last_end is not None and clock_now - last_end < COOLDOWN
        normal = not open_game and not cooling and debt is None
        kinds = [k for k in WEIGHTS if (rival_ok if k == RIVAL else normal)]
        if stage < 1 or not kinds or rng.random() >= sheet["gaze"] / GAZE_PER_PERCENT / 100:
            return None
        kind = rng.choices(kinds, weights=[WEIGHTS[k] * (calamity if k == CALAMITY else 1) for k in kinds])[0]
        if kind == RIVAL:
            return Move(None, rng.choice(OMENS))
    seed = rng.choice([s for s in SEEDS if s.kind == kind])
    return Move(seed, rng.choice(OMENS), _bait(rng, sheet, BAIT_SEEDS[seed.name]) if kind == BAIT else None,
                heavy=debt is not None)


def _bait(rng: random.Random, sheet: dict, what: str) -> dict:
    """餌比平常買得到的好一階：高一品階的破境丹或聚氣丹、親和靈根的功法、一般事件 5 倍的靈石。"""
    lv, top = sheet["realm_lv"], max(items.TIER_LABELS)
    if what == "靈石":
        return {"stones": rng.randint(*STONES) * 2 ** lv * BAIT_STONES_FACTOR}
    if what == "丹":
        return {"name": rng.choice((items.BREAK_PILL, items.QI_PILL)), "tier": min(lv + 1, top), "count": 1}
    books = [i for i in items.CATALOG.values() if i.kind == items.TECHNIQUE and i.tier and i.tier <= min(lv + 1, top)]
    fits = [i for i in books if set(i.affinity) & set(sheet["roots"])] or books
    book = rng.choice(fits)
    return {"name": book.name, "tier": book.tier, "count": 1}


def bait_text(bait: dict) -> str:
    return f"{bait['stones']} 靈石" if "stones" in bait else items.label(bait["name"], bait["tier"])


def scene(rec: dict) -> str:
    """給說書人的天道事件：場面＋異兆。不點明是天道。"""
    seed = next(s for s in SEEDS if s.name == rec["name"])
    text = seed.scene.replace("{what}", bait_text(rec["bait"]) if rec.get("bait") else "")
    ask = "主角還沒決定收不收" if rec["kind"] == BAIT else "主角還沒應對"
    return f"{text}。只寫到這件事發生、{ask}為止。異兆（只寫氣氛，不點明是誰的安排）：{rec['omen']}"


def replies(rec: dict) -> list[dict]:
    """天道落子那回合，Python 保證的選項（換掉說書人給的最後一個；餌換最後兩個）。"""
    if rec["kind"] == BAIT:
        return [{"text": f"收下{bait_text(rec['bait'])}", "nature": J.SOCIAL, "difficulty": J.NORMAL, "target": ""},
                {"text": "婉拒", "nature": J.SOCIAL, "difficulty": J.NORMAL, "target": ""}]
    text, nature = REPLY[rec["name"]]
    return [{"text": text, "nature": nature, "difficulty": "困難", "target": ""}]


def overlaps(rec: dict, text: str) -> bool:
    """說書人自己給的選項和保證的選項重複：餌是含收下／拒絕的字（反正照字判定），其他是同一句。"""
    if rec["kind"] == BAIT:
        return any(w in text for w in TAKE + REFUSE)
    return text in (r["text"] for r in replies(rec))


def decide(rec: dict, verdict: J.Judgment, player_input: str) -> bool:
    """上回合天道落的子，這回合分勝負（True＝主角勝）。放過一律算輸。"""
    if rec["kind"] != BAIT:
        return verdict.rolled and verdict.action_type in rec["answer"] and verdict.is_success
    if any(w in player_input for w in REFUSE):
        return True
    if any(w in player_input for w in TAKE):
        return False
    return verdict.action_type == J.OBSERVE and verdict.rolled and verdict.is_success   # 識破


def result(rec: dict, won: bool, sheet: dict, rng: random.Random, clock_now: int) -> tuple[dict, dict, list[str], list]:
    """勝負的獎懲。回傳（角色卡, 數值增減 mods（交給 effects.gain）, 事件, 注視 marks）。"""
    if won:
        return reward(sheet, rng, rec["kind"])
    factor = DEBT_FACTOR if rec.get("heavy") else 1
    if rec["kind"] == CALAMITY:
        return sheet, {"hp": -max(0, min(round(sheet["hp_max"] * CALAMITY_HP * factor), sheet["hp"] - 1))}, [], []
    if rec["kind"] == DEMON:
        statuses = list(sheet["statuses"])
        magnitude = min(100, round(DEMON_MAGNITUDE * factor))
        status_mod.add(statuses, status_mod.make(DEMON_STATUS, status_mod.NEGATIVE, magnitude, clock_now + SHICHEN_PER_MONTH))
        return {**sheet, "statuses": statuses}, {}, [f"留下狀態「{DEMON_STATUS}」（嚴重度 {magnitude}）"], []
    bait = rec["bait"]
    if "stones" in bait:
        return {**sheet, "debt": clock_now}, {"spirit_stones": bait["stones"]}, [], [(OWED, OWED_GAZE)]
    got = items.add(sheet, bait["name"], bait["tier"], bait["count"])
    return {**got, "debt": clock_now}, {}, [f"得到{bait_text(bait)}"], [(OWED, OWED_GAZE)]


def reward(sheet: dict, rng: random.Random, kind: str) -> tuple[dict, dict, list[str], list]:
    """破局所得：修為、主修親和系的感悟、注視（不乘執念）。宿敵比其他手段重一級。"""
    cultivation, insight, gaze = REWARDS.get(kind, (WIN_CULTIVATION, WIN_INSIGHT, WIN_GAZE))
    sheet, events = dict(sheet), []
    law = laws.insight_target(sheet) if sheet["realm_lv"] >= 1 else ""
    if law:
        sheet["insight"], events = laws.reward(sheet, law, insight)
    return sheet, {"cultivation": rng.randint(*cultivation)}, events, [(WON, gaze)]


# ── 宿敵（第 18-2b 步）──────────────────────────────────────────────────────
def rival_candidate(npcs: list[dict], relations: dict[str, dict], clock_now: int) -> str:
    """從這一生跟主角結怨的人挑宿敵：活著、成年、還不是天道角色、記仇或好感 −50 以下；挑好感最低的。沒有回傳空字串。"""
    pool = [(relations[p["name"]]["affinity"], p["name"]) for p in npcs
            if p["status"] == "ALIVE" and not p["heaven_role"] and p["name"] in relations
            and not npc.is_minor(p, clock_now)
            and (relations[p["name"]]["grudge"] or relations[p["name"]]["affinity"] <= npc.GRUDGE_BELOW)]
    return min(pool)[1] if pool else ""


def rival_newcomer(rng: random.Random, player_lv: int, *, place: str, place_type: str, taken: set[str],
                   land: str = "人族") -> dict | None:
    """沒有結怨的人：安排一個新人物當宿敵——青年或壯年、實力比主角低一階（最高一方強者），對主角帶著說不清的敵意。"""
    p = newcomer.make(rng, place=place, place_type=place_type, taken=taken, land=land)
    if p is None:
        return None
    tiers = [t for t, lv in npc.POWER_TIERS.items() if lv is not None]   # 凡人、初入修行、小有修為、一方強者
    power = tiers[max(0, min(player_lv - 1, len(tiers) - 1))]
    return {**p, "age_band": rng.choice((npc.YOUNG, npc.PRIME)), "power_tier": power, "heaven_role": RIVAL}


def rival_result(*, beaten: bool, affinity: int, down: bool, fallen: bool, gone: bool) -> str:
    """宿敵之局這回合的結果（空＝還沒分）。beaten：交手把他打成重傷或殺死；down：跟他交手陷入瀕死；
    fallen：主角殞落；gone：他因別的原因死了。同回合勝負都成立算勝。"""
    if beaten or affinity >= RIVAL_FRIENDLY:
        return WIN
    if down or fallen:
        return LOSE
    return VOID if gone else ""


def score(games: list[dict]) -> tuple[int, int]:
    """這一生的戰績（勝, 負）；games 是這一生已分勝負的棋局。"""
    return sum(g["result"] == WIN for g in games), sum(g["result"] == LOSE for g in games)


def score_text(games: list[dict]) -> str:
    """給天道開口的要點：「這一生主角破了它兩局、輸了一局」。"""
    wins, losses = score(games)
    if not wins and not losses:
        return "這一生主角還沒跟它交過手"
    return f"這一生主角破了它{_cn(wins)}局、輸了{_cn(losses)}局"


def _cn(n: int) -> str:
    return NUMERALS[n] if n <= 10 else "十多"


def title(kind: str, name: str = "") -> str:
    if kind in (TRIAL, ERASE):
        return kind
    return f"{kind}之局" + (f"（{name}）" if kind == RIVAL and name else "")


def reveal(kind: str, result: str, name: str = "") -> str:
    """揭曉的要點：「心魔之局，主角勝」「宿敵之局（某某），主角負」。"""
    return f"{title(kind, name)}，主角{result}"


def line(game: dict, when: str) -> str:
    """面板「與天道的對局」一行：第 3 年秋，心魔之局，你勝。"""
    return f"{when}，{title(game['kind'], game['name'])}，你{game['result']}"


def valid_record(rec) -> bool:
    """存檔裡回合紀錄的天道事件（匯入時檢查，下一回合結算要讀它）。"""
    seed = next((s for s in SEEDS if isinstance(rec, dict) and s.name == rec.get("name")), None)
    if seed is None or rec.get("kind") != seed.kind or rec.get("answer") != list(seed.answer) \
            or rec.get("omen") not in OMENS or not isinstance(rec.get("heavy"), bool) \
            or not (isinstance(rec.get("game"), str) and rec["game"].isdigit()):
        return False
    bait = rec.get("bait")
    if seed.kind != BAIT:
        return bait is None
    if not isinstance(bait, dict):
        return False
    if set(bait) == {"stones"}:
        return isinstance(bait["stones"], int) and 0 < bait["stones"] <= STONES[1] * 2 ** 11 * BAIT_STONES_FACTOR
    return (set(bait) == {"name", "tier", "count"} and isinstance(bait["name"], str) and bait["name"] in items.CATALOG
            and bait["count"] == 1
            and bait["tier"] in items.tiers_of(bait["name"]))


def new_game(session_id: str, no: int, kind: str, name: str, clock_now: int, turn_no: int, result: str = "") -> dict:
    """棋譜的一筆（渡劫當場就分勝負）。"""
    done = bool(result)
    return {"session_id": session_id, "no": no, "kind": kind, "name": name, "result": result,
            "started_shichen": clock_now, "started_turn": turn_no,
            "ended_shichen": clock_now if done else None, "ended_turn": turn_no if done else None}
