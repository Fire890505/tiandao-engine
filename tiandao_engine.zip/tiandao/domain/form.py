"""族徵的收放（WHITEPAPER 16u 族徵；數字暫定）。純函式。

- 金丹（Lv3）起能收能放：說一句「收起尾巴」「現出狐耳」就好。獸族是變形，魔族是斂住氣息。
- 金丹以前收不住，靠易容、遮掩或化形丹。藥效過了就現形。
- 壓不住：氣血掉到三成以下、判定大失敗、心魔發作、親人或同伴死在眼前，一半機率現形；魔族動手當場現形。
- 現形的時候在場的人都看見，當地傳開；私下看穿的人，同族和交情好的不說，其他人傳出去。
角色卡欄位：shown（玩家的選擇）、form_mode（races.SLIP、races.PILL）、form_until（到什麼時候）。
"""
from __future__ import annotations

import random
import re

from . import races
from .clock import SHICHEN_PER_DAY

PILL_DAYS, SLIP_DAYS, EXPOSED_DAYS = 3, 1, 360
SLIP_ODDS = 0.5
WOUNDED = 0.3             # 氣血低於這個比例算重傷
HAUNTED = "心魔纏身"
FRIEND = 30               # 好感到這裡就替你瞞著
EXPOSED = "身分傳開"       # 地點狀況
HIDE = ("收起", "收回", "藏起", "收斂", "斂住", "斂息", "壓住")
SHOW = ("現出", "放出", "露出", "顯出")
PARTS = ("耳", "尾", "獸徵", "族徵", "原形", "氣息", "魔氣", "角", "鱗")


def fields() -> dict:
    return {"shown": False, "form_mode": "", "form_until": 0}


def order(text: str) -> bool | None:
    """玩家要收還是要放：True 放、False 收、None 沒說。"""
    if not any(w in text for w in PARTS):
        return None
    return True if any(w in text for w in SHOW) else False if any(w in text for w in HIDE) else None


def rest(text: str) -> str:
    """拿掉收放的字，剩下的才看要不要判定（「藏起尾巴」不算潛行，「收起尾巴潛入城門」還是）。"""
    return re.sub("|".join(HIDE + SHOW), "", text)


def command(sheet: dict, show: bool) -> tuple[dict, str]:
    """照玩家的話收放，回傳（角色卡, 事實）。"""
    if sheet["realm_lv"] < races.FULL_FORM_LV:
        return sheet, "未能嘗試：要到金丹才收得住族徵"
    if sheet["form_mode"]:
        return sheet, "未能嘗試：" + ("現在壓不下去" if sheet["form_mode"] == races.SLIP else "化形丹的藥效還在")
    if sheet["shown"] == show:
        return sheet, "族徵本來就" + ("露著" if show else "收著")
    verb = ("你不再壓著氣息" if show else "你斂住了氣息") if sheet["race"] == races.DEMON else ("你現出了族徵" if show else "你收起了族徵")
    return {**sheet, "shown": show}, verb


def take(sheet: dict, clock_now: int) -> dict:
    """吃化形丹：暫時化成人形。"""
    return {**sheet, "form_mode": races.PILL, "form_until": clock_now + PILL_DAYS * SHICHEN_PER_DAY}


def slip(sheet: dict, clock_now: int) -> dict:
    return {**sheet, "form_mode": races.SLIP, "form_until": clock_now + SLIP_DAYS * SHICHEN_PER_DAY}


def tick(sheet: dict, clock_now: int) -> tuple[dict, list[str]]:
    """時間到了回到玩家的選擇。"""
    if not sheet["form_mode"] or clock_now < sheet["form_until"]:
        return sheet, []
    after = {**sheet, "form_mode": "", "form_until": 0}
    return after, ["化形丹的藥效過了"] if sheet["form_mode"] == races.PILL else []


def slipped(rng: random.Random, before: dict, after: dict, *, fumbled: bool, mourning: bool, fought: bool) -> bool:
    """這回合壓不壓得住。after：回合結束的角色卡。"""
    if after["race"] == races.HUMAN or races.visible(after):
        return False
    if after["race"] == races.DEMON and fought:
        return True
    low = after["hp"] < after["hp_max"] * WOUNDED <= before["hp"]
    haunted = any(s["name"] == HAUNTED for s in after["statuses"]) and not any(s["name"] == HAUNTED for s in before["statuses"])
    return (low or fumbled or haunted or mourning) and rng.random() < SLIP_ODDS


def exposed(states: list[dict], place: str, who: str, clock_now: int) -> bool:
    """主角是他族的事在這裡傳開了沒。狀況是整個世界的，所以看文字開頭是誰。"""
    return any(s["name"] == EXPOSED and s["place"] == place and s["text"].startswith(f"{who}是") and s["ends_shichen"] > clock_now
               for s in states)


def exposed_state(place: str, who: str, race: str, source: str, clock_now: int) -> dict:
    return {"place": place, "name": EXPOSED, "text": f"{who}是{race}的事在這裡傳開了"[:80], "source": source, "game": None,
            "started_shichen": clock_now, "ends_shichen": clock_now + EXPOSED_DAYS * SHICHEN_PER_DAY}


def tells(mine: str, theirs: str, affinity: int) -> bool:
    """私下看穿的人會不會傳出去：同族裝作沒看見，交情好的替你瞞著。"""
    return mine != theirs and affinity < FRIEND
