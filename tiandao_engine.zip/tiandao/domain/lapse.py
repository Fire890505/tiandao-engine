"""跳過的歲月（第 8-2 批，progress/時代更替.md 125-4、125-7）：換一世的跳躍、一回合一年以上（第 8-2-1 題甲），
跨過幾個百年就擲幾次。純函式；寫進資料庫在 GameService 的 _lapse。數字暫定。

- 勢力存續：朝廷、國家、仙宗不擲；有修士成員那時還活著（看壽元）的必續；其他照 KEEP。散了的據點是自己那種地點的，
  宗門改廢墟、武館和大宅改古蹟（第 8-2-3 題甲）。
- 改朝換代：每百年 1 - REIGN 換朝；國名不變，國號存 atlas["dynasty"]：國名 → {"name": 國號, "past": [前朝們]}（第 8-2-2 題乙），
  換朝時重擲一類國法。
- 接手（8-2 丙）：散掉、早於這個百年、還沒人接的位子，照種類 TAKE 擲；接了的 REVIVE 重開舊號（拿掉覆滅、記重開），
  其他新開（新名字、記前身，舊的記被誰接手）。據點改回原本那種地點；首領在跳躍結束時生（GameService._lapse）。
"""
from __future__ import annotations

import random

from . import crime, era, names, newcomer, npc, sect, space
from .clock import SHICHEN_PER_YEAR as YEAR

CENTURY = 100 * YEAR
KEEP = {"家族": 0.8, "商會": 0.7, "武館": 0.6, "幫派": 0.5, "宗門": 0.6}   # 宗門沒修士照武館（暫定）
TAKE = {"幫派": 0.7, "商會": 0.6, "武館": 0.4, "家族": 0.3, "宗門": 0.2}   # 空位每百年有人接手（第 8-2 丙 4 題乙）
REVIVE = 0.3                                                             # 接手的是重開舊號（第 3 題丙）
FELL, TAKEN, REOPEN, BEFORE = "覆滅", "接手", "重開", "前身"              # FELL 同 game/factions.FELL
REIGN = 0.7                                                              # 朝代撐過一百年（125-7，平均約 300 年）
SEAT = {"宗門": ("宗門", era.RUIN), "武館": ("武館", era.RELIC), "家族": ("住家", era.RELIC)}   # 據點是這種地點才改
HEAD = {"幫派": "幫主", "商會": "掌櫃", "家族": "家主"}                   # 凡間勢力的首領（宗門、武館照 sect.CAST）
BY = "lapse"                                                             # 接手的勢力的首領：NPC 的 created_by
DYNASTIES = ("大順", "大寧", "永安", "承平", "太和", "景隆", "天佑", "乾元", "長治", "嘉平", "昭明", "永熙")


def centuries(start: int, end: int) -> list[int]:
    """這段時間跨過的百年門檻（時刻）。"""
    return [c * CENTURY for c in range(start // CENTURY + 1, end // CENTURY + 1)]


def alive(p: dict, t: int) -> bool:
    """這個人在時刻 t 還活著沒（跳過的歲月沒補算 NPC，用壽元推）。"""
    birth = p.get("birth_shichen")
    return p["status"] == "ALIVE" and (birth is None or birth + npc.lifespan_years(p["realm_lv"], p.get("race") or "人族") * YEAR > t)


def survives(rng: random.Random, kind: str, crew: list[dict], t: int) -> bool:
    """這個勢力撐過這一百年沒：不在 KEEP 的不擲；有修士成員那時還活著的必續（125-4）。"""
    return kind not in KEEP or any(p["realm_lv"] >= 1 and alive(p, t) for p in crew) or rng.random() < KEEP[kind]


def vacant(f: dict, t: int) -> bool:
    """散掉、早於這個百年、還沒人接手的位子。"""
    fell = (f.get("traits") or {}).get(FELL)
    return f["type"] in TAKE and isinstance(fell, int) and fell < t and not f["traits"].get(TAKEN)


def take(rng: random.Random, f: dict, t: int, town: str, taken: set[str], race: str) -> tuple[dict, dict | None]:
    """這個百年有沒有人接手：回傳（舊那筆的新 traits, 新開的勢力）。沒人接＝traits 不變、None；重開＝拿掉覆滅、None。"""
    if rng.random() >= TAKE[f["type"]]:
        return f["traits"], None
    if rng.random() < REVIVE:
        return {**{k: v for k, v in f["traits"].items() if k != FELL}, REOPEN: t}, None
    kind = f["type"]
    name = (names.pick_unused(rng, names.SECT_PREFIXES, names.SECT_COMMON if kind == "宗門" else ("武館", "拳館"), taken)
            if kind in ("宗門", "武館") else names.mortal_faction_name(rng, kind, town, taken, race))
    if not name:   # 名字用完了：這次沒人接
        return f["traits"], None
    traits = {**(crime.roll_sect(rng, rng.choice(sorted(names.SECT_PATHS))) if kind == "宗門" else {}), BEFORE: f["name"]}
    return {**f["traits"], TAKEN: name}, {"name": name, "type": kind, "location": f["location"], "traits": traits, "discovered_turn": 0}


def head(rng: random.Random, f: dict, places: list[dict], taken: set[str], race: str) -> dict | None:
    """勢力現在的首領（接手的勢力、模型事端的勢力沒有首領時）：宗門、武館照開局那套（sect.cast 的宗主、館主），
    凡間勢力是壯年凡人（HEAD）。"""
    if f["type"] in sect.CAST:
        cast, _ = sect.cast(rng, [(f["name"], f["type"])], set(taken), race)
        return next(({**p, "location": f["location"]} for p in cast if p["job"] in sect.LEADERS), None)
    if f["type"] not in HEAD:   # 朝廷、國家這種不在村鎮裡生首領（模型寫的天災會碰到）
        return None
    here = next((l for l in places if l["name"] == f["location"]), None)
    town = next((l for l in places if l["name"] == space.town_of(places, f["location"])), here)
    p = newcomer.make(rng, place=f["location"], place_type=(here or {}).get("type", ""), taken=taken, land=race, town=town,
                      age=npc.PRIME, role=HEAD[f["type"]])
    return p and {**p, "location": f["location"], "profile": f"{f['name']}的{p['job']}。"}


def new_reign(rng: random.Random, dynasty: dict, nation: str) -> dict:
    """換朝：新國號（這一國用過的不重複），舊的進前朝。回傳整份 dynasty。"""
    old = dynasty.get(nation, {"name": "", "past": []})
    used = {old["name"], *old["past"]}
    name = rng.choice([d for d in DYNASTIES if d not in used] or list(DYNASTIES))
    return {**dynasty, nation: {"name": name, "past": [*old["past"], *([old["name"]] if old["name"] else [])]}}


def reroll(rng: random.Random, traits: dict, era_now: str) -> dict:
    """換朝重擲一類國法（125-7）。"""
    kind = rng.choice(sorted(crime.NATION_KINDS))
    return {**traits, kind: crime.roll_nation(rng, era_now)[kind]}


def reign(atlas: dict | None, nation: str) -> str:
    """給說書人：「（大順朝，前朝：大寧、永安）」；沒換過朝是空字串。"""
    d = ((atlas or {}).get("dynasty") or {}).get(nation)
    return f"（{d['name']}朝" + (f"，前朝：{'、'.join(d['past'])}" if d["past"] else "") + "）" if d else ""
