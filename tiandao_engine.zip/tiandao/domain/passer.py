"""臨時路人（第 86、126-9 題；第 9c 批，progress/路人草稿.md 9-16～9-18）。純函式。

- 你在找人、在場沒有對得上的：說了身分（JOBS 的名字或 ALIAS）這裡又有那種人就照那身分給，沒有就指路；沒說照這裡的職業抽。
  每回合最多一個。
- 輕版（9-17）：職業、圈、一個特點、一件衣著；沒有名字、心事、性格。講兩句：第一句主動說，下一回合追問才說第二句。
- 暫存 KEEP（9-18，角色卡 passers）：同一地再找同身分的人、或說「剛才那個」，就是他，當場登錄；問他名字也登錄。過期散掉。
"""
from __future__ import annotations

import random

from . import circles, looks as outfit, voice
from .clock import SHICHEN_PER_DAY

KEEP = 7 * SHICHEN_PER_DAY
MAX = 5   # 暫存幾個（最舊的先散）
JOBS = {j for js in outfit.TABLE["職業"].values() for j in js}
ALIAS = {"打獵": "獵戶", "種田": "農戶", "種地": "農戶", "放羊": "牧人", "放牛": "牧人", "織布": "織工", "小二": "店小二", "跑堂": "店小二",
         "郎中": "大夫", "看病": "大夫", "官差": "衙役", "捕快": "衙役", "挑夫": "腳夫", "扛貨": "腳夫", "說書": "賣藝人", "賣藝": "賣藝人",
         "算帳": "帳房", "打鐵": "鐵匠", "做菜": "廚子", "走鏢": "鏢師", "教拳": "武師", "看祠": "守祠人"}
AGAIN = ("剛才那", "剛剛那", "先前那", "上次那", "之前那")
NAME = ("名字", "叫什麼", "怎麼稱呼", "尊姓", "大名", "貴姓")


def fields() -> dict:
    return {"passers": []}


def asked_for(text: str) -> str:
    """話裡說要找的身分；沒說回傳空字串。"""
    return next((j for j in sorted(JOBS, key=len, reverse=True) if j in text), "") or next((j for w, j in ALIAS.items() if w in text), "")


def where(job: str) -> tuple[str, ...]:
    """哪幾種地方有這種人。"""
    return tuple(t for t, js in outfit.TABLE["職業"].items() if job in js)


def make(rng: random.Random, job: str, place: str, place_type: str, now: int, turn_no: int) -> dict | None:
    """一個輕版的路人；job 空＝照這裡的職業抽，這裡沒有職業表就沒有路人。"""
    job = job or rng.choice(outfit.TABLE["職業"].get(place_type) or ("",))
    if not job:
        return None
    wear = outfit.TABLE["衣著"].get(job) or outfit.TABLE["衣著"][outfit.COMMON]
    return {"place": place, "job": job, "circle": circles.of(job, place_type), "quirk": rng.choice(sorted(voice.QUIRKS)),
            "looks": rng.choice(wear), "lines": [], "said": 0, "until": now + KEEP, "turn": turn_no}


def keep(passers: list[dict], p: dict, now: int) -> list[dict]:
    """記下（同一個換新的），過期的散掉。"""
    return [q for q in passers if q["until"] > now and (q["place"], q["job"]) != (p["place"], p["job"])][-(MAX - 1):] + [p]


def found(passers: list[dict], here: str, text: str, job: str, now: int, turn_no: int) -> dict | None:
    """要登錄的那一個：上回合在這裡說過話、這回合問他名字；或七天內在這裡再找同身分的人、說「剛才那個」。"""
    alive = [p for p in passers if p["place"] == here and p["until"] > now]
    last = next((p for p in alive if p["turn"] == turn_no - 1), None)
    if last and any(w in text for w in NAME):
        return last
    back = [p for p in alive if p["turn"] < turn_no - 1 and (p["job"] == job or any(w in text for w in AGAIN))]
    return back[-1] if back else None


def line(p: dict) -> str:
    """給說書人的【眼前的人】。"""
    return (f"路人（沒有名字，不要替他取名，也不要寫進 npcs 提案）：{p['job']}，穿著{p['looks']}；"
            f"{p['quirk']}（{voice.QUIRKS[p['quirk']]}）")
