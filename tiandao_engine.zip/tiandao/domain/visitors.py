"""找上門（第 10c-2a 步）：復仇者、宿敵、報恩追隨的人、守約的人來找主角。純函式，不碰資料庫、不呼叫 AI。

規則（2026-10-05 與使用者一題一題定案，見 progress/WHITEPAPER.md 第 14 節「10c-2 找上門的細節」，數字暫定）：
- 每人每年找到你的機率依你所在地（FIND_PER_YEAR），他本來就在同一個地方 ×2；跟世界脈動一樣每跨一個曆月推進。
- 用的是他上次演算的狀態（惰性演算），所以先檢查：活著、沒重傷、壽元沒在那之前耗盡。
- 帶敵意的、善意的各自一回合最多一位（最早到的）。帶敵意的可能偷襲；善意的不打斷閉關（閉關結束那一刻才到）。
- 約定（他人的承諾線頭）期限前判定一次守不守約，守約就來找你（不受機率表限制）。
"""
from __future__ import annotations

import random
from dataclasses import dataclass

from . import evolution, npc
from . import judgment as J
from .clock import SHICHEN_PER_MONTH
from .evolution import months

FIND_PER_YEAR = {"荒野": 0.6, "廢墟": 0.6, "住家": 0.2, "秘境": 0.15, "宗門": 0.1}
DEFAULT_FIND = 0.4                    # 城鎮、坊市、村落、客棧等公開場所，以及還沒分類的地點
SAME_PLACE_FACTOR, MAX_FIND = 2, 0.9
FOE = "敵盟"   # 仙域的遭遇（16l C3a）：不是誰的目標，service 直接排成訪客
DUN = "討債"   # 賴掉的債（第 120-2 題）：不是目標，background.hostile_visit 照帳排進來
BLACKMAIL = "要脅"   # 拿你的把柄要封口費（第 120-2 題，實作第 1-5d 批）：第 7-2b 批起抽到要脅的做法牌才排進來（game/deeds.leverage）
HIRED = "受託"       # 被雇來找你（第 7-2b 批做法牌的雇人，WHITEPAPER ㉗）：不是目標，background.hostile_visit 照帳排進來
HOSTILE_REASONS = ("復仇", "宿敵", FOE, DUN, BLACKMAIL, HIRED)
FRIENDLY_REASONS = ("報恩", "追隨")
PROMISE = "赴約"
OLD = "舊事"   # 回音（domain/echo.py）：結局留下的事，service 直接排成訪客

# 偷襲：善念低、或膽識與野心都高的人會偷襲；察覺看境界差
NOTICE_BASE, NOTICE_PER_LEVEL, NOTICE_RANGE, RETREAT_ALERT = 0.3, 0.2, (0.05, 0.95), 0.1
AMBUSH_SHARE, AMBUSH_PER_LEVEL, AMBUSH_MIN = 0.2, 0.1, 0.05

# 守約：善念高 95%、中 75%、低 40%；疑心高再 −15%
KEEP_PROMISE = {"高": 0.95, "中": 0.75, "低": 0.4}
SUSPICIOUS_PENALTY = 0.15

# 給玩家與說書人的來意（宿敵是天道角色，說書人不能知道，只寫來意不善）
PURPOSE = {"復仇": "向你尋仇", "宿敵": "來意不善", FOE: "敵盟的人，衝著你來", DUN: "上門討債", BLACKMAIL: "拿你的把柄來要封口費", HIRED: "受人之託來找你","報恩": "前來報恩", "追隨": "想追隨你", PROMISE: "如約前來", OLD: "為舊事來找你"}


@dataclass(frozen=True)
class Visit:
    name: str
    reason: str      # 復仇、宿敵、報恩、追隨、赴約
    when: int        # 找到你的時刻

    @property
    def hostile(self) -> bool:
        return self.reason in HOSTILE_REASONS


def reason(p: dict, protagonist: str) -> str:
    """他為什麼要找你；跟你無關回傳空字串。"""
    if p["heaven_role"] == "宿敵":
        return "宿敵"
    if p["goal_target"] == protagonist and p["goal"] in HOSTILE_REASONS + FRIENDLY_REASONS:
        return p["goal"]
    return ""


def able(p: dict, when: int) -> bool:
    """這時候他能不能來：活著、沒重傷、壽元還沒耗盡（他上次演算之後可能已經老死）。"""
    end = evolution.death_time(p)
    return p["status"] == "ALIVE" and p["condition"] != "重傷" and (end is None or end > when)


def find_chance(place_type: str, same_place: bool, span_months: int, boost: float = 1) -> float:
    """boost：你在此地的名聲（第 10c-3b 步，越出名越難藏身）。"""
    rate = FIND_PER_YEAR.get(place_type, DEFAULT_FIND) * (SAME_PLACE_FACTOR if same_place else 1) * boost
    return min(MAX_FIND, rate * span_months / 12)


def first_visit(rng: random.Random, people: list[dict], *, protagonist: str, here: str, place_type: str,
                start: int, end: int, reasons: tuple[str, ...], boost: float = 1) -> Visit | None:
    """這段時間最早找到你的那一位（來意在 reasons 裡的人）。依曆月分段，每段每人擲一次。"""
    seekers = [p for p in people if reason(p, protagonist) in reasons]
    n = min(evolution.MAX_SEGMENTS, months(end) - months(start))
    for i in range(n):
        a, b = start + (end - start) * i // n, start + (end - start) * (i + 1) // n
        for p in seekers:
            if able(p, b) and rng.random() < find_chance(place_type, p["location"] == here, months(b) - months(a),
                                                         boost):
                return Visit(p["name"], reason(p, protagonist), rng.randint(a + 1, b))
    return None


# ── 約定 ─────────────────────────────────────────────────────────────────
def promise_due(thread: dict, start: int, end: int) -> bool:
    """這段時間是不是期限前最後一次推進（期限前一個月內、期限還沒過）。"""
    deadline = thread["deadline_shichen"]
    return deadline is not None and start < deadline and end >= deadline - SHICHEN_PER_MONTH


def keeps_promise(rng: random.Random, p: dict) -> bool:
    chance = KEEP_PROMISE[npc.trait_level(p["kindness"])]
    if npc.trait_level(p["suspicion"]) == "高":
        chance -= SUSPICIOUS_PENALTY
    return rng.random() < chance


# ── 偷襲 ─────────────────────────────────────────────────────────────────
def ambusher(p: dict) -> bool:
    """善念低、或膽識與野心都高的人會偷襲；其他人當面叫陣。"""
    level = npc.trait_level
    return level(p["kindness"]) == "低" or (level(p["courage"]) == "高" and level(p["ambition"]) == "高")


def notice_chance(player_lv: int, lv: int, retreating: bool) -> float:
    chance = NOTICE_BASE + NOTICE_PER_LEVEL * (player_lv - lv) + (RETREAT_ALERT if retreating else 0)
    return max(NOTICE_RANGE[0], min(NOTICE_RANGE[1], chance))


def ambush_damage(hp_max: int, lv: int, player_lv: int) -> int:
    """沒察覺時扣的氣血：最大氣血 20%，他每高你一個大境界 +10%、每低一個 −10%，最少 5%。"""
    share = max(AMBUSH_MIN, AMBUSH_SHARE + AMBUSH_PER_LEVEL * (lv - player_lv))
    return max(1, round(hp_max * share))


# ── 當面對峙（16m 第 7 題）───────────────────────────────────────────────
# 帶敵意的人找上門後留在現場（角色卡 standoff），在場時日常面板不能用。
# 打贏＝他負傷敗走、說動他＝暫且離去，兩種都一年內不再上門；離開此地＝了結（他留在原地）；
# 對他動手沒打贏照一般戰鬥、他還在；不理他＝這回合他出手（ambush_damage，不致瀕死）。
SPARE = SHICHEN_PER_MONTH * 12
WON, TALKED, LEFT, FOUGHT = "打退", "說和", "離開", "交手"


def fields() -> dict:
    return {"standoff": "",   # 在場對峙的仇家；空＝沒有
            "spared": {}}     # 打退、說和的人 → 這個時刻以前不再上門


def spared(sheet: dict, clock_now: int) -> set[str]:
    return {name for name, until in sheet["spared"].items() if until > clock_now}


def settle(sheet: dict, verdict: J.Judgment, target: str, moved: bool, clock_now: int) -> tuple[dict, str]:
    """這回合對峙怎麼了：回傳（角色卡, 結果）；結果空字串＝不理他。"""
    name = sheet["standoff"]
    if moved:
        return {**sheet, "standoff": ""}, LEFT
    if target != name:
        return sheet, ""
    if any(c.target == J.STRIKE and c.outcome in (J.SUCCESS, J.GREAT_SUCCESS) for c in verdict.all_checks):
        result = WON
    elif verdict.action_type == J.SOCIAL and verdict.rolled and verdict.is_success:
        result = TALKED
    else:
        return sheet, FOUGHT if verdict.action_type == J.COMBAT else ""
    keep = {n: t for n, t in sheet["spared"].items() if t > clock_now}
    return {**sheet, "standoff": "", "spared": {**keep, name: clock_now + SPARE}}, result
