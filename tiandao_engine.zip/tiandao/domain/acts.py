"""帳的動作表（Claude主導盤點第 13 題甲，第九節第 3 步）：判定的後果只能從這張表挑，大小分輕中重。純函式，數字暫定。

- 11 類（KINDS）。有大小的照 LEVELS 查數字；消息、物品、移動、領域、在場的人是挑一種做法（WAYS）。
- 上限（cap）：落在主角身上的（CAPPED）帳上有危險（危險度、領域、擋的人比主角強）才能用重，平常最多中。
- 大成功、大失敗：程式把說定的後果升一級（up），Claude 不用寫四種。
- 主角一定經瀕死才死：氣血照 effects 的規則扣（歸零走瀕死）。修為、境界、功法、突破、煉製不在表上，走原系統。
- apply 只做角色卡上的（氣血、狀態、錢、丟東西、時間）；好感、消息、曝光、移動、領域、在場的人、得東西要讀世界，
  回傳給 game 層照現成的路結算（第 4 步接上）。
"""
from __future__ import annotations

from dataclasses import dataclass

from . import effects, items, opinion, status as status_mod

HP, STATUS, MONEY, ITEM, TIME, LIKE, NEWS, EXPOSE, MOVE, DOMAIN, CAST = KINDS = (
    "氣血", "狀態", "錢", "物品", "時間", "好感", "消息", "曝光", "移動", "領域", "在場的人")
LIGHT, MID, HEAVY = LEVELS = ("輕", "中", "重")
LOSE, GAIN = "失", "得"
WAYS = {MONEY: (LOSE, GAIN), ITEM: (LOSE, GAIN), LIKE: ("升", "降"), NEWS: ("一條消息", "事端推進"),
        EXPOSE: ("曝光", "留案底"), MOVE: ("沒到達", "被趕出", "迷路"), DOMAIN: ("犯規", "被盯上", "破解推進"),
        CAST: ("受傷", "被帶走", "逃走", "告官", "要脅", "示警")}
HP_LOSS = {LIGHT: 10, MID: 20, HEAVY: 35}
SEVERITY = {LIGHT: (30, 6), MID: (40, 12), HEAVY: (60, 24)}   # 狀態：（嚴重度, 持續時辰）
MONEY_SHARE = {LIGHT: 0.1, MID: 0.2, HEAVY: 0.3}               # 失身上的幾成
HOURS = {LIGHT: 1, MID: 2, HEAVY: 4}
LIKE_STEP = {LIGHT: 1, MID: 1, HEAVY: 2}                       # 好感升降幾級
LIKE_SIZE = {LIGHT: opinion.SMALL, MID: opinion.BIG, HEAVY: opinion.GRAVE}   # 記成好感原因的大小（10／30／60，約一兩級）
EXPOSE_STEP = {LIGHT: 1, MID: 3, HEAVY: 3}
SHEET = (HP, STATUS, MONEY, ITEM, TIME)                         # apply 自己做得完的（得錢、得東西除外）
CAPPED = (HP, STATUS, MONEY, ITEM, TIME, EXPOSE, MOVE, DOMAIN)  # 落在主角身上的才封頂（好感、在場的人是對別人）
HURT_STEPS = {LIGHT: "成功", MID: "成功", HEAVY: "大成功"}        # 在場的人受傷：照命中的成功（一階）、大成功（兩階）算（npc.consequences）
CASH = {LIGHT: 0.5, MID: 1, HEAVY: 2}                            # 得錢：incident 的得錢乘這個


@dataclass(frozen=True)
class Act:
    """一項後果。way：有做法的那幾類挑哪一種；name：狀態名（Claude 自訂）、丟哪件東西、對誰。"""
    kind: str
    level: str = MID
    way: str = ""
    name: str = ""


def cap(level: str, danger: bool) -> str:
    return level if danger or level != HEAVY else MID


def up(level: str) -> str:
    return LEVELS[min(len(LEVELS) - 1, LEVELS.index(level) + 1)]


def problem(a: Act, *, carried: set[str] = frozenset(), present: set[str] = frozenset()) -> str:
    """擋下的原因（空字串＝可以）。carried：主角身上的東西；present：在場的人。"""
    return ("不在動作表上" if a.kind not in KINDS or a.level not in LEVELS
            else "做法不在清單裡" if a.kind in WAYS and a.way not in WAYS[a.kind]
            else "要寫狀態的名字" if a.kind == STATUS and not a.name
            else "主角身上沒有這件東西" if (a.kind, a.way) == (ITEM, LOSE) and a.name not in carried
            else "那個人不在場" if a.kind in (LIKE, CAST) and a.name not in present else "")


def apply(sheet: dict, a: Act, now: int) -> tuple[dict, list[dict], list[str], int]:
    """角色卡上的後果：回傳（角色卡, 數值變化, 事件, 多花的時辰）。不歸這裡做的原樣回傳。"""
    new, changes, events = {**sheet, "statuses": [dict(s) for s in sheet["statuses"]]}, [], []   # status.add 會改原地
    if a.kind == HP:
        new, changes, events = effects.gain(sheet, {"hp": -HP_LOSS[a.level]})
    elif a.kind == STATUS:
        size, hours = SEVERITY[a.level]
        status_mod.add(new["statuses"], status_mod.make(a.name, status_mod.NEGATIVE, size, now + hours))
        events.append(f"留下狀態「{a.name}」")
    elif (a.kind, a.way) == (MONEY, LOSE) and sheet["money"]:
        lost = max(1, round(sheet["money"] * MONEY_SHARE[a.level]))
        new, changes, events = effects.gain(sheet, {"money": -lost})
    elif (a.kind, a.way) == (MOVE, "迷路"):   # 同辨向大失敗：迷路、多花時間（沒到達在 effects.arrives）
        size, hours = SEVERITY[a.level]
        status_mod.add(new["statuses"], status_mod.make("迷路", status_mod.NEGATIVE, size, now + hours * 2))
        return new, changes, ["迷失方向，留下狀態「迷路」"], HOURS[a.level]
    elif (a.kind, a.way) == (ITEM, LOSE):
        e = next(e for e in sheet["items"] if e["name"] == a.name)
        new = items.remove(new, e["name"], e["tier"])
        events.append(f"失去了{a.name}")
    return new, changes, events, HOURS[a.level] if a.kind == TIME else 0
