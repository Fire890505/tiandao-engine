"""隨行的人：同伴、傭兵、僕人、俘虜（2026-10-13，WHITEPAPER 16i 第 1～8 題；第 8 組草稿批次一）。純函式。

- 最多 2 個名額（俘虜也佔）。隨行的人每回合跟著主角（閉關時主角沒走，他們也就留在原地）。未成年一律不行。
- 交談＋邀請：好感友善以上才判定，目標「追隨」主角的直接願意 → 同伴。
  交談＋僱用：在城鎮、坊市、鏢局，目標「逐利」的才肯，判定成功 → 傭兵，先付一個月。
  交談＋解散：留在原地。
  對手重傷沒死時說擒住、綁起來 → 俘虜（有國法的地方算擄人，crime.WORDS）；對俘虜交談說契約、賣身 → 判定成功成僕人。
- 戰鬥：每人 +5，境界比主角每高一級再 +5，合計上限 +20；重傷的不加成。主角失敗時各一半機會負傷，
  大失敗時一個人替主角擋下一擊（傷兩階，可能殞落）。俘虜不打架。
- 每月開銷：傭兵凡人 30 凡人錢、修士 10 × 2^(境界−1) 靈石；僕人 10 凡人錢。付不出就走。
- 離開：同伴好感掉到冷淡以下；傭兵在主角瀕死、或對手比他高兩級以上時一半機會跑掉；僕人好感敵視時可能逃；
  俘虜每回合 10% 逃跑。善念高的同伴看到殺人、邪術、擄人，好感 −15。
- 角色卡欄位 party：[{"name", "role", "since", "paid"（付到何時；同伴、俘虜是 0）, "physique", "home"}]。
"""
from __future__ import annotations

import random

from . import crime, npc, opinion
from . import judgment as J
from .clock import SHICHEN_PER_MONTH

COMPANION, MERC, SERVANT, CAPTIVE = "同伴", "傭兵", "僕人", "俘虜"
ROLES = (COMPANION, MERC, SERVANT, CAPTIVE)
MAX = 2
INVITE_WORDS = ("邀請", "同行", "結伴", "跟我走", "一起走", "一道走")
HIRE_WORDS = ("僱用", "雇用", "僱傭", "聘請", "僱他", "雇他", "僱她", "雇她")
DISMISS_WORDS = ("解散", "分道揚鑣", "各走各的", "就此別過", "不必跟著", "不用跟著")
CONTRACT_WORDS = ("契約", "賣身", "簽約", "畫押")
HIRE_PLACES = ("城鎮", "坊市", "鏢局")
INVITE_AT = 20                        # 好感友善以上才肯同行（npc.AFFINITY_TIERS）
LEAVE_BELOW = -9                      # 好感掉到冷淡以下就走
HOSTILE_AT = -50                      # 敵視：僕人可能逃
BONUS, STEP, CAP = 5, 5, 20           # 戰鬥加成（暫定）
WAGE_MORTAL, WAGE_STONES, UPKEEP = 30, 10, 10   # 每月：凡人傭兵（凡人錢）、修士傭兵（靈石 × 2^(境界−1)）、僕人（凡人錢）
FLEE_GAP, FLEE_CHANCE = 2, 0.5
ESCAPE = {SERVANT: 0.3, CAPTIVE: 0.1}   # 每回合逃跑的機率（僕人要敵視才會逃）
HURT_CHANCE = 0.5
KIND_AT = 65                          # 善念高
APPALLED = [opinion.hit(opinion.CRIME_SEEN, opinion.LIKE, opinion.BIG, -1)]   # 善念高的同伴看到大罪（1-5 批改照 121-2）
APPALLING = (crime.KILL, crime.DARK, crime.ABDUCT)
PHYSIQUES = ("純陰之體", "純陽之體", "玄陰之體", "先天道體")   # 特殊體質（16i 第 10-9 題；只有拍賣買來的人有）
KEYS = {"name", "role", "since", "paid", "physique", "home"}


def fields() -> dict:
    return {"party": []}


def member(sheet: dict, name: str) -> dict | None:
    return next((m for m in sheet["party"] if m["name"] == name), None)


def names(sheet: dict) -> set[str]:
    return {m["name"] for m in sheet["party"]}


def drop(sheet: dict, gone: set[str]) -> dict:
    return {**sheet, "party": [m for m in sheet["party"] if m["name"] not in gone]}


def add(sheet: dict, name: str, role: str, clock_now: int, paid: int = 0, *, physique: str = "", home: str = "") -> dict:
    """physique：特殊體質；home：出身的勢力（拍賣買來的人，16i 批次三）。換身分時沿用原本的。"""
    old = member(sheet, name) or {}
    entry = {"name": name, "role": role, "since": clock_now, "paid": paid,
             "physique": physique or old.get("physique", ""), "home": home or old.get("home", "")}
    return {**sheet, "party": [m for m in sheet["party"] if m["name"] != name] + [entry]}


def _said(words: str, table: tuple) -> bool:
    return any(w in words for w in table)


def wage(role: str, realm_lv: int) -> tuple[int, int]:
    """每月要付的（凡人錢, 靈石）。"""
    if role == MERC:
        return (WAGE_MORTAL, 0) if realm_lv == 0 else (0, WAGE_STONES * 2 ** (realm_lv - 1))
    return (UPKEEP, 0) if role == SERVANT else (0, 0)


def _pay(sheet: dict, cost: tuple[int, int]) -> dict | None:
    """付得起就扣，付不起回傳 None。"""
    if sheet["money"] < cost[0] or sheet["spirit_stones"] < cost[1]:
        return None
    return {**sheet, "money": sheet["money"] - cost[0], "spirit_stones": sheet["spirit_stones"] - cost[1]}


def _cost_text(cost: tuple[int, int], money_name: str) -> str:
    return "、".join(t for t in (f"{cost[0]} {money_name}" if cost[0] else "", f"{cost[1]} 塊靈石" if cost[1] else "") if t)


# ── 這回合說要帶誰走、放誰走 ─────────────────────────────────────────────
def request(sheet: dict, person: dict | None, state: dict | None, relation: dict | None, *, action: str, words: str,
            ok: bool, place_type: str, clock_now: int, money_name: str) -> tuple[dict, list[str]]:
    """交談邀請、僱用、解散，擒住重傷的對手，逼俘虜簽契約。person：這回合的對象；state：他這回合之後的狀態；
    ok：判定成功。回傳（角色卡, 事實）。"""
    if person is None or (state or {}).get("status", "ALIVE") != "ALIVE":
        return sheet, []
    name, mine, talk = person["name"], member(sheet, person["name"]), action == J.SOCIAL
    if mine and talk and _said(words, DISMISS_WORDS):
        return drop(sheet, {name}), [f"{name}不再跟著你，留在原地"]
    if mine and mine["role"] == CAPTIVE and talk and _said(words, CONTRACT_WORDS):
        if not ok:
            return sheet, [f"{name}不肯簽下契約"]
        return add(sheet, name, SERVANT, clock_now, clock_now + SHICHEN_PER_MONTH), [f"{name}簽下契約，成了你的僕人"]
    capture = state is not None and state["condition"] == "重傷" and _said(words, crime.WORDS[crime.ABDUCT])
    invite, hire = talk and _said(words, INVITE_WORDS), talk and _said(words, HIRE_WORDS)
    if mine or not (capture or invite or hire):
        return sheet, []
    if npc.is_minor(person, clock_now):
        return sheet, [f"{name}還未成年，不能帶在身邊"]
    if len(sheet["party"]) >= MAX:
        return sheet, [f"身邊已經跟著 {MAX} 個人，帶不了{name}"]
    if capture:
        return add(sheet, name, CAPTIVE, clock_now), [f"擒住了{name}，綁起來帶在身邊"]
    if hire:
        cost = wage(MERC, person["realm_lv"])
        if person["goal"] != "逐利" or place_type not in HIRE_PLACES or not ok:
            return sheet, [f"{name}不肯受僱"]
        paid = _pay(sheet, cost)
        if paid is None:
            return sheet, [f"僱{name}一個月要 {_cost_text(cost, money_name)}，錢不夠"]
        return add(paid, name, MERC, clock_now, clock_now + SHICHEN_PER_MONTH), \
            [f"僱了{name}當傭兵，先付了一個月 {_cost_text(cost, money_name)}"]
    follower = person["goal"] == "追隨" and person["goal_target"] == sheet["name"]
    if not follower and (relation["affinity"] < INVITE_AT or not ok):
        return sheet, [f"{name}不願與你同行"]
    return add(sheet, name, COMPANION, clock_now), [f"{name}答應與你同行"]


# ── 戰鬥 ─────────────────────────────────────────────────────────────────
def fighters(sheet: dict, npcs: list[dict]) -> list[dict]:
    """會出手的人：不是俘虜、還活著、沒有重傷。"""
    roles = {m["name"]: m["role"] for m in sheet["party"]}
    return [p for p in npcs if roles.get(p["name"], CAPTIVE) != CAPTIVE and p["status"] == "ALIVE"
            and p["condition"] not in ("重傷", "殞落")]


def bonus(sheet: dict, npcs: list[dict]) -> int:
    return min(CAP, sum(BONUS + STEP * max(0, p["realm_lv"] - sheet["realm_lv"]) for p in fighters(sheet, npcs)))


def hurt(rng: random.Random, sheet: dict, npcs: list[dict], outcome: str) -> tuple[dict[str, str], list[str]]:
    """主角戰鬥失敗：出手的人各一半機會負傷；大失敗：一個人替主角擋下一擊（傷兩階）。回傳（名字 → 新狀況, 事實）。"""
    out = fighters(sheet, npcs)
    if outcome not in (J.FAILURE, J.GREAT_FAILURE) or not out:
        return {}, []
    hurt_now = {p["name"]: npc.harm(p["condition"], 1) for p in out if rng.random() < HURT_CHANCE}
    facts = [f"{n}在混戰中{c}" for n, c in hurt_now.items()]
    if outcome == J.GREAT_FAILURE:
        shield = rng.choice(out)
        hurt_now[shield["name"]] = npc.harm(shield["condition"], 2)
        facts = [f for f in facts if not f.startswith(shield["name"])] + \
            [f"{shield['name']}替你擋下一擊，{hurt_now[shield['name']]}"]
    return hurt_now, facts


def appalled(sheet: dict, npcs: list[dict], found: list[str]) -> list[str]:
    """善念高的同伴看到殺人、邪術、擄人：回傳要扣好感的人。"""
    if not set(found) & set(APPALLING):
        return []
    kind = {p["name"] for p in npcs if p["kindness"] >= KIND_AT}
    return [m["name"] for m in sheet["party"] if m["role"] == COMPANION and m["name"] in kind]


# ── 每回合：付錢、離開、逃跑 ─────────────────────────────────────────────
def upkeep(rng: random.Random, sheet: dict, npcs: list[dict], relations: dict[str, dict], *, clock_now: int,
           dying: bool, foe_lv: int | None, money_name: str) -> tuple[dict, list[str]]:
    """付到期的工錢、伙食；死了、好感太低、付不出錢、見勢不妙的人離開。relations：名字 → 這回合之後的關係。"""
    people = {p["name"]: p for p in npcs}
    kept, facts = [], []
    for m in sheet["party"]:
        p, name = people.get(m["name"]), m["name"]
        if p is None or p["status"] != "ALIVE":
            facts.append(f"同伴{name}殞落了" if p else f"{name}不見了")
            continue
        affinity = relations.get(name, {}).get("affinity", 0)
        if m["role"] == COMPANION and affinity <= LEAVE_BELOW:
            facts.append(f"{name}對你心冷了，不告而別")
            continue
        if m["role"] == MERC and (dying or foe_lv is not None and foe_lv >= p["realm_lv"] + FLEE_GAP) \
                and rng.random() < FLEE_CHANCE:
            facts.append(f"{name}見勢不妙，丟下你跑了")
            continue
        if m["role"] in ESCAPE and (m["role"] == CAPTIVE or affinity <= HOSTILE_AT) and rng.random() < ESCAPE[m["role"]]:
            facts.append(f"{name}趁你不注意逃走了")
            continue
        while m["paid"] and m["paid"] <= clock_now:
            cost = wage(m["role"], p["realm_lv"])
            paid = _pay(sheet, cost)
            if paid is None:
                facts.append(f"付不出{name}的{'工錢' if m['role'] == MERC else '伙食'}，{name}走了")
                break
            sheet, m = paid, {**m, "paid": m["paid"] + SHICHEN_PER_MONTH}
            facts.append(f"付了{name}一個月的{'工錢' if m['role'] == MERC else '伙食'}（{_cost_text(cost, money_name)}）")
        else:
            kept.append(m)
    return {**sheet, "party": kept}, facts


# ── 畫面與說書人 ─────────────────────────────────────────────────────────
def text(sheet: dict, npcs: list[dict]) -> str:
    """給說書人的【同行】：誰跟著、什麼身分、傷勢。"""
    people = {p["name"]: p for p in npcs}
    return "；".join(f"{m['name']}（{m['role']}" + (f"，{people[m['name']]['condition']}" if m["name"] in people
                                                   and people[m["name"]]["condition"] != "無恙" else "") + "）"
                    for m in sheet["party"])


def panel(sheet: dict) -> list[dict]:
    return [{"name": m["name"], "role": m["role"]} for m in sheet["party"]]


def valid(sheet: dict) -> bool:
    p = sheet["party"]
    return isinstance(p, list) and len(p) <= MAX and len({m["name"] for m in p}) == len(p) and all(
        isinstance(m, dict) and set(m) == KEYS and isinstance(m["name"], str) and isinstance(m["home"], str)
        and m["physique"] in ("", *PHYSIQUES)
        and m["role"] in ROLES and isinstance(m["since"], int) and isinstance(m["paid"], int) for m in p)
