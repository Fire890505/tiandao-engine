"""風聲（WHITEPAPER 16v 第 23、28、78 題；數字暫定）：聽到的傳聞先記在後台，玩家看不到。純函式。
和面板「未了的事」的線頭（threads 表）是兩回事。

- 只記指向真實事件的傳聞。期限跟著事件走，最長 60 天；最多 5 條，滿了擠掉最舊的。
- 碰到（照路線「自己撞上」的規則）才抽事件卡；過期或被擠掉要給結果，見 game/leads.py。
- 怪談、傳說變凶後，聽到再記一次（raised），只升級一次。
角色卡欄位：leads。
"""
from __future__ import annotations

from .route import LIMIT

MAX = 5
KEYS = {"kind", "key", "place", "text", "until", "raised"}


def fields() -> dict:
    return {"leads": []}


def make(kind: str, key: str, place: str, text: str, now: int, raised: bool = False) -> dict:
    return {"kind": kind, "key": key, "place": place, "text": text, "until": now + LIMIT, "raised": raised}


def add(leads: list[dict], new: dict) -> tuple[list[dict], list[dict]]:
    """記一條：回傳（線頭, 被擠掉的）。同一件事只有變凶才換新的。"""
    old = next((l for l in leads if l["key"] == new["key"]), None)
    if old and (old["raised"] or not new["raised"]):
        return leads, []
    kept = [*(l for l in leads if l is not old), new]
    return kept[-MAX:], kept[:-MAX]


def valid(sheet: dict) -> bool:
    return isinstance(sheet["leads"], list) and len(sheet["leads"]) <= MAX and all(
        isinstance(l, dict) and set(l) == KEYS and isinstance(l["until"], int) and isinstance(l["raised"], bool)
        and all(isinstance(l[k], str) for k in ("kind", "key", "place", "text")) for l in sheet["leads"])
