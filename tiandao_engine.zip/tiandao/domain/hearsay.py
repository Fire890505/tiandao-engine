"""誰知道什麼（第 120-3 題，實作第 1-5a 批）。純規則，不碰資料庫。

- 主角做的事記成一件事（events 表）：殺人、傷人、犯罪是秘密，救命不是。actor 寫那一生（同 bonds、ledger 的主角那方）。
- 在場的人都知道（knows 表，via＝在場）；易容中不知道是誰。原委（knows_why）這批先都不知道，1-5b 用。
- 秘密過 SPREAD 告訴親近的人（親人、伴侶、師徒、結義、友人），討厭你才說、喜歡你就瞞；每筆只說一次（told）。
- 殺人、傷人：熱鬧的地方（crime.BUSY）當場傳開，其他地方同一村鎮 CROWD 個人知道是你才傳開；
  傳開後記一筆「這個村鎮都知道」（who＝村鎮、via＝傳聞），不再一個一個傳。
- 聽說變好感（第 121-2 題，實作第 1-5b 批）：親口聽到（親眼、聽人說）又知道是你的人當下記一筆（felt），
  輕重看他對被害的人的態度；對說的人存疑以下不信。被害人的親人、伴侶、師徒、結義：知道是你殺的記「血仇」，
  不知道是誰記「追查兇手」，在同一村鎮問到知道的人（asked）就改成血仇。傳聞見面才算、原委、除害還沒做。
- 傳聞見面才算（第 1-5e 批）：傳聞傳到的地方，只聽過傳聞的人見到你時才記（再降一級），記一筆 via＝傳聞的知道（只算一次）。
- 封口（第 121-10 題，實作第 1-5c 批）：畏懼你的人跟喜歡你的人一樣替你瞞著（quiet，由 game/news 算）。
"""
from __future__ import annotations

from . import opinion, society, space
from .clock import SHICHEN_PER_DAY
from ..util import new_id

KILL, HURT, CRIME, SAVE = "殺人", "傷人", "犯罪", "救命"
KINDS = (KILL, HURT, CRIME, SAVE)
CHASE = "追查"   # 你碰了暗線的一個門路（第 5-1-2 題，game/darks.py）：只給對手察覺用，不在 KINDS，傳開、聽說、封口都不管它
LOUD = (KILL, HURT)                       # 傳得開的（變成傳聞）
SEEN, TOWN = "在場", "傳聞"
SPREAD, CROWD = 3 * SHICHEN_PER_DAY, 3
TELLS = society.CLOSE + ("友人",)        # 會告訴的人
HIDE_AT = 20                              # 好感友善以上就替你瞞著（npc.AFFINITY_TIERS）
BASE = {KILL: (opinion.GRAVE, -1), HURT: (opinion.BIG, -1), CRIME: (opinion.SMALL, -1), SAVE: (opinion.BIG, 1)}   # 救命是好事，降一級
NEAR, COLD, DOUBT = 60, -10, -10          # 親近、冷淡以下（好感）；存疑以下（信任）不信
HUSH_MONTHS = {CRIME: 1, HURT: 3, KILL: 10}   # 封口費：他幾個月的工錢（favour.lend，第 1-5d 批）


def event(kind: str, life: str, target: str, place: str, now: int, turn_no: int, **detail) -> dict:
    """detail：name（對外的名字）、lv（對方境界）、my_lv（你的境界）、crimes（犯了哪些罪）。"""
    return {"id": new_id("evt"), "session_id": life, "kind": kind, "actor": life, "target": target, "place": place,
            "detail": detail, "secret": int(kind != SAVE), "era": "", "clock_shichen": now, "turn_no": turn_no}


def know(e: dict, who: str, now: int, *, by: int = 1, via: str = SEEN) -> dict:
    return {"id": new_id("knw"), "session_id": e["session_id"], "event_id": e["id"], "who": who, "knows_who": by,
            "knows_why": 0, "via": via, "clock_shichen": now, "told": 0}


def public(knows: list[dict]) -> set[str]:
    """已經傳開的事（event id）。"""
    return {k["event_id"] for k in knows if k["via"] == TOWN}


def felt(kind: str, toward: int, drop: int = 0) -> opinion.Hit | None:
    """親口聽到的人記的好感原因。toward：他對被害的人的好感。親近照原本的輕重、友善降一級、中立不記、
    冷淡以下反過來記正的再降一級。drop：再降幾級（聽傳聞的見到你時 1，第 1-5e 批）。"""
    size, sign = BASE[kind]
    if COLD < toward < HIDE_AT:
        return None
    i = opinion.LEVELS.index(size) - (toward < NEAR) - drop
    return opinion.hit(opinion.HEARD, opinion.LIKE, opinion.LEVELS[i], sign if toward > 0 else -sign) if i >= 0 else None


def kin(name: str, bonds: list[dict]) -> set[str]:
    """會記血仇的人：親人、伴侶、師徒、結義。"""
    return {b["b"] if b["a"] == name else b["a"] for b in bonds if b["type"] in society.CLOSE and name in (b["a"], b["b"])}


def asked(knows: list[dict], hunts: list[dict], npcs: list[dict], locations: list[dict], quiet: set[str],
          now: int) -> list[dict]:
    """追查兇手的人在同一村鎮問到知道是你、又不替你瞞（quiet 以外）的人，或那裡已經傳開了。hunts：帳上未了的追查兇手。"""
    where = {p["name"]: space.town_of(locations, p["location"]) for p in npcs if p["status"] == "ALIVE"}
    out = []
    for h in hunts:
        town = where.get(h["a"])
        src = next((k for k in knows if k["event_id"] == h["event_id"] and k["who"] != h["a"] and town and (
            k["via"] == TOWN and k["who"] == town or k["via"] != TOWN and k["knows_who"] and where.get(k["who"]) == town
            and k["who"] not in quiet)), None)
        if src:
            out.append(know({"id": h["event_id"], "session_id": h["session_id"]}, h["a"], now, via=src["who"]))
    return out


def spread(events: list[dict], knows: list[dict], npcs: list[dict], bonds: list[dict], quiet: set[str],
           now: int, believe=lambda who, teller: True, fond: set[str] = frozenset(), lips: dict | None = None) -> tuple[list[dict], list[str]]:
    """知道秘密的人過 SPREAD 告訴親近的人。quiet：一定替你瞞的人（畏懼你、封口）；believe(聽的人, 說的人)。
    口風（第 7-1-7 題甲，lips：名字 → 低中高）：fond（喜歡你的）口風低會說溜嘴但不說是你，中高照瞞；
    其他人口風高不說、中照 SPREAD、低一半時間就說。回傳（新的知道, 說過了的 id）。"""
    alive = {p["name"] for p in npcs if p["status"] == "ALIVE"}
    secret, done = {e["id"]: e for e in events if e["secret"]}, public(knows)
    had = {(k["event_id"], k["who"]) for k in knows}
    new, told = [], []
    for k in knows:
        lip, liked = (lips or {}).get(k["who"], "中"), k["who"] in fond
        if (k["told"] or k["event_id"] not in secret or k["event_id"] in done or k["who"] not in alive
                or now - k["clock_shichen"] < (SPREAD // 2 if lip == "低" else SPREAD) or k["who"] in quiet
                or liked and lip != "低" or not liked and lip == "高"):
            continue
        told.append(k["id"])
        for b in bonds:
            other = b["b"] if b["a"] == k["who"] else b["a"] if b["b"] == k["who"] else ""
            if b["type"] in TELLS and other in alive and (k["event_id"], other) not in had and believe(other, k["who"]):
                had.add((k["event_id"], other))
                new.append({**know(secret[k["event_id"]], other, now, by=0 if liked else k["knows_who"], via=k["who"]), "knows_why": k["knows_why"]})
    return new, told


def crowded(events: list[dict], knows: list[dict], npcs: list[dict], locations: list[dict]) -> list[dict]:
    """還沒傳開、同一村鎮已經有 CROWD 個人知道是你的殺人、傷人。"""
    where = {p["name"]: space.town_of(locations, p["location"]) for p in npcs if p["status"] == "ALIVE"}
    done = public(knows)
    return [e for e in events if e["kind"] in LOUD and e["id"] not in done and CROWD <= sum(
        1 for k in knows if k["event_id"] == e["id"] and k["knows_who"] and where.get(k["who"]) == space.town_of(locations, e["place"]))]
