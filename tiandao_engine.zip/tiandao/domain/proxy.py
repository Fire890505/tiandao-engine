"""借刀與懸賞（16l 第 6-3 題）：讓別人去對付你的對手。交手照世界脈動（pulse.maybe_fight）分勝負。純函式。

規則（2026-10-14 與使用者一題一題定案，見 progress/WHITEPAPER.md 16l，數字暫定）：
- 借刀：交談成功，對在場的人說替我對付、幫我除掉……並點名一個認得的人；好感友善以上靠人情，
  不然要說付酬金而且付得起（凡人錢 FEE × 2^對手境界）。成了＝帳上記受託（算成仇家），世界脈動裡會去找他交手。
- 懸賞：在城鎮說懸賞並點名，付得起就貼出告示（地點狀況「懸賞」一年）。每個月 TAKE 的機會有人接：
  境界不低於對手、目標逐利或野心高的人；接了就記受託（算成仇家）。對手已經被人接下就不再擲。
"""
from __future__ import annotations

import random

from . import incident, npc, society
from . import judgment as J
from .clock import SHICHEN_PER_YEAR
from .evolution import AWAY

ASK_WORDS = ("替我", "幫我對付", "幫我除掉", "幫我殺", "幫我教訓", "對付", "除掉", "報官")
PAY_WORDS = ("酬金", "重金", "報酬", "酬勞", "花錢", "付錢", "賞金")
POST_WORDS = ("懸賞", "貼出告示", "張貼告示", "重金求")
FEE = 100                 # 凡人錢 × 2^對手境界
FAVOR_AT = 20             # 好感友善以上靠人情（npc.AFFINITY_TIERS）
BOUNTY, BOUNTY_TEXT = "懸賞", "懸賞捉拿"
LASTS = SHICHEN_PER_YEAR
TAKE = 0.1                # 每個月有人接的機會
POST_PLACES = ("城鎮",)


def fee(lv: int) -> int:
    return FEE * 2 ** lv


def named(words: str, npcs: list[dict], skip: set[str]) -> dict | None:
    """行動裡點名的另一個人（還活著）。"""
    return next((p for p in npcs if p["name"] in (words or "") and p["name"] not in skip and p["status"] == "ALIVE"),
                None)


def feud(a: str, b: str, clock_now: int) -> dict:
    """甲答應對付乙：帳上記一筆受託（讀的時候算成仇家，第 1-3 批）。"""
    return society.owed(society.HIRED, a, b, clock_now)


def ask(verdict, words: str, helper: str, affinity: int, foe: dict | None, money: int,
        deal: str | None = None) -> tuple[int, str] | None:
    """借刀成不成：回傳（付的錢, 事件）；不成回傳 None。deal：讀懂的買賣找人（3-4d），讀成付錢或原文有酬金這類字都算付錢。"""
    talked = any(c.outcome in (J.SUCCESS, J.GREAT_SUCCESS) for c in verdict.all_checks)
    if not (helper and foe and verdict.action_type == J.SOCIAL and talked and any(w in words for w in ASK_WORDS)):
        return None
    if affinity >= FAVOR_AT:
        return 0, f"{helper}念在交情，答應替你對付{foe['name']}"
    cost = fee(foe["realm_lv"])
    if (deal == "付錢" or any(w in words for w in PAY_WORDS)) and money >= cost:   # 3-4d 收尾甲：酬金、重金字很明確，讀漏也算
        return cost, f"付了 {cost} 酬金，{helper}答應替你對付{foe['name']}"
    return None


def post(place: str, place_type: str, words: str, foe: dict | None, money: int, clock_now: int) -> tuple[dict, int] | None:
    """在城鎮貼懸賞：回傳（地點狀況, 付的錢）。"""
    if place_type not in POST_PLACES or not foe or not any(w in words for w in POST_WORDS) \
            or money < fee(foe["realm_lv"]):
        return None
    return ({"place": place, "name": BOUNTY, "text": BOUNTY_TEXT + foe["name"], "source": incident.WORLD, "game": None,
             "started_shichen": clock_now, "ends_shichen": clock_now + LASTS}, fee(foe["realm_lv"]))


def open_bounties(states: list[dict], bonds: list[dict], clock_now: int) -> list[str]:
    """還沒人接的懸賞：被懸賞的人。"""
    return [s["text"][len(BOUNTY_TEXT):] for s in states if s["name"] == BOUNTY
            and s["started_shichen"] <= clock_now < s["ends_shichen"]
            and not any(b["type"] == "仇家" and b["b"] == s["text"][len(BOUNTY_TEXT):]
                        and b["clock_shichen"] >= s["started_shichen"] for b in bonds)]


def takers(rng: random.Random, wanted: list[str], npcs: list[dict], months: int) -> list[tuple[str, str]]:
    """這段時間接下懸賞的人：[(接的人, 被懸賞的人)]。"""
    people = {p["name"]: p for p in npcs if p["status"] == "ALIVE" and p["location"] != AWAY}
    found = []
    for name in dict.fromkeys(wanted):
        foe = people.get(name)
        if not foe or rng.random() >= min(1.0, TAKE * months):
            continue
        pool = [p["name"] for p in people.values() if p["name"] != name and p["realm_lv"] >= foe["realm_lv"]
                and (p.get("goal") == "逐利" or npc.trait_level(p.get("ambition", 50)) == "高")]
        if pool:
            found.append((rng.choice(sorted(pool)), name))
    return found
