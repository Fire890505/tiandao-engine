"""境界階梯 Lv0–Lv11、壽元、突破冷卻與成功率基礎值。純資料＋純函式。

名稱、敘事上限、禁止描寫、空間規模取自舊專案 realm_system.REALM_TABLE；壽元取自
character_realm._DEFAULT_LIFESPAN。刻意不同的地方：
- Lv0 凡人是獨立一層，有自己的敘事上限。舊版 get_realm_tier 會把 Lv0 夾成 Lv1（PORTING_PLAN 第 3 步）。
- 小境界修為滿 100 自動推進，但大境界之間是「瓶頸」：修為停在 100，必須主動突破
  （domain/breakthrough.py）。舊版修為滿就直接升大境界。
- 16l 第 6 題：破格期也要主動踏入（宣告突破，不擲骰）；不踏入就停在天仙境過完一生。
"""
from __future__ import annotations

from dataclasses import dataclass

PROGRESS_PER_STAGE = 100


@dataclass(frozen=True)
class Tier:
    names: tuple[str, ...]   # 小境界名稱（低→高）
    scale: str               # 力量影響範圍（舊版 space_scale 轉成可讀標籤）
    narrative_cap: str       # 敘事上限
    forbidden: str           # 禁止描寫
    lifespan: int | None     # 壽元（年）；None＝不受壽元限制
    breakthrough_base: int   # 突破「進入」這一層的基礎成功率（%）
    cooldown_years: int      # 進入這一層前，距離上次大突破至少要隔幾年


TIERS: dict[int, Tier] = {
    # Lv0～6 的做得到、禁止描寫只管肉身（法則領域世界設計 E0、E2：境界修體）；法則那一份在 DAO_TIERS
    0: Tier(("凡人",), "身邊數丈",
            "常人的體力", "內力外放、飛行、任何超凡能力",
            80, 0, 0),
    1: Tier(("後天武者", "先天武者", "宗師", "化勁"), "村落",
            "內力、輕功、硬功，以一敵十", "御器飛行、開山斷江",
            120, 70, 0),
    2: Tier(("築基期", "築基後期", "大築基"), "村落",
            "靈力入體、刀槍難傷、御劍不超過半時辰", "長途飛行、一擊崩山",
            150, 60, 1),
    3: Tier(("金丹期", "金丹後期", "大金丹"), "鄉鎮",
            "靈力不絕、御劍長飛、一擊崩山頭", "一擊毀城",
            300, 50, 3),
    4: Tier(("返虛期", "返虛後期", "大返虛"), "城市",
            "肉身近乎不壞、一擊撼動一城", "毀滅一國",
            500, 45, 10),
    5: Tier(("合體期", "合道期", "大合道"), "國家",
            "肉身與靈力合一、橫渡一國、撼動山河", "破開天穹、離開這個世界",
            2000, 40, 30),
    6: Tier(("天仙境", "破格期"), "世界",
            "壽元萬年、跨洲往返；破格期能破開天穹", "離開這個世界（要破空）",
            10000, 30, 100),
    7: Tier(("金仙", "太乙金仙", "大羅金仙"), "星系",
            "無相生干預體內世界、信仰香火願力、言出法隨群傷、星系間穿梭", "宇宙職能、神道神位、三律操作、三千大界規模",
            None, 25, 300),
    8: Tier(("天庭受封正神", "神皇"), "宇宙",
            "固有宇宙職能（雷罰、司雨等）、力量暴漲但神魂被天道綁定", "自創道路、三律、拒絕天道受封的行為",
            None, 25, 1000),
    9: Tier(("自創道祖", "混元大羅金仙"), "三千大界",
            "拒絕天道受封、創神→造神→成神三階段、撕裂天道秩序", "太上衍命樞操作、三律同時持有、天道對弈棋局",
            None, 25, 1000),
    10: Tier(("超脫者", "天道棋手"), "三千大界",
             "同時持有三律、太上衍命樞棋局操作、撥弄時間與因果", "成為天道本身、寫入至高常數、靈能總量鎖定",
             None, 25, 1000),
    11: Tier(("身合大道", "新天道"), "寰宇",
             "舊天道崩解、寫入至高常數、掌管萬界命運、成為規則本身", "（無上限，但敘事需維持超然感）",
             None, 25, 1000),
}
MAX_LV = max(TIERS)
# 道階（法則領域世界設計 E2）：道階名 → （範圍, 做得到, 禁止描寫）。算到哪一階看 laws.dao
DAO_TIERS: dict[str, tuple[str, str, str]] = {
    "現象": ("", "看見、記下", "借用任何法則之力"),
    "殘理": ("照境界砍", "借用一條現象的力量（引火、喚風）", "改變現象的規律"),
    "法則": ("照境界砍", "組招、壓制同系術法", "改寫一片範圍的規矩"),
    "領域": ("一個地點", "展開領域、改寫規矩、局部示現、收碎片", "把範圍變成自己的世界"),
    "世界": ("一個村鎮", "展開成自己的世界、撕下碎片", "改自己的劫"),
    "大道": ("", "定世界的命運、改劫", "無相生、信仰神道"),
}
GATES = {6: 1}   # 要主動踏入的小境界（16l 第 6 題：破格期；不宣告就停在天仙境、壽元照常）
GATE_NOTE = "主動踏入破格期"
ASCEND_LV = 7    # 破空：到這一層就離開原世界去仙域（16l）
LADDER: dict[int, tuple[str, ...]] = {lv: t.names for lv, t in TIERS.items()}

# 文風隨境界演變（總綱 1.5，沿用舊版 realm_system 的風格表）。氛圍上處處危險，但機制上不輕易暴斃。
STYLES: dict[int, str] = {
    0: "低魔、泥濘、飢餓感、處處危險", 1: "低魔、泥濘、飢餓感、處處危險", 2: "低魔、泥濘、飢餓感、處處危險",
    3: "高魔仙俠、法則初窺、因果糾纏", 4: "高魔仙俠、法則初窺、因果糾纏",
    5: "陸地神仙、改天換地", 6: "天威浩蕩、逆天破格、生死一瞬", 7: "星瀚浩渺、造物主視角",
    8: "神威如海、身不由己、枷鎖下的傀儡感", 9: "孤高逆天、萬道始祖", 10: "太上忘情、萬物皆為棋子",
    11: "絕對理性、至高寂靜",
}


def stage_name(realm_lv: int, stage_index: int) -> str:
    return TIERS[realm_lv].names[stage_index]


def last_stage(realm_lv: int) -> int:
    return len(TIERS[realm_lv].names) - 1


def at_bottleneck(realm_lv: int, stage_index: int, cultivation: int) -> bool:
    """修為已滿、處於這一層最後一個小境界，而且上面還有境界：要主動突破才能再往上。"""
    return realm_lv < MAX_LV and stage_index == last_stage(realm_lv) and cultivation >= PROGRESS_PER_STAGE


def at_gate(realm_lv: int, stage_index: int, cultivation: int) -> bool:
    """修為已滿，下一個小境界要主動踏入（破格期）。"""
    return GATES.get(realm_lv) == stage_index + 1 and cultivation >= PROGRESS_PER_STAGE


def advance(realm_lv: int, stage_index: int, cultivation: int, gated: bool = True) -> tuple[int, int, int, list[str]]:
    """修為滿 100 往下一個小境界推進（可連續推進），遇到大境界瓶頸就停在 100。
    gated：主角停在要主動踏入的小境界前（16l 第 6 題）；NPC 照舊自動推進。

    回傳 (lv, stage, cultivation, 推進到的小境界名稱)。這裡永遠不會改變大境界 lv。
    迴圈次數受小境界數量限制（最多 3 次），不會因為修為數字很大而跑很久。
    """
    events: list[str] = []
    while cultivation >= PROGRESS_PER_STAGE and stage_index < last_stage(realm_lv) and not (
            gated and GATES.get(realm_lv) == stage_index + 1):
        stage_index += 1
        cultivation -= PROGRESS_PER_STAGE
        events.append(stage_name(realm_lv, stage_index))
    return realm_lv, stage_index, max(0, min(cultivation, PROGRESS_PER_STAGE)), events


def prompt_guide(realm_lv: int, dao: str = "現象") -> str:
    """給說書人的境界規格：境界管肉身、道階管法則，兩份都給（E0、E2）。"""
    t, (reach, can, cannot) = TIERS[realm_lv], DAO_TIERS[dao]
    return (f"文風：{STYLES[realm_lv]}。肉身一擊、行動所及約：{t.scale}。肉身做得到：{t.narrative_cap}；"
            f"做不到、不可描寫成功：{t.forbidden}。道階「{dao}」"
            f"{f'（範圍{reach}）' if reach else ''}做得到：{can}；做不到、不可描寫成功：{cannot}。")
