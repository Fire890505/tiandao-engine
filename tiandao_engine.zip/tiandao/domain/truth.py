"""真相分法的兩讀效果（第 6-5c 批；命途重設計.md 第六節、第十一節第 4 題甲）：從出生起照真讀法在世界裡算、不明講。
每種命每讀只接一條主效果、只用現有系統，數字暫定小。纏絲命這批不接（世界沒記曾是戀人的人，第 6-5c 題甲）；
記下不做：渡壽主動渡壽、寄身封越多力量越大、眾推帳仇轉移、啟封命主找別人開。"""
from __future__ import annotations

import random

from . import opinion, society, stage
from .clock import SHICHEN_PER_YEAR

NONE = ("", 0, "", frozenset())   # 背景演化看的命：（特殊命, 哪一讀, 主角所在, 身邊的人）
LOVE = ("戀人", "伴侶")
SMALL = 3          # 判定小加：風起讀二套話、寄身讀二硬撐
DISASTER = 0.05    # 孤星：每年多一次局部天災的機會（讀一落在主角所在，讀二落在別處）
QI = 1.1           # 地氣讀一：吐納吸地氣
PUSH = {("地氣命", 1): "靈氣-", ("地氣命", 2): "靈氣+", ("風起命", 1): "人心-"}   # 主角所在村鎮每年
PLUS = {"旺人命": 20, "情劫命": 30}   # NPC 衝關千分比（旺人：友善以上；情劫讀二：戀人伴侶）
HURT = 0.05        # 情劫：戀人伴侶每年重傷的機會
MATE_HURT = 0.02   # 孤星（待接，第 6-5d 批，兩讀都算）：隨行同伴每年重傷的機會
LIFE = 0.2         # 旺人讀二（有友善以上的人）、渡壽讀一（有親近以上的人）：每年扣一年壽元的機會
LIFE_AT = {("旺人命", 2): society.FRIEND_AT, ("渡壽命", 1): 60}
SPITE = 0.2        # 寄身讀一：亡者現身時被借了身
GRIND = 5          # 礪：跟命主交手的修為
SAVE = ("救人", "救治", "治病", "醫治", "療傷", "續命")   # 渡壽讀二：救人成功扣一年壽元
BOSS = {1: opinion.hit(opinion.FATE, opinion.LIKE, opinion.SMALL),        # 眾推讀一：成員每年好感小加
        2: opinion.hit(opinion.FATE, opinion.TRUST, opinion.SMALL, -1)}   # 眾推讀二：成員每年信任小降


def key(sheet: dict) -> tuple[str, int]:
    return sheet.get("hidden", ""), sheet.get("reading", 0)


def years(start: int, end: int) -> list[int]:
    """(start, end] 跨過的年頭（最多十年，同天災）。"""
    return list(range(max(start // SHICHEN_PER_YEAR + 1, end // SHICHEN_PER_YEAR - 9), end // SHICHEN_PER_YEAR + 1))


def world(sheet: dict, mine: list[dict], life: str) -> tuple:
    """第四項是身邊的人：情劫看戀人伴侶，孤星看隨行同伴（待接，第 6-5d 批）。"""
    if not sheet.get("hidden"):
        return NONE
    near = frozenset(m["name"] for m in sheet.get("party", ()) if m["role"] == "同伴") if sheet["hidden"] == "孤星命" \
        else frozenset(b["b"] if b["a"] == life else b["a"] for b in mine if b["type"] in LOVE)
    return (*key(sheet), sheet.get("location", ""), near)


def npc(fate: tuple, p: dict, relation: dict | None) -> tuple[int, float]:
    """NPC 演化：（衝關千分比加多少, 每年重傷的機會）。"""
    name, reading, where, near = fate
    if name == "旺人命" and (relation or {}).get("affinity", 0) >= society.FRIEND_AT and (reading == 2 or p["location"] == where):
        return PLUS[name], 0
    if name == "情劫命" and p["name"] in near:
        return PLUS[name] * (reading == 2), HURT
    if name == "孤星命" and p["name"] in near:
        return 0, MATE_HURT
    return 0, 0


def checks(sheet: dict) -> dict:
    return {("風起命", 2): {"套話": SMALL}, ("寄身命", 2): {"硬撐": SMALL}}.get(key(sheet), {})


def qi(sheet: dict) -> float:
    return QI if key(sheet) == ("地氣命", 1) else 1


def pushes(sheet: dict, n: int) -> list[str]:
    """主角所在村鎮這段時間的壓力。"""
    word = PUSH.get(key(sheet))
    return [f"{word}{min(n, 4)}"] if word and n else []


def struck(sheet: dict, rng: random.Random, ys: list[int], towns: list[str], here: str) -> list[tuple[str, int]]:
    """孤星多出來的局部天災：[(村鎮, 哪一年)]。"""
    name, reading = key(sheet)
    pool = [here] if reading == 1 else [t for t in towns if t != here]
    return [(rng.choice(pool), y) for y in ys if rng.random() < DISASTER] if name == "孤星命" and pool and here else []


def lifespan(sheet: dict, rng: random.Random, n: int, relations: dict) -> int:
    at = LIFE_AT.get(key(sheet))
    near = at is not None and any(r.get("affinity", 0) >= at for r in relations.values())
    return -sum(rng.random() < LIFE for _ in range(n)) if near else 0


def possessed(sheet: dict, rng: random.Random) -> bool:
    return key(sheet) == ("寄身命", 1) and rng.random() < SPITE


def rested(sheet: dict) -> str:
    """聞冥：幽魂安息時那地方的人心（讀一照做卻傷到無辜，讀二冤得報）。"""
    return {("聞冥命", 1): "人心-1", ("聞冥命", 2): "人心+1"}.get(key(sheet), "")


def closed(sheet: dict, r: dict) -> list[str]:
    """啟封讀一：開封（抗著）收章，那地方凶險 +1。"""
    return [stage.PRESS + "凶險+1"] if key(sheet) == ("啟封命", 1) == (r["name"], 1) and stage.end_of(r) == stage.AGAINST else []


def rival(sheet: dict) -> str:
    """礪的命主：手上這章的，沒有就上一章的。"""
    r = next((x for x in (sheet.get("route"), sheet.get("chapter")) if stage.chapter(x) and x.get("cast")), None)
    return stage.foe(r) if r else (sheet["chapters"][-1].split(":")[2] if sheet.get("chapters") else "")


def after(sheet: dict, *, target: str, rolled: bool, success: bool, words: str) -> dict:
    """判定之後：礪（對命主）、渡壽讀二（救人成功）。"""
    k = key(sheet)
    if k[0] == "礪命" and rolled and target and target == rival(sheet) and (k[1] == 2 or not success):
        return {**sheet, "cultivation": min(100, sheet["cultivation"] + GRIND)}
    if k == ("渡壽命", 2) and success and target and any(w in words for w in SAVE):
        return {**sheet, "lifespan_adjust": sheet["lifespan_adjust"] - 1}
    return sheet


def members(sheet: dict, mine: list[dict], bonds: list[dict], life: str) -> tuple[list[str], object]:
    """眾推：主角當首領的勢力成員，和每年要記的那筆原因。"""
    k = key(sheet)
    if k[0] != "眾推命":
        return [], None
    led = {b["b"] for b in mine if b["type"] == "首領" and b["a"] == life}
    return [b["a"] for b in bonds if b["type"] == "成員" and b["b"] in led], BOSS[k[1]]
