"""路線（WHITEPAPER 16v 第 1～9、18 題；數字暫定）：主角手上那一件事。純函式。

- 同一時間一條主路線。天道發的（HEAVEN）或自己接的（SELF）；內容在 rules/content/routes.txt。
- 天道的鐘：上一條天道路線結束起，隔幾回合發下一條，注視越高間隔越短（第 66 題）。手上有事就排隊。
- 自己接：查到線索（手上有別條要查到第二條）、撞上怪談、傳說、亡者。
- 事端自己會走到結局；怪談、傳說、亡者沒有結局，路線到期就算過去，留下後果。
角色卡欄位：route、route_old（換線前那一條）、route_turn（天道的鐘）、route_last（上一條的種類）、scars（路線結局留在主角身上的事，第 73 題）、
echoes、echo_turn（見 domain/echo.py）。
"""
from __future__ import annotations

import random

from ..config import PROJECT_ROOT
from . import echo, heaven, names, realm, stage
from .clock import SHICHEN_PER_DAY
from .incident import WORLD

TABLE = names.read_table(PROJECT_ROOT / "rules" / "content" / "routes.txt")
PLOT, ZONE, LEGEND, GHOST, FATE = "事端", "怪談", "傳說", "亡者", "命途"
HEAVEN, SELF = "天道", "自接"
GAP_TURNS = 3
SPEED = (1, 0.75, 0.5, 1 / 3)       # 注視四段（heaven.FEELING_FROM）的間隔倍數
LIMIT = 60 * SHICHEN_PER_DAY        # 第 18 題：沒有結局的路線多久算過去
AFTER_DAYS = 90                     # 後果留多久
SWITCH = 2                          # 手上有路線，要查到幾條才換
SAME_KIND = 0.5                     # 跟上一條同類，機率打折
TRACE = "路線餘波"
# 權重：注視低多抽日常事端和怪談，高多抽命途和跟主角本人有關的（第 7 題）
WEIGHTS = {PLOT: (4, 3, 2, 1), ZONE: (3, 3, 2, 1), LEGEND: (2, 2, 2, 2), GHOST: (1, 2, 3, 3), FATE: (1, 2, 4, 6)}
AFTER = {ZONE: "{地}的怪事一直沒人管，這段日子又有人不見了", LEGEND: "{地}的傳說越傳越凶，這段日子有人出了事",
         GHOST: "{地}的亡者一直沒人理會，附近的人開始繞路走"}
WORDS = {ZONE: "怪事", LEGEND: "傳說", GHOST: "亡者的事"}   # 還沒有階段表的路線怎麼叫


def fields() -> dict:
    """chapter：被擠開的章（進度和放著幾回合 idle，第 6-3-4 題甲）；chapters：了結的章，「抗著:1:張三:交友」＝結局:信哪一讀:牽扯的人:落在哪一宮（第 6-4-4 題甲、第 129 系列）；
    opened：一般命開著的章 {plot, palace, who, like}（第 116c 批，game/fated.py）；
    gripped：被你要脅過、還沒回來當命主的人，最近的在後（第 6-6c 批，routes._heir）；
    called：命數找上過你的人，最近的在後，你下一章他那宮 ×2、抽中他先，開章就清掉（併章重設計第 7 題乙，routes.land）。"""
    return {"route": None, "route_old": "", "route_turn": 0, "route_last": "", "scars": [], "chapter": None, "chapters": [], "opened": None,
            "gripped": [], "called": [],
            **echo.fields()}


def label(r: dict | None) -> str:
    """玩家看到的主線：用叫法和地方，路線的名字可能洩底（「村裡的內應」）。"""
    if not r:
        return ""
    word = WORDS.get(r["kind"]) or stage.word(r)
    return f"{word}（{r['place']}）" if r["place"] else word


def holds(sheet: dict, key: str) -> bool:
    return (sheet.get("route") or {}).get("key") == key


def busy(sheet: dict, key: str) -> bool:
    """手上有別條路線：這件事對主角是背景。"""
    return bool(sheet.get("route")) and not holds(sheet, key)


def band(sheet: dict) -> int:
    return sum(sheet["gaze"] >= v for v in heaven.FEELING_FROM)


def due(sheet: dict, turn_no: int) -> bool:
    """天道該發下一條了沒。手上有事就等，走完馬上發。"""
    return not sheet["route"] and turn_no - sheet["route_turn"] >= GAP_TURNS * SPEED[band(sheet)]


def take(sheet: dict, kind: str, name: str, key: str, place: str, by: str, now: int) -> dict:
    """name：模板的名字，專屬牌看它。手上的章被擠開，進度存起來。"""
    old = sheet["route"]
    saved = {"chapter": {**old, "idle": 0}} if stage.chapter(old) and old["key"] != key else {}
    return {**sheet, **saved, "route": {"kind": kind, "name": name, "key": key, "place": place, "by": by, "since": now, **stage.fields()},
            "route_old": old["key"] if old else sheet["route_old"], "card": None, "card_turn": 0, "card_wait": None, "route_idle": 0, "route_tried": 0, "card_used": []}


def clue(sheet: dict, name: str, key: str, count: int, place: str, now: int) -> dict:
    """查到線索：手上空著就接下；手上有別條，查到第二條才換；回頭查換走的那條，一條就換回來。"""
    if holds(sheet, key) or sheet["route"] and count < SWITCH and key != sheet["route_old"]:
        return sheet
    return take(sheet, PLOT, name, key, place, SELF, now)


def finish(sheet: dict, turn_no: int) -> dict:
    """走完：天道發的才重新算鐘，自己接的不讓鐘停。"""
    r = sheet["route"]
    clock = {"route_turn": turn_no} if r["by"] == HEAVEN else {}
    return {**sheet, "route": None, "route_last": r["kind"], "card": None, **clock}


def late(r: dict, now: int) -> bool:
    return r["kind"] != PLOT and not stage.chapter(r) and now >= r["since"] + LIMIT


def scope(lv: int) -> int:
    """這個境界該走到第幾章（第 115 題）：村落第一章、鄉鎮第二章……世界第五章。"""
    s = realm.TIERS[lv].scale
    return stage.LADDER.index(s) + 1 if s in stage.LADDER else 1 if lv < 3 else len(stage.LADDER)


def gap(scale: str, lv: int) -> int:
    """這件事的範圍比你境界的範圍高幾級（第 116-3 題）：正＝高（只聽傳聞）、0＝同（找上你）、負＝低（碰上才管）。家算村落。"""
    return (stage.LADDER.index(scale) if scale in stage.LADDER else 0) + 1 - scope(lv)


def chapter_no(sheet: dict) -> int:
    """該開第幾章：這個範圍的章還沒了結；0＝不用開。一般命也開，章是一條你的事端（第 116-12 題甲，game/fated.py）。"""
    done = len(sheet["chapters"])
    return done + 1 if done < scope(sheet["realm_lv"]) else 0


def owes(sheet: dict) -> bool:
    """因果未了（第 6-4-2 題甲）：特殊命這個範圍的章還沒了結；一般命是開了還沒收（沒開成不罰，第 116-12 題）。"""
    return bool(chapter_no(sheet)) and bool(sheet["hidden"] or sheet.get("opened"))


def last(sheet: dict) -> tuple[str, str, str, str]:
    """上一章：（結局, 信哪一讀, 牽扯的人, 落在哪一宮）。"""
    return tuple(((sheet["chapters"] or [""])[-1].split(":") + ["", "", "", ""])[:4])


def holder(sheet: dict) -> tuple[str, str]:
    """你開著的那章的（人, 宮）（併章用，第 7-4c 批）：一般命開著的章，特殊命手上或存著的章的命主；沒開著回兩個空字串。"""
    if sheet.get("opened"):
        return sheet["opened"]["who"], sheet["opened"]["palace"]
    r = next((x for x in (sheet.get("route"), sheet.get("chapter")) if stage.chapter(x) and x.get("cast")), None)
    return (stage.foe(r), r.get("palace", "")) if r else ("", "")


def tally(sheet: dict) -> int:
    """信對幾次減信錯幾次（第 6-5-2 題甲）：chapters 第二項，沒選（0）不算。"""
    reads = [c.split(":")[1] for c in sheet["chapters"]]
    return sum(1 if b == str(sheet["reading"]) else -1 for b in reads if b not in ("", "0"))


def chapter(sheet: dict, now: int, place: str = "") -> dict | None:
    """主線空著時天道先發章（第 6-3-1、6-3-4、6-4-1 題甲）：被擠開的那章發回來；該開下一章就開，place 是開章的地方（第一章跟著人）。
    都沒有回傳 None。"""
    ch = sheet["chapter"]
    if ch:
        return {**take(sheet, FATE, ch["name"], ch["key"], ch["place"], HEAVEN, now), "route": {k: v for k, v in ch.items() if k != "idle"}, "chapter": None}
    n = chapter_no(sheet) if sheet["hidden"] else 0
    return take(sheet, FATE, sheet["hidden"], f"{stage.CHAPTER}{n}", place if n > 1 else "", HEAVEN, now) if n else None


def settle(sheet: dict, lv: int) -> dict:
    """衝關到下一個範圍（第 6-4-2 題甲，不管成敗）：這個範圍的章當放著收掉。手上的、存著的直接走到「被帶向」，
    回到主線時照放著收場；還沒開的記一筆放著；一般命開著的章當放著收，事端照樣在世界上走（第 116-12 題）。lv：衝關前的境界。"""
    o = sheet.get("opened")
    if not chapter_no(sheet) or lv >= realm.MAX_LV or realm.TIERS[lv].scale == realm.TIERS[lv + 1].scale:
        return sheet
    if o:
        return {**sheet, "opened": None, "chapters": [*sheet["chapters"], f"{stage.LEFT}:0:{o['who']}:{o['palace']}"]}
    if stage.chapter(sheet["route"]):
        return {**sheet, "route": stage.leave(sheet["route"])}
    if sheet["chapter"]:
        return {**sheet, "chapter": stage.leave(sheet["chapter"])}
    return {**sheet, "chapters": [*sheet["chapters"], f"{stage.LEFT}:0::"]}


def wait(sheet: dict, turn_no: int) -> dict:
    """被擠開的章照樣放著（第 6-3-4 題甲）：命不等人，放夠了就往前一階，最多走到「被帶向」。"""
    ch = sheet["chapter"]
    if not ch:
        return sheet
    after = stage.advance({**ch, "idle": ch["idle"] + 1}, act="", ok=False, found=set(), idle=ch["idle"] + 1, turn_no=turn_no)
    return {**sheet, "chapter": {**after, "idle": 0} if after["stage"] != ch["stage"] else after}


def aftermath(r: dict, now: int) -> dict | None:
    """到期留下的地點狀況。"""
    text = AFTER.get(r["kind"], "")
    return {"place": r["place"], "name": TRACE, "text": text.format(地=r["place"])[:80], "source": WORLD, "game": None,
            "started_shichen": now, "ends_shichen": now + AFTER_DAYS * SHICHEN_PER_DAY} if text else None


def tags(sheet: dict, place_type: str) -> set[str]:
    return {sheet["origin"], sheet["fate"], sheet["hidden"], sheet["race"], sheet["lineage"], place_type}   # 兩個命都算（第 6-2-2 題甲）


def weight(kind: str, name: str, sheet: dict, mine: set[str], rivals: int = 1) -> float:
    """rivals：同一種有幾條可抽。權重是給一種的，不然地點多的怪談、傳說會把事端淹掉。"""
    hits = len(mine & set(TABLE["適合"].get(name, ())))
    return WEIGHTS[kind][band(sheet)] * 2 ** hits * (SAME_KIND if kind == sheet["route_last"] else 1) / rivals


def opening(rng: random.Random, name: str, lone: bool) -> str:
    """開頭。還沒寫的用通用開頭；沒有家人的人不抽家人那一句。"""
    lines = TABLE["開頭"].get(name) or [t for t in TABLE["通用"] if not (lone and "家人" in t)]
    return rng.choice(lines)


def valid(sheet: dict) -> bool:
    r = sheet["route"]
    fine = r is None or isinstance(r, dict) and all(isinstance(r.get(k), str) for k in ("kind", "name", "key", "place", "by")) \
        and isinstance(r.get("since"), int) and stage.valid(r)
    ch = sheet["chapter"]
    fine = fine and (ch is None or isinstance(ch, dict) and isinstance(ch.get("idle"), int) and stage.valid(ch)) \
        and isinstance(sheet["chapters"], list) and all(isinstance(c, str) for c in sheet["chapters"]) \
        and (sheet.get("opened") is None or isinstance(sheet["opened"], dict))
    return (fine and isinstance(sheet["route_old"], str) and isinstance(sheet["route_last"], str)
            and isinstance(sheet["route_turn"], int) and isinstance(sheet["scars"], list) and echo.valid(sheet)
            and all(isinstance(sheet[k], list) and all(isinstance(g, str) for g in sheet[k]) for k in ("gripped", "called")))
