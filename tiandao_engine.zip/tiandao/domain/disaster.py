"""年景、天災、天變（2026-10-13，WHITEPAPER 16j 第 3、4、6 題；第 9 組草稿批次二）。純函式。

- 年景：每年由國名＋年份擲（不必存），權重看氣候。旱年夏天一季旱災、澇年夏天一個月水災、寒冬冬天一季雪災、
  蝗年秋天一個月蝗災；乾燥的地方夏天另有三成機會山火（一個月）。
- 不看氣候的：地震（3%，一個月餘震）、瘟疫（3%，三個月）、未來的人造災害（3%，一個月）；
  天變：靈潮（3%，一季）、靈氣枯竭（2%，一季）、妖獸潮（3%，一個月）。
  7-3c1（WHITEPAPER (65)）：瘟疫、靈氣枯竭、靈潮、妖獸潮的機率看州裡幾成村鎮那條壓力到盡頭（LEAN、lean），最多翻倍或減半。
  地震、瘟疫、人造災害落在區域裡的一個城鎮或村落；其他是整個區域（地點狀況的 place 是空字串）。
- 開始時寫成地點狀況（第 9b 步），說書人看得到、傳聞傳開、受災地點描述標記要重寫。
- 後果：旱災、蝗災、水災期間凡人店買價 × 1.5（現代、未來 × 1.2）；瘟疫、地震、水災、人造災害開始時，
  受災地點的凡人每人 5% 罹難（現代、未來減半）；瘟疫期間待在受災地點每回合 10% 染疫（負面狀態 40，30 天）；
  靈潮修煉 +30%、靈氣枯竭 −30%；妖獸潮期間歷練類事件權重加倍。名字跟著時代換說法。
- 主角能做的（第 5 題；批次三）：救災（交談或做工說賑災、救人……，成功名聲往善、在場凡人好感 +5；
  瘟疫期間點名清心丹救人，用掉一顆、他好感 +20）；趁火打劫（偷竊、擄人判定 +15）；
  靈潮期間衝關多一個契機（breakthrough.SURGE_BONUS）；妖獸潮期間野外打贏得一顆妖丹。
"""
from __future__ import annotations

import random
from dataclasses import dataclass

from . import crime, incident, opinion, status
from . import era as era_mod
from . import judgment as J
from .clock import SHICHEN_PER_DAY, SHICHEN_PER_MONTH, SHICHEN_PER_YEAR


@dataclass(frozen=True)
class Kind:
    name: str
    text: str            # 地點狀況的一句（說書人、玩家看得到）
    months: int
    price: bool = False  # 物價上漲
    deadly: bool = False  # 開始時凡人可能罹難
    local: bool = False  # 落在一個城鎮或村落（否則整個區域）
    qi: float = 1        # 修煉的修為倍數
    eras: tuple = era_mod.ERAS


DROUGHT = Kind("旱災", "久旱不雨，田地龜裂", 3, price=True)
FLOOD = Kind("水災", "大水漫過田舍，到處泥濘", 1, price=True, deadly=True)
FROST = Kind("雪災", "大雪封路，牲畜凍斃", 3)
LOCUST = Kind("蝗災", "蝗蟲過境，莊稼一夜啃光", 1, price=True)
WILDFIRE = Kind("山火", "山火連燒數日，濃煙蔽天", 1)
QUAKE = Kind("地震", "地動山搖，房舍傾頹，餘震不斷", 1, deadly=True, local=True)
PLAGUE = Kind("瘟疫", "瘟疫流行，家家閉戶", 3, deadly=True, local=True)
LEAK = Kind("輻射外洩", "輻射外洩，居民撤離", 1, deadly=True, local=True, eras=(era_mod.FUTURE,))
BLACKOUT = Kind("大停電", "全城大停電，秩序大亂", 1, local=True, eras=(era_mod.FUTURE,))
SURGE = Kind("靈潮", "天地靈氣暴漲，草木瘋長，妖獸躁動", 3, qi=1.3)
DEARTH = Kind("靈氣枯竭", "天地靈氣稀薄，吐納艱難", 3, qi=0.7)
BEASTS = Kind("妖獸潮", "妖獸成群出沒，野外人畜難安", 1)
KINDS = (DROUGHT, FLOOD, FROST, LOCUST, WILDFIRE, QUAKE, PLAGUE, LEAK, BLACKOUT, SURGE, DEARTH, BEASTS)
BY_NAME = {k.name: k for k in KINDS}

YEARS = {"風調雨順": 5, "旱年": 1, "澇年": 1, "寒冬": 1, "蝗年": 1}
YEAR_BOOST = {"乾燥": {"旱年": 3}, "濕熱": {"澇年": 3}, "寒冷": {"寒冬": 3}, "高山": {"寒冬": 2}}
FROM_YEAR = {"旱年": (DROUGHT, 3), "澇年": (FLOOD, 4), "寒冬": (FROST, 9), "蝗年": (LOCUST, 6)}   # 天災, 從第幾個月開始
FIRE_CHANCE, FIRE_MONTH = 0.3, 4
CHANCES = ((QUAKE, 0.03), (PLAGUE, 0.03), (LEAK, 0.03), (SURGE, 0.03), (DEARTH, 0.02), (BEASTS, 0.03))
ERA_NAMES = {era_mod.MODERN: {"瘟疫": "疫情", "蝗災": "蟲害", "山火": "野火"},
             era_mod.FUTURE: {"瘟疫": "疫情", "蝗災": "蟲害", "山火": "野火"}}
SURGE_PRICE, DEATH_SHARE, MODERN_SOFTEN = (1.5, 1.2), 0.05, 0.5
SICK = ("染疫", status.NEGATIVE, 40, 30 * SHICHEN_PER_DAY)
SICK_CHANCE = 0.1
BEAST_BOOST = 2
WILDERNESS = "歷練"   # incident 的事件種類
RELIEF = ("賑災", "救人", "治病", "施粥", "止雨", "滅火")
RELIEF_HIT = [opinion.hit(opinion.HELP, opinion.LIKE, opinion.SMALL)]   # 救災：在場的凡人記一筆幫忙
CURE_HIT = [opinion.hit(opinion.SAVE, opinion.LIKE, opinion.GRAVE)]     # 瘟疫救治：救命
LOOTING = 15
LOOT_WORDS = crime.WORDS[crime.THEFT] + crime.WORDS[crime.ABDUCT]
WILD = ("荒野", "秘境")


def year_of(nation: str, climate: str, year: int) -> str:
    weights = {y: n * YEAR_BOOST.get(climate, {}).get(y, 1) for y, n in YEARS.items()}
    rng = random.Random(f"{nation}:year:{year}")
    return rng.choices(list(weights), weights=list(weights.values()))[0]


LEAN = {"瘟疫": "糧食-", "靈氣枯竭": "靈氣-", "靈潮": "靈氣+", "妖獸潮": "凶險+"}   # 7-3c1 (65)：哪條壓力到盡頭升機率（另一端降）


def lean(card: dict, towns: list[str]) -> dict[str, float]:
    """州裡幾成村鎮那條到盡頭：機率 ×(1 + 升那端的比例) ×(1 − 降那端的比例 / 2)，最多翻倍或減半。card：壓力卡。"""
    if not towns:
        return {}
    share = lambda k, v: sum(card.get(t, {}).get(k, {}).get("v") == v for t in towns) / len(towns)
    return {n: (1 + share(w[:2], 2 if w[2] == "+" else -2)) * (1 - share(w[:2], -2 if w[2] == "+" else 2) / 2)
            for n, w in LEAN.items()}


def of_year(nation: str, climate: str, era_now: str, year: int, towns: list[str], region: str = "",
            odds: dict[str, float] | None = None) -> list[dict]:
    """這一年的天災與天變（地點狀況的欄位）。towns：區域裡的城鎮、村落（局部的天災落在其中一個）；
    region：整片的天災記在哪（16k：州名；舊世界空字串＝整個區域）。nation：決定年景的名字（16k 起是州名）。
    odds：天災名 → 機率倍數（lean，讀壓力）。"""
    rng = random.Random(f"{nation}:disaster:{year}")
    start = year * SHICHEN_PER_YEAR
    found = [FROM_YEAR[y] for y in [year_of(nation, climate, year)] if y in FROM_YEAR]
    if climate == "乾燥" and rng.random() < FIRE_CHANCE:
        found.append((WILDFIRE, FIRE_MONTH))
    found += [(k, rng.randrange(12)) for k, p in CHANCES if rng.random() < p * (odds or {}).get(k.name, 1)]
    out = []
    for k, month in found:
        if era_now not in k.eras or (k.local and not towns):
            continue
        out.append(state(k, rng.choice(sorted(towns)) if k.local else region, start + month * SHICHEN_PER_MONTH, era_now))
    return out


def state(k: Kind, place: str, begin: int, era_now: str) -> dict:
    return {"place": place, "name": k.name, "text": named(k.text, era_now), "source": incident.WORLD, "game": None,
            "started_shichen": begin, "ends_shichen": begin + k.months * SHICHEN_PER_MONTH}


def fated(rng: random.Random, place: str, year: int, era_now: str) -> dict:
    """孤星多出來的局部天災（真相分法，第 6-5c 批）：那一年開頭落下。"""
    return state(rng.choice([k for k in KINDS if k.local and era_now in k.eras]), place, year * SHICHEN_PER_YEAR, era_now)


def starting(nation: str, climate: str, era_now: str, start: int, end: int, towns: list[str],
             region: str = "", odds: dict[str, float] | None = None) -> list[dict]:
    """在 (start, end] 這段時間開始的天災（一次跨很多年也只算最近十年，免得一次閉關翻出一堆舊災）。"""
    years = range(max(start // SHICHEN_PER_YEAR, end // SHICHEN_PER_YEAR - 9), end // SHICHEN_PER_YEAR + 1)
    return [s for y in years for s in of_year(nation, climate, era_now, y, towns, region, odds)
            if start < s["started_shichen"] <= end]


def named(text: str, era_now: str) -> str:
    for old, new in ERA_NAMES.get(era_now, {}).items():
        text = text.replace(old, new)
    return text


def label(name: str, era_now: str) -> str:
    return ERA_NAMES.get(era_now, {}).get(name, name)


# ── 進行中的天災對這裡的影響 ─────────────────────────────────────────────
def here(states: list[dict], place: str, clock_now: int, region: str = "") -> list[Kind]:
    """此地還在進行的天災、天變（整個區域的、這一州〔region，16k〕的也算）。"""
    return [BY_NAME[s["name"]] for s in states if s["name"] in BY_NAME and s["place"] in ("", place, region)
            and s["started_shichen"] <= clock_now < s["ends_shichen"]]


EASED = "，好在大家早有防備"   # 模型寫的天災：爆發前有人傳話、揭穿（domain/newdisasters.EASE），地點狀況這句接在後面，罹難、漲幅減半


def eased(state: dict) -> bool:
    return state.get("text", "").endswith(EASED)


def price(kinds: list[Kind], era_now: str, ease: bool = False) -> float:
    up = SURGE_PRICE[era_now != era_mod.ANCIENT]
    return (1 + (up - 1) / 2 if ease else up) if any(k.price for k in kinds) else 1


def qi(kinds: list[Kind]) -> float:
    out = 1.0
    for k in kinds:
        out *= k.qi
    return out


def beasts(kinds: list[Kind]) -> dict:
    """妖獸潮：歷練類事件權重加倍（incident.choose 的 boost）。"""
    return {WILDERNESS: BEAST_BOOST} if BEASTS in kinds else {}


def death_chance(era_now: str) -> float:
    return DEATH_SHARE * (1 if era_now == era_mod.ANCIENT else MODERN_SOFTEN)


def victims(rng: random.Random, state: dict, npcs: list[dict], era_now: str) -> list[str]:
    """天災開始時受災地點罹難的凡人；早有防備的減半。"""
    k = BY_NAME[state["name"]]
    if not k.deadly:
        return []
    share = death_chance(era_now) / (2 if eased(state) else 1)
    return [p["name"] for p in npcs if p["status"] == "ALIVE" and p["realm_lv"] == 0
            and state["place"] in ("", p["location"], p.get("region")) and rng.random() < share]


def infect(rng: random.Random, sheet: dict, kinds: list[Kind], clock_now: int) -> tuple[dict, str]:
    """瘟疫期間待在受災地點：每回合 10% 染疫（凡人、修士都會）。"""
    if PLAGUE not in kinds or any(s["name"] == SICK[0] for s in sheet["statuses"]) or rng.random() >= SICK_CHANCE:
        return sheet, ""
    name, kind, magnitude, span = SICK
    statuses = status.add([dict(s) for s in sheet["statuses"]], status.make(name, kind, magnitude, clock_now + span))
    return {**sheet, "statuses": statuses}, f"染上了疫病（留下狀態「{name}」）"


# ── 主角能做的事 ─────────────────────────────────────────────────────────
def relief(kinds: list[Kind], verdict: J.Judgment, words: str) -> bool:
    """救災：受災地點交談或做工，說要賑災、救人……；交談要判定成功（做工不擲骰）。"""
    ok = not verdict.rolled or {J.SUCCESS, J.GREAT_SUCCESS} & {c.outcome for c in verdict.all_checks}
    return bool(kinds and ok) and verdict.action_type in (J.SOCIAL, J.WORK) and any(w in words for w in RELIEF)


def looting(kinds: list[Kind], words: str) -> int:
    """趁火打劫：受災地點偷竊、擄人比較容易得手（人心慌亂、官府自顧不暇）。"""
    return LOOTING if kinds and any(w in words for w in LOOT_WORDS) else 0


def beast_core(kinds: list[Kind], place_type: str, verdict: J.Judgment) -> bool:
    """妖獸潮期間在野外打贏一場：得一顆妖丹。"""
    won = {J.SUCCESS, J.GREAT_SUCCESS} & {c.outcome for c in verdict.all_checks if c.target == J.STRIKE}
    return BEASTS in kinds and place_type in WILD and bool(won)
