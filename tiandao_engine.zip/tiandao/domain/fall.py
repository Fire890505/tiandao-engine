"""滅宗清算（16l 已知限制第 9 條、第 38～40 題）：主角這一邊。純函式；成形的人在 realms._purge。

規則（2026-10-19 與使用者一題一題定案，見 progress/WHITEPAPER.md 16l，數字暫定）：
- 骨架 lost {宗名: 覆滅時的盟}（immortal._fall 記）。
- 主角的宗不在了：成了散仙（不算叛宗、誓言了結、差事作廢、戰功留著；宗主、太上長老也一樣），原盟其他仙宗照原職位
  送招攬（宗主、太上長老記真傳）。
- 追殺你的宗覆滅：改由原盟最強的仙宗接手、等級 −1；永不再收的那一宗覆滅：換成原盟每個仙宗都永不再收。
  原宗沒有盟（或盟裡沒剩下仙宗）就清掉。
- 投靠你的流落門人（骨架 refugees {一生: [名字]}）：下回合當同伴（滿了就算了）。
"""
from __future__ import annotations

from . import party, recruit, sect


def gone(realm: dict, name: str) -> bool:
    """這個宗覆滅了（名字可能被後來的宗用掉，所以也看現在有沒有）。"""
    return name in realm.get("lost", {}) and all(s["name"] != name for s in realm["sects"])


def heirs(realm: dict, name: str) -> list[dict]:
    """覆滅的宗原本那一盟還在的仙宗，最強的在前面。"""
    ally = realm.get("lost", {}).get(name, "")
    return sorted((s for s in realm["sects"] if ally and s["alliance"] == ally), key=lambda s: (-s["power"], s["name"]))


def turn(rng, realm: dict, sheet: dict, life: str, now: int) -> tuple[dict, list[str]]:
    """主角這回合的滅宗清算。回傳（角色卡, 事實）；投靠的人由呼叫端從骨架 refugees 清掉。"""
    facts = []
    if sheet["sect"] and gone(realm, sheet["sect"]):
        hall, rank = sheet["sect"], sheet["sect_rank"] if sheet["sect_rank"] in sect.RANKS else sect.CORE
        sheet = sect.leave({**sheet, "sect_oath": None, "errand": None})
        offers = [recruit.offer(rng, s["name"], rank, now) for s in heirs(realm, hall)]
        sheet = {**sheet, "invites": sheet["invites"] + offers}
        facts += [f"{hall}覆滅了，你成了散仙"] + ([f"{'、'.join(o['sect'] for o in offers)}念在同盟之誼，派人來收留"]
                                                  if offers else [])
    h = sheet["sect_hunt"]
    if h and gone(realm, h["hall"]):
        top = heirs(realm, h["hall"])
        keep = top and h["level"] > 1
        sheet = {**sheet, "sect_hunt": {**h, "hall": top[0]["name"], "level": h["level"] - 1} if keep else None}
        facts.append(f"{h['hall']}覆滅，追殺你的仇由{top[0]['name']}接手" if keep else f"{h['hall']}覆滅，追殺你的人散了")
    bans = {k: v for k, v in sheet["sect_bans"].items() if not gone(realm, k)}
    for k in sorted(set(sheet["sect_bans"]) - set(bans)):
        if sheet["sect_bans"][k] >= sect.FOREVER:
            bans.update({s["name"]: sect.FOREVER for s in heirs(realm, k)})
    sheet = {**sheet, "sect_bans": bans}
    for name in realm.get("refugees", {}).get(life, [])[:party.MAX - len(sheet["party"])]:
        sheet = party.add(sheet, name, party.COMPANION, now)
        facts.append(f"{name}在宗門覆滅後來投靠你")
    return sheet, facts
