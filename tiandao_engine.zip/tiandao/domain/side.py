"""支線（WHITEPAPER 16v 第 67、76～79、104 題）：NPC 和個人的小事。純函式，內容在 rules/content/sides.txt。

- 三個來源：路線自帶、家人的往事、動作牌「開出條件」抽請託。答應才算數，答應了就是一條「我的承諾」線頭。
- 心事開口求你（第 9-5 題，9e-3）：條件「心事」照心事接的支線挑；task 多一欄 worry（辦成要了結的帳、怕、隱情）。
- 命數找上你（併章重設計第 3 題丁）：特殊命 NPC 那章以你為命主、對你好感不低，照那章的宮（條件「宮」）抽一條；你可以勸他（advise）。
- 開口和回音排同一條隊（domain/echo.py），支線滿 3 條不開口。開條件的牌當場開口。
- 辦：人在那裡、行動對上、成功，再問模型這句是不是在辦這件事。給的路要說到花錢。
- 路線來的辦成時主線往前一階。答應了沒辦到期限算失約，照線頭的規則扣關係。
- 條件「暗線:門路」（第 5-4-4 題）：對手動過那道門路、還沒補回才開口（沒寫階就不看階）；辦成算補回那道門路，第一次照樣反撲（domain/dark.py 的 mend）。
角色卡欄位：asking（等主角回話的請託）。進行中的內容記在線頭的 task 欄位。
"""
from __future__ import annotations

from dataclasses import dataclass

from ..config import PROJECT_ROOT
from . import deck, stage
from . import memory as m

ROUTE, PERSON, CARD = "路線", "人物", "牌"
ASK, PAST = "請託:", "往事:"
ACCEPT, DECLINE = "答應", "推掉"
YES = ("答應", "好", "行", "沒問題", "交給我", "我去", "我幫", "幫你", "替你")
NO = ("推掉", "不行", "不要", "不了", "算了", "拒絕", "不好", "不答應", "不幫")
ACTS = {"問": "社交", "查": "查探", "打": "動手"}
GIVE, PAY = "給", ("買", "付", "給", "還", "賠", "花錢", "出錢", "掏錢", "借", "酬", "賞金", "打賞", "贖", "重金")   # 後四個：3-4d 託人、贖身
FAMILY, GONE, FAVOUR = "家人", "走", "好感"
KINDS = "找人 送東西 找東西 打聽 討公道 保密 還債 收帳 護送 除害 調解 求藥 引薦 洗名".split()   # 種類＝辦什麼（第 4-f 題）；來源看條件
CALL, FATE = "命數", "命數:"   # 命數找上你（併章重設計第 3 題丁）：來源、條件「宮」的表頭
MIND, WORRY = "心事", "心事:"   # 心事開口求你（第 9-5 題，9e-3）：來源、條件「心事」的表頭
ADVICE = {stage.AGAINST: ("劃清", "別信我", "離我遠", "斷了"), stage.LEFT: ("放下", "別管", "躲開", "避一避", "別再"),
          stage.ALONG: ("跟著我", "跟我走", "跟我一起", "放手去做", "照你的心意", "別怕")}   # 你勸他那章怎麼收（第 6 題丁）


@dataclass(frozen=True)
class Row:
    key: str
    name: str
    who: str
    stages: tuple[str, ...]
    words: str
    place: str
    next: str
    span: str
    ways: tuple[tuple[str, ...], ...]
    left: str
    left_by: tuple[str, ...]
    gain: tuple[str, ...]
    dark: str = ""    # 暗線動過的門路


def _list(text: str) -> tuple[str, ...]:
    return tuple(filter(None, text.split("、")))


def _read(path) -> dict[str, list[Row]]:
    """共用格式（第 4-5 題）：條件 路線、往事、目的（請託）和 階；目標＝開口的人；結果＝辦成留下。"""
    table: dict[str, list[Row]] = {}
    for c in deck.read(path):
        need, (place, nxt, span, one, two, left, left_by) = dict(c.need), c.more
        assert c.kind in KINDS, c.name
        key = need.get("路線") or (PAST + need["往事"] if "往事" in need else FATE + need["宮"] if "宮" in need
                                  else WORRY + need["心事"] if "心事" in need else ASK + need["目的"])
        table.setdefault(key, []).append(Row(key, c.name, c.target, _list(need.get("階", "")), c.text or c.name, place, nxt, span,
                                             (tuple(one.split(":")), tuple(two.split(":"))), left, _list(deck.bare(left_by)),
                                             _list(deck.bare(c.result)), need.get("暗線", "")))
    return table


TABLE = _read(PROJECT_ROOT / "rules" / "content" / "sides.txt")


def fields() -> dict:
    return {"asking": None}


def _fill(text: str, places: dict[str, str]) -> str:
    for k, v in places.items():
        text = text.replace(f"{{{k}}}", v)
    return text


def offer(row: Row, who: str, places: dict[str, str], origin: str, route_key: str = "", gender: str = "") -> dict:
    """填好地方的請託。places：此地、鄰地、鎮、對象 → 地名。gender：開口的人，{他}照這個換。"""
    fill = lambda text: _fill(text, {**places, "他": "她" if gender == "女" else "他"})   # noqa: E731
    ways = [{"act": w[0], "how": fill(w[1]), "line": fill(w[2]), "town": places[w[3] if len(w) > 3 else row.place]} for w in row.ways]
    return {"name": fill(row.name), "who": who, "words": fill(row.words), "next": fill(row.next), "span": row.span, "origin": origin, "route": route_key,
            "ways": ways, "left": fill(row.left), "left_by": list(row.left_by), "gain": [fill(g) for g in row.gain], "dark": row.dark}


def thread(o: dict, now: int, turn_no: int) -> dict:
    """答應了：變成一條線頭。"""
    span = m.DEADLINES[o["span"]]
    return {"kind": m.MY_PROMISE, "subject_kind": m.NPC, "subject": o["who"], "text": o["name"][:m.THREAD_TEXT_LEN[1]], "status": m.OPEN,
            "deadline_shichen": None if span is None else now + span, "opened_shichen": now, "opened_turn": turn_no, "touched_shichen": now,
            "origin": o["origin"], "next_step": o["next"][:40],
            "task": {k: o[k] for k in ("route", "ways", "left", "left_by", "gain", "dark", "worry") if k in o}}


def reply(text: str) -> bool:
    """主角答應了沒。沒回應算推掉，不再追問。"""
    return not any(w in text for w in NO) and any(w in text for w in YES)


def advise(text: str) -> str:
    """你勸他那章怎麼收（併章重設計第 6 題丁）：順著、抗著、放著；沒勸回空字串。"""
    return next((end for end, words in ADVICE.items() if any(w in text for w in words)), "")


def paying(text: str) -> bool:
    """舊鏈（假說書人空單）看原文有沒有付錢的字；讀懂那條路看「買賣找人＝付錢」（3-4c 第 2 題）。"""
    return any(p in text for p in PAY)


def way(task: dict, tag: str, pay: bool, town: str, money: int) -> dict | None:
    """這回合的行動走得通哪條路。pay：這回合在付錢。"""
    here = [w for w in task["ways"] if w["town"] == town]
    paid = next((w for w in here if w["act"] == GIVE and money > 0 and pay), None)
    return paid or next((w for w in here if ACTS.get(w["act"]) == tag), None)


def valid(sheet: dict) -> bool:
    a = sheet["asking"]
    return a is None or isinstance(a, dict) and all(isinstance(a.get(k), str) for k in ("name", "who", "words", "next", "span", "origin", "route")) \
        and a["span"] in m.DEADLINES and isinstance(a.get("ways"), list)
