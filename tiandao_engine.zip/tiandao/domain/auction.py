"""黑市拍賣會（2026-10-13，WHITEPAPER 16i 第 10-5～10-11 題；第 8 組批次三）。純函式。

- 修士黑市底下的拍賣場，每季開 3 天（每季第 46～48 天）。開拍前 15 天寄邀請函（附拍品清單，寄函時就擲好 3～5 件）。
  收函的條件：去過修士黑市（拿過暗號），而且築基以上、或跟修士黑市集團的人交好。沒有這一季的邀請函進不去。
- 出席的 NPC：築基以上的修士、凡人勢力的首領（身家夠）；各一半機會來，清單上有合胃口的再加，最多 8 人；
  不到 3 人補「遠方來客」（真 NPC）。寄函時就標好每人看上哪幾件、最多出多少。
- 競標：一件一回合。主角說「出價 N」（靈石）；高過所有 NPC 的上限就得標（付自己喊的價），不然出價最高的 NPC 得標。
- 被拍賣的人：成年，帶出身（聖女、皇子、皇女、宗門寵兒、臣子之子、被擄的凡人，容貌體態上乘），盡量接上現有勢力；
  三成有特殊體質。買下的進隨行名單當僕人（記著體質、出身的勢力）。
  - 放走：好感 +30、目標報恩；出身的勢力在地圖上就改當同伴跟著，開線頭「送他回家」，到那裡自動了結、勢力欠你人情。
  - 留下當僕人：出身的勢力每回合一成機會派人來搶（沿用宗門派人）。
  - 爐鼎：閉關修煉時說要用他當爐鼎，修為多加一段；他每次傷一階、好感 −15（NPC 沒有壽元欄位，用傷代替損壽）。
- 角色卡欄位 auction：None 或 {"season", "house", "lots", "bidders", "next"}。
"""
from __future__ import annotations

import random
import re

from . import items, names, newcomer, npc, opinion, party, society
from . import memory as m
from . import judgment as J
from .clock import SHICHEN_PER_DAY, SHICHEN_PER_MONTH

SEASON = 3 * SHICHEN_PER_MONTH
OPEN_DAY, DAYS, NOTICE_DAYS = 45, 3, 15
LOTS = (3, 5)
PERSON_SHARE, PHYSIQUE_SHARE = 0.4, 0.3
TITLES = {"聖女": "宗門", "宗門寵兒": "宗門", "皇子": "國家", "皇女": "國家", "臣子之子": "國家", "被擄的凡人": "凡人"}
FAR = {"宗門": "遠方某宗", "國家": "遠方某國", "凡人": ""}
PERSON_PRICE = {"被擄的凡人": 30}                            # 起標價（靈石）；其他出身 60；有體質 × 2
HIGH_PRICE = 60
INVITE_LV, ATTEND, KEEN, MAX_BIDDERS, MIN_BIDDERS = 2, 0.5, 0.25, 8, 3
WANT = 0.4                                                   # 每個出席者看上每一件的機會
BID_WORDS = ("出價", "喊價", "叫價", "加價")
RELEASE_WORDS = ("放他走", "放她走", "放你走", "放了他", "放了她", "還你自由", "還他自由", "還她自由")
FURNACE_WORDS = ("爐鼎", "雙修")
FURNACE_GAIN = 30
FURNACE_HURT = [opinion.hit(opinion.ATTACK, opinion.LIKE, opinion.BIG, -1)]   # 拿他當爐鼎：動手（大）
GRATEFUL = [opinion.hit(opinion.SAVE, opinion.LIKE, opinion.GRAVE)]          # 贖了他：救命（重）
FETCH_CHANCE = 0.1
GUEST_BY = "auction"                                         # 遠方來客、被拍賣的人：NPC 的 created_by


def fields() -> dict:
    return {"auction": None}


def opens(clock_now: int) -> int:
    """這一季開拍的時刻。"""
    return clock_now // SEASON * SEASON + OPEN_DAY * SHICHEN_PER_DAY


def is_open(clock_now: int) -> bool:
    return 0 <= clock_now - opens(clock_now) < DAYS * SHICHEN_PER_DAY


def season(clock_now: int) -> int:
    return clock_now // SEASON


def due(sheet: dict, clock_now: int) -> bool:
    """這回合該不該寄這一季的邀請函（還沒寄、在開拍前 15 天到散場之間）。"""
    early = opens(clock_now) - NOTICE_DAYS * SHICHEN_PER_DAY
    return early <= clock_now < opens(clock_now) + DAYS * SHICHEN_PER_DAY and \
        (sheet["auction"] or {}).get("season") != season(clock_now)


def closed(sheet: dict, house: str, clock_now: int) -> str:
    """進不了拍賣場的原因（空＝可以進）：沒開、沒有這一季的邀請函。"""
    a = sheet["auction"]
    if not is_open(clock_now):
        return f"{house}今天沒開"
    return "" if a and a["house"] == house and a["season"] == season(clock_now) else "沒有這一季的邀請函，進不去"


def invited(sheet: dict, friendly: bool) -> bool:
    """收函的條件：去過修士黑市，而且築基以上或跟修士黑市集團的人交好。"""
    return any(k.endswith("修士黑市") for k in sheet["codes"]) and (sheet["realm_lv"] >= INVITE_LV or friendly)


# ── 寄函：拍品與出席的人 ─────────────────────────────────────────────────
def lots(rng: random.Random, realm_lv: int, homes: dict[str, str], taken: set[str]) -> list[dict]:
    """3～5 件拍品。homes：出身 → 接得上的勢力名（宗門、國家、凡人）。"""
    out = []
    for _ in range(rng.randint(*LOTS)):
        if rng.random() < PERSON_SHARE:
            title, gender = rng.choice(list(TITLES)), rng.choice(npc.GENDERS)
            name = names.person_names(rng, taken, 1, gender=gender)[0]
            taken.add(name)
            physique = rng.choice(party.PHYSIQUES) if rng.random() < PHYSIQUE_SHARE else ""
            start = PERSON_PRICE.get(title, HIGH_PRICE) * (2 if physique else 1)
            out.append({"kind": "人", "name": name, "gender": gender, "tier": 0, "title": title, "physique": physique,
                        "home": homes.get(TITLES[title]) or FAR[TITLES[title]], "price": start, "sold": ""})
        else:
            kind = rng.choice((items.PILL, items.ARTIFACT, items.TECHNIQUE))
            tier = min(realm_lv + 1, max(items.TIER_LABELS))
            name = items.technique(rng, tier) if kind == items.TECHNIQUE else rng.choice(
                [n for n, i in items.CATALOG.items() if i.kind == kind])
            tier = items.CATALOG[name].tier if items.CATALOG[name].tier is not None else tier
            out.append({"kind": "物", "name": name, "tier": tier, "title": "", "physique": "", "home": "",
                        "price": items.price(name, tier), "sold": ""})
    return out


def bidders(rng: random.Random, candidates: list[dict], lots_: list[dict]) -> list[dict]:
    """誰出席、看上哪幾件、最多出多少（靈石）。candidates：修士與凡人勢力首領（還活著、成年）。"""
    out = []
    for p in candidates:
        s = seat(rng, p, lots_)
        if len(out) < MAX_BIDDERS and rng.random() < ATTEND + (KEEN if s["max"] else 0):
            out.append(s)
    return out


def seat(rng: random.Random, p: dict, lots_: list[dict]) -> dict:
    """一個出席者：看上哪幾件（拍品序號 → 最多出多少）。"""
    return {"name": p["name"], "max": {str(i): _limit(rng, lot, p) for i, lot in enumerate(lots_)
                                       if rng.random() < _want(lot, p)}}


def _want(lot: dict, p: dict) -> float:
    """有特殊體質的人，惡念高的修士特別想要（當爐鼎）。"""
    return WANT + (0.3 if lot["physique"] and p["kindness"] < 35 else 0)


def _limit(rng: random.Random, lot: dict, p: dict) -> int:
    return round(lot["price"] * (1 + rng.random() * 1.5) * (1 + 0.5 * p["realm_lv"]))


def guest(rng: random.Random, house: str, taken: set[str], land: str = "人族") -> dict:
    """遠方來客（生成資料，service 寫入時用 npc.roll_profile）。"""
    who = newcomer.roll(rng, land)
    name = names.person_names(rng, taken, 1, **who)[0]
    taken.add(name)
    return {"name": name, **who, "profile": "從遠方來參加拍賣會的修士。", "location": house, "age_band": npc.PRIME,
            "power_tier": rng.choice((npc.ADEPT, npc.POWERFUL)), "goal": "尋物", "goal_target": "",
            **{t: rng.choice(list(npc.TRAIT_LEVELS.values())) for t in npc.TRAITS}}


def person(lot: dict, house: str, rng: random.Random) -> dict:
    """被拍賣的人（生成資料）：成年凡人，容貌體態上乘。"""
    home = f"，出身{lot['home']}" if lot["home"] else ""
    return {"name": lot["name"], "race": "人族", "gender": lot.get("gender", ""),   # 拍品名字是人族的；舊存檔的拍品沒有性別
            "profile": f"在拍賣會上被賣的{lot['title']}{home}；容貌、體態上乘。", "location": house,
            "age_band": npc.YOUNG, "power_tier": npc.MORTAL, "goal": "守護" if lot["home"] else "求道",
            "goal_target": "", **{t: rng.choice(list(npc.TRAIT_LEVELS.values())) for t in npc.TRAITS}}


def card(lots_: list[dict], bidders_: list[dict], house: str, clock_now: int) -> dict:
    return {"season": season(clock_now), "house": house, "lots": lots_, "bidders": bidders_, "next": 0}


def lot_text(lot: dict) -> str:
    if lot["kind"] == "物":
        return items.label(lot["name"], lot["tier"])
    return f"{lot['title']}{lot['name']}" + (f"（{lot['physique']}）" if lot["physique"] else "")


def notice(a: dict) -> str:
    return f"收到{a['house']}的邀請函：本季第 {OPEN_DAY + 1} 天起開拍三天，拍品有" + "、".join(lot_text(l) for l in a["lots"])


# ── 競標 ─────────────────────────────────────────────────────────────────
def offer(words: str, deal: str | None = None) -> int | None:
    """主角這回合喊的價（靈石）；沒喊回傳 None。deal：讀懂的買賣找人（3-4d），None＝舊鏈看字。"""
    if not (deal == "買" if deal is not None else any(w in words for w in BID_WORDS)):
        return None
    found = re.search(r"\d+", words)
    return int(found.group()) if found else None


def hammer(a: dict, bid: int | None, stones: int) -> tuple[dict, dict | None, str, int]:
    """拍下一件：回傳（新的 auction, 這件拍品, 得標的人（"" 流拍、"你"＝主角）, 成交價）。
    主角的出價高過所有 NPC 的上限、不低於起標價、付得起，就得標。"""
    i = a["next"]
    if i >= len(a["lots"]):
        return a, None, "", 0
    lot = a["lots"][i]
    rivals = sorted(((b["max"][str(i)], b["name"]) for b in a["bidders"] if str(i) in b["max"]), reverse=True)
    top, rival = rivals[0] if rivals else (0, "")
    if bid is not None and lot["price"] <= bid <= stones and bid > top:
        winner, paid = "你", bid
    elif top >= lot["price"]:
        winner, paid = rival, max(lot["price"], rivals[1][0] + 1 if len(rivals) > 1 else lot["price"])
    else:
        winner, paid = "", 0
    lots_ = [{**l, "sold": winner or "流拍"} if j == i else l for j, l in enumerate(a["lots"])]
    return {**a, "lots": lots_, "next": i + 1}, lot, winner, paid


def text(a: dict | None, clock_now: int, here: str) -> str:
    """給說書人的【拍賣會】：在拍賣場、開拍中才有。"""
    if not a or a["house"] != here or a["season"] != season(clock_now) or not is_open(clock_now):
        return ""
    up = a["lots"][a["next"]] if a["next"] < len(a["lots"]) else None
    seats = "、".join(b["name"] for b in a["bidders"]) or "幾個不具名的買家"
    now = f"現在拍的是第 {a['next'] + 1} 件：{lot_text(up)}，起標 {up['price']} 塊靈石" if up else "拍品都拍完了"
    return f"在場競標的有{seats}；{now}（主角要喊價就說「出價多少」）"


# ── 買下的人 ─────────────────────────────────────────────────────────────
def release(sheet: dict, name: str, words: str, home_place: str, clock_now: int) -> tuple[dict, bool]:
    """放走買來的僕人。回傳（角色卡, 放走了沒）。出身的勢力在地圖上（home_place）就改當同伴，一路送他回去。"""
    m = party.member(sheet, name)
    if not m or m["role"] != party.SERVANT or not any(w in words for w in RELEASE_WORDS):
        return sheet, False
    if home_place:
        return party.add(sheet, name, party.COMPANION, clock_now), True
    return party.drop(sheet, {name}), True


def home_thread(name: str, home: str, clock_now: int, turn_no: int) -> dict:
    """線頭「送他回家」（跟亡者的執念一樣由 Python 開）。"""
    return {"kind": m.MY_PROMISE, "subject_kind": m.NPC, "subject": name, "text": f"送{name}回{home}",
            "status": m.OPEN, "deadline_shichen": None, "opened_shichen": clock_now, "opened_turn": turn_no,
            "touched_shichen": clock_now}


def furnace(sheet: dict, action: str, retreating: bool, words: str) -> str:
    """閉關修煉時說要用買來的特殊體質僕人當爐鼎：回傳他的名字（空＝沒有）。"""
    if action != J.CULTIVATE or not retreating or not any(w in words for w in FURNACE_WORDS):
        return ""
    return next((m["name"] for m in sheet["party"] if m["role"] == party.SERVANT and m["physique"]), "")


def fetch(rng: random.Random, sheet: dict, factions: list[dict]) -> tuple[str, str]:
    """留下當僕人的人，出身的勢力派人來搶：回傳（勢力, 僕人）；沒有回傳空字串。"""
    known = {f["name"] for f in factions}
    for m in sheet["party"]:
        if m["role"] == party.SERVANT and m["home"] in known and rng.random() < FETCH_CHANCE:
            return m["home"], m["name"]
    return "", ""


def homes(factions: list[dict], city: str) -> dict[str, str]:
    """被拍賣的人接得上的勢力：本山、國家、城裡的凡人勢力。"""
    def first(*types: str, at: str | None = None) -> str:
        return next((f["name"] for f in factions if f["type"] in types and at in (None, f["location"])), "")
    return {"宗門": first("宗門"), "國家": first(society.NATION), "凡人": first("家族", "幫派", "商會", at=city)}


def valid(sheet: dict) -> bool:
    a = sheet["auction"]
    return a is None or isinstance(a, dict) and set(a) == {"season", "house", "lots", "bidders", "next"} \
        and isinstance(a["lots"], list) and isinstance(a["bidders"], list) and isinstance(a["next"], int)
