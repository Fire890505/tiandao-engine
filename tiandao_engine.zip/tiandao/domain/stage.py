"""階段表（WHITEPAPER 16v 第 69、71-1、72、73 題）：路線走到哪一步、怎麼往下走、怎麼收場。純函式。內容在 rules/content/stages.txt。

- 一條路線一張表，命途共用一張骨架。怪談、傳說、亡者還沒有表，階段不動。
- 換階：條件任一條成立，至少隔 GAP 回合。條件是這回合成功的行動（查探、社交、動手）、查到的線索或走過的轉折、放著:幾回合。
- 命途：「選擇」那一階放選項，玩家選了記在路線上；「被帶向」那一階注定的事才來；選的決定結局，沒選算應驗。
- 結局看選擇和成敗（第 92-3 題）：失敗走「應驗敗」這種寫法，放到期限走「放著」；沒寫專屬的用這類路線的通用句。
路線欄位：stage（第幾階）、choice（選了什麼）、dug（查探成功過，第三條路要有）、moved（上次換階的回合）、lost（應對失敗）、cast（角色 → 名字）、asked（開過口的支線）、
pushed（上次換階是誰推的）、seen（伏筆見過幾次，domain/foreshadow.py）、way（從第一階走出去的是哪條路：1 玩家碰的、2 放著或對手推的）。
- 暗線（第 81-1、81-5 題）：條件「暗線:N」＝對手走到第 N 步；對手走一步那回合就看，不等 GAP。
- 特殊命的章（第 6-3 批，key 開頭是「章:」）：一階寫兩句用「／」隔開，照 way 挑；結局只有順著、抗著、放著（第 6-3-2 題甲），不分成敗，沒選算放著。
- 後面的章（第 6-4 批，「章:2」起）：階段用共用的「後章」骨架，{事}是這種命在這個範圍的階梯那一行，{人}是命主、{地}是開章的地方；
  選擇、結局寫在「孤星命:後章」這樣的名字底下。
- 命落在哪一宮（第 129 系列）：每章開時抽宮（domain/palace.py），命主是那一宮的「宮」那一行；第一章只抽「首宮」那兩宮。
- 跡象（第 6-5 系列）：章收場照真讀法給一句，國家章明講、確定真讀法（game/routes.py）。
"""
from __future__ import annotations

import random
import re
from contextvars import ContextVar

from ..config import PROJECT_ROOT

CHOOSE, COMING = "選擇", "被帶向"
FULFIL, LOST, LEFT = "應驗", "敗", "放著"
GAP = 2
IDLE, MARK, HERE, PRESS, DARK = "放著:", "記號:", "此地:", "壓:", "暗線:"
PLAYER, RIVAL, LEFT_BE = "玩家", "對手", "放著"   # 這次換階是誰推的（第 81-2 題：只有玩家推的讓對手欠一步）
LOOK = "查探"
CHAPTER, ALONG, AGAINST = "章:", "順著", "抗著"
LATER, BOSS = "後章", "命主"
PALACE, FIRST = "宮", "首宮"   # 第 129 系列：「宮｜命｜宮名｜句｜職業｜性別｜年紀｜描述」、第一章只抽「首宮」那兩宮
LADDER = ("村落", "鄉鎮", "城市", "國家", "世界")   # 第幾章對哪個範圍（第 115 題）
SIGN, NATION = "跡象", 4   # 第 6-5 系列：跡象句；第幾章（國家）確定真讀法


def _read(path) -> dict[tuple[str, str], list[list[str]]]:
    table: dict[tuple[str, str], list[list[str]]] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        if line and not line.startswith("#"):
            field, name, *rest = line.split("｜")
            table.setdefault((field, name), []).append(rest)
    return table


TABLE = _read(PROJECT_ROOT / "rules" / "content" / "stages.txt")
_MINE: ContextVar[dict] = ContextVar("stages_world", default={})


def use(mine: dict) -> None:
    """這個世界模型寫的事端的事、素材、立場、階段（newplots.use 每回合設；待辦 1）。"""
    _MINE.set(mine)


def _get(key: tuple[str, str], default=None):
    return _MINE.get().get(key) or TABLE.get(key, default)


def fields() -> dict:
    return {"stage": 0, "choice": "", "dug": False, "moved": 0, "lost": False, "cast": {}, "asked": [], "pushed": "", "seen": {}, "way": 0,
            "palace": ""}   # 章落在哪一宮（第 129 系列）


def chapter(r: dict | None) -> bool:
    """特殊命的章（第 6-3 批）。"""
    return bool(r) and r.get("key", "").startswith(CHAPTER)


def number(r: dict) -> int:
    """第幾章。"""
    return int(r["key"][len(CHAPTER):])


def later(r: dict | None) -> bool:
    """第二章以後（第 6-4 批）。"""
    return chapter(r) and number(r) > 1


def _n(r: dict) -> str:
    """這條路線的選擇、結局、人物寫在哪個名字底下。"""
    return f"{r['name']}:{LATER}" if later(r) else r["name"]


def _fill(r: dict, text: str) -> str:
    return text.replace("{人}", r["cast"].get(BOSS, "有人")).replace("{地}", r["place"] or "這一帶")


def foe(r: dict) -> str:
    """章裡牽扯的那個人（第 6-4-4 題甲）：命主，或第一章人物的第一個。"""
    return r["cast"].get(BOSS) or next(iter(r["cast"].values()), "")


def _go(r: dict, by: str, turn_no: int) -> dict:
    """往前一階；從第一階走出去時記下走的是哪條路。"""
    way = r["way"] or (r["stage"] == 0) * (1 if by == PLAYER else 2)
    return {**r, "stage": r["stage"] + 1, "moved": turn_no, "pushed": by, "way": way}


def _rows(r: dict) -> list[list[str]]:
    return _get(("階段", LATER if later(r) else r["name"])) or TABLE.get(("階段", r["kind"]), [])


def names(r: dict) -> list[str]:
    """這條路線各階的名字。"""
    return [row[0] for row in _rows(r)]


def now(r: dict) -> str:
    rows = _rows(r)
    return rows[r["stage"]][0] if rows else ""


def last(r: dict) -> bool:
    """走到階段表最後一階（走向母型的收尾，第 4-8 題）；沒有表的路線不算。"""
    rows = _rows(r)
    return bool(rows) and r["stage"] == len(rows) - 1


def word(r: dict) -> str:
    """這件事的叫法。後面的章是階梯那一行。"""
    if later(r):
        return next((t for scale, t in TABLE.get(("階梯", r["name"]), ()) if scale == LADDER[number(r) - 1]), "這件事")
    return _get(("事", r["name"]), [["這件事"]])[0][0]


def stuff(r: dict) -> list[str]:
    """可填的東西：寫景、動作牌的{物}都用這裡（關鍵物只在專屬牌，第 91 題）。"""
    rows = _get(("素材", _n(r)))
    return rows[0][0].split("、") if rows else []


def side(r: dict, cast: dict, who: str) -> str:
    """這個人在這條路線是友、敵還是中。"""
    pairs = _get(("立場", _n(r)), [[""]])[0][0].split("、")
    return next((p[-1] for p in pairs if p and cast.get(p[:-2]) == who), "")


def line(r: dict, rng: random.Random) -> str:
    """給說書人的一句：現在這一階，加兩樣素材。沒有表回傳空字串。"""
    rows = _rows(r)
    if not rows:
        return ""
    things = stuff(r)
    extra = f"。寫景可以用：{'、'.join(rng.sample(things, min(2, len(things))))}" if things else ""
    chose = f"。主角的決定：{r['choice']}" if r["choice"] else ""
    two = rows[r["stage"]][1].split("／")
    row = _palace(r) if chapter(r) else None
    what = f"{word(r)}，{row[1].replace('你', '主角')}" if row and later(r) else word(r)   # 第二章起 {事}＝階梯那行加宮那句（第 129-8 題）
    boss = r["cast"].get(BOSS)   # 命主在這件事裡是誰：宮裡現成的人也照這層意思寫，不改他的人物資料
    who = f"。{boss}在這件事裡是{row[5]}（身分照他本來的）" if row and boss else ""
    text = _fill(r, two[min(max(r["way"], 1), len(two)) - 1].replace("{事}", what))
    text = re.sub(r"\{(\w+)\}", lambda m: r["cast"].get(m[1], m[0]), text)   # 模型事端的句子帶角色和詞（待辦 1）
    return text + who + chose + extra


def _needs(r: dict) -> list[str]:
    rows = _rows(r)
    return list(filter(None, rows[r["stage"]][2].split("、"))) if r["stage"] + 1 < len(rows) else []


def _met(need: str, act: str, ok: bool, found: set[str], idle: int, dark: int) -> str:
    """這個條件成立是誰推的；不成立是空字串。"""
    if need.startswith(IDLE):
        return LEFT_BE if idle >= int(need[len(IDLE):]) else ""
    if need.startswith(DARK):
        return RIVAL if dark >= int(need[len(DARK):]) else ""
    return PLAYER if (need == act and ok) or need in found else ""


def advance(r: dict, *, act: str, ok: bool, found: set[str], idle: int, turn_no: int, dark: int = 0) -> dict:
    """這回合之後走到哪一階。act：這回合對這件事的行動，沒有是空字串。idle：放著不管幾回合。dark：對手走到第幾步。
    幾個條件同時成立時算玩家推的。"""
    r = {**r, "dug": r["dug"] or (act == LOOK and ok)}
    by = {_met(n, act, ok, found, idle, dark) for n in _needs(r)} - {""}
    if not by or turn_no - r["moved"] < GAP:
        return r
    return _go(r, next(b for b in (PLAYER, RIVAL, LEFT_BE) if b in by), turn_no)


def rival(r: dict, dark: int, turn_no: int) -> dict:
    """對手走了一步（第 81-1 題）：這一階寫了「暗線:N」就往前一階，那回合就算，不等 GAP。"""
    hit = any(_met(n, "", False, set(), 0, dark) == RIVAL for n in _needs(r))
    return _go(r, RIVAL, turn_no) if hit else r


def pushed_by_player(r: dict, turn_no: int) -> bool:
    """這回合換階，而且是玩家推的（第 81-2 題）。"""
    return r["moved"] == turn_no and r["pushed"] == PLAYER


def push(r: dict, turn_no: int) -> dict:
    """路線來的支線辦成（第 77 題）：往前一階，不跳階，第三條路也開了。選擇要主角自己做，不替他往下走。"""
    rows = _rows(r)
    step = r["stage"] + 1 < len(rows) and rows[r["stage"]][0] != CHOOSE
    return _go({**r, "dug": True}, PLAYER, turn_no) if step else {**r, "dug": True}


def scar(text: str) -> tuple[str, str]:
    """主角身上的記號：（標籤, 句子）。「地脈:手背上有一道紋」的標籤是地脈；沒有標籤是空字串（第 82-3 題）。"""
    tag, _, rest = text.partition(":")
    return (tag, rest) if rest else ("", text)


def _choices(r: dict) -> list[list[str]]:
    return [row for row in TABLE.get(("選擇", _n(r)), []) if r["dug"] or not row[3]]


def chosen(r: dict, text: str) -> bool:
    """這句是主線的選項：做選擇不算在查破綻。"""
    return any(row[0] == text for row in TABLE.get(("選擇", _n(r)), []))


def keyed(r: dict | None) -> list[tuple[str, tuple[str, ...]]]:
    """在選擇那一階：（選項, 關鍵字）；3-4a 讀懂挑了它、原文要有其中一個字（第二把鑰匙）。"""
    return [(c[0], tuple(w for w in c[2].split("、") if w)) for c in _choices(r)] if r and now(r) == CHOOSE else []


def options(r: dict) -> list[str]:
    """這回合要放的選項。"""
    return [row[0] for row in _choices(r)] if now(r) == CHOOSE else []


def pick(r: dict, text: str, turn_no: int) -> dict:
    """玩家選了：點選項或話裡有關鍵字。"""
    if now(r) != CHOOSE:
        return r
    rows = _choices(r)   # 整句對上的先算，不然別的選項的關鍵字會搶走（「留下來，替這裡擋下」有「留下」）
    row = next((c for c in rows if c[0] == text), None) or next((c for c in rows if any(w in text for w in c[2].split("、"))), None)
    return {**r, "choice": row[0], "stage": r["stage"] + 1, "moved": turn_no, "pushed": PLAYER} if row else r


def end_of(r: dict) -> str:
    return next((row[1] for row in TABLE.get(("選擇", _n(r)), []) if row[0] == r["choice"]), LEFT if chapter(r) else FULFIL)


def belief(r: dict) -> int:
    """章裡玩家信哪一讀（第 6-3-2 題甲）：選了「查到」那條（照另一讀做）是 2，其他選項 1，沒選 0。"""
    row = next((c for c in TABLE.get(("選擇", _n(r)), []) if c[0] == r["choice"]), None)
    return 0 if not row else 2 if row[3] else 1


def _key(r: dict, left: bool) -> str:
    return LEFT if left else end_of(r) + (LOST if r["lost"] and not chapter(r) else "")


def ending(r: dict, left: bool = False) -> tuple[str, list[str]]:
    """（結果, 留下什麼）。left：放到期限。沒寫結局的路線回傳空的。"""
    key = _key(r, left)
    row = next((x for x in TABLE.get(("結局", _n(r)), ()) if x[0] == key), None) \
        or next((x for x in TABLE.get(("結局", r["kind"]), ()) if key.endswith(x[0])), None)
    return (_fill(r, row[1]), list(filter(None, row[2].split("、")))) if row else ("", [])


def leave(r: dict) -> dict:
    """當放著收掉（第 6-4-2 題甲）：直接走到「被帶向」、不算選了什麼；已經在「被帶向」就照選的收。"""
    return r if now(r) == COMING else {**r, "stage": len(_rows(r)) - 1, "choice": ""}


def echoes(r: dict, left: bool = False) -> list[tuple[str, str]]:
    """這個結局之後會回來的事：（事, 找上門的人）。"""
    return [(f"{cause}，{text}", r["cast"].get(who, "")) for key, cause, who, text in TABLE.get(("回音", _n(r)), ()) if key == _key(r, left)]


def palaces(fate: str, n: int) -> list[str]:
    """這種命第 n 章能落的宮（第 129-5、129-8 題）：第一章是「首宮」那兩宮。沒寫宮表的命回傳空的。"""
    if n == 1:
        return TABLE.get((FIRST, fate), [[""]])[0][0].split("、") if (FIRST, fate) in TABLE else []
    return [row[0] for row in TABLE.get((PALACE, fate), [])]


def sign(fate: str, n: int, reading: int) -> str:
    """第 n 章收場看得到的跡象（第 6-5-1、6-5-3 題甲）：村落用鄉鎮那句（兩讀共用），城市偏一邊，國家起明講。沒寫回傳空字串。"""
    scale = LADDER[min(max(n, 2), NATION) - 1]
    return next((t for s, read, t in TABLE.get((SIGN, fate), ()) if s == scale and read in ("", str(reading))), "")


def _palace(r: dict) -> list[str] | None:
    """這一章落的宮那一行：[宮名, 句, 職業, 性別, 年紀, 描述]。"""
    return next((row for row in TABLE.get((PALACE, r["name"]), []) if row[0] == r.get("palace")), None)


def palace_line(fate: str, where: str) -> str:
    """這種命落在這一宮那句（NPC 的章用，第 122b 批）。"""
    row = _palace({"name": fate, "palace": where})
    return row[1] if row else ""


def roles(r: dict) -> list[list[str]]:
    """這條路線要定的人：[身份, 職業, 性別, 年齡層, 描述]（第 81-13、81-14 題）。身份是內容裡寫的 {名稱}；性別空著就隨機。
    章落了宮，命主是那一宮的那一行（第 129-8 題）。"""
    row = _palace(r) if chapter(r) else None
    return [[BOSS, *row[2:]]] if row else TABLE.get(("人物", _n(r)), [])


def valid(r: dict) -> bool:
    return isinstance(r.get("stage"), int) and isinstance(r.get("choice"), str) and isinstance(r.get("dug"), bool) \
        and isinstance(r.get("moved"), int) and isinstance(r.get("lost"), bool) and isinstance(r.get("cast"), dict) and isinstance(r.get("asked"), list) \
        and r.get("pushed") in ("", PLAYER, RIVAL, LEFT_BE) and isinstance(r.get("seen"), dict) and r.get("way") in (0, 1, 2) \
        and isinstance(r.get("palace"), str)
