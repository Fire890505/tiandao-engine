"""好感、信任、怕：一筆一筆原因加起來（WHITEPAPER 第 120-1、120-6、121-3 題，實作第 1-1、1-2 批）。純函式，不碰資料庫。

- 原因三級：小 ±10（壽元 1/50 淡掉，凡人約一年半）、大 ±30（壽元 1/10，凡人 8 年）、重 ±60（不淡）；
  壞事淡得慢一倍；壽元不受限制的境界（金仙以上）什麼都不淡。
- 同一種事同一級只算最新的幾筆：小 3、大 2、重 1（疊滿只刷新期限）。
- 疑心重的人：信任加的降一級、扣的升一級。
- 不存數字，讀的時候把還沒淡的原因加起來，夾在 -100～100。
- 主角↔NPC：holder 是 NPC、toward 寫 ME，session_id 是那一生（每一生分開）；NPC 之間 session_id 是空字串。
- 關係（dict）帶 had（已存的原因）、adds（這回合新加、還沒存的）、years（他的壽元）、now、wary（疑心重）、
  base（關係種類的固定加減，只加好感，society.bonus）；affinity、trust、fear 是加總的結果，給其他模組讀
  （怕另加境界差、跟膽識比分兩層，見 npc.dread，第 121-10 題）。
"""
from __future__ import annotations

from . import races, realm
from ..util import new_id
from .clock import SHICHEN_PER_YEAR

LIKE, TRUST, FEAR = "好感", "信任", "怕"
AXES = (LIKE, TRUST, FEAR)
SMALL, BIG, GRAVE = "小", "大", "重"
LEVELS = (SMALL, BIG, GRAVE)
SIZES = {SMALL: 10, BIG: 30, GRAVE: 60}
FADE = {SMALL: 50, BIG: 10}      # 壽元的幾分之一淡掉（壞事再慢一倍）；重的不在這裡＝不淡
CAP = {SMALL: 3, BIG: 2, GRAVE: 1}
RANGE = (-100, 100)
ME = "主角"
TRUST_TIERS = ((60, "心腹"), (20, "可信"), (-9, "未定"), (-49, "存疑"), (-100, "提防"))   # 門檻暫定，同好感五層

# 種類（第 121-3 題種類表）
HELP, GIFT, SAVE, CARE, INSULT, ATTACK, ROB, SHAME = "幫忙", "送禮", "救命", "照顧", "冒犯", "動手", "偷搶", "丟臉"
KEEP, TRUTH, BREAK, LIE, BETRAY = "守約", "說真話", "失約", "說謊", "背叛"
OUST = "逐出"   # 立約斷掉、被逐的那方（第 121-4 題）
BOTHER, EVEN, SNUB = "又來麻煩", "有來有往", "有難不幫"   # 人情三套規矩（第 120-2 題，game/favours.py）
INTRO, PLEAD = "引見", "說情"   # 人情換的牽線、說情（第 4-10-3、4-10-4 題）
HEARD = "聽說"   # 親口聽到你做的事（第 121-2 題，domain/hearsay.felt）
THREAT, BLOODY = "威脅", "當面殺人"   # 怕（第 121-10 題）：另有動手、名聲（初見威名）
OLD = "舊恨"   # 氣量低的人被勾起已經淡掉的壞事（第 7-1b 批）：event_id 記翻的是哪一筆，每筆只翻一次
GRACE = {"低": 2, "中": 1, "高": 0.5}   # 氣量（第 7-1b 批）：壞事留得久幾倍；rel["grace"]，npc.relation_for
KNEW = "相認"   # 認出轉世（第 6-6b1 批）：不加減、不淡，記下就算熟人（society.familiar）
# 起點和暫時的（第 1-2 批對照表）：名聲、他族、天道安排、家運、看到大罪、敵盟之爭
FAME, RACE, HEAVEN, HOME, CRIME_SEEN, LEAGUE = "名聲", "他族", "天道安排", "家運", "看到大罪", "敵盟之爭"
FATE = "命途"   # 初見好感（貴人，第 6-2 批）
RANK = "地位"   # 初見地位差兩級以上（第 7-1c 批，domain/rank.first）
FIXED = (HOME,)      # 固定數字、不淡：家運記「跟親人 +60 差多少」（第 1-3b 批，home.relation）
# NPC 之間暫時的（第 1-3 批）：交好不再擲（第 7-2a 批改由村鎮小事長，domain/chatter.py）；結怨留給事端配到新人的仇家（plot.TIE_HITS）
BEFRIEND, FEUD = "交好", "結怨"
RUMOR, USED = "謠言", "借刀"   # 模型寫的事端第二批 a：聽信謠言、被借刀挑起的恨（揭開時撤掉，plot.DROP）
# 種類算在哪一條、加或減（第 4-11-9 題：事端結果欄寫「種類:輕重」就照這張表）
MOODS = {HELP: (LIKE, 1), GIFT: (LIKE, 1), SAVE: (LIKE, 1), CARE: (LIKE, 1), EVEN: (LIKE, 1), BEFRIEND: (LIKE, 1),
         INSULT: (LIKE, -1), ATTACK: (LIKE, -1), ROB: (LIKE, -1), SHAME: (LIKE, -1), FEUD: (LIKE, -1), RUMOR: (LIKE, -1), USED: (LIKE, -1),
         KEEP: (TRUST, 1), TRUTH: (TRUST, 1), BREAK: (TRUST, -1), LIE: (TRUST, -1), BETRAY: (TRUST, -1), THREAT: (FEAR, 1)}

Hit = tuple[str, str, str, int]   # （種類, 哪一條, 小大重, 加減多少）


def hit(kind: str, axis: str, size: str, sign: int = 1) -> Hit:
    return kind, axis, size, sign * SIZES[size]


def mood(kind: str, size: str) -> Hit:
    """照 MOODS 的一筆原因（事端結果欄的「好感:種類:輕重」）。"""
    axis, sign = MOODS[kind]
    return hit(kind, axis, size, sign)


def near(kind: str, axis: str, value: int) -> list[Hit]:
    """舊的起點數字換最接近的一級（不到 5 不記）：名聲、他族這類算出來的數。"""
    a = abs(value)
    if a < 5:
        return []
    return [hit(kind, axis, SMALL if a < 20 else BIG if a < 45 else GRAVE, 1 if value > 0 else -1)]


def lifespan(realm_lv: int, race: str = races.HUMAN) -> int | None:
    """壽元（年，同 npc.lifespan_years）；不受壽元限制的境界回 None（原因不淡）。"""
    base = realm.TIERS[realm_lv].lifespan
    return round(base * races.LIFESPAN.get(race, 1)) if base else None


def reason(holder: str, toward: str, h: Hit, now: int, *, event_id: str = "", life: str = "") -> dict:
    kind, axis, size, value = h
    return {"id": new_id("rsn"), "session_id": life, "holder": holder, "toward": toward, "axis": axis, "size": size,
            "value": value, "kind": kind, "event_id": event_id, "clock_shichen": now}


def alive(r: dict, years: int | None, now: int, fond: float = 1, grace: float = 1) -> bool:
    """fond：好事留得久幾倍（纏絲，第 6-5d 批）；grace：壞事再留得久幾倍（氣量，第 7-1b 批）。"""
    n = FADE.get(r["size"])
    if n is None or years is None:
        return True
    return now - r["clock_shichen"] < years * SHICHEN_PER_YEAR / n * (2 * grace if r["value"] < 0 else fond)


def total(reasons: list[dict], years: int | None, now: int, base: int = 0, fond: float = 1, grace: float = 1) -> int:
    """同一對人、同一條的原因（已篩好）加起來：同種同級只算最新的 CAP 筆。base：關係種類的固定加減（society.bonus）。"""
    seen: dict[tuple[str, str], int] = {}
    s = 0
    for r in sorted(reversed(reasons), key=lambda r: -r["clock_shichen"]):   # 新的在前（同時間的後寫的在前）
        k = (r["kind"], r["size"])
        if alive(r, years, now, fond, grace) and seen.get(k, 0) < CAP[r["size"]]:
            seen[k] = seen.get(k, 0) + 1
            s += r["value"]
    return max(RANGE[0], min(RANGE[1], s + base))


def pair(reasons: list[dict], holder: str, toward: str, life: str = "") -> list[dict]:
    return [r for r in reasons if (r["holder"], r["toward"], r["session_id"]) == (holder, toward, life)]


def score(rel: dict) -> dict:
    rs = rel["had"] + rel["adds"]
    g = rel.get("grace", 1)
    return {"affinity": total([r for r in rs if r["axis"] == LIKE], rel["years"], rel["now"], rel.get("base", 0), rel.get("fond", 1), g),
            "trust": total([r for r in rs if r["axis"] == TRUST], rel["years"], rel["now"], grace=g),
            "fear": total([r for r in rs if r["axis"] == FEAR], rel["years"], rel["now"], grace=g)}


def _old(rel: dict) -> dict | None:
    """舊恨（第 7-1b 批）：已經淡掉、還沒翻過的壞事裡最重的一筆（小的不翻）。"""
    raised = {r["event_id"] for r in rel["had"] + rel["adds"] if r["kind"] == OLD}
    faded = [r for r in rel["had"] if r["axis"] == LIKE and r["value"] < 0 and r["kind"] != OLD and r["size"] != SMALL
             and r["id"] not in raised and not alive(r, rel["years"], rel["now"], grace=rel.get("grace", 1))]
    return max(faded, key=lambda r: LEVELS.index(r["size"]), default=None)


def _wary(h: Hit) -> Hit | None:
    """疑心重：信任加的降一級（小的不記）、扣的升一級。"""
    kind, axis, size, value = h
    if axis != TRUST or kind in FIXED:
        return h
    i = LEVELS.index(size) + (-1 if value > 0 else 1)
    if i < 0:
        return None
    return hit(kind, axis, LEVELS[min(i, 2)], 1 if value > 0 else -1)


def apply(rel: dict, holder: str, hits: list[Hit], *, life: str = "") -> dict:
    """把幾筆原因加進關係（holder 對主角），重算好感、信任。"""
    hits = [w for w in (_wary(h) if rel["wary"] else h for h in hits) if w]
    old = _old(rel) if rel.get("grace", 1) > 1 and any(h[1] == LIKE and h[3] < 0 for h in hits) else None   # 氣量低翻舊帳
    rel = {**rel, "adds": rel["adds"] + [reason(holder, ME, h, rel["now"], life=life) for h in hits]
           + ([reason(holder, ME, hit(OLD, LIKE, LEVELS[LEVELS.index(old["size"]) - 1], -1), rel["now"], event_id=old["id"], life=life)] if old else [])}
    return {**rel, **score(rel)}
