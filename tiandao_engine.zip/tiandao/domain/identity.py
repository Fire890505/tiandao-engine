"""身分與追捕（2026-10-12，WHITEPAPER 16e.1）。純函式。

- 對外的名字：易容中＝「一個陌生人」，否則化名或本名。主角放出的傳聞、名聲、追捕者認的都是這個名字。
- 化名：角色面板設定，不算回合；換回本名，本名的名聲還在。熟人照樣認得。
- 易容：吃易容丹得到 7 天。境界高於丹藥品階的人、有親近羈絆的人看得穿；在人前施展修為就破掉。
- 通緝：記在名字上（名字 → {"level", "blood"（殺人那一份）, "since", "nation"（哪一國；空＝舊紀錄，哪一國都算）}），
  1～3 級，一年沒事降 1 級。2 級起在這一國的城鎮、坊市可能被追捕者找上門；衙署繳罰金降級，殺人那一份不能贖。
  犯了什麼罪、加幾級照國法（domain/crime.py，16h）；罰金級的罪當場罰錢，付不出就通緝 1 級；行賄成功降一級。
- 曝光度：記在時代卡（era）的 exposure；隱世時滿 FLIP_AT 就翻成並存或打壓。
"""
from __future__ import annotations

import random

from ..errors import BadRequest, Conflict, text_field
from . import crime as crime_mod
from . import era
from .clock import SHICHEN_PER_DAY, SHICHEN_PER_YEAR

STRANGER = "一個陌生人"
DISGUISE_DAYS = 7
CLOSE = ("親人", "伴侶", "師父", "徒弟")   # 有這些羈絆的人一眼認得
MAX_LEVEL = 3
HUNT_CHANCE = {2: 0.2, 3: 0.4}             # 待在城鎮、坊市的回合被追捕者找上門的機率（亂世減半，16h）
HUNT_PLACES = ("城鎮", "坊市")
FINE = 500                                 # 每降一級的罰金（凡人錢）× 2 的境界次方
BRIBE_SHARE = 0.5                          # 行賄降一級：罰金的一半
COURT = "衙署"
FLIP_AT = 20                               # 曝光度滿了就翻轉
NAME_LEN = (2, 12)


def fields() -> dict:
    return {"alias": "", "disguise": None, "wanted": {}}


# ── 名字 ─────────────────────────────────────────────────────────────────
def disguised(sheet: dict, clock_now: int) -> bool:
    return bool(sheet["disguise"]) and sheet["disguise"]["until"] > clock_now


def own_name(sheet: dict) -> str:
    """不看易容的名字：化名、道號（仙域，第 44 題）或本名（通緝、罰金記在這個名字上）。"""
    return sheet["alias"] or sheet["dao"] or sheet["name"]


def public(sheet: dict, clock_now: int) -> str:
    return STRANGER if disguised(sheet, clock_now) else own_name(sheet)


def set_alias(sheet: dict, alias, taken: set[str]) -> dict:
    """空字串＝用回本名。"""
    alias = text_field(alias, "化名", "invalid_alias")
    if alias and (not NAME_LEN[0] <= len(alias) <= NAME_LEN[1] or alias in taken or alias == STRANGER):
        raise BadRequest(f"化名需為 {NAME_LEN[0]} 到 {NAME_LEN[1]} 字，不能和已知的人或地方同名。", code="invalid_alias")
    return {**sheet, "alias": "" if alias in (sheet["name"], sheet["dao"]) else alias}


# ── 易容 ─────────────────────────────────────────────────────────────────
def disguise(sheet: dict, tier: int, clock_now: int) -> dict:
    return {**sheet, "disguise": {"tier": tier, "until": clock_now + DISGUISE_DAYS * SHICHEN_PER_DAY}}


def sees_through(sheet: dict, person: dict, bonds: list[dict]) -> bool:
    """這個人認不認得易容的你：境界高於丹藥品階、或有親近的羈絆。"""
    close = any(b["type"] in CLOSE and {b["a"], b["b"]} == {sheet["name"], person["name"]} for b in bonds)
    return close or person["realm_lv"] > sheet["disguise"]["tier"]


def broken(sheet: dict, clock_now: int, *, action: str, place_type: str) -> bool:
    """在人前施展修為：易容當場破掉。"""
    return disguised(sheet, clock_now) and action in era.SHOWY and place_type not in era.QUIET_TYPES


# ── 通緝 ─────────────────────────────────────────────────────────────────
def level(sheet: dict, name: str, clock_now: int) -> tuple[int, int]:
    """這個名字現在的通緝（等級, 殺人那一份）：一年沒事降 1 級。"""
    w = sheet["wanted"].get(name)
    if not w:
        return 0, 0
    lv = max(0, w["level"] - (clock_now - w["since"]) // SHICHEN_PER_YEAR)
    return lv, min(w["blood"], lv)


def accuse(sheet: dict, name: str, amount: int, clock_now: int, *, blood: bool = False, nation: str = "") -> dict:
    """通緝加級（記在 name 上；易容中是「一個陌生人」，不算你的）。"""
    if name == STRANGER or amount <= 0:
        return sheet
    lv, owed = level(sheet, name, clock_now)
    new = min(MAX_LEVEL, lv + amount)
    entry = {"level": new, "blood": min(new, owed + (amount if blood else 0)), "since": clock_now, "nation": nation}
    return {**sheet, "wanted": {**sheet["wanted"], name: entry}}


def charge(sheet: dict, count: int, name: str, clock_now: int, *, nation: str = "",
           money_name: str = "銀兩") -> tuple[dict, str]:
    """罰金級的罪當場罰錢（每條 crime.FINE × 2 的境界次方）；付不出就通緝 1 級。回傳（角色卡, 事實）。"""
    cost = count * crime_mod.FINE * 2 ** sheet["realm_lv"]
    if sheet["money"] >= cost:
        return {**sheet, "money": sheet["money"] - cost}, f"被當場罰了 {cost} {money_name}"
    return accuse(sheet, name, 1, clock_now, nation=nation), f"付不出 {cost} {money_name}罰金，被官府通緝"


def bribe(sheet: dict, clock_now: int, money_name: str = "銀兩") -> tuple[dict, str]:
    """官差收了錢：通緝降一級（不低於殺人那一份），花罰金的一半；錢不夠或沒有能降的就什麼都沒發生。"""
    cost, name = round(fine(sheet, clock_now) * BRIBE_SHARE), own_name(sheet)
    if not cost or sheet["money"] < cost:
        return sheet, ""
    lv, owed = level(sheet, name, clock_now)
    entry = {**sheet["wanted"][name], "level": lv - 1, "blood": owed, "since": clock_now}
    return ({**sheet, "money": sheet["money"] - cost, "wanted": {**sheet["wanted"], name: entry}},
            f"塞了 {cost} {money_name}給官差，通緝降為 {lv - 1} 級")


def hunted(rng: random.Random, sheet: dict, clock_now: int, place_type: str, *, nation: str = "",
           rate: float = 1) -> int:
    """這回合有沒有追捕者找上門：回傳通緝等級（0＝沒有）。別國的通緝不追；rate：國法的追捕倍數（亂世減半）。"""
    name = public(sheet, clock_now)
    lv = level(sheet, name, clock_now)[0]
    here = lv and sheet["wanted"][name]["nation"] in ("", nation)
    return lv if here and place_type in HUNT_PLACES and rng.random() < HUNT_CHANCE.get(lv, 0) * rate else 0


def fine(sheet: dict, clock_now: int) -> int:
    """降一級要付多少（0＝沒有能贖的）。"""
    lv, owed = level(sheet, own_name(sheet), clock_now)
    return FINE * 2 ** sheet["realm_lv"] if lv > owed else 0


def pay(sheet: dict, place_type: str, clock_now: int, money_name: str = "銀兩") -> tuple[dict, str]:
    """衙署繳罰金：降一級（不低於殺人那一份），不算回合。回傳（角色卡, 紀錄；service 用 items.noted 記下）。"""
    cost = fine(sheet, clock_now)
    if place_type != COURT or not cost:
        raise Conflict("這裡不能繳罰金，或沒有能贖的通緝。", code="no_fine")
    if sheet["money"] < cost:
        raise Conflict(f"{money_name}不夠：要 {cost}，身上只有 {sheet['money']}。", code="not_enough_money")
    name = own_name(sheet)
    lv, owed = level(sheet, name, clock_now)
    entry = {**sheet["wanted"][name], "level": lv - 1, "blood": owed, "since": clock_now}
    return ({**sheet, "money": sheet["money"] - cost, "wanted": {**sheet["wanted"], name: entry}},
            f"在衙署繳了 {cost} {money_name}罰金，通緝降為 {lv - 1} 級")


# ── 曝光度 ───────────────────────────────────────────────────────────────
def expose(card: dict, rng: random.Random, amount: int) -> tuple[dict, bool]:
    """隱世時曝光度累積；滿了翻成並存或打壓（權重照這個時代的走向）。回傳（時代卡, 翻了沒）。"""
    if card["stance"] != era.HIDDEN or amount <= 0:
        return card, False
    total = card.get("exposure", 0) + amount
    if total < FLIP_AT:
        return {**card, "exposure": total}, False
    weights = {k: v for k, v in era.STANCES[card["future"] or card["era"]].items() if k != era.HIDDEN}
    stance = rng.choices(list(weights), weights=list(weights.values()))[0]
    return {**card, "stance": stance, "exposure": 0}, True


# ── 畫面與說書人 ─────────────────────────────────────────────────────────
def text(sheet: dict, clock_now: int, *, knowing: list[str] = ()) -> str:
    """給說書人的【身分】：化名、易容（在場誰認得）、通緝等級。都沒有回傳空字串。"""
    parts = [f"在仙域以道號「{sheet['dao']}」行走"] if sheet["dao"] and not sheet["alias"] else []
    if sheet["alias"]:
        parts.append(f"對外自稱「{sheet['alias']}」，不認識的人只知道這個名字")
    if disguised(sheet, clock_now):
        who = "、".join(knowing)
        parts.append("易容中，在場的人認不出主角" + (f"，只有{who}認得出" if who else ""))
    lv = level(sheet, own_name(sheet), clock_now)[0]
    if lv:
        parts.append(f"「{own_name(sheet)}」正被{sheet['wanted'][own_name(sheet)]['nation'] or '官府'}通緝（{lv} 級）")
    return "；".join(parts)


def panel(sheet: dict, clock_now: int) -> dict:
    """狀態列：化名、易容剩幾天、通緝等級。"""
    left = (sheet["disguise"]["until"] - clock_now) if disguised(sheet, clock_now) else 0
    lv = level(sheet, own_name(sheet), clock_now)[0]
    return {"alias": sheet["alias"], "dao": sheet["dao"], "disguiseDays": -(-left // SHICHEN_PER_DAY), "wanted": lv,
            "wantedBy": sheet["wanted"][own_name(sheet)]["nation"] if lv else ""}


def valid(sheet: dict) -> bool:
    d, w = sheet["disguise"], sheet["wanted"]
    return (isinstance(sheet["alias"], str) and len(sheet["alias"]) <= NAME_LEN[1]
            and isinstance(sheet["dao"], str) and len(sheet["dao"]) <= NAME_LEN[1]
            and (d is None or isinstance(d, dict) and set(d) == {"tier", "until"}
                 and all(isinstance(d[k], int) for k in d))
            and isinstance(w, dict) and all(
                isinstance(k, str) and isinstance(v, dict) and set(v) == {"level", "blood", "since", "nation"}
                and all(isinstance(v[x], int) for x in ("level", "blood", "since")) and isinstance(v["nation"], str)
                and 0 <= v["blood"] <= v["level"] <= MAX_LEVEL
                for k, v in w.items()))
