"""模型寫的戰爭（progress/模型生成內容.md 第十一節「戰爭」九題、零件草稿）。純函式，不呼叫模型。

- 戰時事端＝一種模型事端（第 1 題甲）：交戰的每一年，主角所在州和相鄰州裡交戰中的邊境州各一條（第 5 題甲），
  主角在那一州時放（game/service._front）。plan 擲母型、要地、物資、畫面、處名、風味；record 照
  rules/content/war_parts.txt「骨」那張拼成跟 rules/content/plots/ 一樣格式的全文（plots_m）。
- 母型照世界的順序輪流（第 2、4 題甲；第二批第 4、6 題）：家園、死守、細作（細作、人質各半）、運送（運貨、送人各半）、佔領。
  主角是外人，人都是當地現成的（第 3 題甲）。
- 歸鄉（第二批第 1～3 題）：議和那年被徵走的人回家，物是人非、等不等、被佔照真的擲（game/service._homecoming），議和不收。
- 結局只動在地（第 6 題甲）：壓力、人走、抓、錢、帳。議和那年還沒收尾的照「放著」收（over，game/plots.tick）。
- 起因照兩國之間最重的一筆壞原因（第 9 題甲，cause）；「來源｜模型｜戰爭｜鑰匙」認得是哪一場（key：我國@敵國@年@州）。
"""
from __future__ import annotations

import random
import re

from . import atlas, checks, era as era_mod, newplots, opinion, plot
from .clock import SHICHEN_PER_YEAR
from .newdisasters import FLAVORS
from .plot import fill
from .tales import CONTENT

WAY = "戰爭"
BASE = ("家園", "死守", "細作", "運送", "佔領")
CARRY, SPY = ("運貨", "送人"), ("細作", "人質")   # 運送、細作擲到時各半（第 4 題甲；第二批第 6 題甲）
HOME = ("物是人非", "等不等", "被佔")              # 歸鄉（第二批）：議和以後的事，照真的擲（game/service._homecoming）
LASTS = SHICHEN_PER_YEAR      # 放下一年後結局（骨那張的 4320）
YOU = ("scene", "watch")      # 用「你」寫的欄（牌是寫給玩家看的）
_rows = [l.split("｜") for l in (CONTENT / "war_parts.txt").read_text(encoding="utf-8").splitlines() if l and not l.startswith("#")]
_all = lambda k: [r[1:] for r in _rows if r[0] == k]   # noqa: E731
group = lambda kind: "歸鄉" if kind in HOME else "戰時"   # noqa: E731
_for = lambda kinds, kind: kinds in ("全", group(kind)) or kind in kinds.split("、")   # noqa: E731
OPEN = dict(_all("開頭"))
KINDS = {r[0]: r[1:] for r in _all("母型")}   # 代號 → 名字、處境、真相、證（古現未）、結局、結局結果、洩底
CAUSES = dict(_all("起因"))
SPOTS = _all("要地")                           # 處名（、分開）、地點類型
WORDS = dict(_all("詞"))
WHO, ASKS, BONES, FALLBACK = _all("誰"), _all("問"), _all("骨"), dict(_all("通用"))


def key(nation: str, foe: str, year: int, state: str, tag: str = "") -> str:
    """tag：歸鄉寫「歸」（同一年同一州可能也有戰時事端）。"""
    return f"{nation}@{foe}@{year}@{state}" + (f"@{tag}" if tag else "")


def cause(reasons: list[dict], a: str, b: str) -> str:
    """兩國之間最重的一筆壞原因怎麼說；表上沒有的用最後一行（兩國向來不和）。"""
    bad = [r for r in reasons if {r["holder"], r["toward"]} == {a, b} and r["axis"] == opinion.LIKE and r["value"] < 0]
    return CAUSES.get(min(bad, key=lambda r: r["value"])["kind"] if bad else "", CAUSES[""])


def plan(rng: random.Random, era_now: str, nation: str, foe: str, why: str, key_: str, n: int, world_seed: str,
         kind: str = "") -> dict:
    """這一場要寫的骨架。n：這個世界寫過幾場（母型、風味照世界的順序輪流）。kind：指定母型（歸鄉照真的擲、驗收工具輪流擲）。"""
    kind = kind or random.Random(f"{world_seed}:wars").sample(BASE, len(BASE))[n % len(BASE)]
    kind = rng.choice({"運送": CARRY, "細作": SPY}.get(kind, (kind,)))
    mine = [f for f in FLAVORS if WAY in f[2].split("、")]
    flavor = random.Random(f"{world_seed}:flavors:{WAY}").sample(mine, len(mine))[n % len(mine)]
    spots, where = rng.choice(SPOTS)
    words = {w: rng.choice(v.split("、")) for w, v in WORDS.items()}
    words |= {"要地": rng.choice(spots.split("、")), "我國": nation, "敵國": foe, "起因": why,
              "證": KINDS[kind][3 + era_mod.ERAS.index(era_now)]}
    return {"war": True, "kind": kind, "key": key_, "era": era_now, "where": where, "words": words, "flavor": flavor[:2]}


def labels(slot: dict) -> dict[str, str]:
    """給模型看的代稱（照母型）。"""
    return {"村": "這裡", **{role: tag for kinds, role, tag, _ in WHO if _for(kinds, slot["kind"])}}


def _show(slot: dict, text: str) -> str:
    return fill(fill(text.replace("{結局}", KINDS[slot["kind"]][6]), labels(slot)), slot["words"])


def _tidy(slot: dict, key_: str, text) -> str:
    """同 newplots._tidy，再把照抄的代稱換成「他」（亡魂那次學到的：退回不如換掉）；用「你」寫的欄漏了你，開頭補上
    （第一次真 9b：村外那一幕 11 次沒寫你）。"""
    text = newplots._tidy(slot, key_, text)
    for tag in labels(slot).values():
        text = text if tag == "這裡" else text.replace(tag, "他")
    if key_ in YOU and text and "你" not in text:
        text = ("你" if text[0] in "看見望聽" else "你看見") + text
    return text


def brief(slot: dict, part: str) -> dict:
    """叫 bits 時的 slot（同 newplots.brief）：blind 不給真相。"""
    k, (name, trait) = KINDS[slot["kind"]], slot["flavor"]
    who = "；".join(f"{tag}是{what}" for kinds, _, tag, what in WHO if _for(kinds, slot["kind"]))
    lines = [f"時代：{slot['era']}。{OPEN[group(slot['kind'])]}{k[1]}。",
             f"{who}。",
             f"風味：{name}（{trait}），照這個傳統的味道寫。不要寫上面那幾個代稱，也不要取名字。"]
    if part != "blind":
        lines.append(f"真相：{k[2]}。")
    if part == "close":
        lines.append(f"沒人插手的話：{k[6]}。")
    return {"what": "打仗那一年邊境上的一件事", "era": slot["era"], "brief": _show(slot, "\n".join(lines))}


def asks(slot: dict, part: str) -> list[dict]:
    """這一段要模型寫的欄：key、ask、span、leak（同 newplots.asks）。"""
    return [{"key": key_, "ask": _show(slot, ask), "span": newplots.SPANS[span], "leak": leak == "查"}
            for kinds, p, key_, span, leak, ask in ASKS if p == part and _for(kinds, slot["kind"])]


def faults(slot: dict, part: str, got: dict, era_now: str) -> dict[str, str]:
    """逐欄查：長短、中文、時代、洩底（母型的字）。照抄的代稱、漏掉的你 _tidy 補好，不退。"""
    lies, out = KINDS[slot["kind"]][8].split("、"), {}
    for x in (x for x in asks(slot, part) if x["key"] in got):
        text = _tidy(slot, x["key"], got[x["key"]])
        reason = checks.basic([(text, x["span"])], era_now) or ("洩底" if x["leak"] and any(w in text for w in lies) else "")
        if reason:
            out[x["key"]] = reason
    return out


def name(slot: dict, state: str, taken: set[str]) -> str:
    """「雲州守渡口」，撞名加二、三……（名字 Python 拼）。"""
    base = f"{state[:3]}{fill(KINDS[slot['kind']][0], slot['words'])}"
    return next(n for n in (base, *(base + c for c in "二三四五六七八九十")) if n not in taken)


def record(slot: dict, got: dict, name_: str) -> dict:
    """存成一條（plots_m）。got：{欄: 字}，沒有的用通用句。骨那張的 [欄] 換成模型寫的、{要地類}等換成這一場的。"""
    g = {k: _tidy(slot, k, got.get(k) or v) for k, v in FALLBACK.items()}
    g |= {k: newplots._trace(g[k]) if g[k][-1] not in "？！。" else g[k] for k in ("rumor", "tr_end")}
    k, w = KINDS[slot["kind"]], slot["words"]
    put = {"{要地類}": slot["where"], "{路線}": f"路線:{name_}", "{結局}": k[6], "{結局結果}": k[7]}
    body = "\n".join("｜".join(row) for kinds, *row in BONES if _for(kinds, slot["kind"]))
    body = re.sub(r"\[(\w+)\]", lambda x: g[x.group(1)], re.sub("|".join(map(re.escape, put)), lambda x: put[x.group(0)], body))
    rows = [f"牌｜{name_}｜地方｜事端｜｜｜", f"來源｜{newplots.MODEL}｜{WAY}｜{slot['key']}｜{slot['kind']}",
            "｜".join(["表面", slot["era"], *(f"{a}={b}" for a, b in w.items() if b)]), body, f"素材｜{w['要地']}、{w['物資']}"]
    return {"name": name_, "state": slot["era"], "body": "\n".join(rows), "source": newplots.MODEL}


def mine(t: dict) -> bool:
    """這條模板是模型寫的戰爭（不給一般事端挑）。"""
    return bool(t.get("來源")) and t["來源"][0][1:2] == [WAY]


def key_of(t: dict) -> str:
    return t["來源"][0][2] if mine(t) else ""


def kind_of(t: dict) -> str:
    return t["來源"][0][3] if mine(t) else ""


def over(t: dict, sky: dict | None) -> bool:
    """這條戰時事端的兩國已經議和（第 5 題甲：還沒收尾的照放著收）；歸鄉本來就是議和以後的事，不收。"""
    return mine(t) and kind_of(t) not in HOME and not atlas.at_war(sky, *key_of(t).split("@")[:2])


def placed(plots: list[dict], templates: list[dict]) -> set[str]:
    """已經放了的戰時事端（鑰匙）。"""
    by_name = {plot.name(t): t for t in templates if mine(t)}
    return {key_of(by_name[r["name"]]) for r in plots if r["name"] in by_name}
