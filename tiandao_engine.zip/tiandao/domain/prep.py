"""準備（16l 第 6-2 題）：佈局。純函式。

規則（2026-10-14 與使用者一題一題定案，見 progress/WHITEPAPER.md 16l，數字暫定）：
- 三項準備各讓境界差少算一級（npc.realm_diff_modifier）：偷襲（judgment：先藏住再出手）、
  佈局（這裡）、破境道具（items.Item.breaker）。
- 佈局：在一個地方宣告設陷阱、下毒、埋伏（不是當場打），記成那裡的地點狀況，七天內在那裡交手就算一項。
"""
from __future__ import annotations

from . import incident
from .clock import SHICHEN_PER_DAY

LAID = "佈局"
WORDS = ("設陷阱", "設下陷阱", "佈下陷阱", "布下陷阱", "挖陷阱", "下毒", "設伏", "設下埋伏", "佈陣", "布陣")
LASTS = 7 * SHICHEN_PER_DAY
EVENT = "在此布下了陷阱與埋伏（七天內在這裡交手，對手的境界差少算一級）"


def lay(place: str, words: str, clock_now: int) -> dict | None:
    """這回合宣告佈局：回傳要寫入的地點狀況。"""
    if not any(w in (words or "") for w in WORDS):
        return None
    return {"place": place, "name": LAID, "text": "預先布下的陷阱與埋伏", "source": incident.WORLD, "game": None,
            "started_shichen": clock_now, "ends_shichen": clock_now + LASTS}


def laid(states: list[dict], place: str, clock_now: int) -> bool:
    return any(s["name"] == LAID and s["place"] == place and s["started_shichen"] <= clock_now < s["ends_shichen"]
               for s in states)
