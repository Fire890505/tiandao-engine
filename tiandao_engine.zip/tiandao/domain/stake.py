"""要的有多大（3-5，WHITEPAPER 118-2、3-5 第 1～5 題）：說服、套話、偷東西的難度看要的東西，不看形容詞。純函式。

- 三檔跟人情帳同一套（小、大、救命）；沒要東西、小＝普通，大＝困難，救命＝極難。
- 原文點名物品目錄裡的東西或說了數目，換成凡人錢，跟對方境界的做工工錢比，
  一個月以內＝小、一年以內＝大、超過＝救命；再查字表（LIFE_WORDS、BIG_WORDS），取重的那檔。
  不讓模型判（3-5 收尾甲→乙：9B 讀要的有多大只對 77%，多半估小）。
- 他欠你的恩不輕於這一檔就降一級（只看不扣；真要討照走討人情）。
"""
from __future__ import annotations

from . import effects, favour, items, retreat
from . import judgment as J

NONE = "沒要東西"
SIZES = (NONE, *favour.LEVELS)
LEVEL = {NONE: J.NORMAL, favour.SMALL: J.NORMAL, favour.BIG: "困難", favour.LIFE: "極難"}
STONE, YEAR = 10, 12   # 1 靈石約 10 凡人錢（工錢改發凡人錢時的匯率）；一年 12 個月
LIFE_WORDS = ("傳家", "祖傳", "師門", "秘傳", "本命", "臨終", "遺物", "鎮店", "鎮派", "背叛", "出賣", "追殺", "擋刀", "性命")
BIG_WORDS = ("護身", "法寶", "冒險", "闖", "藏", "秘密", "密信", "誰派", "指使", "主子", "官府", "名單", "帳冊", "追兵")


def worth(text: str, number: str, lv: int, own: tuple = ()) -> str:
    """原文點名的物品、數目、字表，取最重的一檔；都沒有＝小。
    own：主角身上的東西，點名它多半是拿出來用、拿去送，不算要的。"""
    goods = [items.price(n, i.tier if i.tier is not None else lv) * STONE for n, i in items.CATALOG.items() if n in text and n not in own]
    money = retreat.to_int(number) * (STONE if "靈石" in text else 1) if number else 0
    value, wage = max(goods + [money]), effects.WORK_WAGE * 2 ** lv
    priced = favour.SMALL if value <= wage else favour.BIG if value <= wage * YEAR else favour.LIFE
    return max(priced, said(text), key=favour.LEVELS.index)


def said(text: str) -> str:
    """字表：說到傳家寶、背叛、追殺這類＝救命，冒險、藏著的事＝大，其他＝小。"""
    return favour.LIFE if any(w in text for w in LIFE_WORDS) else favour.BIG if any(w in text for w in BIG_WORDS) else favour.SMALL


def lips(d: str, lip: str) -> str:
    """套話看口風（第 7-1b 批）：高的難一級、低的容易一級。"""
    order = list(J.DIFFICULTY)
    return order[max(0, min(len(order) - 1, order.index(d) + {"高": 1, "低": -1}.get(lip, 0)))]


def level(size: str, owed: str = "") -> str:
    """這一檔的難度；owed：他欠你最重的恩（favour.top）。"""
    d = LEVEL.get(size, J.NORMAL)
    if owed and size in favour.LEVELS and favour.LEVELS.index(owed) >= favour.LEVELS.index(size):
        return list(J.DIFFICULTY)[list(J.DIFFICULTY).index(d) - 1]
    return d
