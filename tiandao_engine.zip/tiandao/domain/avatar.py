"""化身與道號（16l 第 13 題乙、第 26、27 題；草稿 D1、D1b）：沒在玩的主角以 NPC 的身分活在仙域裡。純函式。

規則（2026-10-14、10-18 與使用者一題一題定案，見 progress/WHITEPAPER.md 16l，數字暫定）：
- 同一個仙域裡，其他正在進行的一生（遊戲中或等開場）就是化身。化身不存成 NPC：每回合從他的角色卡生成，
  境界、宗門永遠是那一生自己的；背景演化不動他（不死、不跌境界、不失去東西）。
- 道號（第 26 題）：飛升一律取道號，記在角色卡的化名（identity.own_name），仙域裡別人用道號稱呼、傳聞名聲化身都記在
  道號上。回答接引時說「道號某某」用自己取的，沒說就從本名挑一個字自動取；都避開仙域裡已有的名字。
  搬上來的 NPC 撞名時也照這樣取。
- 出手（第 14 題乙，D2）：最多打到重傷（致命一擊改成重傷脫身），傷勢寫回他的角色卡（氣血）；名聲、戰功照算。
- 背景（第 27 題）：化身的位置每 SLOT 推算一次（種子＋那一生＋第幾段），弟子多在自家山門、偶爾本盟秘境或戰事，
  散仙在虛空裂隙、遺址、造化之間；剛玩過的那一段照角色卡。交情等換玩那一生時才補算（最近 MAX_SLOTS 段，
  每段從當時所在地的人擲 0～1 個：同盟 +5、敵盟 −5、其他 ±3），寫進那一生的關係與一則總結記事。
- 遇得到、互動得到；關係雙方都記得：你對他的關係照常寫，同時寫一份「他對你」的關係，並在他那一生記一則記事。
"""
from __future__ import annotations

import random
import re

from . import ascent, immortal, memory, npc, sect
from .clock import SHICHEN_PER_DAY

BY = "avatar"   # NPC 的 created_by
DAO_WORDS = re.compile(r"道號[「『]?([一-鿿]{2,4})")
MIDDLES = "虛玄清寒雲塵淵明霄素"
TAILS = ("子", "真人", "道人", "散人", "居士")
SLOT = 10 * SHICHEN_PER_DAY
MAX_SLOTS = 12
MEET_CHANCE = 0.5
SAME, FOE, OTHER = 5, -5, 3
HOME, ROAM = 0.7, 0.15   # 弟子：七成在自家山門、一成半在本盟秘境，其他在戰事
HURT = {"重傷": 0.25, "負傷": 0.6}   # D2：化身的傷勢 ↔ 他角色卡上的氣血比例


def dao(rng: random.Random, name: str, words: str, taken: set[str]) -> str:
    """道號：行動裡說了「道號某某」而且沒人用就用它，不然從本名（去掉姓）挑一個字自動取。"""
    asked = DAO_WORDS.search(words)
    if asked and asked.group(1) not in taken:
        return asked.group(1)
    chars = name[1:] or name
    for _ in range(40):
        pick = rng.choice(chars) + rng.choice(MIDDLES) + rng.choice(TAILS)
        if pick not in taken:
            return pick
    return ""


def where(rng: random.Random, sheet: dict, realm: dict, wilds: list[str], fights: list[dict]) -> str:
    """化身這一段時間在哪裡。wilds：散仙會去的地方（虛空裂隙、遺址、造化）；fights：這一段的戰事。"""
    mine = next((s for s in realm["sects"] if s["name"] == sheet["sect"]), None)
    if not mine:
        return rng.choice(wilds) if wilds else sheet["location"]
    roll = rng.random()
    war_places = [w["place"] for w in fights if mine["alliance"] in w["sides"]]
    if roll < HOME or not mine["alliance"]:
        return mine["name"] + ascent.GATE
    if roll < HOME + ROAM or not war_places:
        return immortal.secrets(realm, mine["alliance"])[0]["name"]   # 主秘境
    return rng.choice(war_places)


def mingle(rng: random.Random, here: list[dict], kin) -> tuple[str, int] | None:
    """這一段在所在地碰上的人與好感變化；kin(名字) → "同盟"、"敵盟" 或空字串。"""
    if not here or rng.random() >= MEET_CHANCE:
        return None
    p = rng.choice(here)
    side = kin(p["name"])
    return p["name"], SAME if side == "同盟" else FOE if side == "敵盟" else rng.choice((OTHER, -OTHER))


def npc_of(sheet: dict, name: str, place: str) -> dict:
    """角色卡 → 這一回合用的 NPC（欄位照 repos.list_npcs）。name：他在仙域的名字（道號）。"""
    who = sect.title(sheet) if sheet["sect"] else "散仙"
    return {"name": name, "appearance": sheet.get("appearance", ""), "profile": f"同樣從下界飛升的{who}。",
            "location": place, "status": "ALIVE", "ai_driven": False, "created_by": BY, "race": sheet["race"],
            "gender": sheet["gender"], "lineage": sheet["lineage"], "birth_shichen": sheet["birth_shichen"], "realm_lv": sheet["realm_lv"], "stage_index": sheet["stage_index"],
            "hidden_power": False, "condition": condition(sheet), "speech": "", "appearance_age": None,
            "profile_age": None, "speech_age": None, "goal": "求道", "goal_target": "",
            **dict.fromkeys(npc.TRAITS, 50), "heaven_role": "", "rewrite_reason": "", "evolved_shichen": None,
            "cultivation": sheet["cultivation"], "away_since": None, "away_from": "", "first_seen_session_id": "",
            "first_seen_turn": 0}


def condition(sheet: dict) -> str:
    """化身的傷勢看他角色卡上的氣血（D2）。"""
    ratio = sheet["hp"] / max(1, sheet["hp_max"])
    return next((c for c, cut in HURT.items() if ratio <= cut), npc.CONDITIONS[0])


def spare(name: str, state: dict, events: list[str]) -> tuple[dict, list[str]]:
    """對化身出手最多重傷（D2，第 14 題乙）：致命一擊改成重傷脫身。"""
    if state["condition"] != npc.CONDITIONS[-1]:
        return state, events
    return ({**state, "condition": "重傷", "status": "ALIVE"},
            [f"{name}重傷脫身" if e == f"{name}{npc.CONDITIONS[-1]}" else e for e in events])


def wound(sheet: dict, cond: str) -> dict:
    """傷勢寫回他的角色卡：氣血降到那一階的上限（已經更低就不動）。"""
    cut = HURT.get(cond)
    return {**sheet, "hp": min(sheet["hp"], max(1, int(sheet["hp_max"] * cut)))} if cut else sheet


def note(me: str, here: str, action: str, clock_now: int) -> dict:
    """記在化身那一生的記事：誰在哪裡遇上了他、做了什麼。"""
    return memory.note(memory.NPC, me, memory.NEWS, f"化身在外時，{me}在{here}遇上了你（{action}）",
                       clock_now=clock_now, turn_no=0)


def summary(me: str, met: dict[str, int], clock_now: int) -> dict:
    """換玩時補算的交情，一則總結記事。"""
    good = [n for n, d in met.items() if d > 0]
    bad = [n for n, d in met.items() if d < 0]
    text = "化身在外這段時間，" + "；".join(x for x in (f"結識了{'、'.join(good)}" if good else "",
                                                     f"和{'、'.join(bad)}起了齟齬" if bad else "") if x)
    return memory.note(memory.SELF, me, memory.MILESTONE, text, clock_now=clock_now, turn_no=0)
