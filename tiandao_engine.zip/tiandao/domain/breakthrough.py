"""大境界突破：前提條件、契機、成功率、大失敗機率。純函式。

規則（2026-10-04 與使用者討論定案，見 progress/HANDOFF.md 第 3 步）：
- 玩家主動宣告才會嘗試（judgment.BREAKTHROUGH），系統不自動衝關。
- 前提（全部由 Python 檢查，不靠 AI 宣稱）：修為卡在瓶頸、冷卻已過（遊戲時間）、氣血至少五成。
- 契機只採用 Python 查得到的事實：所在地點的登錄類型、上一回合是否閉關滿一個月、氣血是否全滿、身上的破境丹、
  衝金丹時有沒有殘理（第 3b-1 步；衝返虛則是一定要有殘理）。
  契機同時提高成功率、降低大失敗機率。
- 舊版四鑰匙的「契機」「代價」靠 AI 說了算，這裡不採用；也不另外扣壽元（冷卻本身就消耗壽元）。
- 第 18-2a 步：衝關就是渡劫，天道注視越重，成功率越低、大失敗率越高（勝負記進棋譜由 game 層做）。
"""
from __future__ import annotations

from dataclasses import asdict, dataclass

from . import clock, realm

MIN_HP_RATIO = 0.5
SUCCESS_RANGE = (5, 95)
GREAT_FAILURE_BASE, GREAT_FAILURE_PER_OPPORTUNITY, GREAT_FAILURE_MIN = 10, 3, 2
OPPORTUNITY_LOCATIONS = {"秘境": ("身處秘境", 10), "宗門": ("身處宗門", 5), "武館": ("身處武館", 5)}   # 武館：第 16b 步
RECENT_RETREAT_BONUS = ("剛閉關沉澱", 10)
FULL_HP_BONUS = ("氣血全滿", 5)
PILL_BONUS = ("服下破境丹", 10)   # 第 8 步：身上有同品階的破境丹，衝關時自動用掉（數字暫定）
SURGE_BONUS = ("靈潮湧動", 10)    # 16j 第 5 題：靈潮期間衝關
# 第 3b-1 步（數字暫定）：衝金丹時有殘理是契機；衝返虛至少要有一系殘理
RESIDUE_BONUS, RESIDUE_BONUS_LV, RESIDUE_REQUIRED_LV = ("領悟殘理", 10), 3, 4
LAW_REQUIRED_LV = 5   # 衝合體至少要一系法則（法則領域世界設計 L3、E0a 雙向門檻）
# 第 18-2a 步（數字暫定）：衝關就是渡劫——成功率 −注視÷10、大失敗率 +注視÷20
TRIAL_SUCCESS_DIV, TRIAL_GREAT_FAILURE_DIV = 10, 20
# 第 6-4-2 題甲（數字暫定）：這個範圍的章沒了結就衝到下一個範圍——成功率 −10、大失敗率 +5
OWED = ("因果未了", 10, 5)

# 突破結果（effects.py 套用）
GREAT_SUCCESS_CULTIVATION = 20
FAIL_CULTIVATION_LOSS = 30
FAIL_HP_RATIO, GREAT_FAIL_HP_RATIO = 0.2, 0.5
STAGE_DROP_FROM_LV = 3        # Lv3 以上大失敗：跌落一個小境界
LIFESPAN_HALVING_FROM_LV = 6  # Lv6 以上大失敗：剩餘壽元折損一半


@dataclass(frozen=True)
class Context:
    clock_now: int
    location_type: str = ""        # 主角所在地點的登錄類型（第 1 步提案通道登錄的地點）
    recent_retreat: bool = False   # 上一回合是閉關滿一個月的修煉
    pill: bool = False             # 身上有同品階的破境丹
    residues: int = 0              # 領悟了幾系殘理（第 3b-1 步）
    applied: int = 0               # 成了法則的系有幾個（L3）
    surge: bool = False            # 此地正逢靈潮（16j）
    owed: bool = False             # 這個範圍的章還沒了結（第 6-4-2 題甲，route.owes）


@dataclass(frozen=True)
class Odds:
    target_lv: int
    missing: tuple[str, ...]        # 不符合的前提；空＝可以嘗試
    opportunities: tuple[str, ...]
    success: int                    # 成功率（%），含大成功
    great_failure: int              # 大失敗率（%），已扣掉與成功區間重疊的部分
    burdens: tuple[str, ...] = ()   # 扣分的（因果未了）

    @property
    def ready(self) -> bool:
        return not self.missing

    def to_dict(self) -> dict:
        return {**asdict(self), "ready": self.ready}


def odds(sheet: dict, ctx: Context) -> Odds:
    lv = sheet["realm_lv"]
    if lv >= realm.MAX_LV:
        return Odds(lv, ("已是最高境界",), (), 0, 0)
    target = lv + 1
    missing: list[str] = []
    if not realm.at_bottleneck(lv, sheet["stage_index"], sheet["cultivation"]):
        top = realm.stage_name(lv, realm.last_stage(lv))
        missing.append(f"修為尚未圓滿（需達{top}且修為 100）")
    ready_at = sheet["breakthrough_ready_at"]
    if ready_at is not None and ctx.clock_now < ready_at:
        missing.append(f"距上次衝關太近，還需約 {clock.format_span(ready_at - ctx.clock_now)}")
    if sheet["hp"] < sheet["hp_max"] * MIN_HP_RATIO:
        missing.append("氣血不足五成，帶傷不能衝關")
    if target == RESIDUE_REQUIRED_LV and ctx.residues < 1:
        missing.append("尚未領悟任何一系殘理（參悟現象累積感悟）")
    if target == LAW_REQUIRED_LV and ctx.applied < 1:
        missing.append("還沒有一系成了法則（一系悟透過半、至少一條靈象）")

    bonuses = []
    if target == RESIDUE_BONUS_LV and ctx.residues >= 1:
        bonuses.append(RESIDUE_BONUS)
    if ctx.location_type in OPPORTUNITY_LOCATIONS:
        bonuses.append(OPPORTUNITY_LOCATIONS[ctx.location_type])
    if ctx.recent_retreat:
        bonuses.append(RECENT_RETREAT_BONUS)
    if sheet["hp"] >= sheet["hp_max"]:
        bonuses.append(FULL_HP_BONUS)
    if ctx.pill:
        bonuses.append(PILL_BONUS)
    if ctx.surge:
        bonuses.append(SURGE_BONUS)

    attrs = sheet["attributes"]
    gaze = sheet["gaze"]          # 劫（第 18-2a 步）：天道注視越重，劫越重
    owed = ctx.owed and realm.TIERS[target].scale != realm.TIERS[lv].scale
    success = (realm.TIERS[target].breakthrough_base + (attrs["root_bone"] - 50) // 2
               + (attrs["wisdom"] - 50) // 4 + sum(b for _, b in bonuses) - round(gaze / TRIAL_SUCCESS_DIV) - OWED[1] * owed)
    success = max(SUCCESS_RANGE[0], min(SUCCESS_RANGE[1], success))
    great_failure = max(GREAT_FAILURE_MIN, GREAT_FAILURE_BASE - GREAT_FAILURE_PER_OPPORTUNITY * len(bonuses)) \
        + round(gaze / TRIAL_GREAT_FAILURE_DIV) + OWED[2] * owed
    return Odds(target, tuple(missing), tuple(name for name, _ in bonuses), success,
                min(great_failure, 100 - success), (OWED[0],) if owed else ())


def cooldown_shichen(target_lv: int, *, doubled: bool = False) -> int:
    """嘗試突破進入 target_lv 之後，下一次嘗試要等多久。"""
    years = realm.TIERS[target_lv].cooldown_years if target_lv <= realm.MAX_LV else 0
    return years * clock.SHICHEN_PER_YEAR * (2 if doubled else 1)
