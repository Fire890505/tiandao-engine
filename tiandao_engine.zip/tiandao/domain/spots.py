"""地點裡的小地方（第 9g 批，progress/第五批草稿.md 9-23～9-28g）。純函式。

- 上一回合敘事提過、玩家說要去：當場登錄成這裡的小地方（scale「家」、parent＝這裡的村鎮），走進去不花時間，那一回合算當地查探。
- 類型看名字尾字對照現有地點類型（9-26），對不上算上層的類型。
- 小地方多記 spot：inside 裡面放了什麼、searched 翻過沒有、stowed 收起沒有、seen 最後去過的時刻、hint 來歷和特徵（交給寫描述）。
- 每處最多 MAX 個不收起的；滿了收「翻過、最久沒去」的那處，有人住、有狀況、被怪談籠罩、還藏著東西的不收；再去就叫回來。
"""
from __future__ import annotations

import random

from . import space

MAX = 5
ORIGINS = ("以前是別的", "有人死過", "某人建的", "搬過一次")   # v2 第 20 副：地點的來歷
MARKS = ("一棵樹", "一口井", "一塊碑", "一種聲音", "一種氣味")   # 地點的一個特徵
KINDS = {   # 尾字 → 遊戲地點類型（9-26 對照表）；兩個字的先比
    "岔路": "荒野", "碼頭": "村落", "渡口": "村落",
    **dict.fromkeys("洞窟穴坑礦崖林谷澗溪潭泉徑橋", "荒野"), **dict.fromkeys("渡津港", "村落"),
    **dict.fromkeys("廟寺觀庵祠壇", "祠堂"), **dict.fromkeys("牢獄衙署", "衙署"), **dict.fromkeys("墓塚陵墟", "廢墟"),
    **dict.fromkeys("宅屋舍院居", "住家"), "棧": "客棧",
}


TOWNS = tuple("村寨莊堡鎮鄉縣市城州府郡都京邑國域境疆界")   # 聚落、疆域：提過也不是小地方，照舊辨向


def told(name: str, narrative: str) -> bool:
    """上一回合的敘事提過它、又不是村鎮州國。"""
    return name in narrative and not name.endswith(TOWNS)


def kind(name: str, parent_type: str) -> str:
    return next((t for end, t in sorted(KINDS.items(), key=lambda x: -len(x[0])) if name.endswith(end)), parent_type)


def make(rng: random.Random, name: str, town: str, town_type: str, now: int, turn_no: int) -> dict:
    """登錄一個小地方；來歷、特徵各擲一個，寫描述時當提示。"""
    t = kind(name, town_type)
    return {"name": name, "description": space.NEW_PLACE_DESCRIPTION, "type": t, "scale": space.SCALES[0],
            "danger": "低" if t in space.DANGER_TYPES else "", "parent": town, "discovered_turn": turn_no,
            "spot": {"inside": "", "searched": False, "stowed": False, "seen": now,
                     "hint": f"來歷：{rng.choice(ORIGINS)}；特徵：{rng.choice(MARKS)}"}}


def visit(spot: dict, now: int, found: str = "") -> dict:
    """去過一次：叫回來、記時刻；查到東西就記下、算翻過。"""
    return {**spot, "stowed": False, "seen": now, **({"inside": found[:40], "searched": True} if found else {})}


def shown(locations: list[dict], town: str) -> list[str]:
    """這裡的小地方（方位圖下面那一行）：沒收起的。"""
    return [l["name"] for l in locations if l.get("spot") and l["parent"] == town and not l["spot"]["stowed"]]


def tuck(locations: list[dict], town: str, keep: set) -> str:
    """超過 MAX 處時要收起的那一處；keep＝有人住、有狀況、被怪談籠罩的。沒得收回傳空字串。"""
    open_ = [l for l in locations if l["name"] in shown(locations, town)]
    can = [l for l in open_ if l["spot"]["searched"] and l["name"] not in keep]
    return min(can, key=lambda l: l["spot"]["seen"])["name"] if len(open_) > MAX and can else ""


def valid(v) -> bool:
    return v is None or (isinstance(v, dict) and set(v) == {"inside", "searched", "stowed", "seen", "hint"}
                         and isinstance(v["inside"], str) and len(v["inside"]) <= 40 and isinstance(v["hint"], str)
                         and len(v["hint"]) <= 40 and isinstance(v["searched"], bool) and isinstance(v["stowed"], bool)
                         and isinstance(v["seen"], int))
