"""模型寫的都市傳說（第 128 系列乙，progress/模型生成內容.md 第七節「乙要定的題」「再次設計」）。純函式，不呼叫模型。

- 判定欄由 Python 照 rules/content/legend_parts.txt 擲（第 2 題甲）：母題、綁法、找上、自救、了結第三步、載體、感悟。
- 再次設計（2026-11-19）：自救那則說法、錯的說法、其實、了結第二三步的整句由 Python 照句型拼（clause_parts.txt），
  模型只寫：story（名字、氣氛、開口、另一則說法、本體、了結的揭露、其實的原因）、bits（兩則說法後面的小段，
  分不出哪則是錯的）；最後叫模型答是非題（questions：每段接不接得上）。
- 綁法（第 2-1 題甲）：地點＝人住的地方；地方＝鄉野，照那一州的地勢寫。都綁一州，只在那一州出現（第 3 題甲）。
- 建世界時背景寫 OPENING 篇；局中每次擲到傳說有 MORE_CHANCE 補寫一篇，每個世界最多 MAX_PER_WORLD 篇（第 4、4-1 題甲）。
  第一批只有古代（載體、母題都是古代那欄）。record 組成跟手寫檔一樣格式的全文（legends.parse 讀）。
"""
from __future__ import annotations

import random

from . import checks, clauses, legends, newitems
from .tales import CONTENT

MODEL = "模型"
OPENING, MORE_CHANCE, MAX_PER_WORLD = 3, 1 / 3, 12      # 暫定（2026-11-18 使用者說照暫定）
STORY = ("name", "mood", "line", "true2", "boss", "found1", "found2", "end", "why")
SPANS = {"name": (2, 8), "mood": (4, 30), "line": (8, 80), "true2": (6, 60), "boss": (1, 8), "found1": (8, 60), "found2": (8, 60),
         "end": (8, 60), "why": clauses.FORMS["其實"][1]}
THING = "它留下的東西"   # 傳說沒有場所的物件：了結句型的 {物件}

_rows = [l.split("｜") for l in (CONTENT / "legend_parts.txt").read_text(encoding="utf-8").splitlines() if l and not l.startswith("#")]
_table = lambda k: {r[1]: r[2:] for r in _rows if r[0] == k}   # noqa: E731
MOTIFS, BINDS, MEETS, SAVES, ENDS, LANDS = _table("母題"), _table("綁法"), _table("找上"), _table("自救"), _table("了結"), _table("地勢")
ORIGINS = {k: v[0] for k, v in _table("起源").items()}   # 起源 → 冤／約（乙第 3 題乙）
CARRIERS, LAWS, ANSWERS = (next(r[1].split("、") for r in _rows if r[0] == k) for k in ("載體", "感悟", "答句"))
CARRIERS = dict(c.split(":") for c in CARRIERS)   # 載體 → 接在第一則說法前面的話
# SAVES：答對、答錯、做了就錯、對的做法、錯的做法、錯的字


def plan(rng: random.Random, seed: str, states: list[str], n: int) -> list[dict]:
    """要寫哪幾篇：每篇擲一州和所有判定欄；同一批母題不重複（母題用完才重來）。seed：天下骨架的種子（算地勢）。"""
    motifs = rng.sample(sorted(MOTIFS), len(MOTIFS))
    out = []
    for i in range(n):
        motif, state = motifs[i % len(motifs)], rng.choice(states)
        meet, save, origin = rng.choice(sorted(MEETS)), rng.choice(sorted(SAVES)), rng.choice(sorted(ORIGINS))
        end, land = ORIGINS[origin], newitems.land(seed, state)
        people, answer = LANDS[land][0].split("、"), rng.choice(ANSWERS) if SAVES[save][0] == "＊" else ""
        out.append({"state": state, "land": land, "motif": motif, "looks": MOTIFS[motif][0],
                    "bind": rng.choice(MOTIFS[motif][1].split("、")), "meet": meet, "meet_looks": MEETS[meet][2],
                    "save": save, "good": SAVES[save][0], "answer": answer, "origin": origin, "end": end,
                    "end_words": ENDS[end][0], "word": rng.choice(ENDS[end][0].split("、")), "who": people,
                    "images": rng.sample(sorted(clauses.IMAGES), 2), "carrier": rng.choice(sorted(CARRIERS)),
                    "law": rng.choice(LAWS), "truth": _truth(save, answer)})   # 給故事段的提示詞看（ai 層不讀 domain）
    return out


def _truth(save: str, answer: str) -> str:
    """其實那句的句型：{段} 等故事段。"""
    return clauses.fill(clauses.FORMS["其實"][0][0], 錯=SAVES[save][4], 做=SAVES[save][3].replace("{答}", answer))


def _good(slot: dict) -> list[str]:
    """答對的詞：查表的，或擲到的那一句（乙第 5 題甲）。"""
    return [slot["answer"]] if slot["good"] == "＊" else slot["good"].split("、")


def _right(slot: dict) -> str:
    return SAVES[slot["save"]][3].replace("{答}", slot["answer"])


def plain(text: str) -> str:
    return text.replace("{此地}", "某地").replace("{鄰地}", "某地")


def truth(slot: dict) -> str:
    """其實那句（{段}＝故事段的 why）。"""
    return _truth(slot["save"], slot["answer"])


def steps(slot: dict, story: dict) -> dict[str, str]:
    """了結第二三步（整句 Python 寫）：到鄰地找地勢的第一個人；第三步照了結句型，本體用故事段寫的。"""
    return {"next1": f"到{{鄰地}}找{slot['who'][0]}打聽它當年的事",
            "next2": clauses.ending(slot["word"], clauses.clean(story["boss"]), THING, slot["who"][1])}


def asks(slot: dict, got: dict) -> list[dict]:
    """bits 段要模型寫的小段：對的那則問為什麼有用、錯的那則問照做的好處（問法不帶對錯）。"""
    span_ = clauses.FORMS["說法"][1]
    meet, words = slot["meet"], [_right(slot), SAVES[slot["save"]][4]]   # 小段不准有：對的、錯的做法本身
    true1 = clauses.fill(clauses.FORMS["說法"][0][0], 載體=CARRIERS[slot["carrier"]], 找上=meet, 做=_right(slot))
    false = clauses.fill(clauses.FORMS["錯的說法"][0][0], 找上=meet, 做=SAVES[slot["save"]][4])
    return [{"key": "true1", "ask": f"接在「{true1.split('{段}')[0]}」後面，寫為什麼這樣做有用", "text": true1, "span": span_,
             "words": words, "fake": False},
            {"key": "false", "ask": f"接在「{false.split('{段}')[0]}」後面，寫照做的好處", "text": false, "span": span_,
             "words": words, "fake": True}]


def review(part: str, slot: dict, got: dict, taken: set[str], batch: list[dict], era_now: str) -> str:
    """一段合格回傳空字串，不然回傳原因。part：story／bits；got：各段的輸出（這段是剛寫的）。
    taken：世界裡已有的名字（傳說、地名）；batch：這批已經收下的（record 過的）。"""
    if part == "bits":
        return next(iter(faults(slot, got, era_now).values()), "")
    g = {k: clauses.clean(v) for k, v in got[part].items()}
    if reason := checks.basic([(plain(clauses.bit(g[k]) if k == "why" else g[k]), SPANS[k]) for k in STORY], era_now):
        return reason
    if not clauses.hit("".join(g[k] for k in STORY), slot["images"]):
        return "沒寫到意象"
    if checks.clash(g["name"], taken | {t.name for t in legends.themes()} | {b["name"] for b in batch}):
        return "撞名"
    return "重複" if checks.same_head(g["line"], [b["line"] for b in batch]) else ""


def faults(slot: dict, got: dict, era_now: str) -> dict[str, str]:
    """bits 逐欄查：沒過的小段 → 原因（GameService._write 只重寫這幾欄）。"""
    return {x["key"]: r for x in asks(slot, got)
            if (r := clauses.bit_ok(clauses.bit(got["bits"][x["key"]]), x["span"], x["words"], x["fake"], era_now))}


def _full(slot: dict, got: dict) -> dict[str, str]:
    """拼好的整句：兩則說法（key 同 asks）、其實（truth）。"""
    out = {x["key"]: x["text"].replace("{段}", clauses.bit(got["bits"][x["key"]])) for x in asks(slot, got)}
    return {**out, "truth": truth(slot).replace("{段}", clauses.bit(got["story"]["why"]))}


def questions(slot: dict, got: dict) -> list[dict]:
    """是非題（再次設計第 6 題乙）：只問模型寫的字通不通順——兩則說法的小段、其實的原因、故事的自由欄。
    want：答「是」才對；key：答錯重寫哪一欄。"""
    s = {k: clauses.bit(v) for k, v in got["story"].items()}
    return [*({"q": clauses.ask_ok(clauses.bit(got["bits"][k])), "want": True, "part": "bits", "key": k} for k in ("true1", "false")),
            *({"q": clauses.ask_ok(s[k]), "want": True, "part": "story", "key": k} for k in ("why", "line", "true2", "found1", "found2", "end"))]


def record(slot: dict, got: dict) -> dict:
    """存成一篇（legends_w）：Python 的判定欄、整句＋模型的小段和故事欄，組成跟 rules/content/legends/ 一樣格式的全文。"""
    g, full = {k: clauses.clean(v) for k, v in got["story"].items()}, _full(slot, got)
    when, natures = MEETS[slot["meet"]][:2]
    bad, wrong = SAVES[slot["save"]][1:3]
    words = slot["end_words"]
    body = [f"牌｜{g['name']}｜地方｜傳說｜地點:{BINDS[slot['bind']][0]} 時代:古代｜｜感悟:{slot['law']} 遺物:無",
            f"氣氛｜{g['mood']}", f"開口｜{g['line']}", f"碰上｜時段:{when}｜行動:{natures}",
            f"答對｜{'、'.join(_good(slot))}", f"答錯｜{bad}", *([f"做了就錯｜{wrong}"] if wrong else []),
            f"說法｜{full['true1']}", f"說法｜{g['true2']}", f"說法｜{full['false']}｜其實:{full['truth']}",
            *ending({**g, **steps(slot, got["story"])}, words), f"本體｜{g['boss']}", f"母題｜{slot['motif']}"]
    return {"name": g["name"], "state": slot["state"], "body": "\n".join(body), "source": MODEL, "line": g["line"]}


def ending(g: dict, words: str) -> list[str]:
    """了結三步的全文：此地打聽 → 鄰地找人 → 照了結的詞做（此地、鄰地都算）。"""
    return [f"步驟｜{g['found1']}｜{g['next1']}", "做法｜時段:白天｜行動:社交", "做法｜時段:白天｜行動:觀察",
            f"步驟｜{g['found2']}｜{g['next2']}", "做法｜地:鄰地｜行動:社交", "做法｜地:鄰地｜行動:探索",
            f"步驟｜{g['end']}｜", f"做法｜地:此地｜詞:{words}", f"做法｜地:鄰地｜詞:{words}"]
