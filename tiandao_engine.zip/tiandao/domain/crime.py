"""國法與宗規（2026-10-12，WHITEPAPER 16h 第 5 題；內容在 progress/LAWS.md）。純函式。

- 國法的輕重：0 無罪、1 罰金、2～4 通緝 1～3 級（通緝加「輕重 − 1」級，domain/identity.py）。
- 國家（勢力類型「國家」）擲信仰、文化、風氣各一項，存在勢力的 traits；換時代重擲。宗門擲門風，道統＝區域的路子。
- 特徵把某條罪調重（+n）、調輕（−n）、入罪（無罪改罰金）或除罪；code() 疊出每條罪的輕重。舊世界沒有國家：照基本輕重。
- 認罪（offences）：要有人看見（人多的地方，或在場還有活著的人）；小罪還要判定失敗（當場被抓）。宗門裡不歸國法管。
- 宗規與叛門（道統、門風）的條目、輕重在這裡；誰犯了、怎麼罰在 domain/sect.py。
"""
from __future__ import annotations

import random
from dataclasses import dataclass, field

from . import era, society
from . import judgment as J

# ── 罪名與基本輕重（5-2、5-2b、5-3b）─────────────────────────────────────────
HURT, KILL, SPOTTED, DESECRATE, GRAVE, DUEL = "傷人", "殺人", "施法被見", "褻瀆", "盜墓", "私鬥"
RESIST, ASSAULT, ARSON, ABDUCT, DARK, TRAFFIC = "拒捕", "襲擊官差", "縱火", "擄人", "邪術", "販賣人口"
THEFT, PEEP, FRAUD, BREAK_IN, GAMBLE, MASK, BRIBE = "偷竊", "偷窺", "詐欺", "闖入", "賭博", "易容入城", "行賄"
ALIEN = "無照入境"                       # 16k：排外的國，他族進城被認出
BASE = {HURT: 2, KILL: 3, SPOTTED: 2, DESECRATE: 1, GRAVE: 1, DUEL: 0, RESIST: 2, ASSAULT: 3, ARSON: 3, ABDUCT: 3,
        DARK: 2, TRAFFIC: 2, THEFT: 1, PEEP: 1, FRAUD: 1, BREAK_IN: 1, GAMBLE: 0, MASK: 0, BRIBE: 1,
        ALIEN: 1}   # 施法被見只在打壓時算
PETTY = (THEFT, PEEP, FRAUD, BREAK_IN, GAMBLE, MASK, BRIBE, ALIEN)
PERSON = (HURT, KILL, DUEL, ABDUCT, ASSAULT, RESIST)   # 對人動手：以下犯上罪加一等（第 7-1c 批）
FINE_LEVEL, MAX_LEVEL = 1, 4
ON, OFF, ALL, SMALL = "入罪", "除罪", "所有", "小罪"   # 調整：入罪、除罪；對象：所有不是無罪的罪、所有小罪
WORDS = {   # 玩家寫的字（「偷偷」「偷看」不算偷竊）
    THEFT: ("偷走", "偷了", "偷取", "偷拿", "扒走", "竊", "順手牽羊", "摸走"),
    PEEP: ("偷看", "偷窺"),
    FRAUD: ("騙", "詐", "冒充", "唬弄"),
    GAMBLE: ("賭錢", "賭博", "賭坊", "下注"),
    ARSON: ("放火", "縱火"),
    ABDUCT: ("擄", "綁走", "綁架", "擒住", "活捉", "綁起來"),   # 擒住重傷的對手＝收為俘虜（16i 第 8 題）
    DARK: ("招魂", "煉屍", "血祭"),
    BRIBE: ("行賄", "賄賂", "塞錢", "打點"),
}
BUSY = ("城鎮", "坊市")                 # 人多的地方：一定有人看見
HOMES = ("住家", "衙署", "丹房", "煉器閣")   # 潛行進去＝闖入（自己的落腳處、自己宗門的丹房煉器閣不算）
GRAVES = ("義莊", "墓", "陵", "墳")      # 地名結尾：在這裡探索＝盜墓
LAWLESS = ("宗門", "黑市", "修士黑市", "拍賣場")   # 不歸國法管（黑市出事自己處理，16i）
COURT = "衙署"                          # 在這裡的人算官差（另外還有追捕者，era.OFFICIAL_BY）
FINE = 100                              # 罰金級的罪當場罰多少（凡人錢）× 2 的境界次方
BRIBE_SWAY = 0.5                        # 清廉：成功也有一半拒收；腐敗：失敗也有一半收下


@dataclass(frozen=True)
class Trait:
    """國家或宗門的一項特徵。adjust：罪名（或 ALL、SMALL）→ +n／−n／ON／OFF。"""
    name: str
    line: str
    adjust: dict = field(default_factory=dict)
    eras: tuple = era.ERAS
    bribe: int = 0      # −1 難收買、+1 好收買
    hunt: float = 1     # 追捕者找上門的機率倍數


A, M, F = era.ANCIENT, era.MODERN, era.FUTURE
FAITHS = (
    Trait("敬天祭祖", "天地祖宗不可冒犯", {DESECRATE: 1, GRAVE: 2}, (A,)),
    Trait("神權", "神殿的話就是律法", {DESECRATE: 2, DARK: 2, SPOTTED: 1}, (A, F)),
    Trait("佛道並行", "寺觀遍地，講因果報應", {KILL: 1, DARK: 1}, (A, M)),
    Trait("巫祝", "巫者通鬼神，招魂是正事", {DARK: -1, DESECRATE: 1}, (A,)),
    Trait("世俗", "沒人當真信神，廟只是古蹟", {DESECRATE: -1, DARK: -1}, (M, F)),
    Trait("科技崇拜", "相信數據與機器，不信怪力亂神", {SPOTTED: 1, DARK: -1}, (F,)),
)
CULTURES = (
    Trait("禮法", "講究名分規矩，失禮就是罪", {PEEP: 1, FRAUD: 1, MASK: ON}, (A,)),
    Trait("尚武", "拳頭說話，打架是家常便飯", {DUEL: OFF, HURT: -1}),
    Trait("重商", "商路就是命脈，信用比命重", {FRAUD: 1, THEFT: 1}),
    Trait("宗族", "一族同氣連枝，血債血償", {KILL: 1, ABDUCT: 1}, (A, M)),
    Trait("邊塞", "地廣人稀，偷一匹馬就是斷人生路", {THEFT: 1, HURT: -1, TRAFFIC: OFF}, (A, F)),
    Trait("法治", "凡事照章，身分要驗明", {RESIST: 1, BRIBE: 1, MASK: ON}, (M, F)),
)
CUSTOMS = (
    Trait("清廉", "官差難收買", {BRIBE: 1}, bribe=-1),
    Trait("腐敗", "有錢能使鬼推磨", {BRIBE: OFF, TRAFFIC: OFF}, bribe=1),
    Trait("嚴刑峻法", "小事也要重罰", {ALL: 1}),
    Trait("寬鬆", "睜一隻眼閉一隻眼", {SMALL: -1}),
    Trait("禁賭", "賭坊一律查封", {GAMBLE: ON}),
    Trait("亂世", "官府自顧不暇", {KILL: -1}, (A, F), hunt=0.5),
    Trait("蓄奴", "買賣人口是正當生意", {TRAFFIC: OFF}),   # 16k
)
OTHERS = "他族"   # 16k：對他族的態度（排外：他族進城被認出算無照入境；包容：初見不因種族扣好感）
STRANGERS = (Trait("排外", "非我族類，其心必異"), Trait("包容", "諸族混居，見怪不怪"), Trait("尋常", "他族來往不多，倒也不禁"))
NATION_KINDS = {"信仰": FAITHS, "文化": CULTURES, "風氣": CUSTOMS, OTHERS: STRANGERS}

# ── 宗規與叛門（5-5～5-7；道統＝區域的路子 names.SECT_PATHS）───────────────────
# 宗規：0 不罰、1～3 記過幾級（記過 3 級＝除名）；叛門：1 輕叛、2 重叛（另外判，不跟記過疊）
HURT_KIN, CHEAT_KIN, SLAUGHTER, DARK_ART, DISGRACE = "傷同門", "偷騙同門", "濫殺凡人", "修邪術", "辱沒門楣"
LOOT, DEFECT, KILL_KIN, REBEL = "盜宗門寶物", "私投敵派", "殺同門", "對宗主長老出手"
SECT_RULES = {HURT_KIN: 1, CHEAT_KIN: 1, SLAUGHTER: 0, DARK_ART: 0, DISGRACE: 0}
TREASON = {LOOT: 1, DEFECT: 1, KILL_KIN: 2, REBEL: 2}
LIGHT, HEAVY = 1, 2
DOCTRINES = {t.name: t for t in (
    Trait("劍修", "以劍證道，劍下不斬無辜", {SLAUGHTER: 2, DARK_ART: 2}),
    Trait("丹道", "丹方是命根子，外人碰不得", {CHEAT_KIN: 1}),
    Trait("符籙", "符能救人也能殺人，畫符先正心", {DARK_ART: 1, CHEAT_KIN: 1}),
    Trait("佛門", "慈悲為懷，戒殺戒妄", {SLAUGHTER: 2, DARK_ART: 2, HURT_KIN: 1}),
    Trait("道觀", "清靜無為，順天而行", {SLAUGHTER: 1, DARK_ART: 2}),
    Trait("體修", "以身為爐，同門切磋天經地義", {HURT_KIN: OFF}),
    Trait("魔門", "弱肉強食，勝者為尊", {HURT_KIN: OFF}),
    Trait("鬼修", "與亡魂為伍，生死只是一線", {SLAUGHTER: 1}),
)}
STYLES = (
    Trait("嚴苛", "門規森嚴，一步不能錯", {CHEAT_KIN: 1, DISGRACE: 1}),
    Trait("寬厚", "有錯能改就好", {c: -1 for c in SECT_RULES}),   # 除名、叛門不變
    Trait("護短", "自家人只有自家能管", {DISGRACE: OFF}),          # 外人打傷同門，宗門派人討公道（domain/sect.py）
    Trait("冷酷", "只看有沒有用", {HURT_KIN: OFF, LOOT: 1}),       # 盜寶算重叛
    Trait("淡泊", "出世清修，不太管弟子"),
)
BY_NAME = {t.name: t for t in (*FAITHS, *CULTURES, *CUSTOMS, *STRANGERS, *DOCTRINES.values(), *STYLES)}


def roll_nation(rng: random.Random, era_now: str) -> dict:
    """國家的三項特徵（只挑這個時代有的）。"""
    return {kind: rng.choice([t for t in table if era_now in t.eras]).name for kind, table in NATION_KINDS.items()}


def roll_sect(rng: random.Random, path: str) -> dict:
    return {"道統": path, "門風": rng.choice(STYLES).name}


def nation(factions: list[dict], name: str = "") -> dict | None:
    """名叫 name 的國家；沒給名字＝第一個（起始區域的國家；舊世界沒有）。"""
    return next((f for f in factions if f["type"] == society.NATION and name in ("", f["name"])), None)


def traits_of(faction: dict | None) -> list[Trait]:
    return [BY_NAME[n] for n in (faction or {}).get("traits", {}).values() if n in BY_NAME]


def code(traits: list[Trait], base: dict[str, int] = BASE, top: int = MAX_LEVEL) -> dict[str, int]:
    """每條罪的輕重：基本輕重疊上特徵的調整（國法用 BASE；宗規用 SECT_RULES 與 TREASON）。別處的條目略過。"""
    levels = dict(base)
    for t in traits:
        for key, change in t.adjust.items():
            for c in PETTY if key == SMALL else [c for c in levels if levels[c]] if key == ALL else (key,):
                if c in levels:
                    levels[c] = (max(levels[c], FINE_LEVEL) if change == ON else 0 if change == OFF
                                 else max(0, min(top, levels[c] + change)))
    return levels


@dataclass(frozen=True)
class Scene:
    """這回合可能犯了什麼罪（service 準備好）。"""
    action: str
    failed: bool              # 判定失敗：小罪當場被抓
    words: str                # 玩家寫的字
    place_type: str
    place_name: str
    witnessed: bool           # 有人看見：人多的地方，或在場還有活著的人
    target: bool = False      # 有對象人物
    hit: bool = False
    killed: bool = False
    defending: bool = False   # 對方找上門來動手：自衛不算傷人，對官差就是拒捕
    official: bool = False    # 對象是官差（追捕者、衙署的人）
    cultivator: bool = False  # 雙方都是修士：私鬥
    own_home: bool = False
    spotted: bool = False     # 打壓時代被凡人看見施展修為
    unmasked: bool = False    # 易容當場破了
    alien: bool = False       # 排外的國，他族進城被認出（16k）
    smuggled: bool = False    # 走過交戰兩國之間封閉的邊關（16k）：算闖入


def said(s: Scene, crime: str) -> bool:
    """玩家寫的字裡有沒有這條罪的關鍵字。"""
    return any(w in s.words for w in WORDS[crime])


def offences(s: Scene) -> list[str]:
    """這回合犯了哪些罪（行賄另外算：bribing）。"""
    if not s.witnessed or s.place_type in LAWLESS:
        return []
    found = [c for c, on in ((SPOTTED, s.spotted), (MASK, s.unmasked), (ALIEN, s.alien), (BREAK_IN, s.smuggled)) if on]
    if s.official and s.hit:
        found.append(ASSAULT)
    elif s.official and s.defending and s.action == J.COMBAT:
        found.append(RESIST)
    elif s.hit and not s.defending:
        found.append(KILL if s.killed else DUEL if s.cultivator else HURT)
    if s.action == J.COMBAT and (s.place_type == "祠堂" or s.place_name.endswith("廟")):
        found.append(DESECRATE)
    if s.action == J.EXPLORE and s.place_name.endswith(GRAVES):
        found.append(GRAVE)
    found += [c for c in (ARSON, DARK) if said(s, c)] + ([ABDUCT] if s.target and said(s, ABDUCT) else [])
    if s.failed:   # 小罪：當場被抓
        found += [c for c in (THEFT, PEEP, FRAUD, GAMBLE) if said(s, c) and not (c == PEEP and s.own_home)]   # 打字第 5 題
        found += [BREAK_IN] if s.action == J.STEALTH and s.place_type in HOMES and not s.own_home else []
    return found


def got_away(s: Scene, ok: bool) -> bool:
    """偷竊得手：判定成功（沒人發現），得少量凡人錢。"""
    return ok and s.action == J.STEALTH and said(s, THEFT)


def bribing(s: Scene) -> bool:
    """這回合在跟官差行賄。"""
    return s.official and s.action == J.SOCIAL and said(s, BRIBE)


def bribe_taken(rng: random.Random, ok: bool, traits: list[Trait]) -> bool:
    """官差收不收：判定成功就收；清廉之國成功也有一半拒收，腐敗之國失敗也有一半收下。"""
    lean = sum(t.bribe for t in traits)
    return rng.random() < BRIBE_SWAY if (ok and lean < 0) or (not ok and lean > 0) else ok


def punish(levels: dict[str, int], found: list[str]) -> tuple[int, int, bool]:
    """這回合的罪 → (罰金級的有幾條, 通緝加幾級, 有沒有殺人)。"""
    return (sum(levels[c] == FINE_LEVEL for c in found), sum(max(0, levels[c] - 1) for c in found),
            KILL in found and levels[KILL] > FINE_LEVEL)


def heavier(levels: dict[str, int], found: list[str]) -> dict[str, int]:
    """以下犯上（第 7-1c 批，rank.upward）：這回合對人動手的罪加一等。"""
    return {**levels, **{c: min(MAX_LEVEL, levels[c] + 1) for c in found if c in PERSON}}


def hunt_rate(traits: list[Trait]) -> float:
    rate = 1.0
    for t in traits:
        rate *= t.hunt
    return rate


def text(faction: dict | None, reign: str = "") -> str:
    """給說書人的【國法】：「大周國（大順朝，前朝：大寧）：敬天祭祖（天地祖宗不可冒犯）；……」。舊世界沒有國家：空字串。
    reign：國號（第 8-2 批，domain/lapse.reign）。"""
    traits = traits_of(faction)
    return f"{faction['name']}{reign}：" + "；".join(f"{t.name}（{t.line}）" for t in traits) if traits else ""


HISTORY = {"覆滅": int, "重開": int, "接手": str, "前身": str}   # 散了、接手（7-3b、第 8-2 批，domain/lapse.py）：哪種勢力都能有


def valid(type_: str, traits) -> bool:
    """勢力的 traits：國家三項、宗門兩項、其他（含舊存檔）空的；另外可以有 HISTORY 那幾欄。"""
    if isinstance(traits, dict) and not all(isinstance(traits[k], t) for k, t in HISTORY.items() if k in traits):
        return False
    traits = {k: v for k, v in traits.items() if k not in HISTORY} if isinstance(traits, dict) else traits
    if not isinstance(traits, dict) or not traits:
        return isinstance(traits, dict)
    if type_ == society.NATION:
        return set(traits) == set(NATION_KINDS) and all(
            traits[k] in {t.name for t in table} for k, table in NATION_KINDS.items())
    if set(traits) == {"黑市"}:   # 經營黑市的集團（16i，domain/market.py）
        return type_ in ("幫派", "商會") and isinstance(traits["黑市"], list) and all(isinstance(m, str) for m in traits["黑市"])
    return (type_ == "宗門" and set(traits) == {"道統", "門風"} and traits["道統"] in DOCTRINES
            and traits["門風"] in {t.name for t in STYLES})
