"""在場的人怎麼反應（Claude 主導第 3 題甲，實作第 2 批）：第一段由大模型決定，程式只擋違反事實的。純函式。

- 做什麼七選一（ACTS）；誰、對誰只能是在場、活著的人（清單本來就只列他們，這裡再擋一次）。
- 揭穿：只能說出他知道的事（knows 帳，domain/hearsay）。
- 動手：這批只准對主角，照當面對峙算（game 層，domain/visitors）；NPC 之間動手還沒做。
- 一回合最多 MAX 個人，說什麼最多 SAY 字。
"""
from __future__ import annotations

ACTS = ("說話", "幫忙", "阻攔", "動手", "離開", "揭穿", "不理")
ME, NONE = "主角", "沒有"
MAX, SAY = 3, 60


def label(e: dict) -> str:
    """一件你做過的事（hearsay.event）：給大模型挑、也給程式對。"""
    return f"{e['kind']}：{e['target']}（{e['place']}）"


def check(moves: list[dict], alive: set[str], known: dict[str, tuple[str, ...]]) -> tuple[list[dict], list[str]]:
    """回傳（照走的, 擋下的原因）。known：名字 → 他知道的事（label）。"""
    kept, dropped = [], []
    for m in moves[:MAX]:
        who, act, to = m.get("誰", ""), m.get("做什麼", ""), m.get("對誰", ME)
        why = ("不在場或已經不在了" if who not in alive or to not in alive | {ME, NONE}
               else "不知道這件事" if act == "揭穿" and m.get("揭穿哪件") not in known.get(who, ())
               else "NPC 之間動手還沒做" if act == "動手" and to != ME
               else "做什麼不在清單裡" if act not in ACTS else "")
        if why:
            dropped.append(f"{who}{act}：{why}")
        else:
            kept.append({**m, "對誰": to, "說什麼": str(m.get("說什麼", ""))[:SAY]})
    return kept, dropped


def line(m: dict) -> str:
    """給第二段的一行：「王二對主角阻攔：別過去」。"""
    what = f"揭穿（{m['揭穿哪件']}）" if m["做什麼"] == "揭穿" else m["做什麼"]
    to = "" if m["對誰"] == NONE else f"對{m['對誰']}"
    return f"{m['誰']}{to}{what}" + (f"：{m['說什麼']}" if m.get("說什麼") else "")
