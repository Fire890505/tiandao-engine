"""宗主經營（16l 第 31、34、37 題；草稿 C5b1）：主角是自己立的仙宗的宗主。純函式。

規則（2026-10-19 與使用者一題一題定案，見 progress/WHITEPAPER.md 16l，數字暫定）：
- 職位「宗主」（sect.LORD）：不會除名、不受門規；月例＝仙宗實力 × PAY。
- 無人主持：宗主離開山門超過 ABSENT，每個百日仙宗實力 −1、成形門人好感 NEGLECT（回山門就停）。
- 派門人：在自家山門說「派某某去出戰／鎮守／搶造化／傳訊」（沒指名＝名冊上的弟子；說「重」「輕」定輕重，預設中）。
  仙宗多 errands [{who, kind, tier, until}]，最多 MAX_OUT 件，期限 errand.LASTS；到期擲勝負（ODDS，門人境界每高
  一級 +LV_BONUS）：成功實力 +1～3（重的加倍）、成形門人差事成績 +1；失敗負傷，重的 DEATH 戰死（名冊上的弟子：
  起點後移一號），成形門人重差事失敗好感 FAIL。
- 人心：好感 < 0 的門人 REFUSE 推託；好感 < GRUDGE、已被派過 DEFECT_AFTER 次重差事，再派重的就叛宗並記恨。
- 任免：「封某某為長老」（長老滿 ELDERS 位就換下第一位；說「換下某某」換指定的）、「逐出某某」除名並記恨。
  仙宗多 elders（長老名字）；好感：被封 RAISE、被換下 DROP、被逐出 EXPEL。
- 升遷：仙宗多 deeds {門人: [辦成幾件, 被派過幾次重的]}；PROMOTE 的門檻升內門、真傳；辦成 ASK 件以上還不是長老，
  之後每辦成一件好感 ASK_DROP。
- 傳承（第 34～36 題，C5b2）：「傳位給某某」（長老）＝自己當太上長老（sect.RETIRED），加說離宗就走（不算叛宗）；
  繼任者 RAISE、其他長老 PASSED。宗主沒傳位就殞落或退隱＝第一位長老接位，動盪（仙宗 unrest）到下一個百日、
  實力 −UNREST，盟內叛盟機率加倍（immortal._pull）；兩位以上長老擲爭位，爭不下就分裂（新宗 origin＝原宗，
  跟原宗的盟算冷戰：immortal.feud）。
"""
from __future__ import annotations

from . import ascent, errand, immortal, opinion, roster, sect
from .clock import SHICHEN_PER_DAY

PAY = 2
ABSENT = immortal.PERIOD
_SLIGHT = [opinion.hit(opinion.INSULT, opinion.LIKE, opinion.SMALL, -1)]
NEGLECT = _SLIGHT
MAX_OUT = 3
ODDS = {"輕": 0.8, "中": 0.6, "重": 0.4}
LV_BONUS = 0.1
DEATH = 0.3
FAIL = _SLIGHT
REFUSE = 0.5
GRUDGE, DEFECT_AFTER = -30, 2
ELDERS = 2
RAISE = [opinion.hit(opinion.HELP, opinion.LIKE, opinion.BIG)]
DROP = [opinion.hit(opinion.INSULT, opinion.LIKE, opinion.BIG, -1)]
EXPEL = [opinion.hit(opinion.OUST, opinion.LIKE, opinion.GRAVE, -1)]   # 逐出＝立約斷掉（第 121-4 題）
PROMOTE = {3: sect.INNER, 6: sect.CORE}
ASK, ASK_DROP = 10, _SLIGHT
NOBODY = "名冊上的弟子"
PASSED = _SLIGHT        # 傳位時沒被選上的長老（C5b2）
UNREST, SPLIT = 2, 0.4  # 沒傳位就走了：動盪扣的實力、長老爭不下而分裂的機率（C5b2）
LEAVE_WORDS = ("離宗", "離開宗門")   # 傳位之後不留宗（不算叛宗）


def own(realm: dict, sheet: dict, life: str) -> dict | None:
    """這一生是宗主的仙宗（自己立的）。"""
    return next((s for s in realm["sects"] if s["name"] == sheet["sect"] and s.get("founder") == life), None)


def rank_of(s: dict, name: str) -> str:
    if name in s.get("elders", []):
        return "長老"
    done = s.get("deeds", {}).get(name, [0, 0])[0]
    return next((r for need, r in sorted(PROMOTE.items(), reverse=True) if done >= need), sect.OUTER)


def neglect(s: dict, sheet: dict, here: str, now: int) -> tuple[dict, list[str]]:
    """宗主不在山門超過 ABSENT：這個百日實力 −1（成形門人的好感由呼叫端一起降）。回傳的事實非空＝這回合扣了。"""
    p = now // immortal.PERIOD
    if here == s["name"] + ascent.GATE or now - sheet["sect_back"] <= ABSENT or s.get("neglect", -1) >= p:
        return s, []
    return {**s, "power": max(0, s["power"] - 1), "neglect": p}, [f"{s['name']}宗主久不在山門，無人主持，人心浮動，實力 −1"]


def order(rng, s: dict, words: str, members: dict[str, tuple[int, int]], now: int):
    """在自家山門下令：逐出、封長老、派差事。members：成形門人 → (好感, 境界)。
    回傳（仙宗, 事實, 好感變化 [(名字, (好感, 信任))], 離宗的人 {名字: 記的仇}）。"""
    out, deeds, elders = s.get("errands", []), s.get("deeds", {}), s.get("elders", [])
    down = next((e for e in elders if f"換下{e}" in words), "")
    who = next((m for m in sorted(members, key=len, reverse=True) if m in words.replace(f"換下{down}", "")), "")
    if "逐出" in words and who:
        return _drop(s, who), [f"把{who}逐出{s['name']}"], [(who, EXPEL)], {who: "被逐出宗門"}
    if "封" in words and "長老" in words and who:
        if who in elders:
            return s, [f"{who}已經是長老"], [], {}
        down = down or (elders[0] if len(elders) >= ELDERS else "")
        s = {**s, "elders": [e for e in elders if e != down] + [who]}
        return (s, [f"封{who}為{s['name']}長老"] + ([f"{down}被換下長老之位"] if down else []),
                [(who, RAISE)] + ([(down, DROP)] if down else []), {})
    kind = next((k for k in errand.KINDS if k in words), "")
    if "派" not in words or not kind:
        return s, [], [], {}
    if len(out) >= MAX_OUT:
        return s, [f"門下已經派出 {MAX_OUT} 件差事，人手不夠"], [], {}
    if who and any(e["who"] == who for e in out):
        return s, [f"{who}手上已經有差事"], [], {}
    tier = "重" if "重" in words else "輕" if "輕" in words else "中"
    if who:
        done, sent = deeds.get(who, [0, 0])
        if tier == "重" and members[who][0] < GRUDGE and sent >= DEFECT_AFTER:
            return _drop(s, who), [f"{who}不肯再被派去送死，叛出{s['name']}"], [], {who: "被派去送死"}
        if members[who][0] < 0 and rng.random() < REFUSE:
            return s, [f"{who}推託不去"], [], {}
        deeds = {**deeds, who: [done, sent + (tier == "重")]}
    e = {"who": who, "kind": kind, "tier": tier, "until": now + errand.LASTS}
    return ({**s, "errands": out + [e], "deeds": deeds},
            [f"派{who or NOBODY}去{kind}（{tier}），{errand.LASTS // SHICHEN_PER_DAY} 天後回報"], [], {})


def settle(rng, s: dict, members: dict[str, tuple[int, int]], now: int):
    """到期的差事擲勝負。回傳（仙宗, 事實, 受傷的成形門人 {名字: 狀況}, 好感變化）。"""
    due = [e for e in s.get("errands", []) if e["until"] <= now]
    if not due:
        return s, [], {}, []
    s = {**s, "errands": [e for e in s["errands"] if e["until"] > now]}
    facts, hurt, shifts = [], {}, []
    for e in due:
        who, heavy = e["who"], e["tier"] == "重"
        if who and who not in members:   # 已經不在宗裡了
            continue
        lv = members[who][1] if who else roster.LV[roster.MEMBER]
        if rng.random() < ODDS[e["tier"]] + LV_BONUS * (lv - roster.LV[roster.MEMBER]):
            gain = rng.randint(1, 3) * (2 if heavy else 1)
            s = {**s, "power": min(100, s["power"] + gain)}
            facts.append(f"{who or NOBODY}辦成了{e['kind']}的差事，{s['name']}實力 +{gain}")
            if who:
                s, more, shift = _promote(s, who)
                facts, shifts = facts + more, shifts + shift
            continue
        dead = heavy and rng.random() < DEATH
        facts.append(f"{who or NOBODY}{e['kind']}失利，{'戰死' if dead else '負傷而回'}")
        if who:
            hurt[who] = "殞落" if dead else "負傷"
            shifts += [(who, FAIL)] if heavy and not dead else []
        elif dead:
            lo, hi = roster.span(s)
            s = {**s, "roster": [min(lo + 1, hi), hi]}
    return s, facts, hurt, shifts


def _promote(s: dict, who: str) -> tuple[dict, list[str], list]:
    deeds = s.get("deeds", {})
    done, sent = deeds.get(who, [0, 0])
    before = rank_of(s, who)
    s = {**s, "deeds": {**deeds, who: [done + 1, sent]}}
    facts = [f"{who}升為{rank_of(s, who)}弟子"] if rank_of(s, who) != before else []
    if who in s.get("elders", []) or done + 1 < ASK:
        return s, facts, []
    if done + 1 == ASK:
        return s, facts + [f"{who}辦成了 {ASK} 件差事，想要長老之位"], []
    return s, facts + [f"{who}不滿遲遲沒有封為長老"], [(who, ASK_DROP)]


def abdicate(s: dict, words: str):
    """在自家山門說「傳位給某某」（要是長老）。回傳 None（沒說），或（仙宗, 事實, 好感變化, 繼任者）；
    繼任者空字串＝傳不成。傳了位的仙宗不再有 founder（之後照 NPC 仙宗）。"""
    if "傳位" not in words:
        return None
    elders = s.get("elders", [])
    heir = next((e for e in elders if e in words), "")
    if not heir:
        return s, ["只能傳位給長老"], [], ""
    rest = [e for e in elders if e != heir]
    return (_hand(s, heir), [f"傳位給{heir}，{heir}成了{s['name']}宗主"], [(heir, RAISE)] + [(e, PASSED) for e in rest],
            heir)


def succeed(rng, realm: dict, s: dict, now: int) -> tuple[dict, list[str], str, tuple[str, str] | None]:
    """宗主沒傳位就殞落或退隱：第一位長老接位，動盪到下一個百日（實力 −UNREST）；兩位以上長老時擲爭位，
    爭不下（SPLIT）就分裂：第二位長老帶走三分之一實力，在原宗旁邊的空格另立新宗（origin＝原宗），沒有空格就成散仙。
    回傳（仙域, 傳聞, 繼任者, (出走的長老, 新宗名或空字串) 或 None）。"""
    elders = s.get("elders", [])
    heir, rival = (elders + ["", ""])[:2]
    kept = {**_hand(s, heir), "power": max(0, s["power"] - UNREST), "unrest": now // immortal.PERIOD + 1}
    facts = [f"{s['name']}宗主身故，未立傳人，{heir or '門人'}接掌宗門，宗內動盪"]
    if not rival or rng.random() >= SPLIT:
        return _put(realm, kept), facts, heir, None
    third = kept["power"] // 3
    realm = _put(realm, {**kept, "power": kept["power"] - third, "elders": [e for e in kept["elders"] if e != rival]})
    at = immortal.cells_of(realm)
    cell = next(iter(sorted((x + dx, y + dy) for x, y in s["cells"] for dx, dy in immortal.STEPS
                            if (x + dx, y + dy) not in at)), None)
    after = immortal._found({**realm, "free": [c for c in realm.get("free", []) if tuple(c) != cell]}, rng, "",
                            s["path"], s["race"], list(cell)) if cell else realm
    if len(after["sects"]) == len(realm["sects"]):
        return realm, facts + [f"{rival}爭位不成，帶著一批門人出走，成了散仙"], heir, (rival, "")
    new = {**after["sects"][-1], "power": max(1, third), "origin": s["name"]}
    return ({**after, "sects": after["sects"][:-1] + [new]}, facts + [f"{rival}爭位不成，帶走一批門人另立{new['name']}"],
            heir, (rival, new["name"]))


def _hand(s: dict, heir: str) -> dict:
    """宗主之位交給 heir：不再是主角的宗，派出的差事作廢。"""
    return {**{k: v for k, v in s.items() if k not in ("founder", "errands")},
            "elders": [e for e in s.get("elders", []) if e != heir]}


def _put(realm: dict, s: dict) -> dict:
    return {**realm, "sects": [s if x["name"] == s["name"] else x for x in realm["sects"]]}


def _drop(s: dict, who: str) -> dict:
    return {**s, "elders": [e for e in s.get("elders", []) if e != who],
            "deeds": {k: v for k, v in s.get("deeds", {}).items() if k != who},
            "errands": [e for e in s.get("errands", []) if e["who"] != who]}


def panel(s: dict, members: dict[str, tuple[int, int]], now: int) -> dict:
    """畫面的「宗門」：仙宗實力、長老、成形門人、派出的差事。"""
    return {"name": s["name"], "power": s["power"], "elders": s.get("elders", []),
            "members": [{"name": n, "rank": rank_of(s, n), "affinity": a,
                         "deeds": s.get("deeds", {}).get(n, [0, 0])[0]} for n, (a, _) in sorted(members.items())],
            "out": [{"who": e["who"] or NOBODY, "kind": e["kind"], "tier": e["tier"],
                     "days": max(0, e["until"] - now) // SHICHEN_PER_DAY} for e in s.get("errands", [])]}
