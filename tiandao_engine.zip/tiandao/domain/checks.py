"""模型寫的內容共用的審核關卡（第 128 系列，progress/模型生成內容.md 第七節）：物品、傳說、之後的怪談都用這一份。純函式。"""
from __future__ import annotations

import re

from . import era as era_mod

CHINESE = re.compile(r"^[㐀-鿿，。、；：「」『』！？·・—…]+$")   # 只准中文和標點，不准數字（『』：9b 寫傳說常用來框住關鍵詞；—：正解常用破折號；…：亡魂斷斷續續的話）
ANCIENT_WORDS = ("手機", "電話", "電燈", "電視", "汽車", "火車", "飛機", "槍", "炸彈", "塑膠", "水泥", "鋼筋", "引擎", "電池",
                 "網路", "公里", "公斤", "晶片", "機器", "玻璃瓶",
                 "撒哈拉", "亞馬遜", "埃及", "羅馬", "希臘", "歐洲", "非洲", "美洲", "印度", "阿拉伯")   # 古代不准出現的詞、外國地名（不夠再補）
OLD_WORDS = ("銀子", "銀兩", "銅錢", "衙門", "捕快", "衙役", "縣太爺", "官老爺", "客棧", "鏢局", "驛站", "朝廷", "聖旨",   # 現代、未來不准出現的（模型事端，第 8 題甲）
             "趕集", "盤纏", "打更", "梆子", "三更", "桃枝", "柴", "挑水", "說書", "粥棚", "畫押", "告示", "樵夫", "跑堂", "馬夫",
             "茶樓", "流寇", "問斬", "走鏢", "灶", "官兵")   # 牌裡查到的（待辦 2）；牌換過時代詞表以後也不准有（test_cards）


def basic(fields: list[tuple[str, tuple[int, int]]], era_now: str) -> str:
    """長度、只准中文、古代詞：合格回傳空字串，不然回傳原因。fields：（文字, （最短, 最長））。"""
    if not all(span[0] <= len(t) <= span[1] for t, span in fields):
        return "長度"
    if not all(CHINESE.match(t) for t, _ in fields):
        return "不是中文"
    if any(w in t for t, _ in fields for w in (ANCIENT_WORDS if era_now == era_mod.ANCIENT else OLD_WORDS)):
        return "時代"
    return ""


def clash(name: str, taken) -> bool:
    """撞名：一樣，或一樣長只差一個字。"""
    return any(name == n or len(name) == len(n) and sum(x != y for x, y in zip(name, n)) == 1 for n in taken)


def same_head(text: str, others: list[str]) -> int:
    """同一批開頭兩字一樣的有幾篇。"""
    return sum(o[:2] == text[:2] for o in others)
