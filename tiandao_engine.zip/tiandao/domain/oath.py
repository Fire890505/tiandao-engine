"""入宗時立的誓（16l 第 23 題；草稿 C4c）。純函式。

規則（2026-10-18 與使用者一題一題定案，見 progress/WHITEPAPER.md 16l，數字暫定）：
- 角色卡 sect_oath：None，或 {text, since, earned}（earned：立誓以來掙到的戰功，花掉不扣）。
- 立了誓的人離宗（辭別、除名、被逐都算）＝叛宗：永不再收、宗門派人追殺（沿用下界重叛）。
  精血誓（BLOOD）另有天道反噬：注視 +BLOOD_GAZE、掉一個小境界（修為歸零）。
- 出戰誓（BATTLE）：立誓起 BATTLE_YEARS 年內 earned 到 BATTLE_MERIT；到期沒達到降一級職位。到期就了結。
- 聽候差遣、鎮守秘境兩條由宗門差事檢查（errand.py，C5a）；不得私收他宗弟子只是文字。
"""
from __future__ import annotations

from . import ascent, sect
from .clock import SHICHEN_PER_YEAR

BATTLE, BLOOD = ascent.OATHS[0], ascent.OATHS[1]
BATTLE_YEARS, BATTLE_MERIT = 100, 100
BLOOD_GAZE = 20
SOURCE = "背誓"   # 天道注視的來源


def make(text: str, clock_now: int) -> dict | None:
    return {"text": text, "since": clock_now, "earned": 0} if text else None


def earn(sheet: dict, points: int) -> dict:
    o = sheet["sect_oath"]
    return {**sheet, "sect_oath": {**o, "earned": o["earned"] + points}} if o and points else sheet


def broken(sheet: dict, hall: str, clock_now: int) -> tuple[dict, list[str], list[tuple[str, int]]]:
    """離開了 hall：有誓在身就是叛宗。回傳（角色卡, 事實, 天道注視）。sheet 是已經離宗的角色卡。"""
    o = sheet["sect_oath"]
    if not o:
        return sheet, [], []
    sheet = {**sheet, "sect_oath": None, "sect_bans": {**sheet["sect_bans"], hall: sect.FOREVER},
             "sect_hunt": {"hall": hall, "level": sect.MAX_HUNT, "since": clock_now, "art": sheet["sect_art"]}}
    facts = [f"背棄了對{hall}立下的誓言（{o['text']}），被視為叛徒，派人追殺"]
    if o["text"] != BLOOD:
        return sheet, facts, []
    sheet = {**sheet, "stage_index": max(0, sheet["stage_index"] - 1), "cultivation": 0}
    return sheet, facts + ["本命精血反噬，境界跌落"], [(SOURCE, BLOOD_GAZE)]


def due(sheet: dict, clock_now: int) -> tuple[dict, list[str]]:
    """出戰誓到期：戰功不夠降一級；到期就了結。"""
    o = sheet["sect_oath"]
    if not o or o["text"] != BATTLE or clock_now - o["since"] < BATTLE_YEARS * SHICHEN_PER_YEAR:
        return sheet, []
    sheet = {**sheet, "sect_oath": None}
    if o["earned"] >= BATTLE_MERIT:
        return sheet, [f"百年出戰之誓圓滿了結（戰功 {o['earned']}）"]
    rank = sect.RANKS[max(0, sect.RANKS.index(sheet["sect_rank"]) - 1)]
    return {**sheet, "sect_rank": rank}, [f"百年出戰之誓沒有做到（戰功只有 {o['earned']}），降為{rank}弟子"]
