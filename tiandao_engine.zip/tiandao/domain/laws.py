"""法則（第 3b-1 步，2026-11-21 重做）：39 系、234 條現象、參悟、殘理與法則、功法親和、天道鎖定。純函式。

規則（progress/法則領域世界設計.md「零、現象」P1～P6、「零之一」R1～R6；內容在 rules/content/phenomena.txt）：
- 角色卡 insight：現象 → 感悟 0～100。有這一格＝見過；滿 100＝悟透，得到那一條的殘理。
- 每系 6 條：凡象 3、靈象 2、天象 1。法則＝那一系悟透過半（4 條，至少一條靈象）而且境界 Lv4。
- 參悟對準一條現象：話裡有現象名就是那條；只說了系，挑那一系見過、沒悟透的，眼前正發生的優先，再來進度最高的。
  眼前正發生、還沒見過的，參悟時順便算見過；一條都沒有就快速拒絕。
- 見過（第二批）：每回合收尾，眼前還沒見過的現象看見一條（天象優先，天道執念對上的加倍）；看見天象注視 +1。
  眼前＝地點、季節、時辰、族、道統、天氣、氣候、地勢、災、這回合的事（service._scene）。
- 成功 +10、大成功 +20、失敗 +3，套閉關遞減公式；契合各 +50%（靈根、主修功法、時節、秘境、道統、命途），在場 +100%。
- 時、因果、命、造化、虛五系天道鎖定到 Lv10：能見過、記進圖鑑，參悟被彈回（扣一成氣血、注視上升）。
- 生、死兩系照算殘理，但不給判定加成（技能延伸 S5 定以前照舊專案的「不延伸」）。
- 判定加成照系認：行動字面用到那一系的字，有殘理 +5、有法則 +10。
- NPC 只記結果：Lv3 一條殘理、Lv4 起一系法則，由名字固定算出（不存資料庫）。
"""
from __future__ import annotations

import re
import zlib
from dataclasses import dataclass

from ..config import PROJECT_ROOT
from . import clock, items
from . import judgment as J

FULL, APPLY_LV, UNLOCK_LV = 100, 4, 10        # 悟透、化為法則的境界、鎖定解開的境界
RESIDUE_STAGE, APPLY_STAGE = "殘理", "法則"
COMMON, SPIRIT, HEAVEN = "凡", "靈", "天"
STUDY_GAIN = {J.GREAT_SUCCESS: 20, J.SUCCESS: 10, J.FAILURE: 3}   # 失敗也有一點（小修清單第 5 題），大失敗沒有
BOOST, HERE_BOOST = 0.5, 1.0                   # 每項契合 +50%；在場 +100%
LOCKED_HP = 0.1
BONUS = {RESIDUE_STAGE: 5, APPLY_STAGE: 10}
BONUS_NATURES = (J.COMBAT, J.STEALTH, J.EXPLORE, J.SOCIAL)
NO_BONUS = ("生系", "死系")
LOCK_NOTE = f"此系為天道所鎖，Lv{UNLOCK_LV} 之前不得領悟"
PERMISSION = {RESIDUE_STAGE: "可借用這一條之力，不能主動操控", APPLY_STAGE: "可操控此系的各種狀態"}
# 新系改接對照 Q1 乙、Q8 乙、Q7 乙：季節、道統、特殊命各帶的系
SEASON_LAWS = {"春": ("木系", "生系"), "夏": ("火系", "光系"), "秋": ("金系", "風系"), "冬": ("水系", "冰系")}
PATH_LAWS = {"劍修": ("金系", "戰系"), "魔門": ("慾系", "暗系"), "丹道": ("火系", "木系"), "符籙": ("封系", "言系"),
             "體修": ("身系",), "鬼修": ("鬼系", "魂系"), "佛門": ("業系", "願系"), "道觀": ("靈系", "星系")}
FATE_LAWS = {"孤星命": "業系", "旺人命": "願系", "情劫命": "情系", "纏絲命": "夢系", "地氣命": "靈系", "啟封命": "封系",
             "聞冥命": "鬼系", "寄身命": "魂系", "風起命": "風系", "眾推命": "律系", "渡壽命": "生系", "礪命": "身系"}
PERIODS = dict(zip(clock.SHICHEN_NAMES, ("夜", "夜", "晨", "晨", "晨", "午", "午", "午", "昏", "昏", "夜", "夜")))
# 這回合的「事」（第二批）：行動本身、字面，其餘由 service 照怪談、亡者、事端、事件、天道落子補上
ACTION_TAGS = {J.COMBAT: ("戰鬥",), J.SOCIAL: ("社交",), J.ALCHEMY: ("煉丹",), J.FORGE: ("煉器",), J.WORK: ("做工",),
               J.REST: ("休息",), J.BREAKTHROUGH: ("突破", "渡劫", "劫")}
WORD_TAGS = {"祭祀": ("祭", "上香", "拜神", "祈雨", "求雨", "燒紙"), "立約": ("立約", "立誓", "發誓", "契約", "結拜", "畫押"),
             "醫治": ("醫治", "治傷", "療傷", "救治", "包紮"),
             "練武": ("練武", "練拳", "練劍", "練刀", "站樁", "打拳", "煉體", "練功")}   # E6：體修走身、戰系的道
HEAVEN_TAGS = ("渡劫", "小劫數", "心魔", "餌", "宿敵", "抹殺之劫")   # 天道落子的種類（games）：也都算「劫」
SIGN, SIGN_GAZE = "天象", 1                                           # 看見天象：天道注視的來源與點數（R6「小升」）


@dataclass(frozen=True)
class Phenomenon:
    system: str
    tier: str
    name: str
    text: str
    need: tuple            # ((字, 值的集合), ...) 的組；任一組成立
    power: str             # 悟透能做到
    persona: str = ""      # 天象：天道執念對上時容易看見


def _need(text: str) -> tuple:
    return tuple(tuple((k, frozenset(re.sub(r"（.*?）", "", v).split("、"))) for k, v in
                       (p.strip().split(":", 1) for p in group.split("；") if p.strip()))
                 for group in text.split("／") if group.strip())


_rows = [line.split("｜") for line in (PROJECT_ROOT / "rules" / "content" / "phenomena.txt").read_text(
    encoding="utf-8").splitlines() if line and not line.startswith("#")]
WORDS = {r[1]: (r[1], *r[4].split("、")) for r in _rows if r[0] == "系"}   # 系名本身也算（日常面板送「參悟生系」）
SYSTEMS = tuple(WORDS)
LOCKED = tuple(r[1] for r in _rows if r[0] == "系" and r[3] == "鎖")
OPEN_SYSTEMS = tuple(s for s in SYSTEMS if s not in LOCKED)
PHENOMENA = {r[3]: Phenomenon(r[1], r[2], r[3], r[4], _need(r[5]), r[7], r[6].removeprefix("人格:"))
             for r in _rows if r[0] == "象"}
BY_SYSTEM = {s: tuple(n for n, p in PHENOMENA.items() if p.system == s) for s in SYSTEMS}


# ── 認字、在場 ───────────────────────────────────────────────────────────
def _matches(text: str) -> list[tuple[int, int, str]]:
    return sorted((text.find(w), -len(w), s) for s, words in WORDS.items() for w in words if w in text)


def system_in(text: str) -> str:
    """字面上最先出現的那一系（現象名也算）；沒有回傳空字串。"""
    name = phenomenon_in(text)
    found = _matches(text or "")
    return PHENOMENA[name].system if name else found[0][2] if found else ""


def phenomenon_in(text: str) -> str:
    return next((n for n in PHENOMENA if n in (text or "")), "")


def system_of(name: str) -> str:
    """現象或系 → 系。"""
    return PHENOMENA[name].system if name in PHENOMENA else name if name in WORDS else ""


def scene(sheet: dict, place_type: str, now: int, **more) -> dict:
    """眼前的情況（條件的字 → 值）。more：service 算的天氣、氣候、地勢（字串），災、事（集合）；沒給的一律不成立。"""
    return {"地點": place_type, "季節": clock.season_of(now), "時": PERIODS[clock.SHICHEN_NAMES[now % clock.SHICHEN_PER_DAY]],
            "族": sheet.get("race", ""), "道統": sheet.get("path", ""), **more}


def tags(nature: str, text: str, retreating: bool, dying: bool) -> set[str]:
    """這回合的事裡，看行動和字面就知道的那些。"""
    found = set(ACTION_TAGS.get(nature, ())) | {t for t, words in WORD_TAGS.items() if any(w in (text or "") for w in words)}
    return found | ({"閉關"} if retreating else set()) | ({"瀕死"} if dying else set())


def _hit(value, vals: frozenset) -> bool:
    return value in vals if isinstance(value, str) else bool(vals & set(value or ()))


def present(name: str, here: dict, realm_lv: int) -> bool:
    """這條現象此刻在眼前：任一組條件都成立。靈象要 Lv1。"""
    p = PHENOMENA[name]
    acted = p.tier != HEAVEN or bool({"劫", *HEAVEN_TAGS} & set(here.get("事") or ()))   # 天象只在天道出手時（R6）
    return acted and (p.tier != SPIRIT or realm_lv >= 1) and any(all(_hit(here.get(k), vals) for k, vals in g) for g in p.need)


def notice(sheet: dict, here: dict, persona: str, rng) -> tuple[dict, list[str], list[tuple[str, int]]]:
    """回合收尾：眼前還沒見過的現象看見一條（天象優先，天道執念對上的再加倍），記成見過。
    回傳（角色卡, 事實, 天道注視的來源）。看見天象注視小升（R6）。"""
    fresh = [n for n in PHENOMENA if n not in sheet["insight"] and present(n, here, sheet["realm_lv"])]
    top = [n for n in fresh if PHENOMENA[n].tier == HEAVEN] or fresh
    if not top:
        return sheet, [], []
    name = rng.choices(top, weights=[2 if persona and PHENOMENA[n].persona == persona else 1 for n in top])[0]
    p = PHENOMENA[name]
    sheet = {**sheet, "insight": {**sheet["insight"], name: 0}}
    return sheet, [f"看見了{name}：{p.text}"], [(SIGN, SIGN_GAZE)] if p.tier == HEAVEN else []


# ── 感悟與階段 ───────────────────────────────────────────────────────────
def mastered(sheet: dict) -> list[str]:
    return [n for n, v in sheet["insight"].items() if v >= FULL]


def _applies(names: list[str], system: str) -> bool:
    mine = [n for n in names if PHENOMENA[n].system == system]
    return len(mine) > len(BY_SYSTEM[system]) // 2 and any(PHENOMENA[n].tier == SPIRIT for n in mine)


def stage(sheet: dict, system: str) -> str:
    names = mastered(sheet)
    if sheet["realm_lv"] >= APPLY_LV and _applies(names, system):
        return APPLY_STAGE
    return RESIDUE_STAGE if any(PHENOMENA[n].system == system for n in names) else ""


def held(sheet: dict) -> dict[str, str]:
    """有殘理的系 → 階段。"""
    return {s: stage(sheet, s) for s in dict.fromkeys(PHENOMENA[n].system for n in mastered(sheet))}


def residue_count(sheet: dict) -> int:
    return len(mastered(sheet))


def law_count(sheet: dict) -> int:
    """成了法則的系有幾個（衝合體要一個，L3）。"""
    return sum(v == APPLY_STAGE for v in held(sheet).values())


def dao(sheet: dict) -> str:
    """道階走到哪（realm.DAO_TIERS）。領域以上還沒做，最高算到法則。"""
    return APPLY_STAGE if law_count(sheet) else RESIDUE_STAGE if mastered(sheet) else "現象"


def study_problem(realm_lv: int, system: str) -> str:
    """參悟不了的原因（不擲骰）；空字串＝可以。"""
    if realm_lv < 1:
        return "凡人感應不到靈氣，參悟不出什麼"
    if not system:
        return "要說出參悟什麼（例如火焰、流水、雷霆）"
    if system in LOCKED and realm_lv < UNLOCK_LV:
        return LOCK_NOTE
    return ""


def pick(sheet: dict, text: str, here: dict[str, str]) -> tuple[str, str]:
    """這次參悟哪一條：回傳（現象, 參悟不了的原因）。"""
    insight, lv = sheet["insight"], sheet["realm_lv"]
    name, system = phenomenon_in(text), system_in(text)
    problem = study_problem(lv, system)
    if problem:
        return (name or (BY_SYSTEM[system][0] if system else "")), problem
    if name:
        if insight.get(name, -1) >= FULL:
            return name, f"已經悟透{name}，再參悟也無所增益"
        return name, "" if name in insight or present(name, here, lv) else f"還沒親眼見過{name}，無從參悟"
    open_ = [n for n in BY_SYSTEM[system] if insight.get(n, 0) < FULL and (n in insight or present(n, here, lv))]
    if not open_:
        done = any(n in insight for n in BY_SYSTEM[system])
        return "", f"{system}見過的現象都已悟透，眼前也沒有新的可看" if done else f"你還沒真正看過{system}的現象，無從參悟"
    return max(open_, key=lambda n: (present(n, here, lv), insight.get(n, 0))), ""


def boosts(sheet: dict, name: str, here: dict[str, str]) -> dict[str, float]:
    """參悟的契合 → 加成比例（相加）：靈根、主修功法（品階低於境界打折）、時節、秘境、道統、命途各 +50%，在場 +100%。"""
    system, found = PHENOMENA[name].system, {}
    if system in sheet["roots"]:
        found["靈根"] = BOOST
    if system in items.CATALOG[sheet["technique"]].affinity:
        found["主修功法"] = BOOST * technique_power(sheet)
    if system in SEASON_LAWS.get(here["季節"], ()):
        found["時節"] = BOOST
    if here["地點"] == "秘境":
        found["秘境"] = BOOST
    if system in PATH_LAWS.get(sheet.get("path", ""), ()):
        found["道統"] = BOOST
    if FATE_LAWS.get(sheet.get("hidden", "")) == system:
        found["命途"] = BOOST
    if present(name, here, sheet["realm_lv"]):
        found["在場"] = HERE_BOOST
    return found


def gain(sheet: dict, name: str, amount: int) -> tuple[dict, list[str]]:
    """加感悟（最多 100，沒見過的順便算見過）。回傳（新的感悟表, 悟透、階段變化的事實）。"""
    before = sheet["insight"].get(name, 0)
    insight = {**sheet["insight"], name: min(FULL, before + amount)}
    if insight[name] < FULL or before >= FULL:
        return insight, []
    system, events = PHENOMENA[name].system, [f"悟透{name}，得{name}殘理"]
    if _applies([n for n, v in insight.items() if v >= FULL], system) and not _applies(mastered(sheet), system):
        events.append(f"{system}殘理過半，化為{system}法則" if sheet["realm_lv"] >= APPLY_LV
                      else f"{system}殘理過半，待境界到了返虛才能化為法則")
    return insight, events


def reward(sheet: dict, target: str, amount: int) -> tuple[dict, list[str]]:
    """怪談、傳說、亡者、棋局給的感悟：target 是現象就給那條；是系就給那一系見過、離悟透最近的，都沒見過給第一條凡象或靈象。"""
    name = target if target in PHENOMENA else _nearest(sheet, system_of(target))
    if not name:
        return sheet["insight"], []
    insight, events = gain(sheet, name, amount)
    return insight, [f"對{name}的感悟加深", *events]


def _nearest(sheet: dict, system: str) -> str:
    if not system:
        return ""
    open_ = [n for n in BY_SYSTEM[system] if n in sheet["insight"] and sheet["insight"][n] < FULL]
    fresh = [n for n in BY_SYSTEM[system] if n not in sheet["insight"] and PHENOMENA[n].tier != HEAVEN]
    return max(open_, key=sheet["insight"].get) if open_ else fresh[0] if fresh else ""


def realm_up(sheet: dict) -> list[str]:
    """突破到返虛那一刻，殘理過半的系化為法則。"""
    if sheet["realm_lv"] != APPLY_LV:
        return []
    names = mastered(sheet)
    return [f"{s}殘理化為{s}法則" for s in SYSTEMS if _applies(names, s)]


def insight_target(sheet: dict) -> str:
    """頓悟給哪一條：主修功法親和的系（沒鎖的）裡離悟透最近的；沒有就給見過、沒悟透、進度最高的。"""
    for s in items.CATALOG[sheet["technique"]].affinity:
        if s not in LOCKED and (name := _nearest(sheet, s)):
            return name
    open_ = {n: v for n, v in sheet["insight"].items() if v < FULL and PHENOMENA[n].system not in LOCKED}
    return max(open_, key=open_.get, default="")


def action_bonus(sheet: dict, nature: str, text: str) -> tuple[int, str]:
    """行動字面用到持有的那一系：回傳（成功率加成, 那一系）。生、死兩系不給。"""
    if nature not in BONUS_NATURES:
        return 0, ""
    mine = held(sheet)
    used = [(BONUS[mine[s]], s) for _, _, s in _matches(text or "") if s in mine and s not in NO_BONUS]
    return max(used, default=(0, ""))


# ── 功法 ─────────────────────────────────────────────────────────────────
def technique_power(sheet: dict) -> float:
    """主修功法的效力（品階低於境界打折）。《吐納法》沒有親和、也沒有加成。"""
    book = items.CATALOG[sheet["technique"]]
    return items.strength(book.tier, sheet["realm_lv"]) if book.affinity else 0.0


def taught(technique: str) -> list[str]:
    """修這本功法就見過的現象（新系改接對照 Q6 乙）：親和每系第一條凡象；《吐納法》是靈地草盛。"""
    affinity = items.CATALOG[technique].affinity
    return [BY_SYSTEM[s][0] for s in affinity] if affinity else ["靈地草盛"]


def learn(sheet: dict, technique: str) -> dict:
    """主修這本：書上的現象記成見過（已經有的不動）。回傳新的感悟表。"""
    return {**{n: 0 for n in taught(technique)}, **sheet["insight"]}


# ── 角色卡、畫面、說書人 ────────────────────────────────────────────────
def valid(sheet: dict) -> bool:
    insight, book = sheet["insight"], items.CATALOG.get(sheet["technique"])
    return (isinstance(insight, dict)
            and all(n in PHENOMENA and isinstance(v, int) and not isinstance(v, bool) and 0 <= v <= FULL
                    for n, v in insight.items())
            and book is not None and book.kind == items.TECHNIQUE
            and (book.name == items.BASIC_TECHNIQUE or items.count(sheet, book.name, book.tier) > 0)
            and isinstance(sheet["laws_warned"], bool))


def panel(sheet: dict) -> list[dict]:
    """圖鑑（P4 乙）：見過的系列出全部條數，沒見過的寫「？？？」。"""
    insight = sheet["insight"]
    return [{"system": s, "stage": stage(sheet, s) or "參悟中", "locked": s in LOCKED,
             "items": [{"name": n, "tier": PHENOMENA[n].tier, "text": PHENOMENA[n].text, "insight": insight[n]}
                       if n in insight else {"name": "？？？", "tier": PHENOMENA[n].tier, "text": "", "insight": None}
                       for n in BY_SYSTEM[s]]}
            for s in SYSTEMS if any(n in insight for n in BY_SYSTEM[s])]


def prompt_text(sheet: dict) -> str:
    """給說書人：「主修《烈陽訣》（火系、光系）；火系殘理：薪盡火傳（讓火沿著東西走……，可借用這一條之力）；參悟中：爐火純青 40／100」。"""
    if sheet["realm_lv"] < 1:
        return ""
    book = items.CATALOG[sheet["technique"]]
    parts = [f"主修《{book.name}》" + (f"（{'、'.join(book.affinity)}）" if book.affinity else "")]
    for s, st in held(sheet).items():
        done = "、".join(f"{n}（{PHENOMENA[n].power}）" for n in mastered(sheet) if PHENOMENA[n].system == s)
        parts.append(f"{s}{st}：{done}，{PERMISSION[st]}")
    studying = [f"{n} {v}／{FULL}" for n, v in sheet["insight"].items() if v < FULL]
    if studying:
        parts.append("參悟中（尚未悟透，不能寫成法則之力）：" + "、".join(studying))
    if len(parts) == 1:
        parts.append("尚未悟透任何現象，不能寫成法則之力")
    return "；".join(parts)


def npc_law(name: str, realm_lv: int, path: str = "") -> str:
    """NPC 的法則：Lv3「薪盡火傳殘理」、Lv4 起「火系法則」。有道統就從道統帶的系挑（新系改接對照 Q5 乙），
    沒有就從沒鎖的系挑；系別由名字固定算出，同一個人永遠是同一系。"""
    if realm_lv < 3:
        return ""
    pool = PATH_LAWS.get(path) or OPEN_SYSTEMS
    system = pool[zlib.crc32(name.encode("utf-8")) % len(pool)]
    return f"{system}{APPLY_STAGE}" if realm_lv >= APPLY_LV else f"{BY_SYSTEM[system][0]}{RESIDUE_STAGE}"
