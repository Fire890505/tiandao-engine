"""回音（WHITEPAPER 16v 第 95、99 題，第 2-2 批）：結局留下的事，隔一段時間找上主角。純函式。

- 排隊，一次一件，隔 GAP 回合（節奏用回合）；這回合有別的事就等。
- 等那個人（第 117-2 題）：放 STALE（世界時間）沒來、或那個人不在人世，就收掉，寫一行「後來才聽說」；
  一回合收兩件以上合成「這段時間：……」，最多 LATER 件。債上門有期限（due），不過期。
- 有名有姓的人來（第三批第 1 步）：{人}換成他的名字，人不在了寫「有人」。
角色卡欄位：echoes（{text, who, place, since, until, side}）、echo_turn（上一件回來的回合）。side：支線開口帶的請託。
"""
from __future__ import annotations

from . import pending, schedule
from .clock import SHICHEN_PER_DAY

GAP, STALE, LATER = 5, 15 * SHICHEN_PER_DAY, 3   # 第 2-2 批第 1、3 題
NOBODY = "有人"


def fields() -> dict:
    return {"echoes": [], "echo_turn": 0}


def _new(text: str, who: str, place: str, since: int, now: int, side: dict | None = None, due: int | None = None) -> dict:
    return {"text": text, "who": who, "place": place, "since": since, "until": None if due is not None else now + STALE, "side": side,
            **({"due": due} if due is not None else {})}


def add(sheet: dict, lines: list[tuple[str, str]], place: str, turn_no: int, now: int, due: int | None = None) -> dict:
    """due：有期限的（上門討債：那筆債到期的時間），排程排在前面，不過期。"""
    return {**sheet, "echoes": [*sheet["echoes"], *(_new(t, who, place, turn_no, now, due=due) for t, who in lines)]}


def offer(e: dict | None) -> schedule.Ask | None:
    """候選（第 2-1a 批）：該回來的那一件。落實不改角色卡，回來的由 turn 拿掉。"""
    if not e:
        return None
    kind = schedule.DEBT if "due" in e else schedule.ASK if e["side"] else schedule.ECHO
    return schedule.Ask(kind, pending.PERSON, e["since"], lambda sheet: sheet, e.get("due"))


def ask(sheet: dict, offer: dict, place: str, turn_no: int, now: int) -> dict:
    """支線開口（domain/side.py）：同一條隊，只看上一件隔多久。offer["how"]：怎麼開口（命數找上你，沒寫就是「開口」）。"""
    return {**sheet, "echoes": [*sheet["echoes"], _new(f"{{人}}{offer.get('how', '開口')}：{offer['words']}", offer["who"], place, turn_no - GAP, now, offer)]}


def due(sheet: dict, turn_no: int, room: bool = True, gone: frozenset = frozenset()) -> dict | None:
    """這回合該回來的那一件。room：手上支線還有位子，不然開口的先等。gone：不在人世的人，他的不會回來。"""
    return next((e for e in sheet["echoes"] if (room or not e["side"]) and e["who"] not in gone
                 and turn_no - max(e["since"], sheet["echo_turn"]) >= GAP), None)


def line(e: dict, who: str = NOBODY) -> str:
    return e["text"].replace("{人}", who)


def turn(sheet: dict, came: dict | None, turn_no: int, now: int, gone: frozenset = frozenset()) -> tuple[dict, list[dict]]:
    """回來的拿掉；等不到的（過期、人不在了）也拿掉。回傳（角色卡, 等不到的）。"""
    stale = [e for e in sheet["echoes"] if e != came and (e["until"] is not None and now >= e["until"] or e["who"] in gone)]
    left = [e for e in sheet["echoes"] if e != came and e not in stale]
    return {**sheet, "echoes": left, "echo_turn": turn_no if came else sheet["echo_turn"]}, stale


def later(stale: list[dict], gone: frozenset = frozenset()) -> list[str]:
    """等不到的寫一行（第 2-2 批第 2、3 題）；開口請託的人不在了就算了。"""
    told = [f"{e['who'] or NOBODY}有事想託你（{e['side']['words']}）" if e["side"] else line(e, e["who"] or NOBODY)
            for e in sorted(stale, key=lambda e: e["since"]) if not (e["side"] and e["who"] in gone)][:LATER]
    return [] if not told else [f"後來才聽說：{told[0]}"] if len(told) == 1 else [f"這段時間：{'；'.join(told)}"]


def valid(sheet: dict) -> bool:
    return isinstance(sheet["echo_turn"], int) and isinstance(sheet["echoes"], list) and all(
        isinstance(e, dict) and all(isinstance(e.get(k), str) for k in ("text", "who", "place")) and isinstance(e.get("since"), int)
        and "until" in e and (e["until"] is None or isinstance(e["until"], int))
        and (e.get("side") is None or isinstance(e["side"], dict)) and isinstance(e.get("due", 0), int) for e in sheet["echoes"])
