"""名字庫（WHITEPAPER 12.6、第 16b 步；清單見 progress/WORLD_SKELETON.md 第 C 節）。

小模型不太會在敘事裡取名，Python 先備好名字。分**凡俗、修行兩種語感**：
凡人用樸素的名字（王二、阿桃、李大娘），修士與宗門用文雅的名字（沈照夜、青冥劍宗）。
三族的人名和機構叫法在 rules/content/peoples/（16u）：人族姓加名、獸族氏加名、魔族前字加後字。
"""
from __future__ import annotations

import random
from pathlib import Path

from ..config import PROJECT_ROOT


def read_table(path: Path) -> dict:
    """一族的表：「欄位｜a、b」一行一欄；「欄位｜鍵｜a、b」是分鍵的（獸族各支系的氏）。"""
    table: dict = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        if line.strip() and not line.startswith("#"):
            field, *rest = line.split("｜")
            values = tuple(rest[-1].split("、"))
            if len(rest) == 2:
                table.setdefault(field, {})[rest[0]] = values
            else:
                table[field] = values
    return table


PEOPLES = {p.stem: read_table(p) for p in (PROJECT_ROOT / "rules" / "content" / "peoples").glob("*.txt")}
HUMAN = "人族"
SURNAMES, MORTAL_SURNAMES = PEOPLES[HUMAN]["修行姓"], PEOPLES[HUMAN]["凡俗姓"]
SEXES = ("男", "女")
DOUBLE_SHARE = 0.7          # 七成「姓＋雙字名」，三成「姓＋單字名」
TITLE_SHARE = 0.3           # 魔族的修士多少帶稱號（暫定）
CLAN_SHARE = 0.7            # 姓氏村（王家村）的凡人七成同姓（暫定）

# ── 地名（字首＋字尾）────────────────────────────────────────────────────
VILLAGE_PREFIXES = ("槐樹", "柳樹", "石橋", "黃泥", "清水", "白楊", "大溪", "雙井", "老鴉", "磨坊", "桃花", "杏花")
VILLAGE_SUFFIXES = ("村", "莊", "屯", "溝", "坡", "灣", "鄉")   # 鄉、鎮、區、縣、市古今共用（第 8-3 批，換時代不用改名）
CLAN_VILLAGE_SHARE = 0.4    # 村落有四成是姓氏村（凡俗姓＋家＋字尾），暫定
TOWN_PREFIXES = ("鐵槐", "金沙", "玉泉", "煙雨", "望鄉", "來風", "臨風", "問路", "折劍", "碧波", "青石", "寒水")
TOWN_SUFFIXES = ("鎮", "集", "鄉", "區")
WILD_PREFIXES = ("黑松", "野狼", "斷崖", "霧隱", "亂石", "枯藤", "鷹愁", "老林", "荒草", "血月", "白骨", "幽松")
WILD_SUFFIXES = ("林", "嶺", "坡", "谷", "澗", "崗")
# 給說書人的地名字首（WHITEPAPER 12.6：AI 自己接上種類）
PLACE_PREFIXES = VILLAGE_PREFIXES + TOWN_PREFIXES + WILD_PREFIXES

# ── 宗門、仙宗、武館、凡人勢力 ──────────────────────────────────────────
SECT_PREFIXES = ("青冥", "問劍", "玄霄", "太微", "紫陽", "歸元", "流雲", "天衍", "凌霄", "清虛", "碧落", "長生", "無量",
                 "觀星", "聽潮")
SECT_PATHS = {   # 路子（＝道統，16h）→ (宗門字尾, 分支字尾)
    "劍修": (("劍宗", "劍門", "劍閣"), ("武館", "劍館")),
    "丹道": (("丹宗", "藥谷", "丹鼎派"), ("丹堂",)),
    "符籙": (("符宗", "籙門", "符堂"), ("符館",)),
    "佛門": (("寺", "禪院"), ("分寺", "下院")),
    "道觀": (("觀", "宮"), ("下院",)),
    "體修": (("門", "堂"), ("武館",)),
    "魔門": (("魔宗", "血煞門", "魔殿"), ("分舵",)),
    "鬼修": (("鬼宗", "冥府", "幽冥殿"), ("分壇",)),
}
SECT_COMMON = ("宗", "門", "派", "閣")   # 名字不綁死路子：通用字尾也能挑（16h）
NATION_PREFIXES = ("大周", "大梁", "南楚", "北燕", "西涼", "東吳", "大晉", "大夏")
IMMORTAL_PREFIXES = ("太初", "玄元", "紫極", "九霄", "鴻蒙", "太乙", "元始", "天樞", "昊天", "玉清")
IMMORTAL_SUFFIXES = ("仙宗", "天宗", "道宗")
# 天下骨架（16k；WORLD_MATERIALS 4.1）：州名＝字首＋州（魔族域、獸族境），主城＝同一個字首＋城市字尾；他族的村落、荒野
STATE_PREFIXES = {
    "人族": ("天樞", "龍脊", "鳳鳴", "雷澤", "問劍", "觀星", "臨淵", "聽雪", "破霧", "長生", "太虛", "玄天", "九霄", "聽潮",
           "鐵槐", "金沙", "玉泉", "煙雨", "望鄉", "臨風", "搖光", "碧波", "霜刀", "折劍"),
    "魔族": ("煉獄", "冥都", "血河", "魔淵", "噬天", "屍山", "鬼王", "滅世", "焚天", "邪君", "孽龍", "幽冥"),
    "獸族": ("靈獸", "百獸", "群靈", "虎嘯", "鳳棲", "鹿鳴", "竹海", "獸皇", "野境", "溪山", "林野", "雲嶺"),
}
STATE_SUFFIX = {"人族": "州", "魔族": "域", "獸族": "境"}
CITY_SUFFIXES = {"人族": ("城", "府", "郡", "市", "縣"), "魔族": ("城", "都", "壘"), "獸族": ("苑", "嶺", "谷")}
NATION_NAMES = {"人族": (NATION_PREFIXES, ("國",)),
                "魔族": (("九幽", "血海", "孽土", "焚魔", "邪皇", "黑淵", "冥土", "幽魘"), ("域", "國", "界")),
                "獸族": (("萬獸", "龍脈", "鳳凰", "山靈", "雲海", "林境", "蒼莽", "青野"), ("境", "國", "域"))}
RACE_PLACES = {   # 他族的村落、荒野：字首, 字尾
    "魔族": (("血影", "屍骸", "鬼哭", "枯骨", "陰風", "噬魂", "焦土", "裂淵", "孽蛛", "毒霧", "腐林", "煞氣"),
           ("穴", "窟", "塚", "淵", "壑", "洞", "窩", "荒")),
    "獸族": (("青丘", "靈狐", "獸跡", "狼嚎", "虎蹤", "鹿野", "竹影", "松風", "野棲", "溪畔", "林深", "雲野"),
           ("窩", "穴", "林", "谷", "溪", "坡", "棲", "巢")),
}
GANG_PREFIXES, GANG_SUFFIXES =("鐵拳", "青龍", "黑虎", "漕運", "長河", "飛刀"), ("幫", "會", "堂")
TRADE_PREFIXES, TRADE_SUFFIXES = ("萬通", "四海", "聚寶", "通源", "恆昌"), ("商號", "行", "商會")
OFFICES = ("縣衙", "巡檢司")
PEOPLE_PER_TURN = 2
MAX_TRIES = 40


def family(rng: random.Random, race: str = HUMAN, line: str = "", refined: bool = False) -> str:
    """一個姓或氏：人族分凡俗、修行，獸族看支系，魔族沒有（空字串）。"""
    t = PEOPLES[race]
    if "氏" in t:
        return rng.choice(t["氏"].get(line) or sum(t["氏"].values(), ()))
    return rng.choice(t["修行姓" if refined else "凡俗姓"]) if "凡俗姓" in t else ""


def has_family(race: str) -> bool:
    return PEOPLES[race]["結構"][0] != "諱"


def surname_of(name: str, chosen: str = "", race: str = HUMAN) -> str:
    """主角的姓（16u 第 2 題）：玩家填的優先；沒填就從名字開頭認複姓和氏，認不出來取第一個字。
    魔族沒有姓；名字不是中文開頭也沒有（家人的名字要是中文，存檔才認得）。"""
    if not has_family(race):
        return ""
    long = (*PEOPLES[HUMAN]["複姓"], *sum(PEOPLES[race].get("氏", {}).values(), ()))
    first = name[0] if is_chinese(name[0]) else ""
    return chosen or next((s for s in long if name.startswith(s)), first)


def is_chinese(text: str) -> bool:
    return all("㐀" <= c <= "鿿" for c in text)


def given(rng: random.Random, race: str = HUMAN, gender: str = "", refined: bool = False) -> str:
    """一個不帶姓的名字。"""
    t, sex = PEOPLES[race], gender if gender in SEXES else rng.choice(SEXES)
    if f"前字{sex}" in t:
        return rng.choice(t[f"前字{sex}"]) + rng.choice(t[f"後字{sex}"])
    if refined and f"單字{sex}名" in t and rng.random() >= DOUBLE_SHARE:
        return rng.choice(t[f"單字{sex}名"])
    return rng.choice(t[f"{'修行' if refined else '凡俗'}{sex}名"])


def person_names(rng: random.Random, taken: set[str], count: int = PEOPLE_PER_TURN, *, race: str = HUMAN,
                 gender: str = "", lineage: str = "") -> list[str]:
    """count 個沒人用過的修行人名（嘗試次數有上限：名字庫用完時給少一點）。"""
    found: list[str] = []
    titles = PEOPLES[race].get("稱號", ())
    for _ in range(count * 20):
        name = family(rng, race, lineage, refined=True) + given(rng, race, gender, refined=True)
        name += rng.choice(titles) if titles and rng.random() < TITLE_SHARE else ""
        if name not in taken and name not in found:
            found.append(name)
        if len(found) == count:
            break
    return found


def renamed(rng: random.Random, name: str, taken: set[str], race: str = HUMAN, gender: str = "") -> str:
    """撞名換名（Claude 主導第九節 5c）：留姓、換名；換不到回傳空字串。"""
    surname = surname_of(name, race=race)
    return next((n for n in (surname + given(rng, race, gender) for _ in range(MAX_TRIES)) if n not in taken and n != name), "")


def mortal_name(rng: random.Random, taken: set[str], *, young: bool, old: bool, clan: str = "", race: str = HUMAN,
                gender: str = "", lineage: str = "", plain: bool = False, shun: frozenset[str] = frozenset()) -> str:
    """一個沒人用過的凡人名字；用完了回傳空字串。young：孩童、少年多用小名；old：壯年、老年多用稱呼。
    clan：姓氏村的姓（七成用它）。魔族沒有姓，也就沒有稱呼和排行。plain：有身分的人，只用姓加名。
    shun：不用的名（不含姓），同一條路線的人名字不撞。"""
    t, sex = PEOPLES[race], gender if gender in SEXES else rng.choice(SEXES)
    for _ in range(MAX_TRIES):
        surname = clan if clan and rng.random() < CLAN_SHARE else family(rng, race, lineage)
        style = 1 if plain else rng.random()
        if young and style < 0.5:
            name = rng.choice(t[f"小名{sex}"])
        elif old and style < 0.5 and surname:
            name = surname + rng.choice(t[f"稱呼{sex}"])
        elif style < 0.75 and "排行" in t:
            name = surname + rng.choice(t["排行"])
        else:
            name = surname + given(rng, race, sex)
        if name not in taken and name[len(surname):] not in shun:
            return name
    return ""


def words(race: str) -> dict[str, str]:
    """這一族對事端裡的人怎麼稱呼（官差、村長……）：事端模板寫 {官差}，放進世界時換成這裡的（16u 第 7 題）。"""
    return dict(pair.split("=") for pair in PEOPLES[race]["叫法"])


def label(place_type: str, race: str) -> str:
    """這一族怎麼叫這種地方（給說書人）：獸族的客棧是歇腳棚。規則上的類型不變。"""
    return PEOPLES[race].get(place_type, (place_type,))[0].lstrip("氏家")


def clan_of(place: str, place_type: str) -> str:
    """人族村落的主要姓：「王家村」→「王」，AI 登錄的「趙家莊」也算；其他村落照村名擲。不是村落回傳空字串。"""
    if place_type != "村落":
        return ""
    named = len(place) >= 3 and place[1] == "家" and place[0] in MORTAL_SURNAMES
    return place[0] if named else random.Random(place).choice(MORTAL_SURNAMES)


def main_line(place: str, race: str) -> str:
    """聚落的主要支系（16u 第 6 題）：地名字首對得上就是那一支，對不上照地名擲。人族不分，空字串。"""
    table = PEOPLES[race].get("地方", {})
    return next((line for line, prefixes in table.items() if place.startswith(prefixes)),
                random.Random(place).choice(sorted(table)) if table else "")


def local_clan(place: str, place_type: str, race: str, line: str) -> str:
    """這個人如果是當地大姓的一員，他的姓或氏：人族看村落；獸族要支系對得上地名（靈狐穴的狐族姓靈狐）。"""
    if race == HUMAN:
        return clan_of(place, place_type)
    return next((c for c in PEOPLES[race].get("氏", {}).get(line, ()) if place.startswith(c)), "")


def place_prefix(rng: random.Random, places: list[str], race: str = HUMAN) -> str:
    """一個還沒有地點用過的字首；都用過了給空字串。他族用他族的地名字首。"""
    pool = RACE_PLACES[race][0] if race in RACE_PLACES else PLACE_PREFIXES
    unused = [p for p in pool if not any(name.startswith(p) for name in places)]
    return rng.choice(unused) if unused else ""


def pick_unused(rng: random.Random, prefixes, suffixes, taken: set[str], avoid=frozenset()) -> str:
    """字首＋字尾，避開用過的名字（也避開用過的字首，同一區域不會有兩個「黑松」）；用完了回傳空字串。
    avoid：世界上已有的名字，只避開一模一樣的，字首還能用。"""
    options = [p for p in prefixes if not any(t.startswith(p) for t in taken)]
    rng.shuffle(options)
    for prefix in options:
        name = prefix + rng.choice(suffixes)
        if name not in taken and name not in avoid:
            return name
    return ""


def village_name(rng: random.Random, taken: set[str]) -> str:
    if rng.random() < CLAN_VILLAGE_SHARE:
        clans = [s + "家" for s in MORTAL_SURNAMES]
        name = pick_unused(rng, clans, VILLAGE_SUFFIXES, taken)
        if name:
            return name
    return pick_unused(rng, VILLAGE_PREFIXES, VILLAGE_SUFFIXES, taken)


def mortal_faction_name(rng: random.Random, kind: str, town: str, taken: set[str], race: str = HUMAN) -> str:
    """城鎮裡的凡人勢力：家族＝姓＋家（獸族氏＋氏；魔族沒有家族，算幫派）、幫派、商會、朝廷＝城鎮名＋縣衙或巡檢司。"""
    clans = PEOPLES[race].get("氏")
    if kind == "家族" and clans:
        return pick_unused(rng, sum(clans.values(), ()), ("氏",), taken)
    if kind == "家族" and race == HUMAN:
        return pick_unused(rng, MORTAL_SURNAMES, ("家",), taken)
    if kind == "家族":
        kind = "幫派"
    if kind == "幫派":
        return pick_unused(rng, GANG_PREFIXES, GANG_SUFFIXES, taken)
    if kind == "商會":
        return pick_unused(rng, TRADE_PREFIXES, TRADE_SUFFIXES, taken)
    return town + rng.choice(OFFICES)
