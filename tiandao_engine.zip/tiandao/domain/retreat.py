"""閉關／休養時長解析。純函式。

參考舊專案 time_system.py 的 parse_retreat_years／_cn_number_to_int，但刻意不同：
- 時長必須緊跟在動詞後面（「閉關三年」「閉關修煉三日」「休息三天」），
  「打坐，回想三年前的事」不會被當成閉關三年。舊版只要字串裡有「閉關N年」就算。
- 支援年、月、日、時辰與「半」（半年、一年半），舊版只認「年」。
- 有上限（MAX_RETREAT_YEARS），而且全部是 O(1) 計算，沒有任何依年數跑的迴圈（稽核 B-06：
  舊版閉關十萬年會讓子嗣迴圈跑出 5,024 名子嗣、季節迴圈跑上百萬次）。
- 「閉關」沒寫時長時視為一個月（沿用舊版 RETREAT_SHORT），其餘動詞沒寫時長就不解析，
  由 effects.TIME_COST 的預設值決定。
- 做工（第 8 步）比照閉關：可以寫時長，只寫「做工」也算一個月。
"""
from __future__ import annotations

import re
from dataclasses import dataclass

from .clock import DAYS_PER_MONTH, MONTHS_PER_YEAR, SHICHEN_PER_DAY

SHICHEN_PER_MONTH = SHICHEN_PER_DAY * DAYS_PER_MONTH
SHICHEN_PER_YEAR = SHICHEN_PER_MONTH * MONTHS_PER_YEAR
MAX_RETREAT_YEARS = 1000          # 壽元系統（第 3 步）上線前的保守上限
MAX_RETREAT_SHICHEN = MAX_RETREAT_YEARS * SHICHEN_PER_YEAR
DEFAULT_SECLUSION_SHICHEN = SHICHEN_PER_MONTH   # 只寫「閉關」或「做工」沒寫多久

WORK_VERBS = ("做工", "打工", "幹活", "幫工", "當雜役", "跑堂", "上班", "上工", "搬貨", "賺錢", "賺點錢", "找工作", "當學徒",
              "採藥", "打獵", "走鏢")   # 做工與營生（16o、打字第 8 題）的關鍵字（judgment 也用這一份）
STUDY_VERBS = ("參悟", "感悟", "領悟", "悟道", "體悟")            # 參悟（第 3b-1 步；judgment 也用這一份）
_VERBS = "閉關|修煉|修行|苦修|靜修|打坐|吐納|休息|休養|靜養|療傷|調息|養傷|" + "|".join(WORK_VERBS)
_NUM = r"[0-9０-９]+|[零〇一二兩三四五六七八九十百千萬數幾]+"
_UNIT = "年|個月|月|日|天|個時辰|時辰"
# 動詞（可再接一個動詞，例如「閉關修煉」）＋可選的「了」＋時長
_DURATION_RE = re.compile(
    rf"(?:{_VERBS})(?:{_VERBS})?了?(?P<num>{_NUM})(?P<unit>{_UNIT})(?P<half>半)?"
    rf"|(?:{_VERBS})(?:{_VERBS})?了?(?P<half_only>半)(?P<half_unit>年|個月|月|日|天)"
)
# 參悟的時長可以隔著參悟的對象（「參悟雷霆三年」），對象最多 6 個字、不能跨標點
_STUDY_RE = re.compile(rf"(?:{'|'.join(STUDY_VERBS)})[^，。、,.!?！？]{{0,6}}?了?"
                       rf"(?:(?P<num>{_NUM})(?P<unit>{_UNIT})(?P<half>半)?|(?P<half_only>半)(?P<half_unit>年|個月|月|日|天))")
_UNIT_SHICHEN = {"年": SHICHEN_PER_YEAR, "個月": SHICHEN_PER_MONTH, "月": SHICHEN_PER_MONTH,
                 "日": SHICHEN_PER_DAY, "天": SHICHEN_PER_DAY, "個時辰": 1, "時辰": 1}
_DIGITS = {"零": 0, "〇": 0, "一": 1, "二": 2, "兩": 2, "三": 3, "四": 4, "五": 5, "六": 6, "七": 7, "八": 8, "九": 9}
_SMALL_UNITS = {"十": 10, "百": 100, "千": 1000}
VAGUE_COUNT = 3                   # 「數年」「幾個月」


@dataclass(frozen=True)
class Duration:
    shichen: int
    phrase: str      # 從玩家輸入中比對到的原文，例如「閉關修煉三年」
    capped: bool     # 超過上限，已以上限計


def parse(player_input: str) -> Duration | None:
    """從玩家輸入找出明確的閉關／休養時長。找不到回傳 None。"""
    text = re.sub(r"\s+", "", player_input or "")
    m = _DURATION_RE.search(text) or _STUDY_RE.search(text)
    if m:
        shichen = _shichen_of(m)
        if shichen > 0:
            return Duration(min(shichen, MAX_RETREAT_SHICHEN), m.group(0), shichen > MAX_RETREAT_SHICHEN)
    for word in ("閉關", *WORK_VERBS):
        if word in text:
            return Duration(DEFAULT_SECLUSION_SHICHEN, word, False)
    return None


def _shichen_of(m: re.Match) -> int:
    if m.group("half_only"):
        return _UNIT_SHICHEN[m.group("half_unit")] // 2
    unit = _UNIT_SHICHEN[m.group("unit")]
    return to_int(m.group("num")) * unit + (unit // 2 if m.group("half") else 0)


def to_int(text: str) -> int:
    """阿拉伯或中文數字轉整數（含萬、十百千位權）。「數」「幾」視為 VAGUE_COUNT。

    極大的數字會原樣算出（Python 整數不溢位），由 parse() 夾到上限。
    """
    text = text.translate(str.maketrans("０１２３４５６７８９", "0123456789"))
    if text.isdigit():
        return int(text)
    if text in ("數", "幾"):
        return VAGUE_COUNT
    if "萬" in text:
        high, _, low = text.partition("萬")
        return (_below_wan(high) if high else 1) * 10000 + (_below_wan(low) if low else 0)
    return _below_wan(text)


def _below_wan(text: str) -> int:
    total, current = 0, 0
    for ch in text:
        if ch in _DIGITS:
            current = _DIGITS[ch]
        elif ch in _SMALL_UNITS:
            total += (current or 1) * _SMALL_UNITS[ch]   # 「十年」＝一十年
            current = 0
        elif ch in ("數", "幾"):
            current = VAGUE_COUNT                         # 「數十年」＝三十年
    return total + current
