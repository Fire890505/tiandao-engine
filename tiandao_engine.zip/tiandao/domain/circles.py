"""消息圈（第 85、120-4 題；第 9b 批，progress/消息圈草稿.md 9-10～9-14）。純函式。

- 一人一個主圈：照職業（JOBS），修士照修行身分都算修行；表上沒有的（小孩、以後新增的職業）照所在地（PLACES）。
- 傳聞種類歸哪個圈、各圈傳得多快在 rumors.CIRCLE、rumors.arrival；大事（大小＝大）人人都講，小、中只有同圈的人講（9-12）。
- 公開消息同圈的照講，只有敵視你的不講也不指路（9-14）。
"""
from __future__ import annotations

from . import profile, rumors

HILL, MARKET, ROAD, OFFICE, CULT = rumors.CIRCLES
_TABLE = {HILL: "獵戶 牧人 農戶 守祠人", MARKET: "掌櫃 小販 帳房 織工 木匠 店小二 廚子 朝奉 夥計 大夫 藥童 鐵匠 學徒 管事",
          ROAD: "腳夫 鏢師 趟子手 賣藝人", OFFICE: "衙役 書吏", CULT: " ".join({"雜役", *profile.GROUPS.values()})}
JOBS = {j: c for c, js in _TABLE.items() for j in js.split()}
PLACES = {"村落": HILL, "城鎮": MARKET, "坊市": MARKET, "客棧": MARKET, "衙署": OFFICE, "鏢局": ROAD, "宗門": CULT, "武館": CULT}
WHERE = {HILL: "村落", MARKET: "城鎮", ROAD: "鏢局", OFFICE: "衙署", CULT: "宗門"}   # 指路指不到人時，說去哪種地方
HOSTILE = -50   # 敵視（npc.AFFINITY_TIERS）


def of(job: str, place_type: str) -> str:
    return JOBS.get(job) or PLACES.get(place_type, HILL)


def tells(rumor: dict, circle: str) -> bool:
    """這個圈的人講不講這則傳聞。"""
    return rumor["size"] == rumors.BIG or rumors.CIRCLE.get(rumor["kind"], circle) == circle
