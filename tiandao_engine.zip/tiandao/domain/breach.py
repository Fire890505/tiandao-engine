"""破格期（16l 第 2 題）：踏入起倒數 300 年，天道漸進出手，時間到降下抹殺之劫。純函式。

規則（2026-10-14 與使用者一題一題定案，見 progress/WHITEPAPER.md 16l，數字暫定）：
- 角色卡 breach：None＝不在倒數；{"since": 踏入的時刻, "spared": 撐過了抹殺之劫（不再來）}。erased：被天道抹殺。
- 倒數內衝關＝破空（照一般突破規則；成功就拿掉 breach，接引與飛升在 16l B3）。
- 剩最後三成時間：每月注視 +LATE_GAZE（平時每月回落 1，淨升）；天道落子時小劫數權重 × CALAMITY_BOOST。
- 時間到（回合結束時跨過）：抹殺之劫——抗性、極難。撐過＝當場照一般規則衝一次破空（不看前提），抹殺不再來；
  撐不過＝死，結局「被天道抹殺」。勝負記進棋局。
- NPC 沒有存踏入的時刻：在破格期的人每年 1/YEARS 的機會被抹殺（期望值相同）。
"""
from __future__ import annotations

from .clock import SHICHEN_PER_MONTH, SHICHEN_PER_YEAR

YEARS = 300
LATE = 0.7
LATE_GAZE = 2
CALAMITY_BOOST = 3
SOURCE = "排斥"             # 天道注視的來源（heaven.watch）
ERASED = "被天道抹殺"        # 結局
NPC_YEARLY = 1 / YEARS
START_EVENT = f"踏入破格期：這方天地開始排斥你。{YEARS} 年內不破空，天道必來抹殺"


def fields() -> dict:
    return {"breach": None, "erased": False}


def start(sheet: dict, clock_now: int) -> dict:
    return {**sheet, "breach": {"since": clock_now, "spared": False}}


def deadline(sheet: dict) -> int | None:
    b = sheet["breach"]
    return None if not b or b["spared"] else b["since"] + YEARS * SHICHEN_PER_YEAR


def late(sheet: dict, clock_now: int) -> bool:
    end = deadline(sheet)
    return end is not None and clock_now >= end - round((1 - LATE) * YEARS * SHICHEN_PER_YEAR)


def marks(sheet: dict, start_: int, end: int) -> list[tuple[str, int]]:
    """這回合跨過的、在最後三成裡的月份：每月注視 +LATE_GAZE。"""
    if not late(sheet, end):
        return []
    from_ = max(start_, deadline(sheet) - round((1 - LATE) * YEARS * SHICHEN_PER_YEAR))
    months = end // SHICHEN_PER_MONTH - from_ // SHICHEN_PER_MONTH
    return [(SOURCE, months * LATE_GAZE)] if months > 0 else []


def due(sheet: dict, clock_now: int) -> bool:
    end = deadline(sheet)
    return end is not None and clock_now >= end and sheet["status"] == "ALIVE"


def text(sheet: dict, clock_now: int) -> str:
    """角色面板與說書人：破格期還剩多久。"""
    end = deadline(sheet)
    if end is None:
        return "破格期：撐過了抹殺之劫，天地仍在排斥" if sheet["breach"] else ""
    left = max(0, (end - clock_now) // SHICHEN_PER_YEAR)
    return f"破格期：天地排斥，再過約 {left} 年天道就會降下抹殺之劫" + ("（天威日重）" if late(sheet, clock_now) else "")


def valid(sheet: dict) -> bool:
    b = sheet["breach"]
    return isinstance(sheet["erased"], bool) and (b is None or (
        isinstance(b, dict) and set(b) == {"since", "spared"} and isinstance(b["since"], int)
        and not isinstance(b["since"], bool) and isinstance(b["spared"], bool)))
