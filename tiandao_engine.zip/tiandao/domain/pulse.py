"""世界脈動（第 10c-1 步）：定期推進需要互動的少數人。純函式，不碰資料庫，不呼叫 AI。

規則（2026-10-05 與使用者討論定案，見 progress/WHITEPAPER.md 第 14 節「10c-1 世界脈動的細節」，數字暫定）：
- 每跨一個曆月推進一次；長時間切成最多 evolution.MAX_SEGMENTS 段，每段的機率依跨過的月數算。
- 只處理有天道角色、待報血仇、有恩怨的人，最多 MAX_PEOPLE 個；其他人照舊凍結（第 10b 步的惰性演算）。
- 每種變化一個函式：挑人、恩怨、交手、天道角色、首領繼位、天道落子（只是呼叫點）、收徒、大事年表。
- 收徒（16i 第 12 題）：同勢力境界高兩級以上的收還沒有師父的為徒，每月一小機率，一次最多 MAX_TIES 條，記進大事年表。
  友人、仇家改由村鎮小事長（第 7-2a 批，domain/chatter.py）。交手輸的人對贏的人記動手（重）
  （被殺的人親近的人照原本的連鎖復仇：反應過來後目標改成復仇，不另加羈絆）。
"""
from __future__ import annotations

import random
from dataclasses import dataclass, field

from . import evolution, memory, npc, opinion, realm, rumors, society, stage
from .clock import SHICHEN_PER_YEAR
from .evolution import AWAY, months

MAX_PEOPLE = 20
SAME_PLACE_FIGHTS, APART_FIGHTS = 0.3, 0.1     # 有恩怨的兩人每年交手的機率：同處一地／不同地（一方找上門）
MAX_FIGHT_CHANCE = 0.9
WIN_BASE, WIN_PER_LEVEL, WIN_RANGE = 0.5, 0.15, (0.1, 0.9)
DEATH_SHARE = 0.3                               # 輸的一方喪命的機率（其餘重傷）；善念高的贏家不下殺手
NEAR_ROLES = ("宿敵", "貴人")                    # 會移到主角附近的天道角色
CHRONICLE_SPAN = SHICHEN_PER_YEAR               # 一次跨過這麼久，才整理大事年表
HEADLINES = 3
DIED, WOUNDED, SUCCEEDED, ROSE, BONDED = 3, 2, 2, 1, 1   # 大事的份量（挑年表用）
TIE_RATE, MAX_TIES, MASTER_GAP = 0.02, 3, 2   # 收徒：每月機率、一次最多幾條、境界差（暫定）
HOSTILE = opinion.hit(opinion.FEUD, opinion.LIKE, opinion.GRAVE, -1)       # 結怨 -60（事端配到新人的仇家，plot.TIE_HITS）


@dataclass
class Event:
    """一件大事。place：交手的地點（其他事是空字串）。rumor：這件事傳開的傳聞（第 10c-3a 步）。"""
    weight: int
    when: int
    text: str
    place: str = ""
    rumor: dict | None = None


@dataclass
class Result:
    npcs: dict[str, dict] = field(default_factory=dict)       # 處理過的人（演算後）
    notes: list[dict] = field(default_factory=list)
    bonds: list[dict] = field(default_factory=list)           # 新的羈絆（繼位、收徒）
    reasons: list[dict] = field(default_factory=list)         # NPC 之間的原因（交好、結怨、交手；第 1-3 批）
    events: list[Event] = field(default_factory=list)
    dead: set[str] = field(default_factory=set)
    visits: list[tuple[str, str, bool]] = field(default_factory=list)   # 特殊命 NPC 的章找上你：（他, 宮, 人到了你那），第 122c 批
    owed: list[tuple[str, str]] = field(default_factory=list)     # 以你為命主的章收了：（他, 結局）


# ── 挑人 ─────────────────────────────────────────────────────────────────
def feuds(npcs: dict[str, dict], bonds: list[dict]) -> set[tuple[str, str]]:
    """有恩怨的兩人（使用者 2026-10-05 決定 A）：仇家羈絆、一方的復仇目標是另一方、所屬勢力互相敵對。都還活著才算。"""
    pairs = {(b["a"], b["b"]) for b in bonds if b["type"] == "仇家" and b["a_kind"] == b["b_kind"] == society.NPC}
    pairs |= {(p["name"], p["goal_target"]) for p in npcs.values() if p["goal"] == "復仇"}
    members: dict[str, set[str]] = {}
    for b in bonds:
        if b["type"] in society.MEMBER_BONDS:
            members.setdefault(b["b"], set()).add(b["a"])
    for b in bonds:
        if b["type"] == "敵對":
            pairs |= {(x, y) for x in members.get(b["a"], ()) for y in members.get(b["b"], ())}
    alive = {name for name, p in npcs.items() if p["status"] == "ALIVE"}
    return {tuple(sorted(pair)) for pair in pairs if pair[0] != pair[1] and set(pair) <= alive}


def bereaved(p: dict, bonds: list[dict], notes: list[dict]) -> bool:
    """親近的人被人所殺，而他還沒演算到那之後（還沒反應過來，見 evolution.change_goal）。"""
    since = p["evolved_shichen"]
    dear = evolution.close_ones(p["name"], bonds)
    return since is not None and any(n["kind"] == memory.DEATH and n.get("actor") and n["subject"] in dear
                                     and n["clock_shichen"] >= since for n in notes)


def choose(npcs: list[dict], bonds: list[dict], notes: list[dict], skip: set[str]) -> list[str]:
    """這次要處理的人，最多 MAX_PEOPLE 個：天道角色 → 待報血仇 → 有恩怨 → 在遠方的人（第 10c-2b 步，名額有剩才輪到，
    先離開的先處理）；同級依登場順序。"""
    in_feud = {name for pair in feuds({p["name"]: p for p in npcs}, bonds) for name in pair}
    killings = [n for n in notes if n["kind"] == memory.DEATH and n.get("actor")]   # 只看被殺的，不必每人掃全部記事

    def rank(p: dict) -> int | None:
        if p["heaven_role"]:
            return 0
        if bereaved(p, bonds, killings):
            return 1
        if p["name"] in in_feud:
            return 2
        return 3 if p["location"] == AWAY else None

    ranked = [(rank(p), p.get("away_since") or 0, i, p["name"]) for i, p in enumerate(npcs)
              if p["status"] == "ALIVE" and p["name"] not in skip]
    return [x[-1] for x in sorted(x for x in ranked if x[0] is not None)][:MAX_PEOPLE]


# ── 推進 ─────────────────────────────────────────────────────────────────
def advance(world: evolution.World, *, seed: str, start: int, end: int, chosen: list[str], relations: dict[str, dict],
            player_lv: int, near: list[str], turn_no: int) -> Result:
    """把 chosen 這些人從 start 推進到 end。world 會被改動（npcs、notes、bonds、gone 換成推進後的）。"""
    result = Result()
    relations = dict(relations)
    rng = random.Random(f"{seed}:pulse:{start}:{end}")
    n = min(evolution.MAX_SEGMENTS, months(end) - months(start))
    for i in range(n):
        a, b = start + (end - start) * i // n, start + (end - start) * (i + 1) // n
        for name in chosen:
            evolve_one(result, world, name, b, seed, relations, turn_no)
        for name in chosen:
            heaven_role(result, world, rng, name, b, player_lv, near, turn_no)
        tiandao_moves(world)
        for x, y in sorted(feuds(world.npcs, world.bonds)):
            if x in chosen and y in chosen:
                maybe_fight(result, world, rng, x, y, a, b, turn_no)
    result.npcs = {name: world.npcs[name] for name in chosen}
    succeed(result, world, end, turn_no)
    ties(result, world, random.Random(f"{seed}:ties:{start}:{end}"), months(end) - months(start), end, turn_no)
    return result


def evolve_one(result: Result, world: evolution.World, name: str, end: int, seed: str, relations: dict[str, dict],
             turn_no: int) -> None:
    """先用第 10b 步的個別演算把他推到這一段的結尾（成長、老死、移動、目標轉換……結果一致）。"""
    p = world.npcs[name]
    start = p["evolved_shichen"]
    out = evolution.evolve(p, rng=random.Random(f"{seed}:evolve:{name}:{start}"), start=start, end=end,
                           world=world, relation=relations.get(name), turn_no=turn_no)
    world.npcs[name] = out.npc
    _record(result, world, out.notes)
    if out.died_at is not None:
        _died(result, world, name)
    result.events += outcome_events(out, end)
    result.visits += [(name, *v) for v in out.visits]
    result.owed += [(name, e) for e in out.owed]


def outcome_events(out: evolution.Outcome, end: int) -> list[Event]:
    """個別演算的結果裡算得上大事的：老死、突破。也是傳聞的來源（第 10c-3a 步；10b 的補算也用）。"""
    p, name = out.npc, out.npc["name"]
    events = [Event(ROSE, end, f"{name}突破至{stage}", rumor=rise_rumor(p, p["realm_lv"] - len(out.stages) + 1 + i, end))
              for i, stage in enumerate(out.stages)]
    events += [Event(ROSE, when, f"{name}命裡的事：{text}", rumor=rumors.make(rumors.FATED, p["location"], place=p["location"], when=when,
                                                                         detail=text[:40], subject_lv=p["realm_lv"]))
               for when, text in out.fated]   # 特殊命 NPC 的章收場（第 122b 批）
    if out.died_at is not None:
        events.append(Event(DIED, out.died_at, name + out.notes[-1]["text"], rumor=rumors.make(
            rumors.OLD_AGE, name, place=p["location"], when=out.died_at, lv=p["realm_lv"], subject_lv=p["realm_lv"])))
    return events


def rise_rumor(p: dict, lv: int, when: int) -> dict:
    kind = rumors.NEW_HEAVEN if lv == realm.MAX_LV else rumors.RISE
    return rumors.make(kind, p["name"], place=p["location"], when=when, detail=realm.stage_name(lv, 0), lv=lv,
                       subject_lv=lv)


def heaven_role(result: Result, world: evolution.World, rng: random.Random, name: str, when: int, player_lv: int,
                near: list[str], turn_no: int) -> None:
    """天道角色的行為：宿敵每段追近主角一個大境界、移到主角附近；貴人移到主角附近。
    宿敵由第 18-2b 步指派（domain/games.py）；貴人還沒有人指派（只有測試會用到）。"""
    p = world.npcs[name]
    if p["status"] != "ALIVE" or p["heaven_role"] not in NEAR_ROLES:
        return
    p = world.npcs[name] = dict(p)
    if p["heaven_role"] == "宿敵" and p["realm_lv"] < player_lv:
        p.update(realm_lv=p["realm_lv"] + 1, stage_index=0, cultivation=0, rewrite_reason="境界提升")
        stage = realm.stage_name(p["realm_lv"], 0)
        _note(result, world, name, memory.NEWS, f"突破至{stage}", when, turn_no)
        result.events.append(Event(ROSE, when, f"{name}突破至{stage}", rumor=rise_rumor(p, p["realm_lv"], when)))
    if near and p["location"] not in near:
        destination = rng.choice(sorted(near))
        _note(result, world, name, memory.NEWS, f"離開{_place(p)}，前往{destination}", when, turn_no)
        p["location"] = destination


def tiandao_moves(world: evolution.World) -> list:
    """天道落子的呼叫點（WHITEPAPER 第 13 節；第 18 步才實作）。這一步一律不落子。"""
    return []


# ── 交手 ─────────────────────────────────────────────────────────────────
def fight_chance(same_place: bool, span_months: int) -> float:
    rate = SAME_PLACE_FIGHTS if same_place else APART_FIGHTS
    return min(MAX_FIGHT_CHANCE, rate * span_months / 12)


def win_chance(lv: int, other_lv: int) -> float:
    """勝率：50% ＋ 每差一個大境界 15%，限制在 10%～90%。"""
    return max(WIN_RANGE[0], min(WIN_RANGE[1], WIN_BASE + WIN_PER_LEVEL * (lv - other_lv)))


def seeker(p: dict, q: dict) -> tuple[dict, dict]:
    """（去找人的, 被找的）：復仇目標指向對方的那方先動，否則野心大的那方。"""
    def eager(x: dict, y: dict) -> tuple[bool, int]:
        return x["goal"] == "復仇" and x["goal_target"] == y["name"], x["ambition"]
    return (p, q) if eager(p, q) >= eager(q, p) else (q, p)


def maybe_fight(result: Result, world: evolution.World, rng: random.Random, x: str, y: str, a: int, b: int,
                turn_no: int) -> None:
    """有恩怨的兩人這一段有沒有交手。任一方重傷、或有人去了遠方（找不到），就打不起來。"""
    p, q = dict(world.npcs[x]), dict(world.npcs[y])
    if "重傷" in (p["condition"], q["condition"]) or AWAY in (p["location"], q["location"]):
        return
    if rng.random() >= fight_chance(p["location"] == q["location"], months(b) - months(a)):
        return
    hunter, prey = seeker(p, q)
    place = hunter["location"] = prey["location"]
    winner, loser = (hunter, prey) if rng.random() < win_chance(hunter["realm_lv"], prey["realm_lv"]) else (prey, hunter)
    killed = rng.random() < DEATH_SHARE and npc.trait_level(winner["kindness"]) != "高"
    world.npcs[x], world.npcs[y] = (p, q)
    w, l = winner["name"], loser["name"]
    _foes(result, world, w, {l}, b)
    if killed:
        loser.update(status="FALLEN", condition=npc.CONDITIONS[-1])
        if loser.get("opened"):   # 命者死了：當場收、算放著（第 122c-7 題）
            evolution.close(loser, stage.LEFT)
        _note(result, world, l, memory.DEATH, f"在{place}死於{w}之手", b, turn_no, actor=w)
        _note(result, world, w, memory.NEWS, f"在{place}殺了{l}", b, turn_no)
        _died(result, world, l)
        result.events.append(Event(DIED, b, f"{w}在{place}殺了{l}", place, rumors.make(
            rumors.KILL, w, target=l, place=place, when=b, lv=loser["realm_lv"], subject_lv=winner["realm_lv"])))
    else:
        loser.update(condition="重傷", rewrite_reason="重傷")
        # actor：誰打傷的（守護他的人會從遠方趕回，見 evolution.urgent_return；不解析文字）
        _note(result, world, l, memory.NEWS, f"在{place}敗給{w}，身受重傷", b, turn_no, actor=w)
        _note(result, world, w, memory.NEWS, f"在{place}擊敗{l}", b, turn_no)
        result.events.append(Event(WOUNDED, b, f"{w}在{place}重創{l}", place, rumors.make(
            rumors.WOUND, w, target=l, place=place, when=b, lv=loser["realm_lv"], subject_lv=winner["realm_lv"])))


# ── 勢力 ─────────────────────────────────────────────────────────────────
def successors(factions: list[str], bonds: list[dict], npcs: dict[str, dict]) -> list[tuple[str, str]]:
    """首領都不在了的勢力，由境界最高的成員繼位。回傳 [(勢力, 繼任者)]；沒有成員就沒有變化。"""
    def alive(name: str) -> bool:
        return npcs.get(name, {}).get("status") == "ALIVE"
    found = []
    for f in factions:
        leaders = [b["a"] for b in bonds if b["b"] == f and b["type"] == "首領"]
        members = [npcs[b["a"]] for b in bonds if b["b"] == f and b["type"] == "成員" and alive(b["a"])]
        if leaders and not any(alive(x) for x in leaders) and members:
            best = max(members, key=lambda p: (p["realm_lv"], p["stage_index"], p["cultivation"]))
            found.append((f, best["name"]))
    return found


def succeed(result: Result, world: evolution.World, when: int, turn_no: int) -> None:
    factions = sorted({b["b"] for b in world.bonds if b["type"] in society.MEMBER_BONDS})
    for faction, name in successors(factions, world.bonds, world.npcs):
        bond = {"a_kind": society.NPC, "a": name, "b_kind": society.FACTION, "b": faction, "type": "首領"}
        world.bonds.append(bond)
        result.bonds.append(bond)
        _note(result, world, name, memory.NEWS, f"繼任{faction}首領", when, turn_no)
        heir = world.npcs[name]
        place = world.factions.get(faction) or heir["location"]
        result.events.append(Event(SUCCEEDED, when, f"{name}繼任{faction}首領", rumor=rumors.make(
            rumors.SUCCEED, name, place=place, when=when, detail=faction, subject_lv=heir["realm_lv"])))
        if heir["location"] == AWAY and world.factions.get(faction):   # 人在遠方：繼位時一併回來（第 10c-2b 步）
            home = world.factions[faction]
            world.npcs[name] = result.npcs[name] = {**heir, "location": home, "away_since": None, "away_from": ""}
            _note(result, world, name, memory.NEWS, f"從遠方趕回{home}", when, turn_no)


# ── 收徒（16i 第 12 題）──────────────────────────────────────────────────
def tie(p: dict, q: dict, home: dict[str, str], taught: set[str]) -> tuple[str, str] | None:
    """同勢力境界高 MASTER_GAP 級以上的收還沒有師父的為徒：（師父, 徒弟）；沒有回傳 None。"""
    if home.get(p["name"]) and home.get(p["name"]) == home.get(q["name"]):
        hi, lo = (p, q) if p["realm_lv"] >= q["realm_lv"] else (q, p)
        if hi["realm_lv"] - lo["realm_lv"] >= MASTER_GAP and lo["name"] not in taught:
            return hi["name"], lo["name"]
    return None


def ties(result: Result, world: evolution.World, rng: random.Random, span_months: int, when: int, turn_no: int) -> None:
    """這段時間的收徒（只看還沒有羈絆的兩人；去了遠方的不算）。"""
    alive = sorted((p for p in world.npcs.values() if p["status"] == "ALIVE" and p["location"] != AWAY),
                   key=lambda p: p["name"])
    linked = {frozenset((b["a"], b["b"])) for b in world.bonds if b["a_kind"] == b["b_kind"] == society.NPC}
    home = {b["a"]: b["b"] for b in world.bonds if b["type"] in society.MEMBER_BONDS and b["a_kind"] == society.NPC}
    taught = {b["b"] for b in world.bonds if b["type"] == "師父"}
    chance, made = min(MAX_FIGHT_CHANCE, TIE_RATE * span_months), 0
    for i, p in enumerate(alive):
        for q in alive[i + 1:]:
            found = None if frozenset((p["name"], q["name"])) in linked else tie(p, q, home, taught)
            if made >= MAX_TIES or not found or rng.random() >= chance:
                continue
            a, b = found
            _bond(result, world, "師父", a, b)
            linked.add(frozenset((a, b)))
            taught.add(b)
            made += 1
            result.events.append(Event(BONDED, when, f"{a}收{b}為徒", world.npcs[a]["location"]))


def _foes(result: Result, world: evolution.World, killer: str, others: set[str], when: int) -> None:
    """交手輸的人（重傷或死）對對手記一筆動手（重）。"""
    for name in sorted(others - {killer}):
        if world.npcs.get(name, {}).get("status") == "ALIVE":
            _feel(result, world, name, killer, npc.KILL, when)


def _feel(result: Result, world: evolution.World, holder: str, toward: str, h: opinion.Hit, when: int) -> None:
    """NPC 之間記一筆原因；這次推進剩下的部分照算出來的關係走（world.bonds 補一條，不存）。"""
    result.reasons.append(opinion.reason(holder, toward, h, when))
    kind = "仇家" if h[3] <= society.FOE_AT else "友人"
    if not any(b["type"] == kind and {b["a"], b["b"]} == {holder, toward} for b in world.bonds):
        world.bonds.append({"a_kind": society.NPC, "a": holder, "b_kind": society.NPC, "b": toward, "type": kind,
                            "clock_shichen": when})


def _bond(result: Result, world: evolution.World, kind: str, a: str, b: str) -> None:
    bond = {"a_kind": society.NPC, "a": a, "b_kind": society.NPC, "b": b, "type": kind}
    world.bonds.append(bond)
    result.bonds.append(bond)


# ── 大事年表 ─────────────────────────────────────────────────────────────
def headlines(events: list[Event], start: int, end: int, here: str) -> list[Event]:
    """一次跨過一年以上：最重大的 HEADLINES 件（同份量先發生的優先）；不到一年：只有發生在主角所在地的交手。依時間排。"""
    if end - start >= CHRONICLE_SPAN:
        picked = sorted(events, key=lambda e: (-e.weight, e.when))[:HEADLINES]
    else:
        picked = [e for e in events if e.place == here]
    return sorted(picked, key=lambda e: e.when)


# ── 小工具 ───────────────────────────────────────────────────────────────
def _note(result: Result, world: evolution.World, subject: str, kind: str, text: str, when: int, turn_no: int,
          actor: str = "") -> None:
    _record(result, world, [memory.note(memory.NPC, subject, kind, text, clock_now=when, turn_no=turn_no,
                                        actor=actor)])


def _record(result: Result, world: evolution.World, notes: list[dict]) -> None:
    """新記事同時放進 world.notes：之後幾段的演算看得到（例如師父剛被殺 → 下一次演算時徒弟改為復仇）。"""
    result.notes += notes
    world.notes += notes


def _died(result: Result, world: evolution.World, name: str) -> None:
    result.dead.add(name)
    world.gone = world.gone | {name}


def _place(p: dict) -> str:
    return "遠方" if p["location"] == AWAY else p["location"]
