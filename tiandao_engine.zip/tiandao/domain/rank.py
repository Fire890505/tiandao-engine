"""地位（第 7-1c 批，WHITEPAPER 第 7-1-8 題甲）：這個人在這裡算什麼人，五級，不存、當場算。純函式。

- NPC：修行身分（宗主、長老……）或職業，奴僕是賤；財和名聲等 NPC 有家產名聲再補。
- 主角五樣：凡人身分（奴隸、世家）、門派職位、凡人錢、這裡的名聲（威名遠近皆知）和通緝、境界處境。
- 境界：古代和並存時境界每兩級升一級（凡人當地平均是 0）；隱世、打壓不看；在宗門裡只看職位。
- 接：初見（差兩級以上：高的看不起低的、低的怕高的）、國法以下犯上、條件表「地位」字。數字暫定。
"""
from __future__ import annotations

from . import era
from .effects import WORK_WAGE

LEVELS = ("賤", "平民", "體面", "士紳", "權貴")
LOW, COMMON, DECENT, GENTRY = 0, 1, 2, 3
ROLE = {"外門弟子": 1, "武館弟子": 1, "內門弟子": 2, "館主": 2, "堂主": 2, "長老": 3, "家主": 3, "幫主": 3, "會首": 3, "宗主": 4}
SECT = {"外門": 1, "內門": 2, "真傳": 3, "太上長老": 3, "宗主": 4}   # 主角的門派職位（sect_rank）
JOB = {"賣藝人": 0, "掌櫃": 2, "大夫": 2, "朝奉": 2, "管事": 2, "武師": 2, "鏢師": 2}
BIRTH = {"沒落世家旁支": 2}
RICH = WORK_WAGE * 36   # 凡人錢有三年工錢升一級；身無分文降一級（最低到平民）
GAP, SNUB, AWE = 2, -10, 10   # 初見：差兩級以上，高的對低的好感 −10，低的怕高的 +10（只算 NPC 對主角）


def _clamp(n: int) -> int:
    return max(LOW, min(len(LEVELS) - 1, n))


def _realm(lv: int, stance: str, in_sect: bool) -> int:
    return 0 if in_sect or stance not in ("", era.OPEN) else lv // 2


def of_npc(p: dict, role: str, *, bound: bool, stance: str, in_sect: bool) -> int:
    """role：修行身分（profile.calling）；bound：是別人的奴、僕。"""
    return LOW if bound else _clamp((ROLE.get(role) or JOB.get(p.get("job", ""), COMMON)) + p.get("fortune", 0)   # 家運（第 9f-1 批）
                                    + _realm(p["realm_lv"], stance, in_sect))


def of_me(sheet: dict, *, wanted: bool, famed: bool, stance: str, in_sect: bool) -> int:
    """wanted：在這一國被通緝；famed：這裡的人都知道你的威名。"""
    if wanted or sheet.get("bondage"):
        return LOW
    n = max(BIRTH.get(sheet["origin"], COMMON), SECT.get(sheet["sect_rank"], COMMON))
    n += (sheet["money"] >= RICH) - (sheet["money"] <= 0 and n > COMMON)
    return _clamp(n + famed + _realm(sheet["realm_lv"], stance, in_sect))


def first(gap: int) -> tuple[int, int]:
    """初見：gap＝他的地位 − 你的。回傳（好感, 怕）。"""
    return (SNUB if gap >= GAP else 0), (AWE if gap <= -GAP else 0)


def upward(me: int, them: int) -> bool:
    """以下犯上：賤或平民對士紳以上動手。"""
    return me <= COMMON and them >= GENTRY
