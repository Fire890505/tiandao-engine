"""天下骨架（2026-10-13，WHITEPAPER 16k 草稿批次一；數字暫定）。純函式，不碰資料庫。

- 開局依世界種子生成：人族 3～4 國、魔族 1～2 國、獸族 1～2 片領域（領域也是「國家」勢力）；人族、魔族每國 3～5 州，
  獸族 2～3 州。州放在方格上，同一國的州連成一片；州只有名字、所屬國、座標、主城（地點，描述留白）。
- 方格上相鄰的州，主城之間有路：同國是官道，跨國是邊關、海路、山道之一（space.STATE_ROADS）。
- 起始區域就是第一個人族國的第一州（它的城鎮當主城）；其他州等主角第一次到主城，才用「世界種子＋州名」生成內容
  （region.generate）。
- 地點屬於哪一州不另存：沿著州內的路（不走州與州之間的路）離哪個主城最近就是哪一州；走不到的算起始州。
骨架存在 worlds.atlas（JSON）：{"start": 州名, "nations": {國名: 種族}, "states": [{name, nation, x, y, capital, built}],
"seed": 生成州內容用的種子（存檔讀回來世界種子會換，這個不換）；批次四加上 stances（國與國的關係）、
year（算到哪一年）、history（國名 → 說書人寫的那一國的往事）；第 7-3b2 批加 since（關係 → 換的時刻）、cd（國事牌冷卻），每年怎麼變在 game/nations}。
"""
from __future__ import annotations

import random

from . import crime, names, races, society, space
from .races import BEAST, DEMON, HUMAN, RACES

NATIONS = ((HUMAN, (3, 4)), (DEMON, (1, 2)), (BEAST, (1, 2)))
STATES = {HUMAN: (3, 5), DEMON: (3, 5), BEAST: (2, 3)}
CROSS = ("邊關", "海路", "山道")
STEPS = {(0, 1): "北", (1, 0): "東", (0, -1): "南", (-1, 0): "西"}


def generate(rng: random.Random, *, nation: str, capital: str, era_now: str, taken: set[str] = frozenset()) -> dict:
    """nation、capital：起始區域的國家與城鎮；taken：世界裡已有的名字。
    回傳 {"atlas", "locations"（其他州的主城）, "connections", "factions"（其他國）}。"""
    taken = {nation, capital, *taken}
    cells: dict[tuple, dict] = {}
    nations, factions, states = {}, [], []
    for race, count in NATIONS:
        for _ in range(rng.randint(*count)):
            name = nation if not nations else names.pick_unused(rng, *names.NATION_NAMES[race], taken)
            taken.add(name)
            nations[name] = race
            if name != nation:
                factions.append({"name": name, "type": society.NATION, "location": "", "discovered_turn": 0,
                                 "traits": crime.roll_nation(rng, era_now)})
            size, mine = rng.randint(*STATES[race]), [rng.choice(sorted(_edge(cells))) if cells else (0, 0)]
            while len(mine) < size and _edge(mine) - cells.keys():
                mine.append(rng.choice(sorted(_edge(mine) - cells.keys())))
            for x, y in mine:
                prefix = names.pick_unused(rng, names.STATE_PREFIXES[race], ("",), taken)
                state = {"name": prefix + names.STATE_SUFFIX[race], "nation": name, "x": x, "y": y,
                         "capital": capital if not states else prefix + rng.choice(names.CITY_SUFFIXES[race]),
                         "built": not states}
                taken |= {state["name"], state["capital"]}
                states.append(state)
                cells[(x, y)] = state
    roads = []
    for (x, y), a in sorted(cells.items()):
        for dx, dy in ((0, 1), (1, 0)):   # 只往北、往東連，每對連一次
            if b := cells.get((x + dx, y + dy)):
                tier = "官道" if a["nation"] == b["nation"] else rng.choice(CROSS)
                roads.append({"a": a["capital"], "b": b["capital"], "tier": tier, "distance_km": space.STATE_ROADS[tier],
                              "direction": STEPS[(dx, dy)], "discovered_turn": 0})
    towns = [{"name": s["capital"], "type": "城鎮", "scale": "鄉鎮", "parent": "", "danger": "", "discovered_turn": 0}
             for s in states[1:]]
    return {"atlas": {"start": states[0]["name"], "nations": nations, "states": states},
            "locations": towns, "connections": roads, "factions": factions}


def _edge(cells) -> set[tuple]:
    """這些格子四周還沒放州的格子。"""
    return {(x + dx, y + dy) for x, y in cells for dx, dy in STEPS} - set(cells)


def state_map(atlas: dict, connections: list[dict]) -> dict[str, str]:
    """每個地點屬於哪一州：沿州內的路離哪個主城最近。"""
    local = [c for c in connections if c["tier"] not in space.STATE_ROADS]
    found: dict[str, tuple[int, str]] = {}
    for s in atlas["states"]:
        for place, km in space.distances_from(local, s["capital"]).items():
            if place not in found or km < found[place][0]:
                found[place] = (km, s["name"])
    return {place: s for place, (_, s) in found.items()}


def state_of(atlas: dict | None, connections: list[dict], place: str) -> dict | None:
    """這個地點所在的州（沒有骨架的舊世界回傳 None）。"""
    if not atlas:
        return None
    name = state_map(atlas, connections).get(place, atlas["start"])
    return next(s for s in atlas["states"] if s["name"] == name)


def unbuilt(atlas: dict | None, place: str) -> dict | None:
    """place 是不是還沒生成內容的州的主城。"""
    return next((s for s in (atlas or {}).get("states", []) if s["capital"] == place and not s["built"]), None)


def built(atlas: dict, state: str) -> dict:
    return {**atlas, "states": [{**s, "built": True} if s["name"] == state else s for s in atlas["states"]]}


def race_of(atlas: dict, state: dict) -> str:
    return atlas["nations"][state["nation"]]


# ── 國與國（批次四：16k 第 7、8 題；數字暫定）────────────────────────────────
WAR, COLD, TRADE, ALLY = "交戰", "冷戰", "通商", "結盟"
STANCES = (WAR, COLD, TRADE, ALLY)
START = {"同族": {TRADE: 4, ALLY: 2, COLD: 2, WAR: 1}, "敵對": {WAR: 3, COLD: 3, TRADE: 1},
         "戒備": {COLD: 3, TRADE: 2, WAR: 1}, "中立": {TRADE: 2, COLD: 2, WAR: 1, ALLY: 1}}
MAX_YEARS = 20   # 一次跨很多年只算最近這幾年


def _key(a: str, b: str) -> str:
    return "|".join(sorted((a, b)))


def bordering(atlas: dict) -> set[str]:
    """方格上相鄰的國（_key）。只有相鄰的國會開戰。"""
    at = {(s["x"], s["y"]): s["nation"] for s in atlas["states"]}
    return {_key(n, at[(x + dx, y + dy)]) for (x, y), n in at.items() for dx, dy in STEPS
            if at.get((x + dx, y + dy), n) != n}


def stances(atlas: dict) -> dict[str, str]:
    """國與國的關係（_key → 關係）；骨架裡還沒有就照種族關係擲（同一個世界每次一樣）。"""
    if "stances" in atlas:
        return atlas["stances"]
    rng, near, nations = random.Random(f"{atlas['seed']}:stances"), bordering(atlas), sorted(atlas["nations"])
    out = {}
    for i, a in enumerate(nations):
        for b in nations[i + 1:]:
            weights = START[races.relation(atlas["nations"][a], atlas["nations"][b])]
            pick = rng.choices(list(weights), weights=list(weights.values()))[0]
            out[_key(a, b)] = COLD if pick == WAR and _key(a, b) not in near else pick
    return out


def news(a: str, b: str, old: str, new: str) -> str:
    """關係變了的一句（大傳聞）。"""
    verb = "議和" if old == WAR else "斷了盟約" if old == ALLY else {WAR: "開戰", COLD: "交惡", TRADE: "互通商路", ALLY: "結為盟國"}[new]
    return f"{a}與{b}{verb}"


def at_war(atlas: dict | None, a: str, b: str) -> bool:
    return bool(atlas) and a != b and stances(atlas).get(_key(a, b)) == WAR


def fronts(atlas: dict) -> dict[str, str]:
    """邊境州 → 跟它相鄰、正在交戰的那一國（好幾國取名字排前的）。"""
    at = {(s["x"], s["y"]): s for s in atlas["states"]}
    out = {}
    for (x, y), s in at.items():
        foes = sorted(o["nation"] for dx, dy in STEPS if (o := at.get((x + dx, y + dy))) and at_war(atlas, s["nation"], o["nation"]))
        if foes:
            out[s["name"]] = foes[0]
    return out


def near_states(atlas: dict, state: dict) -> set[str]:
    """這一州和方格上相鄰的州（背景演化每回合跑的範圍）。"""
    return {s["name"] for s in atlas["states"] if abs(s["x"] - state["x"]) + abs(s["y"] - state["y"]) <= 1}


def valid(atlas) -> bool:
    """讀檔檢查。"""
    try:
        states, nations = atlas["states"], atlas["nations"]
        return (isinstance(atlas["seed"], str) and isinstance(nations, dict)
                and all(r in RACES for r in nations.values())
                and atlas["start"] in {s["name"] for s in states}
                and all(s["nation"] in nations and isinstance(s["built"], bool) and isinstance(s["x"], int)
                        and isinstance(s["y"], int) and isinstance(s["capital"], str) for s in states)
                and all(v in STANCES for v in atlas.get("stances", {}).values())       # 批次四：國與國
                and all(isinstance(v, int) for k in ("since", "cd") for v in atlas.get(k, {}).values())   # 第 7-3b2 批：關係換的時刻、國事牌冷卻
                and isinstance(atlas.get("year", 0), int)
                and all(isinstance(d["name"], str) and isinstance(d["past"], list) for d in atlas.get("dynasty", {}).values())   # 國號（第 8-2 批）
                and all(isinstance(v, str) and len(v) <= 300 for v in atlas.get("history", {}).values()))
    except (KeyError, TypeError):
        return False
