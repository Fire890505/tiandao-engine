"""模型寫的舊亡魂（progress/模型生成內容.md 第十節「亡魂」九題、零件草稿、改骨架甲）。純函式，不呼叫模型。

- 舊亡魂＝一種模型事端（佔事端名額，第 6 題甲）：plan 擲母型、留處、現形、死因、收尾的東西、風味；record 照
  rules/content/ghost_parts.txt「骨」那張拼成跟 rules/content/plots/ 一樣格式的全文（plots_m）。
- 母型（第 2 題甲、改骨架甲）各有自己的骨架：冤魂、冤夢查案；未死相處、說破；心願找、送到；託夢解夢。
  模型要寫的欄、給模型看的代稱也照母型（「問」「誰」那兩張）。託夢三分之一換成「冤夢」。
- 「亡者」不是角色：放的時候才填（game/plots.place：先挑當地的死人，沒有才生，第 5 題丙），同時在留處記一筆幽魂；
  結果欄「亡:安息／散／怒」改那一筆（第 7 題甲）。
- 模型照 newplots 的三段只寫短欄；沒寫好、還沒寫完的欄用零件表的通用句（第 8 題甲），一定拼得出來。
"""
from __future__ import annotations

import random
import re

from . import checks, era as era_mod, newplots, undead
from .clock import SHICHEN_PER_YEAR
from .newdisasters import FLAVORS   # 一張風味表（天災甲第 3 題）
from .plot import fill
from .tales import CONTENT

WAY = "亡魂"
SHARE = 0.25                     # 模型事端裡幾成是舊亡魂（第 9 題）
WRONG = 1 / 3                    # 託夢換成冤夢的機會
YEARS = (3, 30)                  # 新生的死人死了幾年
DEAD, RESULT = "亡者", "亡"      # cast 的那一格；結果欄的類（安息、散、怒）
WAR_DEATH, WAR_KINDS = "打仗時戰死了", ("心願", "託夢")   # 第十一節第 8 題乙
_rows = [l.split("｜") for l in (CONTENT / "ghost_parts.txt").read_text(encoding="utf-8").splitlines() if l and not l.startswith("#")]
_all = lambda k: [r[1:] for r in _rows if r[0] == k]   # noqa: E731
_for = lambda kinds, kind: kinds == "全" or kind in kinds.split("、")   # noqa: E731
KINDS = {r[0]: r[1:] for r in _all("母型")}   # 代號 → 處境、真相、死因、留、證（古現未）、結局、結局結果、洩底
BASE = ("冤魂", "心願", "託夢", "未死")
PROOFS = {r[0]: r[1:] for r in _all("死證")}   # 被害死的：死因 → 收尾的東西（古現未）
WHO, ASKS, BONES = _all("誰"), _all("問"), _all("骨")
STAYS = {r[0]: r[1:] for r in _all("留")}      # 種類 → 處名、地點類型
SHOWS = _all("現形")[0][0].split("、")
WORDS = {r[0]: r[1] for r in _all("處詞")}
FALLBACK = dict(_all("通用"))


def plan(rng: random.Random, era_now: str, n: int, world_seed: str, kind: str = "", war: bool = False) -> dict:
    """一條要寫的骨架。n：這個世界寫過幾條亡魂（風味照世界的順序輪流）。kind：指定母型（驗收工具輪流擲）。
    war：世界上有仗在打，心願、託夢的死因多一種戰死（第十一節第 8 題乙）。"""
    kind = kind or rng.choice(BASE)
    kind = "冤夢" if kind == "託夢" and rng.random() < WRONG else kind
    k = KINDS[kind]
    stay = rng.choice(k[3].split("、"))
    mine = [f for f in FLAVORS if WAY in f[2].split("、")]
    flavor = random.Random(f"{world_seed}:flavors:{WAY}").sample(mine, len(mine))[n % len(mine)]
    cause, i = rng.choice(k[2].split("、") + ([WAR_DEATH] if war and kind in WAR_KINDS else [])), era_mod.ERAS.index(era_now)
    proof = PROOFS.get(f"{kind}:{cause}") or PROOFS.get(cause)   # 死證：先找「母型:死因」那一行
    words = {w: rng.choice(v.split("、")) for w, v in WORDS.items()}
    words |= {"留處": rng.choice(STAYS[stay][0].split("、")), "死因": cause, "證": proof[i] if proof else k[4 + i]}
    return {"ghost": True, "kind": kind, "era": era_now, "stay": stay, "show": rng.choice(SHOWS), "words": words,
            "flavor": flavor[:2], "years": rng.randint(*YEARS)}


def labels(slot: dict) -> dict[str, str]:
    """給模型看的代稱（照母型）。"""
    return {DEAD: "死去的那個人", "村": "這裡", **{role: tag for kinds, role, tag, _ in WHO if _for(kinds, slot["kind"])}}


def _show(slot: dict, text: str) -> str:
    k = KINDS[slot["kind"]]
    return fill(fill(text.replace("{現形}", slot["show"]).replace("{結局}", k[7]), labels(slot)), slot["words"])


def _tidy(slot: dict, key: str, text) -> str:
    """同 newplots._tidy，再把照抄的代稱換成一般說法（第一次真 9b：幫手那幾欄常寫「知情的人」）。"""
    text = newplots._tidy(slot, key, text)
    for tag in labels(slot).values():
        text = text if tag in ("苦主", "這裡") else text.replace(tag, "祂" if tag == "死去的那個人" else "他")
    return text


def brief(slot: dict, part: str) -> dict:
    """叫 bits 時的 slot（同 newplots.brief）：blind 不給真相。"""
    k, (name, trait) = KINDS[slot["kind"]], slot["flavor"]
    who = "；".join(f"{tag}是{what}" for kinds, _, tag, what in WHO if _for(kinds, slot["kind"]))
    war = "祂是打仗時戰死的。" if slot["words"]["死因"] == WAR_DEATH else ""
    lines = [f"時代：{slot['era']}。死去的那個人已經死了{slot['years']}年，魂還留在{{留處}}；祂現身的樣子：{slot['show']}。{k[0]}。{war}",
             f"{who}。",
             f"風味：{name}（{trait}），照這個傳統的味道寫。不要寫上面那幾個代稱，也不要取名字。"]
    if part != "blind":
        lines.append(f"真相：{k[1]}。")
    if part == "close":
        lines.append(f"沒人插手的話：{k[7]}。")
    return {"what": "一件跟死去的人有關的事", "era": slot["era"], "brief": _show(slot, "\n".join(lines))}


def asks(slot: dict, part: str) -> list[dict]:
    """這一段要模型寫的欄：key、ask、span、leak（同 newplots.asks）。"""
    return [{"key": key, "ask": _show(slot, ask), "span": newplots.SPANS[span], "leak": leak == "查"}
            for kinds, p, key, span, leak, ask in ASKS if p == part and _for(kinds, slot["kind"])]


def faults(slot: dict, part: str, got: dict, taken: set[str], era_now: str) -> dict[str, str]:
    """逐欄查（同 newplots.faults）：長短、中文、時代、洩底（母型的字、死因）、撞名。照抄的代稱 _tidy 換掉，不退。"""
    lies = [*KINDS[slot["kind"]][9].split("、"), *slot["words"]["死因"].split("，")]
    out = {}
    for x in (x for x in asks(slot, part) if x["key"] in got):
        text = _tidy(slot, x["key"], got[x["key"]])
        reason = (checks.basic([(text, x["span"])], era_now) or ("洩底" if x["leak"] and any(w in text for w in lies) else "")
                  or ("撞名" if x["key"] == "name" and checks.clash(text, taken) else ""))
        if reason:
            out[x["key"]] = reason
    return out


def record(slot: dict, got: dict, taken=frozenset()) -> dict:
    """存成一條（plots_m）。got：{段: {欄: 字}}，沒有的欄用通用句。骨那張的 [欄] 換成模型寫的。
    taken：已有的事端名；名字用了通用句又被佔了，加二、三……（同 newwars.name，不然整批存不進去）。"""
    flat = {k: v for part in got.values() for k, v in part.items()}
    g = {k: _tidy(slot, k, flat.get(k) or v) for k, v in FALLBACK.items()}
    g["name"] = next(n for n in (g["name"], *(g["name"] + c for c in "二三四五六七八九十")) if n not in taken)
    g |= {k: newplots._trace(g[k]) if g[k][-1] not in "？！。" else g[k] for k in ("rumor", "tr_end")}
    kind, k, w = slot["kind"], KINDS[slot["kind"]], slot["words"]
    put = {"{留類}": STAYS[slot["stay"]][1], "{路線}": f"路線:{g['name']}", "{結局}": k[7], "{結局結果}": k[8]}
    line = lambda row: re.sub(r"\[(\w+)\]", lambda m: g[m.group(1)], "｜".join(row))   # noqa: E731
    bones = [line(row) for kinds, *row in BONES if _for(kinds, kind)]
    for a, b in put.items():
        bones = [x.replace(a, b) for x in bones]
    rows = [f"牌｜{g['name']}｜地方｜事端｜地點:村落、城鎮｜｜", f"來源｜{newplots.MODEL}｜{WAY}｜{kind}｜{slot['years']}",
            "｜".join(["表面", slot["era"], *(f"{x}={y}" for x, y in w.items())]), *bones, f"素材｜{w['留處']}、{w['證']}"]
    return {"name": g["name"], "state": slot["era"], "body": "\n".join(rows), "source": newplots.MODEL}


def mine(t: dict) -> bool:
    """這條模板是模型寫的舊亡魂。"""
    return bool(t.get("來源")) and t["來源"][0][1:2] == [WAY]


def kind_of(t: dict) -> str:
    return t["來源"][0][2] if mine(t) else ""


def died(t: dict, now: int) -> int:
    """新生的亡者什麼時候死的（plan 擲的年數，記在來源那一行）。"""
    return now - int(t["來源"][0][3]) * SHICHEN_PER_YEAR


def grudge(t: dict) -> str:
    """亡者那筆的執念：冤魂、冤夢＝恩怨（對象是隱瞞者，那人死了也安息）；其他＝約定（對象是受害者）。"""
    return undead.GRUDGE if kind_of(t) in ("冤魂", "冤夢") else undead.PROMISE


def ghost(name: str, lv: int, died: int, place: str, grudge_: str, on: str) -> dict:
    """亡者那一筆（domain/undead.born 的格式；一律幽魂，第 9 題）。"""
    return {"name": name, "form": undead.GHOST, "lv": lv, "died_shichen": died, "place": place, "condition": undead.CONDITIONS[0],
            "grudge": grudge_, "grudge_on": on, "awake": False}
