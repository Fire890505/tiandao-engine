"""遊戲時間。單一事實來源是 total_shichen（整數時辰數），其餘皆為衍生值。

曆法沿用舊專案 time_system.py：一日 12 時辰、一月 30 日、一年 12 月（360 日）。
"""
from __future__ import annotations

SHICHEN_PER_DAY = 12
DAYS_PER_MONTH = 30
MONTHS_PER_YEAR = 12
SHICHEN_NAMES = "子丑寅卯辰巳午未申酉戌亥"
SEASONS = ("春", "春", "春", "夏", "夏", "夏", "秋", "秋", "秋", "冬", "冬", "冬")


SHICHEN_PER_MONTH = SHICHEN_PER_DAY * DAYS_PER_MONTH
SHICHEN_PER_YEAR = SHICHEN_PER_MONTH * MONTHS_PER_YEAR
NOTABLE_PASSAGE = SHICHEN_PER_MONTH   # 至少一個月才寫「時間流逝」，避免每回合都多一行


def season_of(total_shichen: int) -> str:
    return SEASONS[(total_shichen // SHICHEN_PER_MONTH) % MONTHS_PER_YEAR]


def format_span(shichen: int) -> str:
    """「3 年 2 個月」「5 日」「4 時辰」：給事實清單用，只取最大的兩個單位。"""
    years, rest = divmod(shichen, SHICHEN_PER_YEAR)
    months, rest = divmod(rest, SHICHEN_PER_MONTH)
    days, hours = divmod(rest, SHICHEN_PER_DAY)
    parts = [f"{n} {u}" for n, u in ((years, "年"), (months, "個月"), (days, "日"), (hours, "時辰")) if n]
    return " ".join(parts[:2]) or "0 時辰"


def passage_facts(before: int, after: int) -> list[str]:
    """時間推進後給 AI 的事實：經過多久、季節如何變化。O(1)，不逐月迭代（舊專案 B-06）。"""
    span = after - before
    facts: list[str] = []
    if span >= NOTABLE_PASSAGE:
        facts.append(f"時間流逝：{format_span(span)}（{describe(before)['label']} → {describe(after)['label']}）")
    years = span // SHICHEN_PER_YEAR
    months_crossed = after // SHICHEN_PER_MONTH - before // SHICHEN_PER_MONTH
    if years >= 1:
        facts.append(f"歷經 {years} 度寒暑，四季皆已輪轉")
    elif season_of(before) != season_of(after):
        facts.append(f"季節由{season_of(before)}入{season_of(after)}")
    elif months_crossed >= 3:   # 同一季節卻跨了 3 個月以上：繞了一圈回來
        facts.append(f"四季輪轉一周，又回到{season_of(after)}季")
    return facts


def describe(total_shichen: int) -> dict:
    if total_shichen < 0:
        raise ValueError("total_shichen 不可為負數")
    days, shichen = divmod(total_shichen, SHICHEN_PER_DAY)
    months, day = divmod(days, DAYS_PER_MONTH)
    year, month = divmod(months, MONTHS_PER_YEAR)
    return {
        "totalShichen": total_shichen,
        "year": year + 1,
        "month": month + 1,
        "day": day + 1,
        "shichen": SHICHEN_NAMES[shichen] + "時",
        "season": SEASONS[month],
        "label": f"第{year + 1}年{month + 1}月{day + 1}日 {SHICHEN_NAMES[shichen]}時（{SEASONS[month]}）",
    }
