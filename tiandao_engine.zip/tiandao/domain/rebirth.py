"""前世（第 6-6b 批，WHITEPAPER 第 6-6b-1～6-6b-7、6-6b2-1 題）：角色卡欄位和信不信的難易。純函式。

- rebirth.told：沒被信的那件事（前世的事、信物）對那個人記「說過了」，不能再拿來用（6-6b-6）。
- rebirth.tokens：撿到、拿到的遺物記下是誰的（信物，6-6b-3）；還在身上、又是上一世的才算。
- rebirth.woke：覺醒的是哪一世（session id，空＝沒覺醒）；tried：這一世擲過覺醒的觸發（同一世不重擲，6-6b-4）；
  dreamt：纏絲、聞冥上次做夢是第幾天（一天最多一次，6-6b-2）。
- 信不信擲說服：前世無難一級、殘夢照常、拿出信物、覺醒各再容易一級。
讀世界資料的部分（前世熟人、前世的事、相認、殘夢、覺醒）在 game/rebirths.py。

NPC 轉世（第 7-5c 批，7-5-6、7-5-7 題；數字暫定）：新人登錄時（repos.insert_npc）從待投胎名單（帳「待投胎」，domain/undead.py）
抽一次 draw，抽中的那筆了結、settle 寫轉世的人（lives 讀回來），藏著只有 Python 知道。前世欄看這一世的命（origins.dream）：
無＝不發生，死後回顧才揭開；殘夢＝第一次跟前世熟人同處似曾相識 ±SWAY；殘夢的人每月跟前世熟人同處擲 WAKE，一生一次，
醒了前世的原因降一級帶過來（carry），那筆名單 body 記「醒」。
"""
from __future__ import annotations

from . import opinion, society

FACTS = 3                                   # 每個人最多列幾件前世的事
LEVELS = ("容易", "普通", "困難", "極難")    # 同 judgment.DIFFICULTY 的順序


def fields() -> dict:
    return {"rebirth": {"told": {}, "tokens": [], "woke": "", "tried": [], "dreamt": -1}}


def level(dream: bool, token: bool, woke: bool = False) -> str:
    return LEVELS[max(0, 1 + (not dream) - token - woke)]


def took(sheet: dict, relic: dict) -> dict:
    """拿到一件遺物：記下原本是誰的。"""
    r = sheet["rebirth"]
    return {**sheet, "rebirth": {**r, "tokens": [*r["tokens"], {"name": relic["name"], "owner": relic["owner"]}]}}


def told(sheet: dict, who: str, key: str) -> dict:
    r = sheet["rebirth"]
    return {**sheet, "rebirth": {**r, "told": {**r["told"], who: [*r["told"].get(who, []), key]}}}


REBORN, SWAY, WAKE = 0.5, 10, 0.2


def draw(rng, waiting: list[dict], state: str, near: set[str], born: int | None) -> dict | None:
    """新人的前世（名單的一筆）：一半有；同州優先、沒有就鄰州；要死在他出生前，對不上就沒有。"""
    if born is None or rng.random() >= REBORN:
        return None
    ok = [w for w in waiting if w["body"]["死"] < born]
    pool = [w for w in ok if w["a"] == state] or [w for w in ok if w["a"] in near]
    return rng.choice(pool) if pool else None


def lives(ledger: list[dict]) -> dict[str, dict]:
    """轉世的人 → 那筆名單（body 名＝前世，醒＝覺醒的時刻）。"""
    return {l["settle"]: l for l in ledger if l["kind"] == society.WAITING and l["settle"]}


def knew(old: str, bonds: list[dict], reasons: list[dict]) -> set[str]:
    """前世熟人：跟前世有血緣立約，或彼此有原因的人。"""
    return ({b["b"] if b["a"] == old else b["a"] for b in bonds if old in (b["a"], b["b"]) and b["type"] in society.BLOOD + society.PACT}
            | {r["toward"] if r["holder"] == old else r["holder"] for r in reasons if old in (r["holder"], r["toward"])}) - {old}


def carry(reasons: list[dict], old: str, new: str, now: int, years: int | None) -> list[dict]:
    """覺醒：前世對別人（含主角那一生）的原因降一級帶過來；小的、固定的、淡掉的不帶。"""
    return [opinion.reason(new, r["toward"], opinion.hit(r["kind"], r["axis"], opinion.LEVELS[i - 1], 1 if r["value"] > 0 else -1),
                           now, life=r["session_id"])
            for r in reasons if r["holder"] == old and r["value"] and r["kind"] not in opinion.FIXED
            and (i := opinion.LEVELS.index(r["size"])) and opinion.alive(r, years, now)]


def valid(sheet: dict) -> bool:
    r = sheet["rebirth"]
    return (isinstance(r["told"], dict) and all(isinstance(v, list) and all(isinstance(x, str) for x in v) for v in r["told"].values())
            and isinstance(r["tokens"], list) and all(isinstance(t, dict) and all(isinstance(t.get(k), str) for k in ("name", "owner"))
                                                      for t in r["tokens"])
            and isinstance(r["woke"], str) and isinstance(r["tried"], list) and all(isinstance(x, str) for x in r["tried"])
            and isinstance(r["dreamt"], int))
