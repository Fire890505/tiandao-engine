"""仙戰（16l 第 12、20、21 題；草稿 C4b）：各盟在自己的秘境招新。純函式。

規則（2026-10-18 與使用者一題一題定案，見 progress/WHITEPAPER.md 16l，數字暫定）：
- 每個盟一處「某盟秘境」（realms.sync_map 登錄，連著盟裡第一座山門；盟不在了成遺址）。每個百日前 war.LASTS 天各辦一場。
- 散仙在秘境說「仙戰」就參加（角色卡 contest：{place, period, wins, foe}）。每一輪的對手在回合開始時抽
  （散仙名單，沒有就抽主辦盟的名冊），這回合出手就是迎戰；打贏進下一輪，輸了停在這一輪，三勝為止。
  人不在秘境或過了這個百日＝棄權（沒有名次）。
- 名次換招攬條件（C4a 的 invites）：魁首 3 家真傳、前三 2 家內門、前十 1 家外門；主辦盟的仙宗先開，
  不夠由跟主辦盟沒交戰的盟補。魁首在仙域傳開。
- 每場也有 immortal.RECRUITS 個 NPC 散仙被主辦盟的仙宗收走（immortal._period 下一個百日結算）。
"""
from __future__ import annotations

from . import atlas, immortal, recruit, sect, war
from . import judgment as J

PLACE = "秘境"
WORDS = ("仙戰",)
PLACES = {3: ("魁首", 3, sect.CORE), 2: ("前三", 2, sect.INNER), 1: ("前十", 1, sect.OUTER)}


def fields() -> dict:
    return {"contest": None}


def host(realm: dict, place: str, main: bool = False) -> str:
    """這裡是哪個盟的秘境（不是回傳空字串）；main：只認主秘境（仙戰在主秘境辦，第 45 題）。"""
    return next((a["name"] for a in realm["alliances"] for i, s in enumerate(immortal.secrets(realm, a["name"]))
                 if s["name"] == place and (i == 0 or not main)), "")


def is_open(now: int) -> bool:
    return now % immortal.PERIOD < war.LASTS


def start(realm: dict, sheet: dict, words: str, now: int) -> tuple[dict, list[str]]:
    """回合開始：棄權，或報名（散仙、人在開著的秘境、說了仙戰）。對手由呼叫端接著抽。"""
    c, here = sheet["contest"], sheet["location"]
    if c and (here != c["place"] or now // immortal.PERIOD != c["period"]):
        return {**sheet, "contest": None}, [f"離開了{c['place']}，仙戰棄權"]
    if c or sheet["sect"] or not host(realm, here, main=True) or not is_open(now) or not any(w in words for w in WORDS):
        return sheet, []
    return ({**sheet, "contest": {"place": here, "period": now // immortal.PERIOD, "wins": 0, "foe": ""}},
            [f"報名參加{host(realm, here)}的仙戰"])


def bout(sheet: dict, target: str, verdict) -> tuple[dict, int | None]:
    """這回合打的是不是這一輪的對手：贏了進下一輪（對手下回合再抽）；回傳（角色卡, 結束時的勝場，沒結束 None）。"""
    c = sheet["contest"]
    if not c or not c["foe"] or target != c["foe"] or verdict.action_type != J.COMBAT:
        return sheet, None
    won = any(x.target == J.STRIKE and x.outcome in (J.GREAT_SUCCESS, J.SUCCESS) for x in verdict.all_checks)
    wins = c["wins"] + won
    if won and wins < len(PLACES):
        return {**sheet, "contest": {**c, "wins": wins, "foe": ""}}, None
    return {**sheet, "contest": None}, wins


def finish(rng, realm: dict, sheet: dict, alliance: str, wins: int, now: int) -> tuple[dict, list[str]]:
    """名次換招攬條件：主辦盟的仙宗先開，不夠由沒交戰的盟補。"""
    if wins not in PLACES:
        return sheet, [f"{alliance}仙戰首輪落敗，沒有名次"]
    title, n, rank = PLACES[wins]
    st = immortal.stances(realm)
    pool = sorted((s for s in realm["sects"] if (sheet["heretic"] or s["alliance"] != immortal.HERETICS) and (
        s["alliance"] == alliance or s["alliance"] and st.get(atlas._key(alliance, s["alliance"])) != atlas.WAR)),
                  key=lambda s: (s["alliance"] != alliance, s["name"]))
    found = [recruit.offer(rng, s["name"], rank, now) for s in pool[:n]]
    return ({**sheet, "invites": sheet["invites"] + found},
            [f"在{alliance}仙戰得了{title}"] + ([f"{'、'.join(o['sect'] for o in found)}開出條件招攬"] if found else []))


def text(sheet: dict) -> str:
    c = sheet["contest"]
    return f"仙戰第 {c['wins'] + 1} 輪" if c else ""


def valid(sheet: dict) -> bool:
    c = sheet["contest"]
    return c is None or isinstance(c, dict) and set(c) == {"place", "period", "wins", "foe"}
