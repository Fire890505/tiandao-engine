"""句型組守則（第 128 系列乙，progress/模型生成內容.md「再次設計」）：有邏輯的整句（要／不要＋做的事、接縫）由 Python
照句型拼，模型只寫接在後面的小段（句型裡的 {段}），不碰邏輯；Python 查小段不准再提那件事。怪談、傳說共用。純函式。"""
from __future__ import annotations

import random
import re

from . import checks
from .tales import CONTENT

_rows = [l.split("｜") for l in (CONTENT / "clause_parts.txt").read_text(encoding="utf-8").splitlines() if l and not l.startswith("#")]
TIMES, LIES, EXCEPTS = (next(r[1].split("、") for r in _rows if r[0] == k) for k in ("時機", "拆穿", "例外"))
IMAGES, FEATURES = ({w.split(":")[0]: w.split(":")[-1] for w in next(r[1] for r in _rows if r[0] == k).split("、")}
                    for k in ("意象", "特徵"))   # 意象 → 認的字；意象 → 身分型的特徵
BOSSES = {r[1]: r[2].split("、") for r in _rows if r[0] == "本體"}
ENDINGS = {r[1]: r[2] for r in _rows if r[0] == "了結"}
_MARK = re.compile(r"[{｛]?(此地|鄰地)[}｝]?")


def span(text: str) -> tuple[int, int]:
    """「10-24」→（10, 24）。"""
    lo, hi = text.split("-")
    return int(lo), int(hi)


FORMS = {r[1]: (r[2].split("／"), span(r[3])) for r in _rows if r[0] == "句型"}   # 名字 →（句型們, 小段幾字）


def fill(form: str, **parts) -> str:
    """句型的 {名字} 換成 parts；沒給的（{段}）留著。"""
    for k, v in parts.items():
        form = form.replace("{" + k + "}", str(v))
    return form


def condition(rng: random.Random, sources: str, forms: str, times: str) -> str:
    """條件：時機＋句型（{來源} 換掉）。禁忌自己有時機就一定加；用共用時機的一半機率不加；沒有句型就只有時機。"""
    when = rng.choice(times.split("、") if times else TIMES)
    if not forms:
        return when
    form = rng.choice(forms.split("、")).replace("{來源}", rng.choice(sources.split("、")))
    return f"{when}{form}" if times or rng.random() < 0.5 else form


def boss(rng: random.Random, kinds: str, obj: str) -> str:
    """本體＝物件的短名＋叫法（「櫃檯的銅鈴」→「銅鈴狐妖」）；kinds 空＝全部的類。"""
    return obj.split("的")[-1] + rng.choice(BOSSES[rng.choice(kinds.split("、") if kinds else sorted(BOSSES))])


def ending(word: str, boss_: str, obj: str, who: str) -> str:
    """了結第三步（整句 Python 寫）：照了結的詞選句型，{此地} 留給遊戲換。"""
    return ENDINGS[word].replace("{本體}", boss_).replace("{物件}", obj).replace("{人}", who)


def clean(text) -> str:
    """模型寫的字：去掉空白（9b 常在「{此地}」後面多一個空格），補回拿掉的大括號（「鄰地」→「{鄰地}」）。"""
    return _MARK.sub(r"{\1}", "".join(str(text).split()))


def bit(text) -> str:
    """模型寫的小段：clean，再去掉頭尾的標點（句型自己有）。"""
    return clean(text).strip("，。！；、：")


def bit_ok(seg: str, span_: tuple[int, int], words, fake: bool, era_now: str) -> str:
    """小段合格回傳空字串，不然回傳原因：長短、只寫中文、時代；不准再提做的那件事（words）；假的那段不准拆穿自己。"""
    if reason := checks.basic([(seg, span_)], era_now):
        return reason
    if any(w and w in seg for w in words):
        return "又提到那件事"
    return "拆穿了" if fake and any(w in seg for w in LIES) else ""


def hit(text: str, images) -> bool:
    """意象有沒有寫到（母型審核第 5 關「種子命中」：其中一個就算）；不在意象表的（規則之物）照原字查。"""
    return any(IMAGES.get(w, w) in text for w in images)


def ask_ok(text: str) -> str:
    return f"「{text}」這段文字通順、讀得懂嗎？"
