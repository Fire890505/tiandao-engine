"""回應哪一個（3-4a，3-4 第 1～3 題）：等你回話的 7 種（第 7-5a 批加拜把子），這回合各從自己的狀態現列選項，讀懂從裡面挑。

選中的字交回原本判回應的地方（`side.reply`、`stage.pick`、`darks._answer`、`trap.answer`、`games.decide`、
`favours.asking`），它們照舊比字就判得對；回的不是自己那件就拿到空字串＝沒回應。
有代價的（命途的選擇、收下、還錢）讀懂挑了、原文又沒有它的字 → 跳確認（`reading.check` 的 costly）。
假說書人回空單時退回原本的字表：各系統照舊拿原文（3-4 第 4 題）。
"""
from __future__ import annotations

from dataclasses import dataclass

from ..domain import dark, favour, games, incident, plot, side, stage, trap
from . import favours, gathers

PAY_WORDS = ("還錢", "還你", "還債", "還給")


@dataclass(frozen=True)
class Offer:
    text: str
    kind: str                   # 請託、命途、收買、反咬、陷阱、天道、人情
    keys: tuple[str, ...] = ()  # 有代價的：原文要有選項全文或這些字之一
    cost: bool = False


def offers(rows: dict, sheet: dict, last: dict, now: int) -> list[Offer]:
    d, rec = sheet["dark"] or {}, last.get("incident") or {}
    out = [Offer(t, "請託") for t in (side.ACCEPT, side.DECLINE) if sheet["asking"]]
    out += [Offer(t, "命途", w, True) for t, w in stage.keyed(sheet["route"])]
    if d.get("offer") and d["state"] == dark.CUT:   # 打斷之後的是反咬（第 5-4-3 題）
        out += [Offer(dark.EXPOSE, "反咬"), Offer(dark.THREATEN, "反咬")]
    elif d.get("offer"):
        out += [Offer(dark.TAKE, "收買", dark.TAKE_WORDS, True), Offer(dark.REFUSE, "收買")]
    if s := d.get("sprung"):
        out += [Offer(plot.fill(w, s["words"]), "陷阱") for w, _ in trap.card(s["sign"]).ways]
    if rec.get("source") == incident.TIANDAO and rec.get("kind") == games.BAIT:
        take, refuse = games.replies(rec)
        out += [Offer(take["text"], "天道", games.TAKE, True), Offer(refuse["text"], "天道")]
    out += [Offer(t, "聚") for t in (gathers.YES[0], gathers.NO)] * gathers.waiting(rows)   # 拜把子（第 7-5a 批）
    return out + [Offer(t, "人情", PAY_WORDS, a is favour.PAY) for opts in favours.menu(rows, sheet, now).values() for t, a in opts]


def answer(found: list[Offer], text: str, picked: str, read: bool):
    """kind → 交給那個系統的字。點的（一字不差）直接算；讀懂挑的；假說書人空單（read 假）照舊給原文。"""
    hit = next((o for o in found if o.text == text.strip()), None) or next((o for o in found if o.text == picked), None)
    if not read and not any(o.text == text.strip() for o in found):
        return lambda kind: text
    return lambda kind: hit.text if hit and hit.kind == kind else ""
