"""事件的遊戲流程（第 9 步）：結算上回合的應對型事件、抽這回合的事件、當下型當場結算；
地點狀況與事件開的線頭（第 9b 步）。

規則在 domain/incident.py。資料來自回合開始時讀好的 rows；事件本身不另存一份，記在回合紀錄裡（delta 的 incident、quiet）。
地點狀況與線頭由 service 在回合的交易裡寫入。好感的變化直接併進 npc_changes（與 people.apply_relation_proposals 一樣）。
"""
from __future__ import annotations

import math
import random
from dataclasses import dataclass, field

from ..domain import cards, clock, effects, games, incident, items, judgment, lineage, newcomer, origins, races, space
from ..domain import atlas
from ..domain import favour, opinion
from ..domain import npc as npc_mod
from . import favours, people

SAVED_HIT = "救命"   # _result 的特別值：照 FAVOUR_CHANGE 處理
FAVOUR_CHANGE = {incident.GAIN_FAVOUR: [opinion.hit(opinion.HELP, opinion.LIKE, opinion.SMALL)],
                 incident.LOSE_FAVOUR: [opinion.hit(opinion.INSULT, opinion.LIKE, opinion.SMALL, -1)],
                 SAVED_HIT: [opinion.hit(opinion.SAVE, opinion.LIKE, opinion.GRAVE)]}


@dataclass
class Happening:
    """這回合的事件。record 記進回合紀錄；prompt 給說書人；arranged 是事件安排登場的新人物；state 是留在地點上的狀況。"""
    record: dict | None = None
    prompt: str = ""
    arranged: dict | None = None
    state: dict | None = None


@dataclass
class Outcome:
    """事件對主角的影響：新的角色卡、數值變化、事件欄、要開的線頭。"""
    sheet: dict
    changes: list[dict] = field(default_factory=list)
    events: list[str] = field(default_factory=list)
    threads: list[dict] = field(default_factory=list)
    marks: list[tuple[str, int]] = field(default_factory=list)   # 引起天道注視的事（第 18-2a 步）
    game: tuple[int, str] | None = None                          # 這回合分出勝負的棋局（第幾盤, 勝／負）


def settle(last: dict, verdict: judgment.Judgment, sheet: dict, rows: dict, npc_changes: dict[str, dict],
           rng: random.Random, *, here: str, clock_now: int, turn_no: int, player_input: str = "", hurt: int = 0) -> Outcome:
    """上回合留下的應對型事件：這回合行動類型對得上 → 依判定成敗給獎懲（成功才開線頭）；對不上＝放過，什麼都不發生
    （押貨、獵場的事放過算失敗）。天道落的子（第 18-2a 步）另外算：放過＝輸，餌看玩家寫收下還是拒絕。
    last：上一回合的回合紀錄 delta。hurt：這回合判定造成的傷，應對失敗時和事件的傷只算較重的（16o 第 10 題）。"""
    rec = last.get("incident")
    if rec and rec.get("source") == incident.TIANDAO:
        return _settle_game(rec, verdict, sheet, rng, clock_now, player_input)
    ok = incident.answered(rec, verdict)
    if ok is None:
        return Outcome(sheet)
    met = verdict.action_type in rec["answer"] and verdict.rolled
    out = _result(rec["win"] if ok else rec["lose"], rec["who"], sheet, rows, npc_changes, rng, rec.get("item"),
                  hurt=hurt if met else 0, now=clock_now)
    out.events.insert(0, f"{rec['name']}：{'應對得當' if ok else '應對失利' if met else '沒有理會，吃了虧'}")
    if ok:
        _open_thread(out, rec, rows, me=sheet["name"], here=here, clock_now=clock_now, turn_no=turn_no)
    return out


def _settle_game(rec: dict, verdict: judgment.Judgment, sheet: dict, rng: random.Random, clock_now: int,
                 player_input: str) -> Outcome:
    """天道落的子分勝負（domain/games.py）：獎懲、注視、棋譜要記的結果。"""
    won = games.decide(rec, verdict, player_input)
    sheet, mods, events, marks = games.result(rec, won, sheet, rng, clock_now)
    sheet, changes, gained = effects.gain(sheet, mods)
    head = ("沒有收下" if won else "收下了") if rec["kind"] == games.BAIT else ("化解了" if won else "沒能化解")
    return Outcome(sheet, changes, [f"{rec['name']}：{head}", *events, *gained], marks=marks,
                   game=(int(rec["game"]), games.WIN if won else games.LOSE))


def draw(rng: random.Random, rows: dict, *, sheet: dict, here: str, action: str, retreating: bool, last: dict,
         clock_now: int, taken: set[str], dead: set[str], move: games.Move | None = None,
         trip_km: int = 0, boost: dict | None = None, odds: float | None = None, only: str = "") -> Happening:
    """這回合有沒有事件、是哪一件、牽涉誰。天道落子（move，第 18-2a 步）蓋過一般事件、不擲機率。
    「認識的人」＝在場、這一生有關係紀錄的人（dead：這回合剛死的不算）。此地還在持續的狀況不會再發生一次。
    trip_km：這回合走了多遠；有移動就只挑路上的事件（地圖第二輪）。boost：天變讓某些種類比較常發生（妖獸潮，16j）。
    odds：已經擲過的機率（日常面板的途中遭遇由 service 先擲，16n 第 16 題）；None＝照 incident.chance。
    only：只挑這一類事件（走鏢、打獵，16o）。"""
    if move:
        no = max((g["no"] for g in rows["games"]), default=0) + 1   # 世界裡的第幾盤
        rec = {**incident.record(move.seed, "", incident.TIANDAO, str(no)), **move.extra()}
        return Happening(rec, games.scene(rec))
    present = [p for p in people.present(rows, here) if p["name"] not in dead]
    known = sorted(p["name"] for p in present if p["name"] in rows["relations"])
    if odds is None:
        odds = incident.chance(action, retreating=retreating, dying=sheet["status"] != "ALIVE",
                               last_had=bool(last.get("incident")), quiet=last.get("quiet", 0), trip_km=trip_km) \
            * (origins.road_boost(sheet) if trip_km else 1) * origins.night(sheet, clock_now)   # 驛馬（第 6-2 批）、聞冥夜裡（6-5d）
    can_add, land = len(present) < newcomer.MAX_PRESENT, people.local_race(rows, here)
    if rng.random() >= odds:
        return Happening()
    seed = incident.choose(
        rng, realm_lv=sheet["realm_lv"], place_type=_place_type(rows, here), season=clock.season_of(clock_now),
        known_here=bool(known), sect_near=_sect_near(rows, here), can_add=can_add,
        active=frozenset(s["name"] for s in states_here(rows, here, clock_now)),
        only=only or (incident.ROAD if trip_km > 0 else ""),
        boost={k: origins.kind_boost(sheet).get(k, 1) * (boost or {}).get(k, 1)
               for k in {*origins.kind_boost(sheet), *(boost or {})}},
        new=[incident.from_row(r) for r in rows.get("new_events", ())], land=land,
        stranger=sheet["race"] != land and (sheet["race"] == races.HUMAN or races.visible(sheet)))
    if seed is None:
        return Happening()
    who, arranged = "", None
    if seed.who == incident.KNOWN:
        if not known:
            return Happening()
        who = rng.choice(known)
    elif seed.who == incident.NEW:
        arranged = newcomer.make(rng, place=here, place_type=_place_type(rows, here), taken=taken,
                                 land=people.local_race(rows, here), town=people.town(rows, here))
        if arranged is None:
            return Happening()
        who = arranged["name"]
    rec = incident.record(seed, who, incident.WORLD)
    how = (f"只寫到這件事發生、主角還沒應對為止；choices 之一要是應對它（{'或'.join(seed.answer)}）" if seed.answer
           else "結果照【結果】寫")
    return Happening(rec, f"（{seed.kind}）{incident.scene(seed, who)}。{how}", arranged,
                     incident.place_state(seed, rec, place=here, clock_now=clock_now))


def happen_now(happening: Happening, sheet: dict, rows: dict, npc_changes: dict[str, dict], rng: random.Random, *,
               here: str, clock_now: int, turn_no: int) -> Outcome:
    """事件欄寫一行「種類：名稱」（天道落的子只寫名稱，不點明是天道）；當下型當場結算、當場開線頭（應對型要等應對成功）。"""
    rec = happening.record
    out = _result(rec["now"], rec["who"], sheet, rows, npc_changes, rng, rec.get("item"),
                  incident.DAILY_FLOOR if rec["kind"] == incident.DAILY else 0, now=clock_now) if rec["now"] else Outcome(sheet)
    head = rec["name"] if rec["source"] == incident.TIANDAO else f"{rec['kind']}：{rec['name']}"
    out.events.insert(0, head + (f"（{rec['who']}）" if rec["who"] else ""))
    if not rec["answer"]:
        _open_thread(out, rec, rows, me=sheet["name"], here=here, clock_now=clock_now, turn_no=turn_no)
    return out


def states_here(rows: dict, here: str, clock_now: int) -> list[dict]:
    """此地還在持續的狀況（燈會、妖獸出沒……）。place 是空字串的＝整個區域、州名＝整個州（天災，16j、16k）；
    天災是預先排定的，開始之前不算。"""
    state = atlas.state_of(rows.get("atlas"), rows.get("connections", []), here)
    return [s for s in rows["place_states"] if s["place"] in (here, "", (state or {}).get("name"))
            and s["started_shichen"] <= clock_now < s["ends_shichen"]]


def states_text(rows: dict, here: str, clock_now: int) -> list[str]:
    """給玩家與說書人：「燈會正熱鬧（還有 2 天）」。"""
    return [f"{s['text']}（還有 {math.ceil((s['ends_shichen'] - clock_now) / clock.SHICHEN_PER_DAY)} 天）"
            for s in states_here(rows, here, clock_now)]


def _open_thread(out: Outcome, rec: dict, rows: dict, *, me: str, here: str, clock_now: int, turn_no: int) -> None:
    """事件開的線頭。牽涉的人要已經登錄（安排登場的新人物，說書人沒寫出名字就沒有登錄）。"""
    t = incident.thread(rec, me=me, place=here, clock_now=clock_now, turn_no=turn_no)
    if t and (not rec["who"] or people.find(rows, rec["who"])):
        out.threads.append(t)
        out.events.append(f"未了的事：{t['text']}")


def _result(result: str, who: str, sheet: dict, rows: dict, npc_changes: dict[str, dict],
            rng: random.Random, rec_item: list | None = None, floor: float = 0, hurt: int = 0, now: int = 0) -> Outcome:
    """rec_item：事件記錄裡的（物品名或種類, 最少, 最多），結果是得物品時才用。now：記人情的時刻。"""
    if not result:
        return Outcome(sheet)
    if result == incident.SAVED:   # 救了他：救命（重），再記一份救命之恩（16v 第 113 題）
        out = _result(SAVED_HIT, who, sheet, rows, npc_changes, rng)
        out.events += favours.give(rows, npc_changes, who, favour.OWED, favour.LIFE, "你在路邊救了他", now)
        return out
    if result in FAVOUR_CHANGE:
        p = people.find(rows, who)
        if p is None or p["status"] != "ALIVE":
            return Outcome(sheet)
        relation, events = npc_mod.shift(who, people.changed_relation(rows, npc_changes, who), FAVOUR_CHANGE[result])
        npc_changes.setdefault(who, {})["relation"] = relation
        return Outcome(sheet, events=events)
    if result == incident.GAIN_ITEM:   # 第 8b 步：品階跟著主角境界
        what, low, high = rec_item
        sheet, fact = items.grant(rng, sheet, what, sheet["realm_lv"], rng.randint(low, high), rows["new_items"])
        return Outcome(sheet, events=[fact])
    return Outcome(*effects.gain(sheet, incident.amounts(result, sheet, rng, floor, hurt)))


def gain(result: str, sheet: dict, rows: dict, rng: random.Random, item: tuple | None = None, who: str = "",
         npc_changes: dict | None = None) -> Outcome:
    """牌的效果（16v）：和事件的結果同一套。"""
    return _result(result, who, sheet, rows, {} if npc_changes is None else npc_changes, rng, item)


def pay(token: str, sheet: dict, rows: dict, rng: random.Random) -> Outcome:
    """牌和結局寫的效果：「物品:名字」或結果的名字。"""
    if token.startswith(cards.ITEM):
        return gain(incident.GAIN_ITEM, sheet, rows, rng, (token[len(cards.ITEM):], 1, 1))
    return gain(token, sheet, rows, rng)


def _place_type(rows: dict, name: str) -> str:
    return next((l["type"] for l in rows["locations"] if l["name"] == name), "")


def _sect_near(rows: dict, here: str) -> bool:
    """附近有已知的宗門：這裡或相鄰的地點是宗門，或有宗門勢力在這些地方。"""
    near = {here} | {n["name"] for n in space.neighbors(rows["connections"], here)}
    return any(l["type"] == "宗門" and l["name"] in near for l in rows["locations"]) \
        or any(f["type"] == "宗門" and f["location"] in near for f in rows["factions"])
