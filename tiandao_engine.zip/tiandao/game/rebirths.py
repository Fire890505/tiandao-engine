"""認出轉世、殘夢、覺醒（第 6-6b 批，WHITEPAPER 第 6-6b-1～6-6b-7、6-6b2-1 題；121-16 ③④、126-3）。

- 前世只算上一世：登錄成 NPC 的他（已故或隱居，legacy.as_npc）。前世熟人＝跟他有關係、對他有原因、或親眼看過他做事的人。
- 前世的事：兩人的關係、他在場的事，最多 rebirth.FACTS 件；讀懂從清單挑玩家這句對上哪一件（「說出前世的事」）。
- 信物：上一世的遺物，在他面前拿出來（原文有它的名字）。
- 信不信擲說服（難易見 domain/rebirth.level）。信了＝相認：他對上一世的原因降一級套到這一世（小的不帶），
  記一筆相認（不加減、不淡，直接算熟人，society.familiar）；沒信＝那件事記說過了，大失敗照說服大失敗記冒犯。
- 殘夢（6-6b2）：纏絲休息時夢見跟情緣（戀人、伴侶）的一件事、聞冥聽見上一世對這一帶熟人說的一件事，一天最多一次；
  寄身第一次見到前世熟人擲 BORROW，中了前世借口說出一件事：好感 ±10、直接擲信不信。
- 覺醒（6-6b2）：殘夢的人碰到前世的人、信物、牌位（上一世最後待的城鎮裡的祠堂）、死處，各擲一次 WAKE；
  醒了上一世的記事抄一份到這一世，說書人多一行「你記得他是你上一世的某某」，信不信再容易一級。
"""
from __future__ import annotations

import random

from ..domain import evolution, hearsay, judgment, legacy, opinion, origins, rebirth, society, space
from ..domain import npc as npc_mod
from ..domain.clock import SHICHEN_PER_DAY

VERBS = {hearsay.KILL: "殺了", hearsay.HURT: "打傷了", hearsay.CRIME: "得罪了", hearsay.SAVE: "救了"}
TIES = society.BLOOD + society.PACT
LOVERS = ("戀人", "伴侶")   # 纏絲夢見的情緣
NAMED = "："   # 清單的字：「阿禾：我上一世是你的親人」
PERSON, TOKEN, TABLET, GRAVE = "前世的人", "信物", "牌位", "死處"   # 覺醒的四樣觸發
SHRINE = "祠堂"
WAKE, BORROW, SWAY = 0.2, 1 / 3, 10   # 覺醒、寄身借口的機率；借口的好感（暫定）


def past(rows: dict) -> dict | None:
    """上一世（rows["past_lives"] 最後一筆），要登錄成 NPC 了才算。"""
    life = rows["past_lives"][-1] if rows["past_lives"] else None
    return life if life and any(p["name"] == life["name"] and p["created_by"] == legacy.RETIRED_BY for p in rows["npcs"]) else None


def _bonds(rows: dict, me: dict, who: str) -> list[dict]:
    return [b for b in rows["bonds"] if {b["a"], b["b"]} == {who, me["name"]} and b["type"] in TIES]


def facts(rows: dict, me: dict, who: str) -> list[str]:
    """只有他和上一世知道的事，用主角的口吻：關係在前，事情新的在前。"""
    ties = [f"我上一世是你的{b['type']}" if b["a"] == me["name"] else f"你是我上一世的{b['type']}" for b in _bonds(rows, me, who)]
    seen = {k["event_id"] for k in rows["knows"] if (k["who"], k["session_id"], k["via"]) == (who, me["id"], hearsay.SEEN)}
    did = [f"上一世我在{e['place']}{VERBS[e['kind']]}{'你' if e['target'] == who else e['target'] + '，你在場'}"
           for e in reversed(rows["happened"]) if e["id"] in seen and e["kind"] in VERBS]
    return list(dict.fromkeys(ties + did))[:rebirth.FACTS]


def _knew(rows: dict, who: str) -> bool:
    return any(r["kind"] == opinion.KNEW for r in rows["relations"].get(who, {}).get("had", []))


def _held(rows: dict, me: dict, who: str) -> list[dict]:
    return [r for r in rows["npc_reasons"] if (r["holder"], r["toward"]) == (who, me["name"])]


def _known(rows: dict, me: dict, who: str) -> bool:
    """前世熟人。"""
    return who != me["name"] and bool(facts(rows, me, who) or _held(rows, me, who))


def _open(rows: dict, me: dict | None, who: str) -> bool:
    """還沒相認的前世熟人。"""
    return bool(me) and _known(rows, me, who) and not _knew(rows, who)


def _woke(sheet: dict, me: dict) -> bool:
    return sheet["rebirth"]["woke"] == me["id"]


def _left(rows: dict, sheet: dict, me: dict, who: str) -> list[str]:
    """還沒說過的前世的事。"""
    return [f for f in facts(rows, me, who) if f not in sheet["rebirth"]["told"].get(who, [])]


def offers(rows: dict, sheet: dict, present: list[str]) -> list[str]:
    """讀懂「說出前世的事」的清單：在場還沒相認的前世熟人，還沒說過的事。"""
    me = past(rows)
    return [f"{n}{NAMED}{f}" for n in present if _open(rows, me, n) for f in _left(rows, sheet, me, n)]


def attempt(rows: dict, sheet: dict, intent: judgment.Intent, text: str, target: dict | None) -> tuple[str, str, str] | None:
    """這回合對眼前的人說出前世的事、拿出信物：回傳（他, 說過了記哪件, 難易）；不是就 None。"""
    me = past(rows)
    if not target or intent.nature not in (judgment.SOCIAL, judgment.OBSERVE) or not _open(rows, me, who := target["name"]):
        return None
    told = sheet["rebirth"]["told"].get(who, [])
    said = intent.past.partition(NAMED)[2] if intent.past.startswith(who + NAMED) else ""
    have = {e["name"] for e in sheet["items"]}
    token = next((t["name"] for t in sheet["rebirth"]["tokens"]
                  if t["owner"] == me["name"] and t["name"] in have and t["name"] in text and t["name"] not in told), "")
    key = said if said and said not in told else token
    return (who, key, rebirth.level(origins.dream(sheet), bool(token), _woke(sheet, me))) if key else None


def settle(sheet: dict, rows: dict, tried: tuple[str, str, str], rel: dict, won: bool) -> tuple[dict, dict, list[str]]:
    """信了＝相認；沒信＝那件事記說過了。回傳（角色卡, 關係, 事件）。"""
    who, key, _ = tried
    me = past(rows)
    if not won:
        return rebirth.told(sheet, who, key), rel, [f"{who}不信你說的往事"]
    hits = [opinion.hit(r["kind"], r["axis"], opinion.LEVELS[i - 1], 1 if r["value"] > 0 else -1) for r in _held(rows, me, who)
            if r["value"] and r["kind"] not in opinion.FIXED and (i := opinion.LEVELS.index(r["size"]))
            and opinion.alive(r, rel["years"], rel["now"])]
    rel, events = npc_mod.shift(who, rel, [*hits, opinion.hit(opinion.KNEW, opinion.LIKE, opinion.GRAVE, 0)])
    return sheet, rel, [f"{who}認出你是上一世的{me['name']}", *events]


# ── 殘夢、覺醒（第 6-6b2 批）──────────────────────────────────────────────
def _plain(fact: str) -> str:
    """前世自己說的口吻：拿掉「上一世」。"""
    return fact.replace("上一世", "")


def borrow(rows: dict, sheet: dict, met: dict[str, dict], rng) -> tuple[dict, dict[str, dict], list[str]]:
    """寄身：第一次見到前世熟人擲 BORROW，中了前世借口說出一件事：好感 ±SWAY（看他對上一世的原因），直接擲信不信。"""
    me, events = past(rows), []
    if not me or not origins.has(sheet, "寄身命"):
        return sheet, met, []
    for who in [n for n in met if _open(rows, me, n) and _left(rows, sheet, me, n)]:
        if rng.random() >= BORROW:
            continue
        fact = _left(rows, sheet, me, who)[0]
        sign = 1 if sum(r["value"] for r in _held(rows, me, who)) >= 0 else -1
        check = judgment.roll_check(rng, judgment.PERSUADE, judgment.chance_for(
            sheet, judgment.PERSUADE, rebirth.level(True, False, _woke(sheet, me))))
        rel, swayed = npc_mod.shift(who, met[who], opinion.near(opinion.FATE, opinion.LIKE, sign * SWAY)
                                    + ([npc_mod.BOTCHED] if check.outcome == judgment.GREAT_FAILURE else []))
        sheet, rel, said = settle(sheet, rows, (who, fact, ""), rel, check.outcome in (judgment.SUCCESS, judgment.GREAT_SUCCESS))
        met = {**met, who: rel}
        events += [f"上一世的你借你的口對{who}說：「{_plain(fact)}」", *swayed, *said]
    return sheet, met, events


def dream(rows: dict, sheet: dict, here: str, now: int, rng) -> tuple[dict, list[str]]:
    """休息、睡覺時（一天最多一次）：纏絲夢見跟情緣的一件事，聞冥聽見上一世對這一帶熟人說的一件事。"""
    me, r, day = past(rows), sheet["rebirth"], now // SHICHEN_PER_DAY
    if not me or r["dreamt"] == day:
        return sheet, []
    if origins.has(sheet, "纏絲命"):
        who = {b["a"] if b["b"] == me["name"] else b["b"] for b in rows["bonds"] if me["name"] in (b["a"], b["b"]) and b["type"] in LOVERS}
        say = "你夢見上一世的自己對{}說：「{}」"
    elif origins.has(sheet, "聞冥命"):
        near = {here, *space.within(rows["locations"], here)}
        who = {p["name"] for p in rows["npcs"] if p["location"] in near}
        say = "你耳邊響起上一世自己的聲音，對{}說：「{}」"
    else:
        return sheet, []
    pool = [(w, f) for w in sorted(who - {me["name"]}) for f in facts(rows, me, w)]
    if not pool:
        return sheet, []
    return {**sheet, "rebirth": {**r, "dreamt": day}}, [say.format(w, _plain(f)) for w, f in [rng.choice(pool)]]


def wake(rows: dict, sheet: dict, *, here: str, met: dict, took: list[dict], rng) -> tuple[dict, list[str]]:
    """殘夢的人碰到前世的人、信物、牌位、死處，還沒擲過的各擲一次 WAKE。"""
    me, r = past(rows), sheet["rebirth"]
    if not me or r["woke"] or not origins.dream(sheet):
        return sheet, []
    body = next(p for p in rows["npcs"] if p["name"] == me["name"])
    place = next((l for l in rows["locations"] if l["name"] == here), {})
    town = lambda n: space.town_of(rows["locations"], n)   # noqa: E731
    hit = {PERSON: any(_known(rows, me, n) for n in met), TOKEN: any(t["owner"] == me["name"] for t in took),
           TABLET: place.get("type") == SHRINE and town(here) == town(me["place"]),
           GRAVE: body["status"] == "FALLEN" and body["location"] == here}
    now = [k for k, on in hit.items() if on and k not in r["tried"]]
    if not now:
        return sheet, []
    woke = me["id"] if any(rng.random() < WAKE for _ in now) else ""
    return {**sheet, "rebirth": {**r, "tried": [*r["tried"], *now], "woke": woke}}, [f"你想起了上一世：你是{me['name']}"] if woke else []


def tick(rows: dict, sheet: dict, before: dict, *, here: str, met: dict[str, dict], rested: bool, now: int,
         rng) -> tuple[dict, dict[str, dict], list[str]]:
    """這回合的殘夢和覺醒。before：回合開始的角色卡（這回合拿到的信物）。回傳（角色卡, 初見的關係, 事件）。"""
    met = familiar(rows, met)
    sheet, met, said = borrow(rows, sheet, met, rng)
    sheet, dreamt = dream(rows, sheet, here, now, rng) if rested else (sheet, [])
    sheet, woke = wake(rows, sheet, here=here, met=met, took=sheet["rebirth"]["tokens"][len(before["rebirth"]["tokens"]):], rng=rng)
    return sheet, met, said + dreamt + woke


def recall(rows: dict) -> list[dict]:
    """覺醒：上一世的記事抄一份到這一世（標「上一世」）。"""
    me = past(rows)
    return [{**n, "id": None, "thread_id": None, "rumor_id": None, "text": f"上一世：{n['text']}"[:80]}
            for n in rows["memories"] if me and n["session_id"] == me["id"]]


def scene(rows: dict, sheet: dict, present: list[str]) -> str:
    """覺醒後眼前有前世熟人，給說書人的一句。"""
    me = past(rows)
    if not me or not _woke(sheet, me):
        return ""

    def line(n):
        b = next(iter(_bonds(rows, me, n)), None)
        return f"{n}是你上一世的{b['type']}" if b and b["a"] == n else f"你上一世是{n}的{b['type']}" if b else f"{n}是你上一世認識的人"
    lines = [line(n) for n in present if _known(rows, me, n)]
    return f"。你記得{'；'.join(lines)}" if lines else ""


# ── NPC 轉世（第 7-5c 批，規則在 domain/rebirth.py）────────────────────────
def _sign(reasons: list[dict]) -> int:
    return 1 if sum(r["value"] for r in reasons) >= 0 else -1


def familiar(rows: dict, met: dict[str, dict]) -> dict[str, dict]:
    """轉世的人第一次見到你：殘夢、還沒醒、前世對這一生有原因，似曾相識 ±SWAY（醒了的原因已經帶過來）。"""
    by = {p["name"]: p for p in rows["npcs"]}
    for new, w in rebirth.lives(rows.get("ledger", [])).items():
        had = rows["relations"].get(w["body"]["名"], {}).get("had", [])
        if new in met and new in by and origins.dream(by[new]) and "醒" not in w["body"] and had:
            met = {**met, new: npc_mod.shift(new, met[new], [opinion.hit(opinion.FATE, opinion.LIKE, opinion.SMALL, _sign(had))])[0]}
    return met


def npcs(rows: dict, updates, start: int, end: int) -> None:
    """每月脈動（background.pulse）：殘夢的人跟前世熟人在同一個村鎮——第一次似曾相識 ±SWAY；
    每跨一個月擲一次 WAKE（一生一次），醒了前世的原因降一級帶過來（對你的帶那一生）。"""
    months = evolution.months(end) - evolution.months(start)
    by = {p["name"]: p for p in rows["npcs"]}
    reasons = rows.get("npc_reasons", []) + updates.reasons
    town = lambda n: space.town_of(rows["locations"], by[n]["location"])   # noqa: E731
    for new, w in rebirth.lives(rows.get("ledger", [])).items():
        p, old = by.get(new), w["body"]["名"]
        if months <= 0 or not p or p["status"] != "ALIVE" or not origins.dream(p) or p["location"] == society.AWAY:
            continue
        near = [n for n in sorted(rebirth.knew(old, rows["bonds"], reasons)) if n != new and by.get(n, {}).get("status") == "ALIVE"
                and by[n]["location"] != society.AWAY and town(n) == town(new)]
        updates.reasons += [opinion.reason(new, n, opinion.hit(opinion.FATE, opinion.LIKE, opinion.SMALL,
                                                               _sign(opinion.pair(reasons, old, n))), end)
                            for n in near if not any(r["kind"] == opinion.FATE for r in opinion.pair(reasons, new, n))]
        rng = random.Random(f"{rows['seed']}:wake:{new}:{end}")
        if near and "醒" not in w["body"] and w["id"] not in updates.woke and any(rng.random() < rebirth.WAKE for _ in range(months)):
            was = by.get(old, {})
            got = rebirth.carry(reasons + rows["relations"].get(old, {}).get("had", []), old, new, end,
                                opinion.lifespan(was.get("realm_lv", 0), was.get("race", "人族")))
            updates.reasons += [r for r in got if not r["session_id"]]
            updates.mine += [r for r in got if r["session_id"]]
            updates.woke.append(w["id"])
