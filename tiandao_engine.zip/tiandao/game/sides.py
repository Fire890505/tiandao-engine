"""支線在回合裡（WHITEPAPER 16v 第 76～79 題）：回話、辦成、放著、排隊開口。規則在 domain/side.py。
命數找上你（併章重設計）：fated 照宮抽請託、waiting 還在等你的人；回話時勸他、他聽就記一筆 society.CALLED「勸」，推掉好感降。
心事（第 9-5、9-7、9-9 題，9e-3）：confide 說出口時開口求你；在那裡「查」翻出隱情（另起一條沒期限的）；辦成了結那件狀態。"""
from __future__ import annotations

import random
from dataclasses import dataclass, field

from ..domain import cards, dark, echo, favour, home, incident, judgment, opinion, plot, route, side, society, space, stage
from ..domain import memory as m
from ..domain import npc as npc_mod
from ..domain.evolution import AWAY, GRATITUDE
from . import favours, incidents, people

REFUSED = [opinion.hit(opinion.SNUB, opinion.LIKE, opinion.SMALL, -1)]   # 推掉命數找上你的事（併章重設計第 5 題甲）


@dataclass
class Task:
    """這回合支線的變化。threads：答應的新支線；closed：線頭 id → 要改的欄位；pushes：放著推動的壓力；
    scene：辦成的事，放進【主事】；moved：辦成的是路線來的，算有碰主線。"""
    sheet: dict
    threads: list[dict] = field(default_factory=list)
    closed: dict[str, dict] = field(default_factory=dict)
    events: list[str] = field(default_factory=list)
    changes: list[dict] = field(default_factory=list)
    pushes: list[str] = field(default_factory=list)
    scene: str = ""
    moved: bool = False


def _near(rows: dict, town: str, rng: random.Random) -> str:
    near = [n["name"] for n in space.neighbors(rows["connections"], town) if space.town_of(rows["locations"], n["name"]) != town]
    return rng.choice(near) if near else ""


def _town(rows: dict, name: str) -> str:
    """這個人所在的村鎮。不在了或去了遠方是空字串。"""
    p = people.find(rows, name)
    return space.town_of(rows["locations"], p["location"]) if p and p["status"] == "ALIVE" and p["location"] != AWAY else ""


def _kin(rows: dict) -> str:
    return next((p["name"] for p in rows["npcs"] if p["created_by"] == home.FAMILY_BY and p["status"] == "ALIVE"), "")


def _queue_route(rows: dict, sheet: dict, turn_no: int, now: int, rng: random.Random) -> dict:
    """路線走到那一階，開口的人排進隊伍。同名的幾列是同一條，第一個找得到人的開口。"""
    r = sheet["route"]
    for row in side.TABLE.get(r["name"], []) if r and r["cast"] else []:
        who = _kin(rows) if row.who == side.FAMILY else r["cast"].get(row.who, "")
        town = _town(rows, who)
        if row.name in r["asked"] or not town or row.stages and stage.now(r) not in row.stages \
                or row.dark and not dark.moved_gate(sheet, r["key"], row.dark):   # 暗線:門路（第 5-4-4 題）
            continue
        near = _near(rows, town, rng)
        if near or row.place != "鄰地":
            r = {**r, "asked": [*r["asked"], row.name]}
            sheet = echo.ask({**sheet, "route": r}, side.offer(row, who, {"此地": town, "鄰地": near}, side.ROUTE, r["key"], people.find(rows, who)["gender"]), town, turn_no, now)
    return sheet


def _queue_past(rows: dict, sheet: dict, turn_no: int, now: int) -> dict:
    """家人講完往事的第三層，往事變成支線。"""
    p, who = sheet["past"], _kin(rows)
    town = _town(rows, who)
    if not town or not p["side"] or p["asked"] or p["told"] < len(p["lines"]):
        return sheet
    o = side.offer(side.TABLE[side.PAST + p["side"]][0], who, {"此地": town, "鄰地": p["near"], "鎮": p["town"]}, side.PERSON, gender=people.find(rows, who)["gender"])
    return echo.ask({**sheet, "past": {**p, "asked": True}}, o, town, turn_no, now)


def ask(rows: dict, sheet: dict, who: str, rng: random.Random) -> dict | None:
    """動作牌「開出條件」：照他的目標抽一條請託。對象不合用的句子不抽，想找主角報仇的人不開口。"""
    p, town = people.find(rows, who), _town(rows, who)
    target = p["goal_target"] if p else ""
    if not town or p["goal"] == "復仇" and target == sheet["name"]:
        return None
    near = _near(rows, town, rng)
    spot = _town(rows, target) or (space.town_of(rows["locations"], target) if any(l["name"] == target for l in rows["locations"]) else "")
    named = spot and target != sheet["name"]   # 對象是到得了的人或地方；東西、不在的人都不算
    picks = [r for r in side.TABLE.get(side.ASK + p["goal"], []) if (named or "{對象}" not in r.name) and (near or r.place != "鄰地")]
    if not picks:
        return None
    o = side.offer(rng.choice(picks), who, {"此地": town, "鄰地": near, "對象": target}, side.CARD, gender=p.get("gender", ""))
    return {**o, "ways": [{**w, "town": spot if w["town"] == target else w["town"]} for w in o["ways"]]}   # 句子寫他的名字，要去他在的地方


def fated(rows: dict, p: dict, where: str, rng: random.Random) -> dict | None:
    """命數找上你（併章重設計第 3 題丁）：照他那章的宮抽一條請託（p 是演算後的他，人可能到了你那）；沒有合用的回傳 None。"""
    town = space.town_of(rows["locations"], p["location"]) if p["location"] != AWAY else ""
    near = _near(rows, town, rng) if town else ""
    picks = [r for r in side.TABLE.get(side.FATE + where, []) if town and (near or r.place != "鄰地")]
    return side.offer(rng.choice(picks), p["name"], {"此地": town, "鄰地": near}, side.CALL, gender=p.get("gender", "")) if picks else None


def confide(rows: dict, who: str, w, rng: random.Random) -> dict | None:
    """心事說出口時開口求你（第 9-5 題，9e-3）：照心事接的支線擲一種；人情照心事輕重。只說不求的、到不了的回傳 None。"""
    p, town = people.find(rows, who), _town(rows, who)
    row = side.TABLE[side.WORRY + rng.choice(w.sides)][0] if town and w.sides else None
    near = _near(rows, town, rng) if row else ""
    if not row or row.place == "鄰地" and not near:
        return None
    o = side.offer(row, who, {"此地": town, "鄰地": near, "對象": w.call}, side.MIND, gender=p.get("gender", ""))
    spot = _town(rows, w.who) or near or town   # 對象不在到得了的地方就改鄰地
    return {**o, "ways": [{**x, "town": spot if x["town"] == w.call else x["town"]} for x in o["ways"]],
            "gain": [favour.TOKEN + w.tier], "worry": {"對": w.who, "帳": list(w.ids), "怕": w.fear, "隱": w.hidden}}


THREAD_KEYS = ("kind", "subject_kind", "subject", "text", "status", "deadline_shichen", "opened_shichen", "opened_turn", "touched_shichen", "origin", "next_step", "task")


def _reveal(out: Task, t: dict, hidden: str, now: int) -> None:
    """查到隱情（第 9-7 題、9e-3 甲）：這回合不算辦成；舊的收掉、另起一條沒有期限的，辦不辦都不算失約。"""
    out.closed[t["id"]] = {"status": m.RESOLVED, "closed_shichen": now, "result_note": "翻出隱情"}
    out.threads.append({**{k: t[k] for k in THREAD_KEYS}, "deadline_shichen": None, "touched_shichen": now,
                        "task": {**t["task"], "worry": {**t["task"]["worry"], "隱": "", "翻": hidden}}})   # 翻：人物卡寫（9e-4-4）
    out.events.append(f"翻出隱情：{hidden}")
    out.scene = f"（支線）{t['text']}，查著查著翻出一件事：{hidden}。寫到主角知道這件事為止，事還沒辦成，辦不辦由主角決定"


def _settle(t: dict, updates, now: int) -> None:
    """心事支線辦成（第 9-5、9-9 題）：那件狀態了結（帳已了、怕抵掉），記一筆已了的「心事」帳，一年內不再算這件也不從小表抽。"""
    wo, who = t["task"]["worry"], t["subject"]
    updates.settled += wo["帳"]
    updates.reasons += [opinion.reason(who, wo["怕"], opinion.hit(opinion.HELP, opinion.FEAR, opinion.GRAVE, -1), now)] if wo["怕"] else []
    updates.ledger.append({**society.owed(society.WORRY, who, wo["對"], now), "status": society.DONE, "body": {"了": t["text"]}})


def waiting(sheet: dict, threads: list[dict]) -> set[str]:
    """命數找上你的事還在等你的人：排著還沒開口、等你回話、答應了還沒辦完（併章重設計第 4 題甲）。"""
    asked = [e["side"] for e in sheet.get("echoes", []) if e.get("side")] + ([sheet["asking"]] if sheet.get("asking") else [])
    return {o["who"] for o in asked if o["origin"] == side.CALL} | {
        t["subject"] for t in threads if t["status"] == m.OPEN and t["origin"] == side.CALL}


def _heeds(rows: dict, npc_changes: dict, who: str) -> bool:
    """他聽你的勸：好感親近、信任可信以上（併章重設計第 6-1 題乙，同想報恩或追隨）。"""
    rel = people.changed_relation(rows, npc_changes, who)
    return rel["affinity"] >= GRATITUDE[0] and rel["trust"] >= GRATITUDE[1]


def _queue_owed(rows: dict, sheet: dict, npc_changes: dict, now: int, turn_no: int, rng: random.Random) -> dict:
    """你欠他的恩：隔半年他會上門請你還，請託照他的目標抽，辦成就用掉那筆恩（16v 第 111 題）。一次排一個。"""
    queued = {e["who"] for e in sheet["echoes"]} | ({sheet["asking"]["who"]} if sheet["asking"] else set())
    for name in sorted(set(rows["relations"]) - queued):
        rel, had = favours.ledger(rows, npc_changes, name)
        mine = favour.graces(had, favour.OWE)
        o = ask(rows, sheet, name, rng) if mine and now - min(f["since"] for f in mine) >= favour.GAP else None
        if o:
            favours.record(npc_changes, name, rel, [{**f, "since": now} if f in mine else f for f in had])
            o = {**o, "origin": favour.ORIGIN, "words": favour.LINES["上門"] + o["words"], "gain": [favour.REPAY]}
            return echo.ask(sheet, o, _town(rows, name), turn_no, now)
    return sheet


def _answer(out: Task, rows: dict, npc_changes: dict, updates, ctx: dict, now: int, turn_no: int, text: str) -> None:
    o = out.sheet["asking"]
    if not o:
        return
    out.sheet = {**out.sheet, "asking": None}
    told = side.advise(text) if o["origin"] == side.CALL else ""   # 勸他（併章重設計第 6 題丁）：勸了不算推掉
    if told and _heeds(rows, npc_changes, o["who"]):
        updates.ledger.append({**society.owed(society.CALLED, o["who"], ctx["life"], now), "status": society.DONE,
                               "session_id": ctx["life"], "body": {"勸": told}})
        out.events.append(f"{o['who']}把你的勸聽進去了")
    if o["origin"] == route.PLOT and side.reply(text):   # 事端的請託：答應就接下那條事端，不另開支線（第 116b-1 題甲）
        out.sheet = route.take(out.sheet, route.PLOT, o["name"], o["plot"], o["place"], route.SELF, now)
        out.events.append(f"你答應了{o['who']}，接下{o['place']}的事")
    elif side.reply(text):
        out.threads.append(side.thread(o, now, turn_no))
        out.events.append(f"未了的事：{o['name']}")
    elif o["origin"] == favour.ORIGIN and favour.graces(favours.ledger(rows, npc_changes, o["who"])[1], favour.OWE):   # 推掉還恩（第 112 題）
        owe = favour.graces(favours.ledger(rows, npc_changes, o["who"])[1], favour.OWE)
        out.events.append(favours.refuse(rows, npc_changes, updates, o["who"], min(owe, key=lambda f: favour.LEVELS.index(f["level"])), ctx, now))
    elif o["origin"] == side.CALL and not told:   # 推掉命數找上你的事：好感降（第 5 題甲），自家人照有難不幫
        rel, had = favours.ledger(rows, npc_changes, o["who"])
        out.events += favours.snub(rows, npc_changes, o["who"]) or [f"你沒有接下{o['who']}的請託"]
        if not favours.kin(rows, npc_changes, o["who"]):
            favours.record(npc_changes, o["who"], npc_mod.shift(o["who"], rel, REFUSED)[0], had)
    elif o["origin"] != side.CALL:
        out.events += [f"你沒有接下{o['who']}的請託", *favours.snub(rows, npc_changes, o["who"])]   # 自家人：有難不幫


def _left(out: Task, t: dict, updates, now: int) -> None:
    """放著到期：世界的後果。失約扣關係已經照線頭的規則算過。"""
    task = t["task"]
    out.events += [task["left"]] if task["left"] else []
    for token in task["left_by"]:
        if token.startswith(stage.PRESS):
            out.pushes.append(token[len(stage.PRESS):])
        elif token == side.GONE:
            updates.fields.setdefault(t["subject"], {}).update(location=AWAY, away_since=now)
            out.sheet = {**out.sheet, "echoes": [{**e, "who": ""} if e["who"] == t["subject"] else e for e in out.sheet["echoes"]]}


def _done(out: Task, t: dict, w: dict, rows: dict, rng: random.Random, npc_changes: dict, updates, now: int, turn_no: int, paid: bool) -> None:
    """paid：這回合受了傷或花了錢，人情升一級（16v 第 106 題）。"""
    task, line = t["task"], w["line"] or f"{w['how']}，事情辦成了"
    out.closed[t["id"]] = {"status": m.RESOLVED, "closed_shichen": now, "result_note": line[:40]}
    if task.get("worry"):
        _settle(t, updates, now)
    for token in [*([incident.LOSE_MONEY] if w["act"] == side.GIVE else []), *task["gain"]]:
        if token.startswith(stage.MARK):
            out.sheet = {**out.sheet, "scars": [*out.sheet["scars"], token[len(stage.MARK):]]}
            continue
        if token.startswith(favour.TOKEN):
            level = favour.weigh(token[len(favour.TOKEN):], dying=favours.dying(rows, t["subject"]), paid=paid or w["act"] == side.GIVE)
            out.events += favours.give(rows, npc_changes, t["subject"], favour.OWED, level, f"你辦成了他託的事：{t['text']}", now)
            continue
        if token == favour.REPAY:   # 他上門請你還的恩，還了
            rel, had = favours.ledger(rows, npc_changes, t["subject"])
            favours.record(npc_changes, t["subject"], favours.even(t["subject"], rel), favour.use(had, favour.SMALL, favour.OWE))
            out.events.append(f"欠{t['subject']}的人情還清了")
            continue
        got = incidents.gain(incident.GAIN_FAVOUR, out.sheet, rows, rng, who=t["subject"], npc_changes=npc_changes) if token == side.FAVOUR \
            else incidents.pay(token, out.sheet, rows, rng)
        out.sheet, out.changes, out.events = got.sheet, out.changes + got.changes, out.events + got.events
    if task["dark"] and dark.moved_gate(out.sheet, task["route"], task["dark"]):   # 補回那道門路，第一次照樣反撲（第 5-4-4 題）
        out.sheet = {**out.sheet, "dark": dark.mend(out.sheet["dark"], task["dark"], w["act"])}
    if task["route"]:
        out.sheet = {**out.sheet, "route": stage.push(out.sheet["route"], turn_no)}
        out.moved = True
    out.events.append(line)
    out.scene = f"（支線）{line}。寫到這件事辦成為止"


def tasks(threads: list[dict]) -> list[str]:
    """讀懂「在辦哪件請託」的清單（3-4b）：手上的請託。turn 交給 spot 的字以它開頭。"""
    return [t["text"] for t in threads if t["status"] == m.OPEN and t.get("task")]


def turn(rows: dict, sheet: dict, threads: list[dict], care, verdict: judgment.Judgment, rng: random.Random, updates, *, text: str, here: str, now: int,
         turn_no: int, spot, npc_changes: dict, paid: bool = False, ctx: dict | None = None, reply: str | None = None,
         pay: bool | None = None) -> Task:
    """一回合。threads：做過維護的線頭。spot(細節)：問模型這句是不是在辦這件事。paid：這回合受了傷或花了錢。
    ctx：賴帳寫記事、傳聞用（game/favours.py）。reply：回請託的字（3-4a，game/replies.py；沒給照原文）。
    pay：讀懂讀成付錢（3-4c；沒給照原文的付錢字）。"""
    out, ctx = Task(sheet), ctx or {"me": sheet["name"], "life": "", "here": here, "turn_no": turn_no}
    _answer(out, rows, npc_changes, updates, ctx, now, turn_no, text if reply is None else reply)
    for t in care.broken:
        if t.get("task"):
            _left(out, t, updates, now)
        if favour.REPAY in (t.get("task") or {}).get("gain", []):   # 答應還恩卻失約：恩變成怨
            out.events += favours.forfeit(rows, npc_changes, updates, t["subject"], ctx, now)
    mine = [t for t in threads if t["status"] == m.OPEN and t.get("task")]
    for t in mine:   # 主線收場，路線來的支線跟著結束，不算失約
        if t["task"]["route"] and not route.holds(sheet, t["task"]["route"]):
            out.closed[t["id"]] = {"status": m.FAILED_STATUS, "closed_shichen": now, "result_note": (t["task"]["left"] or "主線收場了")[:40]}
    if verdict.is_success or not verdict.rolled:
        town, tag = space.town_of(rows["locations"], here), cards.TAGS.get(verdict.action_type, "")
        for t in (t for t in mine if t["id"] not in out.closed):
            w = side.way(t["task"], tag, side.paying(text) if pay is None else pay, town, out.sheet["money"])
            hidden = (t["task"].get("worry") or {}).get("隱", "") if tag == side.ACTS["查"] and town in {x["town"] for x in t["task"]["ways"]} else ""
            if (w or hidden) and spot(f"{t['text']}：{'，或'.join(x['how'] for x in t['task']['ways'])}"):
                _reveal(out, t, hidden, now) if hidden else _done(out, t, w, rows, rng, npc_changes, updates, now, turn_no, paid)
                break
    live = {plot.tag(p) for p in rows.get("plots", []) if p["ended_shichen"] is None}   # 事端收場了，它的請託不來
    kept = [e for e in out.sheet["echoes"] if not (e.get("side") and (e["side"]["route"] and not route.holds(out.sheet, e["side"]["route"])
                                                                      or e["side"].get("plot", "") not in live | {""}))]
    out.sheet = _queue_past(rows, _queue_route(rows, {**out.sheet, "echoes": kept}, turn_no, now, rng), turn_no, now)
    out.sheet = _queue_owed(rows, out.sheet, npc_changes, now, turn_no, rng)
    return out
