"""人情帳在回合裡（WHITEPAPER 16v 第 87、106～113 題）：記帳、討、債、推掉和賴帳、遇險出手、人死轉帳。規則在 domain/favour.py。

ctx：{"me": 對外的名字, "life": 這一生, "here": 所在地, "turn_no": 回合}，賴帳寫記事、傳聞用。
"""
from __future__ import annotations

from dataclasses import dataclass, field

from ..domain import echo, era, favour, hearsay, home, items, opinion, party, rumors, society, space, visitors
from ..domain import memory as m
from ..domain import npc as npc_mod
from ..domain.clock import SHICHEN_PER_DAY
from . import news, people, proposals

HEIRS = society.HEIRS
TEACH = items.PILL_CULTIVATION   # 指點：修為 +15，同一顆聚氣丹（第 4-10-2 題）
WARN_DAYS = 3                    # 報信：仇家晚幾天才到（第 4-10-1 題）
FOES = ("仇家", "敵對")           # 牽線、說情不找這兩種羈絆的人


@dataclass
class Paid:
    """討人情、還債的結果。scene：放進【主事】；lead：多一個前往某地的選項。"""
    sheet: dict
    events: list[str] = field(default_factory=list)
    scene: str = ""
    lead: str = ""


def ledger(rows: dict, npc_changes: dict, name: str) -> tuple[dict, list[dict]]:
    rel = people.changed_relation(rows, npc_changes, name)
    return rel, rel.get("favours", [])


def record(npc_changes: dict, name: str, rel: dict, favours: list[dict]) -> None:
    npc_changes.setdefault(name, {})["relation"] = {**rel, "favours": favours}


def _alive(rows: dict, name: str) -> dict | None:
    p = people.find(rows, name)
    return p if p and p["status"] == "ALIVE" else None


# ── 三套規矩（第 120-2 題，實作第 1-4b 批）────────────────────────────────
EVEN = [opinion.hit(opinion.EVEN, opinion.LIKE, opinion.SMALL)]
SNUB = [opinion.hit(opinion.SNUB, opinion.LIKE, opinion.BIG, -1)]


def kin(rows: dict, npc_changes: dict, name: str) -> bool:
    """自家人（親人、伴侶、師徒、結義，society.circle）：人情不記帳。"""
    p = people.find(rows, name)
    return ledger(rows, npc_changes, name)[0].get("circle") == society.KIN or bool(p) and p["created_by"] == home.FAMILY_BY


def even(name: str, rel: dict) -> dict:
    """熟人的恩還了：不是兩清，他多一筆「有來有往」（主角那方的好感不存）。"""
    return npc_mod.shift(name, rel, EVEN)[0]


def _bother(name: str, rel: dict) -> dict:
    """向自家人開口：記一筆「又來麻煩」；小的已經記滿（opinion.CAP，再多也不算）就記大的，常開口就疏遠。"""
    small = [r for r in rel["had"] + rel["adds"] if (r["kind"], r["size"]) == (opinion.BOTHER, opinion.SMALL)
             and opinion.alive(r, rel["years"], rel["now"])]
    size = opinion.BIG if len(small) >= opinion.CAP[opinion.SMALL] else opinion.SMALL
    return npc_mod.shift(name, rel, [opinion.hit(opinion.BOTHER, opinion.LIKE, size, -1)])[0]


def snub(rows: dict, npc_changes: dict, name: str) -> list[str]:
    """自家人求你幫忙你推掉：記大的「有難不幫」。不是自家人回傳空的。"""
    if not kin(rows, npc_changes, name):
        return []
    rel, had = ledger(rows, npc_changes, name)
    record(npc_changes, name, npc_mod.shift(name, rel, SNUB)[0], had)
    return [f"{name}有難，你沒有幫"]


def _money(rows: dict, amount: int) -> str:
    return f"{amount} {era.MONEY[rows['era']['era']]}"


def give(rows: dict, npc_changes: dict, name: str, way: str, level: str, why: str, now: int) -> list[str]:
    """記一筆恩。自家人不記（只記好感原因），不在的人不記。回傳事件。
    旁邊還有別人看著就記 seen：賴掉時才會傳開（第 1-5d 批）。"""
    p = _alive(rows, name)
    if not p or kin(rows, npc_changes, name):
        return []
    rel, had = ledger(rows, npc_changes, name)
    seen = int(any(o["name"] != name for o in people.present(rows, p["location"])))
    record(npc_changes, name, rel, favour.add(had, favour.make(way, level, why, now, seen)))
    return [f"{name}欠你一份{favour.NAMES[level]}" if way == favour.OWED else f"你欠{name}一份{favour.NAMES[level]}"]


def blackmail(rows: dict, npc_changes: dict, name: str, e: dict, now: int) -> list[str]:
    """他拿你的把柄上門（news.blackmailers）：記一筆封口費，數目看那件事多大、他幾個月的工錢。"""
    p = people.find(rows, name)
    amount = favour.lend(p["realm_lv"], hearsay.HUSH_MONTHS[e["kind"]])
    rel, had = ledger(rows, npc_changes, name)
    about = e["target"] or e["kind"]
    record(npc_changes, name, rel, favour.add(had, favour.hush(amount, f"封口費（{about}那件事）", e["id"], now)))
    return [f"{name}知道{about}那件事是你做的，要 {_money(rows, amount)} 封口"]


def dying(rows: dict, name: str) -> bool:
    p = people.find(rows, name)
    return bool(p) and p["condition"] == "重傷"


# ── 賴帳（第 112 題）─────────────────────────────────────────────────────
def welsh(rows: dict, npc_changes: dict, updates, name: str, f: dict, ctx: dict, now: int, *, told: bool = True) -> str:
    """照失約扣信任（賴救命算重），留一筆不淡忘的記事。恩銷掉，受恩時有人在場就傳出去（丟面子，第 1-5d 批）、
    救命再加記恨；債不銷、標成賴掉，債主上門討（background.hostile_visit），不傳（第 120-2 題）；
    封口費賴掉：他揭穿那件事（news.expose），帳銷掉。told=False：失約已經傳過了。"""
    rel, had = ledger(rows, npc_changes, name)
    life = f["level"] == favour.LIFE
    rel, _ = npc_mod.shift(name, rel, [opinion.hit(opinion.BREAK, opinion.TRUST, opinion.GRAVE if life else opinion.BIG, -1)])
    rel = {**rel, **({"grudge": "賴了救命之恩"} if life else {})}
    debt, e = f["kind"] == favour.DEBT, next((x for x in rows.get("happened", []) if x["id"] == f["event"]), None)
    keep = debt and not f["event"]
    record(npc_changes, name, rel, [{**x, "refused": favour.WELSHED} if x == f else x for x in had] if keep else [x for x in had if x != f])
    text = f"賴了欠{name}的{favour.what(f)}" + (f"，{name}把那件事抖了出來" if e else "")
    if e:
        news.expose(rows, updates, e, name, now)
    updates.notes.append(m.note(m.NPC, name, m.BROKEN, f"{ctx['me']}{text}", clock_now=now, turn_no=ctx["turn_no"]))
    if told and not debt and f["seen"]:
        updates.rumors.append(rumors.make(rumors.BROKE, ctx["me"], target=name, place=ctx["here"], when=now, detail=text, life=ctx["life"]))
    return f"你{text}"


def refuse(rows: dict, npc_changes: dict, updates, name: str, f: dict, ctx: dict, now: int) -> str:
    """他上門你推掉、債到期說再寬限：第一次不算，恩過半年他換件事再來、債延一個月；第二次算賴帳。"""
    if f["refused"]:
        return welsh(rows, npc_changes, updates, name, f, ctx, now)
    rel, had = ledger(rows, npc_changes, name)
    later = {**f, "refused": 1, "since": now, "due": f["due"] + favour.GRACE_MONTH if f["kind"] == favour.DEBT else f["due"]}
    record(npc_changes, name, rel, [later if x == f else x for x in had])
    return favour.LINES["等等"].replace("{人}", name)


def forfeit(rows: dict, npc_changes: dict, updates, name: str, ctx: dict, now: int) -> list[str]:
    """答應還恩卻失約：恩變成怨。扣關係、傳聞已經照失約算過。"""
    owe = favour.graces(ledger(rows, npc_changes, name)[1], favour.OWE)
    return [welsh(rows, npc_changes, updates, name, min(owe, key=lambda f: favour.LEVELS.index(f["level"])), ctx, now, told=False)] if owe else []


# ── 討、還債（第 110 題）─────────────────────────────────────────────────
def _fill(text: str, p: dict, sheet: dict, amount: int = 0, rows: dict | None = None, more: dict | None = None) -> str:
    """more：{誰}{事}（第 4-10 題）。"""
    r = sheet["route"]
    text = (text.replace("{人}", p["name"]).replace("{地}", r["place"] if r else "").replace("{仇}", sheet["standoff"])
            .replace("{數}", _money(rows, amount) if rows else ""))
    for k, v in (more or {}).items():
        text = text.replace("{" + k + "}", v)
    return text


# ── 第 4-10 題新增的換法：牽線、說情、保密找誰，報信的帳 ──────────────────────
def _ties(rows: dict, name: str) -> set[str]:
    return {b["b"] if b["a"] == name else b["a"] for b in rows["bonds"] if name in (b["a"], b["b"]) and b["type"] not in FOES}


def _intro(rows: dict, p: dict) -> dict | None:
    """牽線：他的羈絆裡你還不認識、還活著的人，境界高的優先（第 4-10-3 題）。"""
    them = [q for q in rows["npcs"] if q["name"] in _ties(rows, p["name"]) and q["status"] == "ALIVE" and q["name"] not in rows["relations"]]
    return max(them, key=lambda q: q["realm_lv"], default=None)


def _plead(rows: dict, p: dict) -> str:
    """說情：他的羈絆裡對你冷淡以下、對你最差的人（第 4-10-4 題）。"""
    rels = rows["relations"]
    them = [n for n in _ties(rows, p["name"]) if n in rels and rels[n]["affinity"] <= hearsay.COLD and _alive(rows, n)]
    return min(them, key=lambda n: rels[n]["affinity"], default="")


def _secret(rows: dict, name: str) -> dict | None:
    """保密：他知道、還沒傳開、知道是你的事裡最重的一件；本來就替你瞞的人不算（第 4-10-5 題）。"""
    life = rows.get("life", "")
    knows = [k for k in rows["knows"] if k["session_id"] == life]
    his = {k["event_id"] for k in knows if k["who"] == name and k["knows_who"]} - hearsay.public(knows)
    if not his or name in news._quiet(rows, {}, life):
        return None
    return max((e for e in rows["happened"] if e["id"] in his and e["secret"] and e["kind"] in hearsay.KINDS), key=lambda e: hearsay.HUSH_MONTHS.get(e["kind"], 0), default=None)


def _watching(rows: dict) -> list[dict]:
    """替你留意風聲、還活著的人的帳（報信，第 4-10-1 題）。"""
    return [l for l in rows.get("ledger", []) if (l["kind"], l["session_id"], l["status"]) == (society.WATCH, rows.get("life", ""), society.OPEN)
            and _alive(rows, l["a"])]


def warn(rows: dict, foe, end: int) -> tuple:
    """帶敵意的人這回合要上門，又有人替你留意：他這回合先不到，晚 WARN_DAYS 天才可能再來。
    回傳（仇家, （句子, 仇家名字, 到那時以前不來, 用掉的帳 id）或空的）。"""
    w = _watching(rows)[:1] if foe else []
    if not w:
        return foe, ()
    line = favour.LINES["報信"].replace("{人}", w[0]["a"]).replace("{仇}", foe.name).replace("{天}", str(WARN_DAYS))
    return None, (line, foe.name, end + WARN_DAYS * SHICHEN_PER_DAY, w[0]["id"])


def _more(rows: dict, p: dict, key: str = "") -> dict:
    e = _secret(rows, p["name"])
    return {"誰": (_intro(rows, p) or {}).get("name", "") if key == "牽線" else _plead(rows, p), "事": e and (e["target"] or e["kind"]) or ""}


def _can(p: dict, sheet: dict, town: str, rows: dict) -> dict[str, bool]:
    """他換得到哪幾種（辦法 → 能不能）。"""
    r = sheet["route"]
    return {"錢": not p["hidden_power"], "路": bool(r and r["place"] and r["place"] != town), "擋": bool(sheet["standoff"]),
            "伴": len(sheet["party"]) < party.MAX and p["name"] not in party.names(sheet),
            "指點": p["realm_lv"] > sheet["realm_lv"], "牽線": bool(_intro(rows, p)), "報信": all(l["a"] != p["name"] for l in _watching(rows)),
            "說情": bool(_plead(rows, p)), "保密": bool(_secret(rows, p["name"]))}


def menu(rows: dict, sheet: dict, now: int = 0, npc_changes: dict | None = None) -> dict[str, list[tuple[str, favour.Ask]]]:
    """在場的人 → 這回合能做的（選項, 辦法）：他欠你恩換得到的事（自家人看好感；重的排前面，不限件數，第 4-10-6 題）、
    到期的債還錢或寬限（賴掉的只能還）。"""
    here = sheet["location"]
    town = space.town_of(rows["locations"], here)
    out = {}
    for p in people.present(rows, here):
        rel, book = ledger(rows, npc_changes or {}, p["name"])
        level = favour.close(rel["affinity"]) if kin(rows, npc_changes or {}, p["name"]) else favour.top(book)
        can = _can(p, sheet, town, rows) if level else {}
        fits = [a for a in reversed(favour.upto(level)) if can[a.key]]
        owed = [(_fill(a.text, p, sheet, f["amount"], rows), a) for f in favour.due(book, now)[:1] for a in (favour.PAY, favour.WAIT)
                if a is favour.PAY and sheet["money"] >= f["amount"] or a is favour.WAIT and f["refused"] < favour.WELSHED]
        if fits or owed:
            more = _more(rows, p) if fits else {}
            out[p["name"]] = [(_fill(a.text, p, sheet, more=more), a) for a in fits] + owed
    return out


def asking(rows: dict, sheet: dict, text: str, now: int = 0) -> tuple[str, favour.Ask] | None:
    """玩家按的是不是討人情、還債的選項：（誰, 辦法）。"""
    return next(((name, a) for name, opts in menu(rows, sheet, now).items() for t, a in opts if t == text.strip()), None)


def redeem(rows: dict, sheet: dict, ask: tuple[str, favour.Ask], npc_changes: dict, now: int, updates=None, ctx: dict | None = None) -> Paid:
    """他還你人情、你還他錢或求寬限：照辦法辦。"""
    name, a = ask
    p, out = people.find(rows, name), Paid(sheet)
    rel, had = ledger(rows, npc_changes, name)
    if a.key in ("還錢", "寬限"):
        f = favour.due(had, now)[0]
        if a.key == "寬限":
            out.events.append(refuse(rows, npc_changes, updates, name, f, ctx, now))
        else:
            out.sheet = {**sheet, "money": sheet["money"] - f["amount"]}
            if sheet["standoff"] == name:   # 上門討債的人拿到錢就走
                out.sheet = {**out.sheet, "standoff": "", "spared": {**sheet["spared"], name: now + visitors.SPARE}}
            record(npc_changes, name, rel, [x for x in had if x != f])
            if f["event"] and updates is not None:   # 封口費：他收了錢，往後替你瞞著（news._quiet）
                updates.ledger.append({**society.owed(society.HUSH, name, ctx["life"], now), "session_id": ctx["life"], "event_id": f["event"]})
            out.events.append(_fill(a.fact, p, sheet, f["amount"], rows))
        out.scene = f"（人情）{out.events[0]}。寫到這件事說定為止，不用判定"
        return out
    more = _more(rows, p, a.key)
    fact = _fill(a.fact, p, sheet, more=more)
    if a.key == "錢":
        amount = favour.lend(p["realm_lv"], 1 if a.level == favour.SMALL else 3)
        out.sheet = {**sheet, "money": sheet["money"] + amount}
        out.events.append(f"得到 {_money(rows, amount)}")
    elif a.key == "路":
        out.lead = f"前往{sheet['route']['place']}"
    elif a.key == "擋":
        out.sheet = {**sheet, "standoff": "", "spared": {**sheet["spared"], sheet["standoff"]: now + visitors.SPARE}}
    elif a.key == "伴":
        out.sheet = party.add(sheet, name, party.COMPANION, now)
    elif a.key == "指點":
        out.sheet = {**sheet, "cultivation": min(100, sheet["cultivation"] + TEACH)}
        out.events.append(f"修為 +{TEACH}")
    elif a.key in ("牽線", "說情"):   # 他看這人的面子：好感記一筆小的引見、大的說情
        q = more["誰"]
        hit = opinion.hit(opinion.INTRO, opinion.LIKE, opinion.SMALL) if a.key == "牽線" else opinion.hit(opinion.PLEAD, opinion.LIKE, opinion.BIG)
        qrel, qhad = ledger(rows, npc_changes, q)
        record(npc_changes, q, npc_mod.shift(q, qrel, [hit])[0], qhad)
        where = people.find(rows, q)["location"]
        if a.key == "牽線" and where not in (sheet["location"], society.AWAY):
            out.lead = f"前往{where}"
    elif a.key in ("報信", "保密"):   # 記在帳上：報信等人上門時用（warn），保密照收了封口費的人替你瞞（news._quiet）
        e = _secret(rows, name) if a.key == "保密" else None
        updates.ledger.append({**society.owed(society.HUSH if a.key == "保密" else society.WATCH, name, ctx["life"], now),
                               "session_id": ctx["life"], "event_id": e["id"] if e else ""})
    if kin(rows, npc_changes, name):
        record(npc_changes, name, _bother(name, rel), had)
        out.events.insert(0, f"{fact}（{name}幫了你）")
    else:
        record(npc_changes, name, even(name, rel), favour.use(had, a.level))
        out.events.insert(0, f"{fact}（{name}還了你的人情）")
    out.scene = f"（人情）{fact}。寫到這件事辦成為止，不用判定"
    return out


def view(rows: dict, sheet: dict) -> dict[str, list[str]]:
    """前端：在場又欠你恩的人 → 選項（債的選項直接放進回合的選項）。"""
    return {name: [t for t, a in opts if a.level] for name, opts in menu(rows, sheet).items() if any(a.level for _, a in opts)}


def dues(rows: dict, sheet: dict, now: int, npc_changes: dict) -> list[str]:
    """這回合的選項：在場的人的債到期了，還錢或求寬限。"""
    return [t for opts in menu(rows, sheet, now, npc_changes).values() for t, a in opts if not a.level]


# ── 主動的部分（第 111 題）───────────────────────────────────────────────
def chase(rows: dict, sheet: dict, npc_changes: dict, updates, ctx: dict, now: int) -> tuple[dict, list[str]]:
    """債到期他上門（排進回音的隊伍）；過了寬限還沒還算推掉一次。回傳（角色卡, 事件）。"""
    events, queued = [], {e["who"] for e in sheet["echoes"]}
    for name in sorted(rows["relations"]):
        p = _alive(rows, name)
        for f in favour.due(ledger(rows, npc_changes, name)[1], now) if p else []:
            if f["refused"] == favour.WELSHED:   # 賴掉的：他自己找上門（background.hostile_visit）
                continue
            if now >= f["due"] + favour.GRACE_MONTH:
                events.append(refuse(rows, npc_changes, updates, name, f, ctx, now))
            elif name not in queued and p["location"] != sheet["location"] and now - f["since"] >= favour.GRACE_MONTH:
                rel, had = ledger(rows, npc_changes, name)
                record(npc_changes, name, rel, [{**x, "since": now} if x == f else x for x in had])
                sheet = echo.add(sheet, [(_fill(favour.LINES["討債"], {"name": "{人}"}, sheet, f["amount"], rows), name)], ctx["here"], ctx["turn_no"], now,
                                 due=f["due"])
                queued.add(name)
    return sheet, events


def rescue(rows: dict, before: dict, sheet: dict, npc_changes: dict, now: int) -> tuple[dict, list[str], str]:
    """你遇險時，在場又欠你大恩以上的人（或親近你的自家人）出手一次：瀕死拉回來、剛找上門的仇家替你擋下。
    回傳（角色卡, 事件, 被擋走的仇家）。"""
    foe = sheet["standoff"] if sheet["standoff"] != before["standoff"] else ""
    risk = sheet["status"] == "DYING" and before["status"] == "ALIVE"

    def able(name):
        rel, had = ledger(rows, npc_changes, name)
        return (favour.close(rel["affinity"]) if kin(rows, npc_changes, name) else favour.top(had)) in (favour.BIG, favour.LIFE)
    helper = next((p for p in people.present(rows, sheet["location"]) if (risk or foe) and p["name"] != sheet["standoff"] and able(p["name"])), None)
    if not helper:
        return sheet, [], ""
    rel, had = ledger(rows, npc_changes, helper["name"])
    if kin(rows, npc_changes, helper["name"]):   # 自家人出手不記帳，也不算你開口
        why = f"{helper['name']}出手救了你"
    else:
        record(npc_changes, helper["name"], even(helper["name"], rel), favour.use(had, favour.BIG))
        why = f"{helper['name']}還了你的人情"
    if risk:
        line = favour.LINES["救命"].replace("{人}", helper["name"])
        return {**sheet, "status": "ALIVE", "hp": max(1, sheet["hp_max"] // 10)}, [f"{line}（{why}）"], ""
    line = _fill(favour.LINES["擋人"], helper, sheet)
    return {**sheet, "standoff": "", "spared": {**sheet["spared"], foe: now + visitors.SPARE}}, [f"{line}（{why}）"], foe


def inherit(rows: dict, npc_changes: dict, died: set[str], notes: list | None = None, now: int = 0, turn_no: int = 0) -> list[str]:
    """人死了，帳轉給還活著的親人或徒弟，照 favour.lower 隔代降級；沒有人接就銷帳（第 108、125-2、126-2 題）。
    降完銷掉的沉成舊聞：這一生留一筆記事（notes），照記事的規矩淡忘。"""
    events = []
    for name in sorted(died):
        rel, had = ledger(rows, npc_changes, name)
        if not had:
            continue
        record(npc_changes, name, rel, [])
        heir = society.heir(rows["bonds"], name, {p["name"] for p in rows["npcs"] if p["status"] == "ALIVE"})
        if heir:
            hrel, hhad = ledger(rows, npc_changes, heir)
            for f in had:
                got = favour.lower(f, f"{name}生前：{f['why']}")
                if got:
                    hhad = favour.add(hhad, got)
                elif notes is not None:
                    text = f"{name}欠你的{favour.what(f)}" if f["way"] == favour.OWED else f"你欠{name}的{favour.what(f)}"
                    notes.append(m.note(m.NPC, heir, m.NEWS, f"{text}，傳到{heir}已經沒人提了", clock_now=now, turn_no=turn_no))
            record(npc_changes, heir, hrel, hhad)
            events.append(f"{name}的人情帳，往後由{heir}記著")
    return events


def bequeath(rows: dict, npc_changes: dict, updates, life: str, name: str, gone: set[str]) -> list[str]:
    """主角死了（第 6-6a-1 題）：這一生的人情帳照 inherit 的規矩轉給還活著的親人或徒弟，記成 NPC 之間的帳（updates.ledger）；
    沒有人接、降完銷掉的就了結。gone：這回合死的人。回傳事件。"""
    def alive(n):
        return n not in gone and _alive(rows, n)
    heir = next((b[k] for b in rows["mine"] for k, other in (("a", "b"), ("b", "a")) if b[other] == life
                 and b["type"] in HEIRS[other] and alive(b[k])), "")
    events = []
    for who in sorted(set(rows["relations"]) | set(npc_changes)):
        rel, had = ledger(rows, npc_changes, who)
        if not had:
            continue
        record(npc_changes, who, rel, [])
        got = [g for f in had if (g := favour.lower(f, f"{name}生前：{f['why']}"))] if heir and who != heir and alive(who) else []
        updates.ledger += [{**favour.row(g, who, heir), "session_id": ""} for g in got]
        if got:
            events.append(f"{name}和{who}的人情帳，往後由{heir}記著")
    return events


def proposed(rows: dict, sheet: dict, verdicts: list, npc_changes: dict, *, ok: bool, paid: bool, asked: bool, now: int) -> tuple[dict, list[str]]:
    """模型提的人情（第 113 題）：欠你、借你要這回合判定成功；欠你的輕重照第 106 題算；你欠一律小恩；
    借你記一筆債、錢先拿到手；還了用掉他欠你最輕的那筆（這回合按了討人情的就不再算）。"""
    events = []
    for v in (v for v in verdicts if v.accepted and v.kind == proposals.FAVOUR):
        name, way, why = v.name, v.record["way"], v.record["why"] or "這回合的事"
        p = _alive(rows, name)
        if not p:
            continue
        rel, had = ledger(rows, npc_changes, name)
        if way == favour.OWED and ok and not any(f["way"] == way and f["since"] == now for f in had):   # 這回合已經記過（辦成請託）就不重記
            events += give(rows, npc_changes, name, way, favour.weigh(favour.SMALL, dying=dying(rows, name), paid=paid), why, now)
        elif way == favour.OWE:
            events += give(rows, npc_changes, name, way, favour.SMALL, why, now)
        elif way == favour.BORROW and ok and not p["hidden_power"] and kin(rows, npc_changes, name):   # 自家人借錢就是給
            amount = favour.lend(p["realm_lv"])
            sheet = {**sheet, "money": sheet["money"] + amount}
            record(npc_changes, name, _bother(name, rel), had)
            events.append(f"{name}給了你 {_money(rows, amount)}")
        elif way == favour.BORROW and ok and not p["hidden_power"] and not [f for f in had if f["kind"] == favour.DEBT]:
            amount = favour.lend(p["realm_lv"])
            sheet = {**sheet, "money": sheet["money"] + amount}
            record(npc_changes, name, rel, favour.add(had, favour.debt(amount, why, now)))
            events.append(f"{name}借你 {_money(rows, amount)}，說好一年內還")
        elif way == favour.REPAID and not asked and favour.graces(had):
            record(npc_changes, name, even(name, rel), favour.use(had, favour.SMALL))
            events.append(f"{name}還了你的人情")
    return sheet, events
