"""NPC 對你的做法（第 7-2b 批，WHITEPAPER 121-9、㉓～㉝；數字暫定）。牌在 rules/content/deeds.txt，抽法同 chatter（deck.pool）。

- 見過你、對你敵視、冷淡或友善以上的人；你不在場時跟世界脈動一起每跨一個月一輪，一輪最多 CAP 人、每人一張（㉔）。
- 你在場（㉖）：眼前的人和同處的人最多 HERE 個，每人隔一個月才抽；抽到的是候選，跟牌同一級，被挑中那回合才結算。
  通風、雇人在你面前做不了，在場不抽。
- 同一種做法每人一年一次：帳上記一筆「做法」（society.DEED），body 寫做了哪種。
- 結算都接現有的路：告官 identity.accuse（㉙）、壞話 小傳聞（㉘）、要脅 favours.blackmail（leverage，㉚）、
  雇人 受託（㉗）、上門 目標改向你復仇、通風 background.hostile_visit 當作同處一個月（㉛）、示警 society.WATCH（㉜）、
  消息 plot.hint 指的地方（㉝）。通風、雇人你不會知道，不給一行。
- 命數找上你、好感低（併章重設計第 3 題丁）：fated 只抽條件有「宮」的牌（平常沒有「宮」抽不到），文字不寫主詞，由 service._faced 接在怎麼來後面。
"""
from __future__ import annotations

import random
from dataclasses import dataclass, field

from ..config import PROJECT_ROOT
from ..domain import (atlas, crime, deck, favour, hearsay, identity, npc, opinion, pending, plot, proxy, reputation, route, rumors, schedule,
                      society, space, visitors)
from ..domain.chatter import LABELS
from ..domain.clock import SHICHEN_PER_MONTH, SHICHEN_PER_YEAR
from ..domain.evolution import MAX_SEGMENTS, months
from . import news, plots

KINDS = ("告官", "壞話", "要脅", "雇人", "上門", "通風", "示警", "消息")
CAP, HERE = 20, 3
FEAR = {npc.AWED: "畏懼", npc.WARY: "忌憚", "": "不怕"}
HUNTERS, ALLY, QUIET = ("復仇", "宿敵"), ("友善", "親近"), ("通風", "雇人")
CRUEL_KINDS = (opinion.ATTACK, opinion.BLOODY, opinion.HEARD)                 # 壞話方向（㉘）：其餘照信義、仁善
FAITH_KINDS = (opinion.BREAK, opinion.LIE, opinion.BETRAY)

DECK = deck.read(PROJECT_ROOT / "rules" / "content" / "deeds.txt")
assert all(c.who == "對你" and c.result.startswith("做:") and c.result[2:] in KINDS for c in DECK), "做法牌的結果寫錯了"


@dataclass
class Scene:
    """在場那半：ask 是候選；被挑中才有 scene（放進【主事】）和 lines。"""
    ask: schedule.Ask | None = None
    scene: str = ""
    lines: list[str] = field(default_factory=list)


def kind(c: deck.Card) -> str:
    return c.result[2:]


def what(e: dict) -> str:
    """{那件事}。"""
    head = {hearsay.KILL: "殺", hearsay.HURT: "傷"}.get(e["kind"], "")
    return f"{head}{e['target']}的事" if head else f"{'、'.join(e['detail'].get('crimes') or ['犯'])}的事"


def mine(rows: dict, life: str) -> list[dict]:
    return [l for l in rows.get("ledger", []) if l["session_id"] == life and l["status"] == society.OPEN]


def leverage(rows: dict, life: str) -> dict[str, dict]:
    """抽到要脅、還沒上門要過封口費的人 → 那件事（換掉第 1-5d 批每回合自動排的 news.blackmailers）。"""
    happened = {e["id"]: e for e in rows.get("happened", [])}
    asked = {(n, f["event"]) for n, r in rows.get("relations", {}).items() for f in r.get("favours", []) if f.get("event")}
    return {l["a"]: happened[l["event_id"]] for l in mine(rows, life) if l["kind"] == society.DEED
            and l["body"].get("做") == "要脅" and l["event_id"] in happened and (l["a"], l["event_id"]) not in asked}


def _desk(rows: dict, updates, sheet: dict, templates: list[dict], *, now: int, skip: set[str], rng: random.Random):
    """兩半共用：facts(p) → （條件, 空位）、cards(p, when, drop) → 可抽的牌、play(sheet, p, card, got, when) → （角色卡, 一行）。
    play 回傳的一行：None＝雇人挑不到人（改抽別張），""＝你不會知道。"""
    life, me, lv = rows["life"], sheet["name"], rows.get("my_lv", sheet["realm_lv"])
    alive = [p for p in rows["npcs"] if p["status"] == "ALIVE"]
    rels = rows["relations"]
    happened = {e["id"]: e for e in rows["happened"] if e["session_id"] == life}
    knows = [k for k in rows["knows"] if k["session_id"] == life]
    like = society.liking(rows["npcs"], rows["bonds"], rows.get("npc_reasons", []), now, rows.get("factions", []))
    fear = society.liking(rows["npcs"], rows["bonds"], rows.get("npc_reasons", []), now, axis=opinion.FEAR)
    r_ = sheet.get("route")
    rec, t = plots.case(rows, templates, r_["key"]) if r_ and r_["kind"] == route.PLOT else (None, None)
    hint = plot.hint(rec, t, sheet, plots.gone(rows)) if t else {}

    def town(p: dict) -> str:
        return space.town_of(rows["locations"], p["location"])

    def book() -> list[dict]:
        return mine({"ledger": rows.get("ledger", []) + updates.ledger}, life)

    def hunters() -> list[dict]:
        hired = {l["a"] for l in book() if l["kind"] == society.HIRED}
        return [q for q in alive if visitors.reason(q, me) in HUNTERS or q["name"] in hired]

    def nation(p: dict) -> dict | None:
        state = atlas.state_of(rows.get("atlas"), rows["connections"], p.get("away_from") or p["location"]
                               if p["location"] == society.AWAY else p["location"])
        return crime.nation(rows["factions"], state["nation"] if state else "")

    def crimes(p: dict) -> list[tuple]:
        """㉙：他知道、當時沒人看見的殺人（事發那一刻沒有人知道＝沒記通緝），在他那國有罪、還沒人告過。"""
        told = {l["event_id"] for l in book() if l["kind"] == society.DEED and l["body"].get("做") == "告官"}
        seen = {k["event_id"] for k in knows if k["event_id"] in happened and k["clock_shichen"] == happened[k["event_id"]]["clock_shichen"]}
        law = nation(p)
        punish = crime.punish(crime.code(crime.traits_of(law)), [crime.KILL])
        return [(happened[k["event_id"]], law, *punish[1:]) for k in knows if k["who"] == p["name"] and k["knows_who"]
                and k["event_id"] in happened and happened[k["event_id"]]["kind"] == hearsay.KILL
                and k["event_id"] not in seen | told and punish[1] > 0]

    def foe(p: dict, r: dict, ally: bool) -> str:
        """他認得（同村鎮或有關係）的仇家；敵視冷淡要偏向那人、友善以上要偏向你（darks._leans 的比法）。"""
        mine_ = r["affinity"] + opinion.SIZES[opinion.BIG] * sum(f["way"] == favour.OWED for f in r.get("favours", []))
        ties = {b["b"] if b["a"] == p["name"] else b["a"] for b in rows["bonds"] if p["name"] in (b["a"], b["b"])}
        return next((q["name"] for q in hunters() if q["name"] != p["name"]
                     and (q["name"] in ties or town(q) == town(p) != society.AWAY)
                     and (like(p["name"], q["name"]) + fear(p["name"], q["name"]) > mine_) != ally), "")

    def taker(p: dict) -> str:
        """㉗：當地現成的人，境界不低於你、逐利或野心高、對你不到友善、還沒受託。"""
        hired = {l["a"] for l in book() if l["kind"] == society.HIRED}
        pool = sorted(q["name"] for q in alive if q["name"] not in skip | hired | {p["name"]} and town(q) == town(p) != society.AWAY
                      and q["realm_lv"] >= sheet["realm_lv"] and (q["goal"] == "逐利" or npc.trait_level(q["ambition"]) == "高")
                      and rels.get(q["name"], {}).get("affinity", 0) < proxy.FAVOR_AT)
        return rng.choice(pool) if pool else ""

    def facts(p: dict) -> tuple[dict, dict]:
        """抽牌的條件、要填的空位。"""
        r = rels[p["name"]]
        layer = npc.tier(r["affinity"], npc.AFFINITY_TIERS)
        sins, secret = crimes(p), news.blackmailers({**rows, "ledger": rows.get("ledger", []) + updates.ledger}, life).get(p["name"])
        hunter = foe(p, r, layer in ALLY)
        clue = bool(hint.get("線索地")) and space.town_of(rows["locations"], hint["線索地"]) == town(p)
        know = ("罪",) * bool(sins) + ("秘密",) * bool(secret) + ("仇家",) * bool(hunter) + ("線索",) * clue
        return ({"層": (layer,), "怕": (FEAR[npc.dread(r, p, lv)],), "知": know,
                 "甲": (*(f"{v}{npc.trait_level(p[k])}" for k, v in LABELS.items()), p["goal"])},
                {"罪": sins[0] if sins else None, "秘密": secret, "仇家": hunter})

    def cards(p: dict, when: int, drop: tuple = ()) -> list[deck.Card]:
        """同一種做法每人一年一次。"""
        cool = {l["body"].get("做") for l in book() if l["kind"] == society.DEED and l["a"] == p["name"]
                and when - l["clock_shichen"] < SHICHEN_PER_YEAR}
        return [c for c in DECK if kind(c) not in cool and kind(c) not in drop]

    def row(kind_: str, p: dict, when: int, until: int, event_id: str = "", **body) -> dict:
        return {**society.owed(kind_, p["name"], life, when), "session_id": life, "event_id": event_id,
                "deadline_shichen": until, "body": body}

    def play(sheet: dict, p: dict, card: deck.Card, got: dict, when: int) -> tuple[dict, str | None]:
        k, slots, event = kind(card), {"甲": p["name"], "仇家": got["仇家"]}, ""
        if k == "告官":
            e, law, amount, blood = got["罪"]
            event, country, name = e["id"], (law or {}).get("name", ""), e["detail"].get("name") or me
            sheet = identity.accuse(sheet, identity.own_name(sheet) if name == identity.STRANGER else name, amount, when,
                                    blood=blood, nation=country)
            updates.knows.append(hearsay.know(e, country or "官府", when, via=p["name"]))   # 官府成了知道的人
            slots["那件事"] = what(e)
        elif k == "要脅":
            event, slots["那件事"] = got["秘密"]["id"], what(got["秘密"])
        elif k == "雇人":
            slots["打手"] = taker(p)
            if not slots["打手"]:
                return sheet, None
            updates.ledger.append(row(society.HIRED, {"name": slots["打手"]}, when, when + SHICHEN_PER_YEAR))
        elif k == "上門":
            updates.fields.setdefault(p["name"], {}).update(goal="復仇", goal_target=me)
        elif k == "示警":
            updates.ledger.append(row(society.WATCH, p, when, None))
        elif k == "消息":
            slots["消息"] = f"這件事接下來要{hint['做法']}{hint['線索地']}"
        elif k == "壞話":
            true = next((happened[x["event_id"]] for x in knows if x["who"] == p["name"] and x["knows_who"]
                         and happened.get(x["event_id"], {}).get("kind") in hearsay.LOUD
                         and x["event_id"] not in hearsay.public(knows + updates.knows)), None)
            if true:
                news.expose(rows, updates, true, p["name"], when)
            else:
                worst = min((h for h in rels[p["name"]]["had"] if h["axis"] == opinion.LIKE and h["value"] < 0),
                            key=lambda h: h["value"], default=None)
                axis = (reputation.CRUEL if worst and worst["kind"] in CRUEL_KINDS
                        else reputation.HONOUR if worst and worst["kind"] in FAITH_KINDS else reputation.KIND)
                updates.rumors.append(rumors.make(rumors.SLANDER, identity.own_name(sheet), target=p["name"], place=town(p),
                                                  when=when, detail=axis, life=life))
        until = when + (SHICHEN_PER_MONTH if k == "通風" else SHICHEN_PER_YEAR)
        updates.ledger.append(row(society.DEED, p, when, until, event, 做=k, **({"仇家": got["仇家"]} if k == "通風" else {})))
        text = card.text
        for key, v in slots.items():
            text = text.replace("{" + key + "}", v or "")
        return sheet, "" if k in QUIET else text + (f"（{(got['罪'][1] or {}).get('name') or '官府'}通緝你）" if k == "告官" else "")

    return facts, cards, play


def _open(rows: dict, p: dict) -> bool:
    """見過你、不是中立的活人。"""
    r = rows["relations"].get(p["name"])
    return p["status"] == "ALIVE" and bool(r) and bool(r.get("met", 1)) and npc.tier(r["affinity"], npc.AFFINITY_TIERS) != "中立"


def turn(rows: dict, updates, sheet: dict, templates: list[dict], *, start: int, end: int, skip: set[str],
         turn_no: int) -> tuple[dict, list[str]]:
    """start 到 end 跨過的每個月，不在場的人對你的做法。回傳（角色卡, 給你的幾行）。skip：在場的、這回合動過的人。"""
    n = min(MAX_SEGMENTS, months(end) - months(start))
    if n <= 0 or not rows["life"]:
        return sheet, []
    rng = random.Random(f"{rows['seed']}:deeds:{start}:{end}")
    facts, cards, play = _desk(rows, updates, sheet, templates, now=end, skip=skip, rng=rng)
    lines = []
    for i in range(n):
        when = start + (end - start) * (i + 1) // n
        people = [p for p in rows["npcs"] if p["name"] not in skip and _open(rows, p)]
        for p in rng.sample(people, min(CAP, len(people))):
            need, got = facts(p)
            pile = cards(p, when)
            while pile and (top := deck.pool(pile, need)):
                sheet, text = play(sheet, p, rng.choice(top), got, when)
                if text is not None:
                    lines += [text] if text else []
                    break
                pile = [c for c in pile if kind(c) != "雇人"]
    return sheet, lines


def fated(rows: dict, updates, sheet: dict, templates: list[dict], who: str, where: str, *, now: int,
          rng: random.Random) -> tuple[dict, str | None]:
    """命數找上你、對你好感低（併章重設計第 3 題丁）：照他那章的宮抽一張條件有「宮」的牌，當場結算。沒有合用的回傳 None。"""
    p = next((q for q in rows["npcs"] if q["name"] == who), None)
    if not p or who not in rows["relations"]:
        return sheet, None
    facts, cards, play = _desk(rows, updates, sheet, templates, now=now, skip=set(), rng=rng)
    need, got = facts(p)
    top = deck.pool([c for c in cards(p, now, QUIET) if "宮" in dict(c.need)], {**need, "宮": (where,)})
    return play(sheet, p, rng.choice(top), got, now) if top else (sheet, None)


def offer(rows: dict, updates, sheet: dict, templates: list[dict], *, present: set[str], focus: str, now: int, turn_no: int) -> Scene:
    """㉖ 在場那半：眼前的人先，同處的人隨機，最多 HERE 個各抽一張；第一張是候選，沒被挑中就丟。"""
    out = Scene()
    life = rows["life"]
    if not life:
        return out
    rng = random.Random(f"{rows['seed']}:deeds-here:{turn_no}")
    facts, cards, play = _desk(rows, updates, sheet, templates, now=now, skip=set(), rng=rng)
    recent = {l["a"] for l in mine(rows, life) if l["kind"] == society.DEED and now - l["clock_shichen"] < SHICHEN_PER_MONTH}
    by = {p["name"]: p for p in rows["npcs"]}
    others = sorted(present - {focus})
    names = ([focus] if focus in present else []) + rng.sample(others, len(others))
    for p in [by[x] for x in names if x in by and x not in recent and _open(rows, by[x])][:HERE]:
        need, got = facts(p)
        top = deck.pool(cards(p, now, QUIET), need)
        if top:
            card = rng.choice(top)

            def run(s: dict) -> dict:
                s, text = play(s, p, card, got, now)
                out.scene, out.lines = f"（做法）{text}", [text]
                return s
            out.ask = schedule.Ask(schedule.DEED, pending.NOW, turn_no, run)
            break
    return out
