"""傳聞的遊戲流程（第 10c-3a 步）：這回合聽到哪些傳聞、你做的事變成哪些傳聞；你在某地的名聲（第 10c-3b 步）。

規則在 domain/rumors.py、domain/reputation.py；資料一律來自回合開始時讀好的 rows（rows["rumors"]），不在這裡重讀。
新的傳聞與聽到的記事由 service 在回合的交易裡寫入。
"""
from __future__ import annotations

import random

from ..domain import circles, crime, era, hearsay, identity, judgment, oldnews, opinion, profile, realm, reputation, rumors, society, space
from ..domain import memory as m
from ..domain.clock import SHICHEN_PER_YEAR
from ..domain import npc as npc_mod
from . import proposals
from .background import known_names

OVERHEARD = 2                                         # 每回合順耳聽到幾則
ASKED = {judgment.SUCCESS: 4, judgment.GREAT_SUCCESS: 6}   # 主動打聽消息：成功、大成功聽到幾則；失敗只有順耳聽到的
OLD_ASKED, OLD_CHANCE, OLD_AGE = 3, 0.3, 60                 # 舊聞：打聽成功幾句、順耳的機率、老人幾歲（第 8-4-3 題甲，暫定）


def hear(rows: dict, *, here: str, clock_now: int, session_id: str, limit: int,
         turn_no: int) -> tuple[list[str], list[dict]]:
    """這回合在 here 聽到的傳聞（最多 limit 則）。回傳（事件, 記事）。
    只聽得到：傳到這裡了、還沒過時、這種地方聽得到、這一生還沒聽過、不是關於這一生的你自己、這裡有那個圈的人（第 9b 批）。
    優先：跟你認識的人有關 → 比較大 → 比較新。聽到的是這裡的版本（可能走樣）。"""
    said = _said(rows, here, clock_now)
    events, notes = [], []
    for r, km in [(r, km) for r, km in _fresh(rows, here, clock_now, session_id) if any(circles.tells(r, c) for c in said)][:limit]:
        v = _version(rows, r, km, here)
        said = rumors.text(v)
        events.append(f"江湖傳聞：{said}")
        notes.append(m.note(m.NPC, v["subject"] or v["target"], m.RUMOR, f"聽聞{said}", clock_now=clock_now,
                            turn_no=turn_no, rumor_id=r["id"]))
    old = _old(rows, here, clock_now, session_id, limit > OVERHEARD, turn_no)
    return events + [f"{oldnews.RULE}：{t}" for t in old], notes + [_old_note(here, t, clock_now, turn_no) for t in old]


def _fresh(rows: dict, here: str, clock_now: int, session_id: str) -> list[tuple[dict, int | None]]:
    """傳到這裡、這一生還沒聽過、不是你自己的傳聞，照優先排好。"""
    heard = {n["rumor_id"] for n in rows["memories"] if n["session_id"] == session_id and n.get("rumor_id")}
    known = known_names(rows, session_id)
    found = [((r["subject"] not in known and r["target"] not in known, -rumors.SIZES.index(r["size"]), -r["clock_shichen"]), r, km)
             for r, km in _arrived(rows, here, clock_now) if r["id"] not in heard and r["life"] != session_id]
    return [(r, km) for _, r, km in sorted(found, key=lambda x: x[0])]


def _type(rows: dict, place: str) -> str:
    return next((l["type"] for l in rows["locations"] if l["name"] == place), "")


def circle(rows: dict, p: dict, now: int) -> str:
    """他的消息圈（第 9-11 題）：職業，修士、小孩照修行身分那一組，都沒有照所在地。"""
    return circles.of(p.get("job") or profile.group(p, rows["bonds"], rows.get("factions", []), now), _type(rows, p["location"]))


def _said(rows: dict, here: str, now: int) -> set[str]:
    """這裡有人講的圈（第 9-10、9-14 題）：這種地方本來的人，加上在場不敵視你的人。"""
    rels = rows.get("relations", {})
    return {circles.of("", _type(rows, here))} | {circle(rows, p, now) for p in rows["npcs"] if p["location"] == here
                                                   and p["status"] == "ALIVE" and rels.get(p["name"], {}).get("affinity", 0) > circles.HOSTILE}


def told(rows: dict, here: str, now: int, life: str, circle: str) -> str:
    """這個圈的人會講的第一則傳聞（臨時路人，第 9-17 題）；不記成聽過。"""
    return next((rumors.text(_version(rows, r, km, here)) for r, km in _fresh(rows, here, now, life) if circles.tells(r, circle)), "")


def point(rows: dict, *, here: str, clock_now: int, session_id: str, asked: str = "") -> tuple[str, str]:
    """打聽到圈外的事：指到附近（此地、鄰地）同圈的人，沒有就說去哪種地方（第 9-13 題、9b-1 題甲）。回傳（一句, 前往選項）。
    asked：你問的人；敵視你的不指路（9-14）。"""
    said = _said(rows, here, clock_now)
    r = next((r for r, _ in _fresh(rows, here, clock_now, session_id) if not any(circles.tells(r, c) for c in said)), None)
    if not r or rows.get("relations", {}).get(asked, {}).get("affinity", 0) <= circles.HOSTILE:
        return "", ""
    c, near = rumors.CIRCLE[r["kind"]], [here, *(n["name"] for n in space.neighbors(rows["connections"], here))]
    p = next((p for n in near for p in rows["npcs"] if p["location"] == n and p["status"] == "ALIVE" and circle(rows, p, clock_now) == c), None)
    where = p["location"] if p else next((n for n in near if _type(rows, n) == circles.WHERE[c]), "")
    line = (f"這事你得問{where}的{p.get('job') or ''}{p['name']}" if p else f"這事你得去{where}問問，那裡{c}的人知道得多" if where
            else f"這事得問{c}的人")
    return line, f"前往{where}" if where and where != here else ""


def _old_note(here: str, text: str, clock_now: int, turn_no: int) -> dict:
    return m.note(m.PLACE, here, m.HEARD, f"舊聞：{text}"[:m.MEMORY_TEXT_LEN[1]], clock_now=clock_now, turn_no=turn_no)


def _old(rows: dict, here: str, clock_now: int, life: str, asked: bool, turn_no: int) -> list[str]:
    """這回合聽到的舊聞（第 8-4-3 題甲）：順耳 1 句——在場有老人或舊聞裡那人的親近的人就一定聽到，不然 OLD_CHANCE；
    打聽成功給到 OLD_ASKED 句。這一生聽過的（同一句記事）不重複。"""
    card = rows.get("era") or era.DEFAULT
    heard = {n["text"] for n in rows["memories"] if n["session_id"] == life and n["kind"] == m.HEARD}
    fresh = [(x, t) for x in oldnews.here(rows, here, clock_now)
             for t in [oldnews.told(x, rows, card, clock_now, rows["seed"])] if _old_note(here, t, 0, 0)["text"] not in heard]
    if asked:
        return [t for _, t in fresh[:OLD_ASKED]]
    if not fresh:
        return []
    around = [p for p in rows.get("npcs", []) if p["status"] == "ALIVE" and p["location"] == here]
    elder = any(p.get("birth_shichen") is not None and clock_now - p["birth_shichen"] >= OLD_AGE * SHICHEN_PER_YEAR for p in around)
    whos = {x["who"] for x, _ in fresh if x["who"]}
    close = {b[k] for b in rows.get("bonds", []) for k, o in (("a", "b"), ("b", "a")) if b[o] in whos}
    sure = elder or any(p["name"] in close for p in around)
    rng = random.Random(f"{rows['seed']}:oldnews:{life}:{turn_no}")
    return [fresh[0][1]] if fresh and (sure or rng.random() < OLD_CHANCE) else []


def fame(rows: dict, *, place: str, life: str, clock_now: int, name: str = "") -> reputation.Fame:
    """你在 place 的名聲（第 10c-3b 步）：傳到那裡、還沒過時、那種地方聽得到、關於這一生的你的傳聞，用那裡的版本算。
    name：對外的名字（身分與追捕）——只算記在這個名字下的傳聞（化名從零累積、易容時沒人聽過你）。"""
    return reputation.tally([_version(rows, r, km, place) for r, km in _arrived(rows, place, clock_now)
                             if r["life"] == life and (not name or r["subject"] == name)])


def _arrived(rows: dict, here: str, clock_now: int) -> list[tuple[dict, int | None]]:
    """已經傳到 here、還沒過時、這種地方聽得到的傳聞：（傳聞, 距離公里）。"""
    distance = space.distances_from(rows["connections"], here)
    place_type = next((l["type"] for l in rows["locations"] if l["name"] == here), "")
    found = []
    for r in rows["rumors"]:
        if not rumors.still_told(r, clock_now) or not rumors.audible(r, place_type):
            continue
        km = 0 if r["place"] == here else distance.get(r["place"])
        at = rumors.arrival(r, km)
        if at is not None and at <= clock_now:
            found.append((r, km))
    return found


def _version(rows: dict, r: dict, km: int | None, here: str) -> dict:
    """here 聽到的版本：種子＝傳聞＋地點，所以同一個地方聽到的固定。"""
    return rumors.version(r, km, random.Random(f"{rows['seed']}:rumor:{r['id']}:{here}"))


def limit_for(intent: judgment.Intent, verdict: judgment.Judgment) -> int:
    """主動打聽消息（套話但沒有打聽特定的人）：成功 4 則、大成功 6 則；其他時候順耳聽到 2 則。"""
    outcome = next((c.outcome for c in verdict.all_checks if c.target == judgment.PRY), "")
    if outcome and not intent.inquiry_npc:
        return max(OVERHEARD, ASKED.get(outcome, 0))
    return OVERHEARD


def turn_rumors(*, protagonist: str, session_id: str, before_sheet: dict, after_sheet: dict,
                verdict: judgment.Judgment | None, target: dict | None, npc_changes: dict[str, dict],
                notes: list[dict], care: m.ThreadUpkeep, verdicts: list, open_threads: dict, here: str,
                clock_now: int) -> list[dict]:
    """你這回合做的事變成的傳聞：大境界突破、兌現承諾、失約、受了你恩惠的人、殞落（殺人、傷人看誰知道，見 witness）。
    全部看欄位（判定、關係轉折記事的 attitude、線頭種類），不解析文字。"""
    lv = before_sheet["realm_lv"]

    def said(kind, target_name="", detail="", their_lv=0):
        return rumors.make(kind, protagonist, target=target_name, place=here, when=clock_now, detail=detail,
                           lv=their_lv, subject_lv=lv, life=session_id)

    found = []   # 殺人、傷人看誰知道（witness、spread，第 1-5a 批）
    if after_sheet["realm_lv"] > lv:
        found.append(said(rumors.RISE, detail=realm.stage_name(after_sheet["realm_lv"], 0),
                          their_lv=after_sheet["realm_lv"]))
    for v in verdicts:
        thread = open_threads.get(v.record.get("no")) if v.accepted and v.kind == proposals.THREAD_CLOSE else None
        if thread and thread["kind"] == m.MY_PROMISE and v.record["result"] == "兌現":
            found.append(said(rumors.KEPT, thread["subject"]))
    found += [said(rumors.BROKE, t["subject"]) for t in care.broken]
    found += [said(rumors.FAVOUR, n["subject"]) for n in notes if n["kind"] == m.TURN and n.get("attitude") == "親近"]
    if after_sheet["status"] == "FALLEN":
        found.append(said(rumors.FELL))
    return found


# ── 誰知道（第 120-3、121-2 題，實作第 1-5a、1-5b 批；規則在 domain/hearsay.py）──────
def witness(rows: dict, updates, npc_changes: dict, *, kind: str, life: str, who: str, target: str, here: str, now: int,
            turn_no: int, place_type: str = "", lv: int = 0, my_lv: int = 0, crimes: list[str] = (), frame: str = "") -> None:
    """你這回合做的事記成一件事，在場的人都知道（被傷沒死的人也算）；熱鬧的地方殺人、傷人當場傳開。who：對外的名字。
    殺人：被害人的親人等不在場、或不知道是你的，記追查兇手（家人一定知道出事）。
    frame：嫁禍給哪個勢力（第 7-3b1b2 批）：對外寫「那個勢力的人」，在場的人不知道是你。"""
    who = f"{frame}的人" if frame else who
    e = hearsay.event(kind, life, target, here, now, turn_no, name=who, lv=lv, my_lv=my_lv, crimes=list(crimes),
                      **({"frame": frame} if frame else {}))
    dead = {n for n, c in npc_changes.items() if c.get("state", {}).get("status") == "FALLEN"}
    alive = {p["name"] for p in rows["npcs"] if p["status"] == "ALIVE"} - dead
    seen = [hearsay.know(e, p["name"], now, by=int(who != identity.STRANGER and not frame)) for p in rows["npcs"]
            if p["location"] == here and p["name"] in alive]
    updates.happened.append(e)
    updates.knows += seen
    feel = _feel(rows, now)
    for k in seen:
        _learn(rows, updates, npc_changes, e, k, feel, now, scared=kind == hearsay.KILL)
    if kind == hearsay.KILL:
        sure = {k["who"] for k in seen if k["knows_who"]}
        updates.ledger += [{**society.owed(society.HUNT, n, life, now), "session_id": life, "event_id": e["id"]}
                           for n in sorted(hearsay.kin(target, rows["bonds"]) & alive - sure)]
    if kind in hearsay.LOUD and place_type in crime.BUSY:
        _loud(updates, e, rows["locations"], now)


def spread(rows: dict, updates, npc_changes: dict, *, life: str, now: int) -> None:
    """這一生的秘密照關係傳開、追查兇手的人問到了；同一村鎮知道是你的人夠多就變成傳聞。
    用回合開始時的資料，這回合剛看到的下回合才傳。"""
    events = {e["id"]: e for e in rows["happened"] if e["session_id"] == life and e["kind"] in hearsay.KINDS}
    knows = [k for k in rows["knows"] if k["session_id"] == life and k["event_id"] in events]
    (hush, fond), feel = _quiet(rows, npc_changes, life), _feel(rows, now)
    quiet = hush | fond
    trust = society.liking(rows["npcs"], rows["bonds"], rows.get("npc_reasons", []), now, axis=opinion.TRUST)
    new, told = hearsay.spread(list(events.values()), knows, rows["npcs"], rows["bonds"], hush, now,
                               believe=lambda who, teller: trust(who, teller) > hearsay.DOUBT, fond=fond,
                               lips={p["name"]: npc_mod.trait_level(p.get("discretion", 50)) for p in rows["npcs"]})   # 口風（第 7-1b 批）
    hunts = [l for l in rows.get("ledger", []) if l["kind"] == society.HUNT and l["status"] == society.OPEN and l["session_id"] == life]
    got = {(k["event_id"], k["who"]) for k in new}   # 同一回合有人告訴他了就不必再問
    new += [k for k in hearsay.asked(knows, hunts, rows["npcs"], rows["locations"], quiet, now) if (k["event_id"], k["who"]) not in got]
    updates.knows += new
    updates.told += told
    for k in new:
        _learn(rows, updates, npc_changes, events[k["event_id"]], k, feel, now, away=True)
    for e in hearsay.crowded(list(events.values()), knows + new, rows["npcs"], rows["locations"]):
        _loud(updates, e, rows["locations"], now)


def _quiet(rows: dict, npc_changes: dict, life: str) -> tuple[set[str], set[str]]:
    """替你瞞著的人：（一定瞞的：畏懼你＝封口（第 121-10 題）、收了或在等你的封口費（第 1-5d 批）、欠著那件事的人情；
    喜歡你的（友善以上，口風低會說溜嘴，第 7-1b 批））。用這回合變過的關係。"""
    by, lv = {p["name"]: p for p in rows["npcs"]}, rows.get("my_lv", 0)
    rels = {**rows["relations"], **{n: c["relation"] for n, c in npc_changes.items() if c.get("relation")}}
    paid = {l["a"] for l in rows.get("ledger", []) if l["kind"] == society.HUSH and l["session_id"] == life}
    hush = paid | {n for n, r in rels.items() if any(f.get("event") for f in r.get("favours", []))
                   or n in by and npc_mod.dread(r, by[n], lv) == npc_mod.AWED}
    return hush, {n for n, r in rels.items() if r["affinity"] >= hearsay.HIDE_AT} - hush


def blackmailers(rows: dict, life: str) -> dict[str, dict]:
    """拿你的把柄來要錢的人 → 那件事（第 120-2 題，實作第 1-5d 批）：知道你的秘密（還沒傳開、知道是你）、對你冷淡以下、
    不怕你、野心高、不是自家人；同一件事只來要一次（帳上已經有他綁著這件事的就不算）。"""
    events = {e["id"]: e for e in rows["happened"] if e["session_id"] == life and e["secret"] and e["kind"] in hearsay.KINDS}
    knows = [k for k in rows["knows"] if k["session_id"] == life]
    done, by, lv = hearsay.public(knows), {p["name"]: p for p in rows["npcs"]}, rows.get("my_lv", 0)
    took = {(l["a"], l["event_id"]) for l in rows.get("ledger", []) if l["event_id"] and l["session_id"] == life}
    out = {}
    for k in knows:
        p, r = by.get(k["who"]), rows["relations"].get(k["who"])
        if (k["event_id"] in events and k["event_id"] not in done and k["knows_who"] and p and r and p["status"] == "ALIVE"
                and r["affinity"] <= hearsay.COLD and not npc_mod.dread(r, p, lv) and npc_mod.trait_level(p["ambition"]) == "高"
                and r.get("circle") != society.KIN and (k["who"], k["event_id"]) not in took):
            out.setdefault(k["who"], events[k["event_id"]])
    return out


def expose(rows: dict, updates, e: dict, who: str, now: int) -> None:
    """揭穿：那件事在他住的村鎮傳開（殺人、傷人變成傳聞；第 1-5d 批），把柄就沒了。"""
    _loud(updates, {**e, "place": next(p["location"] for p in rows["npcs"] if p["name"] == who)}, rows["locations"], now)


def _feel(rows: dict, now: int):
    return society.liking(rows["npcs"], rows["bonds"], rows.get("npc_reasons", []), now, rows.get("factions", []))


def met(rows: dict, updates, npc_changes: dict, *, here: str, life: str, now: int) -> None:
    """傳聞見面才算（第 121-2 題 ③，實作第 1-5e 批）：你身邊的人，這件事只聽過傳到這裡的傳聞（沒看到、沒人告訴他），
    見到你時才記一筆、再降一級；記成 via＝傳聞的知道，只算一次。易容時犯的事傳聞寫陌生人，不算到你頭上。"""
    from . import people
    events = [e for e in rows["happened"] if e["session_id"] == life and e["kind"] in hearsay.LOUD and not (e["detail"] or {}).get("frame")]   # 嫁禍的不算到你
    if not events:
        return
    had, feel, here_now = {(k["event_id"], k["who"]) for k in rows["knows"] + updates.knows}, _feel(rows, now), people.present(rows, here)
    kind = {rumors.KILL: hearsay.KILL, rumors.HURT: hearsay.HURT}
    for r, _ in _arrived(rows, here, now):
        if r["life"] != life or r["kind"] not in kind or r["subject"] == identity.STRANGER:
            continue
        e = max((e for e in events if (e["kind"], e["target"]) == (kind[r["kind"]], r["target"]) and e["clock_shichen"] <= r["clock_shichen"]),
                key=lambda e: e["clock_shichen"], default=None)
        for p in here_now if e else []:
            if (e["id"], p["name"]) not in had:
                had.add((e["id"], p["name"]))
                k = hearsay.know(e, p["name"], now, via=hearsay.TOWN)
                updates.knows.append(k)
                _learn(rows, updates, npc_changes, e, k, feel, now, drop=1)


def _learn(rows: dict, updates, npc_changes: dict, e: dict, k: dict, feel, now: int, scared: bool = False,
           away: bool = False, drop: int = 0) -> None:
    """知道是你做的：照他對被害的人的態度記一筆好感原因；被害人的親人等知道是你殺的記血仇（不淡，膽大的會來報仇）。
    scared：在他面前殺人，他怕你多一筆（第 121-10 題）。away：聽人說的，還沒見過你就記 met＝0（不算認識的人，第 1-5e 批）。
    drop：聽傳聞的再降一級。"""
    from . import people   # people 也用到 news
    who, victim = k["who"], e["target"]
    if not k["knows_who"] or not victim or who == victim or not people.find(rows, who):
        return
    hit = [h for h in (hearsay.felt(e["kind"], feel(who, victim), drop),) if h] + ([npc_mod.SCARED] if scared else [])
    rel = people.changed_relation(rows, npc_changes, who)
    if away and who not in rows["relations"] and "relation" not in npc_changes.get(who, {}):
        rel = {**rel, "met": 0}
    rel = npc_mod.shift(who, rel, hit)[0] if hit else rel
    if e["kind"] == hearsay.KILL and who in hearsay.kin(victim, rows["bonds"]):
        rel = {**rel, "grudge": society.FEUD}
        book = rows.get("ledger", []) + updates.ledger
        if not any((l["kind"], l["a"], l["event_id"]) == (society.FEUD, who, e["id"]) for l in book):
            updates.ledger.append({**society.owed(society.FEUD, who, e["session_id"], now), "session_id": e["session_id"], "event_id": e["id"]})
        updates.settled += [l["id"] for l in rows.get("ledger", []) if (l["kind"], l["a"], l["event_id"], l["status"]) == (society.HUNT, who, e["id"], society.OPEN)]
        updates.ledger[:] = [l for l in updates.ledger if (l["kind"], l["a"], l["event_id"]) != (society.HUNT, who, e["id"])]
    if hit or rel.get("grudge") == society.FEUD:
        npc_changes.setdefault(who, {})["relation"] = rel


def _loud(updates, e: dict, locations: list[dict], now: int) -> None:
    """傳開：殺人、傷人變成傳聞；記一筆「這個村鎮都知道」。"""
    d = e["detail"]
    if e["kind"] in hearsay.LOUD:
        updates.rumors.append(rumors.make(rumors.KILL if e["kind"] == hearsay.KILL else rumors.HURT, d["name"], target=e["target"],
                                          place=e["place"], when=now, lv=d["lv"], subject_lv=d["my_lv"], life=e["session_id"]))
    updates.knows.append(hearsay.know(e, space.town_of(locations, e["place"]), now, via=hearsay.TOWN))