"""國與國（第 7-3b2 批，WHITEPAPER (56)～(60)；數字暫定）。每年跨年由 service._statecraft 呼叫 year。

立約、開局、國事牌的抽法跟盟與盟共用（domain/pacts.py，一步＝一年）；這裡只有國特有的：
- 好感：原因沿用 reasons 表，持有者、對象寫國名；種族關係當固定一筆 BASE；國事牌的「族對」看種族關係。
- 原因的來源：兩國的朝廷勢力（縣衙）之間這一年記了大或重的原因，國也記一筆小的（同號一對一年一筆）；
  國事牌（(58)，rules/content/nation.txt）：立約之後每國抽一張，冷卻存 atlas 的 cd（「國|牌名」→ 到期時刻）；
  地方的累積（7-3c1，(66)）：邊境州民怨到盡頭、縣衙聲勢衰微，鄰國記小壞「趁虛」；通商滿 10 年互記小好「互利」。
- 結果寫 atlas 的 stances、since（換的時刻），邊關、漲價、徵兵照讀 stances。
"""
from __future__ import annotations

import random

from ..config import PROJECT_ROOT
from ..domain import atlas, chains, deck, opinion, pacts, races, space
from ..domain.atlas import TRADE
from ..domain.clock import SHICHEN_PER_YEAR as YEAR

BASE = {"同族": 20, "中立": 0, "戒備": -20, "敵對": -40}
GOV, PREY, GAIN, GAIN_YEARS = "縣衙", "趁虛", "互利", 10   # 後三個：地方的累積（7-3c1，(66)）
DECK = deck.read(PROJECT_ROOT / "rules" / "content" / "nation.txt")
assert all(c.who == "國" and all(t.split(":")[0] in pacts.RESULTS for t in c.result.split()) for c in DECK), "國事牌的結果寫錯了"


class Nations(pacts.Pacts):
    def __init__(self, rows: dict, updates, a: dict):
        super().__init__(a["nations"], atlas.stances(a), a.get("since", {}), atlas.bordering(a),
                         [r for r in rows.get("npc_reasons", []) + updates.reasons if r["holder"] in a["nations"]],
                         a.get("cd", {}), YEAR, DECK)
        self.rows, self.u, self.a = rows, updates, a

    def base(self, x: str, y: str) -> int:
        return BASE[races.relation(self.a["nations"][x], self.a["nations"][y])]

    def pair(self, k: str, f: str, g: str, t: int) -> set[str]:
        return {races.relation(self.a["nations"][f], self.a["nations"][g])} if k == "族對" else super().pair(k, f, g, t)

    def govs(self) -> dict[str, str]:
        """縣衙（朝廷勢力）→ 它在哪一國。"""
        where, nation = atlas.state_map(self.a, self.rows["connections"]), {s["name"]: s["nation"] for s in self.a["states"]}
        return {f["name"]: n for f in self.rows["factions"] if f["type"] == "朝廷"
                and (n := nation.get(where.get(space.town_of(self.rows["locations"], f["location"]), ""), ""))}

    def local(self, t: int) -> None:
        """地方的累積（(66)）：邊境州有村鎮民怨到盡頭、或縣衙聲勢衰微，相鄰的國記小壞「趁虛」；通商滿 10 年互記小好「互利」。"""
        card, where = self.rows.get("pressure", {}), atlas.state_map(self.a, self.rows["connections"])
        nation = {s["name"]: s["nation"] for s in self.a["states"]}
        weak = {(y, s["nation"]) for s in self.a["states"]
                if any(card.get(x, {}).get("人心", {}).get("v") == -2 for x, st in where.items() if st == s["name"])
                for y in {nation[n] for n in atlas.near_states(self.a, s)} - {s["nation"]}}
        weak |= {(y, n) for f, n in self.govs().items() if card.get(f, {}).get("聲勢", {}).get("v") == -2
                 for y in self.names if atlas._key(y, n) in self.near}
        for y, x in sorted(weak):
            self.feel(y, x, PREY, opinion.SMALL, -1, t)
        for key, s in sorted(self.st.items()):
            if s == TRADE and t - self.since.get(key, t) >= GAIN_YEARS * YEAR:
                x, y = key.split("|")
                self.feel(x, y, GAIN, opinion.SMALL, 1, t)
                self.feel(y, x, GAIN, opinion.SMALL, 1, t)

    def rollup(self, t: int) -> None:
        """兩國縣衙之間這一年的大、重原因 → 國記一筆小的（(56)）。"""
        gov, got = self.govs(), {}
        for r in self.rows.get("npc_reasons", []) + self.u.reasons:   # 有根的優先（因果鏈，domain/chains）
            if r["holder"] in gov and r["toward"] in gov and r["axis"] == opinion.LIKE and r["size"] != opinion.SMALL \
                    and t - YEAR < r["clock_shichen"] <= t:
                key = (gov[r["holder"]], gov[r["toward"]], 1 if r["value"] > 0 else -1)
                got[key] = got.get(key) or r["event_id"]
        for (x, y, sign), root in sorted(got.items()):
            if x != y:
                self.feel(x, y, GOV, opinion.SMALL, sign, t, event=root)


def year(rows: dict, updates, a: dict, t: int) -> tuple[dict, list[tuple[str, str]], list[tuple[str, str]]]:
    """過一年（t＝跨年那一刻）：回傳（新骨架, 關係變了的國事, 國事牌那幾句），都是 [(國, 一句)]。"""
    n = Nations(rows, updates, a)
    if "stances" not in a:
        n.open(n.st, t)
    n.rollup(t)
    n.local(t)
    n.pacts(t)
    rng = random.Random(f"{a['seed']}:nation:{t // YEAR}")
    for f in n.names:
        n.draw(rng, f, t)
    updates.reasons += n.added
    updates.happened += [chains.event(chains.WAR, x, y, "", b.pop("from"), t, 0, **b) for x, y in n.wars if (b := chains.blame(n.rs, x, y, t, n.years))]
    cd ={k: v for k, v in n.cd.items() if v > t}
    return {**a, "stances": n.st, "since": n.since, "cd": cd, "year": t // YEAR}, n.news, n.told
