"""案中案在回合裡（WHITEPAPER 第 13、30、40、42-3 題，第 5-5a 批 5-5-1～5-5-5 題）：解開這一層，把柄帶出下一層。規則在 domain/dark.py。

- 暗線打斷了、這條又解開（dark.link）：下一回合翻面。附近沒有接得上的事，就在附近最大的村鎮放一條新事端，
  隱瞞者用幕後那一方住在那裡的人（plots.Tick.boss）。
- 下一層：接得上的線頭優先（同一州，或有同一個人），沒有就挑附近還在的事端、怪談、傳說，規模大的優先、不往下（第 42-3 題）。
- 翻面那句（dark.FLIPS）：有同一個人寫人名，新放的事端寫帳，其他寫信；都帶這一層的記號，不寫幕後是誰。
- 手上沒有路線就接下（算自己接的，鐘不動）；手上有就記成線頭（第 5-5-4 題）。下一層的暗線在 game/darks.py 啟動。
- 下一層往上換人（第 5-5b 批）：這一生有還沒分勝負的宿敵就是他（第 43 題，寫名字、幕後換成他的勢力），沒有就幕後的首領。
- 延後揭穿（第 5-5c2 批）：換了人就揭出上一層的對手是被推出來頂的，他記恨下一層的對手，找他交談吐一條破綻（game/darks.py）。
"""
from __future__ import annotations

import random

from ..domain import atlas, dark, domains, games, home, lead, legends, opinion, plot, route, society, space
from . import routes
from .routes import Walk


def _people(rows: dict, kind: str, key: str) -> set[str]:
    """這件事裡有名字的人（事端的隱瞞者不算：寫出來就先洩底）。"""
    names = {p["name"] for p in rows["npcs"]}
    if kind == route.PLOT:
        return {v for p in rows["plots"] if plot.tag(p) == key for k, v in p["cast"].items() if k != plot.KEY_ROLE} & names
    if kind == route.ZONE:
        return {x for d in rows["domains"] if d["place"] == key for x in (d["person"], d["ghost"])} & names
    return {x for g in rows["legends"] if routes.legend_key(g) == key for x in (g["dead"], g["target"])} & names


def _live(rows: dict) -> list[tuple[str, str, str, str]]:
    """還在的事：（種類, 名字, key, 地方）。"""
    return [*((route.PLOT, p["name"], plot.tag(p), p["town"]) for p in rows["plots"] if p["ended_shichen"] is None),
            *((route.ZONE, d["tale"], d["place"], d["place"]) for d in rows["domains"] if d["status"] == domains.ACTIVE),
            *((route.LEGEND, g["theme"], routes.legend_key(g), g["root"]) for g in rows["legends"] if g["status"] == legends.ACTIVE)]


def _rank(rows: dict, place: str) -> int:
    town = space.town_of(rows["locations"], place)
    return space.scale_rank(next((l.get("scale", "") for l in rows["locations"] if l["name"] == town), ""))


def _picks(rows: dict, sheet: dict, ch: dict) -> list[tuple[str, str, str, str]]:
    live = [x for x in _live(rows) if x[2] != ch["from"] and not route.holds(sheet, x[2])]
    states = atlas.state_map(rows["atlas"], rows["connections"]) if rows.get("atlas") else {}
    state = states.get(space.town_of(rows["locations"], ch["place"]))
    keys = {l["key"] for l in sheet["leads"]}
    tied = [x for x in live if x[2] in keys and (states.get(space.town_of(rows["locations"], x[3])) == state
                                                  or _people(rows, x[0], x[2]) & set(ch["people"]))]
    if tied:
        return tied
    near, low = routes.around(rows, ch["place"]), _rank(rows, ch["place"])
    close = [x for x in live if x[3] in near and _rank(rows, x[3]) >= low]
    top = max((_rank(rows, x[3]) for x in close), default=None)
    return [x for x in close if _rank(rows, x[3]) == top]


def _place(rows: dict, ticked, ch: dict, rng: random.Random) -> None:
    """接不上：附近最大的村鎮放一條新事端，回合結束時放（plots.write）；隱瞞者用幕後那一方住在那裡的人。"""
    near = routes.around(rows, ch["place"])
    towns = [l for l in rows["locations"] if l["name"] in near and l["type"] in home.RENT_TYPES]
    top = max((space.scale_rank(l["scale"]) for l in towns), default=None)
    town = rng.choice([l for l in towns if space.scale_rank(l["scale"]) == top]) if towns else None
    if not town or any(t["name"] == town["name"] for t, _ in ticked.towns):
        return
    ticked.towns.append((town, ""))
    alive = {p["name"] for p in rows["npcs"] if p["status"] == "ALIVE" and space.town_of(rows["locations"], p["location"]) == town["name"]}
    his = sorted({b["a"] for b in rows["bonds"] if ch["by"] and b["b"] == ch["by"] and b["type"] in society.MEMBER_BONDS} & alive)
    if his:
        ticked.boss[town["name"]] = rng.choice(his)


def _boss(rows: dict, ch: dict, life: str) -> tuple[str, str, str, bool]:
    """下一層的（對手, 幕後, 記號, 是不是宿敵）：還沒分勝負、活著的宿敵（幕後換成他的勢力，沒有就沿用），不然幕後的首領，都沒有空字串。"""
    alive = {p["name"] for p in rows["npcs"] if p["status"] == "ALIVE"}
    rival = next((g["name"] for g in rows.get("games", []) if g["session_id"] == life and g["kind"] == games.RIVAL
                  and not g["result"] and g["name"] in alive), "")
    if rival:
        f = next((f for b in rows["bonds"] if b["a"] == rival and b["type"] in society.MEMBER_BONDS
                  for f in rows["factions"] if f["name"] == b["b"] and f["type"] in dark.MARKS), None)
        return (rival, f["name"], dark.MARKS[f["type"]], True) if f else (rival, ch["by"], ch["mark"], True)
    head = next((b["a"] for b in rows["bonds"] if ch["by"] and b["type"] == "首領" and b["b"] == ch["by"] and b["a"] in alive), "")
    return head, ch["by"], ch["mark"], False


def _flip(walk: Walk, rows: dict, ch: dict, updates, rng: random.Random, now: int, life: str) -> None:
    picks = _picks(rows, walk.sheet, ch)
    if not picks:   # 放新事端也失敗了（名字用完、沒有模板）：就算了
        walk.sheet = {**walk.sheet, "chain": None}
        return
    kind, name, key, place = rng.choice(picks)
    foe, by, mark, rival = _boss(rows, ch, life)
    shared = sorted(_people(rows, kind, key) & set(ch["people"]))
    new = kind == route.PLOT and any(plot.tag(p) == key and p["started_shichen"] >= ch["since"] for p in rows["plots"])
    how = "宿敵" if rival else "人名" if shared else "帳" if new else "信"
    text = plot.fill(dark.FLIPS[how], {"記號": mark, "地方": place, "人": foe if rival else shared[0] if shared else ""})
    alive = {p["name"] for p in rows["npcs"] if p["status"] == "ALIVE"}
    witness = ch["witness"] if foe and ch["witness"] in alive and ch["witness"] != foe else ""
    if witness:   # 延後揭穿（第 5-5-11～5-5-13 題）：上一層的對手是被推出來頂的，記恨下一層的對手
        text += f"；原來{witness}只是被推出來頂的"
        updates.reasons.append(opinion.reason(witness, foe, opinion.hit(opinion.BETRAY, opinion.LIKE, opinion.BIG, -1), now))
    walk.facts.append(f"把柄裡還藏著一樣東西：{text}")
    walk.scene = walk.scene or f"（翻面）把柄裡還藏著一樣東西：{text}。寫到主角看出這件事背後還有一層為止"
    sheet = walk.sheet
    if sheet["route"]:   # 手上有路線：記成線頭，滿了由 leads.turn 擠掉最舊的、給結果
        sheet = {**sheet, "leads": [*(l for l in sheet["leads"] if l["key"] != key), lead.make(kind, key, place, text, now)]}
    else:
        sheet = route.take(sheet, kind, name, key, place, route.SELF, now)
    walk.sheet = {**sheet, "chain": {**ch, "key": key, "foe": foe, "by": by, "mark": mark, "witness": witness}}


def turn(walk: Walk, rows: dict, ticked, updates, rng: random.Random, *, here: str, now: int, turn_no: int, life: str = "") -> None:
    """路線剛解開：記下要翻面，接不上就先放一條新事端；到了下一回合翻面。"""
    r = walk.won
    ch = r and dark.link(walk.dark, r, r["place"] or here, sorted(_people(rows, r["kind"], r["key"])), turn_no, now)
    if ch:
        walk.sheet = {**walk.sheet, "chain": ch}
        if not _picks(rows, walk.sheet, ch):
            _place(rows, ticked, ch, rng)
        return
    ch = walk.sheet.get("chain")
    if ch and not ch["key"] and turn_no >= ch["due"]:
        _flip(walk, rows, ch, updates, rng, now, life)
