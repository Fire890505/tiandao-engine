"""AI 提案的審核：AI 提出「新地點／新 NPC」，由 Python 依遊戲狀態決定是否採用。

純函式：不碰資料庫、不呼叫 AI。service.py 把審核結果與回合寫進同一個交易。

參考舊專案的行為（db.py::apply_journey_logs 的 location_discovered／npc_discovered、
engine.py::_validate_payload），但刻意不同：
- 每種提案一個小函式（review_location／review_npc），不做成處理所有類型的大迴圈（稽核 T-02）。
- 舊版 Name 已存在時會覆寫或另建同名 NPC，只發警告；這裡同名一律不採用，已確立的事實不被改寫。
- NPC 的所在地、狀態、aiDriven、建立者由 Python 推導，AI 填了也進不來（合約白名單擋掉，稽核 B-12）。
- 提案的名字必須原樣出現在本回合敘事裡，避免 AI 憑空登錄玩家沒看過的東西。
"""
from __future__ import annotations

import dataclasses
import re
from dataclasses import dataclass, field

from ..ai.contract import FAVOUR_WAYS, PROPOSAL_ENUMS, PROPOSAL_MAX_PER_TURN
from ..domain import memory as memory_mod
from ..domain import npc as npc_mod
from ..domain import era, house, newcomer, scene, society, space
from ..domain import incident as incident_mod
from ..domain import items as items_mod

LOCATION, NPC, NPC_UPDATE, RELATION, FAVOUR = "location", "npc", "npc_update", "relation", "favour"
MEMORY, THREAD_OPEN, THREAD_CLOSE = "memory", "thread_open", "thread_close"
FACTION, BOND, SELF_APPEARANCE, SELF_REPUTATION = "faction", "bond", "self_appearance", "self_reputation"
PLACE_TEXT, ITEM, PLACE_FEATURES, EVENT = "place_text", "item", "place_features", "incident"
HISTORY_TEXT, HISTORY_LEN = "history_text", (20, 200)   # 16k：一國的往事
RULE = "rules"   # 說書立下、要程式執行的規矩（domain/house.py，2026-11-23）

# 沿用舊專案 rules.py 的 LocationType 詞彙；不在表內的值直接忽略，不影響採用
LOCATION_TYPES = ("客棧", "坊市", "藥鋪", "當鋪", "鐵匠鋪", "宗門", "武館", "公會", "衙署", "鏢局",
                  "村落", "城鎮", "住家", "祠堂", "秘境", "廢墟", "荒野", era.RELIC, "丹房", "煉器閣")
# 資料裡一律記古代的叫法：AI 用這個時代的叫法提案（旅館、公寓）時換回來（第 16e 節）
MAX_PER_TURN = {LOCATION: PROPOSAL_MAX_PER_TURN["locations"], NPC: PROPOSAL_MAX_PER_TURN["npcs"],
                NPC_UPDATE: PROPOSAL_MAX_PER_TURN["npc_updates"], RELATION: PROPOSAL_MAX_PER_TURN["relations"],
                FAVOUR: PROPOSAL_MAX_PER_TURN["favours"],
                MEMORY: PROPOSAL_MAX_PER_TURN["memories"], THREAD_OPEN: PROPOSAL_MAX_PER_TURN["thread_opens"],
                THREAD_CLOSE: PROPOSAL_MAX_PER_TURN["thread_closes"], FACTION: PROPOSAL_MAX_PER_TURN["factions"],
                BOND: PROPOSAL_MAX_PER_TURN["bonds"], ITEM: PROPOSAL_MAX_PER_TURN["items"],
                EVENT: PROPOSAL_MAX_PER_TURN["incidents"]}
# 見聞不可描述 Python 管的事（境界、生死、數值、關係），這些由 Python 自動記
PYTHON_OWNED_WORDS = ("境界", "突破", "修為", "氣血", "靈石", "好感", "信任", "殞落", "身亡", "死了", "斃命",
                      "壽元", "記恨", "態度")
MAX_PER_SESSION = {LOCATION: 200, NPC: 200, FACTION: 100, ITEM: 200, EVENT: 100}
GOAL_TARGET_LEN = 20
NOT_REQUESTED, MINOR_BOND = "not_requested", "minor_bond"
NAME_RE = re.compile(r"^[㐀-鿿·・]{2,12}$")   # 中文名，允許間隔號（例：青雲觀·主殿）
# 地名的最後一個字（2026-10-05）：擋掉把物品、功法當成地點的提案（qwen 曾把藥名「復元散」提成地點）。
# 勢力用字（宗、派、門、會）不在表內：那是勢力提案。漏了常見的地名用字就補進來。
PLACE_ENDINGS = set(
    "山峰崖嶺岡崗坡坪谷峪澗溪河江湖海泉潭池井瀑灘岸畔洲渚島嶼灣浦港津渡口原野林森漠澤沼荒"   # 山水
    "洞窟穴淵壑坑墟塚陵墓碑壇"                                                               # 洞穴、遺跡
    "村寨莊堡鎮鄉縣市集城州府郡都京邑國域境疆界關隘驛站營"                                   # 聚落、疆域（鄉縣：第 8-3 批）
    "路道徑街巷橋廊"                                                                       # 道路
    "樓閣亭臺台殿堂廟寺觀庵祠塔院宅居舍屋室園圃苑館店鋪肆棧坊行號場署衙局獄牢窯庫宮"         # 建築
    "寓廈艙區司廠所"                                                                       # 現代、未來（第 16e 節）
)
DESCRIPTION_LEN = (10, 200)
NPC_TEXT_LEN = (4, 200)

# 拒絕原因（寫進 proposal_log，ai-check 報告會統計）
INVALID_NAME, NOT_IN_NARRATIVE, ALREADY_KNOWN = "invalid_name", "not_in_narrative", "already_known"
IS_PLAYER, DUPLICATE_IN_TURN, TOO_MANY = "is_player", "duplicate_in_turn", "too_many_this_turn"
SESSION_LIMIT, INVALID_TEXT = "session_limit", "invalid_text"
INVALID_PROFILE, UNKNOWN_NPC, NOT_PRESENT = "invalid_profile", "unknown_npc", "not_present"
UNKNOWN_SUBJECT, PYTHON_OWNED, UNKNOWN_THREAD = "unknown_subject", "python_owned", "unknown_thread"
THREAD_LIMIT, NOT_A_PLACE = "thread_limit", "not_a_place"
COPIED = "copied"   # 抄了主角的話（3-7a 第 2 題）
TEXTS = ("description", "appearance", "profile", "reason", "why", "text", "scene")   # 提案裡會存下來的文字欄
SPARE = ("reason", "why")   # 可以空著的欄：抄了只丟這欄；人物的外貌、個性留一欄就好


def copied(text: str, lines, n: int = 8) -> bool:
    """3-7a 第 2 題：text 裡任一段連續 n 字出現在主角說過的話裡。"""
    return any(text[i:i + n] in line for line in lines if line for i in range(len(text) - n + 1))


def uncopied(v: Verdict, said) -> list[Verdict]:
    """抄了主角的話：可以空著的欄丟掉那欄（npc_update 不寫那欄），必填的退那筆。
    丟掉的欄另記一筆不採用（原因 copied_欄名），ai-check 數得到。"""
    hit = [k for k in TEXTS if isinstance(v.record.get(k), str) and copied(v.record[k], said)] if v.accepted else []
    if not hit:
        return [v]
    rec = {k: x for k, x in v.record.items() if k not in hit} if v.kind == NPC_UPDATE else {**v.record, **dict.fromkeys(hit, "")}
    ok = all(k in SPARE for k in hit) or v.kind in (NPC, NPC_UPDATE) and any(rec.get(k) for k in ("appearance", "profile"))
    return [dataclasses.replace(v, record=rec), *(_reject(v.kind, v.name, f"{COPIED}_{k}") for k in hit)] if ok \
        else [_reject(v.kind, v.name, COPIED)]


@dataclass(frozen=True)
class Context:
    """審核需要的遊戲狀態。名稱集合已正規化（normalize_name）。"""
    narrative: str
    turn_no: int
    player_name: str
    current_location: str
    known_locations: frozenset[str]
    known_npcs: frozenset[str]
    place_scales: dict = field(default_factory=dict)   # 已知地點 → 規模（驗證上層地點用，第 7 步）
    npc_location: str = ""     # NPC 登場的地點（這回合移動過就是抵達處）；空字串＝current_location
    npc_info: dict = field(default_factory=dict)       # 已知 NPC → {"status", "location", "minor"}（第 6 步）
    open_threads: dict = field(default_factory=dict)   # 線頭編號 → 線頭（這一生看得到、還沒結束的，第 17 步）
    known_factions: frozenset = frozenset()            # 已登錄的勢力（第 10a 步）
    bonds: tuple = ()                                   # 已登錄的羈絆（去重用）
    appearance_task: str = ""                           # 這回合有沒有請 AI 寫主角外貌（沒請就不收）
    reputation_task: str = ""                           # 這回合有沒有請 AI 寫江湖傳言中的你（第 10c-3b 步）
    place_task: str = ""                                # 這回合請 AI 寫描述的地點（地圖第二輪）；空＝沒請
    # Python 發出去的名字（WHITEPAPER 12.6）：用了就不必在敘事裡出現
    arranged: dict | None = None                        # 這回合安排登場的人（domain/newcomer.arrange 的資料）
    place_prefix: str = ""                              # 這回合給的地名字首
    race: str = "人族"                                  # 這一州的種族：說書人寫的新人物預設是這一族（16k）
    history_task: str = ""                              # 這回合請 AI 寫往事的國（16k）；空＝沒請
    known_items: frozenset = frozenset()                # 這個世界登錄過的新物品（16p）
    scene_task: str = ""                                # 這回合請 AI 列環境物的地點（16r）；空＝沒請
    known_events: frozenset = frozenset()               # 這個世界登錄過的新事件（16p）
    said: tuple = ()                                    # 說書人看得到的主角台詞：這回合＋前情提要（3-7a），抄 8 字以上丟那欄

    @property
    def here(self) -> str:
        return self.npc_location or self.current_location


@dataclass
class Verdict:
    kind: str
    name: str
    accepted: bool
    reason: str = ""
    record: dict = field(default_factory=dict)   # 採用時要寫入的完整資料（含 Python 推導欄位）


def normalize_name(name: str) -> str:
    return re.sub(r"\s+", "", name or "")


# 合成提案換回舊的四種（第 2-4b 批第 3 題的表，121-3 做好前的過渡）：你做的改他對你的態度，他做的先記見聞，大事才動人情
_NICE, _RUDE = [("relations", "小幅好轉")], [("relations", "小幅惡化")]
MINE = {"幫忙": _NICE, "送禮": _NICE, "照顧": _NICE, "救命": [("relations", "明顯好轉"), ("favours", "欠你")],
        "冒犯": _RUDE, "威脅": _RUDE, "害他丟臉": [("relations", "明顯惡化")], "說謊": [("memories", "做")],
        "答應": [("thread_opens", "我的承諾")], "借錢": [("favours", "欠你")], "還情": [("memories", "做")],
        "說了": [("memories", "說")], "看到": [("memories", "見")], "懸念": [("thread_opens", "懸念")]}
THEIRS = {**{k: [("memories", "做")] for k in ("幫忙", "送禮", "照顧", "冒犯", "威脅", "害他丟臉")},
          "救命": [("favours", "你欠"), ("memories", "做")], "說謊": [("memories", "說")], "答應": [("thread_opens", "他人的承諾")],
          "借錢": [("favours", "借你")], "還情": [("favours", "還了")], "說了": [("memories", "說")], "看到": [("memories", "見")],
          "懸念": [("thread_opens", "懸念")]}
# 答應的期限從那句話找時間字（第 2-4b 批第 5 題）；「總有一天」要先比，免得當成「一天」
WHEN = ((re.compile(r"將來|有朝一日|日後|總有一天|改天|以後"), "無期限"),
        (re.compile(r"明[天日早晚]|後天|今[天日晚夜]|[一二三四五六七八九十兩幾數\d]+[天日]"), "數日"),
        (re.compile(r"年"), "一年"), (re.compile(r"月"), "一月"))


def deadline(text: str) -> str:
    return next((d for r, d in WHEN if r.search(text)), "一月")


def expand(acts: list[dict]) -> dict[str, list[dict]]:
    """acts（第 2-4b 批）→ relations、favours、memories、thread_opens，之後照舊審核。"""
    out = {"relations": [], "favours": [], "memories": [], "thread_opens": []}
    for a in acts:
        name, text = a.get("name", ""), a.get("text", "")
        for kind, value in (MINE if a.get("by") == "你" else THEIRS).get(a.get("kind"), ()):
            out[kind].append({"relations": {"name": name, "change": value, "reason": text},
                              "favours": {"name": name, "way": value, "why": text},
                              "memories": {"kind": value, "subject": name, "text": text},
                              "thread_opens": {"kind": value, "subject": name, "text": text, "deadline": deadline(text)}}[kind])
    return out


def review(proposals: dict[str, list[dict]], ctx: Context, counts: dict[str, int]) -> list[Verdict]:
    """審核一回合的所有提案。counts 是這一局目前已登錄的數量（{LOCATION: n, NPC: m}）。"""
    proposals = {**proposals, **{k: proposals.get(k, []) + v for k, v in expand(proposals.get("acts", [])).items()}}
    verdicts: list[Verdict] = []
    taken: set[str] = set()   # 本回合已採用的新名字：地點、人物、勢力共用，同名只採用第一個
    for kind, items, reviewer in ((LOCATION, proposals.get("locations", []), review_location),
                                  (NPC, proposals.get("npcs", []), review_npc),
                                  (FACTION, proposals.get("factions", []), review_faction),
                                  (ITEM, proposals.get("items", []), review_item),
                                  (EVENT, proposals.get("incidents", []), review_event)):
        accepted = 0
        for item in items:
            v = reviewer(item, ctx)
            if v.accepted and v.name in taken:
                v = _reject(kind, v.name, DUPLICATE_IN_TURN)
            elif v.accepted and accepted >= MAX_PER_TURN[kind]:
                v = _reject(kind, v.name, TOO_MANY)
            elif v.accepted and counts.get(kind, 0) + accepted >= MAX_PER_SESSION[kind]:
                v = _reject(kind, v.name, SESSION_LIMIT)
            if v.accepted:
                accepted += 1
                taken.add(v.name)
            verdicts.append(v)
    # 安排登場的人是 Python 定的事實（故事第 4 題）：說書人沒提案、沒寫名字，照樣用準備好的資料登錄（描述空著，下回合請 AI 補寫）
    arranged = ctx.arranged
    if arranged and arranged["name"] not in taken:
        verdicts.append(Verdict(NPC, arranged["name"], True, record=_npc_record(arranged, {}, ctx)))
    for kind, items, reviewer in ((NPC_UPDATE, proposals.get("npc_updates", []), review_npc_update),
                                  (RELATION, proposals.get("relations", []), review_relation),
                                  (FAVOUR, proposals.get("favours", []), review_favour)):
        done: set[str] = set()   # 同一個 NPC 一回合只採用一次
        for item in items:
            v = reviewer(item, ctx)
            if v.accepted and (v.name in done or len(done) >= MAX_PER_TURN[kind]):
                v = _reject(kind, v.name, DUPLICATE_IN_TURN if v.name in done else TOO_MANY)
            if v.accepted:
                done.add(v.name)
            verdicts.append(v)
    # 第 17 步：見聞可以同一人多條（不能完全相同）；開線、結線依內容與編號去重
    for kind, items, reviewer, key in ((MEMORY, proposals.get("memories", []), review_memory, "text"),
                                       (THREAD_OPEN, proposals.get("thread_opens", []), review_thread_open, "text"),
                                       (THREAD_CLOSE, proposals.get("thread_closes", []), review_thread_close, "no")):
        seen: set = set()
        for item in items:
            v = reviewer(item, ctx)
            if v.accepted and (v.record[key] in seen or len(seen) >= MAX_PER_TURN[kind]):
                v = _reject(kind, v.name, DUPLICATE_IN_TURN if v.record[key] in seen else TOO_MANY)
            if v.accepted:
                seen.add(v.record[key])
            verdicts.append(v)
    # 第 10a 步：羈絆可以連到本回合剛登錄的人物與勢力；主角外貌只有這回合有請 AI 寫時才收
    bond_ctx = _with_new_entities(ctx, verdicts)
    accepted_bonds: list[dict] = []
    for item in proposals.get("bonds", []):
        v = review_bond(item, bond_ctx)
        if v.accepted and any(society.same_bond(v.record, b) for b in accepted_bonds):
            v = _reject(BOND, v.name, DUPLICATE_IN_TURN)
        elif v.accepted and len(accepted_bonds) >= MAX_PER_TURN[BOND]:
            v = _reject(BOND, v.name, TOO_MANY)
        if v.accepted:
            accepted_bonds.append(v.record)
        verdicts.append(v)
    for kind, task in ((SELF_APPEARANCE, ctx.appearance_task), (SELF_REPUTATION, ctx.reputation_task)):
        for i, item in enumerate(proposals.get(kind, [])):
            v = review_self_text(kind, item, task, ctx)
            verdicts.append(_reject(kind, v.name, TOO_MANY) if v.accepted and i else v)
    for i, item in enumerate(proposals.get("place_text", [])):
        v = review_place_text(item, ctx)
        verdicts.append(_reject(PLACE_TEXT, v.name, TOO_MANY) if v.accepted and i else v)
    for i, item in enumerate(proposals.get(HISTORY_TEXT, [])):
        v = review_history_text(item, ctx)
        verdicts.append(_reject(HISTORY_TEXT, v.name, TOO_MANY) if v.accepted and i else v)
    verdicts += [review_feature(item, ctx) for item in proposals.get(PLACE_FEATURES, [])]
    verdicts += [review_rule(item, ctx) for item in proposals.get(RULE, [])[:PROPOSAL_MAX_PER_TURN[RULE]]]
    return [u for v in verdicts for u in uncopied(v, ctx.said)]


def review_location(item: dict, ctx: Context) -> Verdict:
    name = normalize_name(item.get("name", ""))
    offered = bool(ctx.place_prefix) and name.startswith(ctx.place_prefix)
    if reason := _name_problem(name, ctx, offered=offered):
        return _reject(LOCATION, name, reason)
    if name[-1] not in PLACE_ENDINGS:
        return _reject(LOCATION, name, NOT_A_PLACE)
    description = item.get("description", "").strip()
    if not DESCRIPTION_LEN[0] <= len(description) <= DESCRIPTION_LEN[1]:
        return _reject(LOCATION, name, INVALID_TEXT)
    loc_type = era.base(item.get("type", ""))
    loc_type = loc_type if loc_type in LOCATION_TYPES else ""
    return Verdict(LOCATION, name, True, record={
        "name": name, "description": description, "type": loc_type,
        "discovered_turn": ctx.turn_no, **_place_fields(item, loc_type, ctx),
    })


def _place_fields(item: dict, loc_type: str, ctx: Context) -> dict:
    """地點的附帶欄位（第 7 步）。不合格的欄位丟掉、不影響採用：
    距離預設「鄰近」（在眼前看到的地方）；上層地點必須已知，而且規模不能比這個地點小；
    危險度只有荒野、秘境、廢墟才有。"""
    scale = item.get("scale", "") if item.get("scale", "") in space.SCALES else ""
    parent = normalize_name(item.get("parent", ""))
    parent_scale = ctx.place_scales.get(parent)
    if parent_scale is None or (scale and parent_scale and space.scale_rank(parent_scale) < space.scale_rank(scale)):
        parent = ""
    danger = item.get("danger", "")
    return {
        "distance": item.get("distance") if item.get("distance") in space.DISTANCE_TIERS else space.NEAR,
        "direction": item.get("direction") if item.get("direction") in space.DIRECTIONS else "",
        "parent": parent, "scale": scale,
        "danger": danger if loc_type in space.DANGER_TYPES and danger in space.DANGER else "",
    }


def review_npc(item: dict, ctx: Context) -> Verdict:
    name = normalize_name(item.get("name", ""))
    if name == normalize_name(ctx.player_name):
        return _reject(NPC, name, IS_PLAYER)
    if ctx.arranged and name == ctx.arranged["name"]:
        # 安排登場的人：年紀、實力、目標、性格用 Python 準備的；AI 只給描述（不合格的描述丟掉，之後再補寫）
        if reason := _name_problem(name, ctx, offered=True):
            return _reject(NPC, name, reason)
        return Verdict(NPC, name, True, record=_npc_record(ctx.arranged, _npc_texts(item) or {}, ctx))
    if reason := _name_problem(name, ctx):
        return _reject(NPC, name, reason)
    texts = _npc_texts(item)
    if texts is None or not (texts.get("appearance") or texts.get("profile")):
        return _reject(NPC, name, INVALID_TEXT)
    # 年齡層與實力層級必填（第 6 步）：Python 依此決定歲數與境界，缺了就不採用，不替 AI 猜
    if item.get("age") not in npc_mod.AGE_BANDS or item.get("power") not in npc_mod.POWER_TIERS:
        return _reject(NPC, name, INVALID_PROFILE)
    # 目標與四個性格軸也必填（第 10a 步）：機制層由 Python 存成 0–100，之後隨經歷移動
    if item.get("goal") not in npc_mod.GOALS or any(item.get(t) not in npc_mod.TRAIT_LEVELS for t in npc_mod.TRAITS):
        return _reject(NPC, name, INVALID_PROFILE)
    target = normalize_name(item.get("goal_target", ""))[:GOAL_TARGET_LEN] \
        if item["goal"] in npc_mod.GOALS_WITH_TARGET else ""
    profile = {"name": name, "age_band": item["age"], "power_tier": item["power"], "goal": item["goal"],
               "gender": item["gender"] if item.get("gender") in npc_mod.GENDERS else "",   # 沒填就由 Python 擲（16u）
               "goal_target": target, **{t: npc_mod.TRAIT_LEVELS[item[t]] for t in npc_mod.TRAITS}}
    return Verdict(NPC, name, True, record=_npc_record(profile, texts, ctx))


def _npc_record(profile: dict, texts: dict, ctx: Context) -> dict:
    """新人物要寫入的資料：機制層（名字、年齡層、實力、目標、性格）＋描述＋ Python 推導的欄位。"""
    race = profile.get("race") or ctx.race
    return {   # 安排登場的人外貌用 Python 定的（16m 第 4 題），說書人寫的不採用
        **{k: v for k, v in profile.items() if k != "looks"},
        "appearance": profile.get("looks") or texts.get("appearance", ""), "profile": texts.get("profile", ""),
        "race": race, **newcomer.kin({**profile, "race": race}),
        # 以下由 Python 推導，AI 無法指定（歲數、境界在寫入時依年齡層、實力層級、地點規模換算）
        "location": ctx.here,
        "status": "ALIVE",
        "ai_driven": True,          # 敘事中登場的 NPC 一律參與之後的背景演化（舊專案 B-12 漏標）
        "created_by": profile.get("created_by", "narrator"),   # 追捕者是 era.OFFICIAL_BY（16h 國法的官差）
        "first_seen_turn": ctx.turn_no,
    }


def review_npc_update(item: dict, ctx: Context) -> Verdict:
    """AI 提案更新已知 NPC 的描述（外貌、身分個性）。只改描述，不改事實。"""
    name = normalize_name(item.get("name", ""))
    if reason := _known_npc_problem(name, ctx, need_present=False):
        return _reject(NPC_UPDATE, name, reason)
    texts = _npc_texts(item)
    if not texts:
        return _reject(NPC_UPDATE, name, INVALID_TEXT)
    return Verdict(NPC_UPDATE, name, True, record={"name": name, **texts})


def review_relation(item: dict, ctx: Context) -> Verdict:
    """AI 提案判定以外的互動帶來的關係變化：NPC 必須在場、出現在本回合敘事裡。"""
    name = normalize_name(item.get("name", ""))
    if reason := _known_npc_problem(name, ctx, need_present=True):
        return _reject(RELATION, name, reason)
    if item.get("change") not in npc_mod.RELATION_CHANGES:
        return _reject(RELATION, name, INVALID_TEXT)
    return Verdict(RELATION, name, True, record={"name": name, "change": item["change"],
                                                 "reason": item.get("reason", "").strip()[:40]})


def review_favour(item: dict, ctx: Context) -> Verdict:
    """AI 提案的人情（16v 第 113 題）：在場、出現在本回合敘事裡。判定成不成功、輕重由 game/favours.py 看。"""
    name = normalize_name(item.get("name", ""))
    if reason := _known_npc_problem(name, ctx, need_present=True):
        return _reject(FAVOUR, name, reason)
    if item.get("way") not in FAVOUR_WAYS:
        return _reject(FAVOUR, name, INVALID_TEXT)
    return Verdict(FAVOUR, name, True, record={"name": name, "way": item["way"], "why": item.get("why", "").strip()[:30]})


def review_memory(item: dict, ctx: Context) -> Verdict:
    """AI 提案的見聞（說／做／見）。主體必須是已登錄的人或地點，而且出現在本回合敘事（「見」可以是所在地）。"""
    subject, mine = _own_subject(item, ctx)
    subject_kind, reason = _subject(subject, ctx, allow_here=mine or item.get("kind") == memory_mod.SAW)
    if reason:
        return _reject(MEMORY, subject, reason)
    text = _note_text(item.get("text", ""), ctx.player_name)
    if item.get("kind") not in memory_mod.NARRATOR_KINDS or not _len_ok(item.get("text", "").strip(), memory_mod.MEMORY_TEXT_LEN):
        return _reject(MEMORY, subject, INVALID_TEXT)
    if any(w in text for w in PYTHON_OWNED_WORDS):
        return _reject(MEMORY, subject, PYTHON_OWNED)
    return Verdict(MEMORY, subject, True, record={"subject_kind": subject_kind, "subject": subject,
                                                  "kind": item["kind"], "text": text})


def review_thread_open(item: dict, ctx: Context) -> Verdict:
    """AI 提案開線。承諾只能綁在 NPC 身上；懸念可以綁人或地點。期限只對承諾有效，沒給或不合法視為無期限。"""
    subject, _ = _own_subject(item, ctx)
    kind = item.get("kind")
    subject_kind, reason = _subject(subject, ctx, allow_here=True)
    if reason:
        return _reject(THREAD_OPEN, subject, reason)
    text = _note_text(item.get("text", ""), ctx.player_name)
    if kind not in memory_mod.THREAD_KINDS or not _len_ok(item.get("text", "").strip(), memory_mod.THREAD_TEXT_LEN) \
            or (kind in memory_mod.PROMISES and subject_kind != memory_mod.NPC):
        return _reject(THREAD_OPEN, subject, INVALID_TEXT)
    if any(t["subject"] == subject and t["text"] == text for t in ctx.open_threads.values()):
        return _reject(THREAD_OPEN, subject, ALREADY_KNOWN)
    if len(ctx.open_threads) >= memory_mod.MAX_ACTIVE_THREADS or len(memory_mod.sides(ctx.open_threads.values())) >= memory_mod.MAX_SIDE:
        return _reject(THREAD_OPEN, subject, THREAD_LIMIT)
    deadline = item.get("deadline") if kind in memory_mod.PROMISES and item.get("deadline") in memory_mod.DEADLINES \
        else "無期限"
    return Verdict(THREAD_OPEN, subject, True, record={"kind": kind, "subject_kind": subject_kind, "subject": subject,
                                                       "text": text, "deadline": deadline})


def review_thread_close(item: dict, ctx: Context) -> Verdict:
    """AI 提案結線：用聯絡簿裡的編號（「線3」或「3」），線頭必須還沒結束，綁定的對象要出現在本回合敘事。"""
    raw = str(item.get("thread", ""))
    digits = re.sub(r"\D", "", raw)
    no = int(digits) if digits else -1
    thread = ctx.open_threads.get(no)
    name = thread["subject"] if thread else raw[:12]
    if thread is None or thread.get("task"):   # 支線辦成了沒由 Python 判斷（domain/side.py）
        return _reject(THREAD_CLOSE, name, UNKNOWN_THREAD)
    if item.get("result") not in memory_mod.CLOSE_RESULTS:
        return _reject(THREAD_CLOSE, name, INVALID_TEXT)
    if thread["subject"] not in normalize_name(ctx.narrative):
        return _reject(THREAD_CLOSE, name, NOT_IN_NARRATIVE)
    return Verdict(THREAD_CLOSE, name, True, record={"no": no, "thread_id": thread["id"], "result": item["result"]})


def review_faction(item: dict, ctx: Context) -> Verdict:
    """勢力（第 10a 步，最小版）：名字規則同地點與人物；所在地必須是已知地點，沒給或不合法就用主角所在地。"""
    name = normalize_name(item.get("name", ""))
    if reason := _name_problem(name, ctx):
        return _reject(FACTION, name, reason)
    if item.get("type") not in society.FACTION_TYPES:
        return _reject(FACTION, name, INVALID_TEXT)
    location = normalize_name(item.get("location", ""))
    if location not in ctx.known_locations:
        location = ctx.here
    return Verdict(FACTION, name, True, record={"name": name, "type": item["type"], "location": location,
                                                "discovered_turn": ctx.turn_no})


def review_item(item: dict, ctx: Context) -> Verdict:
    """新物品（16p）：只進世界清單，名字不必出現在敘事（第 9 題）；不能和物品表、登錄過的新物品同名；
    底要是可以借的；描述不寫 Python 管的事。"""
    name, text = normalize_name(item.get("name", "")), (item.get("description") or "").strip()
    reason = _name_problem(name, ctx, offered=True) \
        or (ALREADY_KNOWN if name in ctx.known_items or name in items_mod.CATALOG else "")
    if not reason and (item.get("base") not in items_mod.BASES or not _len_ok(text, DESCRIPTION_LEN)):
        reason = INVALID_TEXT
    if not reason and any(w in text for w in PYTHON_OWNED_WORDS):
        reason = PYTHON_OWNED
    return _reject(ITEM, name, reason) if reason else Verdict(ITEM, name, True, record={
        "name": name, "base": item["base"], "description": text, "discovered_turn": ctx.turn_no})


def review_event(item: dict, ctx: Context) -> Verdict:
    """新事件（16p 第二批）：只進世界清單，規則同新物品；底牽涉人時場景要有 {who}，不牽涉人時不能有。"""
    name, text = normalize_name(item.get("name", "")), (item.get("scene") or "").strip()
    base = incident_mod.BASES.get(item.get("base"))
    known = name in ctx.known_events or any(s.name == name for s in incident_mod.SEEDS)
    reason = _name_problem(name, ctx, offered=True) or (ALREADY_KNOWN if known else "")
    if not reason and (base is None or not _len_ok(text, incident_mod.SCENE_LEN) or ("{who}" in text) != bool(base.who)):
        reason = INVALID_TEXT
    if not reason and any(w in text for w in PYTHON_OWNED_WORDS):
        reason = PYTHON_OWNED
    return _reject(EVENT, name, reason) if reason else Verdict(EVENT, name, True, record={
        "name": name, "base": item["base"], "scene": text, "discovered_turn": ctx.turn_no})


def review_bond(item: dict, ctx: Context) -> Verdict:
    """羈絆：甲對乙而言是〔種類〕。兩方都要已登錄（人物要活著）、出現在本回合敘事；
    種類要符合兩方的類型；戀人、伴侶雙方都必須成年；同一件事已記錄過就不再記。"""
    a, b = normalize_name(item.get("a", "")), normalize_name(item.get("b", ""))
    label = f"{a}→{b}"[:40]
    kinds = []
    for name in (a, b):
        if name in ("你", "主角", normalize_name(ctx.player_name)):
            return _reject(BOND, label, IS_PLAYER)   # 主角與人的關係由好感、信任記，不是羈絆提案
        if name in ctx.npc_info and ctx.npc_info[name]["status"] == "ALIVE":
            kinds.append(society.NPC)
        elif name in ctx.known_factions:
            kinds.append(society.FACTION)
        else:
            return _reject(BOND, label, UNKNOWN_SUBJECT)
    narrative = normalize_name(ctx.narrative)
    if a == b or not society.allowed(item.get("type"), *kinds):
        return _reject(BOND, label, INVALID_TEXT)
    if a not in narrative or b not in narrative:
        return _reject(BOND, label, NOT_IN_NARRATIVE)
    if item["type"] in society.ADULT_ONLY_BONDS and (ctx.npc_info[a]["minor"] or ctx.npc_info[b]["minor"]):
        return _reject(BOND, label, MINOR_BOND)   # 未成年底線：年齡不詳也算未成年
    record = {"a_kind": kinds[0], "a": a, "b_kind": kinds[1], "b": b, "type": item["type"]}
    if any(society.same_bond(record, existing) for existing in ctx.bonds):
        return _reject(BOND, label, ALREADY_KNOWN)
    return Verdict(BOND, label, True, record=record)


def review_self_text(kind: str, item: dict, task: str, ctx: Context) -> Verdict:
    """關於主角的一段文字：外貌（只是描寫，不帶來能力）、江湖傳言中的你（第 10c-3b 步）。
    只有這回合 Python 有請 AI 寫（task 不是空的）才收。"""
    text = item.get("text", "").strip()
    if not task:
        return _reject(kind, ctx.player_name, NOT_REQUESTED)
    if not NPC_TEXT_LEN[0] <= len(text) <= NPC_TEXT_LEN[1]:
        return _reject(kind, ctx.player_name, INVALID_TEXT)
    return Verdict(kind, ctx.player_name, True, record={"text": text})


def review_place_text(item: dict, ctx: Context) -> Verdict:
    """所在地的描述（地圖第二輪）：只有這回合有請 AI 寫才收，長度同地點描述。"""
    text = item.get("text", "").strip()
    if not ctx.place_task:
        return _reject(PLACE_TEXT, ctx.here, NOT_REQUESTED)
    if not DESCRIPTION_LEN[0] <= len(text) <= DESCRIPTION_LEN[1]:
        return _reject(PLACE_TEXT, ctx.place_task, INVALID_TEXT)
    return Verdict(PLACE_TEXT, ctx.place_task, True, record={"text": text})


def review_feature(item: dict, ctx: Context) -> Verdict:
    """眼前的環境物（16r）：只有這回合有請 AI 列才收；名字 2～8 個中文字，用途要在清單裡。"""
    name = normalize_name(item.get("name", ""))
    if not ctx.scene_task:
        return _reject(PLACE_FEATURES, name, NOT_REQUESTED)
    if not NAME_RE.match(name) or len(name) > 8 or item.get("use") not in scene.USES:
        return _reject(PLACE_FEATURES, name, INVALID_TEXT)
    return Verdict(PLACE_FEATURES, name, True, record={"name": name, "use": item["use"], "once": item.get("once") == "是"})


def review_rule(item: dict, ctx: Context) -> Verdict:
    """說書立下的規矩：綁在已知地點（沒寫＝主角所在），文字長短、時辰、行動、後果要合格（domain/house.py）。"""
    text, place = item.get("text", "").strip(), (item.get("place") or ctx.here).strip()
    enums = PROPOSAL_ENUMS[RULE]
    if place != ctx.here and place not in ctx.known_locations:
        return _reject(RULE, text, NOT_A_PLACE)
    if not house.TEXT_LEN[0] <= len(text) <= house.TEXT_LEN[1] or any(item.get(k) not in enums[k] for k in enums):
        return _reject(RULE, text, INVALID_TEXT)
    return Verdict(RULE, text, True, record={"place": place, "text": text, "when": item["when"], "act": item["act"],
                                             "word": item.get("word", "").strip()[:8], "cost": item["cost"]})


def review_history_text(item: dict, ctx: Context) -> Verdict:
    """一國的往事（16k）：只有這回合有請 AI 寫才收，20 到 200 字。"""
    text = item.get("text", "").strip()
    if not ctx.history_task:
        return _reject(HISTORY_TEXT, ctx.here, NOT_REQUESTED)
    if not HISTORY_LEN[0] <= len(text) <= HISTORY_LEN[1]:
        return _reject(HISTORY_TEXT, ctx.history_task, INVALID_TEXT)
    return Verdict(HISTORY_TEXT, ctx.history_task, True, record={"text": text})


def _with_new_entities(ctx: Context, verdicts: list[Verdict]) -> Context:
    """把本回合剛採用的人物、勢力加進審核羈絆用的 Context（年齡層孩童、少年＝未成年）。"""
    npc_info = dict(ctx.npc_info)
    factions = set(ctx.known_factions)
    for v in verdicts:
        if v.accepted and v.kind == NPC:
            npc_info[v.name] = {"status": "ALIVE", "location": ctx.here,
                                "minor": v.record["age_band"] in (npc_mod.CHILD, npc_mod.TEEN)}
        elif v.accepted and v.kind == FACTION:
            factions.add(v.name)
    return dataclasses.replace(ctx, npc_info=npc_info, known_factions=frozenset(factions))


def _subject(name: str, ctx: Context, *, allow_here: bool) -> tuple[str, str]:
    """記事、線頭綁定的對象：（種類, 拒絕原因）。必須已登錄；NPC 要活著；必須出現在敘事（所在地可免）。"""
    here = normalize_name(ctx.here)
    if name in ctx.npc_info:
        if ctx.npc_info[name]["status"] != "ALIVE":
            return "", UNKNOWN_NPC
        kind = memory_mod.NPC
    elif name in ctx.known_locations or name == here:
        kind = memory_mod.PLACE
    else:
        return "", UNKNOWN_SUBJECT
    if name not in normalize_name(ctx.narrative) and not (allow_here and kind == memory_mod.PLACE and name == here):
        return "", NOT_IN_NARRATIVE
    return kind, ""


def _own_subject(item: dict, ctx: Context) -> tuple[str, bool]:
    """提案的主語；寫成「你」或主角＝主角在此地的事，改記在所在地（16m 第 11 題）。回傳（主語, 是不是主角）。"""
    name = normalize_name(item.get("subject", ""))
    if name in ("你", "主角", normalize_name(ctx.player_name)):
        return normalize_name(ctx.here), True
    return name, False


def _note_text(text: str, player_name: str) -> str:
    """記事以名字記錄（下一世讀到時才知道是誰）：把「你」換成主角的名字。"""
    return text.strip().replace("你", player_name)


def _len_ok(text: str, bounds: tuple[int, int]) -> bool:
    return bounds[0] <= len(text) <= bounds[1]


def _npc_texts(item: dict) -> dict | None:
    """提案中的描述欄位；任一欄位長度不合就整筆不合格（回傳 None），全部沒填回傳空 dict。"""
    texts = {k: item.get(k, "").strip() for k in ("appearance", "profile") if item.get(k, "").strip()}
    if not all(NPC_TEXT_LEN[0] <= len(t) <= NPC_TEXT_LEN[1] for t in texts.values()):
        return None
    return texts


def _known_npc_problem(name: str, ctx: Context, *, need_present: bool) -> str:
    info = ctx.npc_info.get(name)
    if info is None or info["status"] != "ALIVE":
        return UNKNOWN_NPC
    if need_present and info["location"] != ctx.here:
        return NOT_PRESENT
    if name not in normalize_name(ctx.narrative):
        return NOT_IN_NARRATIVE
    return ""


def _name_problem(name: str, ctx: Context, *, offered: bool = False) -> str:
    """offered：Python 發出去的名字（WHITEPAPER 12.6），不必出現在敘事裡（事件會補一行告訴玩家）。"""
    if not NAME_RE.match(name):
        return INVALID_NAME
    if name in ctx.known_locations or name in ctx.known_npcs or name in ctx.known_factions \
            or name == normalize_name(ctx.current_location):
        return ALREADY_KNOWN
    if not offered and name not in normalize_name(ctx.narrative):
        return NOT_IN_NARRATIVE
    return ""


def name_events(verdicts: list[Verdict], narrative: str) -> list[str]:
    """採用了 Python 給的地名、敘事卻沒寫出來時，補一行讓玩家知道名字。
    人物不補（16m 第 4 題：「此人名叫」會被讀成在場的人改名），名字先出現在面板，下回合說書人才寫。"""
    narrative = normalize_name(narrative)
    labels = {LOCATION: "此地名叫"}
    return [f"{labels[v.kind]}{v.name}" for v in verdicts
            if v.accepted and v.kind in labels and v.name not in narrative]


def _reject(kind: str, name: str, reason: str) -> Verdict:
    return Verdict(kind, name, False, reason)
