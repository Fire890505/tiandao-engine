"""前期領域在回合流程裡（第 19-1 步）：出現、進去看守則、犯規與後果、情境、本體追人、破解與收穫。

規則在 domain/domains.py，主題在 domain/tales.py。資料來自回合開始時讀好的 rows["domains"]；
結果放在 Zones，由 service 在回合的交易裡寫入（write）。上演的情境、要應對的規則之物記在回合紀錄（delta 的 domain）。
"""
from __future__ import annotations

import dataclasses
import random
from dataclasses import dataclass, field

from ..domain import domains, era, heaven, items, judgment, laws, learn, legends, newlegends, newtales, rumors, space, undead
from ..domain import memory as m
from ..domain import npc as npc_mod
from ..domain.clock import SHICHEN_PER_MONTH
from ..domain.tales import BOSS, HERE, HURT1, HURT2, MARKED, NEAR, THING, fill, theme
from ..store import repos
from . import people, rites, sightings

RELIC_KINDS = (items.PILL, items.TALISMAN, items.ARTIFACT)   # 來由主人留下的東西：從這幾種擲


@dataclass
class Zones:
    """這回合領域的變化。record：記進回合紀錄的（上演的情境或規則之物）；scene：給說書人的這回合事件；prompt：【領域】。"""
    born: list[dict] = field(default_factory=list)
    changed: dict[str, dict] = field(default_factory=dict)
    events: list[str] = field(default_factory=list)
    changes: list[dict] = field(default_factory=list)
    threads: list[dict] = field(default_factory=list)
    closed: dict[str, dict] = field(default_factory=dict)
    rumors: list[dict] = field(default_factory=list)
    record: dict | None = None
    scene: str = ""
    prompt: str = ""
    moved: bool = False                                 # 這回合破解有進度（牌組看）
    swallowed: set[str] = field(default_factory=set)   # 儀式型：期限到了死去的人（被儀式吞了，不變亡者）
    marks: list = field(default_factory=list)           # 天道注視（硬解，16l）
    more: bool = False                                  # 這回合出現的怪談擲中局中補寫（第 128 系列乙第二批，service._more 看）

    def now(self, d: dict) -> dict:
        return self.changed.get(d["id"], d)


def parents(rows: dict) -> dict[str, str]:
    return {l["name"]: l["parent"] for l in rows["locations"]}


def active(rows: dict, z: Zones, *, place: str = "", neighbor: str = "") -> dict | None:
    """籠罩中的領域：蓋得到 place 的（地點本身或它底下的子地點），或以 neighbor 為{鄰地}的。"""
    up = parents(rows)
    return next((d for d in (z.now(d) for d in rows["domains"]) if d["status"] == domains.ACTIVE
                 and (place and domains.covers(up, d["place"], place) or d["neighbor"] == neighbor)), None)


# ── 出現 ───────────────────────────────────────────────────────────────────
def spawn(z: Zones, rows: dict, rng: random.Random, *, start: int, end: int, here: str,
          s: sightings.Sightings, r: rites.Rites) -> None:
    """世界脈動跨過的月份裡，有沒有地方被籠罩。同一個地方只能有一個（已經被籠罩的、主角所在的地方都不挑）。
    出現就傳出「怪談」傳聞。儀式型（19-3）：不直接出事，改成那一帶開始流傳錯的玩法（game/rites.py）。
    都市傳說（第 19-2 步）跟領域一起抽（生靈級權重比照家級），抽中就記在 s。"""
    months = end // SHICHEN_PER_MONTH - start // SHICHEN_PER_MONTH
    if not domains.appears(rng, months):
        return
    picks = ([(domains.WEIGHT[p[1]], p) for p in free(rows, here)]
             + [(legends.WEIGHT, p) for p in sightings.options(rows, s, here)])
    if not picks:
        return
    pick = rng.choices([p for _, p in picks], weights=[w for w, _ in picks])[0]
    if isinstance(pick[-1], legends.Legend):
        sightings.born(s, rng, rows, pick[0], pick[-1], end)
        s.more = random.Random(f"{pick[0]}:{end}:more").random() < newlegends.MORE_CHANCE   # 局中補寫（第 128 系列乙第 4-1 題甲）；另開亂數，不動這回合的
        return
    if pick[2].doer:
        rites.start(r, rng, rows, pick[0], pick[2], end)
        return
    born(z, rng, rows, pick, end)
    z.more = random.Random(f"{pick[0]}:{end}:more").random() < newtales.MORE_CHANCE   # 局中補寫怪談（同傳說）


def _world(rows: dict) -> dict:
    near = {l["name"]: [n["name"] for n in space.neighbors(rows["connections"], l["name"])] for l in rows["locations"]}
    dead = {p["name"] for p in rows["npcs"] if p["status"] != "ALIVE"}
    return dict(locations=rows["locations"], neighbors=near, npcs=rows["npcs"], undead=rows["undead"],
                mourners=domains.mourners(rows["bonds"], dead))


def free(rows: dict, here: str) -> list:
    """可以被籠罩的（地點, 規模, 主題）：已經被籠罩的、主角所在的地方、主角的家不挑
    （家：現代落腳處是老公寓、凶宅又是住家，幾乎每局一開門就是同一篇，2026-11-23 回報）。"""
    up = parents(rows)
    taken = [here] + [d["place"] for d in rows["domains"] if d["status"] == domains.ACTIVE]
    home = rows.get("home", "")   # 只擋家和家裡的小地方，不擋家所在的村鎮
    blocked = {l["name"] for l in rows["locations"] if any(domains.overlaps(up, l["name"], p) for p in taken)
               or home and domains.covers(up, home, l["name"])}
    return domains.options(**_world(rows), blocked=blocked, card=rows.get("era", era.DEFAULT), states=sightings.states(rows))


def born(z: Zones, rng: random.Random, rows: dict, pick: tuple, end: int) -> dict:
    """新的領域，傳出「怪談」傳聞（規模越大傳得越遠）。"""
    d = domains.make(rng, pick, **_world(rows), clock_now=end)
    z.born.append(d)
    z.rumors.append(rumors.make(rumors.TALE, d["place"], place=d["place"], when=end, detail=domains.rumor_text(d),
                                lv=domains.power(d)))
    return d


def due(z: Zones, rows: dict, updates, *, end: int, turn_no: int) -> dict:
    """儀式型：期限到了還沒人收尾，做儀式的人撐不過去——死在那裡（不變亡者，記在 z.swallowed）、領域照舊。
    死訊寫進背景演化的結果 updates（遺物落地、線頭落空都照 NPC 死亡的流程）。回傳換上死訊的 rows。"""
    alive = {p["name"] for p in rows["npcs"] if p["status"] == "ALIVE"}
    for d in rows["domains"]:
        when = domains.deadline(d)
        if d["status"] != domains.ACTIVE or when is None or end < when or d["person"] not in alive:
            continue
        name = d["person"]
        updates.fields.setdefault(name, {}).update(status="FALLEN", condition=npc_mod.CONDITIONS[-1])
        updates.dead.add(name)
        updates.world_notes.append(m.note(m.NPC, name, m.DEATH, f"在{d['place']}照錯了玩法做儀式，沒能撐過去",
                                          clock_now=when, turn_no=turn_no))
        updates.rumors.append(rumors.make(rumors.TALE, d["place"], place=d["place"], when=when,
                                          detail=f"的{name}照錯了玩法做儀式，死在那裡", lv=domains.power(d)))
        z.swallowed.add(name)
    fallen = {"status": "FALLEN", "condition": npc_mod.CONDITIONS[-1]}
    return {**rows, "npcs": [{**p, **fallen} if p["name"] in z.swallowed else p for p in rows["npcs"]]}


# ── 判定前：本體追人、規則之物 ─────────────────────────────────────────────
def facing(rows: dict, sheet: dict, intent: judgment.Intent, last: dict, life: str) -> tuple[judgment.Intent, int | None]:
    """這回合的對手是不是領域裡的東西。被本體追著還想離開：改成脫身判定（對手是本體）。回傳（意圖, 對手戰力）。"""
    d = active(rows, Zones(), place=sheet["location"])
    if not d or d["life"] != life:
        return intent, None
    if d["chased"]:
        if intent.destination and not domains.covers(parents(rows), d["place"], intent.destination):
            intent = dataclasses.replace(intent, nature=judgment.COMBAT, targets=(judgment.ESCAPE,), blocked="")
        return dataclasses.replace(intent, difficulty=domains.BOSS_DIFFICULTY), domains.power(d, boss=True)
    return intent, domains.power(d) if (last.get("domain") or {}).get("thing") else None


def law_here(rows: dict, sheet: dict, life: str) -> str | None:
    """主角在這一生進過的領域裡：怪談主題的系（16l 第 6-5 題：技能加倍、同系歸零）；不在領域裡回傳 None。"""
    d = active(rows, Zones(), place=sheet["location"])
    return laws.system_of(theme(d["tale"]).law) if d and d["life"] == life else None


# ── 回合 ───────────────────────────────────────────────────────────────────
def play(z: Zones, rows: dict, sheet: dict, *, life: str, before: str, verdict: judgment.Judgment, player_input: str,
         last: dict, clock_now: int, rng: random.Random, target: str, rested: set[str], gone: set[str],
         npc_changes: dict, threads: list[dict], turn_no: int, protagonist: str, quiet: bool) -> dict:
    """這回合的領域。before：回合開始時的所在地；rested／gone：這回合安息的、消散的亡者（id）；
    quiet：這回合已經有別的事件（亡者現身），不再上演情境。回傳角色卡。"""
    here = sheet["location"]
    left = active(rows, z, place=before)
    if left and left["life"] == life and not domains.covers(parents(rows), left["place"], here):   # 走出領域
        sheet = domains.marked(sheet, False)   # 被盯上的狀態拿掉、本體不再追
        z.changed[left["id"]] = {**left, "chased": False}
        z.events.append(f"走出了{left['place']}")
    sheet = _ghost_lifted(z, rows, sheet, life=life, rested=rested, gone=gone, clock_now=clock_now, rng=rng,
                          npc_changes=npc_changes, threads=threads, protagonist=protagonist)
    inside, outside = active(rows, z, place=here), active(rows, z, neighbor=here)
    d = inside or (outside if outside and outside["life"] == life else None)
    if d is None:
        return sheet
    tale, ghost = theme(d["tale"]), _ghost(rows, d)
    n = domains.names(d, ghost)
    doer_dead = bool(tale.doer and d["person"]) and not _alive(rows, d["person"])
    if inside and d["life"] != life:   # 這一生第一次進來：看到守則、開線頭，這回合不算犯規
        d = {**d, "life": life, "step": 0, "strikes": 0, "staged": [], "chased": False}
        z.changed[d["id"]] = d
        z.events.append(f"走進{d['place']}，看見{tale.notice_at(d['scale'])}上寫著守則")
        z.threads.append(_thread(d, "弄清來由", clock_now, turn_no))
        if domains.deadline(d) and not doer_dead:   # 儀式型：救出做儀式的人，有期限
            z.threads.append({**_thread(d, "", clock_now, turn_no), "subject_kind": m.NPC, "subject": d["person"],
                              "text": domains.rescue_text(d), "deadline_shichen": domains.deadline(d)})
        z.prompt = domains.prompt(d, n, doer_dead, reader(rows, sheet))
        return sheet
    nature, when = verdict.action_type, domains.period(clock_now)
    if inside and domains.forced(d, sheet["realm_lv"], verdict, player_input):
        sheet, z.changed[d["id"]] = _force(z, d, sheet, rows=rows, npc_changes=npc_changes, threads=threads,
                                           protagonist=protagonist, clock_now=clock_now, life=life)
        return sheet
    if inside:
        sheet, d = _rules(z, d, sheet, tale=tale, names=n, nature=nature, when=when, text=player_input,
                          rec=last.get("domain") or {}, verdict=verdict)
    if tale.steps and domains.step_done(d, at=HERE if inside else NEAR, when=when, nature=nature, text=player_input,
                                        target=target, success=verdict.is_success or not verdict.rolled,
                                        alone=doer_dead):
        z.moved = True
        sheet, d = _step(z, d, sheet, tale=tale, names=n, threads=threads, clock_now=clock_now, turn_no=turn_no,
                         rng=rng, npc_changes=npc_changes, protagonist=protagonist, rows=rows, life=life)
    z.changed[d["id"]] = d
    if inside and d["status"] == domains.ACTIVE:
        if not z.record and not quiet and domains.scene_rules(d) and rng.random() < domains.SCENE_CHANCE:
            i = rng.choice(domains.scene_rules(d))
            d = z.changed[d["id"]] = {**d, "staged": d["staged"] + [i]}
            z.record = {"place": d["place"], "scene": i}
            z.scene = f"（領域）{fill(tale.rules[i].scene, n)}。只寫到這件事發生、主角還沒應對為止"
        z.prompt = domains.prompt(d, n, doer_dead, reader(rows, sheet))
    return sheet


def reader(rows: dict, sheet: dict) -> str | None:
    """守則誰念（第 7-1c 批）：主角識字＝自己（空字串）；不識字找在場識字的人；都沒有 None。
    不合時宜的人讀這個時代的字降 learn.BEHIND 級（第 8-3-4 題乙；主角至少識字，脫節也降不到不識字）。"""
    if learn.level(sheet) >= learn.READ:
        return ""
    card = rows.get("era") or era.DEFAULT
    return next((p["name"] for p in people.present(rows, sheet["location"])
                 if learn.level(p) - learn.BEHIND * era.behind(p, card) >= learn.READ), None)


def _rules(z: Zones, d: dict, sheet: dict, *, tale, names: dict, nature: str, when: set[str], text: str, rec: dict,
           verdict: judgment.Judgment) -> tuple[dict, dict]:
    """犯規：上回合的情境怎麼應對、規則之物打散或避開了沒、這回合有沒有犯禁令；後果、犯規次數、本體。"""
    broken = []
    i = rec.get("scene") if rec.get("place") == d["place"] else None
    if i in d["rules"] and domains.broke_scene(tale.rules[i], nature=nature, text=text, names=names):
        broken.append(tale.rules[i])
    if rec.get("thing") and rec.get("place") == d["place"]:
        name = fill(tale.thing, names)
        if verdict.is_success and nature in (judgment.COMBAT, judgment.STEALTH):
            z.events.append(f"擺脫了{name}")
        else:
            sheet = _cost(z, sheet, HURT2, f"沒能擺脫{name}")
    broken += [tale.rules[j] for j in domains.broken_bans(d, when=when, nature=nature, text=text, names=names)]
    for r in broken:   # 該說的沒說要寫清楚，否則說書人會照字面寫成主角說了（2026-10-06 真模型實測）
        rule = fill(r.text, names)
        missed = r.good and not any(w in text for w in r.good)
        sheet = _cost(z, sheet, r.cost, f"照著「{rule}」做了，事情不對勁" if r.fake
                      else f"沒有照著「{rule}」應對" if missed else f"觸犯了「{rule}」")
        if r.cost == THING:
            z.record = {"place": d["place"], "thing": True}
            z.scene = f"（領域）{fill(tale.thing, names)}出現了，擋住主角。只寫到它出現為止；choices 之一要是應對它（戰鬥或避開）"
    strikes = d["strikes"] + sum(2 if r.cost == BOSS else 1 for r in broken if r.cost)
    boss = fill(tale.boss, names)
    if d["chased"]:
        sheet, changes, events = domains.hurt(sheet, domains.BOSS_HURT, lethal=True)
        z.changes += changes
        z.events += [f"{boss}追了上來", *events]
    elif strikes >= domains.STRIKES_FOR_BOSS:
        z.events.append(f"{boss}現身了，追著你不放")
    return sheet, {**d, "strikes": strikes, "chased": d["chased"] or strikes >= domains.STRIKES_FOR_BOSS}


def _cost(z: Zones, sheet: dict, cost: str, event: str) -> dict:
    z.events.append(event)
    if cost in (HURT1, HURT2):
        sheet, changes, events = domains.hurt(sheet, domains.HURTS[cost])
        z.changes += changes
        z.events += events
    elif cost == MARKED:
        sheet = domains.marked(sheet, True)
        z.events.append(f"留下狀態「{domains.MARK}」")
    return sheet


def _step(z: Zones, d: dict, sheet: dict, *, tale, names: dict, threads: list[dict], clock_now: int, turn_no: int,
          rng: random.Random, npc_changes: dict, protagonist: str, rows: dict, life: str) -> tuple[dict, dict]:
    """完成一步：揭露、換提示線頭；最後一步就破解。"""
    step = tale.steps[d["step"]]
    d = {**d, "step": d["step"] + 1}
    z.events.append(f"查明了：{fill(step.reveal, names)}")
    _close_hint(z, d, threads, life, clock_now)
    if d["step"] < len(tale.steps):
        z.threads.append(_thread(d, fill(step.hint, names), clock_now, turn_no))
        return sheet, d
    rescue = domains.rescue_text(d)   # 儀式型：救出做儀式的人的線頭跟著了結
    z.closed.update({t["id"]: {"status": m.RESOLVED, "closed_shichen": clock_now, "result_note": "救出來了"}
                     for t in threads if t["session_id"] == life and t["status"] in m.ACTIVE and t["text"] == rescue})
    return _solve(z, d, sheet, rows=rows, rng=rng, npc_changes=npc_changes, protagonist=protagonist, clock_now=clock_now,
                  life=life)


def _solve(z: Zones, d: dict, sheet: dict, *, rows: dict, rng: random.Random, npc_changes: dict, protagonist: str,
           clock_now: int, life: str) -> tuple[dict, dict]:
    """破解：籠罩解除、感悟、傳聞、被困的人好感上升、有遺物的擲一件。"""
    tale = theme(d["tale"])
    z.events.append(f"{d['place']}的怪談破了")
    if domains.covers(parents(rows), d["place"], sheet["location"]):
        sheet = domains.marked(sheet, False)
    if sheet["realm_lv"] >= 1:
        insight, reached = laws.reward(sheet, tale.law, domains.INSIGHT[d["scale"]])
        sheet = {**sheet, "insight": insight}
        z.events += reached
    z.rumors.append(rumors.make(rumors.CLEARED, protagonist, place=d["place"], when=clock_now, lv=domains.power(d),
                                subject_lv=sheet["realm_lv"], life=life))
    up = parents(rows)
    saved = d["person"] if tale.doer and _alive(rows, d["person"]) else ""   # 儀式型：做儀式的人得救
    trapped = {p["name"] for p in rows["npcs"] if p["status"] == "ALIVE" and domains.covers(up, d["place"], p["location"])}
    for name in sorted(trapped - {saved}):   # 被困的人（籠罩的區域裡）：救命（第 1-2 批對照表）
        relation, events = npc_mod.shift(name, people.changed_relation(rows, npc_changes, name), npc_mod.RESCUED)
        npc_changes.setdefault(name, {})["relation"] = relation
        z.events += events
    if saved:
        relation, events = npc_mod.shift(saved, people.changed_relation(rows, npc_changes, saved), npc_mod.RESCUED)
        npc_changes.setdefault(saved, {})["relation"] = relation
        z.events += [f"{saved}得救了", *events]
    if tale.relic:
        sheet, fact = items.grant(rng, sheet, rng.choice(RELIC_KINDS), domains.RELIC_TIER[d["scale"]])
        z.events.append(f"在來由的主人留下的東西裡{fact}")
    return sheet, {**d, "status": domains.CLEARED, "chased": False, "solved_shichen": clock_now}


def _force(z: Zones, d: dict, sheet: dict, *, rows: dict, npc_changes: dict, threads: list[dict], protagonist: str,
           clock_now: int, life: str) -> tuple[dict, dict]:
    """硬解（16l 第 6-6 題）：散去、不算破解，沒有遺物與感悟；困在裡面的人被波及重傷；霸道的傳聞；天道注視。"""
    z.events.append(f"仗著修為強行打散了籠罩{d['place']}的怪談")
    if d["person"] and _alive(rows, d["person"]):
        npc_changes.setdefault(d["person"], {})["state"] = {"condition": "重傷", "status": "ALIVE"}
        z.events.append(f"困在裡面的{d['person']}被波及，身受重傷")
    _close_hint(z, d, threads, life, clock_now)
    rescue = domains.rescue_text(d)
    z.closed.update({t["id"]: {"status": m.RESOLVED, "closed_shichen": clock_now, "result_note": "怪談被強行打散"}
                     for t in threads if t["session_id"] == life and t["status"] in m.ACTIVE and t["text"] == rescue})
    z.rumors.append(rumors.make(rumors.FORCED, protagonist, place=d["place"], when=clock_now, lv=domains.power(d),
                                subject_lv=sheet["realm_lv"], life=life))
    z.marks.append((heaven.FORCE, heaven.GAIN[heaven.FORCE]))
    return domains.marked(sheet, False), {**d, "status": domains.LIFTED, "chased": False, "solved_shichen": clock_now}


def _ghost_lifted(z: Zones, rows: dict, sheet: dict, *, life: str, rested: set[str], gone: set[str], clock_now: int,
                  rng: random.Random, npc_changes: dict, threads: list[dict], protagonist: str) -> dict:
    """亡者執念型：幽魂安息（這一生了結的）＝破解；被打散或別人了結的＝籠罩散去，沒有收穫。"""
    for d in [z.now(d) for d in rows["domains"]]:
        u = _ghost(rows, d)
        if d["status"] != domains.ACTIVE or not u or u["id"] not in gone:
            continue
        _close_hint(z, d, threads, life, clock_now)
        if u["id"] in rested:
            sheet, z.changed[d["id"]] = _solve(z, d, sheet, rows=rows, rng=rng, npc_changes=npc_changes,
                                               protagonist=protagonist, clock_now=clock_now, life=life)
        else:
            z.changed[d["id"]] = {**d, "status": domains.LIFTED, "chased": False, "solved_shichen": clock_now}
            z.events.append(f"籠罩{d['place']}的怨氣散了")
    return sheet


def _alive(rows: dict, name: str) -> bool:
    return any(p["name"] == name and p["status"] == "ALIVE" for p in rows["npcs"])


def _ghost(rows: dict, d: dict) -> dict | None:
    return next((u for u in rows["undead"] if d["ghost"] and u["name"] == d["ghost"] and u["place"] == d["place"]
                 and u["form"] == undead.GHOST), None)


def _thread(d: dict, hint: str, clock_now: int, turn_no: int) -> dict:
    return {"kind": m.MYSTERY, "subject_kind": m.PLACE, "subject": d["place"], "text": domains.thread_text(d["place"], hint),
            "status": m.OPEN, "deadline_shichen": None, "opened_shichen": clock_now, "opened_turn": turn_no,
            "touched_shichen": clock_now}


def _close_hint(z: Zones, d: dict, threads: list[dict], life: str, clock_now: int) -> None:
    head = f"{d['place']}{domains.THREAD_HEAD}"
    for t in threads:
        if t["session_id"] == life and t["status"] in m.ACTIVE and t["text"].startswith(head):
            z.closed[t["id"]] = {"status": m.RESOLVED, "closed_shichen": clock_now, "result_note": "查明了"}


# ── 畫面與寫入 ─────────────────────────────────────────────────────────────
def panel(rows: dict, sheet: dict, life: str) -> dict | None:
    """「領域守則」面板：主角在籠罩中的領域裡（這一生進來過）。"""
    d = active(rows, Zones(), place=sheet["location"])
    if not d or d["life"] != life:
        return None
    n, tale = domains.names(d, _ghost(rows, d)), theme(d["tale"])
    doer = (f"{d['person']}照著流傳的玩法做了儀式，" + ("已經死在這裡" if not _alive(rows, d["person"]) else "還困在這裡")
            if tale.doer and d["person"] else "")
    who = reader(rows, sheet)
    return {"place": d["place"], "notice": tale.notice_at(d["scale"]) + (f"，{who}念給你聽" if who else ""), "scale": d["scale"],
            "rules": domains.rules_text(d, n) if who is not None else [domains.UNREAD], "doer": doer,
            "lore": domains.lore(d, n), "strikes": d["strikes"], "chased": d["chased"]}


def write(conn, world_id: str, z: Zones) -> None:
    for d in z.born:
        repos.insert_domain(conn, world_id, d)
    # 被籠罩的地方描述換回預設，下次有人在場時請說書人照現在的樣子重寫（地圖第二輪）
    repos.set_description(conn, world_id, [d["place"] for d in z.born], space.NEW_PLACE_DESCRIPTION)
    for did, d in z.changed.items():
        repos.update_domain(conn, did, d)
