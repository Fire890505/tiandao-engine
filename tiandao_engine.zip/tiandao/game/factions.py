"""勢力之間（第 7-3b1a 批，WHITEPAPER ㊺～㊿、(52)～(54)；牌單 rules/content/faction.txt，草稿 progress/勢力牌草稿.md；數字暫定）。

- 算哪些勢力：所在州和相鄰州的村鎮裡、還有活人的凡間勢力（society.FACTION_TYPES）。
- 好感（㊺）：原因沿用 reasons 表，持有者、對象寫勢力名；壽元固定當 YEARS 年；加首領之間的好惡（最多 ±LEAD）；
  打壓時朝廷對宗門固定 -HUNT（(54)）。分五層 TIERS。隱世時宗門跟凡人勢力不互記、不立約（(54)）。
- 聲勢（㊽）：同一張壓力卡，鍵是勢力名、一條「聲勢」，每月 pressure.month 朝目標走；推力見 World.pushes。
- 每年（跨年那個月；補算這回合以前的月份不算）：成員的事記到勢力頭上（㊻①）→ 立約（㊼）→ 每個勢力抽一張勢力牌（㊿）。
- 宗門、武館不歸附、不自立（門派上下層的從屬不動，㊼）；議和兩邊各記一筆小的好原因，免得隔年又打（實作時定）。
- 你所屬的勢力抽到的牌是主事候選（schedule.FACTION）；相連的地方挑一件寫成一行「聽說」。
- 第 7-3b1b1 批：打垮（(53)，World.fall）；附庸跟著主家（(52)：主家的盟友、敵人也算、主家首領好惡也算一筆、附庸不自己立約）；
  你做的事（events 表，有人知道是你才算）也算到你所屬的勢力（㊻①）；AI 寫的盟友、敵對改記原因（pact_reasons，㊻③）；
  隱世時宗門的人傷了凡人勢力的人，傳聞不寫是誰（(54)）。
- 第 7-3b1b2 批：挑撥、撮合、調停（meddle）、嫁禍（caught；認法是讀懂的「勢力之間」「說到哪個勢力」）、套話（gossip）、角色卡那行（card_line）。
"""
from __future__ import annotations

import random
from dataclasses import dataclass, field

from ..config import PROJECT_ROOT
from ..domain import atlas, chains, crime, deck, evolution, hearsay, identity, memory, opinion, pacts, pending, pressure, reading, rites, rumors, schedule, society, space, stage
from ..domain import era as era_mod
from ..domain import npc as npc_mod
from ..domain.clock import SHICHEN_PER_MONTH as MONTH, SHICHEN_PER_YEAR as YEAR
from . import routes

DECK = deck.read(PROJECT_ROOT / "rules" / "content" / "faction.txt")
KEY = "聲勢"
YEARS, LEAD, HUNT = 100, 30, 30
TIERS = ((60, "親近"), (20, "友善"), (-9, "中立"), (-49, "冷淡"), (-100, "敵視"))
FEAR_AT, WAR_YEARS, CD, LEAVE, RIVAL = 20, 3, 3 * YEAR, 0.1, 60
MAX, FIRST = 24, 12
SIZE = {"小": opinion.SMALL, "大": opinion.BIG, "重": opinion.GRAVE}
PAIR = ("好", "對勢")   # 看目標的條件
AIMED = ("原", "原對", "原我", "對勢", "從", "斷", "壓")   # 要目標的結果
GOOD = {opinion.SAVE: 1, opinion.HELP: 1, opinion.ROB: -1}   # 成員之間的原因算到勢力頭上（大的一筆）
MINE = {hearsay.KILL: (opinion.ATTACK, opinion.GRAVE, -1), hearsay.HURT: (opinion.ATTACK, opinion.BIG, -1),
        hearsay.SAVE: (opinion.SAVE, opinion.BIG, 1)}   # 你做的事（events 表）
STYLE = 0.1   # 宗主換人改門風的機率（125-7）
DIE, FLEE, FELL = 70, 40, "覆滅"   # 打垮：首領野心 ≥ DIE 寧死不降、≥ FLEE 遷走；traits 記覆滅的時刻
AI_PACT = {"盟友": ("交好", 1), "敵對": ("交惡", -1)}
FRAME, FRAMED, CATCH = "嫁禍", "@", 0.3   # 嫁禍（(51)）：events 的 detail["frame"]＝被栽贓的勢力；home 裡用「@勢力」；每年識破的機會
TALK = {"親近": "跟{}親如一家", "友善": "跟{}走得很近", "冷淡": "跟{}不太對付", "敵視": "恨死{}了"}   # 套話（(55)）
STIR, WED, PEACE, _ = reading.PLOYS   # 你在勢力之間動手腳（(51)、㊼-1）：讀懂的「勢力之間」，嫁禍是 FRAME
TALKS = (STIR, WED, PEACE)            # 交談的這三種一律判說服（service._take）
assert all(c.who == "勢力" and all(t.split(":")[0] in AIMED + ("勢", "換", "散") for t in c.result.split()) for c in DECK), "勢力牌的結果寫錯了"


def tier(v: int) -> str:
    return next(n for at, n in TIERS if v >= at)


def _steps(v: int) -> set[str]:
    """聲勢門檻：-2 → {-1, -2}（「勢:-1」＝≤ -1）。"""
    return {f"{k if v > 0 else -k:+d}" for k in range(1, abs(v) + 1)}


_likes, _hit = pacts.likes, pacts.match   # 好感層、條件比對（跟國事牌、盟事牌共用）


@dataclass
class Scene:
    """你所屬的勢力抽到的牌：ask 是候選；被挑中才有 scene（放進【主事】）和 lines。"""
    ask: schedule.Ask | None = None
    scene: str = ""
    lines: list[str] = field(default_factory=list)


class World:
    """這回合的勢力：bonds、原因、壓力卡隨每年的結果更新，要寫回的都放進 updates。"""

    def __init__(self, rows: dict, updates, names: list[str], turn_no: int, now: int, skip: set[str] = frozenset(), life: str = ""):
        self.rows, self.u, self.turn_no, self.skip = rows, updates, turn_no, skip   # skip：化身、這回合動過的人不換位、不走
        self.life = life or next((b["a"] for b in rows.get("mine", []) if b["type"] in society.MEMBER_BONDS), "")   # 這一生
        self.card, self.bonds = rows["pressure"], list(rows["bonds"])
        self.by = {p["name"]: p for p in rows["npcs"]}
        every = {f["name"] for f in rows["factions"]}
        self.fs = {f["name"]: dict(f) for f in rows["factions"] if f["name"] in names}
        self.rs = [r for r in rows.get("npc_reasons", []) + updates.reasons if r["holder"] in every]
        self.town = {n: space.town_of(rows["locations"], f["location"]) for n, f in self.fs.items()}
        a = rows.get("atlas")
        self.where = where = atlas.state_map(a, rows["connections"]) if a else {}
        self.state = {n: where.get(t, "") for n, t in self.town.items()}
        self.xy = {s["name"]: (s["x"], s["y"]) for s in (a or {}).get("states", [])}
        e = rows["era"]
        self.stance = era_mod.OPEN if e["era"] == era_mod.ANCIENT else e.get("stance", "")
        self.died = {n["subject"]: n["clock_shichen"] for n in rows.get("memories", []) + updates.world_notes if n["kind"] == memory.DEATH}
        self.npc_like = society.liking(rows["npcs"], rows["bonds"], rows.get("npc_reasons", []) + updates.reasons, now, rows["factions"])
        self.names = [n for n in names if self.crew(n)]
        self.news, self.drawn, self.memo = [], {}, {}   # [(勢力, 一句)]；勢力 → 抽到的牌那一句；好感的快取

    # ── 讀 ───────────────────────────────────────────────────────────────
    def alive(self, n: str) -> bool:
        return self.by.get(n, {}).get("status") == "ALIVE"

    def crew(self, f: str, kinds=society.MEMBER_BONDS) -> list[dict]:
        return [self.by[b["a"]] for b in self.bonds if b["b"] == f and b["type"] in kinds and self.alive(b["a"])]

    def head(self, f: str) -> dict | None:
        return next(iter(self.crew(f, ("首領",))), None)

    def has(self, a: str, b: str, kind: str) -> dict | None:
        pairs = {(a, b), (b, a)} if kind in society.SYMMETRIC else {(a, b)}
        return next((x for x in self.bonds if x["type"] == kind and (x["a"], x["b"]) in pairs), None)

    def lord(self, f: str) -> str:
        return next((b["b"] for b in self.bonds if b["type"] == "從屬" and b["a"] == f and b["b"] in self.fs), "")

    def side(self, f: str) -> set[str]:
        return {f, self.lord(f)} - {""}

    def ties(self, f: str, kind: str) -> set[str]:
        """f 這邊（連主家）跟誰有這種約，對方的附庸也算（(52)）。"""
        mine = self.side(f)
        out = {b["a"] if b["b"] in mine else b["b"] for b in self.bonds if b["type"] == kind and {b["a"], b["b"]} & mine}
        return (out | {g for g in self.fs if self.lord(g) in out}) - mine

    def foes(self, f: str) -> list[str]:
        return sorted(self.ties(f, "敵對"))

    def level(self, f: str) -> int:
        return self.card.get(f, {}).get(KEY, {}).get("v", 0)

    def like(self, a: str, b: str, t: int, axis: str = opinion.LIKE) -> int:
        """a 對 b 的好感（或畏懼）；記了新原因、換了羈絆就重算（memo）。"""
        key = (a, b, t, axis)
        if key not in self.memo:
            base, x, y = 0, self.head(a), self.head(b)
            if axis == opinion.LIKE:   # 首領之間的好惡；附庸再加主家首領的一筆（(52)）
                lead = lambda p, q: max(-LEAD, min(LEAD, self.npc_like(p["name"], q["name"]))) if p and q and p is not q else 0
                base = lead(x, y) + lead(self.head(self.lord(a)), y)
                base -= HUNT if self.stance == era_mod.HUNTED and (self.fs[a]["type"], self.fs[b]["type"]) == ("朝廷", "宗門") else 0
            self.memo[key] = opinion.total([r for r in self.rs if (r["holder"], r["toward"], r["axis"]) == (a, b, axis)], YEARS, t, base)
        return self.memo[key]

    def apart(self, a: str, b: str) -> bool:
        """隱世時宗門跟凡人勢力不互記（(54)）。"""
        return self.stance == era_mod.HIDDEN and (self.fs[a]["type"] == "宗門") != (self.fs[b]["type"] == "宗門")

    def near(self, a: str, b: str) -> bool:
        x, y = self.xy.get(self.state[a]), self.xy.get(self.state[b])
        return self.state[a] == self.state[b] or bool(x and y) and abs(x[0] - y[0]) + abs(x[1] - y[1]) <= 1

    def war(self, f: str, g: str = "") -> str:
        """f 跟 g（沒給就任一個）在打的那場仗的因果鏈根（domain/chains）。"""
        events = self.rows.get("happened", []) + self.u.happened
        return next((r for e in self.foes(f) if g in ("", e) and (r := chains.war_root(events, f, e))), "")

    def told(self, r: dict) -> str:
        """一筆原因怎麼說（因果鏈的「加上…」）：成員之間動手寫誰對誰，其他照 chains.WORDS 或種類。"""
        if r["kind"] == opinion.ATTACK:
            of = lambda n, f: self.has(n, f, "首領") or self.has(n, f, "成員")
            n = next((n for n in reversed(self.rows.get("memories", []) + self.u.world_notes)
                      if n["kind"] in (memory.DEATH, memory.NEWS) and n.get("actor") and r["clock_shichen"] - YEAR < n["clock_shichen"] <= r["clock_shichen"]
                      and of(n["subject"], r["holder"]) and of(n["actor"], r["toward"])), None)
            if n:
                return f"{n['actor']}{'殺了' if n['kind'] == memory.DEATH else '打傷了'}{n['subject']}"
        return chains.WORDS.get(r["kind"], r["kind"])

    def lost(self, f: str, t: int) -> int:
        """這一年死了幾個首領、成員。"""
        return sum((d := self.died.get(b["a"])) is not None and t - YEAR < d <= t
                   for b in self.bonds if b["b"] == f and b["type"] in society.MEMBER_BONDS)

    # ── 寫 ───────────────────────────────────────────────────────────────
    def tie(self, a: str, b: str, kind: str, t: int, a_kind: str = society.FACTION) -> None:
        bond = {"session_id": "", "a_kind": a_kind, "a": a, "b_kind": society.FACTION, "b": b, "type": kind,
                "clock_shichen": t, "turn_no": self.turn_no}
        self.bonds.append(bond)
        self.memo.clear()
        if (a, b, (kind,)) in self.u.unbonds:   # 這回合斷了又接回來：不斷就好
            self.u.unbonds.remove((a, b, (kind,)))
        else:
            self.u.bonds.append(bond)

    def cut(self, bond: dict | None) -> None:
        if not bond:
            return
        self.bonds = [x for x in self.bonds if x is not bond]
        self.memo.clear()
        if bond in self.u.bonds:   # 這回合才接的：不寫就好
            self.u.bonds.remove(bond)
        else:
            self.u.unbonds.append((bond["a"], bond["b"], (bond["type"],)))

    def feel(self, a: str, b: str, kind: str, size: str, sign: int, t: int, axis: str = opinion.LIKE, event: str = "") -> None:
        r = opinion.reason(a, b, opinion.hit(kind, axis, size, sign), t, event_id=event)
        self.rs.append(r)
        self.u.reasons.append(r)
        self.memo.clear()

    def push(self, f: str, by: int, t: int, why: str) -> None:
        self.card = pressure.apply(self.card, f, [f"{KEY}{by:+d}"], t, why)

    def say(self, f: str, text: str, t: int) -> None:
        self.news.append((f, text))
        self.u.rumors.append(rumors.make(rumors.FACTION, f, place=self.town[f], when=t, detail=text[:40]))

    def note(self, who: str, text: str, t: int) -> None:
        self.u.world_notes.append(memory.note(memory.NPC, who, memory.NEWS, text, clock_now=t, turn_no=self.turn_no))

    # ── 每月：聲勢的推力（㊽、㊾、(52)）────────────────────────────────────
    def pushes(self, f: str, t: int) -> list[tuple]:
        out, crew, head = [], self.crew(f), self.head(f)
        hb = self.has(head["name"], f, "首領") if head else None
        if hb and t - YEAR < hb["clock_shichen"] <= t and any(   # 前任這一年死了（死了才繼位，pulse.succeed）
                b["b"] == f and b["type"] == "首領" and t - YEAR < self.died.get(b["a"], -YEAR) <= t for b in self.bonds):
            out.append((KEY, -1, "換人", f"自從{head['name']}接任"))
            out += [(KEY, -1, "爭位", "自從爭位")] * any(p is not head and p["realm_lv"] == head["realm_lv"]
                                                         and min(p["ambition"], head["ambition"]) >= RIVAL for p in crew)
        dead = self.lost(f, t)
        share = dead / max(1, len(crew) + dead)
        out += [(KEY, -2 if share >= 0.3 else -1, "折損", "自從折了不少人手")] if share >= 0.1 else []
        new = sum(b["b"] == f and b["type"] == "成員" and bool(b.get("turn_no")) and t - YEAR < b["clock_shichen"] <= t and self.alive(b["a"])
                  for b in self.bonds)
        out += [(KEY, 1, "人多", "自從人手多了")] if new and new * 10 >= len(crew) - new > 0 else []
        k = "靈氣" if self.fs[f]["type"] == "宗門" else "興衰"
        v = pressure.levels(self.card, self.town[f]).get(k, 0)
        out += [(KEY, v // 2, "地方", f"自從{self.town[f]}{pressure.LEVELS[k][v + 2]}")] if abs(v) == pressure.EDGE else []
        out += [(KEY, -1, "交戰", f"自從跟{e}打仗") for e in self.foes(f) if e in self.fs and self.lost(f, t) > self.lost(e, t)]
        lord = self.lord(f)
        v = self.level(lord) if lord else 0
        return out + ([(KEY, v // 2, "主家", f"自從{lord}{'勢大' if v > 0 else '衰落'}")] if abs(v) == pressure.EDGE else [])

    # ── 每年 ─────────────────────────────────────────────────────────────
    def year(self, rng: random.Random, t: int) -> None:
        self.deeds(t)
        self.caught(rng, t)
        self.pacts(t)
        for f in list(self.names):
            if f in self.names:   # 這一年被滅的不抽
                self.draw(rng, f, t)

    def deeds(self, t: int) -> None:
        """這一年成員之間的事算到勢力頭上（㊻①）：殺人重的壞、打傷大的壞；交戰中死人，死的那方記一筆小的畏懼；救命、幫忙、偷搶大的。"""
        home: dict[str, set[str]] = {}
        for b in self.bonds:
            if b["type"] in society.MEMBER_BONDS and b["b"] in self.fs:
                home.setdefault(b["a"], set()).add(b["b"])
        span = lambda x: t - YEAR < x["clock_shichen"] <= t
        notes = [n for n in self.rows.get("memories", []) + self.u.world_notes if n.get("actor") and span(n) and n["kind"] in (memory.DEATH, memory.NEWS)]
        acts = [(n["subject"], n["actor"], opinion.ATTACK, opinion.GRAVE if n["kind"] == memory.DEATH else opinion.BIG, -1, "") for n in notes]
        acts += [(r["holder"], r["toward"], r["kind"], opinion.BIG, GOOD[r["kind"]], "") for r in self.rows.get("npc_reasons", []) + self.u.reasons
                 if r["kind"] in GOOD and not r["session_id"] and span(r) and r["holder"] in home]
        mine = [b for b in self.rows.get("mine", []) if b["type"] in society.MEMBER_BONDS and b["b"] in self.fs]
        life = self.life
        home[life] = {b["b"] for b in mine}
        home.update({FRAMED + f: {f} for f in self.fs})
        known = {k["event_id"] for k in self.rows.get("knows", []) + self.u.knows if k["knows_who"]}
        for e in self.rows.get("happened", []) + self.u.happened:   # 你做的事：有人知道是你才算（不是秘密的救命照算）；嫁禍的記在被栽贓的勢力頭上
            frame = (e.get("detail") or {}).get("frame", "")
            if life and e["actor"] == life and e["kind"] in MINE and span(e) and (frame or not e["secret"] or e["id"] in known):
                acts.append((e["target"], FRAMED + frame if frame else life, *MINE[e["kind"]], e["id"]))   # event_id 也是因果鏈的根
        for who, by, kind, size, sign, eid in acts:
            for a in home.get(who, ()):
                for b in sorted(home.get(by, set()) - {a}):
                    if not self.apart(a, b):
                        self.feel(a, b, kind, size, sign, t, event=eid)
                        if size == opinion.GRAVE and b in self.foes(a):
                            self.feel(a, b, opinion.THREAT, opinion.SMALL, 1, t, opinion.FEAR)

    def caught(self, rng: random.Random, t: int) -> None:
        """嫁禍（(51)）：記在被栽贓那方頭上的原因，每年擲一次識破；識破了那幾筆撤掉，兩邊首領各對你記一筆重的壞原因，傳成傳聞。"""
        framed = {e["id"]: e for e in self.rows.get("happened", []) if (e.get("detail") or {}).get("frame")}
        for eid in sorted({r["event_id"] for r in self.rows.get("npc_reasons", []) if r["event_id"] in framed}):
            if rng.random() >= CATCH:
                continue
            e, gone = framed[eid], [r for r in self.rs if r["event_id"] == eid]
            self.rs = [r for r in self.rs if r["event_id"] != eid]
            self.memo.clear()
            self.u.dropped += [r["id"] for r in gone]
            sides = sorted({r["holder"] for r in gone} | {e["detail"]["frame"]})
            self.u.mine += [opinion.reason(h["name"], opinion.ME, opinion.hit(FRAME, opinion.LIKE, opinion.GRAVE, -1), t, life=e["session_id"])
                            for h in map(self.head, sides) if h]
            if here := next((f for f in sides if f in self.fs), ""):
                self.say(here, f"原來{e['target']}那件事是{(e['detail'].get('name') or '有人')}栽贓給{e['detail']['frame']}的", t)

    def pacts(self, t: int) -> None:
        """立約（㊼）：結盟、斷盟、議和、交戰。附庸跟著主家，不自己立約（(52)）。"""
        for i, a in enumerate(self.names):
            for b in self.names[i + 1:]:
                if self.apart(a, b) or self.lord(a) or self.lord(b):
                    continue
                la, lb = self.like(a, b, t), self.like(b, a, t)
                ally, war = self.has(a, b, "盟友"), self.has(a, b, "敵對")
                if ally and min(la, lb) < -9:
                    self.cut(ally)
                    hurt, other = (b, a) if la < lb else (a, b)   # 還比較喜歡對方的那方被背棄
                    self.feel(hurt, other, opinion.BETRAY, opinion.BIG, -1, t)
                    self.say(a, f"{a}和{b}鬧翻了，盟約作罷", t)
                elif war and (max(self.like(a, b, t, opinion.FEAR), self.like(b, a, t, opinion.FEAR)) >= FEAR_AT
                              or t - war["clock_shichen"] >= WAR_YEARS * YEAR):
                    self.cut(war)
                    self.feel(a, b, "議和", opinion.SMALL, 1, t)
                    self.feel(b, a, "議和", opinion.SMALL, 1, t)
                    self.say(a, f"{a}和{b}議和了", t)
                elif not ally and not war and min(la, lb) >= 20 and (self.wed(a, b, t) or any(
                        max(self.like(a, c, t), self.like(b, c, t)) < -49 for c in self.names if c not in (a, b))):
                    self.tie(a, b, "盟友", t)
                    self.say(a, f"{a}和{b}結盟了", t)
                elif not ally and not war and min(la, lb) < -49 and self.near(a, b):
                    self.tie(a, b, "敵對", t)
                    self.say(a, f"{a}和{b}打起來了", t)
                    if d := chains.blame(self.rs, a, b, t, YEARS, self.told):
                        self.u.happened.append(chains.event(chains.WAR, a, b, self.town[a], d.pop("from"), t, self.turn_no, **d))

    def wed(self, a: str, b: str, t: int) -> bool:
        return any(r["kind"] == "聯姻" and {r["holder"], r["toward"]} == {a, b} and opinion.alive(r, YEARS, t) for r in self.rs)

    # ── 勢力牌（㊿）─────────────────────────────────────────────────────────
    def facts(self, f: str) -> dict:
        head, crew = self.head(f), self.crew(f)
        town = pressure.levels(self.card, self.town[f])
        out = {"勢": _steps(self.level(f)), "型": {self.fs[f]["type"]}, "戰": {"是"} if self.foes(f) else set(),
               "從": {"是"} if self.lord(f) and self.fs[f]["type"] not in society.HALLS else set(),
               "壓": {f"{k}{s}" for k, v in town.items() for s in _steps(v)}}
        if head:
            out["首"] = {f"{w}{n}" for w, k in (("野心", "ambition"), ("善念", "kindness")) for n in (60, 70) if head[k] >= n}
            out["員"] = {f"野心{n}" for n in (60, 70) if any(p is not head and p["ambition"] >= n and p["realm_lv"] >= head["realm_lv"] for p in crew)}
        return out

    def pair(self, k: str, f: str, g: str, t: int) -> set[str]:
        if k == "好":
            return _likes(self.like(f, g, t))
        return _steps(self.level(g)) | ({"比我低"} if self.level(g) < self.level(f) else set())

    def aim(self, words: str, f: str, g: str) -> bool:
        same = [h for h in self.names if h != f and self.state[h] == self.state[f]]
        ok = {"同州": self.state[g] == self.state[f], "盟友": g in self.ties(f, "盟友"), "主家": self.lord(f) == g,
              "交戰": g in self.foes(f), "最高": g in same and self.level(g) == max(self.level(h) for h in same)}
        return all(ok[w] for w in words.split("、") if w) and self.lord(g) != f

    def heir(self, c: deck.Card, f: str) -> dict | None:
        head, n = self.head(f), int(dict(c.need).get("員", "野心0")[2:])
        k = {"野心": "ambition", "善念": "kindness"}[c.target.split(":")[1]]
        pool = [p for p in self.crew(f, ("成員",)) if head and not {p["name"], head["name"]} & self.skip and p["ambition"] >= n
                and (not n or p["realm_lv"] >= head["realm_lv"])]
        return max(pool, key=lambda p: (p[k], p["name"]), default=None)

    def match(self, c: deck.Card, f: str, me: dict, t: int) -> tuple[bool, str]:
        """（合不合, 目標）。"""
        swap = c.target.startswith("接:")
        if not all(_hit(v, me.get(k, ())) for k, v in c.need if k not in PAIR) or swap and not self.heir(c, f) \
                or "從:目標" in c.result.split() and (self.fs[f]["type"] in society.HALLS or self.lord(f)):
            return False, ""
        if not (any(k in PAIR for k, _ in c.need) or c.target and not swap or any(x.split(":")[0] in AIMED for x in c.result.split())):
            return True, ""
        cands = [g for g in self.names if g != f and not self.apart(f, g) and self.aim("" if swap else c.target, f, g)
                 and all(_hit(v, self.pair(k, f, g, t)) for k, v in c.need if k in PAIR)]
        g = max(cands, key=lambda g: (abs(self.like(f, g, t)), self.state[g] == self.state[f], g), default="")
        return bool(g), g

    def draw(self, rng: random.Random, f: str, t: int) -> None:
        row, me = self.card.get(f, {}), self.facts(f)
        fits = [(c, g) for c in DECK if c.name not in row.get("cd", {}) for ok, g in [self.match(c, f, me, t)] if ok]
        top = max((len(c.need) for c, _ in fits), default=0)
        pool = [x for x in fits if len(x[0].need) == top]
        if not pool:
            return
        c, g = rng.choice(pool)
        self.card = pressure.put(self.card, f, {**row, "cd": {**row.get("cd", {}), c.name: t + CD}})
        self.play(rng, c, f, g, t)

    def play(self, rng: random.Random, c: deck.Card, f: str, g: str, t: int) -> None:
        head, why = self.head(f), f"自從{c.name}"
        heir = self.heir(c, f) if c.target.startswith("接:") else None
        text = c.text.format(勢=f, 對=g, 首領=(head or {}).get("name", ""), 接=(heir or {}).get("name", ""),
                             地=self.town[g] if g and "壓:" in c.result else self.town[f])
        fall = bool(g) and self.level(g) == -pressure.EDGE and g in self.foes(f) and "對勢:-" in c.result   # 已衰微又被搶（(53)）
        for x in c.result.split():
            k, _, v = x.partition(":")
            if k in ("原", "原對", "原我"):
                size, sign = SIZE[v[0]], 1 if v[1] == "好" else -1
                if k != "原對":
                    self.feel(f, g, c.name, size, sign, t)
                if k != "原我":
                    self.feel(g, f, c.name, size, sign, t)
            elif k in ("勢", "對勢"):
                self.push(f if k == "勢" else g, int(v), t, why)
            elif k == "壓":
                town, root, old = self.town[g], self.war(f, g), dict(self.card.get(self.town[g], {}))
                self.card = pressure.apply(self.card, town, [v], t, why, root)
                self.u.happened += [chains.event(chains.TOP, "", town, town, root, t, self.turn_no, key=n, v=x, why=why,   # 當場推到盡頭：前一級算別人的
                                                 mine=chains.HALF, also=chains.bare(old.get(n, {}).get("why", ["", ""])[1]))
                                    for n, x in pressure.levels(self.card, town).items()
                                    if root and abs(x) == pressure.EDGE and old.get(n, {}).get("v") != x]
            elif k == "從":
                self.tie(f, g, "從屬", t)
            elif k == "斷":
                self.cut(self.has(f, g, "從屬"))
            elif k == "散":
                for p in self.crew(f, ("成員",)):
                    if p["name"] not in self.skip and rng.random() < LEAVE:
                        self.cut(self.has(p["name"], f, "成員"))
                        self.note(p["name"], f"離開了{f}", t)
            elif k == "換":
                self.swap(c, f, head, heir, t)
        self.say(f, text, t)
        self.drawn[f] = text
        if fall:
            self.fall(rng, f, g, t)

    def fall(self, rng: random.Random, f: str, g: str, t: int) -> None:
        """打垮（(53)）：照輸方首領的野心三選一，一定結束交戰。野心 ≥ DIE 寧死不降＝滅；
        ≥ FLEE 或宗門、武館（不歸附）＝遷到相鄰州的村鎮，沒地方去的宗門、武館滅；其他降（從屬勝方）。"""
        head, halls = self.head(g), self.fs[g]["type"] in society.HALLS
        amb, away = (head or {}).get("ambition", 0), self.away(rng, g)
        way = "滅" if amb >= DIE else "遷" if (amb >= FLEE or halls) and away else "滅" if halls else "降"
        drop = ("敵對",) if way == "遷" else ("盟友", "敵對")
        for x in [x for x in self.bonds if g in (x["a"], x["b"])
                  and (x["type"] in drop or x["type"] == "從屬" and (x["a"] == g or way == "滅"))]:
            self.cut(x)
        if way == "降":
            self.tie(g, f, "從屬", t)
            self.say(f, f"{g}被{f}打垮，只好歸附了{f}", t)
        elif way == "遷":
            self.say(f, f"{g}被{f}趕出了{self.town[g]}，搬到{away}去了", t)
            self.fs[g]["location"] = self.town[g] = away
            self.state[g] = self.where.get(away, "")
            self.u.factions.setdefault(g, {})["location"] = away
        else:
            self.say(f, f"{g}被{f}滅了" + ("，" + self.wipe(f, g, head, t) if head else "") + "，門人四散", t)

    def away(self, rng: random.Random, g: str) -> str:
        """遷到哪：相鄰州（不是同州）的一個村鎮；沒有天下骨架就沒地方去。"""
        x = self.xy.get(self.state[g])
        y = lambda p: self.xy.get(self.where.get(p, ""))
        towns = sorted(l["name"] for l in self.rows["locations"] if l["type"] in rites.TOWN_TYPES and x and (q := y(l["name"]))
                       and abs(q[0] - x[0]) + abs(q[1] - x[1]) == 1)
        return rng.choice(towns) if towns else ""

    def wipe(self, f: str, g: str, head: dict, t: int) -> str:
        """滅：成員散成散人、首領戰死（化身、這回合動過的人不動）、traits 記覆滅。回傳傳聞補的那句。"""
        for p in self.crew(g):
            if p["name"] not in self.skip:
                self.cut(self.has(p["name"], g, "首領") or self.has(p["name"], g, "成員"))
        self.fs[g]["traits"] = {**(self.fs[g].get("traits") or {}), FELL: t}
        self.u.factions.setdefault(g, {})["traits"] = self.fs[g]["traits"]
        self.names.remove(g)
        name = head["name"]
        if name in self.skip:
            return f"{name}下落不明"
        p = self.by[name] = {**head, "status": "FALLEN", "condition": npc_mod.CONDITIONS[-1]}
        if p.get("opened"):   # 命者死了：當場收（同 pulse）
            evolution.close(p, stage.LEFT)
        self.u.fields.setdefault(name, {}).update(evolution.changed_fields(head, p))
        self.u.dead.add(name)
        self.died[name] = t
        self.u.world_notes.append(memory.note(memory.NPC, name, memory.DEATH, f"{g}覆滅時戰死", clock_now=t, turn_no=self.turn_no,
                                              actor=(self.head(f) or {}).get("name", "")))
        return f"{name}戰死"

    def hide(self) -> None:
        """隱世時宗門的人傷了凡人勢力的人：這回合的傳聞不寫是誰（(54)「不明人士」）。"""
        if self.stance != era_mod.HIDDEN:
            return
        kind = {f["name"]: f["type"] for f in self.rows["factions"]}
        home: dict[str, set[str]] = {}
        for b in self.rows["bonds"]:
            if b["type"] in society.MEMBER_BONDS:
                home.setdefault(b["a"], set()).add(kind.get(b["b"], ""))
        for r in self.u.rumors:
            if r["kind"] in (rumors.KILL, rumors.WOUND, rumors.HURT) and not r["life"] and "宗門" in home.get(r["subject"], ()) \
                    and home.get(r["target"], set()) & (set(society.FACTION_TYPES) - {"宗門"}):
                r["subject"] = ""

    def swap(self, c: deck.Card, f: str, head: dict, heir: dict, t: int) -> None:
        """換首領（㊾）：舊首領降為成員、對新首領記一筆重的壞原因；新首領上任，聲勢 -1 留一年。"""
        old, new = head["name"], heir["name"]
        self.cut(self.has(old, f, "首領"))
        self.tie(old, f, "成員", t, society.NPC)
        self.cut(self.has(new, f, "成員"))
        self.tie(new, f, "首領", t, society.NPC)
        self.push(f, -1, t, f"自從{new}接任")
        self.u.reasons.append(opinion.reason(old, new, opinion.hit(c.name, opinion.LIKE, opinion.GRAVE, -1), t))
        self.note(new, f"接任{f}首領", t)
        self.note(old, f"被迫讓出{f}首領之位", t)
        rng = random.Random(f"{self.rows['seed']}:style:{f}:{t}")
        if self.fs[f]["type"] == "宗門" and rng.random() < STYLE:   # 宗主換人改門風（125-7、第 8-2 批）
            self.fs[f]["traits"] = {**(self.fs[f].get("traits") or {}), "門風": rng.choice(crime.STYLES).name}
            self.u.factions.setdefault(f, {})["traits"] = self.fs[f]["traits"]


def turn(rows: dict, updates, towns: list[str], *, start: int, end: int, here: str, turn_no: int,
         skip: set[str] = frozenset(), life: str = "") -> tuple[dict, Scene]:
    """這幾處的勢力補到 end：聲勢每月、跨年那個月立約和抽牌。回傳（換上新壓力卡和羈絆的 rows, 你所屬勢力的候選）。"""
    w, last = World(rows, updates, around(rows, towns), turn_no, end, skip, life), end // MONTH
    w.hide()
    first = {f: max(last - MAX, w.card[f]["t"] // MONTH if "t" in w.card.get(f, {}) else last - FIRST) + 1 for f in w.names}
    for m in range(min(first.values(), default=last + 1), last + 1):
        t = m * MONTH
        for f in (x for x in w.names if first[x] <= m):
            ps = w.pushes(f, t)
            row, moved = pressure.month(w.card.get(f, {}), t, ps, random.Random(f"{rows['seed']}:faction:{f}:{m}"))
            w.card = pressure.put(w.card, f, row)
            updates.happened += [chains.event(chains.TOP, "", f, w.town[f], d.pop("from"), t, turn_no, key=k, v=v, why=why, **d)
                                 for k, v, d, why in chains.tops(moved, row, ps, lambda: w.war(f))]
        if t > start and t % YEAR == 0:
            w.year(random.Random(f"{rows['seed']}:faction:{m}"), t)
    mine = sorted({b["b"] for b in rows.get("mine", []) if b["type"] in society.MEMBER_BONDS} & set(w.drawn))
    near, out = routes.around(rows, here), Scene()
    heard = [text for f, text in w.news if w.town[f] in near and f not in mine]
    updates.events += [f"聽說：{heard[0]}"] if heard else []
    if mine:
        text = w.drawn[mine[0]]

        def run(sheet: dict) -> dict:
            out.scene, out.lines = f"（勢力）{text}", [text]
            return sheet
        out.ask = schedule.Ask(schedule.FACTION, pending.NOW, turn_no, run)
    return {**rows, "pressure": w.card, "bonds": w.bonds, "npcs": [w.by[p["name"]] for p in rows["npcs"]],
            "factions": [w.fs.get(f["name"], f) for f in rows["factions"]]}, out


def live(rows: dict) -> list[str]:
    """還在的凡間勢力（沒覆滅）。"""
    return [f["name"] for f in rows["factions"] if f["type"] in society.FACTION_TYPES and not (f.get("traits") or {}).get(FELL)]


def home(rows: dict, name: str) -> str:
    """這個人所屬、還在的凡間勢力（沒有就空字串）。"""
    fs = set(live(rows))
    return next((b["b"] for b in rows["bonds"] if b["a"] == name and b["type"] in society.MEMBER_BONDS and b["b"] in fs), "")


def around(rows: dict, towns: list[str], but: set[str] = frozenset()) -> list[str]:
    """這幾處（所在州和相鄰州的村鎮）還在的凡間勢力：勢力之間算這些。
    讀懂「說到哪個勢力」也列這些，but＝在場的人自己的勢力不列（9B 常挑成對方自己那一家）。"""
    places = set(towns)
    return sorted(f["name"] for f in rows["factions"] if f["type"] in society.FACTION_TYPES and not (f.get("traits") or {}).get(FELL)
                  and space.town_of(rows["locations"], f["location"]) in places and f["name"] not in but)


def meddle(rows: dict, updates, f: str, g: str, way: str, ok: bool, *, likes, me: int, of, lv: int, now: int) -> str:
    """挑撥、撮合、調停（(51)、㊼-1）：f＝你交談那人的勢力，g＝讀懂的說到哪個勢力，way＝讀懂的勢力之間；ok＝這回合說服成了。
    likes(名字)：他對你的好感；me、of：你和 NPC 的地位（people.standing）；lv：你的境界。
    回傳給說書人的事實；挑撥沒成回傳 STIR（由呼叫端記你交談那人對你的原因）。"""
    if way not in TALKS or not g or g == f:
        return ""
    w = World(rows, updates, live(rows), 0, now)
    if g not in w.names or f not in w.names or w.apart(f, g):
        return ""
    if way == STIR:
        if ok:
            w.feel(f, g, STIR, opinion.SMALL, -1, now)
            return f"你的話在{f}那邊起了作用，{f}對{g}起了嫌隙"
        return STIR
    if not ok:
        return ""
    heads = [h for h in (w.head(f), w.head(g)) if h]
    sect = "宗門" in (w.fs[f]["type"], w.fs[g]["type"])
    top = max((of(h) for h in heads), default=0)
    weight = len(heads) == 2 and all(likes(h["name"]) >= 20 for h in heads) and (
        me >= top - 1 or sect and lv >= max(h["realm_lv"] for h in heads) - 1)   # ㊼-1
    war = w.has(f, g, "敵對")
    if weight and way == WED:
        w.feel(f, g, "聯姻", opinion.BIG, 1, now)
        w.feel(g, f, "聯姻", opinion.BIG, 1, now)
        w.say(f, f"{f}和{g}結了親家", now)
        return f"在你撮合下，{f}和{g}結了親家"
    if weight and war:
        w.cut(war)
        w.feel(f, g, "議和", opinion.SMALL, 1, now)
        w.feel(g, f, "議和", opinion.SMALL, 1, now)
        w.say(f, f"{f}和{g}議和了", now)
        return f"在你調停下，{f}和{g}議和了"
    w.feel(f, g, "勸和", opinion.SMALL, 1, now)
    w.feel(g, f, "勸和", opinion.SMALL, 1, now)
    return f"{f}和{g}聽進了你幾句勸" + ("" if weight else "，但你分量不夠，成不了事")


def gossip(rows: dict, updates, f: str, now: int) -> list[str]:
    """套話（(55)）：f 對其他勢力的好感層，加最大那筆原因；中立的不說，最多三句，不給數字。"""
    w = World(rows, updates, live(rows), 0, now)
    if f not in w.names:
        return []
    out = []
    for g in sorted((g for g in w.names if g != f and not w.apart(f, g)), key=lambda g: (-abs(w.like(f, g, now)), g)):
        if word := TALK.get(tier(w.like(f, g, now))):
            rs = [r for r in w.rs if (r["holder"], r["toward"], r["axis"]) == (f, g, opinion.LIKE) and opinion.alive(r, YEARS, now)]
            top = max(rs, key=lambda r: abs(r["value"]), default=None)
            out.append(f + word.format(g) + (f"，自從{top['kind']}" if top else ""))
    return out[:3]


def card_line(rows: dict, f: str) -> str:
    """角色卡所屬勢力那行（(55)）：「鐵掌會（興盛）：與青幫結盟；與黑虎幫交戰」，主家、附庸也寫。"""
    other = lambda b: b["b"] if b["a"] == f else b["a"]
    got = {k: [other(b) for b in rows["bonds"] if b["type"] == k and f in (b["a"], b["b"])] for k in ("盟友", "敵對")}
    lord = [b["b"] for b in rows["bonds"] if b["type"] == "從屬" and b["a"] == f]
    under = [b["a"] for b in rows["bonds"] if b["type"] == "從屬" and b["b"] == f]
    parts = [f"與{'、'.join(x)}{w}" for x, w in ((got["盟友"], "結盟"), (got["敵對"], "交戰")) if x]
    parts += [f"附庸於{'、'.join(lord)}"] * bool(lord) + [f"附庸有{'、'.join(under)}"] * bool(under)
    v = rows.get("pressure", {}).get(f, {}).get(KEY, {}).get("v", 0)
    return f"{f}（{pressure.LEVELS[KEY][v + pressure.EDGE]}）" + ("：" + "；".join(parts) if parts else "")


def era_lean(factions: list[dict], reasons: list[dict], card: dict, era_card: dict, now: int) -> dict[str, float]:
    """換時代時修士處境的權重倍數（7-3c1，(67)）：朝廷、宗門之間敵視的比例加打壓；宗門聲勢興盛、衰微的比例加並存、隱世；
    隱世時曝光度越低越容易再隱世。各最多加倍。"""
    gov, sects = ([f["name"] for f in factions if f["type"] == k] for k in ("朝廷", "宗門"))
    like = lambda x, y: opinion.total([r for r in reasons if (r["holder"], r["toward"], r["axis"]) == (x, y, opinion.LIKE)], YEARS, now)
    pairs = [(g, s) for g in gov for s in sects]
    share = lambda xs: sum(xs) / len(xs) if xs else 0
    up = [card.get(s, {}).get(KEY, {}).get("v", 0) for s in sects]
    low = share([v < 0 for v in up])
    if era_card.get("stance") == era_mod.HIDDEN:
        low = max(low, 1 - era_card.get("exposure", 0) / identity.FLIP_AT)
    return {era_mod.HUNTED: 1 + share([min(like(g, s), like(s, g)) < -49 for g, s in pairs]),
            era_mod.OPEN: 1 + share([v > 0 for v in up]), era_mod.HIDDEN: 1 + low}


def pact_reasons(bond: dict, t: int) -> list[dict]:
    """AI 寫的盟友、敵對改記成兩邊各一筆大的原因（㊻③）：立約由 Python 每年判。其他羈絆回傳空的。"""
    kind, sign = AI_PACT.get(bond["type"], ("", 0)) if bond["a_kind"] == bond["b_kind"] == society.FACTION else ("", 0)
    return [opinion.reason(x, y, opinion.hit(kind, opinion.LIKE, opinion.BIG, sign), t)
            for x, y in ((bond["a"], bond["b"]), (bond["b"], bond["a"]))] if sign else []
