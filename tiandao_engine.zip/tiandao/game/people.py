"""NPC 在回合流程裡的小工具（第 6、10a、10b 步）：認出對象、打聽、關係（含初次見面，第 10c-3b 步）、
在場人物的畫面與聯絡簿那一行、年齡一致性檢查。

規則本身在 domain/npc.py、domain/evolution.py；這裡只把回合資料（service._world_rows 讀好的 rows）接上規則。
除了 write_changes、ensure_now、settle_family 以外都不碰資料庫。
"""
from __future__ import annotations

import dataclasses
import random

from ..domain import character as character_mod
from ..domain import atlas, crime, era, evolution, family, favour, identity, judgment, laws, learn, legacy, lineage, names, opinion, plot, profile, races, rank, realm, region, reputation, routine, society, space, voice as voice_mod
from ..domain import home as home_mod
from ..domain import looks as outfit
from ..domain import npc as npc_mod
from ..store import repos
from ..store.db import transaction
from . import background, news, proposals

TARGETED_NATURES = (judgment.COMBAT, judgment.SOCIAL, judgment.STEALTH)   # 會有對象 NPC 的行動
INQUIRY_HARD_PLACES = ("荒野", "秘境", "廢墟")   # 沒什麼人可問的地方：打聽改為困難
# 一致性檢查用的詞（只記進遙測，不阻擋）
CHILD_WORDS = ("孩童", "小孩", "孩子", "稚童", "女童", "男童", "小女孩", "小男孩", "少年", "少女")
ELDER_WORDS = ("老者", "老人", "老翁", "老嫗", "白髮蒼蒼", "鬚髮皆白", "中年")
INTIMATE_WORDS = ("親吻", "擁吻", "曖昧", "調情", "愛慕", "心動", "親熱", "同床", "求親", "婚配")
WARN_WINDOW = 12   # 名字前後幾個字內出現才算
TEXT_FIELDS = (("appearance", "外貌"), ("profile", "身分"))   # 說話由 Python 組（第 7-1d 批，voice）
POINTING = ("他", "她", "對方")   # 動手沒點名時，要這樣說才算衝著眼前的人
LOOKING = ("人", "誰")            # 觀察、探索的話裡有這些字才算在找人
KIN_WORDS = ("養父", "養母", "父親", "母親")
SEEK = ("打聽", "尋找", "去找", "追", "前往")   # 問起、去找不在場的人可以，當他在眼前不行
FILL = (("看看四周", judgment.OBSERVE), ("向附近的人打聽", judgment.SOCIAL), ("想想下一步往哪走", judgment.OBSERVE))
BLANK_TAG = {"nature": "", "difficulty": "", "target": ""}
NOT_HERE = "（不在這裡）"
HOME_BUSY = "在家忙著"   # 家人該出門的時段


def find(rows: dict, name: str) -> dict | None:
    return next((p for p in rows["npcs"] if p["name"] == name), None)


def present(rows: dict, here: str) -> list[dict]:
    """在這裡、活著、這個時段沒出門的人（作息，routine）。rows 沒有世界時鐘時不看作息。"""
    now = rows.get("world", {}).get("clock_shichen")
    return [p for p in rows["npcs"] if p["location"] == here and p["status"] == "ALIVE"
            and (now is None or doing(rows, p, now)[0] != routine.OUT)]


def doing(rows: dict, p: dict, now: int) -> tuple[str, str]:
    """此刻（在／出／睡, 在做什麼）：照職業或修行身分那一組；家人不出門（該出門的時段在家忙）；小孩有家人同處就跟著家人。"""
    key = profile.group(p, rows["bonds"], rows.get("factions", []), now) or p.get("job", "")
    folk = next((q for q in rows["npcs"] if q["name"] in kin(rows["bonds"], p["name"]) and q["location"] == p["location"]
                 and not npc_mod.is_minor(q, now)), None) if key == profile.KID else None
    s = doing(rows, folk, now) if folk else routine.state(key, now)
    return (routine.IN, HOME_BUSY) if s[0] == routine.OUT and p.get("created_by") == home_mod.FAMILY_BY else s


def present_names(rows: dict, here: str) -> set[str]:
    return {p["name"] for p in present(rows, here)}


_REL_KEYS = ("affinity", "trust", "fear", "grudge", "favours", "had", "adds", "years", "now", "wary", "base", "circle", "met", "fond")


def relation(rows: dict, name: str) -> dict:
    """這一生與某 NPC 的關係（每一生各自獨立：轉生後不繼承前世的恩怨）。turn_change 只在回合內計算。
    還沒有紀錄的人照他的壽元、疑心開一筆空的（第 1-2 批：好感由原因加起來，domain/opinion.py）。"""
    stored = rows["relations"].get(name) or npc_mod.relation_for(find(rows, name), rows.get("world", {}).get("clock_shichen", 0))
    return {**npc_mod.new_relation(), **{k: stored[k] for k in _REL_KEYS if k in stored}, "turn_change": 0}


def fresh(p: dict | None, name: str, now: int, hits: list, base: int = 0, **extra) -> dict:
    """還沒有關係紀錄的人：從零加幾筆原因（初見的名聲、家人、天道安排）；base：關係種類的固定加減。"""
    return {**npc_mod.shift(name, {**npc_mod.relation_for(p, now), "base": base}, hits)[0], **extra}


def _away(rows: dict, here: str) -> list[str]:
    now = present_names(rows, here)
    return [p["name"] for p in rows["npcs"] if p["name"] not in now]


def here_only(choices: list[str], tags: list[dict], rows: dict, here: str) -> tuple[list[str], list[dict]]:
    """選項把不在場的人當成在眼前就換掉（16v 第 90 題；提示管不住模型）。"""
    away, spare, out = _away(rows, here), [f for f in FILL if f[0] not in choices], []
    for c, t in zip(choices, [*tags, *[BLANK_TAG] * len(choices)]):
        if any(n in c for n in away) and not any(w in c for w in SEEK):
            if not spare:
                continue
            c, nature = spare.pop(0)
            t = {**BLANK_TAG, "nature": nature, "difficulty": "容易"}
        out.append((c, t))
    return [c for c, _ in out], [t for _, t in out]


def mark(text: str, rows: dict, here: str) -> str:
    """活著、不在這裡的人第一次出現時標「（不在這裡）」（away 警告第 2 條；只寫在規則裡，小模型會寫成他在眼前）。
    已故的不標：亡者可能正以亡魂出場。名字後面已經有括號的不標。"""
    for n in sorted((p["name"] for p in rows["npcs"] if p["status"] == "ALIVE" and p["location"] != here), key=len, reverse=True):
        i = text.find(n) + len(n)
        if i >= len(n) and text[i:i + 1] != "（":
            text = f"{text[:i]}{NOT_HERE}{text[i:]}"
    return text


def away_warnings(rows: dict, here: str, narrative: str) -> list[str]:
    """敘事寫到不在場的人：可能只是回憶，只記錄（16v 第 90 題）。"""
    return [f"away:{n}" for n in _away(rows, here) if n in narrative]


def meet(rows: dict, here: str, *, life: str, clock_now: int, kin: set[str] = frozenset(),
         stranger=lambda p: 0, gap=lambda p: 0, warm: int = 0, crowd: int = 0) -> tuple[dict, dict[str, dict]]:
    """初次見面（第 10c-3b 步）：這一生第一次跟你同處一地、還沒有關係紀錄的人，依他聽過的你的名聲記下
    第一筆原因（只算這一次，之後照第 6 步的規則變化）。回傳（換上新關係的 rows, 新的關係），由 service 寫入。
    kin：同門的名字，好感多同門的固定加減（第 1-3b 批）。stranger(p)：認出你是他族扣多少好感（16k）。
    warm：命途的初見好感（貴人，第 6-2 批；照 opinion.near 換成一級，+5 記成「小」）；crowd：勢力成員再多加的（眾推，第 6-5d 批）。
    gap(p)：他的地位 − 你的（第 7-1c 批，rank.first）。
    只聽說過你、還沒見過面的人（met＝0，第 1-5e 批）也算初次見面：原因加在原本的關係上。"""
    new = [p for p in present(rows, here) if not rows["relations"].get(p["name"], {"met": 0}).get("met", 1)]
    if not new:
        return rows, {}
    levels = news.fame(rows, place=here, life=life, clock_now=clock_now).levels
    members = {b["a"] for b in rows["bonds"] if b["type"] in society.MEMBER_BONDS} if crowd else set()
    met = {}
    for p in new:
        affinity, trust = reputation.first_view(levels, p)
        snub, awe = rank.first(gap(p))
        hits = (opinion.near(opinion.FAME, opinion.LIKE, affinity) + opinion.near(opinion.FAME, opinion.TRUST, trust)
                + opinion.near(opinion.RACE, opinion.LIKE, stranger(p)) + opinion.near(opinion.FATE, opinion.LIKE, warm + crowd * (p["name"] in members))
                + opinion.near(opinion.FAME, opinion.FEAR, reputation.first_fear(levels, p))
                + opinion.near(opinion.RANK, opinion.LIKE, snub) + opinion.near(opinion.RANK, opinion.FEAR, awe))
        met[p["name"]] = ({**npc_mod.shift(p["name"], relation(rows, p["name"]), hits)[0], "met": 1} if p["name"] in rows["relations"]
                          else fresh(p, p["name"], clock_now, hits, society.SAME_HALL if p["name"] in kin else 0,
                                     npc_name=p["name"], known_goal="", known_goal_shichen=None))
    return {**rows, "relations": {**rows["relations"], **met}}, met


def changed_relation(rows: dict, npc_changes: dict[str, dict], name: str) -> dict:
    """這回合已經變過就用變過的，否則用回合開始時的。
    背景演化回歸的好感存回來時沒有 turn_change（那不算這回合的互動），補 0。"""
    changed = npc_changes.get(name, {}).get("relation")
    return {"turn_change": 0, **changed} if changed else relation(rows, name)


def relations_before(rows: dict, npc_changes: dict[str, dict]) -> dict[str, dict]:
    """這回合之前的關係，用來寫「關係轉折」記事。"""
    return {name: relation(rows, name) for name, change in npc_changes.items() if "relation" in change}


# ── 對象與打聽 ───────────────────────────────────────────────────────────
def attach_target(intent: judgment.Intent, rows: dict, sheet: dict, player_input: str,
                  choice_target: str) -> judgment.Intent:
    """認出行動的對象 NPC：選項標註的名字優先，其次是玩家輸入裡出現的名字（在場者優先、長名字優先）。

    對不在場或已死的人動手 → 不能嘗試（blocked）；說話時旁邊沒有別人也一樣；潛行提到不在場的人只是話題，不算對象。
    打聽（套話）不在場的人 → 記成打聽的對象（第 10b 步），可以同時有在場的對象（向掌櫃打聽阿桃）。
    """
    if intent.nature not in TARGETED_NATURES:
        return intent
    here = sheet["location"]
    here_now = present_names(rows, here)
    intent = _with_inquiry(intent, rows, here, here_now, player_input, choice_target)
    if choice_target in here_now:
        return dataclasses.replace(intent, target_npc=choice_target)
    named = sorted((p for p in rows["npcs"] if p["name"] in player_input), key=lambda p: -len(p["name"]))
    for p in named:
        if p["name"] in here_now:
            return dataclasses.replace(intent, target_npc=p["name"])
    # 16m 第 3 題：找不到對象就不能嘗試；說話要旁邊沒人、也不是打聽才算（有人在就是向他提起此人）
    talk = intent.nature == judgment.SOCIAL and not here_now and judgment.PRY not in intent.targets
    if named and (intent.nature == judgment.COMBAT or talk):
        p = named[0]
        reason = f"{p['name']}已不在人世" if p["status"] != "ALIVE" else f"{p['name']}不在這裡"
        return dataclasses.replace(intent, blocked=reason)
    return intent


# ── 眼前的人（故事第 2 題）──────────────────────────────────────────────
def seeking(nature: str, text: str) -> bool:
    return nature == judgment.SOCIAL or (nature in (judgment.OBSERVE, judgment.EXPLORE) and any(w in text for w in LOOKING))


def _newest(rows: dict, here: str, skip: set[str] = frozenset()) -> str:
    """在場最新登場的人：玩家才看過他的敘事，最可能是話裡的那個人。"""
    people = [p for p in present(rows, here) if p["name"] not in skip]
    return max(people, key=lambda p: p.get("first_seen_turn") or 0)["name"] if people else ""


def aim(intent: judgment.Intent, rows: dict, here: str, last: str, player_input: str) -> judgment.Intent:
    """玩家沒點名時，行動是衝著眼前的人：說話一定是，動手要說「他」「對方」才是。"""
    talking = intent.nature == judgment.SOCIAL
    pointing = intent.nature == judgment.COMBAT and any(w in player_input for w in POINTING)
    if intent.blocked or intent.target_npc or not (talking or pointing):
        return intent
    who = (talking and called(rows, here, player_input)) or (
        last if last in present_names(rows, here) else _newest(rows, here) if talking else "")
    return dataclasses.replace(intent, target_npc=who) if who else intent


def called(rows: dict, here: str, text: str) -> str:
    """話裡用稱呼點到在場的人：家人的身分寫著「某某的養母。」（「問養母」），其他人看職業（「問鐵匠」）。"""
    word = next((w for w in KIN_WORDS if w in text), "")
    return next((p["name"] for p in present(rows, here)
                 if (word and f"的{word}" in p["profile"]) or (p.get("job") and p["job"] in text)), "")


def facing(rows: dict, here: str, text: str, *, target: str, guests: list[str], last: str, looking: bool,
           dead: set[str], job: str = "") -> str:
    """這回合結束時眼前的人：對象 → 話裡提到的在場者 → 找上門的人 → 上回合的人 → 玩家在找人時挑一個。
    job：話裡說要找的身分（第 9-16 題）：只挑這種人，沒有就空著（給臨時路人）。"""
    names = present_names(rows, here) - dead
    said = sorted((n for n in names if n in text), key=len, reverse=True)
    picked = next((n for n in (target, *said, *guests, last) if n in names), "")
    pro = next((p["name"] for p in present(rows, here) if p["name"] not in dead and p.get("job") == job), "") if job else None
    return picked or (pro if pro is not None else _newest(rows, here, dead) if looking else "")


def greeted(focus: str, came: str, *, target: str, text: str, narrative: str) -> str:
    """新面孔登場後眼前的人：玩家正對著的人不換；敘事沒寫到新面孔也不換。"""
    busy = focus and (focus == target or focus in text)
    return focus if busy or came not in narrative else came


def waiting(last: dict, rows: dict, here: str) -> str:
    """玩家沒點名時衝著誰：上回合的事在等回應就是事件裡的人，不然是上回合眼前的人。"""
    event = last.get("incident") or {}
    who = event.get("who", "") if event.get("answer") else ""
    return who if who in present_names(rows, here) else last.get("focus", "")


def focus_line(rows: dict, npc_changes: dict[str, dict], name: str, said: str = "") -> str:
    """給說書人的筆記：這個人是誰、對你什麼態度、自己想要什麼、怎麼說話（said，people.voice）。"""
    p, rel = find(rows, name), changed_relation(rows, npc_changes, name)
    goal = p["goal"] + (f"（{p['goal_target']}）" if p["goal_target"] else "")
    kind, owed = lineage.who(p), favour.prompt(rel.get("favours", []))
    dread = npc_mod.dread(rel, p, rows.get("my_lv", 0))   # 怕（第 121-10 題）：「敵視、忌憚」
    return (f"{name}{f'（{kind}）' if kind else ''}，對你{npc_mod.tier(rel['affinity'], npc_mod.AFFINITY_TIERS)}、"
            + (f"{dread}、" if dread else "") +
            f"信任{npc_mod.tier(rel['trust'], npc_mod.TRUST_TIERS)}"
            + (f"，{owed}" if owed else "") + (f"，想要：{goal}" if goal else "") + (f"，外貌：{p['appearance']}" if p["appearance"] else "")
            + (f"，說話：{said}" if said else ""))


def _with_inquiry(intent: judgment.Intent, rows: dict, here: str, here_now: set[str], player_input: str,
                  choice_target: str) -> judgment.Intent:
    if judgment.PRY not in intent.targets:
        return intent
    absent = [p["name"] for p in rows["npcs"] if p["name"] not in here_now]
    if choice_target in absent:
        subject = choice_target
    else:
        subject = max((n for n in absent if n in player_input), key=len, default="")
    # 沒有打聽特定的人＝打聽最近有什麼消息（第 10c-3a 步，聽傳聞）：在荒野一樣沒什麼人可問
    asked_someone = choice_target in here_now or any(n in player_input for n in here_now)
    place_type = next((l["type"] for l in rows["locations"] if l["name"] == here), "")
    hard = (place_type in INQUIRY_HARD_PLACES and not asked_someone
            and judgment.DIFFICULTY.get(intent.difficulty, 0) > judgment.DIFFICULTY["困難"])
    return dataclasses.replace(intent, inquiry_npc=subject, difficulty="困難" if hard else intent.difficulty)


def inquiry(rows: dict, intent: judgment.Intent, verdict: judgment.Judgment, target: dict | None,
            npc_changes: dict[str, dict], updates: background.NpcUpdates, events: list[str], *, protagonist: str,
            clock_now: int, turn_no: int) -> dict[str, str]:
    """打聽與套話的收穫（第 10b 步）。回傳這回合打聽到的目標 {名字: 目標}；消息併進 events、記事併進 updates。

    - 打聽不在場的人：依套話結果問到多少（domain/evolution.inquiry_text）。
    - 對在場的人套話成功（沒有打聽別人時）：看出他的目標。
    """
    outcome = next((c.outcome for c in verdict.all_checks if c.target == judgment.PRY), "")
    if not outcome:
        return {}
    if intent.inquiry_npc:
        found = background.inquire(find(rows, intent.inquiry_npc), outcome, protagonist=protagonist,
                                   notes=rows["memories"] + updates.notes + updates.world_notes, clock_now=clock_now, turn_no=turn_no)
        events.append(f"打聽{found.subject}：{found.text}")
        if found.note:
            updates.notes.append(found.note)
        return {found.subject: found.goal} if found.goal else {}
    alive = target is not None and npc_changes.get(target["name"], {}).get("state", {}).get("status", "ALIVE") == "ALIVE"
    if alive and outcome in evolution.HEARD_OUTCOMES:
        goal = evolution.goal_phrase(target, protagonist)
        events.append(f"言談間看出{target['name']}{goal}")
        return {target["name"]: goal}
    return {}


# ── 關係與狀態的變化 ─────────────────────────────────────────────────────
def apply_relation_proposals(rows: dict, verdicts: list, npc_changes: dict[str, dict]) -> list[str]:
    """判定以外的互動：AI 提案方向，Python 換算並限制每回合幅度。結果併進 npc_changes，回傳給玩家看的事件。"""
    events = []
    for v in verdicts:
        if v.accepted and v.kind == proposals.RELATION:
            updated, new_events = npc_mod.apply_interaction(v.name, changed_relation(rows, npc_changes, v.name),
                                                            v.record["change"])
            npc_changes.setdefault(v.name, {})["relation"] = updated
            events += new_events
    return events


def write_changes(conn, session: dict, changes: dict[str, dict], met: dict[str, dict] | None = None) -> None:
    """在回合的交易內呼叫：寫入初次見面的關係（met），再寫判定與互動對 NPC 造成的狀態、關係變化（後寫的蓋過先寫的）。"""
    for name, relation in (met or {}).items():
        repos.upsert_relation(conn, session["world_id"], name, session["id"], relation)
    for name, change in changes.items():
        if "state" in change:
            state = change["state"]
            fields = {"condition": state["condition"], "status": state["status"]}
            if state["condition"] == "重傷" and state["status"] == "ALIVE":
                fields["rewrite_reason"] = "重傷"   # 留下傷痕：外貌要改寫（第 10a 步）
            repos.update_npc(conn, session["world_id"], name, fields)
        if "relation" in change:
            repos.upsert_relation(conn, session["world_id"], name, session["id"], change["relation"])


def written_ages(npc: dict, texts: dict, clock_now: int) -> dict:
    """描述「寫於幾歲」：這次有寫的欄位記下 NPC 目前的歲數（年齡不詳記 None）。"""
    years = npc_mod.age(npc, clock_now)
    return {f"{k}_age": years for k, _ in TEXT_FIELDS if texts.get(k)}


def kin(bonds: list[dict], name: str) -> list[str]:
    """他的親人（血緣）。"""
    return [b["b"] if b["a"] == name else b["a"] for b in bonds if b["type"] in society.BLOOD and name in (b["a"], b["b"])]


def _unborn(p: dict) -> bool:
    """還沒有出身：身分空的、或模型寫的（模型的接在出身後面）；模板寫好身分的照舊（第 7-1-3 題）。"""
    return not p["origin"] and (not p["profile"] or p["created_by"] == "narrator")


def _origin(rows: dict, p: dict, jobs: dict, bonds: list[dict], seed) -> str:
    here = town(rows, p["location"])   # 不在村鎮（山道、荒野）就算最近相連的村鎮，都沒有寫外地
    place = here if here and here["type"] in home_mod.RENT_TYPES else next(
        (l for n in space.neighbors(rows["connections"], p["location"]) for l in rows["locations"]
         if l["name"] == n["name"] and l["type"] in home_mod.RENT_TYPES), {"name": "外地", "type": ""})
    trade = next((jobs[k] for k in kin(bonds, p["name"]) if jobs.get(k)), "")   # 家業：家人的職業
    return profile.origin(random.Random(f"{seed}:origin:{p['name']}"), p, town=place["name"], trade=trade,
                          jobs=tuple(outfit.TABLE["職業"].get(place["type"], ())), land=local_race(rows, p["location"]))


def ensure_now(conn, session: dict) -> None:
    """補上 NPC 沒有的欄位，用「世界種子＋名字」（自己的交易，可重複、結果固定）：第 10a 步之前登錄的沒有目標與性格；
    還沒有出身的補出身（第 7-1a 批：登錄的路徑很多，統一在回合開頭補）；還沒有學識的照出身擲（第 7-1c 批）；
    還沒有特點的擲特點、口頭禪（第 7-1d 批，同一個地方的口頭禪不重複）。"""
    w = session["world_id"]
    npcs = repos.list_npcs(conn, w)
    missing = [p for p in npcs if not p["goal"] or _unborn(p) or not p["learning"] or not p["quirks"]]
    if not missing:
        return
    seed = repos.get_world(conn, w)["rng_seed"]
    rows = {"locations": repos.list_locations(conn, w), "connections": repos.list_connections(conn, w), "atlas": repos.get_atlas(conn, w)}
    jobs, bonds = {p["name"]: p["job"] for p in npcs}, repos.list_bonds(conn, w)
    factions = repos.list_factions(conn, w)
    halls = {f["name"]: f["traits"].get("道統", "") for f in factions if f["type"] == "宗門"}
    sects = {b["a"]: halls[b["b"]] for b in bonds if b["b"] in halls and b["type"] in society.MEMBER_BONDS}
    when, now = (repos.get_era(conn, w) or era.DEFAULT)["era"], repos.get_world(conn, w)["clock_shichen"]
    said = {}
    for p in npcs:
        said.setdefault(p["location"], set()).add(p["catchphrase"])
    with transaction(conn):
        for p in missing:
            fields = {**({} if p["goal"] else npc_mod.roll_traits(random.Random(f"{seed}:traits:{p['name']}"))),
                      **({"origin": _origin(rows, p, jobs, bonds, seed)} if _unborn(p) else {})}
            if not p["learning"]:
                fields |= learn.of_npc(random.Random(f"{seed}:learn:{p['name']}"), {**p, **fields}, when, p["name"] in sects)
            if not p["quirks"]:
                group = profile.GROUPS.get(profile.calling(p, bonds, factions)[0], "")
                fields |= voice_mod.roll(random.Random(f"{seed}:voice:{p['name']}"), p, adult=not npc_mod.is_minor(p, now), era_now=when,
                                         group=group, path=sects.get(p["name"], ""), taken=said.get(p["location"], set()))
                said.setdefault(p["location"], set()).add(fields["catchphrase"])
            repos.update_npc(conn, w, p["name"], fields)


def standing(rows: dict, sheet: dict, here: str, life: str, clock_now: int):
    """地位（第 7-1c 批，domain/rank.py）：（主角在這裡算哪一級, 算 NPC 那一級的函式）。"""
    state = atlas.state_of(rows.get("atlas"), rows["connections"], here)
    law = crime.nation(rows.get("factions", []), state["nation"] if state else "")
    name = identity.own_name(sheet)
    wanted = identity.level(sheet, name, clock_now)[0] > 0 and sheet["wanted"][name].get("nation", "") in ("", (law or {}).get("name", ""))
    famed = news.fame(rows, place=here, life=life, clock_now=clock_now, name=name).levels[reputation.MIGHT] == reputation.FAMOUS
    stance = (rows.get("era") or era.DEFAULT)["stance"]
    in_sect = next((l["type"] for l in rows["locations"] if l["name"] == here), "") == "宗門"
    bound = {b["a"] for b in rows["bonds"] if b["type"] in ("奴", "僕")}
    me = rank.of_me(sheet, wanted=wanted, famed=famed, stance=stance, in_sect=in_sect)
    return me, lambda p: rank.of_npc(p, profile.calling(p, rows["bonds"], rows.get("factions", []))[0],
                                     bound=p["name"] in bound, stance=stance, in_sect=in_sect)


def voice(rows: dict, sheet: dict, name: str, *, here: str, life: str, clock_now: int, turn_no: int, fresh: bool, catch: bool = True) -> str:
    """眼前的人說話那一行（第 7-1d 批，domain/voice.py）。fresh：這回合初見；口頭禪初見和每三回合放一次。
    catch＝False：不放口頭禪（大模型那一路，2026-11-23 使用者：口頭禪看起來太怪）。
    知道你是誰（之前見過、或這裡有人聽過你）才叫姓（第 7-1-16 題甲）；化名、道號拿第一個字。"""
    p = find(rows, name)
    me, of = standing(rows, sheet, here, life, clock_now)
    card = rows.get("era") or era.DEFAULT
    heard = any(v != reputation.UNKNOWN for v in news.fame(rows, place=here, life=life, clock_now=clock_now, name=identity.own_name(sheet)).levels.values())
    knows = not identity.disguised(sheet, clock_now) and (heard or (not fresh and rows["relations"].get(name, {}).get("met", 0)))
    surname = "" if not knows or not names.has_family(sheet["race"]) else (
        (sheet["alias"] or sheet["dao"])[:1] or names.surname_of(sheet["name"], sheet.get("surname", ""), sheet["race"]))
    female = sheet["gender"] == "女"
    title = voice_mod.honour(me, female=female, minor=character_mod.age(sheet, clock_now) < npc_mod.ADULT_AGE, sage=sheet["realm_lv"] > 0,
                             era_now=card["era"], stance=card["stance"], surname=surname)
    return voice_mod.line(p, gap=of(p) - me, title=title, female=female, show=catch and (fresh or turn_no % voice_mod.EVERY == 0),
                          kin=p["created_by"] == home_mod.FAMILY_BY)


# ── 畫面與聯絡簿 ─────────────────────────────────────────────────────────
def realm_label(p: dict) -> str:
    return "深不可測" if p["hidden_power"] else realm.stage_name(p["realm_lv"], p["stage_index"])


def land_race(conn, world_id: str, place: str) -> str:
    """這個地方是哪一族的地盤（16k；舊世界是人族）。"""
    return local_race({"atlas": repos.get_atlas(conn, world_id), "connections": repos.list_connections(conn, world_id)}, place)


def settle_family(conn, world_id: str, person: dict, town: str, clock_now: int, home: str = "",
                  rng: random.Random | None = None) -> None:
    """新生的人帶家人一起登錄（121-1，domain/family.py）：住家、家人、關係。人名、地名快到上限就不帶。
    亂數照世界和名字另開一條，不動原本事端、路線的亂數；綁架要一定生得出家人時（plots._hostage）傳 rng 重擲。"""
    taken = {p["name"] for p in repos.list_npcs(conn, world_id)} | {l["name"] for l in repos.list_locations(conn, world_id)}
    if len(taken) >= plot.MAX_NAMES:
        return
    rng = rng or random.Random(f"{world_id}:{person['name']}:family")
    place, kin, ties = family.kin(rng, person, town=town, clock_now=clock_now, taken=taken, home=home)
    if place:
        repos.insert_location(conn, world_id, "", place)
        repos.insert_connection(conn, world_id, "", {"a": town, "b": place["name"], "tier": space.NEAR,
                                                     "distance_km": space.DISTANCE_TIERS[space.NEAR]})
    for p in kin:
        repos.insert_npc(conn, world_id, "", p)
    for b in ties:
        repos.insert_bond(conn, world_id, "", b)


def town(rows: dict, place: str) -> dict | None:
    """這個地方所在的聚落（家級的地方看上層）。"""
    name = space.town_of(rows["locations"], place)
    return next((l for l in rows["locations"] if l["name"] == name), None)


def local_race(rows: dict, place: str) -> str:
    a = rows.get("atlas")
    state = atlas.state_of(a, rows["connections"], place)
    return atlas.race_of(a, state) if state else races.HUMAN


def age_label(p: dict, clock_now: int) -> str:
    years = npc_mod.age(p, clock_now)
    return "年齡不詳" if years is None else f"{years}歲"


def people_view(rows: dict, here: str, clock_now: int, focus: str = "", seats: dict | None = None) -> list[dict]:
    """前端的「在場人物」：年齡、境界（深不可測者不顯示）、狀況、對你的態度與信任、是不是眼前的人、在你哪一宮（routes.seat）。"""
    view = []
    for p in present(rows, here):
        rel = relation(rows, p["name"])
        view.append({"name": p["name"], "race": p["race"], "kin": lineage.who(p, short=True), "age": age_label(p, clock_now),
                     "minor": npc_mod.is_minor(p, clock_now),
                     "realm": realm_label(p), "condition": p["condition"],
                     "attitude": npc_mod.tier(rel["affinity"], npc_mod.AFFINITY_TIERS),
                     "trust": npc_mod.tier(rel["trust"], npc_mod.TRUST_TIERS), "grudge": rel["grudge"],
                     "favour": favour.label(rel["favours"]), "favourNotes": favour.notes(rel["favours"]),   # 人情帳（16v 第 110 題）
                     "focus": p["name"] == focus, "palace": (seats or {}).get(p["name"], "")})
    return view


def people_line(rows: dict, p: dict, clock_now: int) -> str:
    """聯絡簿裡一位在場人物：年齡（與是否未成年）、境界、狀況、關係、目標與性情、羈絆、描述；描述過時或有改寫原因時要求重寫。
    天道角色（宿敵、餌……）不寫進來：說書人也不能知道（第 18 步只給「異兆」提示）。"""
    rel = relation(rows, p["name"])
    minor = "，未成年" if npc_mod.is_minor(p, clock_now) else ""
    hall = next((b["b"] for b in rows.get("bonds", ()) if b["a"] == p["name"] and b["type"] in society.MEMBER_BONDS), "")
    path = next((f.get("traits", {}).get("道統", "") for f in rows.get("factions", ()) if hall and f["name"] == hall), "")
    law = "" if p["hidden_power"] else laws.npc_law(p["name"], p["realm_lv"], path)   # 第 3b-1 步：說書人寫招式有依據；照宗門道統挑系
    kind = lineage.who(p)   # 性別、他族（16k、16u）
    head = (f"{p['name']}（{kind + '，' if kind else ''}{age_label(p, clock_now)}{minor}，{realm_label(p)}" + (f"・{law}" if law else "")
            + f"，{p['condition']}，"
            f"對你{npc_mod.tier(rel['affinity'], npc_mod.AFFINITY_TIERS)}、"
            f"信任{npc_mod.tier(rel['trust'], npc_mod.TRUST_TIERS)}"
            + (f"、記恨：{rel['grudge']}" if rel["grudge"] else "") + "）"
            + f" 此刻：{doing(rows, p, clock_now)[1]}")   # 作息（第八節）
    shown = {**p, "profile": "。".join(x for x in (who(rows, p, clock_now), p["profile"]) if x)}   # 出身、如今在前（第 7-1a 批）
    texts = "；".join(f"{label}：{shown[k]}" for k, label in TEXT_FIELDS if shown[k])
    goal = p["goal"] + (f"（{p['goal_target']}）" if p["goal_target"] else "")
    inner = f" 目標：{goal}" if p["goal"] else ""   # 性情改進說話那一行（第 7-1-9 題甲）
    ties = [t for t in (society.describe(b, p["name"]) for b in rows["bonds"]) if t]
    ties_text = f"；羈絆：{'、'.join(ties)}" if ties else ""
    carried = legacy.held_text(rows.get("relics", []), p["name"])   # 第 11-1 步：殺了前人拿走的東西
    ties_text += f"；隨身帶著{carried}" if carried else ""
    odd = era.behind(p, rows.get("era") or era.DEFAULT)   # 不合時宜（第 8-3 批）：照舊時代寫，不改寫
    old = [] if odd else [label for k, label in TEXT_FIELDS if p[k] and npc_mod.stale(p, f"{k}_age", clock_now)]
    note = f"　※{'、'.join(old)}是多年前的樣子，請依現在的年紀重新描寫並以 npc_updates 提案" if old else ""
    if odd:
        note += "　※還是舊時代的樣子：穿著、說話照舊，不懂這個時代的東西（描述不要改寫）"
    elif p["rewrite_reason"]:
        note += f"　※{p['rewrite_reason']}之後樣貌或性情有了變化，請重新描寫並以 npc_updates 提案"
    if not any(p[k] for k, _ in TEXT_FIELDS):   # Python 安排登場、AI 還沒寫描述的人（WHITEPAPER 12.6）
        note += "　※還沒有描寫，請依上面的設定寫外貌、身分個性並以 npc_updates 提案"
    return head + (f" {texts}" if texts else "") + inner + ties_text + note


def cast_line(rows: dict, p: dict, clock_now: int, my_lv: int, known: tuple[str, ...]) -> str:
    """第一段（編劇）看的帳（Claude 主導第 3 題甲）：聯絡簿那一行（不帶寫給說書的提醒），加上怕不怕你、人情、知道你做過的事。"""
    rel = relation(rows, p["name"])
    more = [x for x in (f"{npc_mod.dread(rel, p, my_lv)}你" if npc_mod.dread(rel, p, my_lv) else "",
                        f"人情：{favour.label(rel['favours'])}" if rel["favours"] else "",
                        f"知道你做過：{'、'.join(known)}" if known else "") if x]
    return people_line(rows, p, clock_now).split("　※")[0] + "".join(f"；{x}" for x in more)


def who(rows: dict, p: dict, clock_now: int) -> str:
    """出身，如今（第 7-1a 批）：聯絡簿和人物卡共用。"""
    folk = next(iter(kin(rows["bonds"], p["name"])), "")
    return "，".join(x for x in (p.get("origin", ""), profile.now(p, rows["bonds"], rows.get("factions", []), clock_now, folk,
                                                                 (rows.get("era") or era.DEFAULT)["stance"])) if x)


def ties_view(rows: dict) -> dict:
    """玩家看得到的羈絆：人物或勢力名字 → 「阿桃的師父」「首領：守碑老人」……（點名字展開時顯示）。"""
    hidden = region.hidden_names(rows["factions"])   # 宗門的上宗（仙宗）看不到（第 16b 步）
    names = [p["name"] for p in rows["npcs"]] + [f["name"] for f in rows["factions"] if f["name"] not in hidden]
    bonds = [b for b in rows["bonds"] if not {b["a"], b["b"]} & hidden]
    view = {name: [t for t in (society.describe(b, name) for b in bonds) if t] for name in names}
    return {k: v for k, v in view.items() if v}


def age_warnings(rows: dict, here: str, clock_now: int, narrative: str, sheet: dict | None = None) -> list[str]:
    """敘事與 NPC 年齡的矛盾（成年人被寫成孩子、孩子被寫成老人、未成年者出現親密描寫）。只記錄，不阻擋。

    sheet：主角。主角建角時 16 歲，未成年時敘事裡任何親密用詞都記一筆（敘事以「你」稱呼主角，無法用名字定位）。
    """
    warnings = []
    if sheet is not None and character_mod.age(sheet, clock_now) < npc_mod.ADULT_AGE \
            and any(w in narrative for w in INTIMATE_WORDS):
        warnings.append("minor_intimacy:主角")
    for p in present(rows, here):
        years = npc_mod.age(p, clock_now)
        for i in _occurrences(narrative, p["name"]):
            around = narrative[max(0, i - WARN_WINDOW):i + len(p["name"]) + WARN_WINDOW]
            if years is not None and years >= npc_mod.ADULT_AGE and any(w in around for w in CHILD_WORDS):
                warnings.append(f"age_mismatch:{p['name']}（{years}歲）被寫成孩童")
            if years is not None and years < npc_mod.ADULT_AGE and any(w in around for w in ELDER_WORDS):
                warnings.append(f"age_mismatch:{p['name']}（{years}歲）被寫成年長者")
            if npc_mod.is_minor(p, clock_now) and any(w in around for w in INTIMATE_WORDS):
                warnings.append(f"minor_intimacy:{p['name']}")
    return sorted(set(warnings))


def _occurrences(text: str, word: str) -> list[int]:
    found, start = [], text.find(word)
    while start != -1:
        found.append(start)
        start = text.find(word, start + 1)
    return found
