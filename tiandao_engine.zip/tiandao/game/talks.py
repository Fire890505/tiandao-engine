"""NPC 的話在回合裡（WHITEPAPER 16v 第 65 題）：挑這回合眼前的人講什麼。規則在 domain/talk.py。"""
from __future__ import annotations

import random

from ..domain import atlas, circles, clock, crime, disaster, era, hearsay, home, identity, lead, passer, plot, profile, route, routine, rumors, sect, society, space, talk
from ..domain import looks as outfit
from ..domain import evolution, opinion, origins, side, voice, worry
from ..domain import memory as memory_mod
from ..domain.clock import SHICHEN_PER_DAY, SHICHEN_PER_YEAR, season_of
from ..store import repos
from ..util import new_id
from . import news, people, plots, routes

DID = {hearsay.KILL: "殺了", hearsay.HURT: "傷了", hearsay.SAVE: "救了"}
HOW = {hearsay.SEEN: "那天我看見你"}   # 親眼看到的；其他是聽人說的
STANCE = {era.OPEN: ("見慣了修士", "照樣走動"), era.HIDDEN: ("不信有修士這回事", "都藏著身分"), era.HUNTED: ("見了修士就報官", "都躲著官府")}
PUNISH = {0: "不算犯法", 1: "要罰錢"}   # 其他：官府要抓人
HEARD = {rumors.TALE: ("怪談地", "subject"), rumors.LEGEND: ("傳說地", "subject"), rumors.LOCAL: ("地方", "detail")}


def _put(w: dict, **kw) -> None:
    """一組字都有才放；同一個字先找到的算。"""
    if all(kw.values()):
        for k, v in kw.items():
            w.setdefault(k, v)


def common(rows: dict, here: str, now: int, sheet: dict) -> dict[str, str]:
    """常識牌（第 9-15 題）的 {}：此地和鄰地現成的資料。牌上的字湊不齊就不抽；「有:」看這裡有沒有那個字。"""
    near = space.neighbors(rows["connections"], here)
    around, side, w = {here, *(n["name"] for n in near)}, {n["name"]: n["direction"] for n in near}, {}
    days = lambda place: str(-(-space.travel_shichen(next((n["km"] for n in near if n["name"] == place), 0), 0) // SHICHEN_PER_DAY))
    for n in near[:1]:
        _put(w, 鄰地=n["name"], 日=days(n["name"]))
        _put(w, 方位=n["direction"])
    card = rows.get("era") or {}
    for s in rows.get("place_states", []):   # 天災（16j）
        k = disaster.BY_NAME.get(s["name"])
        if k and s["place"] in around | {""} and s["started_shichen"] <= now < s["ends_shichen"]:
            _put(w, 災地=s["place"] or "這一帶", 災=disaster.label(s["name"], card.get("era", "")))
            _put(w, 貨="米糧" if k.price else "")
    for r, _ in sorted(news._arrived(rows, here, now), key=lambda x: -x[0]["clock_shichen"]):   # 傳到這裡的公開消息
        if r["kind"] in HEARD:
            _put(w, **{HEARD[r["kind"]][0]: r[HEARD[r["kind"]][1]]})
        _put(w, **({"國": r["subject"], "國事": r["detail"]} if r["kind"] == rumors.AFFAIRS else {}))
        _put(w, **({"犯事地": r["place"], "外貌": sheet.get("appearance", "")} if r["kind"] == rumors.WANTED and r["life"] == rows.get("life") else {}))
    for u in rows.get("undead", []):   # 亡者（第 11-2 步）
        _put(w, **({"亡者": u["name"], "亡者地": u["place"]} if u["place"] in around else {}))
    for l in rows["locations"]:
        _put(w, **({"荒野": l["name"]} if l["type"] == "荒野" and l["name"] in around else {}))
        _put(w, **({"秘境": l["name"], "秘境方位": side.get(l["name"], "")} if l["type"] == "秘境" else {}))
    for f in rows.get("factions", []):
        if f["location"] in around and f["type"] in society.FACTION_TYPES:
            _put(w, 勢力=f["name"])
            _put(w, **({"宗門": f["name"], "宗門地": f["location"], "宗門日": days(f["location"]) if f["location"] != here else "1",
                        "宗規": f"講究{sect.style_of(rows['factions'], f['name'])}" if sect.style_of(rows["factions"], f["name"]) else ""}
                       if f["type"] == "宗門" else {}))
    for l in rows.get("ledger", []):   # 關押（第 7-2a 批：只有傷人會被抓）
        _put(w, **({"某人": l["a"], "罪名": "傷人"} if l["kind"] == society.JAILED and l["status"] == society.OPEN and l["b"] in around else {}))
    _put(w, **dict(zip(("看修士", "怎麼做"), STANCE.get(card.get("stance", ""), ("", "")))))
    _put(w, 打壓="是" if card.get("stance") == era.HUNTED else "")
    state = atlas.state_of(rows.get("atlas"), rows["connections"], here)
    nation = crime.nation(rows.get("factions", []), state["nation"] if state else "")
    traits = crime.traits_of(nation)
    if traits:
        lv = crime.code(traits)
        moved = sorted((c for c in lv if lv[c] != crime.BASE.get(c)), key=lambda c: -lv[c])
        _put(w, 本國=nation["name"], 國風=traits[0].line)
        _put(w, **({"罪": moved[0], "罰": PUNISH.get(lv[moved[0]], "官府要抓人")} if moved else {}))
    _put(w, 季節=season_of(now))
    return w


def _towns(locations: list[dict], links: list[dict], place: str) -> list[str]:
    """這裡和相連的地方有哪些村鎮，近的在前。"""
    near = [place, *(n["name"] for n in space.neighbors(links, place))]
    return [n for n in near for l in locations if l["name"] == n and l["type"] in home.RENT_TYPES]


def past(rng: random.Random, sheet: dict, born: dict, locations: list[dict], links: list[dict]) -> dict:
    """開局的往事：地名用出生地和相連的地方。"""
    town = next(iter(_towns(locations, links, born["name"])), born["name"])
    return talk.past(rng, sheet, town, next((n["name"] for n in space.neighbors(links, born["name"])), born["name"]))


def _main(rows: dict, templates: list[dict], sheet: dict, here: str) -> list[str]:
    """手上路線的背景：事端先講風聲。"""
    r = sheet["route"]
    if not r:
        return []
    place = space.town_of(rows["locations"], here)
    town = next(iter(_towns(rows["locations"], rows["connections"], place)), place)
    rec, t = plots.case(rows, templates, r["key"]) if r["kind"] == route.PLOT else (None, None)
    return ([plot.fill(t["風聲"][0][0], rec["cast"])] if t else []) + [
        plot.fill(l, {"地": r["place"] or town, "鎮": town, "亡者": r["key"]}) for l in talk.MAINS.get(r["name"]) or talk.MAINS.get(r["kind"], ())]


def _heard(rows: dict, who: str) -> list[str]:
    """跟你有關的聽說（第 126-10 題第 ② 格）：他知道是你做的事，新的在前；做在他身上的不講。"""
    how = {k["event_id"]: k["via"] for k in rows.get("knows", [])
           if (k["session_id"], k["who"], k["knows_who"]) == (rows.get("life"), who, 1)}
    done = sorted((e for e in rows.get("happened", []) if e["id"] in how and e["kind"] in hearsay.KINDS and e["target"] != who),
                  key=lambda e: -e["clock_shichen"])
    return [f"{HOW.get(how[e['id']], '聽說你')}在{e['place']}"
            + (f"{DID[e['kind']]}{e['target']}" if e["kind"] in DID else "、".join(e["detail"].get("crimes") or ["犯了事"]))
            for e in done]


RANK = ("師父", "徒弟", "親人", "伴侶", "結義", "戀人", "恩人", "同門", "友人", "仇家")   # 人際牌的羈絆，輕重照這個順序（第 9-19 題）


def ties(rows: dict, x: dict, here: str, *, about: str = "") -> list[tuple[dict, dict]]:
    """人際牌要講的人（第 9-19、9-20 題）：（條件, 字），你認識的 → 在附近的 → 羈絆輕重。about：你在打聽的人，講他的羈絆。"""
    who, by, rels = about or x["name"], {p["name"]: p for p in rows["npcs"]}, rows.get("relations", {})
    near = {here, *(n["name"] for n in space.neighbors(rows["connections"], here))}
    sure = {"可信": {"是"}} if worry.opens(x, rels.get(x["name"], {}).get("trust", 0)) else {}   # 私密的可信才講（第 9-20 題）
    found = []
    for b in rows["bonds"]:
        y, kind = (b["a"], b["type"]) if b["b"] == who else (b["b"], society.INVERSE.get(b["type"], b["type"] if b["type"] in society.SYMMETRIC else "")) \
            if b["a"] == who else ("", "")
        if kind not in RANK or by.get(y, {}).get("status") != "ALIVE":
            continue
        why = max((q for q in rows.get("npc_reasons", []) if (q["holder"], q["toward"]) == (who, y) and q["axis"] == opinion.LIKE
                   and q["kind"] in talk.WHY), key=lambda q: q["clock_shichen"], default=None)
        facts = {**({"打聽": {"是"}} if about else {"羈絆": {kind}}), **({"原因": {"好" if why["value"] > 0 else "壞"}} if why else {}), **sure}
        words = {"名字": y, "地": space.town_of(rows["locations"], by[y]["location"]), "他": about, "稱呼": society.kin_call(by.get(who, {}), by[y]),
                 "原因": talk.WHY[why["kind"]].format(對="他" if about else "我") if why else ""}
        found.append(((y not in rels, by[y]["location"] not in near, RANK.index(kind)), facts, {k: v for k, v in words.items() if v}))
    for l in [] if about else rows.get("ledger", []):   # 欠人的債
        if (l["kind"], l["status"], l["b"]) == (society.DEBT, society.OPEN, who) and not l.get("session_id") and l["a"] in by:
            found.append(((l["a"] not in rels, by[l["a"]]["location"] not in near, len(RANK)), {"帳": {"債"}, **sure}, {"名字": l["a"]}))
    return [(f, w) for _, f, w in sorted(found, key=lambda t: t[0])]


BAD_NEWS = {rumors.BROKE: "說話不算話", rumors.KILL: "殺了人", rumors.WOUND: "把人打成重傷", rumors.HURT: "出手傷人"}


def worries(rows: dict, x: dict, now: int) -> list[worry.Worry]:
    """他身上的心事（第 9-2、9-3 題）：小表抽過的（帳上的「心事」）和現成的狀態；對象是你的不算，小表那條的對象不重複算。"""
    me, by = x["name"], {p["name"]: p for p in rows["npcs"]}
    mine = [l for l in rows.get("ledger", []) if l["status"] == society.OPEN and not l.get("session_id")]
    drawn = [l for l in mine if (l["kind"], l["a"]) == (society.WORRY, me)]
    out = [_drawn(l, mine, me) for l in drawn]
    taken = {l["b"] for l in drawn} | {l["b"] for l in rows.get("ledger", []) if (l["kind"], l["a"]) == (society.WORRY, me)   # 辦成了結的一年內不再算（9-9）
                                       and l["status"] != society.OPEN and now - (l.get("clock_shichen") or 0) < SHICHEN_PER_YEAR}
    for l in mine:
        kind, other = {(society.FEUD, "a"): ("血仇", "b"), (society.HUNT, "a"): ("追查兇手", "b"), (society.DEBT, "b"): ("債", "a"),
                       (society.HIRED, "a"): ("受託", "b"), (society.MARKED, "a"): ("記過", "b")}.get(
            (l["kind"], "a" if l["a"] == me else "b" if l["b"] == me else ""), ("", ""))
        if kind and (l[other] in by or kind == "記過") and l[other] not in taken:
            out.append(worry.of(kind, l[other], l.get("clock_shichen") or 0, ids=(l["id"],) if l.get("id") else ()))
    held = {l["a"] for l in rows.get("ledger", []) if l["kind"] == society.JAILED and l["status"] == society.OPEN}
    for b in rows["bonds"]:
        k = b["b"] if b["a"] == me else b["a"] if b["b"] == me else ""
        if b["type"] not in ("親人", "伴侶") or k not in by or k in taken:
            continue
        q, call = by[k], "家裡那口子" if b["type"] == "伴侶" else society.kin_call(x, by[k])
        died = q["status"] != "ALIVE" and now - (q.get("evolved_shichen") or 0) < SHICHEN_PER_YEAR
        kind = "家人殞落" if died else "" if q["status"] != "ALIVE" else "家人關押" if k in held else \
            "家人遠方" if q["location"] == society.AWAY else {"重傷": "家人重傷", "負傷": "家人負傷"}.get(q.get("condition", ""), "")
        out += [worry.of(kind, call, q.get("evolved_shichen") or q.get("away_since") or 0, name=k, call="我" + call)] if kind else []
    fear = society.liking(rows["npcs"], rows["bonds"], rows.get("npc_reasons", []), now, axis=opinion.FEAR)
    out += [worry.of("怕", y, 0, fear=y) for y in sorted({r["toward"] for r in rows.get("npc_reasons", []) if r["holder"] == me and r["axis"] == opinion.FEAR})
            if y in by and y not in taken and fear(me, y) >= 20]
    out += [worry.of("壞傳聞", BAD_NEWS[r["kind"]], r["clock_shichen"]) for r in rows.get("rumors", [])
            if r["subject"] == me and r["kind"] in BAD_NEWS and rumors.still_told(r, now) and BAD_NEWS[r["kind"]] not in taken]
    return out + ([worry.of("殘夢", "", 0)] if origins.dream(x) else [])


def _drawn(l: dict, mine: list[dict], me: str) -> worry.Worry:
    """小表抽過的那筆「心事」帳；同時寫進的債、記過（同一時辰）辦成時跟著了結（9e-3）。"""
    body, c = l["body"], worry.TABLE[l["body"]["條"] - 1]
    r = worry.result(c)
    ids = (l.get("id"), *(k.get("id") for k in mine if k["kind"] in (society.DEBT, society.MARKED) and me in (k["a"], k["b"])
                         and k.get("clock_shichen") == l["clock_shichen"]))
    return worry.Worry(body["級"], l["clock_shichen"], body["說"], body["舉"], worry.sides(c), l["b"],
                       worry.KIN.get(r.get("親", ""), l["b"]), body["隱"], tuple(filter(None, ids)), l["b"] if r["狀態"] == "怕" else "")


ROLE_JOB = {"錢莊": "掌櫃", "當鋪": "朝奉", "消息販子": "小販", "館主": "武師"}   # 心事的對象先挑這種職業的現成的人


def draw(rows: dict, updates, p: dict, here: str, now: int, rng: random.Random) -> None:
    """沒有心事的人從小表抽一條，寫進 updates（第 9-2 題丙、9-6、9-7）：一年內了結過的不抽（9-9）。"""
    me, life = p["name"], rows.get("life", "")
    book = rows.get("ledger", []) + updates.ledger
    if worries({**rows, "ledger": book}, p, now) or any((l["kind"], l["a"]) == (society.WORRY, me) and now - (l.get("clock_shichen") or 0) < SHICHEN_PER_YEAR
                                                       for l in book if l["status"] != society.OPEN):
        return
    by = {q["name"]: q for q in rows["npcs"]}
    near = {here, *(n["name"] for n in space.neighbors(rows["connections"], here))}
    kin = {society.kin_call(p, by[k]) if t == "親人" else t: by[k] for b in rows["bonds"] for k, t in [(b["a"] if b["b"] == me else b["b"] if b["a"] == me and b["type"] == "親人" else "", b["type"])]
           if k in by and t in ("親人", "師父")}
    hall = next((b["b"] for b in rows["bonds"] if b["a"] == me and b["type"] in society.MEMBER_BONDS
                 and any(f["name"] == b["b"] and f["type"] in society.HALLS for f in rows.get("factions", []))), "")
    others = [q for q in rows["npcs"] if q["status"] == "ALIVE" and q["location"] in near and q["name"] != me and q not in kin.values()]

    def target(c) -> str:
        r = worry.result(c)
        if "親" in r:
            q = kin.get(r["親"])
            return q["name"] if q and (q["status"] != "ALIVE") == r["死"] else ""
        role = r.get("對象", "")
        if r["狀態"] == "記過":
            mates = [q["name"] for q in others if any((b["a"], b["b"], b["type"]) == (q["name"], hall, "成員") for b in rows["bonds"])]
            return mates[0] if hall and mates else ""
        pool = [q["name"] for q in others if q.get("job") == ROLE_JOB.get(role)] or ([q["name"] for q in others] if r["狀態"] in ("怕",) or role == "兇手" else [])
        return pool[0] if pool else role if r["狀態"] in ("債", "心事", "傳開") else ""

    group = profile.group(p, rows["bonds"], rows.get("factions", []), now)
    got = worry.draw(rng, {"目的": {p.get("goal", "")}, "職業": {p.get("job", "")}, "修行": {group}}, lambda c: bool(target(c)))
    if not got:
        return
    c, hidden = got
    r, who = worry.result(c), target(c)
    town = next(iter(_towns(rows["locations"], rows["connections"], here)), here)
    words = {"鄰地": next((n["name"] for n in space.neighbors(rows["connections"], here)), here), "鎮": town}
    body = {"說": c.text.format(**words), "舉": c.more[0].format(**words), "級": r["輕重"], "隱": hidden.format(**words), "條": TABLE_NO[c]}
    updates.ledger.append({**society.owed(society.WORRY, me, who, now), "body": body, "id": new_id("led")})   # 先給 id：同一回合就可能開口求你（9e-3）
    if r["狀態"] == "債":
        updates.ledger.append({**society.owed(society.DEBT, who if who in by else f"{words['鄰地']}的{who}", me, now), "id": new_id("led")})
    elif r["狀態"] == "怕":
        updates.reasons.append(opinion.reason(me, who, opinion.hit(opinion.THREAT, opinion.FEAR, opinion.BIG if r["輕重"] != worry.SMALL else opinion.SMALL), now))
    elif r["狀態"] == "記過":
        updates.ledger.append({**society.owed(society.MARKED, me, hall, now), "deadline_shichen": now + SHICHEN_PER_YEAR, "id": new_id("led")})
    elif r["狀態"] == "傳開":
        updates.rumors.append(rumors.make(rumors.CHAT, town, place=town, when=now, detail=f"{me}在{town}比試使了陰招"))


TABLE_NO = {c: i + 1 for i, c in enumerate(worry.TABLE)}


def mind(rows: dict, p: dict, now: int) -> tuple[worry.Worry, bool] | None:
    """他現在的心事和肯不肯說；沒有回傳 None。"""
    w = worry.pick(worries(rows, p, now))
    return (w, worry.opens(p, rows.get("relations", {}).get(p["name"], {}).get("trust", 0))) if w else None


def manner(rows: dict, who: str, now: int) -> str:
    """給說書人的【眼前的人】：心事還沒說出口時的舉止（第 9-4 題）。"""
    p = people.find(rows, who)
    m = mind(rows, p, now) if p else None
    return f"；心裡有事還沒說出口，只寫他的舉止：{m[0].manner}" if m and not m[1] else ""


# ── 人物卡（第 9-8 題、9e-4）─────────────────────────────────────────────
HEAD = ("kin", "age", "realm", "condition", "attitude", "trust", "palace")   # 頭一行，跟著記進快照


def card(rows: dict, p: dict, now: int, me: str) -> dict:
    """在場的人當場算：出身如今、特點（口頭禪不列，9e-4-3）、目標（熟人以上自動知道，9e-4-2）、
    心事（可信或聽他說過才寫那句，之前只寫舉止，9e-4-4）。"""
    rel = rows["relations"].get(p["name"], {})
    w = mind(rows, p, now)
    said = bool(w) and (w[1] or w[0].said in rel.get("heard", []))
    return {"origin": people.who(rows, p, now),
            "quirks": [f"{q}（{voice.QUIRKS[q]}）" for q in p.get("quirks", ()) if q in voice.QUIRKS],
            "goal": evolution.goal_phrase(p, me) if p["goal"] and rel.get("circle") in (society.KNOWN, society.KIN) else "",
            "worry": w[0].said if said else "", "manner": w[0].manner if w and not said else ""}


def cards(rows: dict, view: list[dict], now: int, me: str, threads: list[dict], life: str) -> dict[str, dict]:
    """名字 → 人物卡。在場的照 view（people_view）當場算；不在眼前的讀最後見到時的快照（9e-4-1）。
    你答應幫他的心事支線照現在的線頭寫，翻出的隱情跟在後面。"""
    by = {p["name"]: p for p in rows["npcs"]}
    here = {v["name"]: {**{k: v[k] for k in HEAD}, **card(rows, by[v["name"]], now, me)} for v in view if v["name"] in by}
    away = {n: r["seen"] for n, r in rows["relations"].items() if r.get("seen") and n not in here}
    promised: dict[str, list[str]] = {}
    for t in memory_mod.visible(threads, life):
        if t["status"] == memory_mod.OPEN and t["origin"] == side.MIND:
            found = (t.get("task") or {}).get("worry", {}).get("翻", "")
            promised.setdefault(t["subject"], []).append(t["text"] + (f"（翻出：{found}）" if found else ""))
    return {n: {**c, "promise": promised.get(n, [])} for n, c in {**away, **here}.items()}


def remember(conn, world_id: str, life: str, rows: dict, view: list[dict], shown: dict[str, dict], when: str, where: str) -> None:
    """回合結束時在場、見過面的人：記下這張卡和日期地點，離開後照這份顯示（9e-4-1）。"""
    for v in view:
        if v["name"] in rows["relations"] and v["name"] in shown:
            c = {k: x for k, x in shown[v["name"]].items() if k != "promise"}
            repos.set_card(conn, world_id, v["name"], life, seen={**c, "date": when, "place": where})


def heard(conn, world_id: str, life: str, rows: dict, who: str, said: str) -> None:
    """他把心事說出口了：記住那句，之後信任掉了也照樣寫（9e-4-4）。"""
    had = rows["relations"].get(who, {}).get("heard", [])
    if said not in had:
        repos.set_card(conn, world_id, who, life, heard=[*had, said][-5:])


def _two(known: list[list[str]], said: list[str], asked: bool) -> list[str]:
    """每張牌先講第一句；講過、又追問才講第二句。"""
    return [l for ls in known for l in (ls if asked and ls[0] in said else ls[:1])]


def place_type(rows: dict, here: str) -> str:
    """路人照這裡的職業抽；家級的地方看它的村鎮。"""
    types = [next((l["type"] for l in rows["locations"] if l["name"] == n), "") for n in (here, space.town_of(rows["locations"], here))]
    return next((t for t in types if t in outfit.TABLE["職業"]), types[0])


def stranger(rows: dict, templates: list[dict], sheet: dict, rng: random.Random, *, here: str, text: str, now: int,
             turn_no: int) -> tuple[dict, str, str, tuple[str, str]]:
    """臨時路人（第 9c 批）：回傳（角色卡, 給說書人的【眼前的人】, 他講的那句, （指路的一句, 前往選項））。
    上回合在這裡跟他說過話、沒換身分就是追問，講第二句；不然照身分給一個新的，這裡沒有那種人就指路。"""
    job, kind = passer.asked_for(text), place_type(rows, here)
    last = next((p for p in sheet["passers"] if p["place"] == here and p["turn"] == turn_no - 1 and p["until"] > now), None)
    if last and job in ("", last["job"]):
        p = {**last, "said": 2, "turn": turn_no}
        return {**sheet, "passers": passer.keep(sheet["passers"], p, now)}, passer.line(p), p["lines"][1] if last["said"] == 1 and len(p["lines"]) > 1 else "", ("", "")
    if job and kind not in passer.where(job):
        near = [here, *(n["name"] for n in space.neighbors(rows["connections"], here))]
        there = next((n for n in near if place_type(rows, n) in passer.where(job)), "")
        return sheet, "", "", (f"這裡找不到{job}，{there}那邊才有" if there else f"這一帶找不到{job}", f"前往{there}" if there else "")
    p = passer.make(rng, job, here, kind, now, turn_no)
    if not p:
        return sheet, "", "", ("", "")
    pool = [*_main(rows, templates, sheet, here)[:1], news.told(rows, here, now, rows.get("life", ""), p["circle"]),
            *(l for ls in talk.commons(p["circle"], common(rows, here, now, sheet)) for l in ls)]
    p = {**p, "lines": [l for l in pool if l][:2], "said": 1}
    return {**sheet, "passers": passer.keep(sheet["passers"], p, now)}, passer.line(p), p["lines"][0] if p["lines"] else "", ("", "")


def recent(rows: dict, who: str) -> list[str]:
    """近況（話題第 ④ 格，第 9f 批）：這一生記下他的近況，新的在前，最多兩句。"""
    news = [n for n in rows["memories"] if n["subject"] == who and n["kind"] == memory_mod.NEWS and n["session_id"] == rows.get("life")]
    return [n["text"] for n in sorted(news, key=lambda n: -n["clock_shichen"])[:2]]


NEAR_MAX, HEARD_MAX, MET_MAX = 8, 3, 3   # 附近的事最多幾條；其中傳來的消息、認識的人的近況各最多幾條


def _ago(now: int, t: int) -> str:
    return f"{clock.format_span(now - t)}前" if now > t else "剛剛"


def nearby(rows: dict, templates: list[dict], sheet: dict, here: str, now: int) -> list[tuple[str, dict | None]]:
    """附近的事（Claude 主導第 4 題甲，第 3 批）：（一條事實, 講到時記的線頭或 None）。只列事實，帶進戲由大模型決定。
    手上路線的風聲 → 附近還沒結束、手上沒在查的事端的風聲（講到就記線頭，同 turn） → 傳到這裡的消息 → 認識的人（不在場）的近況。"""
    out = [(f"手上的事：{x}", None) for x in _main(rows, templates, sheet, here)[:1]]
    around, by_name = routes.around(rows, here), {plot.name(t): t for t in templates}
    for p in rows["plots"]:
        if p["town"] in around and p["ended_shichen"] is None and p["name"] in by_name and not route.holds(sheet, plot.tag(p)):
            text = plot.fill(by_name[p["name"]]["風聲"][0][0], p["cast"])
            out.append((f"{p['town']}的風聲：{text}", lead.make(route.PLOT, plot.tag(p), p["town"], text, now)))
    heard = sorted(news._arrived(rows, here, now), key=lambda x: -x[0]["clock_shichen"])[:HEARD_MAX]
    out += [(f"{_ago(now, r['clock_shichen'])}傳到這裡的消息：{rumors.text(news._version(rows, r, km, here))}", None) for r, km in heard]
    away = {n for n, r in rows.get("relations", {}).items() if r.get("met")} - people.present_names(rows, here)
    notes = sorted((n for n in rows.get("memories", []) if n["subject"] in away and n["kind"] == memory_mod.NEWS
                    and n["session_id"] == rows.get("life")), key=lambda n: -n["clock_shichen"])
    latest = {}
    for n in notes:   # 每人最新一件
        latest.setdefault(n["subject"], n)
    out += [(f"{n['subject']}（{_ago(now, n['clock_shichen'])}）：{n['text']}", None) for n in list(latest.values())[:MET_MAX]]
    return out[:NEAR_MAX]


def probe(rows: dict, name: str, now: int) -> str:
    """大模型第一段點名要查的人或地方（第 4 題甲）：給第二段的近況一行。"""
    p = people.find(rows, name)
    if p:
        if p["status"] != "ALIVE":
            return f"{name}：已經不在人世"
        state = people.doing(rows, p, now)
        where = f"人在{p['location']}，此刻{'不在那裡，' if state[0] == routine.OUT else ''}{state[1]}" if p["location"] != society.AWAY else "出遠門了"
        return f"{name}：{where}；{p.get('condition') or '無恙'}" + "".join(f"；近況：{t}" for t in recent(rows, name))
    there = [q["name"] for q in people.present(rows, name)][:5]
    states = [s["name"] for s in rows.get("place_states", []) if s["place"] == name and s["started_shichen"] <= now < s["ends_shichen"]]
    cases = [p["name"] for p in rows["plots"] if p["town"] == name and p["ended_shichen"] is None]
    return f"{name}：" + "；".join(x for x in (f"這時候在那裡的人：{'、'.join(there)}" if there else "這時候那裡沒有認識的人",
                                              f"狀況：{'、'.join(states)}" if states else "", f"正有事：{'、'.join(cases)}" if cases else "") if x)


def _near(rows: dict, templates: list[dict], sheet: dict, here: str) -> tuple[dict, dict] | None:
    """附近還沒結束、主角手上沒在查的事端：（事端, 模板）。"""
    around, by_name = routes.around(rows, here), {plot.name(t): t for t in templates}
    return next(((p, by_name[p["name"]]) for p in rows["plots"] if p["town"] in around and p["ended_shichen"] is None
                 and p["name"] in by_name and not route.holds(sheet, plot.tag(p))), None)


def turn(rows: dict, templates: list[dict], sheet: dict, who: str, rng: random.Random, *, here: str, asked: bool, now: int,
         turn_no: int, about: str = "") -> tuple[dict, str]:
    """回傳（角色卡, 這回合他講的事）。講到傳聞就記成線頭，指向真的地方；線頭滿了不擠掉別條。about：你在打聽的人。"""
    p, near = people.find(rows, who), _near(rows, templates, sheet, here)
    rumor = plot.fill(near[1]["風聲"][0][0], near[0]["cast"]) if near else ""
    job = p.get("job") or profile.group(p, rows["bonds"], rows.get("factions", []), now)   # 修士、小孩照修行身分那一組（第 7-1a 批）
    heard = [] if identity.disguised(sheet, now) else _heard(rows, who)   # 易容中他認不出你
    foe = rows.get("relations", {}).get(who, {}).get("affinity", 0) <= circles.HOSTILE   # 敵視你的不講公開消息（第 9-14 題）
    known = [] if foe else talk.commons(news.circle(rows, p, now), common(rows, here, now, sheet))
    sheet, line = talk.pick(rng, sheet, turn_no, kin=p.get("created_by") == home.FAMILY_BY, asked=asked, job=job,
                            offers={"手上": _main(rows, templates, sheet, here), "聽說": heard, "傳聞": [rumor],
                                    "人際": _two(talk.ties(ties(rows, p, here, about=about)), sheet["said"], asked),
                                    "心事": [m[0].said for m in [mind(rows, p, now)] if m and m[1]],
                                    "近況": recent(rows, who),
                                    "常識": _two(known, sheet["said"], asked)})
    if rumor and line == rumor and len(sheet["leads"]) < lead.MAX:
        made = lead.make(route.PLOT, plot.tag(near[0]), near[0]["town"], rumor, now)
        sheet = {**sheet, "leads": lead.add(sheet["leads"], made)[0]}
    return sheet, line
