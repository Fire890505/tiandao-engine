"""長期記憶的遊戲流程（第 17 步）：組聯絡簿、產生這回合的自動記事、寫入記事與線頭。

規則本身在 domain/memory.py（純函式）；這裡負責讀資料庫、把結果交給 service 的回合交易寫入。
"""
from __future__ import annotations

from dataclasses import dataclass, field

from ..domain import calls, clock, judgment, realm
from ..domain import memory as m
from ..domain import npc as npc_mod
from ..store import repos
from . import proposals


def date_label(clock_shichen: int) -> str:
    d = clock.describe(max(0, clock_shichen))
    return f"第{d['year']}年{d['season']}"


# ── 聯絡簿 ───────────────────────────────────────────────────────────────
@dataclass
class ContactBook:
    text: str
    open_threads: dict[int, dict] = field(default_factory=dict)   # 編號 → 線頭（AI 可以結的）


def contact_book(*, session_id: str, notes: list[dict], threads: list[dict], present: list[dict], here: str,
                 protagonist_lifespan: int | None, clock_now: int, people_line, last_contact: dict[str, int], focus: str = "") -> ContactBook:
    """依 WHITEPAPER 第 10 節組聯絡簿。threads 是這一生看得到的線頭（已做過這回合的維護）。

    people_line(npc) → 在場人物那一行（第 6 步的格式）；last_contact：NPC → 這一生最後一次有記事的時間（排序用）。
    focus：眼前的人。16v 第 83 題：只有他給完整資料，其他在場的人只列名字（未成年一定標明）；線頭只給和在場的人、此地有關的。
    """
    active = [t for t in threads if t["status"] in m.ACTIVE]
    open_now = [t for t in active if t["status"] == m.OPEN]
    linked = {t["subject"] for t in open_now}
    people = sorted(present, key=lambda p: (last_contact.get(p["name"], -1), p["name"]), reverse=True)
    shown, others = [p for p in people if p["name"] == focus], [p for p in people if p["name"] != focus]

    sections = []
    for p in shown:   # 這一生的記事＋世界脈動的記事（不屬於任何一生，session_id 空字串；人在眼前才給說書人看）
        mine = [n for n in notes if n["subject"] == p["name"] and n["session_id"] in (session_id, "")]
        past = [n for n in notes if n["subject"] == p["name"] and n["session_id"] not in ("", session_id)
                and m.IMPORTANCE[n["kind"]] >= m.PAST_LIFE_MIN_IMPORTANCE]
        lifespan = npc_mod.lifespan_years(p["realm_lv"])
        sections += [m.Section(f"p:{p['name']}", m.ranked(mine, clock_now=clock_now, lifespan_years=lifespan,
                                                          linked_subjects=linked), *m.PERSON),
                     m.Section(f"past:{p['name']}", m.ranked(past, clock_now=clock_now, lifespan_years=None),
                               *m.PAST_LIFE)]
    place = [n for n in notes if n["subject_kind"] == m.PLACE and n["subject"] == here and n["session_id"] == session_id]
    own = [n for n in notes if n["subject_kind"] == m.SELF and n["session_id"] == session_id]
    related = {p["name"] for p in present} | {here}
    sections += [
        m.Section("place", m.ranked(place, clock_now=clock_now, lifespan_years=protagonist_lifespan,
                                    linked_subjects=linked), *m.PLACE_NOTES),
        m.Section("threads", sorted((m.thread_rank(t, related) for t in open_now if t["subject"] in related), key=lambda x: (x[0], x[1]),
                                    reverse=True), *m.THREADS),
        m.Section("self", m.ranked(own, clock_now=clock_now, lifespan_years=None), *m.SELF_NOTES),
    ]
    chosen = m.assemble(sections)

    lines: list[str] = []
    if shown:
        lines.append("在場人物：")
        for p in shown:
            lines.append(f"- {people_line(p)}")
            if chosen[f"p:{p['name']}"]:
                lines.append("  記事：" + "；".join(_note_line(n) for n in chosen[f"p:{p['name']}"]))
            if chosen[f"past:{p['name']}"]:
                lines.append("  往事（與你無關，是前人的事）：" + "；".join(_note_line(n) for n in chosen[f"past:{p['name']}"]))
    if others:
        lines.append("其他在場的人：" + "、".join(p["name"] + ("（未成年）" if npc_mod.is_minor(p, clock_now) else "") for p in others))
    if chosen["place"]:
        lines.append(f"「{here}」的見聞：" + "；".join(_note_line(n) for n in chosen["place"]))
    if chosen["threads"]:
        lines.append("未了的線頭（結線時用編號）：")
        lines += [f"- {_thread_line(t, clock_now)}" for t in chosen["threads"]]
    if chosen["self"] and shown:
        lines.append("主角近況：" + "；".join(_note_line(n) for n in chosen["self"]))
    return ContactBook("\n".join(lines), {t["no"]: t for t in active})


def _note_line(n: dict) -> str:
    return f"{date_label(n['clock_shichen'])}・{n['text']}" + (m.FAINT if n.get("faint") else "")


def _thread_line(t: dict, clock_now: int) -> str:
    left = m.remaining_text(t, clock_now)
    return f"〔線{t['no']}〕{t['kind']}｜{t['subject']}：{t['text']}" + (f"（{left}）" if left else "")


# ── 這回合自動產生的記事 ─────────────────────────────────────────────────
def turn_notes(*, protagonist: str, before_sheet: dict, after_sheet: dict, verdict: judgment.Judgment | None,
               target: dict | None, npc_changes: dict[str, dict], relations_before: dict[str, dict],
               verdicts: list, care: m.ThreadUpkeep, here: str, clock_now: int, turn_no: int) -> list[dict]:
    """Python 自己知道的事：初遇、動手、生死、關係轉折、主角大事、失約與落空。"""
    def note(kind_of, subject, kind, text, thread_id=None, **fields):
        return m.note(kind_of, subject, kind, text, clock_now=clock_now, turn_no=turn_no, thread_id=thread_id, **fields)

    notes = []
    for v in verdicts:
        if v.accepted and v.kind == proposals.NPC:
            notes.append(note(m.NPC, v.name, m.MEET, f"在{here}初遇{protagonist}"))
        elif v.accepted and v.kind == proposals.LOCATION:
            notes.append(note(m.SELF, protagonist, m.MILESTONE, f"發現{v.name}"))
    if verdict is not None:
        if verdict.new_place and verdict.destination and after_sheet["location"] == verdict.destination \
                and not any(v.accepted and v.name == verdict.destination for v in verdicts):
            notes.append(note(m.SELF, protagonist, m.MILESTONE, f"尋路來到{verdict.destination}"))
        if target and calls.struck(verdict):
            state = npc_changes[target["name"]]["state"]
            if state["status"] == "FALLEN":
                notes.append(note(m.NPC, target["name"], m.DEATH, f"死於{protagonist}之手", actor=protagonist))
            else:
                hurt = f"，{state['condition']}" if state["condition"] != target["condition"] else ""
                notes.append(note(m.NPC, target["name"], m.ATTACK, f"被{protagonist}攻擊{hurt}"))
    for name, change in npc_changes.items():
        if "relation" in change and name in relations_before:
            notes += [note(m.NPC, name, m.TURN, text, attitude=attitude)
                      for text, attitude in m.relation_texts(protagonist, relations_before[name], change["relation"])]
    if after_sheet["realm_lv"] > before_sheet["realm_lv"]:
        stage = realm.stage_name(after_sheet["realm_lv"], after_sheet["stage_index"])
        notes.append(note(m.SELF, protagonist, m.MILESTONE, f"於{here}突破至{stage}"))
    if before_sheet["status"] != "DYING" and after_sheet["status"] == "DYING":
        notes.append(note(m.SELF, protagonist, m.MILESTONE, f"在{here}身受重創，一度瀕死"))
    if after_sheet["status"] == "FALLEN":
        notes.append(note(m.SELF, protagonist, m.DEATH, f"{protagonist}殞落於{here}"))
    for t in care.broken:
        notes.append(note(m.NPC, t["subject"], m.BROKEN, f"{t['text']}，{protagonist}逾期未兌現", t["id"]))
    for t in care.failed:
        if t["subject_kind"] == m.NPC and t["kind"] in m.PROMISES and t["subject"] not in dead_this_turn(npc_changes):
            reason = care.changes[t["id"]]["result_note"]
            notes.append(note(m.NPC, t["subject"], m.FAILED, f"{t['text']}（{reason}）", t["id"]))
    return notes


def dead_this_turn(npc_changes: dict[str, dict]) -> set[str]:
    return {n for n, c in npc_changes.items() if c.get("state", {}).get("status") == "FALLEN"}


# ── 寫入（在回合的交易內呼叫）────────────────────────────────────────────
def write(conn, session: dict, *, turn_no: int, clock_now: int, notes: list[dict], care: m.ThreadUpkeep,
          verdicts: list) -> None:
    world_id, session_id = session["world_id"], session["id"]
    for thread_id, fields in care.changes.items():
        repos.update_thread(conn, thread_id, fields)
    for v in verdicts:
        if v.accepted and v.kind == proposals.THREAD_CLOSE:
            repos.update_thread(conn, v.record["thread_id"], {
                "status": m.CLOSE_RESULTS[v.record["result"]], "closed_shichen": clock_now,
                "result_note": v.record["result"]})
        elif v.accepted and v.kind == proposals.THREAD_OPEN:
            span = m.DEADLINES[v.record["deadline"]]
            repos.insert_thread(conn, world_id, session_id, {
                "kind": v.record["kind"], "subject_kind": v.record["subject_kind"], "subject": v.record["subject"],
                "text": v.record["text"], "status": m.OPEN,
                "deadline_shichen": None if span is None else clock_now + span,
                "opened_shichen": clock_now, "opened_turn": turn_no, "touched_shichen": clock_now})
        elif v.accepted and v.kind == proposals.MEMORY:
            repos.insert_memory(conn, world_id, session_id, m.note(
                v.record["subject_kind"], v.record["subject"], v.record["kind"], v.record["text"],
                clock_now=clock_now, turn_no=turn_no, source=m.NARRATOR))
    for n in notes:
        repos.insert_memory(conn, world_id, session_id, n)


# ── 玩家看的編年史（依對象整理）──────────────────────────────────────────
NOTES_PER_SUBJECT = 30


def chronicle(*, session_id: str, notes: list[dict], threads: list[dict], npcs: list[dict],
              protagonist_lifespan: int | None, clock_now: int, route: str = "") -> dict:
    """「未了的事」面板（主線、支線、結束的）＋每個人物、地點的記事（淡忘的標 faint，前世的標 pastLife）。route：手上的路線。
    世界脈動的記事（不屬於任何一生）不列：玩家要重逢、打聽或聽到傳聞才知道。"""
    lifespans = {p["name"]: npc_mod.lifespan_years(p["realm_lv"]) for p in npcs}
    by_subject: dict[str, list] = {}
    for n in notes:
        if not n["session_id"]:
            continue
        past = n["session_id"] != session_id
        if n["subject_kind"] != m.NPC and past:      # 地點見聞與主角近況屬於那一生的主角
            continue
        lifespan = lifespans.get(n["subject"]) if n["subject_kind"] == m.NPC else protagonist_lifespan
        by_subject.setdefault(n["subject"], []).append({
            "date": date_label(n["clock_shichen"]), "kind": n["kind"], "text": n["text"],
            "faint": m.faded(n, clock_now, lifespan), "pastLife": past})
    view = [{"no": t["no"], "kind": t["kind"], "subject": t["subject"], "text": t["text"], "status": t["status"],
             "remaining": m.remaining_text(t, clock_now) if t["status"] in m.ACTIVE else "",
             "resultNote": t["result_note"], "origin": t["origin"], "next": t["next_step"]} for t in m.visible(threads, session_id)]
    live = [t for t in view if t["status"] in m.ACTIVE]
    return {"route": route,
            "threads": {"main": [t for t in live if t["origin"] == m.MAIN], "open": [t for t in live if t["origin"] != m.MAIN],
                        "closed": [t for t in view if t["status"] not in m.ACTIVE]},
            "notes": {k: v[-NOTES_PER_SUBJECT:] for k, v in by_subject.items()}}
