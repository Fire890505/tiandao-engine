"""地方（第 7-3a 批，WHITEPAPER ㉟～㊸，草稿 progress/地方牌草稿.md；數字暫定）：壓力每月朝目標走，換級的村鎮抽一張地方牌。

- 算哪些村鎮：所在州和相鄰州（service._scopes）；從那處上次算到的月份補到現在，最多 MAX 個月；
  沒算過的補 FIRST 個月。補的是這回合以前的月份就不抽牌。
- 外因（目標的推力）：天災（PUSH，發生期間）、怪談籠罩（凶險 +1）、縣衙首領（㊴：善念 ≥ KIND 仁政 +1，
  善念 ≤ HARSH 且野心 ≥ GREED 苛政 -1；村落沒有縣衙看最近相連的城鎮）、相鄰村鎮到盡頭的那一條（㊵：同一條 ±1，
  取最近的一個；靈氣不傳）、交戰的邊境州（(59)：凶險 +1、糧食 -1，看這回合的關係）。同地牽動、事件外因在 domain/pressure。
- 抽牌（㊸）：哪條往外換級，那個月那處抽一張（rules/content/local.txt，條件「壓」「因」，條件多的那層），同一張同地冷卻一年。
  結果：「壓:人心+2」照事件推（留一年）、「死:凡人一成」在地凡人各 DEATH 死。
- 這回合每處最後抽到的那張傳成傳聞；你在的那處是主事候選（schedule.LOCAL，被挑中才有【主事】那一行），
  相連的地方挑一張寫成一行「聽說」（盡頭先）。換回尋常的方向不抽牌（實作時定）。
"""
from __future__ import annotations

import random
from dataclasses import dataclass, field

from ..config import PROJECT_ROOT
from ..domain import atlas, chains, deck, disaster, memory, npc, pending, pressure, rumors, schedule, space
from ..domain.clock import SHICHEN_PER_MONTH as MONTH, SHICHEN_PER_YEAR as YEAR
from . import routes, zones

DECK = deck.read(PROJECT_ROOT / "rules" / "content" / "local.txt")
DIE, EDGE_KIND = "死:凡人一成", "盡頭"
assert all(c.who == "地方" and all(t == DIE or t.startswith("壓:") and pressure.known(t[2:]) for t in c.result.split())
           for c in DECK), "地方牌的結果寫錯了"
MAX, FIRST, DEATH = 24, 12, 0.1
KIND, HARSH, GREED = 70, 30, 60
PUSH = {"旱災": ("糧食", -2), "蝗災": ("糧食", -2), "水災": ("糧食", -1), "雪災": ("糧食", -1), "瘟疫": ("人心", -1),
        "地震": ("興衰", -1), "輻射外洩": ("興衰", -1), "大停電": ("興衰", -1), "妖獸潮": ("凶險", 2),
        "靈潮": ("靈氣", 2), "靈氣枯竭": ("靈氣", -2)}
WAR = (("凶險", 1), ("糧食", -1))   # 交戰時邊境州的村鎮（(59)）
NEAR = {"人心": ("鬧事", "人心安定"), "興衰": ("生意蕭條", "生意興旺"), "凶險": ("太平無事", "不太平"), "糧食": ("斷了糧", "糧食豐足")}
TOWNS = ("城鎮", "村落")


@dataclass
class Scene:
    """你在的那處抽到的牌：ask 是候選；被挑中才有 scene（放進【主事】）和 lines。"""
    ask: schedule.Ask | None = None
    scene: str = ""
    lines: list[str] = field(default_factory=list)


def head(rows: dict, town: str) -> dict | None:
    """縣衙首領（㊴）：這處的朝廷勢力的首領；沒有就看最近相連、有首領的城鎮。"""
    alive = {p["name"]: p for p in rows["npcs"] if p["status"] == "ALIVE"}
    kinds = {l["name"]: l["type"] for l in rows["locations"]}

    def of(t: str) -> dict | None:
        fs = {f["name"] for f in rows["factions"] if f["type"] == "朝廷" and space.town_of(rows["locations"], f["location"]) == t}
        return next((alive[b["a"]] for b in rows["bonds"] if b["type"] == "首領" and b["b"] in fs and b["a"] in alive), None)

    return of(town) or next((g for n in space.neighbors(rows["connections"], town) if kinds.get(n["name"]) == "城鎮"
                             and (g := of(n["name"]))), None)


def pushes(card: dict, town: str, t: int, *, woes: list, gov: dict | None, zone: bool, near: list[str], era: str,
           war: str = "") -> list[tuple]:
    """這處這個月的外因 [(壓力, 級, 因, 原因)]。war：這處在交戰的邊境州，跟哪一國打（(59)）。"""
    out = [(*PUSH[k.name], k.name, f"自從{disaster.label(k.name, era)}之後") for k in woes if k.name in PUSH]
    out += [(k, v, "交戰", f"自從跟{war}開戰") for k, v in WAR] if war else []
    out += [("凶險", 1, "怪談", "自從鬧了怪事")] if zone else []
    if gov and gov["kindness"] >= KIND:
        out.append(("人心", 1, "仁政", f"自從{gov['name']}主事"))
    elif gov and gov["kindness"] <= HARSH and gov["ambition"] >= GREED:
        out.append(("人心", -1, "苛政", f"自從{gov['name']}主事"))
    for k in NEAR:
        v, n = next(((v, n) for n in near if abs(v := pressure.levels(card, n).get(k, 0)) == pressure.EDGE), (0, ""))
        out += [(k, 1 if v > 0 else -1, "鄰", f"{n}那邊{NEAR[k][v > 0]}")] if v else []
    return out


def _draw(rng: random.Random, row: dict, moved: list[tuple]) -> tuple[deck.Card, str] | None:
    """往外換級的那幾條 → 一張牌和它的原因那一句。"""
    facts = {"壓": {f"{k}{v:+d}" for k, v, *_ in moved}, "因": {c for _, _, c, _ in moved}}
    pool = deck.pool([c for c in DECK if c.name not in row.get("cd", {})], facts)
    if not pool:
        return None
    c = rng.choice(pool)
    at = dict(c.need).get("壓", "")
    return c, next((why for k, v, _, why in moved if f"{k}{v:+d}" == at), "")


def turn(rows: dict, updates, towns: list[str], *, start: int, end: int, here: str, turn_no: int, skip: set[str],
         woes) -> tuple[dict, Scene]:
    """這幾處的壓力補到 end，換級的抽牌結算。woes(村鎮, 時辰)＝那時進行中的天災。回傳（換上新壓力和死者的 rows, 你在那處的候選）。"""
    card, era = rows["pressure"], rows["era"]["era"]
    by = {l["name"]: l["type"] for l in rows["locations"] if space.town_of(rows["locations"], l["name"]) == l["name"]}   # 子地點算上層
    towns = sorted(t for t in towns if by.get(t) in TOWNS)
    near = {t: [n["name"] for n in space.neighbors(rows["connections"], t) if by.get(n["name"]) in TOWNS] for t in towns}
    gov = {t: head(rows, t) for t in towns}
    zone = {t: bool(zones.active(rows, zones.Zones(), place=t)) for t in towns}
    a = rows.get("atlas")
    front, where = (atlas.fronts(a), atlas.state_map(a, rows["connections"])) if a else ({}, {})
    nation = {s["name"]: s["nation"] for s in (a or {}).get("states", [])}
    last = end // MONTH
    first = {t: max(last - MAX, card[t]["t"] // MONTH if "t" in card.get(t, {}) else last - FIRST) + 1 for t in towns}
    drawn, gone, died = {}, set(skip) | set(updates.dead), set()
    for m in range(min(first.values(), default=last + 1), last + 1):
        t, snap = m * MONTH, card
        for town in (x for x in towns if first[x] <= m):
            rng = random.Random(f"{rows['seed']}:local:{town}:{m}")
            enemy = front.get(where.get(town, ""), "")
            ps = pushes(snap, town, t, woes=woes(town, t), gov=gov[town], zone=zone[town], near=near[town], era=era, war=enemy)
            row, moved = pressure.month(card.get(town, {}), t, ps, rng)
            updates.happened += [chains.event(chains.TOP, "", town, town, d.pop("from"), t, turn_no, key=k, v=v, why=why, **d)
                                 for k, v, d, why in chains.tops(moved, row, ps, lambda: chains.war_root(
                                     rows.get("happened", []) + updates.happened, nation[where[town]], enemy) if enemy else "")]
            got = _draw(rng, row, moved) if moved and t > start else None
            card = pressure.put(card, town, {**row, "cd": {**row.get("cd", {}), got[0].name: t + YEAR}} if got else row)
            if not got:
                continue
            c, why = got
            name = (gov[town] or {}).get("name", "衙門")
            drawn[town] = (c, c.text.format(地=town, 首領=name, 因=why))
            tokens = [x[2:] for x in c.result.split() if x != DIE]
            card = pressure.apply(card, town, tokens, t, f"自從{c.name}之後") if tokens else card
            for p in rows["npcs"] if DIE in c.result.split() else ():
                if p["status"] == "ALIVE" and p["realm_lv"] == 0 and p["name"] not in gone | died \
                        and space.town_of(rows["locations"], p["location"]) == town and rng.random() < DEATH:
                    died.add(p["name"])
                    updates.dead.add(p["name"])
                    updates.fields.setdefault(p["name"], {}).update(status="FALLEN", condition=npc.CONDITIONS[-1])
                    updates.world_notes.append(memory.note(memory.NPC, p["name"], memory.DEATH, f"死於{c.name}", clock_now=t, turn_no=turn_no))
    mine, around, out = space.town_of(rows["locations"], here), routes.around(rows, here), Scene()
    updates.rumors += [rumors.make(rumors.LOCAL, town, place=town, when=end, detail=text[:40]) for town, (_, text) in drawn.items()]
    heard = sorted(((c.kind == EDGE_KIND, text) for town, (c, text) in drawn.items() if town in around and town != mine), reverse=True)
    updates.events += [f"聽說：{heard[0][1]}"] if heard else []
    if mine in drawn:
        text = drawn[mine][1]

        def run(sheet: dict) -> dict:
            out.scene, out.lines = f"（地方）{text}", [text]
            return sheet
        out.ask = schedule.Ask(schedule.LOCAL, pending.NOW, turn_no, run)
    npcs = [{**p, "status": "FALLEN", "condition": npc.CONDITIONS[-1]} if p["name"] in died else p for p in rows["npcs"]]
    return {**rows, "pressure": card, "npcs": npcs}, out
