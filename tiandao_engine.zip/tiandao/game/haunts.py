"""亡者在回合流程裡（第 11-2 步）：認出對象、現身、交手、說出執念、安息、新的死者變成亡者。

規則在 domain/undead.py。資料來自回合開始時讀好的 rows["undead"]；結果放在 Haunts，由 service 在回合的交易裡寫入（write）。
亡者不是 NPC：不進 NPC 表，所以不參與背景演化、關係、名聲、提案審核。
"""
from __future__ import annotations

import random
from dataclasses import dataclass, field

from ..domain import atlas, games, items, judgment, laws, legacy, newghosts, origins, rumors, society, space, truth, undead
from ..domain import memory as m
from ..domain import status as status_mod
from ..domain.clock import SHICHEN_PER_MONTH
from ..store import repos
from ..util import new_id

ASKED = (judgment.SOCIAL, judgment.OBSERVE)   # 對幽魂交談或觀察成功：說出執念
SHRINE = "祠堂"                                # 牌位在這種地方（同 rebirths.SHRINE）
RITES = ("祭", "拜", "上香", "燒紙")           # 祭拜的字（第 8-4-5 題甲）


@dataclass
class Haunts:
    """這回合亡者的變化。changed：id → 新的亡者；threads／closed：開的線頭、結掉的線頭（id → 欄位）。"""
    born: list[dict] = field(default_factory=list)
    changed: dict[str, dict] = field(default_factory=dict)
    events: list[str] = field(default_factory=list)
    threads: list[dict] = field(default_factory=list)
    closed: dict[str, dict] = field(default_factory=dict)
    notes: list[dict] = field(default_factory=list)
    rumors: list[dict] = field(default_factory=list)
    rested: set[str] = field(default_factory=set)   # 這一生了結執念、讓他安息的幽魂（亡者執念型領域算破解，第 19-1 步）
    pushes: list[tuple[str, str]] = field(default_factory=list)   # (地點, 壓力)：聞冥安息時的人心（第 6-5c 批）
    souls: list[dict] = field(default_factory=list)    # 進待投胎名單的（帳，第 7-5b 批）
    pushed: set[str] = field(default_factory=set)      # 名單滿了被擠掉的（帳 id）

    def now(self, u: dict) -> dict:
        return self.changed.get(u["id"], u)


def facing(rows: dict, sheet: dict, nature: str, player_input: str) -> dict | None:
    """這回合行動的對象是不是現身中的亡者：在主角所在地、現身中、交手／交談／潛行／觀察時提到他。"""
    u = undead.here(rows["undead"], sheet["location"])
    targeted = nature in (judgment.COMBAT, judgment.SOCIAL, judgment.STEALTH, judgment.OBSERVE)
    return u if u and u["awake"] and targeted and undead.named(u, player_input) else None


def rise(h: Haunts, rows: dict, place: str, *, rng: random.Random, action: str, retreating: bool, clock_now: int,
         boost: float = 1) -> dict | None:
    """亡者這回合現身了沒（現身算這回合的事件）。回傳現身的亡者。boost：命途「亡者回聲」（16g）。"""
    u = undead.here(rows["undead"], place)
    if not undead.rises(rng, u, action=action, retreating=retreating, clock_now=clock_now, boost=boost):
        return None
    h.changed[u["id"]] = {**u, "awake": True}
    h.events.append(f"亡者現身：{undead.label(u, clock_now)}")
    return u


def possess(sheet: dict, rng: random.Random, clock_now: int) -> dict:
    """寄身讀一（真相分法，第 6-5c 批）：亡者現身時有機會借了主角的身，留下怨念纏身一個月。"""
    if not truth.possessed(sheet, rng):
        return sheet
    return {**sheet, "statuses": status_mod.add([dict(s) for s in sheet["statuses"]], status_mod.make(
        undead.SPITE, status_mod.NEGATIVE, undead.SPITE_MAGNITUDE, clock_now + SHICHEN_PER_MONTH))}


def fight(h: Haunts, u: dict, verdict: judgment.Judgment, sheet: dict, rng: random.Random, *, protagonist: str,
          life: str, here: str, clock_now: int, turn_no: int, threads: list[dict], bearer: tuple[str, str] | None = None,
          in_plot: bool = False) -> dict:
    """主角對現身的亡者做了什麼：交手往下打、打散的收穫與代價；對幽魂交談或觀察成功就說出執念、開線頭。回傳角色卡。
    bearer：約定的話現在該帶給誰（haunts.bearer）；對象不在了，說出執念時一起說。
    in_plot：舊亡魂（plotted）不開說出執念的線頭，了結看事端的轉折（第十節零件草稿）。"""
    after, events = undead.struck(u, [(c.target, c.outcome) for c in verdict.all_checks], clock_now)
    h.events += events
    name, power = undead.label(u, clock_now), undead.power(u, clock_now)
    if after["condition"] == undead.GONE:
        after = {**after, "awake": False}
        if u["form"] == undead.CORPSE:   # 打散屍變：擲一次戰利品，傳開
            got = items.loot(rng, sheet, power)
            if got:
                sheet, fact = got
                h.events.append(f"從{name}身上{fact}")
            h.rumors.append(rumors.make(rumors.DISPEL, protagonist, target=name, place=here, when=clock_now, lv=power,
                                        subject_lv=sheet["realm_lv"], life=life))
        else:                            # 強行打散還有執念的幽魂：怨念纏身一個月
            statuses = status_mod.add([dict(s) for s in sheet["statuses"]], status_mod.make(
                undead.SPITE, status_mod.NEGATIVE, undead.SPITE_MAGNITUDE, clock_now + SHICHEN_PER_MONTH))
            sheet = {**sheet, "statuses": statuses}
            h.events.append(f"強行打散了{name}，留下狀態「{undead.SPITE}」")
    elif u["form"] == undead.GHOST and verdict.action_type in ASKED and verdict.is_success \
            and not _wish_thread(threads, u, life) and not in_plot:
        text = undead.wish(u)
        h.threads.append({"kind": m.MY_PROMISE, "subject_kind": m.PLACE, "subject": u["place"], "text": text,
                          "status": m.OPEN, "deadline_shichen": None, "opened_shichen": clock_now, "opened_turn": turn_no,
                          "touched_shichen": clock_now})
        h.events += [f"{name}說出了放不下的事", f"未了的事：{text}", *[x for x in [undead.bearer_text(u, bearer or (u["grudge_on"], ""))] if x]]
    h.changed[u["id"]] = after
    return sheet


def plotted(rows: dict, u: dict) -> bool:
    """這個亡者是舊亡魂事端裡的那一個（domain/newghosts.py）。"""
    return any(p["cast"].get(newghosts.DEAD) == u["name"] and p["cast"].get("留處") == u["place"] for p in rows["plots"])


def bearer(rows: dict, u: dict, dead: set[str]) -> tuple[str, str]:
    """約定型幽魂現在該把話帶給誰（125-9 ②、第 8-4-5 題甲）：（人, 牌位）。對象還在＝對象；死了＝活著的後人；
    沒後人＝對象最後待的村鎮的祠堂（同覺醒的牌位），沒祠堂改死處；連人都查不到＝（"", ""）。"""
    on = u["grudge_on"]
    if u["grudge"] != undead.PROMISE or on not in dead:
        return on, ""
    alive = {p["name"] for p in rows["npcs"] if p["status"] == "ALIVE"} - set(dead)
    if heir := society.heir(rows["bonds"], on, alive):
        return heir, ""
    p = next((p for p in rows["npcs"] if p["name"] == on), None)
    if not p or not p["location"]:
        return "", ""
    town = space.town_of(rows["locations"], p["location"])
    return "", next((l["name"] for l in rows["locations"] if l["type"] == SHRINE and space.town_of(rows["locations"], l["name"]) == town),
                    p["location"])


def rite_at(player_input: str, action_type: str, here: str) -> str:
    """主角這回合在 here 祭拜了沒（行動有祭、拜、上香、燒紙，或在那裡休息）：有就回 here。"""
    return here if action_type == judgment.REST or any(w in player_input for w in RITES) else ""


def settle(h: Haunts, rows: dict, sheet: dict, *, dead: set[str], told: str, life: str, protagonist: str,
           clock_now: int, turn_no: int, threads: list[dict], rite: str = "") -> dict:
    """幽魂的執念了結了沒（每回合都看，不論主角在不在）：了結就安息；這一生答應過他的，拿到回報。回傳角色卡。
    rite：主角這回合祭拜的地方（rite_at；約定改帶牌位用）。"""
    for u in [h.now(u) for u in rows["undead"]]:
        t = _wish_thread(threads, u, life)
        b = bearer(rows, u, dead)
        if not undead.settled(u, dead=dead, told=told if t else "", bearer=b, rite=rite if t else ""):
            continue
        h.changed[u["id"]] = {**u, "condition": undead.GONE, "awake": False}
        if not any(p["name"] == u["name"] and p.get("created_by") == legacy.RETIRED_BY for p in rows["npcs"]):
            _queue(h, rows, u["name"], u["place"], u["died_shichen"], clock_now)   # 安息了才去投胎（主角不進）
        if not t:
            continue
        name = undead.label(u, clock_now)
        if u["grudge"] == undead.PROMISE and b == ("", ""):   # 沒人可帶話、也沒有牌位：自己散了，沒有收穫
            h.closed[t["id"]] = {"status": m.RESOLVED, "closed_shichen": clock_now, "result_note": "幽魂自己散了"}
            h.events.append(f"{name}等不到可以帶話的人，自己散了")
            continue
        h.rested.add(u["id"])
        h.closed[t["id"]] = {"status": m.RESOLVED, "closed_shichen": clock_now, "result_note": "幽魂安息"}
        h.events.append(f"{name}的執念了結，安息了")
        h.pushes += [(u["place"], t_) for t_ in [truth.rested(sheet)] if t_]
        h.notes.append(m.note(m.SELF, protagonist, m.MILESTONE, f"讓{name}安息", clock_now=clock_now, turn_no=turn_no))
        if sheet["realm_lv"] >= 1:
            insight, reached = laws.reward(sheet, undead.REST_LAW, round(undead.REST_INSIGHT * origins.rest(sheet)))   # 聞冥（第 6-5d 批）
            sheet = {**sheet, "insight": insight}
            h.events += reached
    return sheet


def leave(h: Haunts, rows: dict, place: str) -> None:
    """主角不在這裡了：現身中的亡者隱去。"""
    for u in [h.now(u) for u in rows["undead"]]:
        if u["awake"] and u["place"] != place:
            h.changed[u["id"]] = {**u, "awake": False}


def born(h: Haunts, rows: dict, deaths: list[dict], clock_now: int, *, protagonist: dict | None = None,
         life: str = "", threads: list[dict] = (), relations: dict[str, dict] | None = None) -> None:
    """這回合死去的人會不會變成亡者。deaths：死去的 NPC（rows 裡死前的樣子，所在地＝死處）；
    protagonist：這回合殞落的主角角色卡（一定會，執念看宿敵、仇人、答應的事）；relations：這一生回合結束時的關係。"""
    alive = {p["name"] for p in rows["npcs"] if p["status"] == "ALIVE"} - {p["name"] for p in deaths}
    haunted = {u["place"] for u in rows["undead"] if u["condition"] != undead.GONE}
    people = [(p, p.get("created_by") == legacy.RETIRED_BY, undead.npc_grudge(p, alive)) for p in deaths]
    if protagonist:
        rival = next((g["name"] for g in rows["games"] if g["session_id"] == life and g["kind"] == games.RIVAL
                      and not g["result"]), "")
        promised = [t["subject"] for t in threads if t["kind"] == m.MY_PROMISE and t["status"] in m.ACTIVE
                    and t["subject_kind"] == m.NPC and t["session_id"] == life]
        grudge = undead.protagonist_grudge(rival, relations or {}, promised, alive)
        people.append(({"name": protagonist["name"], "realm_lv": protagonist["realm_lv"],
                        "location": protagonist["location"]}, True, grudge))
    for p, sure, grudge in people:
        place_type = next((l["type"] for l in rows["locations"] if l["name"] == p["location"]), "")
        u = undead.born(random.Random(f"{rows['seed']}:undead:{p['name']}:{clock_now}"), name=p["name"], lv=p["realm_lv"],
                        place=p["location"], place_type=place_type, clock_now=clock_now, sure=sure, grudge=grudge,
                        haunted=haunted)
        if u:
            h.born.append({**u, "life": life})
            haunted.add(u["place"])
        elif not sure and undead.knotted(p["name"], rows.get("ledger", []), rows["bonds"] + rows.get("mine", [])):
            _queue(h, rows, p["name"], p["location"], clock_now, clock_now)


def _queue(h: Haunts, rows: dict, name: str, place: str, died: int, when: int) -> None:
    """進那一州的待投胎名單（第 7-5b 批），滿了擠掉最舊的。沒有州的舊世界不記。"""
    world = rows.get("atlas")
    if not world:
        return
    state = atlas.state_map(world, rows["connections"]).get(place, world["start"])
    h.souls.append({**undead.wait(name, state, died, when), "id": new_id("led")})
    h.pushed |= set(undead.full([l for l in rows.get("ledger", []) + h.souls if l["id"] not in h.pushed], state))


def write(conn, world_id: str, h: Haunts) -> None:
    """在回合的交易裡呼叫：新的亡者寫入、狀況與現身變了的更新、待投胎名單。"""
    for u in h.born:
        repos.insert_undead(conn, world_id, u["life"], u)
    for uid, u in h.changed.items():
        repos.update_undead(conn, uid, u["condition"], u["awake"])
    for row in h.souls:
        repos.insert_book(conn, "ledger", world_id, row)
    if h.pushed:
        repos.settle(conn, sorted(h.pushed))


def _wish_thread(threads: list[dict], u: dict, life: str) -> dict | None:
    """這一生答應過這個幽魂的線頭（還沒結束的）。"""
    return next((t for t in threads if t["session_id"] == life and t["status"] in m.ACTIVE and t["kind"] == m.MY_PROMISE
                 and u["form"] == undead.GHOST and t["text"] == undead.wish(u)), None)
