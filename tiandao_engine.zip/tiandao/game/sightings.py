"""都市傳說在回合流程裡（第 19-2 步）：出現、移動、碰上、應對、追殺、了結；客死異鄉的傳說。

規則在 domain/legends.py。資料來自回合開始時讀好的 rows["legends"]；結果放在 Sightings，由 service 在回合的交易裡寫入。
碰上的那一回合記在回合紀錄（delta 的 legend），下一回合看應對。
"""
from __future__ import annotations

import dataclasses
import random
from dataclasses import dataclass, field

from ..domain import atlas, domains, era, items, judgment, laws, legacy, legends, rumors, space
from ..domain import memory as m
from ..domain.evolution import AWAY
from ..domain.tales import fill
from ..store import repos


@dataclass
class Sightings:
    """這回合都市傳說的變化。relics：客死異鄉的死者 → 他的遺物落在哪裡（根源處，了結前有他守著）。"""
    born: list[dict] = field(default_factory=list)
    changed: dict[str, dict] = field(default_factory=dict)
    events: list[str] = field(default_factory=list)
    changes: list[dict] = field(default_factory=list)
    threads: list[dict] = field(default_factory=list)
    closed: dict[str, dict] = field(default_factory=dict)
    rumors: list[dict] = field(default_factory=list)
    relics: dict[str, str] = field(default_factory=dict)
    record: dict | None = None
    scene: str = ""
    prompt: str = ""
    moved: bool = False                # 這回合查根源有進度（牌組看）
    more: bool = False                 # 每月擲到傳說時，要不要在背景再寫一篇（第 128 系列乙第 4-1 題，service 去叫）

    def now(self, g: dict) -> dict:
        return self.changed.get(g["id"], g)


def near(rows: dict) -> dict[str, list[str]]:
    return {l["name"]: [n["name"] for n in space.neighbors(rows["connections"], l["name"])] for l in rows["locations"]}


def _active(rows: dict, s: Sightings) -> list[dict]:
    return [g for g in (s.now(g) for g in rows["legends"]) if g["status"] == legends.ACTIVE]


# ── 出現與移動 ─────────────────────────────────────────────────────────────
def born(s: Sightings, rng: random.Random, rows: dict, place: str, legend: legends.Legend, clock_now: int,
         **ghost) -> None:
    """新的傳說：記下來、說法傳開。"""
    g = legends.make(rng, place, legend, near(rows), clock_now, **ghost)
    s.born.append(g)
    s.rumors += [rumors.make(rumors.LEGEND, place, place=place, when=clock_now, detail=text[:40])
                 for text in legends.told(rng, g)]


def options(rows: dict, s: Sightings, here: str) -> list:
    """跟領域一起抽的選項（game/zones.spawn）：（中心, 主題）。模型寫的只在它那一州（第 128 系列乙）。"""
    return legends.options(rows["locations"], near(rows), _active(rows, s) + s.born, {here},
                           rows.get("era", era.DEFAULT), states(rows))


def states(rows: dict) -> dict[str, str]:
    """地點 → 州（模型寫的傳說、怪談只在它那一州出現）；沒有天下骨架的舊世界回空的。"""
    a = rows.get("atlas")
    found = atlas.state_map(a, rows["connections"]) if a else {}
    return {l["name"]: found.get(l["name"], a["start"]) for l in rows["locations"]} if a else {}


def drift(s: Sightings, rows: dict, rng: random.Random, *, start: int, end: int) -> None:
    """每半年三分之一的機會，中心換到相連的一個地點（根源不動）。"""
    for g in _active(rows, s):
        if legends.moves(rng, g, start, end):
            move(s, rows, g, rng, end)


def _taken(rows: dict, s: Sightings) -> set[str]:
    """已經是某個傳說中心的地方（同一個地方只有一個）。"""
    return {g["center"] for g in _active(rows, s) + s.born}


def ways(rows: dict, s: Sightings, g: dict) -> list[str]:
    return [w for w in near(rows).get(g["center"], []) if w not in _taken(rows, s)]


def move(s: Sightings, rows: dict, g: dict, rng: random.Random, when: int) -> str:
    """中心換到相連的地方，回傳去了哪裡，沒地方去回傳空字串。"""
    options = ways(rows, s, g)
    if not options:
        return ""
    to = rng.choice(options)
    s.changed[g["id"]] = {**g, "center": to, "moved_shichen": when}
    s.rumors.append(rumors.make(rumors.LEGEND, to, place=to, when=when, detail=f"最近也有人碰到{g['theme']}"))
    return to


def ghosts(s: Sightings, rng: random.Random, rows: dict, dead: list[dict], clock_now: int) -> None:
    """客死異鄉（第 4、5 題）：前世的主角（退隱後）死在遠方，依執念變成三種傳說之一；中心＝他離開前的地點。
    執念：仇家還活著＝尋仇；友人還活著＝托話；都沒有＝想回老家。帶著的遺物落在根源處，了結前由他守著。"""
    alive = {p["name"] for p in rows["npcs"] if p["status"] == "ALIVE"}
    links = near(rows)
    for p in dead:
        root = p["away_from"]
        if p["created_by"] != legacy.RETIRED_BY or p["location"] != AWAY or not links.get(root):
            continue
        ties = {t: [b["b"] if b["a"] == p["name"] else b["a"] for b in rows["bonds"] if b["type"] == t
                    and p["name"] in (b["a"], b["b"]) and ({b["a"], b["b"]} - {p["name"]}) <= alive] for t in ("仇家", "友人")}
        life = next((life for life in rows["past_lives"] if life["name"] == p["name"]), {})
        home = life.get("home") if life.get("home") in links else root
        kind, target = ((legends.GRUDGE, ties["仇家"][0]) if ties["仇家"] else (legends.PROMISE, ties["友人"][0])
                        if ties["友人"] else (legends.HOMESICK, home))
        free = [x for x in [root, *links[root]] if x not in _taken(rows, s)]   # 根源已經是別的傳說的中心：出沒在旁邊
        if not free:
            continue
        born(s, rng, rows, root, legends.theme(kind), clock_now, dead=p["name"], target=target, home=home)
        s.born[-1]["center"] = free[0]
        s.relics[p["name"]] = root


def guards(rows: dict, relic: dict) -> bool:
    """客死異鄉的傳說還在流傳：他的遺物有他守著，探索找不到（了結後才找得到）。"""
    return any(g["status"] == legends.ACTIVE and g["dead"] == relic["owner"] and g["root"] == relic["place"]
               for g in rows["legends"])


# ── 判定前：本體追殺 ───────────────────────────────────────────────────────
def facing(rows: dict, intent: judgment.Intent, life: str) -> tuple[judgment.Intent, int | None]:
    """被本體追著：想離開就是脫身判定（對手是本體）。"""
    if not any(g["chased"] and g["haunts"] == life and g["status"] == legends.ACTIVE for g in rows["legends"]):
        return intent, None
    if intent.destination:
        intent = dataclasses.replace(intent, nature=judgment.COMBAT, targets=(judgment.ESCAPE,), blocked="")
    return intent, legends.POWER


# ── 回合 ───────────────────────────────────────────────────────────────────
def play(s: Sightings, rows: dict, sheet: dict, *, life: str, before: str, verdict: judgment.Judgment,
         player_input: str, last: dict, clock_now: int, rng: random.Random, target: str, threads: list[dict],
         turn_no: int, protagonist: str, quiet: bool) -> dict:
    """應對上回合碰上的、追殺、了結的進度、這回合會不會碰上。quiet：這回合已經有別的事件。回傳角色卡。"""
    here, nature, when = sheet["location"], verdict.action_type, domains.period(clock_now)
    rec = last.get("legend") or {}
    for g in _active(rows, s):
        if (g["theme"], g["root"]) == (rec.get("theme"), rec.get("root")):   # 存檔匯入後 id 會換，用主題＋根源認
            sheet = _answer(s, rows, g, sheet, life=life, nature=nature, text=player_input, rng=rng,
                            clock_now=clock_now)
    for g in _active(rows, s):
        if g["chased"] and g["haunts"] == life and g["theme"] != rec.get("theme"):   # 剛現身的這回合不打
            sheet = _chase(s, g, sheet, before=before, here=here, verdict=verdict)
    for g in _active(rows, s):
        if g["met"] == life and legends.step_done(g, here=here, when=when, nature=nature, text=player_input,
                                                   target=target, success=verdict.is_success or not verdict.rolled,
                                                   matches=domains.matches):
            s.moved = True
            sheet = _step(s, rows, g, sheet, life=life, threads=threads, clock_now=clock_now, turn_no=turn_no,
                          rng=rng, protagonist=protagonist)
    links = near(rows)
    if not quiet and not rec and sheet["status"] == "ALIVE":
        met = [g for g in _active(rows, s) if not g["chased"] and (
            legends.haunting(g, life, clock_now) and rng.random() < legends.HAUNT_CHANCE
            or legends.in_range(g, here, links) and legends.meets(g, when=when, nature=nature,
                                                                  failed=verdict.rolled and not verdict.is_success)
            and rng.random() < legends.ENCOUNTER)]
        if met:
            g = met[0]
            first = g["met"] != life
            s.changed[g["id"]] = g = {**g, "met": life} if first else g
            if first:   # 這一生第一次碰上：開線頭「弄清來由」
                s.threads.append(_thread(g, "弄清來由", clock_now, turn_no))
            s.record, s.scene = {"theme": g["theme"], "root": g["root"]}, legends.scene(g)
    s.prompt = "；".join(legends.prompt(g) for g in _active(rows, s)
                        if legends.in_range(g, here, links) or legends.haunting(g, life, clock_now))
    return sheet


def _answer(s: Sightings, rows: dict, g: dict, sheet: dict, *, life: str, nature: str, text: str,
            rng: random.Random, clock_now: int) -> dict:
    name = g["theme"]
    result = legends.answer(g, nature=nature, text=text)
    if result == "fled":
        s.events.append(f"{name}化成一陣煙逃走了")
    elif result == "right":
        s.events.append(f"應對對了，{name}離開了")
        if g["rewarded"] != life:   # 這一生第一次答對：一點感悟（19-3 第 5 題；每一生一次，不能來回刷）
            insight, reached = laws.reward(sheet, legends.theme(name).law, legends.ANSWER_INSIGHT)
            sheet = {**sheet, "insight": insight}
            s.events += reached
            s.changed[g["id"]] = {**g, "rewarded": life}
    else:
        g = legends.miss(g, life, clock_now)
        s.changed[g["id"]] = g
        if g["chased"]:
            s.events.append(f"{fill(legends.theme(name).boss, legends.names(g))}現身了，追著你不放")
        else:
            sheet, changes, events = domains.hurt(sheet, domains.HURTS["傷2"])
            s.changes += changes
            s.events += [f"應對錯了，被{name}纏上了", *events]
        move(s, rows, g, rng, clock_now)   # 害了人之後換地方
    return sheet


def _chase(s: Sightings, g: dict, sheet: dict, *, before: str, here: str, verdict: judgment.Judgment) -> dict:
    """本體追殺：脫身成功（離開原地）就甩掉；否則每回合受傷，可以打到瀕死。"""
    if here != before:
        s.changed[g["id"]] = {**s.now(g), "chased": False}
        s.events.append(f"甩掉了{g['theme']}")
        return sheet
    sheet, changes, events = domains.hurt(sheet, domains.BOSS_HURT, lethal=True)
    s.changes += changes
    s.events += [f"{fill(legends.theme(g['theme']).boss, legends.names(g))}追了上來", *events]
    return sheet


def _step(s: Sightings, rows: dict, g: dict, sheet: dict, *, life: str, threads: list[dict], clock_now: int,
          turn_no: int, rng: random.Random, protagonist: str) -> dict:
    legend = legends.theme(g["theme"])
    step = legend.steps[g["step"]]
    g = {**s.now(g), "step": g["step"] + 1}
    s.events.append(f"查明了：{fill(step.reveal, legends.names(g))}")
    head = f"{g['theme']}{legends.THREAD_HEAD}"
    s.closed.update({t["id"]: {"status": m.RESOLVED, "closed_shichen": clock_now, "result_note": "查明了"}
                     for t in threads if t["session_id"] == life and t["status"] in m.ACTIVE and t["text"].startswith(head)})
    if g["step"] < len(legend.steps):
        s.changed[g["id"]] = g
        s.threads.append(_thread(g, step.hint, clock_now, turn_no))
        return sheet
    s.changed[g["id"]] = {**g, "status": legends.CLEARED, "chased": False, "haunts": "", "haunt_until": None,
                          "solved_shichen": clock_now}
    s.events.append(f"{g['theme']}的傳說了結了")
    if sheet["realm_lv"] >= 1:
        insight, reached = laws.reward(sheet, legend.law, legends.INSIGHT)
        sheet = {**sheet, "insight": insight}
        s.events += reached
    if legend.relic:
        sheet, fact = items.grant(rng, sheet, rng.choice((items.PILL, items.TALISMAN, items.ARTIFACT)), 0)
        s.events.append(f"在它留下的東西裡{fact}")
    if g["dead"] and any(r["owner"] == g["dead"] and r["place"] == g["root"] for r in rows["relics"]):
        s.events.append(f"{g['dead']}留下的東西，如今在{g['root']}找得到了")
    s.rumors.append(rumors.make(rumors.CLEARED, protagonist, place=g["root"], when=clock_now, life=life,
                                subject_lv=sheet["realm_lv"]))
    return sheet


def _thread(g: dict, hint: str, clock_now: int, turn_no: int) -> dict:
    return {"kind": m.MYSTERY, "subject_kind": m.PLACE, "subject": g["root"], "text": legends.thread_text(g, hint),
            "status": m.OPEN, "deadline_shichen": None, "opened_shichen": clock_now, "opened_turn": turn_no,
            "touched_shichen": clock_now}


def write(conn, world_id: str, s: Sightings) -> None:
    for g in s.born:
        repos.insert_legend(conn, world_id, g)
    for gid, g in s.changed.items():
        repos.update_legend(conn, gid, g)
