"""路線在回合裡（WHITEPAPER 16v）：走完了沒、自己撞上、天道發下一條。規則在 domain/route.py。"""
from __future__ import annotations

import random
from collections import Counter
from dataclasses import dataclass, field

from ..domain import atlas, cards, chains, character, dark, domains, echo, era, evolution, foreshadow, heaven, home, judgment, knot, legends, memory, names, newcomer, origins, palace, pending, plot, pressure, rebirth, route, rumors, schedule, society, space, stage, tales, truth, undead
from ..domain.clock import SHICHEN_PER_YEAR
from ..domain.incident import WORLD
from ..domain.route import FATE
from . import incidents, people, sightings, zones
from .sightings import Sightings
from .zones import Zones

RISEN = "；上一章沒人理會，他在命主一方裡升了官，這回親自來"   # 上一章放著（第 6-4-3 題甲）
# 確定真讀法時回頭看信對幾次（第 6-5-2 題甲，12 種命共用）：（接在明講後面的話, 留下什麼）
RIGHT = ("回頭看，主角一路信的大多沒錯，原來如此，心裡一下子定了", ["長修為", "記號:命途:看清了自己的命"])
PULLED = "{人}找上門來，說{苦主}那邊出了事，連他也被牽連進去："   # 一般命的章：宮裡的人沒角色演（第 116-7 題）
WRONG = ("回頭看，主角一路信的大多錯了，那些年照錯的去做，這下一起反噬回來", ["受傷", "壓:人心-1"])


@dataclass
class Walk:
    """這回合路線的變化。scene：新路線的開頭（只放事實時模型常常不寫，要放【主事】）；
    lead：通往它的選項；state：到期、結局留下的地點狀況；tail：結局句，敘事寫完由 Python 接上；pushes：結局推動的壓力；
    people：這條路線新來的人，service 登錄。dark：剛結束那條路線的暗線（mark 寫記事，第 5-4-5 題）；won：這回合解開的路線（案中案，game/chains.py）。"""
    sheet: dict
    facts: list[str] = field(default_factory=list)
    changes: list[dict] = field(default_factory=list)
    marks: list = field(default_factory=list)
    state: dict | None = None
    scene: str = ""
    lead: str = ""
    tail: str = ""
    pushes: list[str] = field(default_factory=list)
    people: list[dict] = field(default_factory=list)
    dark: dict | None = None
    won: dict | None = None


@dataclass
class Pick:
    """抽得到的一條。make()：真的放進世界，回傳（key, 地點, 填空用的字）。"""
    kind: str
    name: str
    make: object


def at(rows: dict, r: dict, here: str) -> bool:
    """人在路線那裡。命途跟著人走。"""
    return not r["place"] or space.town_of(rows["locations"], r["place"]) == space.town_of(rows["locations"], here)


def around(rows: dict, here: str) -> set[str]:
    """眼前或附近：這個村鎮、相連的地方，和它們底下的幾處。"""
    town = space.town_of(rows["locations"], here)
    around = {town, *(n["name"] for n in space.neighbors(rows["connections"], town))}
    return around | {l["name"] for l in rows["locations"] if l.get("parent") in around}


def legend_key(g: dict) -> str:
    return f"{g['theme']}:{g['root']}"   # 存檔匯入後 id 會換


def _plots(rows: dict, here: str, near: set[str]) -> list[Pick]:
    """天道抽到事端時用眼前或附近正在跑的那條，眼前的優先（第 5 題）。"""
    live = [p for p in rows["plots"] if p["ended_shichen"] is None and p["town"] in near]
    town = space.town_of(rows["locations"], here)
    return [Pick(route.PLOT, p["name"], lambda p=p: (plot.tag(p), p["town"], p["cast"]))
            for p in [p for p in live if p["town"] == town] or live]


def _zones(rows: dict, z: Zones, rng: random.Random, here: str, near: set[str], now: int, lv: int = 0) -> list[Pick]:
    """附近已有的怪談，或新籠罩一處。儀式型要等人去做，不當路線。只發跟你境界同範圍的（第 116-13 題）。"""
    def fresh(pick):
        d = zones.born(z, rng, rows, pick, now)
        return d["place"], d["place"], domains.names(d, None)

    old = [d for d in rows["domains"] if d["status"] == domains.ACTIVE and d["place"] in near and route.gap(d["scale"], lv) == 0]
    era_now = rows["era"]["era"]   # 路線直接寫出來，主題要是這個時代的（古代沒有公車）
    return [Pick(route.ZONE, d["tale"], lambda d=d: (d["place"], d["place"], domains.names(d, None))) for d in old] \
        + [Pick(route.ZONE, p[2].name, lambda p=p: fresh(p)) for p in zones.free({**rows, "domains": [*rows["domains"], *z.born]}, here)   # 這回合剛長出來的也算
           if p[0] in near and not p[2].doer and era_now in p[2].eras and route.gap(p[1], lv) == 0]


def _legends(rows: dict, s: Sightings, rng: random.Random, here: str, near: set[str], now: int) -> list[Pick]:
    def fresh(place, legend):
        sightings.born(s, rng, rows, place, legend, now)
        g = s.born[-1]
        return legend_key(g), g["root"], legends.names(g)

    old = [g for g in rows["legends"] if g["status"] == legends.ACTIVE and g["center"] in near]
    return [Pick(route.LEGEND, g["theme"], lambda g=g: (legend_key(g), g["root"], legends.names(g))) for g in old] \
        + [Pick(route.LEGEND, g.name, lambda p=p, g=g: fresh(p, g)) for p, g in sightings.options(rows, s, here)
           if p in near and rows["era"]["era"] in g.eras]


def _ghosts(rows: dict, near: set[str]) -> list[Pick]:
    return [Pick(route.GHOST, route.GHOST, lambda u=u: (u["name"], u["place"], {"亡者": u["name"], "地": u["place"]}))
            for u in rows["undead"] if u["condition"] != undead.GONE and u["place"] in near]


def _start(sheet: dict, pick: Pick, rng: random.Random, now: int) -> tuple[dict, str, str]:
    """發出去：回傳（角色卡, 開頭, 通往它的地方）。事端帶到大家聚集的地方，不然只會問到身邊的人。"""
    key, place, cast = pick.make()
    line = route.opening(rng, pick.name, not sheet.get("family"))
    return route.take(sheet, pick.kind, pick.name, key, place, route.HEAVEN, now), plot.fill(line, {"地": place, **cast}), cast.get("公共處", place)


def _picks(rows: dict, sheet: dict, z: Zones, s: Sightings, rng: random.Random, *, here: str, now: int) -> list[Pick]:
    """抽得到的幾條（還沒放進世界）。"""
    near = around(rows, here)
    return [*_plots(rows, here, near), *_zones(rows, z, rng, here, near, now, sheet.get("realm_lv", 0)), *_legends(rows, s, rng, here, near, now),
            *_ghosts(rows, near)]


def draw(rows: dict, sheet: dict, z: Zones, s: Sightings, rng: random.Random, *, here: str, place_type: str, now: int) -> tuple[dict, str, str]:
    """天道抽一條：路線帶標籤，對到就加倍（第 8 題）。沒得抽回傳空字串。特殊命的章、一般命開著的章先發（第 6-3、6-4 批，第 116c 批）。"""
    n = route.chapter_no(sheet)
    ch = route.chapter(sheet, now, _seat(rows, here, stage.LADDER[n - 1]) if n else "")
    if ch:
        r = ch["route"] = _land(rows, sheet, ch["route"], rng, now)
        name = f"{stage.LATER}:{route.last(sheet)[0]}" if stage.later(r) else r["name"]   # 上一章怎麼收場決定開頭（第 6-4-3 題甲）
        return ch, plot.fill(route.opening(rng, name, not sheet.get("family")), {"地": r["place"] or here, "事": stage.word(r)}), r["place"]
    own = _own(rows, sheet)
    if own:
        sheet, line, place = _start(sheet, own[0], rng, now)
        *_, who, role = own[1]["cast"][plot.CHAPTER].split(":")
        line = line if role else PULLED.format(人=who, 苦主=own[1]["cast"].get(plot.VICTIM, "")) + line
        tie = knot.say(own[1]["cast"], line)   # 交會（第 7-4a 批）：結牽到誰，不點破；前面點過名的不再說
        return sheet, line.rstrip("。") + "。" + tie if tie else line, place
    picks = _picks(rows, sheet, z, s, rng, here=here, now=now)
    if not picks:
        return sheet, "", ""
    mine, sizes = route.tags(sheet, place_type), Counter(p.kind for p in picks)
    pick = rng.choices(picks, weights=[route.weight(p.kind, p.name, sheet, mine, sizes[p.kind]) for p in picks])[0]
    return _start(sheet, pick, rng, now)


def _seat(rows: dict, here: str, scale: str) -> str:
    """章開在哪（第 6-4-1 題甲）：離主角最近、那一級的地方，沒有那一級挑現有最大的；村落、世界的章跟著人（空字串）。"""
    if scale in (stage.LADDER[0], stage.LADDER[-1]):
        return ""
    far = space.distances_from(rows["connections"], space.town_of(rows["locations"], here))
    have = [l for l in rows["locations"] if l["name"] in far and 1 <= space.scale_rank(l["scale"]) <= space.scale_rank(scale)]
    top = max((space.scale_rank(l["scale"]) for l in have), default=0)
    return min((l["name"] for l in have if space.scale_rank(l["scale"]) == top), key=far.get, default="")


def _own(rows: dict, sheet: dict) -> tuple[Pick, dict] | None:
    """一般命開著的章（game/fated.py）：手上沒拿著、事端還在，就跟特殊命的章一樣先發。回傳（Pick, 事端）。"""
    o = sheet.get("opened")
    rec = next((p for p in rows["plots"] if o and plot.tag(p) == o["plot"] and p["ended_shichen"] is None), None)
    if not rec or route.holds(sheet, o["plot"]):
        return None
    return Pick(route.PLOT, rec["name"], lambda: (o["plot"], rec["town"], rec["cast"])), rec


def land(rows: dict, sheet: dict, rng: random.Random, now: int, allowed, fate: str, extra=()) -> str:
    """這一章落哪一宮（第 129-2、129-3 題）：大限宮、順著同宮、放著對宮加權；extra：再 ×2 的宮（一般命的偏宮，第 129-6 題）；
    命數找上過你的人（called）在的宮也 ×2（併章重設計第 7 題乙）。"""
    end, _, _, last = route.last(sheet)
    age, b = (now - sheet["birth_shichen"]) // SHICHEN_PER_YEAR, board(rows, sheet)
    calls = [p for p, ppl in b.items() if any(n in sheet.get("called", ()) and not gone for n, _, gone in ppl)]
    return palace.draw(rng, b, list(allowed), fate, palace.boost(end, last, palace.decade(sheet, age)) + list(extra) + calls)


def caller(sheet: dict, mine: list[str]) -> str:
    """命數找上過你、在這一宮的人，最近的先（併章重設計第 7 題乙：抽中他那宮他當命主）。沒有回傳空字串。"""
    return next((n for n in reversed(sheet.get("called", ())) if n in mine), "")


def _land(rows: dict, sheet: dict, r: dict, rng: random.Random, now: int) -> dict:
    """新開的特殊命章抽宮（land）。被擠開存著的章已經有宮。"""
    allowed = stage.palaces(r["name"], stage.number(r))
    return r if r["palace"] or not allowed else {**r, "palace": land(rows, sheet, rng, now, allowed, r["name"])}


def _heir(rows: dict, sheet: dict, here: str = "") -> str:
    """上一章的人回來（第 6-4-3、6-4-4、129-3 題甲）：抗著那個人還在就是他，不在了找他的親人、師父；
    順著又落同一宮（here）也是他。都沒有回傳空字串。被你要脅過、還沒回來的人最先（最近的先，第 6-6c 批）。"""
    end, _, who, was = route.last(sheet)
    alive = {p["name"] for p in rows["npcs"] if p["status"] == "ALIVE"}
    held = next((g for g in reversed(sheet["gripped"]) if g in alive), "")
    if held:
        return held
    if end == stage.ALONG and here and here == was and who in alive:
        return who
    if end != stage.AGAINST or not who:
        return ""
    if who in alive:
        return who
    kin =(b["a"] if b["b"] == who else b["b"] for b in rows["bonds"] if who in (b["a"], b["b"]) and b["type"] in evolution.DEAREST)
    return next((k for k in kin if k in alive), "")


def board(rows: dict, sheet: dict) -> dict:
    """主角的十二宮（第 129-1 題）：自己的羈絆、好感算出的友人仇家、NPC 之間的羈絆（隔一層、首領）、那一生的帳。"""
    life = rows.get("life", "")
    felt = palace.felt(rows.get("relations", {}), life)
    births = {p["name"]: p.get("birth_shichen") for p in rows["npcs"]} | {life: sheet["birth_shichen"]}
    return palace.split(life, rows.get("mine", []) + felt + rows.get("bonds", []), rows.get("ledger", []), births,
                        {p["name"] for p in rows["npcs"] if p["status"] != "ALIVE"})


def seat(rows: dict, sheet: dict) -> dict:
    """人物卡「他在你哪一宮」（第 122c-c 批）：名字 → 宮；隔一層的不寫，你在他哪一宮也不寫（122c-4）。"""
    return {n: p if p.endswith("宮") else p + "宮" for p, ppl in board(rows, sheet).items() for n, w, _ in ppl if w >= 1}


def chart(rows: dict, sheet: dict, now: int, ended: bool) -> dict:
    """命盤（第 129-7 題甲）：十二宮各列認得的人、落過的章和結局，大限那宮標這十年；line＝每章落的宮連成的線（手上這章接在最後）。
    活著只給面板上的命（特殊命點破才換）、隔一層的人不列；死了回顧全揭：真命、哪一讀是真的、隔一層的人。"""
    b, done = board(rows, sheet), [c.split(":") + ["", "", "", ""] for c in sheet["chapters"]]
    open_ = next((r for r in (sheet["route"], sheet["chapter"]) if stage.chapter(r) and r["palace"]), None)
    open_ = open_ or ({"palace": sheet["opened"]["palace"]} if sheet.get("opened") else None)   # 一般命開著的章（第 116c 批）
    line = [c[3] for c in done if c[3]] + ([open_["palace"]] if open_ else [])
    fate = sheet["hidden"] or sheet["fate"] if ended or origins.shown(sheet) else sheet["fate"]   # 一般命沒有真名，照面板的命
    f = origins.FATES.get(fate)
    truth = (f.line if sheet["reading"] == 1 else f.other) if ended and sheet["hidden"] else ""
    cells = [{"name": p, "decade": p == palace.decade(sheet, (now - sheet["birth_shichen"]) // SHICHEN_PER_YEAR),
              "people": [n + ("（已故）" if gone else "") for n, w, gone in b[p] if ended or w >= 1],
              "chapters": [f"第{i + 1}章{c[0]}" for i, c in enumerate(done) if c[3] == p] + (["這一章"] if open_ and open_["palace"] == p else [])}
             for p in palace.PALACES]
    a = rows.get("atlas") or {}   # 因果鏈（第 7-3c2 批）：死了才有
    why = chains.review(rows, set(a.get("nations", {})), atlas.state_map(a, rows["connections"]) if a else {}) if ended else []
    why += [x for x in (_crossed(rows, sheet, i + 1, c[4]) for i, c in enumerate(done)) if x] if ended else []   # 交會（第 7-4b 批）
    why += [f"{n}的前世是{w['body']['名']}" for n, w in rebirth.lives(rows.get("ledger", [])).items()
            if n in rows.get("relations", {})] if ended else []   # 這一世見過的人前世是誰（124-8、第 7-5c 批）
    card, keep = rows.get("era", era.DEFAULT), [x["name"] for x in rows.get("npcs", []) + rows.get("locations", [])]
    w = lambda t: era.words(t, card, keep)   # noqa: E731  時代詞表（第 8-1 批）；判詞（verse）不換
    cells = [{**c, "chapters": [w(x) for x in c["chapters"]]} for c in cells]
    return {"name": sheet["name"], "fate": fate, "verse": f.verse if f else "", "truth": w(truth), "cells": cells, "line": line,
            "chains": [w(x) for x in why]}


def _crossed(rows: dict, sheet: dict, n: int, verdict: str) -> str:
    """死後回顧：第 n 章的交會一行，命都寫真名。"""
    rec = knot.of(rows.get("plots", []), rows.get("life", ""), n)
    him = people.find(rows, rec["cast"][plot.CHAPTER].rsplit(":", 2)[1]) if rec else None
    return knot.review(n, (sheet["hidden"] or sheet["fate"], sheet["reading"]), (him.get("hidden") or him.get("fate", ""), him.get("reading", 0)),
                       him["name"], rec["cast"], verdict) if him else ""


def lead(rows: dict, here: str, place: str) -> str:
    """通往路線的選項。"""
    return "" if not place else "去打聽這件事" if place == space.town_of(rows["locations"], here) else f"前往{place}"


def over(rows: dict, sheet: dict, ticked, z: Zones, s: Sightings, h) -> tuple[bool, bool]:
    """手上這條（結束了沒, 是不是解掉的）。記錄不見了算結束。"""
    r = sheet["route"]
    kind, key = r["kind"], r["key"]
    if kind == route.PLOT:
        now_ = next((c for c in ticked.changes if plot.tag(c[0]) == key and c[2] is not None), None)
        gone = now_ or not any(plot.tag(p) == key and p["ended_shichen"] is None for p in rows["plots"])
        return bool(gone), bool(now_ and now_[0].get("trace"))
    if kind == route.ZONE:
        d = next((z.now(d) for d in reversed(rows["domains"]) if d["place"] == key), None)
        return not d or d["status"] != domains.ACTIVE, bool(d) and d["status"] == domains.CLEARED
    if kind == route.LEGEND:
        g = next((s.now(g) for g in rows["legends"] if legend_key(g) == key), None)
        return not g or g["status"] != legends.ACTIVE, bool(g) and g["status"] == legends.CLEARED
    if kind == route.GHOST:
        u = next((h.now(u) for u in rows["undead"] if u["name"] == key), None)
        return not u or u["condition"] == undead.GONE, bool(u) and u["condition"] == undead.GONE
    done = stage.now(r) == stage.COMING   # 命途走到「被帶向」就照選擇收場，章就了結（第 6-3-2 題甲）
    return done, done


def _people(walk: Walk, rows: dict, rng: random.Random, here: str) -> None:
    """定路線的人（第三批第 1 步）：當地同職業的人優先，沒有才新來一個。名字用完就少一個。
    章的命主（第 6-4-4、129-8 題）：照落的宮那一行，職業空著用宮裡現成的人；後面的章在開章的地方定，
    上一章抗著（或順著又落同一宮）就是那個人或他的親人師父，放著是命主一方裡升了官的人。"""
    r = walk.sheet["route"]
    town = people.town(rows, r["place"] or here)
    if town is None:   # 在荒野、路上：到了村鎮再定
        return
    heir, end = (_heir(rows, walk.sheet, r["palace"]), route.last(walk.sheet)[0]) if stage.later(r) else ("", "")
    mine = palace.who(board(rows, walk.sheet), r["palace"]) if r["palace"] else []   # 宮裡現成的人（第 129-8 題）
    heir = caller(walk.sheet, mine) or heir if stage.chapter(r) else heir   # 命數找上過你的人先（併章重設計第 7 題乙）
    locals_ = [p for p in rows["npcs"] if p["status"] == "ALIVE" and p["created_by"] != home.FAMILY_BY
               and space.town_of(rows["locations"], p["location"]) == town["name"]]
    taken = {p["name"] for p in rows["npcs"]} | {l["name"] for l in rows["locations"]} | {walk.sheet["name"]}
    cast = {}
    for role, trade, gender, age, profile in stage.roles(r):
        if role == stage.BOSS and (heir or not trade and mine):   # 職業空著＝宮裡現成的人，沒有才新來
            cast[role] = heir or mine[0]
            continue
        profile += RISEN if role == stage.BOSS and end == stage.LEFT else ""
        old = next((p for p in locals_ if p.get("job") == trade and gender in ("", p.get("gender")) and p["name"] not in cast.values()), None)
        new = None if old else newcomer.make(rng, place=town["name"], place_type=town["type"], taken=taken, land=people.local_race(rows, here), town=town,
                                             age=age, role=trade, gender=gender,
                                             shun=frozenset(n[len(names.surname_of(n)):] for n in cast.values()))
        if new:
            taken.add(new["name"])
            walk.people.append({**new, "location": town["name"], "profile": profile, "speech": ""})
        if old or new:
            cast[role] = (old or new)["name"]
    walk.sheet = {**walk.sheet, "route": {**r, "cast": cast}, "gripped": [g for g in walk.sheet["gripped"] if g != cast.get(stage.BOSS)],   # 回來過就劃掉（第 6-6c 批）
                  "called": [] if stage.chapter(r) else walk.sheet.get("called", [])}   # 開了章就清掉（併章重設計第 7 題乙）


def _close(walk: Walk, r: dict, rows: dict, rng: random.Random, here: str, now: int, turn_no: int, ignored: bool) -> None:
    """命途的結局（16v 第 73 題）：留下的東西真的改資料。結局句模型常常不寫，由 Python 接在敘事最後（第 92-2 題）。
    ignored：放到期限。"""
    text, left = stage.ending(r, ignored)
    walk.tail = text
    walk.scene = f"（這件事收尾）敘事最後會接上這句：{text}。寫到能接上這句為止，不要寫這句本身" if text else ""
    town = space.town_of(rows["locations"], here)
    told, later, marks = foreshadow.close(r)   # 還沒翻開的伏筆：見過的回頭看，沒見過的之後有人上門說（第 82-2 題）
    walk.scene += f"。另外寫進：{'；'.join(told)}" if walk.scene and told else ""
    walk.facts += told
    walk.sheet = echo.add(walk.sheet, stage.echoes(r, ignored) + later, town, turn_no, now)
    if stage.chapter(r):   # 章了結：記下結局和信哪一讀，下一章讀它（第 6-3-2 題甲）
        walk.sheet = {**walk.sheet, "chapters": [*walk.sheet["chapters"], f"{stage.end_of(r)}:{stage.belief(r)}:{stage.foe(r)}:{r['palace']}"]}
        sure = not walk.sheet["known"] and (stage.number(r) >= stage.NATION or dying(walk.sheet, now))   # 國家章或壽元將盡確定（第 6-5-6 題甲）
        seen = stage.sign(r["name"], stage.NATION if sure or walk.sheet["known"] else stage.number(r), walk.sheet["reading"])
        if sure:
            walk.sheet, seen, more = _sure(walk.sheet, seen)
            left = left + more
        walk.scene += f"。另外寫進這章看得到的跡象：{seen}" if walk.scene and seen else ""
        left = left + truth.closed(walk.sheet, r)   # 啟封讀一：開了封，那地方凶險（第 6-5c 批）
    _pay(walk, left + [stage.MARK + m for m in marks], rows, rng, here, now)


def dying(sheet: dict, now: int) -> bool:
    """壽元將盡（第 123-9 題）：剩不到 LAST_LIFE 年。"""
    left = character.remaining_life_shichen(sheet, now)
    return left is not None and left <= origins.LAST_LIFE * SHICHEN_PER_YEAR


def _sure(sheet: dict, line: str) -> tuple[dict, str, list[str]]:
    """確定真讀法（第 6-5-2 題甲）：明講那句，信對多接好處、信錯多接反噬；角色卡記已確定。"""
    n = route.tally(sheet)
    text, left = RIGHT if n > 0 else WRONG if n < 0 else ("", [])
    return {**sheet, "known": True}, "。".join(filter(None, (line, text))), left


def _pay(walk: Walk, tokens: list[str], rows: dict, rng: random.Random, here: str, now: int) -> None:
    """結局留下的東西：壓力、記號、注視、此地狀況，其餘照牌的效果付。"""
    for token in tokens:
        if token.startswith(stage.PRESS):
            walk.pushes.append(token[len(stage.PRESS):])
        elif token.startswith(stage.MARK):
            walk.sheet = {**walk.sheet, "scars": [*walk.sheet["scars"], token[len(stage.MARK):]]}
        elif token == cards.GAZE:   # 注視（第 81-15 題）：和牌的注視同一套
            walk.marks.append((heaven.ROUTE, heaven.GAIN[heaven.ROUTE]))
        elif token.startswith(stage.HERE):
            walk.state = {"place": here, "name": route.TRACE, "text": token[len(stage.HERE):][:80], "source": WORLD, "game": None,
                          "started_shichen": now, "ends_shichen": now + plot.TRACE_LEN}
        else:
            got = incidents.pay(token, walk.sheet, rows, rng)
            walk.sheet, walk.changes, walk.facts = got.sheet, walk.changes + got.changes, walk.facts + got.events


def mark(walk: Walk, rows: dict, updates, *, name: str, here: str, now: int, turn_no: int) -> dict:
    """結局留在世界上的（16v 第 93、95 題）：事實記在村鎮上，壓力變動，小果傳開。回傳換上新壓力的 rows。
    暗線碰過的人各記一句（第 5-4-5 題），只記還活著的真 NPC。"""
    alive = {p["name"] for p in rows["npcs"] if p["status"] == "ALIVE"}
    updates.notes += [memory.note(memory.NPC, who, memory.TURN, text, clock_now=now, turn_no=turn_no)
                      for who, text in dark.recall(walk.dark, name).items() if who in alive]
    if not walk.tail and not walk.pushes:   # 壽元將盡沒章時確定，只有壓力沒有結局句
        return rows
    town = space.town_of(rows["locations"], here)
    if walk.tail:
        updates.world_notes.append(memory.note(memory.PLACE, town, memory.DEED, walk.tail.replace("你", name)[:memory.MEMORY_TEXT_LEN[1]], clock_now=now, turn_no=turn_no))
        updates.rumors += [rumors.make(rumors.AFTERMATH, town, place=town, when=now, detail=pressure.rumor(town, t)) for t in walk.pushes[:1]]
    return {**rows, "pressure": pressure.apply(rows["pressure"], town, walk.pushes, now)}


def omens(rows: dict, sheet: dict, verdict: judgment.Judgment, *, focus: str, here: str, turn_no: int) -> tuple[dict, list[str]]:
    """伏筆（第 82-1 題）：在那個人面前說話、在路線那裡查探，就露一句破綻；見過兩次後查探成功就翻開。"""
    r = sheet["route"]
    if not r or not foreshadow.hints(r):
        return sheet, []
    looked = verdict.action_type in (judgment.EXPLORE, judgment.OBSERVE) and at(rows, r, here)
    r, facts = foreshadow.turn(r, focus=focus, talked=verdict.action_type == judgment.SOCIAL, looked=looked,
                               found=looked and verdict.rolled and verdict.is_success, turn_no=turn_no)
    return {**sheet, "route": r}, facts


def cast(rows: dict, r: dict, z: Zones, s: Sightings, h, here: str) -> dict:
    """牌上的 {受害者}{此地}{亡者} 這些換成什麼。"""
    kind, key = r["kind"], r["key"]
    found = {}
    if kind == route.PLOT:
        found = next((p["cast"] for p in rows["plots"] if plot.tag(p) == key), {})
    elif kind == route.ZONE:
        found = next((domains.names(z.now(d), None) for d in reversed(rows["domains"]) if d["place"] == key), {})
    elif kind == route.LEGEND:
        found = next((legends.names(s.now(g)) for g in rows["legends"] if legend_key(g) == key), {})
    elif kind == route.GHOST:
        found = {"亡者": key, "對象": _ghost(rows, key).get("grudge_on", "")}
    elif kind == FATE:
        found = dict(r["cast"])   # 路線的人：礦主、族老（暗線的牌寫他們）
    return {"地": r["place"] or here, "此地": r["place"] or here, "鄰地": r["place"] or here, "人": "這裡的人", **found}


def _ghost(rows: dict, key: str) -> dict:
    return next((u for u in rows.get("undead", ()) if u["name"] == key), {})


def part(rows: dict, r: dict) -> str:
    """這條路線的零件套（待辦 3，牌 路線:零件 先抽）：亡者是執念（恩怨、約定），沒有是屍變；模型寫的怪談是扭法、傳說是母題（手寫的空）。"""
    if r["kind"] == route.ZONE:
        return getattr(tales.theme(r["name"]), "twist", "")
    if r["kind"] == route.LEGEND:
        return getattr(legends.theme(r["name"]), "motif", "")
    u = _ghost(rows, r["key"]) if r["kind"] == route.GHOST else {}
    return u and (u["grudge"] or u["form"]) or ""


def _ran_into(rows: dict, sheet: dict, z: Zones, s: Sightings, rose: dict | None, *, before: str, here: str, now: int) -> dict:
    """自己撞上就算接下（第 5 題）：走進怪談、碰上傳說、亡者現身。"""
    d = zones.active(rows, z, place=here)
    if d and not zones.active(rows, z, place=before) and not route.holds(sheet, d["place"]):
        sheet = route.take(sheet, route.ZONE, d["tale"], d["place"], d["place"], route.SELF, now)
    if s.record and not route.holds(sheet, f"{s.record['theme']}:{s.record['root']}"):
        sheet = route.take(sheet, route.LEGEND, s.record["theme"], f"{s.record['theme']}:{s.record['root']}", s.record["root"], route.SELF, now)
    if rose and not route.holds(sheet, rose["name"]):
        sheet = route.take(sheet, route.GHOST, route.GHOST, rose["name"], rose["place"], route.SELF, now)
    return sheet


def turn(rows: dict, sheet: dict, ticked, z: Zones, s: Sightings, h, rose: dict | None, rng: random.Random, *, before: str, here: str,
         place_type: str, now: int, turn_no: int, quiet: bool) -> Walk:
    """一回合：手上的走完了沒、自己撞上。天道發下一條是候選（offer）。quiet：這回合有新來的人，路線的人先等（同一回合兩邊都新來人可能撞名）。"""
    walk = Walk(route.wait(sheet, turn_no))
    sheet = walk.sheet
    if not quiet and sheet["route"] and not sheet["route"]["cast"] and stage.roles(sheet["route"]):
        _people(walk, rows, rng, here)
    sheet = walk.sheet
    r = sheet["route"]
    if r and r["since"] < now:
        ended, solved = over(rows, sheet, ticked, z, s, h)
        if ended or route.late(r, now):
            walk.sheet = route.finish(sheet, turn_no)
            walk.dark = sheet["dark"] if sheet.get("dark") and sheet["dark"]["key"] == r["key"] else None
            walk.won = r if solved else None
            walk.marks += [(heaven.ROUTE, heaven.GAIN[heaven.ROUTE])] if solved and r["by"] == route.HEAVEN else []
            walk.state = None if ended else route.aftermath(r, now)
            walk.facts += [walk.state["text"]] if walk.state and space.town_of(rows["locations"], r["place"]) == space.town_of(rows["locations"], here) else []
            if r["kind"] == FATE:
                _close(walk, r, rows, rng, here, now, turn_no, not ended)
    walk.sheet = _ran_into(rows, walk.sheet, z, s, rose, before=before, here=here, now=now)
    s_ = walk.sheet   # 壽元將盡、手上沒有章：這回合交給說書人明講（第 6-5-6 題甲）
    if s_["hidden"] and not s_["known"] and dying(s_, now) and not stage.chapter(s_["route"]) and not s_["chapter"]:
        walk.sheet, text, left = _sure(s_, stage.sign(s_["hidden"], stage.NATION, s_["reading"]))
        walk.facts.append(f"主角這時看清了自己的命，寫進去：{text}")
        _pay(walk, left, rows, rng, here, now)
    return walk


def offer(walk: Walk, sheet: dict, rows: dict, z: Zones, s: Sightings, rng: random.Random, *, here: str, place_type: str, now: int,
          turn_no: int) -> schedule.Ask | None:
    """候選：天道發下一條（第 2-1a 批）。沒得抽就不是候選；新籠罩的怪談、新的傳說等被挑中才放進世界。"""
    if not route.due(sheet, turn_no) or not (route.chapter(sheet, now) or _own(rows, sheet) or _picks(rows, sheet, z, s, rng, here=here, now=now)):
        return None

    def run(sheet: dict) -> dict:
        sheet, line, place = draw(rows, sheet, z, s, rng, here=here, place_type=place_type, now=now)
        walk.facts.append(line)
        walk.scene = f"（新的事）{line}。寫到主角得知這件事為止，怎麼得知的由你寫"
        walk.lead = lead(rows, here, place)
        return sheet
    return schedule.Ask(schedule.ROUTE, pending.THERE, sheet["route_turn"], run)

