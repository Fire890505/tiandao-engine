"""牌組在回合裡（WHITEPAPER 16v）：看進度、抽牌、結算效果。規則在 domain/cards.py，內容在 rules/content/cards.txt、actions.txt。"""
from __future__ import annotations

import random
from dataclasses import dataclass, field

from ..domain import cards, favour, hearsay, heaven, identity, incident, judgment, pending, plot, route, schedule, side, space, stage, status
from ..domain.clock import SHICHEN_PER_DAY
from . import darks, favours, incidents, plots, routes, sides, traps

LIFT_DAYS = 1   # 順勢持續多久


@dataclass
class Deal:
    """這回合的牌。scene：放進【主事】。lead：通往下一處的選項。choices：階段表的選項（命途的選擇）、請託的回話。
    room：手上支線還有位子。"""
    sheet: dict
    changes: list[dict] = field(default_factory=list)
    events: list[str] = field(default_factory=list)
    marks: list = field(default_factory=list)
    scene: str = ""
    lead: str = ""
    choices: list[str] = field(default_factory=list)
    room: bool = False
    ask: schedule.Ask | None = None   # 這回合的牌（候選）


def _hint(rows: dict, r: dict, sheet: dict, templates: list[dict]) -> dict:
    """下一條線索：只有事端有。"""
    rec, t = plots.case(rows, templates, r["key"]) if r["kind"] == route.PLOT else (None, None)
    return plot.hint(rec, t, sheet, plots.gone(rows)) if t else {}


def _found(rows: dict, r: dict, sheet: dict, templates: list[dict]) -> set[str]:
    rec, _ = plots.case(rows, templates, r["key"]) if r["kind"] == route.PLOT else (None, None)
    return plot.known_of(sheet, rec) if rec else set()


def _step(out: Deal, rows: dict, templates: list[dict], act: str, ok: bool, turn_no: int, rng: random.Random, focus: str, paying: bool,
          now: int) -> None:
    """階段往下走。換階算有推進。被對手動過的門路擋住就推不動（第 5-3-3b 題）。"""
    r, s = out.sheet["route"], out.sheet
    rival = s["dark"]["step"] if s.get("dark") and s["dark"]["key"] == r["key"] else 0   # 暗線:N（第 81-1 題）
    after = stage.advance(r, act=act, ok=ok, found=_found(rows, r, s, templates), idle=s["route_idle"] - s["route_tried"], turn_no=turn_no, dark=rival)
    s, said, changes = darks.stall(rows, s, after, rng, focus=focus, tag=act, ok=ok, paying=paying, now=now)
    out.events, out.changes = out.events + said, out.changes + changes
    out.sheet = {**s, **({"route_idle": 0, "route_tried": 0} if s["route"]["stage"] != r["stage"] else {})}


def _next_place(rows: dict, r: dict, hint: dict, here: str, rng: random.Random) -> str:
    """{地}：下一條線索的地方、路線那裡，都沒有就是相連的村鎮。人已經在那裡就不算。"""
    town = space.town_of(rows["locations"], here)
    spot = hint.get("線索地") or r["place"]
    if spot and spot not in (here, town) and any(l["name"] == spot for l in rows["locations"]):
        return spot
    near = [n["name"] for n in space.neighbors(rows.get("connections", []), town) if space.town_of(rows["locations"], n["name"]) != town]
    return rng.choice(near) if near else ""


def _have(sheet: dict, r: dict, cast: dict, who: str, thing: str, place: str, now: int) -> set[str]:
    """動作牌的需要欄對得上哪些。"""
    side = stage.side(r, cast, who) if who else ""
    poor = sheet["hp"] * 2 < sheet["hp_max"] or sheet["money"] < 10
    wanted = identity.level(sheet, identity.own_name(sheet), now)[0] or sheet.get("alias")
    tags = {f"{stage.MARK}{t}" for t, _ in map(stage.scar, sheet["scars"]) if t}   # 記號:地脈（第 82-3 題）
    searched = r["stage"] > 0 or sum(a in ("查探", "社交") for a in sheet["acts"]) >= 2   # 查過（查:過）：走過一階，或最近查問過兩回
    return {*sheet["records"], *tags, *(["過"] if searched else []), *(["物"] if thing else []), *(["地"] if place else []), *(["窘境"] if poor else []), *(["身分"] if wanted else []),
            *(["人", *(["人非敵"] if side != "敵" else ["人敵"]), *(["人非友"] if side != "友" else [])] if who else [])}


def _effect(out: Deal, card, rows: dict, rng: random.Random, who: str = "", place: str = "", npc_changes: dict | None = None,
            now: int = 0) -> None:
    if card.result == cards.SEE:   # 看破：識破陷阱或知道對手下一步（第 81-9 題）
        out.sheet, said = traps.foresee(out.sheet)
        out.events += said
    elif card.result == cards.LIFT:   # 順勢：判定加分一陣子
        good = status.make(cards.LIFT, status.POSITIVE, 20, now + LIFT_DAYS * SHICHEN_PER_DAY)
        out.sheet = {**out.sheet, "statuses": status.add([dict(x) for x in out.sheet["statuses"]], good)}
        out.events.append(f"留下狀態「{cards.LIFT}」")
    elif card.result == cards.OWE:   # 欠下人情：你欠他一份小恩（16v 第 113 題）
        out.events += favours.give(rows, npc_changes, who, favour.OWE, favour.SMALL, out.events[-1], now) if who and npc_changes is not None else []
    elif card.result == cards.GAZE:
        out.marks.append((heaven.ROUTE, heaven.GAIN[heaven.ROUTE]))
    elif card.result == cards.GUIDE:
        out.lead = f"前往{place}"
    elif card.result == cards.DOUBT:
        out.events += incidents.gain(incident.LOSE_FAVOUR, out.sheet, rows, rng, who=who, npc_changes=npc_changes).events if who else []
    elif card.result == cards.TERMS:   # 開出條件：抽一條請託，等主角回話（第 76 題）；手上滿了就只是一句話
        o = sides.ask(rows, out.sheet, who, rng) if out.room and who else None
        if o:
            out.sheet, out.choices = {**out.sheet, "asking": o}, [side.ACCEPT, side.DECLINE]
            out.scene = f"{out.scene}：{o['words']}。寫到他把話說完，主角還沒回答為止"
    elif card.result and card.result != cards.CLUE:
        got = incidents.pay(card.result, out.sheet, rows, rng)
        out.sheet, out.changes, out.events = got.sheet, got.changes, out.events + got.events


def deal(rows: dict, sheet: dict, verdict: judgment.Judgment, rng: random.Random, z, s, h, *, moved: bool, point: bool,
         records: list[str], here: str, before: str, turn_no: int, templates: list[dict], event: str = "", text: str = "", focus: str = "",
         npc_changes: dict | None = None, now: int = 0, room: bool = False, paying: bool = False, want: str | None = None) -> Deal:
    """記帳：看進度、換階。抽牌是候選（out.ask，第 2-1a 批），只限這回合，沒被挑中就丟。moved：這回合路線有推進。point：這回合走到轉折。
    event：這回合碰到的線頭（那則傳聞）。text：玩家這句話。focus：眼前的人。room：手上支線還有位子。paying：這回合在付錢。
    want：大模型要的那種（第九節 5a），空字串＝不抽；None＝照條件輪（9b）。"""
    out = Deal(cards.note(sheet, verdict.action_type, records), room=room)
    r = out.sheet["route"]
    if not r:
        return out
    r = stage.pick(r, text, turn_no)
    out.sheet = {**out.sheet, "route": r}
    near = routes.at(rows, r, here)
    settled = verdict.action_type != judgment.CULTIVATE and space.town_of(rows["locations"], before) == space.town_of(rows["locations"], here)
    act = cards.TAGS.get(verdict.action_type, "") if near and settled else ""
    ok = verdict.is_success or not verdict.rolled
    out.sheet = cards.progress(out.sheet, moved, bool(act))
    foe = not point and traps.plan(rows, out.sheet, here, verdict)   # 對手盯著：這回合的牌換成陷阱或識破（第 81-7 題）
    pull = None if point or foe else _deck(out, rows, r, verdict, rng, z, s, h, near=near and settled, act=act, ok=ok, here=here, turn_no=turn_no,
                                            templates=templates, event=event, who=focus, now=now, want=want)
    _step(out, rows, templates, act, ok, turn_no, rng, focus, paying, now)
    out.choices = [] if point else stage.options(out.sheet["route"])
    if pull:
        out.ask = schedule.Ask(schedule.CARD, pending.NOW, turn_no, lambda sheet: _play(out, sheet, rows, r, rng, *pull, turn_no=turn_no,
                                                                                         npc_changes=npc_changes, now=now),
                               urgent=verdict.outcome in cards.DICE or bool(want))
    return out


def _deck(out: Deal, rows: dict, r: dict, verdict, rng, z, s, h, *, near: bool, act: str, ok: bool, here: str, turn_no: int, templates: list[dict],
          event: str, who: str, now: int, want: str | None = None) -> tuple | None:
    """這回合抽得到的牌（不改狀態）：回傳（牌堆, 填空的字, 人, 地）；不抽回傳 None。want：見 deal。"""
    kind = want if want is not None else cards.kind_for(out.sheet, verdict.outcome, turn_no, bool(event), bool(act))
    if want is None and not kind and routes.at(rows, r, here) and r["kind"] != route.PLOT and rng.random() < cards.SMALL_CHANCE:   # 事端有自己的小事（plots.small）
        kind = cards.SMALL
    if not kind:
        return None
    dark, records = traps.running(out.sheet), out.sheet["records"]
    turn = kind == cards.TURN and cards.motif(rng, act=act, ok=ok, end=stage.last(r), records=records, dark=dark,
                                              close=bool(who) and rows.get("relations", {}).get(who, {}).get("affinity", 0) >= hearsay.NEAR)
    kind = turn.name if turn else kind   # 走向先挑母型（第 4-8 題）
    hint, cast = _hint(rows, r, out.sheet, templates), routes.cast(rows, r, z, s, h, here)
    used = tuple(out.sheet["card_used"])
    deck = cards.pool(kind, (r["kind"], r["name"], routes.part(rows, r)), near=near, hint=bool(hint), records=records, stage=stage.now(r), act=act, ok=ok, used=used,
                      gone=tuple(k for k, v in cast.items() if v in plots.gone(rows) and k != "亡者"), dark=dark,
                      stuck=kind == cards.CHANCE and verdict.outcome not in cards.DICE, era_now=rows["era"]["era"])   # 機會不是大成功來的就是卡住
    things = [t for t in stage.stuff(r) if not t.endswith("人")]   # {物}不填人
    thing, place = rng.choice(things) if things else "", _next_place(rows, r, hint, here, rng)
    if not deck and (turn or kind in cards.DICE_MOVES):   # 專屬牌優先，沒有對應才用動作牌（走向照母型挑組，第 4-c 題）
        groups = tuple(turn.text.split("、")) if turn else cards.DICE_MOVES[kind]
        deck = cards.moves(groups, act, {cards.WON if ok else cards.LOST, *_have(out.sheet, r, cast, who, thing, place, now),
                                           *([f"地位:{rows['standing']}"] if rows.get("standing") else [])}, used, rows["era"]["era"])   # 第 7-1c 批
    return (deck, {**cast, **hint, "傳聞": event}, {"人": who, "物": thing, "地": place, "事": stage.word(r)}) if deck else None


def _play(out: Deal, sheet: dict, rows: dict, r: dict, rng, deck: list, words: dict, own: dict, *, turn_no: int, npc_changes: dict | None,
          now: int) -> dict:
    """落實：打出這回合的牌。"""
    card = cards.pick(rng, deck, sheet)
    text = plot.fill(card.text, {**words, **(own if card in cards.MOVE_DECK else {})})
    out.sheet = cards.play(sheet, card, text, turn_no)
    out.events.append(text)
    out.scene = f"（{card.kind}）{text}"
    _effect(out, card, rows, rng, own["人"], own["地"], npc_changes, now)
    out.choices = out.choices or stage.options(out.sheet["route"])
    return out.sheet


def note(sheet: dict, turn_no: int) -> str:
    """給說書人的主線一句：這一階；沒有階段表的路線是這類故事怎麼走。"""
    r = sheet["route"]
    return (stage.line(r, random.Random(turn_no)) or cards.GUIDES.get(r["kind"], "")) if r else ""


def held(sheet: dict, turn_no: int) -> str:
    """還留在場景的事：這回合沒有別的事才送（16v 第 83 題）。"""
    return cards.held(sheet, turn_no) if sheet["route"] else ""
