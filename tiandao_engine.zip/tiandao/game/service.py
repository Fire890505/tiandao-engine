"""遊戲流程。一個回合的固定管線（WHITEPAPER 12.1）：

  1. 讀取（帶 user_id，資料層就擋掉別人的局）；這回合要用的世界資料一次讀好（_world_rows），往下傳
  2. 冪等檢查（同一個 requestId 重送 → 直接回傳上次結果）
  3. 階段檢查
  4. Python 判定（judgment.judge，亂數種子 = 局種子 + 回合序號，重送或換句話說都不會重擲）
  5. Python 套用效果（effects.apply，純函式）；補算抵達處的 NPC（background）；線頭維護
  6. AI 敘事（一次呼叫；不持有資料庫交易；失敗則整回合不寫入）
  7. Python 審核 AI 提案（game/proposals.py）
  8. 單一交易寫入：回合紀錄、角色卡、局狀態（樂觀鎖防並行）、補算、採用的提案與審核紀錄

任何一步失敗，資料庫維持在上一回合結束時的狀態。
NPC 的小工具在 game/people.py，存檔在 game/saves.py，背景演化在 game/background.py。
"""
from __future__ import annotations

import dataclasses
import json
import logging
import random
import re
import secrets
import sqlite3
import threading
import time

from ..ai import budget, narrators, tone
from ..ai.contract import ACTS, PROPOSAL_FIELDS, YES, NarrationRequest, NarrationResult
from ..domain import (auction, breakthrough, cards, clock, crafting, crime, daily, echo, effects, era, evolution, favour, form, games, heaven, home, identity,
                      incident, inspiration, items, judgment, laws, legacy, lineage, looks, market, names, newcomer, origins,
                      opinion, party, realm, region, reputation, rumors, sect, side, space, stage, undead, visitors, weather)
from ..domain import (ascent, atlas, avatar, avoid, bondage, breach, contest, disaster, domains, errand, fall, founding,
                      hearsay, hire, immortal, league, lord, merit, paths, prep, pressure, proxy, races, recruit, roster, society, war)
from ..domain import lapse, learn, legends, newdisasters, newghosts, newitems, newlegends, newplots, newtales, newwars, passer, rank, reading, rebirth, schedule, stake, tales, truth, vet
from ..domain import route as route_mod
from ..domain import character as character_mod
from ..domain import plot as plot_mod
from ..domain import scene as scene_mod
from ..domain import spots as spot_mod
from ..domain import memory as memory_mod
from ..domain import npc as npc_mod
from ..domain import oath as oath_mod
from ..domain import world as world_mod
from ..errors import BadRequest, Conflict, NotFound, UpstreamError, text_field
from ..store import repos
from ..store.db import connect, transaction
from ..util import new_id
from . import (background, chains, darks, decks, deeds, factions, fated, favours, gathers, haunts, incidents, leads, local, memory_book, nations, news, people, plots, proposals, realms, rebirths, replies, rites, routes, saves, sides,
               sightings, talks, zones)
from .phases import ENDED, NEED_CHARACTER, NEED_OPENING, PLAYING  # noqa: F401（ENDED 給 tools/ai_check 用）
from .saves import load_sheet

MAX_INPUT_CHARS = 200
LOOK_PICKS = {"髮色": "hair", "髮型": "style", "衣著": "clothes"}   # 搭配卡玩家能自己寫的格（氣質只能從清單挑），3-7b 檢查
RECENT_TURNS_FOR_PROMPT = 3
BIG_RECENT_TURNS = 8          # 大模型：前情多給幾回合、附敘事原文（2026-11-23）
KNOWN_NAMES_FOR_PROMPT = 30   # 提示詞只列最近登錄的名字；審核時比對的是全部
NEW_PLACE_DESCRIPTION = space.NEW_PLACE_DESCRIPTION
NOBODY_HEARD = "此地沒人聽過你"
LOOK_RULE = {"女": "主角是女性，不要用少年、男子這類字眼。", "男": "主角是男性，不要用少女、女子這類字眼。"}
log = logging.getLogger(__name__)


def _in_thread(job) -> None:
    """建世界後要模型寫的東西放背景跑（第 128-12 題甲）：玩家不用等，寫壞了也不影響開局。"""
    threading.Thread(target=job, daemon=True).start()


def _rng(session: dict, purpose: str, turn_no: int = 0) -> random.Random:
    return random.Random(f"{session['rng_seed']}:{purpose}:{turn_no}")


def _request_id(value) -> str:
    rid = str(value or "").strip()
    if not 1 <= len(rid) <= 64:
        raise BadRequest("缺少 requestId。", code="missing_request_id")
    return rid


def _recap(turns: list[dict], place: str, full: bool = False) -> list[str]:
    """前情提要：每回合只給行動與結果的摘要，最後一回合附上「結束時在哪裡」（Python 組的事實）。

    不給敘事原文：給開頭，小模型會照抄成本回合的開頭（Step 0 參考跑第 3、5 回合）；
    給結尾 80 字也一樣會被一字不差抄走（2026-10-06 深度檢查，qwen3.5:9b 第 1 回合；使用者選乙：改給摘要）。
    full：大模型不會照抄，摘要後面再附那回合的敘事原文，記得前面寫過什麼（2026-11-23）。
    """
    lines = []
    for t in turns:
        if t["kind"] == "opening":
            line = "開場"
        else:
            j = t["judgment"]
            checks = j.get("checks") or []
            if len(checks) > 1:
                outcome = "、".join(f"{c['target']}{c['outcome']}" for c in checks)
            else:
                outcome = j.get("outcome", "") if j.get("rolled") else "不需判定"
            changes = "、".join([effects.describe_change(c) for c in t["delta"].get("changes", [])]
                               + t["delta"].get("events", []) + t["delta"].get("side", []))
            act = t["delta"].get("act") or j.get("action_type", "")   # 3-6a：原文不進說書人，用回合存的那一行
            line = f"你{act}，結果：{outcome}" + (f"；{changes}" if changes else "")
        if full and t.get("narrative"):
            line += f"\n  當時的敘事：{t['narrative']}"
        lines.append(line)
    if turns:
        lines[-1] += f"。上回合結束時，你在「{place}」"
    return lines


class GameService:
    def __init__(self, narrator, rulebook):
        self.narrator = narrator
        self.rulebook = rulebook
        self.make_region = region.generate   # 新原初世界的起始區域（第 16b 步）；第 16b 步之前寫的測試換成空區域
        self.pick_lineage = lineage.pick     # 建角沒選的支系（16k 三族）；不測他族的測試換成只抽人族
        self.slave_chance = bondage.chance   # 沒選身分時出身奴隸的機率（16k）；舊測試換成 0
        self.routes_on = True                # 天道發路線（16v）；舊測試關掉，免得多出來的怪談和事端影響結果
        self.acts = False                    # 合成提案（第 2-4b 批）：Settings.acts，A/B 比較用
        self.later = _in_thread              # 背景工作（第 128-12 題甲）；測試換成當場跑
        self._writing: set[str] = set()      # 背景正在寫的天災（鑰匙，newdisasters.key）
        self.omens_on = True                 # 模型寫的天災放前兆（第九節）；舊測試關掉，免得多出來的事端和地方影響結果
        self.ghosts_on = True                # 模型事端四分之一寫成舊亡魂（第十節）；舊測試關掉，理由同上
        self.wars_on = True                  # 打仗的邊境州放戰時事端（第十一節）；舊測試關掉，理由同上
        self.big = False                     # 大模型（聊天版的 Claude）：事端一次叫完、傳說怪談不叫是非題（2026-11-23）

    # ── 世界與局 ──────────────────────────────────────────────────────────
    def create_session(self, conn, user_id: str, title: str, *, world_id: str | None = None,
                       span: str | None = None, world_name: str | None = None, start_era: str | None = None) -> dict:
        """開始新的一生。

        - 沒給 world_id：建立新的原初世界。start_era＝起始時代（預設古代，第 16e 節第 10 題）：
          古代從紀元 0 開始；現代、未來先照舊生成古代的區域，再換到那個時代（世界年數從那個時代的門檻開始）。
        - 給了 world_id：在既有世界開新局。世界不能有進行中的局；已有前世時，時間依 span 往後跳。
        """
        title = _valid_name(title, "新的旅程", "存檔名稱", "invalid_title")
        world_id = text_field(world_id, "世界 id", "invalid_world_id") or None
        span = text_field(span, "時間跨度", "invalid_span") or None
        start_era = text_field(start_era, "起始時代", "invalid_era") or era.ANCIENT
        if start_era not in era.ERAS:
            raise BadRequest(f"起始時代只能選：{'、'.join(era.ERAS)}。", code="invalid_era")
        session_id, fresh, seed = new_id("ses"), not world_id, ""
        try:
            with transaction(conn):
                if world_id:
                    clock_now = self._advance_world_for_new_life(conn, user_id, world_id, span)
                else:
                    world_id, seed = new_id("wld"), secrets.token_hex(16)
                    rng = random.Random(f"{seed}:era")
                    card = era.new(rng)
                    shift = (era.start(card, rng, start_era), rng) if start_era != era.ANCIENT else None
                    clock_now = shift[0]["since"] if shift else 0
                    repos.insert_world(conn, world_id=world_id, user_id=user_id, rng_seed=seed, clock_shichen=clock_now,
                                       name=_valid_name(world_name, title, "世界名稱", "invalid_world_name"))
                    region_now = self.make_region(random.Random(f"{seed}:region"))
                    _write_region(conn, world_id, region_now, clock_now)
                    _write_era(conn, world_id, card, shift)
                    for town in repos.list_locations(conn, world_id):   # 事端（16t）：世界先有，不等玩家；換時代改過地名之後放（第 8-6 批）
                        plots.place(conn, world_id, random.Random(f"{seed}:plot:{town['name']}"), self.rulebook.plots,
                                    town, clock_now, _system_npc)
                    _ensure_atlas(conn, world_id)   # 天下骨架（16k）
                    repos.set_heaven(conn, world_id, _heaven_card(conn, world_id, seed))   # 天道人格卡（第 18-1 步）
                    for row in self.rulebook.items:   # TXT 基本款（16p 第 11 題）：不屬於任何一生
                        repos.insert_item(conn, world_id, "", {**row, "discovered_turn": 0, "source": newitems.HAND})
                    for row in self.rulebook.events:
                        repos.insert_event(conn, world_id, "", {**row, "discovered_turn": 0})
                repos.insert_session(conn, session_id=session_id, user_id=user_id, world_id=world_id, title=title,
                                     phase=NEED_CHARACTER, rng_seed=secrets.token_hex(16), clock_shichen=clock_now)
        except sqlite3.IntegrityError:
            # 兩個請求同時在同一世界開新局：資料庫的部分唯一索引擋下第二個
            raise Conflict("這個世界還有進行中的一局。", code="world_busy") from None
        if fresh:   # 建世界時模型寫這個世界的物品（第 128 系列）：背景跑、自己開連線，寫好才放進世界（128-12 甲）
            path = conn.execute("PRAGMA database_list").fetchone()["file"]
            self.later(lambda: self._alone(path, self._forge, world_id, session_id, seed, start_era))
        return self.get_state(conn, user_id, session_id)

    @property
    def plots(self) -> list[dict]:
        """事端模板：手寫的＋這個世界模型寫的（newplots.use 每回合設一次，同傳說、怪談）。"""
        return newplots.templates(self.rulebook.plots)

    def _alone(self, path: str, job, *args) -> None:
        """背景工作自己開連線（第 128-12 題甲）。"""
        conn = connect(path)
        try:
            job(conn, *args)
        except Exception:   # 背景出錯只記下來：世界照樣有手寫的物品、傳說
            log.exception("背景寫物品或傳說失敗")
        finally:
            conn.close()

    def _more(self, conn, session: dict, rows: dict, s, z, placed: bool = False) -> None:
        """局中補寫（第 128 系列乙第 4-1 題甲）：這回合擲到傳說（怪談）又擲中補寫，背景替它所在的州再寫一篇。
        placed：這回合放了新事端，有 MORE_CHANCE 背景再寫一條模型事端（第 7 題甲），下次放才用得上。"""
        path = conn.execute("PRAGMA database_list").fetchone()["file"]
        if placed and random.Random(f"{session['id']}:{len(rows['plots'])}:plot-more").random() < newplots.MORE_CHANCE:
            self.later(lambda: self._alone(path, self._plot_lore, session["world_id"], session["id"], rows["seed"], rows["era"]["era"], 1))
        if not rows.get("atlas"):
            return
        for kind, place in (("legend", s.more and s.born[-1]["center"]), ("tale", z.more and z.born[-1]["place"])):
            if place:
                state = atlas.state_of(rows["atlas"], rows["connections"], place)["name"]
                self.later(lambda kind=kind, state=state: self._alone(path, self._lore, session["world_id"], session["id"],
                                                                      rows["seed"], rows["era"]["era"], [state], 1, kind))

    def _forge(self, conn, world_id: str, session_id: str, seed: str, era_now: str) -> None:
        """第 128 系列：domain/newitems.plan 定每州寫哪幾件，模型一次寫名字、外觀、來歷，review 審四項；
        沒過的重叫一次，再不過就算了（那一州照樣有手寫的，第 128-4 題乙）。模型失敗也一樣。手寫庫是空的（測試）不叫。"""
        bases = sorted({r["base"] for r in self.rulebook.items})
        atlas_ = repos.get_atlas(conn, world_id)
        if not bases or not atlas_:
            return
        taken = {i["name"] for i in repos.list_items(conn, world_id)} | {l["name"] for l in repos.list_locations(conn, world_id)}
        slots = newitems.plan(random.Random(f"{seed}:items"), atlas_["seed"], [s["name"] for s in atlas_["states"]], bases)
        kept = self._ask_twice(conn, session_id, "forge", slots, lambda s: self.narrator.forge(s, era_now),
                               lambda slot, g, kept: not newitems.review(slot, g, taken, kept, era_now) and newitems.record(slot, g))
        with transaction(conn):
            for r in kept:
                repos.insert_item(conn, world_id, "", r)
        start = next(s for s in atlas_["states"] if s["name"] == atlas_["start"])
        for kind in ("legend", "tale"):
            self._lore(conn, world_id, session_id, seed, era_now, sorted(atlas.near_states(atlas_, start)), newlegends.OPENING, kind)
        self._plot_lore(conn, world_id, session_id, seed, era_now, newplots.OPENING)

    def _groups(self) -> tuple:
        """事端一類分幾次叫：9b 三段分開叫（不知情的那段不給真相）；大模型一次叫完，用最後一段（給全部背景）的說明，洩底照查。"""
        return (newplots.PARTS,) if self.big else tuple((p,) for p in newplots.PARTS)

    def _plot_lore(self, conn, world_id: str, session_id: str, seed: str, era_now: str, n: int) -> None:
        """模型寫 n 條事端（progress/模型生成內容.md 第八節）：newplots.plan 擲骨架，分三段叫（第 12 題甲），每段沒過的欄重寫、
        最多叫 3 次，還不過整條不要、不手寫補（第 8 題甲）。三個時代都寫；每個世界最多 MAX_PER_WORLD 條。
        四分之一是舊亡魂（第十節第 6、9 題，newghosts）：沒寫好的欄用通用句，照樣留。"""
        mine = [t for t in repos.list_themes(conn, world_id, repos.PLOTS_M)
                if not (newdisasters.mine(p := plot_mod.parse(t["body"])) or newwars.mine(p))]   # 天災、戰爭另算
        taken = ({t["name"] for t in mine} | {plot_mod.name(t) for t in self.rulebook.plots}
                 | {l["name"] for l in repos.list_locations(conn, world_id)})
        kept, rng = [], random.Random(f"{seed}:plots:{len(mine)}")
        ghosts = sum(newghosts.mine(plot_mod.parse(t["body"])) for t in mine)
        fought = bool(atlas.fronts(repos.get_atlas(conn, world_id) or {"states": []}))   # 世界上有仗在打：心願、託夢可能是戰死的（第十一節第 8 題乙）
        slots = newplots.plan(rng, era_now, min(n, newplots.MAX_PER_WORLD - len(mine)))
        slots = [newghosts.plan(rng, era_now, ghosts + i, seed, war=fought) if self.ghosts_on and rng.random() < newghosts.SHARE else s
                 for i, s in enumerate(slots)]
        for slot in slots:
            got, mod = {}, newghosts if slot.get("ghost") else newplots
            for group in self._groups():
                part = group[-1]
                got[part], need = {}, [x for p in group for x in mod.asks(slot, p)]
                for _ in range(3):
                    todo = [x for x in need if x["key"] not in got[part]]
                    g = self._ask(conn, session_id, "plot", part, lambda: self.narrator.bits("plot", mod.brief(slot, part), todo))
                    bad = {k: r for p in group for k, r in mod.faults(slot, p, g or {}, taken, era_now).items()}
                    got[part] |= {k: v for k, v in (g or {}).items() if k not in bad and k in {x["key"] for x in todo}}
                    if len(got[part]) == len(need):
                        break
                if len(got[part]) < len(need) and mod is newplots:
                    break
            else:
                r = mod.record(slot, got) if mod is newplots else mod.record(slot, got, taken)   # 亡魂的名字可能是通用句
                taken.add(r["name"])
                kept.append(r)
        with transaction(conn):
            for r in kept:
                repos.insert_theme(conn, world_id, r, repos.PLOTS_M)

    def _omen(self, conn, session: dict, rows: dict, o: dict, skip: set[str]) -> None:
        """到了前兆時刻、主角在那一州（progress/模型生成內容.md 第九節天災第 1、3 題）：放這場天災的事端，時間線從前兆那刻算；
        模型還沒寫好就用通用句拼一份（第 6 題甲）。壓消息的人是那村鎮對得上動機的勢力首領，沒有就是帶頭不信的人（第 4 題甲）。"""
        world_id = session["world_id"]
        t = next((t for t in self.plots if newdisasters.key_of(t) == o["key"]), None)
        if not t:
            r = newdisasters.record(_disaster_slot(conn, world_id, rows["seed"], rows["era"]["era"], o), {},
                                    _disaster_name(conn, world_id, self.rulebook.plots, rows["era"]["era"], o))
            repos.insert_theme(conn, world_id, r, repos.PLOTS_M)
            t = plot_mod.parse(r["body"])
        types = t["勢力"][0][1].split("、") if t.get("勢力") else []
        facs = sorted((f for f in plots._factions(conn, world_id, repos.list_locations(conn, world_id), o["town"]) if f["type"] in types),
                      key=lambda f: f["name"])
        alive, bonds = {p["name"] for p in rows["npcs"] if p["status"] == "ALIVE"}, repos.list_bonds(conn, world_id, everyone=True)
        boss = next((b["a"] for f in facs for b in bonds if b["b"] == f["name"] and b["type"] == "首領" and b["a"] in alive), "")
        town = next(l for l in rows["locations"] if l["name"] == o["town"])
        plots.place(conn, world_id, random.Random(f"{rows['seed']}:omen:{o['key']}"), [], town, o["omen"], _system_npc,
                    skip=skip, boss=boss, fixed=t)

    def _foretell(self, conn, session: dict, rows: dict, omens: list[dict]) -> None:
        """離前兆不到一季、還沒寫的天災交給背景寫（第 6 題甲）；寫好之前到了前兆時刻，_omen 先用通用句放。"""
        path = conn.execute("PRAGMA database_list").fetchone()["file"]
        have = {newdisasters.key_of(plot_mod.parse(t["body"])) for t in repos.list_themes(conn, session["world_id"], repos.PLOTS_M)}
        for o in [o for o in omens if o["key"] not in have | self._writing]:
            self._writing.add(o["key"])
            self.later(lambda o=o: self._alone(path, self._disaster_lore, session["world_id"], session["id"], rows["seed"], rows["era"]["era"], o))

    def _disaster_lore(self, conn, world_id: str, session_id: str, seed: str, era_now: str, o: dict) -> None:
        self._fixed_lore(conn, world_id, session_id, newdisasters, o["key"], lambda: _disaster_slot(conn, world_id, seed, era_now, o),
                         lambda slot: _disaster_name(conn, world_id, self.rulebook.plots, era_now, o))

    def _war_lore(self, conn, world_id: str, session_id: str, seed: str, era_now: str, o: dict) -> None:
        self._fixed_lore(conn, world_id, session_id, newwars, o["key"], lambda: _war_slot(conn, world_id, seed, era_now, o),
                         lambda slot: _war_name(conn, world_id, self.rulebook.plots, slot, o))

    def _fixed_lore(self, conn, world_id: str, session_id: str, mod, key: str, make, name) -> None:
        """模型寫一場天災或一條戰時事端（mod＝newdisasters、newwars）：三段照事端的叫法（newplots.PARTS），沒過的欄重寫、
        最多叫 3 次，還不過的用通用句（天災第 6 題甲）。放的時刻先到了的已經用通用句放了，不再存。"""
        try:
            slot, got = make(), {}
            for group in self._groups():
                part, need = group[-1], [x for p in group for x in mod.asks(slot, p)]
                for _ in range(3):
                    todo = [x for x in need if x["key"] not in got]
                    if not todo:
                        break
                    g = self._ask(conn, session_id, "plot", part, lambda: self.narrator.bits("plot", mod.brief(slot, part), todo))
                    bad = {k: r for p in group for k, r in mod.faults(slot, p, g or {}, slot["era"]).items()}
                    got |= {k: v for k, v in (g or {}).items() if k not in bad and k in {x["key"] for x in todo}}
            with transaction(conn):
                have = {mod.key_of(plot_mod.parse(t["body"])) for t in repos.list_themes(conn, world_id, repos.PLOTS_M)}
                if key not in have:
                    repos.insert_theme(conn, world_id, mod.record(slot, got, name(slot)), repos.PLOTS_M)
        finally:
            self._writing.discard(key)

    def _front(self, conn, session: dict, rows: dict, o: dict, now: int, skip: set[str]) -> None:
        """主角在打仗的邊境州（第十一節第 3、5 題甲）：放這一年的戰時事端，時間線從現在算；模型還沒寫好用通用句拼一份。
        家園被點名的先挑那村鎮的凡人（跟現成的徵兵一樣）。"""
        world_id = session["world_id"]
        t = next((t for t in self.plots if newwars.key_of(t) == o["key"]), None)
        if not t:
            slot = _war_slot(conn, world_id, rows["seed"], rows["era"]["era"], o)
            r = newwars.record(slot, {}, _war_name(conn, world_id, self.rulebook.plots, slot, o))
            repos.insert_theme(conn, world_id, r, repos.PLOTS_M)
            t = plot_mod.parse(r["body"])
        town = next(l for l in rows["locations"] if l["name"] == o["town"])
        draft = o.get("want") or {p["name"]: (plot_mod.VICTIM,) for p in rows["npcs"] if newwars.kind_of(t) == "家園"
                                  and p["status"] == "ALIVE" and p["realm_lv"] == 0 and space.town_of(rows["locations"], p["location"]) == o["town"]}
        plots.place(conn, world_id, random.Random(f"{rows['seed']}:front:{o['key']}"), [], {**town, "want": draft, "first": list(o.get("want", ()))},
                    now, _system_npc, skip=skip, fixed=t)   # 歸鄉回來的人沒職業也能演（first）

    def _enlist(self, conn, session: dict, rows: dict, fronts: list[dict]) -> None:
        """這一年還沒寫的戰時事端交給背景寫（相鄰州的也先寫）；寫好之前主角先到了，_front 先用通用句放。"""
        path = conn.execute("PRAGMA database_list").fetchone()["file"]
        have = {newwars.key_of(plot_mod.parse(t["body"])) for t in repos.list_themes(conn, session["world_id"], repos.PLOTS_M)}
        for o in [o for o in fronts if o["key"] not in have | self._writing]:
            self._writing.add(o["key"])
            self.later(lambda o=o: self._alone(path, self._war_lore, session["world_id"], session["id"], rows["seed"], rows["era"]["era"], o))

    def _lore(self, conn, world_id: str, session_id: str, seed: str, era_now: str, states: list[str], n: int,
              kind: str = "legend") -> None:
        """第 128 系列乙：模型寫 n 篇都市傳說（kind＝tale：規則怪談，第二批），綁這幾州（plan 擲判定欄、組骨架）；
        一篇一篇寫（_write），不過就不要，不手寫補（第 5 題甲）。第一批只有古代；每個世界各最多 MAX_PER_WORLD 篇。"""
        mod, table = {"legend": (newlegends, repos.LEGENDS_W), "tale": (newtales, repos.TALES_W)}[kind]
        mine = repos.list_themes(conn, world_id, table)
        n = min(n, mod.MAX_PER_WORLD - len(mine))
        if era_now != era.ANCIENT or n <= 0 or not states:
            return
        atlas_ = repos.get_atlas(conn, world_id)
        taken = {t["name"] for t in mine} | {l["name"] for l in repos.list_locations(conn, world_id)}
        kept = []
        for slot in mod.plan(random.Random(f"{seed}:{kind}s:{len(mine)}"), atlas_["seed"], states, n):
            if r := self._write(conn, session_id, kind, mod, slot, lambda part, got: mod.review(part, slot, got, taken, kept, era_now),
                                lambda got: mod.faults(slot, got, era_now)):
                kept.append(r)
        with transaction(conn):
            for r in kept:
                repos.insert_theme(conn, world_id, r, table)

    def _write(self, conn, session_id: str, kind: str, mod, slot: dict, review, faults) -> dict | None:
        """一篇分三段叫（句型組守則第 6 題甲、再次設計第 4 題甲）：故事（story）、小段（bits）、是非題（judge）。
        故事、小段各最多叫 3 次，還不過整篇不要（再次設計第 5 題甲）；小段逐欄重寫（faults 逐欄查，過了的留在 draft），
        是非題答錯：故事欄錯了重寫故事，小段錯了只重寫那幾欄。"""
        got, left, draft = {}, {"story": 3, "bits": 3}, {}
        while True:
            part = next((p for p in left if p not in got), "judge")
            if part == "judge":
                if self.big:   # 是非題是讓 9b 自己核對故事；大模型照 review、faults 把關就好（2026-11-23）
                    return mod.record(slot, got)
                qs = mod.questions(slot, got)
                answers = self._ask(conn, session_id, kind, part, lambda: self.narrator.judge(qs))
                if answers is None:
                    return None
                wrong = [q for q, a in zip(qs, answers.values()) if (a == YES) != q["want"]]
                if not wrong:
                    return mod.record(slot, got)
                if any(q["part"] == "story" for q in wrong):
                    got.pop("story")
                if any(q["part"] == "bits" for q in wrong):
                    draft = {k: v for k, v in got.pop("bits").items() if k not in {q["key"] for q in wrong}}
                continue
            if not left[part]:
                return None
            left[part] -= 1
            todo = [x for x in mod.asks(slot, {**got, "bits": draft}) if x["key"] not in draft] if part == "bits" else []
            ask = (lambda: self.narrator.story(kind, slot)) if part == "story" else (lambda: self.narrator.bits(kind, slot, todo))
            g = self._ask(conn, session_id, kind, part, ask)
            if g is None:
                continue
            g = {**draft, **g} if part == "bits" else g
            if not review(part, {**got, part: g}):
                got[part], draft = g, {} if part == "bits" else draft
            elif part == "bits":
                bad = faults({**got, part: g})
                draft = {k: v for k, v in g.items() if k not in bad}

    def _ask(self, conn, session_id: str, kind: str, part: str, invoke) -> dict | None:
        """叫一段，記 ai_calls（outcome＝哪一段）；模型失敗回傳 None。"""
        try:
            got, call = self._call_ai(conn, session_id, 0, kind, invoke, outcome=part)
        except UpstreamError:
            return None
        with transaction(conn):
            repos.insert_ai_call(conn, call)
        return got.items[0]

    def _ask_twice(self, conn, session_id: str, kind: str, slots: list[dict], ask, keep) -> list[dict]:
        """物品：模型一次寫一批，沒過的重叫一次，再不過就算了（第 128-4 題乙）；模型失敗也一樣。
        keep(slot, 輸出, 已收下的)：合格回傳要存的，不然回傳假值。"""
        kept = []
        for _ in range(2):
            if not slots:
                break
            try:
                got, call = self._call_ai(conn, session_id, 0, kind, lambda: ask(slots))
            except UpstreamError:
                break
            miss = []
            for slot, g in zip(slots, got.items):
                r = keep(slot, g, kept)
                if r:
                    kept.append(r)
                else:
                    miss.append(slot)
            call.update(warnings=[f"{kind}_rejected_{len(miss)}_of_{len(slots)}"] if miss else [])
            with transaction(conn):
                repos.insert_ai_call(conn, call)
            slots = miss
        return kept

    def _advance_world_for_new_life(self, conn, user_id: str, world_id: str, span: str | None) -> int:
        world = repos.get_world_for_user(conn, world_id, user_id)
        if not world:
            raise NotFound("找不到這個世界。", code="world_not_found")
        if world["kind"] == world_mod.IMMORTAL:
            raise Conflict("仙域只能破空飛升進去。", code="immortal_world")
        past = repos.list_sessions_in_world(conn, world_id)
        if any(s["phase"] in repos.ACTIVE_PHASES for s in past):
            raise Conflict("這個世界還有進行中的一局，結束後才能開始下一生。", code="world_busy")
        if not past:
            return world["clock_shichen"]
        if span not in world_mod.SPANS:
            raise BadRequest(f"請選擇時間跨度：{'、'.join(s.label for s in world_mod.SPANS.values())}。",
                             code="invalid_span")
        # 種子＝世界種子＋第幾生：同一世界的同一次轉生，跳躍年數固定，不能靠重送刷年數
        # 16l 第 7-1 題：有人從這裡飛升過，仙域過了多久就回流多少（天上一日，地上一年），跟原本的跳躍取較大值
        clock_now = world["clock_shichen"] + max(world_mod.jump_shichen(
            random.Random(f"{world['rng_seed']}:jump:{len(past)}"), span), realms.backflow(conn, user_id, world_id))
        repos.set_world_clock(conn, world_id, clock_now)
        card = _era_card(conn, world_id, world["rng_seed"])   # 跳過的歲月跨過門檻就換時代（第 16e 節）
        _lapse(conn, world_id, world["rng_seed"], world["clock_shichen"], clock_now, card["era"])   # 勢力存續、改朝換代（第 8-2 批）
        _write_era(conn, world_id, card, _next_era(card, world["rng_seed"], clock_now, lambda: factions.era_lean(
            repos.list_factions(conn, world_id), [r for r in repos.list_book(conn, "reasons", world_id) if not r["session_id"]],
            repos.get_pressure(conn, world_id), card, clock_now)))
        return clock_now

    def list_worlds(self, conn, user_id: str) -> list[dict]:
        return [{"id": w["id"], "name": w["name"], "kind": w["kind"], "clock": clock.describe(w["clock_shichen"]),
                 "lives": w["lives"], "activeSessionId": w["active_session_id"],
                 "canStartLife": w["active_session_id"] is None}
                for w in repos.list_worlds(conn, user_id)]

    def list_sessions(self, conn, user_id: str) -> list[dict]:
        return [self._public_session(s) for s in repos.list_sessions(conn, user_id)]

    def require_session(self, conn, user_id: str, session_id: str) -> dict:
        session = repos.get_session_for_user(conn, session_id, user_id)
        if not session:
            raise NotFound("找不到這個存檔。", code="session_not_found")
        return session

    def get_state(self, conn, user_id: str, session_id: str, *, turn: dict | None = None,
                  replayed: bool = False) -> dict:
        """畫面需要的一切。turn：剛完成（或重送）的回合，一併回傳。"""
        session = self.require_session(conn, user_id, session_id)
        sheet = load_sheet(conn, session_id)
        turns = repos.recent_turns(conn, session_id, 20)
        rows = _world_rows(conn, session["world_id"], session_id)
        lives = [s["id"] for s in repos.list_sessions_in_world(conn, session["world_id"])]
        now = session["clock_shichen"]
        threads = repos.list_threads(conn, session["world_id"])
        view = people.people_view(rows, sheet["location"], now, turns[-1]["delta"].get("focus", "") if turns else "",
                                  routes.seat(rows, sheet)) if sheet else []
        shown = talks.cards(rows, view, now, identity.own_name(sheet), threads, session_id) if sheet else {}   # 人物卡（9e-4）
        state = {
            "session": self._public_session(session),
            "character": _character_view(rows, turns[-1:], sheet, now, session_id) if sheet else None,
            "turns": [self._public_turn(t, rows) for t in turns],
            "choices": turns[-1]["choices"] if turns else [],
            "choiceTags": turns[-1]["choice_tags"] if turns else [],
            "world": _public_world(rows),
            "map": _map_view(rows, sheet, now) if sheet else None,
            "items": {**items.panel(sheet, _place(rows, sheet["location"]).get("type", ""), rows["era"]["era"],
                                    _shop_extra(rows, sheet["location"]), _surge(rows, sheet["location"], now),
                                    rows["new_items"]),
                      # 衙署可繳罰金（16e.1）
                      "fine": identity.fine(sheet, now) if _place(rows, sheet["location"]).get("type") == identity.COURT
                      else 0} if sheet else None,
            "crafts": crafting.panel(sheet) if sheet else None,   # 可煉丹、可煉器（第 3b-3 步）
            # 日常面板（16m 第 2 題）：修練、營生、靜養的時長，這裡能做哪些營生、工錢
            "routine": daily.panel(_place(rows, sheet["location"]).get("type", ""), sheet["realm_lv"], sheet["standoff"],
                                   rows["era"], {laws.system_of(n) for n in sheet["insight"]}) if sheet else None,
            "domain": zones.panel(rows, sheet, session_id) if sheet else None,   # 領域守則（第 19-1 步）
            # 與天道的對局（第 18-2a 步）：只列這一生已分勝負的（作廢的宿敵之局不列）
            "heavenGames": [games.line(g, _year_season(g["ended_shichen"])) for g in _my_games(rows, session_id)
                            if g["result"] in (games.WIN, games.LOSE)],
            "birthplaces": [] if sheet else region.birthplaces(rows["locations"], rows["atlas"]),   # 建角時可選的出生地
            "origins": {} if sheet else {**origins.options(rows["era"]["era"]),     # 建角時可選的身分、命途（16g）、姓氏來歷、氣質（16u）
                                         "surnameFrom": home.SOURCES, "moods": looks.MOODS,
                                         "lookCard": rows["era"]["era"] == era.ANCIENT},
            "people": view + _undead_view(rows, sheet["location"], now) if sheet else [],
            "cards": shown,
            "asks": favours.view(rows, sheet) if sheet else {},   # 在場又欠你恩的人 → 討人情的選項（16v 第 110 題）
            "chronicle": memory_book.chronicle(
                session_id=session_id, notes=rows["memories"], threads=threads,
                npcs=rows["npcs"], protagonist_lifespan=character_mod.lifespan(sheet), clock_now=now, route=route_mod.label(sheet["route"]),
            ) if sheet else None,
            "chart": routes.chart(rows, sheet, now, session["phase"] == ENDED) if sheet else None,   # 命盤（第 129-7 題）
            "ties": people.ties_view(rows),
            "knownGoals": background.known_goals(rows),
            "acquaintances": background.acquaintances(rows, session_id),
            "worldMeta": {"id": rows["world"]["id"], "name": rows["world"]["name"], "kind": rows["world"]["kind"],
                          "clock": clock.describe(rows["world"]["clock_shichen"]), "era": era.text(rows["era"]),
                          "lives": len(lives), "lifeNo": lives.index(session_id) + 1},
            "lord": _lord_view(conn, session, rows, sheet, now) if sheet and sheet["sect_rank"] == sect.LORD else None,
        }
        if turn is not None:
            state = {"turn": self._public_turn(turn, rows), "replayed": replayed, **state}
            if sheet and not replayed:   # 回合結束時在場的人記下這張卡（9e-4-1）
                with transaction(conn):
                    talks.remember(conn, session["world_id"], session_id, rows, view, shown,
                                   memory_book.date_label(now), sheet["location"])
        return state

    # ── 建角 ──────────────────────────────────────────────────────────────
    def create_character(self, conn, user_id: str, session_id: str, body: dict) -> dict:
        session = self.require_session(conn, user_id, session_id)
        if session["phase"] != NEED_CHARACTER:
            raise Conflict("這一局已經建立過角色。", code="character_exists")
        # 凡人身分（16g）：照開世界時的時代；玩家挑的優先，沒挑就隨機。命途不能選，下面 origins.draw 擲（第 6-2 批）
        era_now = (repos.get_era(conn, session["world_id"]) or era.DEFAULT)["era"]
        origin = origins.pick(_rng(session, "origin"), era_now, body.get("origin"))
        # 支系（第 5 步；16k 三族）：沒選就依權重，用這一局的種子（重送結果一樣）；種族決定生在哪一州
        line = self.pick_lineage(_rng(session, "lineage"), body.get("lineage"))
        sheet = character_mod.create_sheet(
            _rng(session, "character"),
            name=body.get("name", ""), gender=body.get("gender", ""), background=body.get("background", ""),
            clock_now=session["clock_shichen"], appearance=body.get("appearance", ""),
            location=_birthplace(conn, session, body.get("birthplace"), origins.born_types(origin),
                                 lineage.LINEAGES[line].race),
        )
        sheet = lineage.assign(_rng(session, "lineage-roots"), sheet, line, body.get("extraAttribute"))
        # 諸天異端開局就有天道注視（第 18-1 步）；從建角起算待在凡人多久（第一次突破也看快慢，2026-10-06 使用者選甲）
        sheet = {**sheet, **heaven.fields(sheet["heretic"]), "realm_since": session["clock_shichen"]}
        # 出身奴隸（16k）：沒指定身分時擲（他族生在敵對族的地盤比較高）
        if not body.get("origin") and _rng(session, "slave").random() < self.slave_chance(
                sheet["race"], people.land_race(conn, session["world_id"], sheet["location"])):
            origin = origins.SLAVE
        sheet = origins.draw(_rng(session, "fate"), home.surname(origins.apply(sheet, origin), body.get("surname")))
        sheet = learn.of_me(_rng(session, "learn"), sheet, era_now)   # 學識（第 7-1c 批）
        if era_now == era.ANCIENT:   # 搭配卡（16u 外貌）：現代、未來的身分和衣著不同，先只有古代
            sheet = {**sheet, "look": looks.card(_rng(session, "look"), gender=sheet["gender"], minor=True,
                                                 origin=sheet["origin"], race=sheet["race"], picks=body)}
        # 落腳處與家人（第 19 步）：出生地底下的家級子地點，主角從這裡開場；舊世界（沒有生成區域）沒有
        # 奴隸沒有家人：開局押在坊市，買主與他的宅子先安排好
        self._vetted(conn, session, {"背景": sheet["background"], "外貌": sheet["appearance"],
                                     **{k: str(body.get(f) or "")[:looks.MAX_PICK] for k, f in LOOK_PICKS.items()}})
        sheet, place, family = (_sold(conn, session, sheet) if origin is origins.SLAVE
                                else _settle_home(conn, session, sheet, body, origin))
        with transaction(conn):
            repos.transition_phase(conn, session_id, from_phase=NEED_CHARACTER, to_phase=NEED_OPENING)
            repos.upsert_character(conn, session_id, sheet)
            if place:
                repos.insert_location(conn, session["world_id"], "", place)
                repos.insert_connection(conn, session["world_id"], "", {
                    "a": place["parent"], "b": place["name"], "tier": space.NEAR,
                    "distance_km": space.DISTANCE_TIERS[space.NEAR], "discovered_turn": 0})
            for p in family:   # 家人先登錄，事端的人和他們的家人取名才會避開
                repos.insert_npc(conn, session["world_id"], session_id, p)
                if p["created_by"] == home.FAMILY_BY:   # 奴隸的主人照初見的規則
                    hits, grudge = home.relation(sheet)
                    repos.upsert_relation(conn, session["world_id"], p["name"], session_id,
                                          people.fresh(p, p["name"], session["clock_shichen"], hits, grudge=grudge))
                elif place:   # 奴隸的主人一家住他的宅子（121-1）
                    people.settle_family(conn, session["world_id"], p, place["parent"], session["clock_shichen"], home=place["name"])
            for b in home.ties(family, session_id, session["clock_shichen"]):
                repos.insert_bond(conn, session["world_id"], session_id, b)
            if place:   # 家鄉的事端（現代未來照時代挑模板，第 8-6 批）
                newplots.use(repos.list_themes(conn, session["world_id"], repos.PLOTS_M))   # 這裡還沒讀過世界資料
                plots.ensure(conn, session["world_id"], _rng(session, "plot-near"), self.plots, place["parent"],
                             session["clock_shichen"], _system_npc)
            _ensure_place(conn, session["world_id"], sheet["location"])
        return self.get_state(conn, user_id, session_id)

    # ── 主角外貌（第 10a 步）─────────────────────────────────────────────
    @staticmethod
    def look_card(query: dict) -> dict:
        """建角時的「抽靈感」：配一張搭配卡（16u 外貌）。query 帶著玩家留下的項目，其他的重抽；建角才生效。"""
        line = lineage.LINEAGES.get(query.get("lineage", ""))
        card = looks.card(random.Random(secrets.token_hex(8)), gender=query.get("gender", ""), minor=True,
                          origin=query.get("origin", ""), race=line.race if line else "", picks=query)
        return {"card": card, "text": looks.text(card, lineage.mark({"lineage": query.get("lineage", ""), "look": card}))}

    def edit_appearance(self, conn, user_id: str, session_id: str, body: dict) -> dict:
        """玩家修改外貌（edit）、改回上一版（revert）、或看過改寫提示（seen）。外貌只是描寫，不帶來能力。"""
        session = self.require_session(conn, user_id, session_id)
        if session["phase"] not in (NEED_OPENING, PLAYING):
            raise Conflict("這一局目前不能修改外貌。", code=f"phase_{session['phase'].lower()}")
        sheet = load_sheet(conn, session_id)
        action = body.get("action")
        if action == "edit":
            text = character_mod.valid_appearance(body.get("text"))
            self._vetted(conn, session, {"外貌": text})
            sheet = character_mod.apply_appearance(sheet, text, session["clock_shichen"], by_player=True)
        elif action == "revert":
            if not sheet["appearance_prev"]:
                raise Conflict("沒有上一版的外貌可以改回。", code="no_previous_appearance")
            sheet = character_mod.apply_appearance(sheet, sheet["appearance_prev"], session["clock_shichen"],
                                                   by_player=True)
        elif action == "seen":
            sheet = {**sheet, "appearance_changed": False}
        else:
            raise BadRequest("action 只能是 edit、revert、seen。", code="invalid_action")
        with transaction(conn):
            repos.upsert_character(conn, session_id, sheet)
        return self.get_state(conn, user_id, session_id)

    def set_alias(self, conn, user_id: str, session_id: str, body: dict) -> dict:
        """化名（16e.1）：不算回合；name 空＝用回本名。不能和已知的人、地方同名。"""
        session = self.require_session(conn, user_id, session_id)
        if session["phase"] != PLAYING:
            raise Conflict("這一局目前不能改化名。", code=f"phase_{session['phase'].lower()}")
        world_id = session["world_id"]
        taken = {p["name"] for p in repos.list_npcs(conn, world_id)} | {l["name"] for l in repos.list_locations(conn, world_id)}
        sheet = identity.set_alias(load_sheet(conn, session_id), body.get("name", ""), taken)
        with transaction(conn):
            repos.upsert_character(conn, session_id, sheet)
        return self.get_state(conn, user_id, session_id)

    # ── 物品（第 8 步）───────────────────────────────────────────────────
    def use_items(self, conn, user_id: str, session_id: str, body: dict) -> dict:
        """買、賣、服用丹藥：不算回合、不花時間、不呼叫 AI。做過的事記在角色卡，下一回合交給說書人。"""
        session = self.require_session(conn, user_id, session_id)
        if session["phase"] != PLAYING:
            raise Conflict("這一局目前不能買賣或使用物品。", code=f"phase_{session['phase'].lower()}")
        sheet = load_sheet(conn, session_id)
        rid = str(body.get("requestId") or "")[:64]   # 重送同一個就不重做（小修清單第 1 題）
        if rid and rid == sheet["item_request"]:
            return self.get_state(conn, user_id, session_id)
        rows = _world_rows(conn, session["world_id"], session_id)
        place_type, era_now = _place(rows, sheet["location"]).get("type", ""), rows["era"]["era"]
        action, name, tier = body.get("action"), body.get("item"), body.get("tier")
        money = era.MONEY[era_now]
        if action == "buy":   # 黑市可能買到假貨（16i）
            fake = place_type in market.TYPES and _rng(session, f"fake:{rid}", session["turn_no"]).random() < market.FAKE
            sheet = items.buy(sheet, place_type, name, tier, body.get("count", 1), money,
                              extra=_shop_extra(rows, sheet["location"]), fake=fake, era_now=era_now,
                              surge=_surge(rows, sheet["location"], session["clock_shichen"]))
            if not fake and any(i["name"] == body.get("aka") and i["base"] == name for i in rows["new_items"]):
                sheet = items.named(sheet, name, tier, body["aka"], body.get("count", 1))   # 貨架上的新物品（16p）
        elif action == "sell":
            sheet = items.sell(sheet, place_type, name, tier, body.get("count", 1), money, era_now)
        elif action == "exchange":                # 當鋪換錢（經濟第二輪）：to＝spirit_stones 或 money
            sheet = items.exchange(sheet, place_type, body.get("to"), body.get("count", 1), money)
        elif action == "fine":                    # 衙署繳罰金（16e.1）
            sheet, note = identity.pay(sheet, place_type, session["clock_shichen"], money)
            sheet = items.noted(sheet, note)
        elif action == "use":
            sheet, mods = items.use(sheet, name, tier, session["clock_shichen"])
            sheet, _, events = effects.gain(sheet, mods)
            sheet = items.noted(sheet, *events)   # 例如聚氣丹讓小境界提升
        elif action == "learn":                   # 修習功法＝換主修（第 3b-1 步）
            sheet = items.learn(sheet, name, tier)
        else:
            raise BadRequest("action 只能是 buy、sell、exchange、fine、use、learn。", code="invalid_action")
        with transaction(conn):
            repos.upsert_character(conn, session_id, {**sheet, "item_request": rid})
        return self.get_state(conn, user_id, session_id)

    # ── 開場 ──────────────────────────────────────────────────────────────
    def opening(self, conn, user_id: str, session_id: str, body: dict) -> dict:
        request_id = _request_id(body.get("requestId"))
        session = self.require_session(conn, user_id, session_id)
        replay = repos.get_turn_by_request(conn, session_id, request_id)
        if replay:
            return self.get_state(conn, user_id, session_id, turn=replay, replayed=True)
        if session["phase"] != NEED_OPENING:
            raise Conflict("這一局目前不能開場。", code=f"phase_{session['phase'].lower()}")
        sheet = load_sheet(conn, session_id)
        _ensure_place_now(conn, session["world_id"], sheet["location"])
        people.ensure_now(conn, session)
        here, now = sheet["location"], session["clock_shichen"]
        rows = _world_rows(conn, session["world_id"], session_id)
        routing = self.routes_on and repos.get_world(conn, session["world_id"])["kind"] != world_mod.IMMORTAL
        if routing and rows["era"]["era"] == era.ANCIENT:   # 第一條路線可能是家鄉的事端：先放進來（本來第一回合才放）
            with transaction(conn):
                ticked = plots.tick(rows, self.plots, here, now)
                fated.queue(ticked, rows, sheet, here, now, _rng(session, "fated", 0))   # 一般命開局第一章（第 116-12 題）
                plots.write(conn, session["world_id"], ticked, _rng(session, "plots", 0), self.plots, now, _system_npc, plots.mine(sheet))
            rows = _world_rows(conn, session["world_id"], session_id)
        # 背景演化：開場地點的人補算到現在（第 10b 步），世界脈動推進前世結束到現在（第 10c-1 步）。轉生跳過的歲月在這裡發生
        rows, updates = background.update_npcs(session, rows, people.present_names(rows, here), now,
                                               protagonist=sheet["name"], here=here, turn_no=0)
        last_life_end = max((life["end"] for life in rows["past_lives"]), default=now)
        rows = background.pulse(rows, updates, last_life_end, now, protagonist=sheet["name"],
                                player_lv=sheet["realm_lv"], here=here, turn_no=0, relations={}, skip=set())
        rows = background.chatter(rows, updates, background.towns(rows, here), now,
                                  known=background.known_names(rows, session_id), turn_no=0)   # 村鎮小事（第 7-2a 批）
        rows = background.reunion(rows, updates, people.present_names(rows, here), background.towns(rows, here), now,
                                  known=background.known_names(rows, session_id), here=people.present_names(rows, here), turn_no=0)   # 重逢（第 9f 批）
        z, s, r = zones.Zones(), sightings.Sightings(), rites.Rites()
        rows = zones.due(z, rows, updates, end=now, turn_no=0)   # 儀式型：跳過的歲月裡期限到了的人死在儀式裡
        rites.due(r, z, rows, updates, _rng(session, "rites", 0), start=last_life_end, end=now, here="",
                  turn_no=0, last={})   # 跳過的歲月裡流傳的玩法有人動心、出事，或被親近的人勸住、救出（19-3）
        npc_changes: dict[str, dict] = {}
        heard, heard_notes = news.hear(rows, here=here, clock_now=now, session_id=session_id, limit=news.OVERHEARD,
                                       turn_no=0)   # 傳聞（第 10c-3a 步）：轉生後聽到前人與世間的事
        updates.events += heard
        updates.notes += heard_notes
        rows, met = people.meet(rows, here, life=session_id, clock_now=now,   # 初次見面看名聲（第 10c-3b 步）
                                stranger=_stranger(rows, sheet, here, session_id, now), gap=_gap(rows, sheet, here, session_id, now), warm=origins.meet_bonus(sheet),
                                crowd=origins.crowd(sheet))
        sheet, met, past_said = rebirths.tick(rows, sheet, sheet, here=here, met=met, rested=False, now=now,
                                              rng=_rng(session, "rebirth", 0))   # 寄身借口、覺醒（第 6-6b2 批）
        rows = {**rows, "relations": {**rows["relations"], **met}}
        updates.events += past_said
        updates.notes += rebirths.recall(rows) if sheet["rebirth"]["woke"] else []
        threads = memory_mod.visible(repos.list_threads(conn, session["world_id"]), session_id)
        kin = next((p["name"] for p in people.present(rows, here) if p["created_by"] == home.FAMILY_BY), "")   # 家人一開場就開口（16v 第 65 題）
        book = _contact(rows, session, sheet, here, now, threads, focus=kin)
        # 轉生跳過的歲月（第 11-2 步）：死去的人可能變成亡者、恩怨的對象死了幽魂就安息、上一生現身的亡者隱去
        h = haunts.Haunts()
        haunts.settle(h, rows, sheet, dead=_gone_now(rows, {}, updates), told="", life=session_id,
                      protagonist=sheet["name"], clock_now=now, turn_no=0, threads=threads)
        haunts.leave(h, rows, "")
        haunts.born(h, rows, [p for p in rows["npcs"] if p["name"] in updates.dead - z.swallowed], now, life=session_id)
        # 跳過的歲月裡有沒有地方被怪談籠罩（第 19-1 步）
        zones.spawn(z, rows, _rng(session, "zone-spawn", 0), start=last_life_end, end=now,
                    here=here, s=s, r=r)
        sightings.drift(s, rows, _rng(session, "legend-drift", 0), start=last_life_end, end=now)
        sightings.ghosts(s, _rng(session, "legend-ghost", 0), rows, [p for p in rows["npcs"] if p["name"] in updates.dead],
                         now)   # 跳過的歲月裡客死異鄉的前世主角（第 19-2 步）
        task = _appearance_task(session, sheet, now, 0, rows["era"])
        fame = news.fame(rows, place=here, life=session_id, clock_now=now, name=identity.public(sheet, now))
        talk = _reputation_task(sheet, fame)
        offer = _name_offer(session, 0, rows, here)
        look = _place_task(rows, here)
        sight = _scene_task(rows, here)
        legend = _legend(rows, here, now)
        hook, lead = _hook(rows, here, now, legend, heard)   # 16m 第 12 題：開場帶到一件近處真有的事
        if routing:   # 開局第一條路線（16v）：蓋過鉤子
            sheet = fated.turn(rows, sheet)
            sheet, line, place = routes.draw(rows, sheet, z, s, _rng(session, "route", 0), here=here,
                                             place_type=_place(rows, here).get("type", ""), now=now)
            hook, lead = (line, routes.lead(rows, here, place)) if line else (hook, lead)
        said = ""
        if kin and not self.big:   # 大模型：家人不硬講那件事，開場怎麼開由它決定
            sheet, said = talks.turn(rows, self.plots, sheet, kin, _rng(session, "talk", 0), here=here, asked=True, now=now, turn_no=0)
        result = self._narrate(conn, session_id, 0, NarrationRequest(
            kind="opening", character=_character_view(rows, [], sheet, now, session_id),
            clock_label=clock.describe(now)["label"],
            facts=updates.events + ([ascent.arrival(sheet)] if repos.get_world(conn, session["world_id"])["kind"]
                                    == world_mod.IMMORTAL else [])   # 從被接引的那一刻開場（16l）
            + ([f"近處有一件事（你決定開場要不要提、怎麼提，可以只是遠遠一句風聲）：{hook}" if self.big
                else f"近處正有一件事（開場要帶到）：{hook}"] if hook else []),
            rules_text=self.rulebook.prompt_text(), realm_guide=realm.prompt_guide(sheet["realm_lv"], laws.dao(sheet)),
            sect_lore=region.sect_lore(rows["factions"], rows["bonds"], max(sheet["realm_lv"], sheet["lore_tier"])),
            place_info=_place_info(rows, here, now), contact=book.text, inspiration=_inspiration(session, 0),
            subjects=[*sorted(people.present_names(rows, here)), here],
            name_offer=offer, reputation=reputation.line(fame.levels), reputation_task=talk,
            legend=legend, plot=plots.scene_note(rows, self.plots, sheet, here), route=decks.note(sheet, 0),
            focus=people.focus_line(rows, npc_changes, kin, people.voice(rows, sheet, kin, here=here, life=session_id, clock_now=now, turn_no=0,
                                                                         fresh=kin in met)) + _said(said) if kin else "",
            # 時代（第 16e 節）：上一生之後換過時代，開場就寫「世界變了」
            era_line=era.prompt(rows["era"], changed=bool(rows["past_lives"]) and rows["era"]["since"] > last_life_end),
            era_words=tuple(era.pairs(rows["era"])), era_keep=_names(rows, rows["era"]), appearance_task=task, place_task=look, scene_task=sight,
            proposal_kinds=_proposal_kinds(rows, here, book.open_threads, task, talk, look, sight=sight, acts=self.acts),
            **_known_names(rows, here),
        ), warnings=lambda r: people.age_warnings(rows, here, now, r.narrative, sheet))
        verdicts = _review_proposals(result, sheet, rows, turn_no=0, open_threads=book.open_threads,
                                     clock_now=now, appearance_task=task, reputation_task=talk,
                                     place_prefix=offer["place_prefix"], place_task=look, scene_task=sight)
        sheet = _apply_self_texts(sheet, verdicts, now, fame=fame, here=here)
        people.apply_relation_proposals(rows, verdicts, npc_changes)   # 開場沒有事件欄，變化直接寫入
        updates.rumors += z.rumors + s.rumors + r.rumors
        care = memory_mod.ThreadUpkeep()
        notes = memory_book.turn_notes(
            protagonist=sheet["name"], before_sheet=sheet, after_sheet=sheet, verdict=None, target=None,
            npc_changes=npc_changes, relations_before=people.relations_before(rows, npc_changes),
            verdicts=verdicts, care=care, here=here, clock_now=now, turn_no=0)
        choices, tags = ((list(result.choices), list(result.choice_tags)) if self.big   # 選項過濾是因為提示管不住 9b
                         else people.here_only(*plots.hush(result.choices, result.choice_tags, rows, self.plots, sheet, here, ""), rows, here))
        turn = {
            "id": new_id("trn"), "session_id": session_id, "turn_no": 0, "request_id": request_id,
            "kind": "opening", "player_input": "", "judgment": {},
            "delta": {**({"situation": result.situation} if result.situation else {}), **({"focus": kin} if kin else {})},
            "narrative": result.narrative, "model": result.model,
            # 最後一個選項換成通往鉤子的那件事
            "choices": choices[:-1] + [lead] if lead and choices and not self.big else choices,   # 大模型不硬換成通往那件事的選項
            "choice_tags": tags[:len(choices) - 1] + [{"nature": "", "difficulty": "", "target": ""}] if lead and choices and not self.big else tags,
        }
        with transaction(conn):
            repos.transition_phase(conn, session_id, from_phase=NEED_OPENING, to_phase=PLAYING)
            repos.upsert_character(conn, session_id, sheet)
            repos.insert_turn(conn, turn)
            _write_proposals(conn, session, rows, 0, verdicts, origin=here, clock_now=now)
            _write_scene(conn, session["world_id"], rows, verdicts, task=sight, start=here)
            background.write(conn, session, updates, {}, now)
            repos.close_ledger(conn, session["world_id"], updates.dead, _heirs(rows, updates.dead))
            people.write_changes(conn, session, npc_changes, met)
            memory_book.write(conn, session, turn_no=0, clock_now=now, notes=notes, care=care, verdicts=verdicts)
            _write_relics(conn, session, [], [], updates.dead, now, kept=s.relics)   # 轉生跳過的歲月裡死去的人
            haunts.write(conn, session["world_id"], h)
            zones.write(conn, session["world_id"], z)
            sightings.write(conn, session["world_id"], s)
            rites.write(conn, session["world_id"], r)
        self._more(conn, session, rows, s, z)
        return self.get_state(conn, user_id, session_id, turn=turn)

    # ── 回合 ──────────────────────────────────────────────────────────────
    def play_turn(self, conn, user_id: str, session_id: str, body: dict) -> dict:
        request_id = _request_id(body.get("requestId"))
        try:   # 日常面板（16m 第 2 題）：換成一句行動，不經過分類
            routine = daily.action(body.get("routine"))
        except ValueError as exc:
            raise BadRequest(str(exc), code="invalid_routine") from exc
        player_input = routine[0] if routine else str(body.get("input") or "").strip()
        if not 1 <= len(player_input) <= MAX_INPUT_CHARS:
            raise BadRequest(f"行動內容需為 1 到 {MAX_INPUT_CHARS} 字。", code="invalid_input")

        session = self.require_session(conn, user_id, session_id)
        replay = repos.get_turn_by_request(conn, session_id, request_id)
        if replay:
            return self.get_state(conn, user_id, session_id, turn=replay, replayed=True)
        if session["phase"] != PLAYING:
            raise Conflict("這一局目前不能行動。", code=f"phase_{session['phase'].lower()}")

        stored = repos.get_character(conn, session_id)   # 寫入前比對：處理期間有人買賣物品就不覆蓋
        sheet = load_sheet(conn, session_id)
        if sheet["ascent"]:   # 接引法陣在等回答（16l）：這回合只能選
            return self._ascend(conn, user_id, session, sheet, stored, player_input, request_id)
        if routine and sheet["standoff"]:   # 16m 第 7 題：仇家在場時日常面板不能用
            _cannot_try(f"{sheet['standoff']}還在這裡衝著你來，先處理他（動手、交談或離開）。")
        _ensure_place_now(conn, session["world_id"], sheet["location"])
        if repos.get_atlas(conn, session["world_id"]) is None:   # 舊世界補上天下骨架（16k）
            with transaction(conn):
                _ensure_atlas(conn, session["world_id"])
        people.ensure_now(conn, session)
        turn_no, now = session["turn_no"] + 1, session["clock_shichen"]
        world = repos.get_world(conn, session["world_id"])
        up = world["kind"] == world_mod.IMMORTAL
        if up:   # 仙域（16l B4）：你沒在玩的時候仙域照樣在走（其他主角、下界流進來的時間），這一局跟上
            now = max(now, world["clock_shichen"])
        with transaction(conn):   # 仙域的百日演進；下界看本山的上宗有沒有覆滅（16l C1）；仙域的遭遇（C3a）
            realms.tick(conn, session, up)
            clash = realms.encounter(conn, session, sheet, now, _rng(session, "clash", turn_no)) if up else ""
            sheet, back = realms.resume(conn, session, sheet, now) if up else (sheet, [])   # 換玩化身：補算交情（D1b）
            sheet, bout_facts = realms.contest_turn(conn, session, sheet, player_input, now,   # 仙戰（C4b）
                                                    _rng(session, "contest", turn_no)) if up else (sheet, [])
            bout_facts = back + bout_facts
        rows = _world_rows(conn, session["world_id"], session_id)
        avatars = realms.avatars(conn, session, sheet, now) if up else {}   # 仙域裡其他主角的化身（16l D1）
        rows = {**rows, "npcs": rows["npcs"] + [p for _, p, _ in avatars.values()],   # 化身的宗門也放進來（算戰功、D2）
                "bonds": rows["bonds"] + [sect.member_bond(n, s) for n, (_, _, s) in avatars.items() if s]}
        atlas_was, pressure_was = rows["atlas"], rows["pressure"]
        # 初次見面看名聲（第 10c-3b 步）：上回合才登場的人；回合結束時所在地的人在敘事前再看一次
        rows, met = people.meet(rows, sheet["location"], life=session_id, clock_now=now, kin=_kin(rows, sheet),
                                stranger=_stranger(rows, sheet, sheet["location"], session_id, now),
                                gap=_gap(rows, sheet, sheet["location"], session_id, now), warm=origins.meet_bonus(sheet),
                                crowd=origins.crowd(sheet))
        recent = repos.recent_turns(conn, session_id, BIG_RECENT_TURNS if self.big else RECENT_TURNS_FOR_PROMPT)
        tag = _choice_tag(recent[-1:], player_input)
        last = recent[-1]["delta"] if recent else {}
        rows = {**rows, "told": recent[-1]["narrative"] if recent else ""}   # 上一回合的敘事：提過的地方算小地方（第 9g 批）
        waiting = [] if routine else replies.offers(rows, sheet, last, now)   # 等你回話的選項（3-4a）
        threads = memory_mod.visible(repos.list_threads(conn, session["world_id"]), session_id)
        ask = None if routine else favours.asking(rows, sheet, player_input, now)   # 討人情、還債不用判定（16v 第 110 題）
        read = None if routine or ask else self._take(conn, session, sheet, player_input, turn_no, rows, tag,
                                                      pending=bool(last.get("incident")),
                                                      with_whom=last.get("focus") or last.get("left", ""),
                                                      answer=None if body.get("answer") is None else str(body["answer"]), offers=waiting,
                                                      looks=darks.clues(sheet, turn_no), tasks=sides.tasks(threads),
                                                      pasts=rebirths.offers(rows, sheet, [p["name"] for p in people.present(rows, sheet["location"])]))
        reply = replies.answer(waiting, player_input, read.reply if read else "", bool(read) and read.source == "read")   # 種類 → 交給它的字
        trade = read.deal if read and read.source == "read" else None   # 3-4d：讀懂的買賣找人；舊鏈 None，照舊看字表
        ask = ask or (None if routine else favours.asking(rows, sheet, reply("人情"), now))   # 打字讀出來的討人情、還債（3-4a）
        intent = _work_here(judgment.intent_for(routine[1], player_input, source="routine") if routine
                            else dataclasses.replace(judgment.intent_for(judgment.SOCIAL, player_input), targets=(), target_npc=ask[0]) if ask
                            else read, rows, sheet, player_input)
        job = effects.JOBS[effects.job(player_input)] if intent.nature == judgment.WORK else None   # 營生（16o；打字第 8 題：打字也算）
        intent = _craft_recipe(_study_law(intent, sheet, player_input, _scene(
            rows, sheet, _place(rows, sheet["location"]).get("type", ""), sheet["location"], now,
            laws.tags(intent.nature, player_input, effects.is_retreat(intent.nature, player_input), sheet["status"] == "DYING"))),
            sheet, player_input)
        # 領域（第 19-1 步）：被本體追著還想離開＝脫身判定；上回合犯規引來的東西要應對
        intent, zone_power = zones.facing(rows, sheet, intent, last, session_id)
        if zone_power is not None:   # 16l 第 6-5 題：領域裡雙方都不算境界差（本體改用難度表現）
            zone_power = sheet["realm_lv"]
        else:   # 都市傳說的本體追殺（第 19-2 步）
            intent, zone_power = sightings.facing(rows, intent, session_id)
        haunt = haunts.facing(rows, sheet, intent.nature, player_input)   # 對現身的亡者動手、交談（第 11-2 步）
        blocked = intent.blocked
        intent = intent if haunt else people.attach_target(intent, rows, sheet, player_input, tag.get("target", ""))
        if intent.blocked != blocked:   # 16m 第 3 題：找不到對象，快速回覆
            _cannot_try(f"{intent.blocked}。")
        if not haunt and zone_power is None and intent.source != "read":   # 沒點名：衝著眼前的人（故事第 2 題）；有事要應對時，問話也算應對（第 3 題）；讀懂已經填了對誰
            answering = (last.get("incident") or {}).get("answer") or sheet["standoff"]
            intent = intent if answering else judgment.chat(intent, player_input)
            intent = people.aim(intent, rows, sheet["location"], people.waiting(last, rows, sheet["location"]), player_input)
        if sheet["contest"] and sheet["contest"]["foe"] and intent.nature == judgment.COMBAT and not intent.target_npc:
            intent = dataclasses.replace(intent, target_npc=sheet["contest"]["foe"])   # 仙戰：出手就是迎戰這一輪的對手
        target = people.find(rows, intent.target_npc) if intent.target_npc else None
        relation = people.relation(rows, intent.target_npc) if target else None
        threat = bool(target) and npc_mod.threatens(player_input)   # 威脅他：畏懼你就答應（第 121-10 題）
        awed = threat and npc_mod.dread(relation, target, sheet["realm_lv"]) == npc_mod.AWED
        opponent = (judgment.Opponent(target["realm_lv"], relation["affinity"], awed=awed) if target
                    else judgment.Opponent(undead.power(haunt, now), 0) if haunt
                    else judgment.Opponent(zone_power, 0) if zone_power is not None else None)
        intent = _staked(intent, player_input, target, relation, tuple(e["name"] for e in sheet["items"]))   # 3-5：說服、套話、偷東西看要的有多大
        tried = rebirths.attempt(rows, sheet, intent, player_input, target)   # 說出前世的事、拿出信物：擲信不信（第 6-6b1 批）
        if tried:
            intent = dataclasses.replace(intent, nature=judgment.SOCIAL, targets=(judgment.PERSUADE,), difficulty=tried[2])
        ctx = _breakthrough_ctx(rows, recent[-1:], sheet, now)
        gear = items.gear(sheet, player_input, rows["era"]["era"], rows["perks"])   # 法器帶著就有效、點名的符籙用掉一張（第 8 步）
        town = space.town_of(rows["locations"], sheet["location"])
        nook = spot_mod.make(_rng(session, "spot", turn_no), intent.destination, town, _place(rows, town).get("type", ""), now, turn_no) \
            if intent.spot else None   # 走進提過的小地方（第 9g 批）：照它的類型查探
        place_type = nook["type"] if nook else _place(rows, sheet["location"]).get("type", "")
        law_points, law_used = laws.action_bonus(sheet, intent.nature, player_input)   # 借用持有的法則（第 3b-1 步）
        zone_law = zones.law_here(rows, sheet, session_id)   # 領域裡只能靠技能：加倍、跟怪談同系的歸零（16l 第 6-5 題）
        if law_used and zone_law is not None:
            law_points = 0 if law_used == zone_law else law_points * domains.LAW_FACTOR
        if intent.nature in judgment.CRAFTS:   # 熟練度、地點、火系／金系（第 3b-3 步）
            law_points = crafting.bonus(sheet, intent.nature, place_type)
            law_points += sect.room_bonus(sheet, intent.nature, _place(rows, sheet["location"]))   # 丹房、煉器閣（16h）
        # 入門考核（16h）：上門拜入、應對收徒的事件、比武選拔期間在武館戰鬥；有靈根 +10
        exam = sect.exam(rows["factions"], place=sheet["location"], action=intent.nature, words=player_input,
                         last=last.get("incident"), tourney=any(s["name"] == sect.TOURNEY for s in
                                                                incidents.states_here(rows, sheet["location"], now)))
        law_points += sect.ROOT_BONUS if exam and sheet["roots"] else 0
        law_points += paths.exam(sheet, _hall_path(rows, exam)) if exam else 0   # 拜入不同道統的宗門
        law_points += learn.bonus(sheet, nature=intent.nature, words=player_input, target=target,   # 學識（第 7-1c 批）：考核、查典故、對讀書人講道理
                                  persuade=judgment.PERSUADE in intent.targets, exam=bool(exam))
        law_points += party.bonus(sheet, rows["npcs"]) if intent.nature == judgment.COMBAT else 0   # 同伴一起打（16i）
        ghosts = intent.nature == judgment.COMBAT and (haunt or zone_power is not None)   # 對亡者、怪談
        law_points += round(paths.bonus(sheet, intent.nature) + (paths.bonus(sheet, paths.GHOST) if ghosts else 0))   # 道統
        sky = _sky(rows, now, sheet["location"])   # 天氣（16j）：雨霧好藏身難辨向、大雪暴雨趕路慢、修煉的修為加減；室內不受影響
        if intent.travel and weather.slow(sky, place_type) > 1:
            intent = dataclasses.replace(intent, travel=round(intent.travel * weather.slow(sky, place_type)))
        gate = intent.destination and not avoid.detour(player_input) and not avoid.forcing(player_input) \
            and _border(rows, sheet["location"], intent.destination)
        if gate:   # 16m 第 9 題：封閉的邊關前先停下，讓玩家選硬闖或繞道
            to = intent.destination
            _cannot_try(f"去{to}要經過{gate[0]}與{gate[1]}交戰的邊關，邊關已經封閉。",
                        (f"硬闖邊關前往{to}", f"繞道前往{to}"))
        detour = bool(intent.travel) and avoid.detour(player_input)   # 繞路（16l 第 6-3 題）：多花一半時間
        if detour:
            intent = dataclasses.replace(intent, travel=round(intent.travel * avoid.DETOUR))
        disasters = _woes(rows, sheet["location"], now)   # 此地的天災、天變（16j）
        qi = weather.qi(sky, place_type) * disaster.qi(disasters) * bondage.qi(sheet) \
            * (1 + paths.bonus(sheet, paths.QI)) * truth.qi(sheet) \
            * origins.retreat(sheet, effects.is_retreat(intent.nature, player_input))   # 當爐鼎被採補（16k）；道觀；地氣讀一（第 6-5c 批）、閉關（6-5d）
        law_points += disaster.looting(disasters, player_input)   # 趁火打劫
        if opponent:   # 準備（16l 第 6-2 題）：此地有佈局、用上破境道具，各讓境界差少算一級；偷襲在 judgment 裡看
            opponent = dataclasses.replace(opponent, breaker=gear.breaker,
                                           prep=prep.laid(rows["place_states"], sheet["location"], now) + gear.breaker)
        spoils_rng = _rng(session, "spoils", turn_no)
        plain = bool(plots.current(rows, self.plots, sheet["location"]))   # 有事端的地方探索查的是線索（16t）
        seen_here = _scene(rows, sheet, place_type, sheet["location"], now,   # 參悟的在場加成（第 3b-1 步第二批）
                           laws.tags(intent.nature, player_input, effects.is_retreat(intent.nature, player_input), sheet["status"] == "DYING")
                           | {t for t, on in (("怪談", zone_power is not None), ("亡者", haunt), ("事端", plain)) if on})
        lucky = not plain and items.lucky_find(spoils_rng, place_type)   # 第 8b 步
        sights = scene_mod.of(_place(rows, sheet["location"]))   # 眼前的環境物（16r）
        touched = [] if routine else scene_mod.hits(sights, player_input)
        before = recent[-1]["judgment"] if recent else {}   # 待接（第 6-5d 批）：孤星逢凶事、寄身對亡者鬼神、渡壽救人、礪上一次失敗
        law_points += origins.moment(sheet, woe=bool(disasters), ghost=bool(haunt) or zone_power is not None,
                                     saving=bool(target) and any(w in player_input for w in truth.SAVE),
                                     failed=bool(before.get("rolled")) and before.get("outcome") in (judgment.FAILURE, judgment.GREAT_FAILURE))
        verdict = judgment.judge(_rng(session, "turn", turn_no), sheet, intent, ctx,
                                 danger=_place(rows, sheet["location"]).get("danger", ""),
                                 opponent=opponent, bonus={t: gear.bonus.get(t, 0) + law_points + weather.bonus(sky, place_type).get(t, 0)
                                        + scene_mod.bonus(touched).get(t, 0) + origins.check_bonus(sheet).get(t, 0) + truth.checks(sheet).get(t, 0)   # 命途（第 6-2 批）、真相分法（第 6-5c 批）
                                        for t in judgment.TARGET_ATTRS})
        delta = effects.apply(sheet, verdict, player_input=player_input, clock_before=now, guard=gear.guard,
                              found_item=lucky, place_type=place_type, qi=qi, plain=plain, bleed=origins.bleed(sheet), here=seen_here)
        used_sights = scene_mod.used(touched, {c.target for c in verdict.all_checks})
        if used_sights:
            delta.events.insert(0, f"利用了{'、'.join(f['name'] for f in used_sights)}")
        if law_used and verdict.rolled:
            delta.events.insert(0, f"{law_used}之力被此地的怪談吞沒了" if law_used == zone_law
                                else f"借用了{law_used}{laws.held(sheet)[law_used]}之力")
        trap = None if verdict.action_type == judgment.COMBAT \
            else prep.lay(sheet["location"], player_input, now)   # 佈局（16l 第 6-2 題）：當場交手不算
        if trap:
            delta.events.append(prep.EVENT)
        # 找上門（第 10c-2a 步）：閉關途中有人帶著敵意找上門 → 閉關停在他到的那一刻，修為依實際閉關的時間算
        busy = {intent.target_npc} - {""}
        who = identity.public(sheet, now)   # 對外的名字（16e.1）：這回合的傳聞、名聲、通緝都記在這個名字上
        # 越出名越難藏身（第 10c-3b 步）：看你在那裡的名聲
        boost = reputation.find_boost(news.fame(rows, place=delta.sheet["location"], life=session_id,
                                                clock_now=now, name=who).levels)
        leverage = deeds.leverage(rows, session_id)   # 抽到要脅、拿你把柄來要錢的人（第 1-5d 批；第 7-2b 批起照做法牌）
        foe = background.hostile_visit(rows, protagonist=sheet["name"], here=delta.sheet["location"], start=now,
                                       end=now + delta.clock_advance, boost=boost, alias=identity.own_name(sheet),
                                       hurt=sheet["hp"] * 2 < sheet["hp_max"], blackmail=set(leverage),
                                       skip=busy | visitors.spared(sheet, now) | {sheet["standoff"]})   # 16m 第 7 題
        if foe and identity.disguised(sheet, now) and people.find(rows, foe.name)["realm_lv"] <= sheet["disguise"]["tier"]:
            foe = None   # 易容中：境界不高於丹藥品階的人找不到你
        if foe and avoid.hiding(verdict, player_input):   # 避風頭（16l 第 6-3 題）
            delta.events.append(f"避開了找上門的{foe.name}")
            foe = None
        foe, warned = favours.warn(rows, foe, now + delta.clock_advance)   # 報信（第 4-10-1 題）：這回合先不到
        retreating = effects.is_retreat(verdict.action_type, player_input)
        if foe and retreating:
            delta = effects.apply(sheet, verdict, player_input=player_input, clock_before=now, cut_short=foe.when - now,
                                  guard=gear.guard, found_item=lucky, place_type=place_type, qi=qi, plain=plain, bleed=origins.bleed(sheet), here=seen_here)
            if verdict.action_type == judgment.CULTIVATE and \
                    _rng(session, "deviation", turn_no).random() < effects.DEVIATION_CHANCE * (1 - paths.bonus(sheet, paths.CALM)) * races.DEVIATION.get(
                        sheet["race"], 1):   # 魔族加倍（16k）
                effects.deviate(delta, now + delta.clock_advance)   # 閉關修煉被打斷，走火入魔（小修清單第 4 題）
        # 亡者現身（第 11-2 步）：有人找上門就不現身；閉關途中現身，閉關停在那一刻（與找上門相同）
        h = haunts.Haunts()
        rose = None if foe else haunts.rise(h, rows, delta.sheet["location"], rng=_rng(session, "undead-rise", turn_no),
                                            action=verdict.action_type, retreating=retreating,
                                            clock_now=now + delta.clock_advance, boost=origins.undead_boost(sheet))
        if rose and retreating:
            delta = effects.apply(sheet, verdict, player_input=player_input, clock_before=now, guard=gear.guard,
                                  cut_short=_rng(session, "undead-when", turn_no).randint(1, max(1, delta.clock_advance)),
                                  found_item=lucky, place_type=place_type, qi=qi, plain=plain, bleed=origins.bleed(sheet), here=seen_here)
        # 途中遭遇（16n 第 16 題）：日常面板照時長擲一次，遇上就停在途中某一刻，事件在下面照常挑
        waylaid = bool(routine or job) and not (foe or rose) and sheet["status"] == "ALIVE" and _rng(
            session, "routine-met", turn_no).random() < incident.routine_chance(
            delta.clock_advance / clock.SHICHEN_PER_MONTH, job.monthly if job else incident.ROUTINE_MONTHLY)
        if waylaid:
            delta = effects.apply(sheet, verdict, player_input=player_input, clock_before=now, guard=gear.guard,
                                  cut_short=_rng(session, "routine-when", turn_no).randint(1, max(1, delta.clock_advance)),
                                  found_item=lucky, place_type=place_type, qi=qi, plain=plain, bleed=origins.bleed(sheet), here=seen_here)
        if rose:   # 真相分法（第 6-5c 批）：寄身讀一被借了身；礪對命主、渡壽讀二救人
            delta.sheet = haunts.possess(delta.sheet, _rng(session, "possess", turn_no), now + delta.clock_advance)
        delta.sheet = truth.after(delta.sheet, target=intent.target_npc, rolled=verdict.rolled, success=verdict.is_success,
                                  words=player_input)
        if job:   # 工錢、時長算完了，之後的紀錄與敘事都用這個時代的叫法（16o 第 6 題）
            player_input = era.job_text(player_input, rows["era"])
            delta.events[:] = [era.job_text(e, rows["era"]) for e in delta.events]
        delta.sheet, item_facts = _spend_items(sheet, delta.sheet, verdict, gear, ctx)
        if verdict.action_type == judgment.BREAKTHROUGH and verdict.rolled:   # 衝到下一個範圍，這個範圍的章當放著收掉（第 6-4-2 題甲）
            delta.sheet = route_mod.settle(delta.sheet, sheet["realm_lv"])
        delta.events[:0] = bout_facts + item_facts   # 仙戰的報名、對手（C4b）在最前面
        delta.sheet = character_mod.flag_appearance(sheet, delta.sheet)   # 突破、瀕死會讓外貌改寫（第 10a 步）
        new_clock = now + delta.clock_advance
        rows = _breach_turn(session, turn_no, rows, delta, ctx, start=now, end=new_clock)   # 破格期（16l）
        if delta.sheet["realm_lv"] == ascent.LV > sheet["realm_lv"] and not up:   # 破空：接引法陣降下（16l）
            delta.sheet = _ascent_offers(conn, session, rows, delta.sheet, turn_no)
            delta.events.append(ascent.text(delta.sheet["ascent"]["offers"]))
        # 房租（經濟第二輪）：這回合跨過幾個月就付幾個月，欠滿三個月被趕走；住在門派裡不付（16h）
        months = new_clock // clock.SHICHEN_PER_MONTH - now // clock.SHICHEN_PER_MONTH
        delta.sheet, rent_events = home.pay_rent(delta.sheet, 0 if sheet["sect"] else months, _money(rows))
        delta.events += rent_events
        # 時代演進（第 16e 節）：這回合跨過門檻，說書人這回合就寫「世界變了」；地名在交易最後才改（下回合起看到新名字）
        long = delta.clock_advance >= era.LONG   # 一般回合到門檻順延（125-12、第 8-1 批）
        shift = _next_era(rows["era"], rows["seed"], new_clock, lambda: factions.era_lean(
            rows["factions"], rows.get("npc_reasons", []), rows["pressure"], rows["era"], new_clock), long)
        npc_changes: dict[str, dict] = {}   # 這回合對 NPC 的改變：name → {"state": ..., "relation": ...}
        if target:
            state, relation, npc_events = npc_mod.consequences(
                target["name"], [(c.target, c.outcome) for c in verdict.all_checks],
                {"condition": target["condition"], "status": target["status"]}, relation, threat)
            if target["name"] in avatars:   # 對化身出手最多重傷（16l D2）
                state, npc_events = avatar.spare(target["name"], state, npc_events)
            npc_changes[target["name"]] = {"state": state, "relation": relation}
            delta.events.extend(npc_events)
            if tried and state["status"] == "ALIVE":   # 信了相認、沒信記說過了（第 6-6b1 批）
                delta.sheet, npc_changes[target["name"]]["relation"], said = rebirths.settle(delta.sheet, rows, tried, relation, verdict.is_success)
                delta.events += said
        if haunt:
            delta.sheet = haunts.fight(h, haunt, verdict, delta.sheet, spoils_rng, protagonist=sheet["name"],
                                       life=session_id, here=haunt["place"], clock_now=new_clock, turn_no=turn_no,
                                       threads=threads, bearer=haunts.bearer(rows, haunt, {p["name"] for p in rows["npcs"] if p["status"] != "ALIVE"}),
                                       in_plot=haunts.plotted(rows, haunt))
        # 亡者守著的地方，遺物要等他消散或安息之後才找得到
        unguarded = [r for r in rows["relics"] if not undead.here(rows["undead"], r["place"])
                     and not sightings.guards(rows, r)]   # 客死異鄉的傳說還在：他守著自己的遺物（第 19-2 步）
        delta.sheet, found, taken = _spoils(spoils_rng, delta.sheet, verdict, lucky, target, npc_changes, unguarded,
                                            new_clock, rows["new_items"])
        delta.events.extend(found)
        for _ in range(round(delta.clock_advance / clock.SHICHEN_PER_MONTH) if job and job.herb else 0):
            if spoils_rng.random() < job.herb:   # 採藥（16o）：每個月兩成採到一份靈材
                delta.sheet, fact = items.find(spoils_rng, delta.sheet, rows["new_items"])
                delta.events.append(fact)
        if disaster.beast_core(disasters, place_type, verdict):   # 妖獸潮期間野外打贏（16j）
            delta.sheet, fact = items.grant(spoils_rng, delta.sheet, "妖丹", sheet["realm_lv"], world=rows["new_items"])
            delta.events.append(f"斬殺妖獸，{fact}")
        # 黑市與奴隸商人（16i）：可能把主角擋在門外、趕出來，所以在定下 here 之前
        rows, found_new = _market_turn(session, turn_no, rows, sheet, delta, verdict, words=player_input,
                                       clock_now=new_clock, deal=trade)
        delta.sheet, bond_events = _bondage_turn(rows, delta.sheet, verdict, player_input, trade)   # 出身奴隸（16k）
        delta.events += bond_events
        # 上回合留下的應對型事件（第 9a 步）：行動類型對得上才結算，對不上＝放過
        here = delta.sheet["location"]
        if nook and here == nook["name"]:   # 小地方這回合就在世界裡：寫描述、挑遭遇照它（交易裡才寫進資料庫）
            rows = {**rows, "locations": rows["locations"] + [nook]}
        rows, opened = _open_state(rows, session, here)   # 第一次到某州的主城：生成那一州（16k）
        settled = incidents.settle(last, verdict, delta.sheet, rows, npc_changes, _rng(session, "incident-settle", turn_no),
                                   here=here, clock_now=new_clock, turn_no=turn_no, player_input=reply("天道"),
                                   hurt=sum(max(0, c["from"] - c["to"]) for c in delta.changes if c["field"] == "hp"))
        delta.sheet = settled.sheet
        delta.changes += settled.changes
        delta.events += settled.events
        delta.marks += settled.marks
        hall_was = delta.sheet["sect"]   # 差事違誓、記過除名（C5a）也在仙域回合裡離宗
        writes = _realm_turn(conn, session, turn_no, rows, delta, verdict, target, npc_changes, words=player_input,
                             here=here, clock_now=now) if up else {}   # 仙域（16l）：交易裡寫回骨架的東西
        if writes.get("found"):   # 剛立的宗（C4d）：勢力在交易最後才登錄，這回合先算它在（宗門的回合才不會當它不在了）
            rows = {**rows, "factions": rows["factions"] + [{"name": writes["found"]["sect"]["name"], "type": "宗門",
                                                             "location": here, "traits": {}}]}
        delta.sheet, sect_events = _sect_turn(session, turn_no, rows, delta.sheet, verdict, exam=exam,
                                              words=player_input, here=here, months=months, clock_now=new_clock,
                                              merit_ranks=merit.RANKS if up else None, lord_pay=writes.get("pay", 0),
                                              bar=(recruit.problem(repos.get_immortal(conn, session["user_id"]) or {"sects": []},
                                                                   delta.sheet, exam) if up and exam else "")
                                              or paths.problem(delta.sheet, _hall_path(rows, exam)))
        delta.events += sect_events
        if hall_was and delta.sheet["sect"] != hall_was and delta.sheet["sect_oath"]:   # 立了誓的人離宗＝叛宗（C4c）
            alive = any(s["name"] == hall_was for s in (repos.get_immortal(conn, session["user_id"]) or {"sects": []})["sects"])
            delta.sheet, broke, marks = oath_mod.broken(delta.sheet, hall_was, new_clock) if alive \
                else ({**delta.sheet, "sect_oath": None}, [], [])   # 仙宗覆滅了不算背誓
            delta.events += broke
            delta.marks += marks
        delta.sheet, took_path = paths.sync(sheet, delta.sheet, _hall_path(rows, delta.sheet["sect"]),
                                            _master_path(rows, sheet))   # 道統：照所屬宗門、沒宗門照師父
        delta.events += took_path
        delta.sheet = _party_turn(session, turn_no, rows, delta, verdict, target, npc_changes, opponent,
                                  words=player_input, here=here, clock_now=new_clock)
        auc = _auction_turn(session, turn_no, rows, delta, verdict, npc_changes, threads, words=player_input, here=here,
                            retreating=retreating, clock_now=new_clock, deal=trade)   # 拍賣會（16i 批次三）
        found_new["npcs"] += auc.npcs
        rows = _with_new(rows, session, {"npcs": auc.npcs})
        helped = _relief(rows, delta, verdict, target, npc_changes, disasters, words=player_input, here=here, who=who,
                         life=session_id, clock_now=new_clock)   # 救災（16j）
        # 天道的棋局（第 18-2a 步）：上回合落的子分勝負、衝關就是渡劫；寫進 rows["games"]，交易裡再比對寫入
        games_before = rows["games"]
        rows, reveal = _play_games(rows, session_id, settled.game, verdict, new_clock, turn_no)
        # 善意的訪客（報恩、追隨、守約）不打斷閉關，在這回合結束那一刻才到
        friend, kept = background.friendly_visit(rows, threads, protagonist=sheet["name"], here=here, start=now,
                                                 end=new_clock, skip=busy | ({foe.name} if foe else set()),
                                                 events=delta.events, boost=boost)
        guests = [] if delta.fallen else [v for v in (foe, friend) if v]
        if clash and not delta.fallen and clash not in busy | {v.name for v in guests}:   # 仙域遇上敵盟的人（16l C3a）
            guests.append(visitors.Visit(clash, visitors.FOE, now))
        # 背景演化（一回合一次）：抵達處的人＋打聽的對象補算到回合結束（第 10b 步），再推進世界脈動（第 10c-1 步）
        # 16k：走進另一州時，那一州的人一次補算；遠方州（不是所在州或相鄰州）的人不跟著世界脈動走
        far, entered = _far(rows, sheet["location"], here)
        names = (people.present_names(rows, here) | entered | {intent.inquiry_npc} - {""}) \
            - memory_book.dead_this_turn(npc_changes)
        changed = {n: c["relation"] for n, c in npc_changes.items() if "relation" in c}
        rows, updates = background.update_npcs(session, rows, names, new_clock, protagonist=sheet["name"],
                                               here=here, turn_no=turn_no, relations=changed)
        rows = background.pulse(rows, updates, now, new_clock, protagonist=sheet["name"],
                                player_lv=delta.sheet["realm_lv"], here=here, turn_no=turn_no,
                                relations=changed,
                                skip=set(npc_changes) | {v.name for v in guests} | far | set(avatars))   # 化身不跟著脈動
        asked = next((p["location"] for p in rows["npcs"] if p["name"] == intent.inquiry_npc), "")
        rows = background.chatter(rows, updates, background.towns(rows, here, asked), new_clock,
                                  known=background.known_names(rows, session_id), turn_no=turn_no)   # 你到的、打聽的那處（第 7-2a 批）
        rows = background.reunion(rows, updates, names, background.towns(rows, here, asked), new_clock,
                                  known=background.known_names(rows, session_id), here=people.present_names(rows, here),
                                  turn_no=turn_no)   # 重逢補抽人物層牌（第 9f 批）
        delta.sheet, done = deeds.turn(rows, updates, delta.sheet, self.plots, start=now, end=new_clock, turn_no=turn_no,
                                       skip=set(npc_changes) | {v.name for v in guests} | people.present_names(rows, here))   # 不在場的人對你的做法（第 7-2b 批）
        updates.events += done + gathers.answer(rows, updates, reply("聚"), now=new_clock, turn_no=turn_no)   # 回拜把子（第 7-5a 批）
        updates.rumors += helped
        delta.sheet = _faced(rows, updates, npc_changes, delta.sheet, self.plots, here=here, turn_no=turn_no, now=new_clock)   # 他的章以你為命主（第 122c 批）
        delta.sheet, ran = _runaway(rows, delta.sheet, updates, here=here, who=who, clock_now=new_clock)   # 逃奴（16k）
        delta.events += ran
        planned = newdisasters.placed(rows["plots"], self.plots)   # 放了前兆的天災（第九節天災）
        rows, woes = _disaster_turn(session, turn_no, rows, updates, start=now, end=new_clock, here=here, sheet=delta.sheet,
                                    planned=planned)   # 天災（16j）
        rows, spot_here = local.turn(rows, updates, [t for _, _, ts in _scopes(rows, here) for t in ts], start=now, end=new_clock, here=here,
                                     turn_no=turn_no, skip=set(npc_changes) | people.present_names(rows, here) | {v.name for v in guests},
                                     woes=lambda town, t: _woes(rows, town, t))   # 地方壓力每月、地方牌（第 7-3a 批）
        rows, spot_faction = factions.turn(rows, updates, [t for _, _, ts in _scopes(rows, here) for t in ts], start=now, end=new_clock,
                                           here=here, turn_no=turn_no, skip=set(npc_changes) | set(avatars), life=session_id)   # 聲勢、立約、勢力牌（第 7-3b1a 批）；life：沒入勢力也要算嫁禍
        rows, delta.sheet = _fated(session, turn_no, rows, delta.sheet, npc_changes, start=now, end=new_clock, here=here)   # 真相分法（第 6-5c 批）
        rows = _statecraft(rows, updates, start=now, end=new_clock,   # 國與國（16k）
                           skip=set(party.names(delta.sheet)) | {sheet["name"]})
        delta.sheet, aid, bounty = _proxy(session, turn_no, rows, updates, delta.sheet, verdict, target, relation,
                                          player_input, here=here, start=now, end=new_clock, deal=trade)   # 借刀、懸賞（16l）
        delta.events += aid
        delta.sheet, sick = disaster.infect(_rng(session, "plague", turn_no), delta.sheet,
                                            _woes(rows, here, new_clock), new_clock)
        delta.events += [sick] if sick else []
        # 前期領域（第 19 步）：儀式型的期限、流傳的玩法（19-3）、怪談與都市傳說的出現、傳說移動
        z, s, r = zones.Zones(), sightings.Sightings(), rites.Rites()
        rows = zones.due(z, rows, updates, end=new_clock, turn_no=turn_no)
        rites.due(r, z, rows, updates, _rng(session, "rites", turn_no), start=now, end=new_clock, here=here,
                  turn_no=turn_no, last=last)
        zones.spawn(z, rows, _rng(session, "zone-spawn", turn_no), start=now, end=new_clock,
                    here=here, s=s, r=r)
        sightings.drift(s, rows, _rng(session, "legend-drift", turn_no), start=now, end=new_clock)
        delta.events.extend(updates.events)
        for visit in guests:   # 訪客移到你身邊；帶敵意的可能偷襲
            moved = background.arrive(rows, updates, visit, here=here, protagonist=sheet["name"], turn_no=turn_no)
            if moved is None:
                continue
            rows = moved
            cut = max(1, round((visit.when - now) / clock.SHICHEN_PER_MONTH)) if visit.hostile and retreating else 0
            delta.events.append(background.visit_event(visit, interrupted_months=cut, doing=(
                judgment.WORK if verdict.action_type == judgment.WORK else "閉關")))
            if visit.reason == visitors.BLACKMAIL:
                delta.events += favours.blackmail(rows, npc_changes, visit.name, leverage[visit.name], new_clock)
            if visit.hostile:
                delta.sheet, hurt, events = background.ambush(rows, visit, delta.sheet, retreating=retreating)
                delta.changes += hurt
                delta.events += events
        foe_was, owe_ctx = delta.sheet["standoff"], {"me": who, "life": session_id, "here": here, "turn_no": turn_no}   # 人情帳（16v 第 87 題）
        paid = favours.redeem(rows, delta.sheet, ask, npc_changes, new_clock, updates, owe_ctx) if ask else favours.Paid(delta.sheet)
        delta.sheet, delta.events = paid.sheet, delta.events + paid.events
        if warned:   # 報信：仇家晚幾天才到，那筆帳用掉
            line, name, until, used = warned
            delta.sheet = {**delta.sheet, "spared": {**delta.sheet["spared"], name: until}}
            delta.events.append(line)
            updates.settled.append(used)
        _standoff(rows, updates, delta, verdict, target, guests, start=sheet["location"], here=here, clock_now=new_clock)
        delta.sheet, saved, foe_new = favours.rescue(rows, sheet, delta.sheet, npc_changes, new_clock)   # 遇險時欠你大恩的人出手
        delta.events += saved
        for foe_gone in {foe_was if foe_was and not paid.sheet["standoff"] else "", foe_new} - {""}:   # 替你打發走的仇家離開此地
            away = _next_place(rows, here)
            if away:
                updates.fields.setdefault(foe_gone, {}).update(location=away)
        known = people.inquiry(rows, intent, verdict, target, npc_changes, updates, delta.events,
                               protagonist=sheet["name"], clock_now=new_clock, turn_no=turn_no)
        delta.events += _meddle(rows, updates, npc_changes, verdict, target, intent, delta.sheet,
                                here=here, life=session_id, now=new_clock)   # 挑撥撮合調停、套話勢力（第 7-3b1b2 批）
        # 宿敵之局（第 18-2b 步）：找上門、偷襲之後才看勝負；roles＝這回合要改的天道角色（交易裡最後寫）
        rows, rival, roles = _judge_rival(rows, session_id, sheet, delta.sheet, target, npc_changes, new_clock, turn_no)
        if rival in (games.WIN, games.LOSE):
            rival_name = next(iter(roles))
            delta.events.append(f"與{rival_name}之間的恩怨暫告一段落")
            reveal = "；".join(x for x in (reveal, games.reveal(games.RIVAL, rival, rival_name)) if x)
        if rival == games.WIN:
            delta.sheet, mods, won, marks = games.reward(delta.sheet, _rng(session, "rival-win", turn_no), games.RIVAL)
            delta.sheet, changes, gained = effects.gain(delta.sheet, mods)
            delta.changes += changes
            delta.events += won + gained
            delta.marks += marks
        # 線頭維護（逾期、對象死亡、主角殞落、擱置）在敘事前做：失約的後果要能寫進這回合的事實
        care, threads = _upkeep_threads(session, rows, threads, here, new_clock, npc_changes, delta.fallen,
                                        updates.dead, kept=kept)
        delta.events.extend(care.events)
        # 幽魂的執念了結了沒、主角離開了的亡者隱去（第 11-2 步）
        told = target["name"] if target and verdict.action_type == judgment.SOCIAL and verdict.is_success else ""
        delta.sheet = haunts.settle(h, rows, delta.sheet, dead=_gone_now(rows, npc_changes, updates), told=told,
                                    life=session_id, protagonist=sheet["name"], clock_now=new_clock, turn_no=turn_no,
                                    threads=threads, rite=haunts.rite_at(player_input, verdict.action_type, here))
        haunts.leave(h, rows, here)
        for place, push in h.pushes:   # 聞冥：幽魂安息時那地方的人心（第 6-5c 批）
            rows = {**rows, "pressure": pressure.apply(rows["pressure"], space.town_of(rows["locations"], place), [push], new_clock, "自從幽魂安息之後")}
        delta.events.extend(h.events)
        # 前期領域（第 19-1 步）：進出、守則、犯規、情境、破解
        delta.sheet = zones.play(z, rows, delta.sheet, life=session_id, before=sheet["location"], verdict=verdict,
                                 player_input=player_input, last=last, clock_now=new_clock,
                                 rng=_rng(session, "zone", turn_no), target=target["name"] if target else "",
                                 rested=h.rested, gone={i for i, u in h.changed.items() if u["condition"] == undead.GONE},
                                 npc_changes=npc_changes, threads=threads, turn_no=turn_no, protagonist=sheet["name"],
                                 quiet=bool(rose))
        delta.changes += z.changes
        delta.events.extend(z.events)
        delta.marks += z.marks
        # 都市傳說（第 19-2 步）：應對、追殺、了結、碰上
        delta.sheet = sightings.play(s, rows, delta.sheet, life=session_id, before=sheet["location"], verdict=verdict,
                                     player_input=player_input, last=last, clock_now=new_clock,
                                     rng=_rng(session, "legend", turn_no), target=target["name"] if target else "",
                                     threads=threads, turn_no=turn_no, protagonist=sheet["name"],
                                     quiet=bool(rose or z.scene or z.record or r.scene))
        delta.changes += s.changes
        delta.events.extend(s.events)
        # 流傳的玩法（19-3）：當夜怎麼收尾、找源頭與斷根、勸住或拿走道具、打聽
        delta.sheet = rites.play(r, z, rows, delta.sheet, life=session_id, verdict=verdict,
                                 target=target["name"] if target else "", text=player_input, last=last,
                                 clock_now=new_clock, rng=_rng(session, "rite", turn_no), npc_changes=npc_changes,
                                 updates=updates)
        delta.events.extend(r.events)
        # 傳聞（第 10c-3a 步）：順耳聽到，或主動打聽消息時聽得更多
        heard, heard_notes = news.hear(rows, here=here, clock_now=new_clock, session_id=session_id,
                                       limit=news.limit_for(intent, verdict), turn_no=turn_no)   # heard 是旁支事實，下面跟痕跡一起排
        updates.notes += heard_notes
        steer = news.point(rows, here=here, clock_now=new_clock, session_id=session_id, asked=target["name"] if target else "") \
            if news.limit_for(intent, verdict) > news.OVERHEARD else ("", "")   # 圈外的事指路（第 9b 批）
        heard += [f"指路：{steer[0]}"] if steer[0] else []
        # 新人物登場；同一回合已有人登場或找上門就不抽事件，事件需要新面孔時由事件安排登場（第 9a 步）
        dead = memory_book.dead_this_turn(npc_changes)
        # 事端（16t）：不管玩家在不在都照時間走；玩家在這個村鎮才看得到
        ticked = plots.tick(rows, self.plots, here, new_clock, killed=dead,
                            sheet=delta.sheet)   # ticked.news 是旁支事實
        if self.routes_on and rows["era"]["era"] == era.ANCIENT:   # 一般命該開章：回合結束時放（第 116c 批）
            fated.queue(ticked, rows, delta.sheet, here, new_clock, _rng(session, "fated", turn_no))
        # 眼前的人（故事第 2 題）：先定人再寫；隔了一天以上就不算還在面對面
        was = last.get("focus", "") if new_clock - now < clock.SHICHEN_PER_DAY else ""
        looking = people.seeking(verdict.action_type, player_input)
        focus = people.facing(rows, here, player_input, target=target["name"] if target else "", dead=dead,
                              guests=[v.name for v in guests], last=was, looking=looking, job=passer.asked_for(player_input) if looking else "")
        gone = people.find(rows, was) if was not in people.present_names(rows, here) | dead else None
        parted = gone["name"] if gone and gone["status"] == "ALIVE" and here == sheet["location"] else ""
        if parted:
            delta.events.append(f"{parted}離開這裡，往{gone['location']}去了")
        if focus and here == sheet["location"] and FOLLOW.search(player_input):
            delta.events.append(f"{focus}沒有要離開，你們還在原處")
        paying = side.paying(player_input) if trade is None else trade == "付錢"
        delta.sheet, skip, blocks, blocked = darks.held(rows, self.plots, delta.sheet, updates, _rng(session, "dark-held", turn_no), here=here,
                                                        focus=focus, verdict=verdict, paying=paying, now=new_clock)   # 被對手動過的門路（第 5-3 批）
        delta.sheet, found = plots.search(rows, self.plots, delta.sheet, here, focus, verdict, new_clock, skip)   # 查線索（16t）
        delta.events += blocks + found
        delta.changes += blocked
        delta.sheet, point = plots.turning_point(rows, self.plots, delta.sheet, here, focus, verdict, player_input,
                                                 ticked, new_clock)   # 玩家做到了就改變事端（16t 第 5 題）
        delta.sheet, gains = plots.pay(rows, ticked, delta.sheet, npc_changes, point[0] if point else "",
                                      _rng(session, "plot-pay", turn_no), new_clock)   # 轉折的結果欄算在你身上的（第 4-11-7 題）
        delta.events += gains
        # 轉折的回合不再安排別的事：事情一多，說書人會把誰做了什麼寫混（真模型實測）
        delta.events += point
        small = [] if point else plots.small(rows, self.plots, delta.sheet, here, _rng(session, "plot-small", turn_no))   # 旁支事實
        settled_here = focus or plots.current(rows, self.plots, here)   # 有人在說話、事端的人都安排好了，不再來新面孔
        back = passer.found(delta.sheet["passers"], here, player_input, passer.asked_for(player_input), new_clock, turn_no) \
            if looking and not focus else None   # 問路人名字、或再回來找他：當場登錄（第 9-18 題）
        enrol = _enrol(session, turn_no, rows, delta.sheet, here, back) if back else None
        delta.sheet = {**delta.sheet, "passers": [q for q in delta.sheet["passers"] if q != back]} if enrol else delta.sheet
        face = enrol or (None if settled_here else _arrival(session, turn_no, rows, verdict, delta.sheet, here, dead=dead))   # 候選（第 2-1b 批）
        # 在凡人面前施展修為被看見（第 16e 節第 6 題）：隱世＝怪事傳聞＋曝光度；打壓＝國法的施法被見（16h）
        here_type = _place(rows, here).get("type", "")
        seen = "" if delta.fallen else era.spotted(_rng(session, "era-spot", turn_no), rows["era"],
                                                   action=verdict.action_type, place_type=here_type,
                                                   realm_lv=delta.sheet["realm_lv"])
        if seen:
            updates.rumors += [rumors.make(rumors.ODD, who, place=here, when=new_clock)] if seen == era.HIDDEN else []
            delta.events.append("施展修為的樣子被凡人看見了")
        delta.sheet, rows, flipped, provoked = _crime_and_exposure(
            session, turn_no, rows, sheet, delta, updates, verdict, target, npc_changes, who=who, seen=seen, here=here,
            player_input=player_input, clock_now=new_clock)
        # 通緝 2 級起，待在這一國的城鎮、坊市可能有追捕者找上門（已經有人在追你就不再派；亂世減半）
        law = _law(rows, here)
        level = 0 if delta.sheet["status"] != "ALIVE" or market.papered(delta.sheet, new_clock) else identity.hunted(
            _rng(session, "hunt", turn_no), delta.sheet, new_clock, here_type, nation=(law or {}).get("name", ""),
            rate=crime.hunt_rate(crime.traits_of(law)))
        chaser = identity.public(delta.sheet, new_clock)
        hunter = None   # 追兵：急的候選（第 2-1b 批）
        if level and not any(p["status"] == "ALIVE" and p["goal"] == "復仇" and p["goal_target"] == chaser
                             for p in rows["npcs"]):
            hunter = era.hunter(_rng(session, "era-hunter", turn_no), delta.sheet["realm_lv"] + (level >= 3),
                                  protagonist=chaser, place=here, place_type=here_type, taken=_taken(rows, delta.sheet),
                                  land=people.local_race(rows, here))
        # 宗門派人（16h）：重叛的追殺（哪裡都可能找上門）、護短的門派來討公道；已經有宗門的人在找你就不再派
        # 拍賣買來的人留下當僕人：出身的勢力派人來搶（16i 批次三，沿用同一套）
        send = "" if delta.sheet["status"] != "ALIVE" or hunter else \
            provoked or sect.hunted(_rng(session, "sect-hunt", turn_no), delta.sheet, new_clock)
        fetch, kept = ("", "") if send or delta.sheet["status"] != "ALIVE" or hunter else \
            auction.fetch(_rng(session, "fetch", turn_no), delta.sheet, rows["factions"])
        if (send or fetch) and not any(p["status"] == "ALIVE" and p["created_by"] == sect.HUNTER_BY
                                       and p["goal_target"] == sheet["name"] for p in rows["npcs"]):
            errand = (f"是{fetch}派來帶回{kept}的人" if fetch else f"是{send}派來討公道的人" if provoked
                      else f"是{send}派來追殺叛徒的人")
            hunter = era.hunter(_rng(session, "sect-hunter", turn_no), delta.sheet["realm_lv"] + 1,
                                  protagonist=sheet["name"], place=here, place_type=here_type,
                                  taken=_taken(rows, delta.sheet), by=sect.HUNTER_BY, errand=errand,
                                  land=people.local_race(rows, here))
        # 被宗門派來的人打成瀕死：廢掉本門功法（16h 第 4 題）
        beaten = {foe.name if foe else "", target["name"] if target else ""}
        if sheet["status"] == "ALIVE" and delta.sheet["status"] == "DYING" and any(
                p["name"] in beaten and p["created_by"] == sect.HUNTER_BY for p in rows["npcs"]):
            delta.sheet, fact = sect.cripple(delta.sheet)
            delta.events += [fact] if fact else []
        happening = incidents.Happening(None, "；".join(x for x in (undead.scene(rose, new_clock) if rose else "", z.scene, s.scene,
                                                                   r.scene) if x))
        # 亡者現身（第 11-2 步）、領域上演情境或引來規則之物（第 19-1 步）、儀式的當夜（19-3）是危險，已經拿走這回合
        busy_here = point or plain and _rng(session, "plot-other", turn_no).random() >= plot_mod.OTHER_SHARE   # 有事端的地方通用事件變少（第 6 題）
        move = drawn = None   # 天道落子、事件：候選（第 2-1b 批），挑中才落實
        if not (delta.fallen or busy_here):
            move = _heaven_move(session, turn_no, rows, delta.sheet, verdict.action_type, retreating, new_clock)
            if not (move and move.kind == games.RIVAL):
                trip = _trip_km(rows, sheet["location"], here)
                strolled = verdict.action_type == judgment.MOVE and not trip   # 村裡走動不算趕路，沒有路上的事
                drawn = incidents.draw(_rng(session, "incident", turn_no), rows, sheet=delta.sheet, here=here,
                                       action=judgment.OBSERVE if strolled else verdict.action_type,
                                       retreating=retreating, last=last,
                                       clock_now=new_clock, taken=_taken(rows, delta.sheet), dead=dead, move=move,
                                       trip_km=trip,
                                       boost={} if detour else disaster.beasts(_woes(rows, here, new_clock)),
                                       odds=(1.0 if waylaid else 0.0) if routine else None,
                                       only=job.kind if job else "")   # 走鏢、打獵有自己的事件（16o）
        event = None if move or not drawn else drawn.record
        spots = [schedule.here(kind, turn_no, urgent) for kind, urgent, ok in (
            (schedule.HUNT, True, hunter), (schedule.HEAVEN, True, move), (schedule.FACE, False, face),   # 同級照這個順序：有人登場就不出事件（第 9a 步）
            (schedule.EVENT, waylaid, event)) if ok]   # 途中遭遇已經停在途中那一刻，算急
        new_threads = list(settled.threads) + auc.threads
        delta.sheet, form_facts, spread = _form_turn(session, turn_no, rows, sheet, delta.sheet, verdict, here, player_input, dead,
                                                    npc_changes, new_clock)
        delta.events += form_facts
        rows = {**rows, "place_states": rows["place_states"] + [spread]} if spread else rows
        walk, trail, deal, shade = routes.Walk(delta.sheet), leads.Trail(delta.sheet), decks.Deal(delta.sheet), darks.Shade(delta.sheet)   # 路線、線頭、牌組、暗線（16v）
        came, quest = None, sides.Task(delta.sheet)   # 這回合回來的舊事（16v 第 95 題）、支線（第 76 題）
        spot = reading.picked(read.look, read.task) if read and read.source == "read" \
            else lambda detail: self._spot(conn, session_id, turn_no, player_input, detail)   # noqa: E731  3-4b：讀懂挑的那件，不再問模型
        room = len(memory_mod.sides(threads)) < memory_mod.MAX_SIDE
        answer = schedule.answering(sheet, last, turn_no)   # 回應的回合不插新主事（第 2-1b 批）
        danger = bool(guests or rose or z.scene or s.scene or r.scene or point or delta.fallen)
        asks, due, hints = [], None, []
        gone = frozenset(p["name"] for p in rows["npcs"] if p["status"] != "ALIVE") | dead   # 不在人世的人：他的回音收掉（第 2-2 批）
        if self.routes_on and not up and not delta.fallen:
            quest = sides.turn(rows, delta.sheet, threads, care, verdict, _rng(session, "side", turn_no), updates, text=player_input, here=here, now=new_clock,
                             turn_no=turn_no, spot=spot, reply=reply("請託"), npc_changes=npc_changes,
                             pay=None if trade is None else trade == "付錢",
                             paid=delta.sheet["hp"] < sheet["hp"] or delta.sheet["money"] < sheet["money"], ctx=owe_ctx)
            delta.sheet, dunned = favours.chase(rows, quest.sheet, npc_changes, updates, owe_ctx, new_clock)   # 債到期他上門
            quest.events += dunned
            crowded = bool(guests or rose or z.scene or s.scene or r.scene or quest.scene or paid.scene or answer)   # 危險、玩家在回應的
            route_rng = _rng(session, "route", turn_no)
            walk = routes.turn(rows, delta.sheet, ticked, z, s, h, rose, route_rng, before=sheet["location"], here=here, place_type=here_type, now=new_clock,
                               turn_no=turn_no, quiet=crowded or bool(point or hunter or move or face or drawn and drawn.arranged))   # 可能有新面孔：路線的人先等
            walk.sheet = fated.turn(rows, walk.sheet, dead, self.plots)   # 一般命的章：記下、收章；交會判誰壓過
            chains.turn(walk, rows, ticked, updates, _rng(session, "chain", turn_no), here=here, now=new_clock, turn_no=turn_no, life=session_id)   # 案中案（第 5-5 批）
            trail = leads.turn(rows, self.plots, walk.sheet, heard_notes, ticked, z, s, h, before=sheet["route"], here=here, now=new_clock, turn_no=turn_no)
            standing = rank.LEVELS[people.standing(rows, trail.sheet, here, session_id, new_clock)[0]]   # 條件表「地位」（第 7-1c 批）
            deal = decks.deal({**rows, "standing": standing}, trail.sheet, verdict, _rng(session, "card", turn_no), z, s, h, moved=bool(found or point or z.moved or s.moved or quest.moved), point=bool(point),
                              here=here, before=sheet["location"], turn_no=turn_no, templates=self.plots, event=trail.touched,
                              records=_records(verdict, dead, care, helped, h), text=reply("命途"), focus=focus, npc_changes=npc_changes, now=new_clock,
                              room=room and not quest.threads, paying=paying)
            shade = darks.turn(rows, deal.sheet, ticked, z, s, h, updates, _rng(session, "dark", turn_no), templates=self.plots, verdict=verdict,
                               text=player_input, reply=reply("收買") or reply("反咬") or reply("陷阱"), spot=spot, moved=bool(found or point or z.moved or s.moved), crowded=crowded or bool(point), focus=focus,
                               here=here, now=new_clock, turn_no=turn_no, life=session_id)
            for who, hits, why in shade.mine:   # 反咬：對手對你（第 5-4-2 題）
                rel, said = npc_mod.shift(who, people.changed_relation(rows, npc_changes, who), hits, why)
                npc_changes.setdefault(who, {})["relation"], shade.events = rel, shade.events + said
            due = echo.due(shade.sheet, turn_no, room and not quest.threads, gone)
            new_route = (walk.sheet["route"] or {}).get("key") != (sheet["route"] or {}).get("key") and not trail.touched   # 剛撞上的路線這回合不抽牌
            asks = [a for a in (echo.offer(due), routes.offer(walk, shade.sheet, rows, z, s, route_rng, here=here, place_type=here_type, now=new_clock,
                                                              turn_no=turn_no), None if new_route else deal.ask) if a]
        deed = deeds.Scene() if delta.fallen else deeds.offer(rows, updates, shade.sheet, self.plots, focus=focus, now=new_clock, turn_no=turn_no,
                                                              present=people.present_names(rows, here) - dead - {v.name for v in guests} - set(avatars))   # 在場的人對你的做法（第 7-2b 批，㉖）；化身不抽
        group = deeds.Scene() if delta.fallen else gathers.offer(rows, updates, here, now=new_clock, turn_no=turn_no)   # 你那群提議拜把子（第 7-5a 批）
        asks += [a for a in (deed.ask, None if delta.fallen else spot_here.ask, None if delta.fallen else spot_faction.ask, group.ask) if a]
        # 說書排程（第 2-1a、2-1b 批）：會等的、當場的交候選挑一件；危險、回應的、路線收尾、陷阱落下已經拿走就不挑
        chosen =schedule.pick(asks + spots, taken=danger or answer or bool(quest.scene or paid.scene or walk.scene or shade.scene or shade.choices), now=new_clock)
        kind = chosen.kind if chosen else ""
        shade.sheet = chosen.run(shade.sheet) if chosen else shade.sheet
        came = due if kind in (schedule.ECHO, schedule.ASK, schedule.DEBT) else None
        if self.routes_on and not up and not delta.fallen:
            shade.sheet, hints = routes.omens(rows, shade.sheet, verdict, focus=focus, here=here, turn_no=turn_no)   # 伏筆的破綻、翻開（16v 第 82-1 題）
        delta.sheet, stale = echo.turn(shade.sheet, came, turn_no, new_clock, gone)
        if came:   # 舊事的人走到主角面前，人不在了就只是「有人」
            moved = people.find(rows, came["who"]) and background.arrive(rows, updates, visitors.Visit(came["who"], visitors.OLD, new_clock), here=here,
                                                                         protagonist=sheet["name"], turn_no=turn_no)
            rows, focus = (moved, came["who"]) if moved else (rows, focus)
            came = None if came["side"] and not moved else {**came, "text": echo.line(came, came["who"]) if moved else echo.line(came)}   # 開口的人不在了就算了
        if came and came["side"]:
            delta.sheet = {**delta.sheet, "asking": came["side"]}
        # 落實當場的主事：追兵、新面孔登場；天道落子記一盤棋、指派宿敵；事件當場結算
        if kind == schedule.HEAVEN and move.kind == games.RIVAL:
            rows, happening, assigned = _assign_rival(session, turn_no, rows, delta.sheet, here, move, new_clock, dead)
            roles.update(assigned)
        elif kind in (schedule.HEAVEN, schedule.EVENT):
            happening = drawn
        if kind == schedule.HEAVEN and move.kind != games.RIVAL:   # 記一盤還沒分勝負的棋；討的是因果就把帳銷掉
            rec = happening.record
            rows = {**rows, "games": rows["games"] + [games.new_game(session_id, int(rec["game"]), rec["kind"], rec["name"], new_clock, turn_no)]}
            delta.sheet = {**delta.sheet, "debt": None} if move.heavy else delta.sheet
        arranged = enrol or {schedule.HUNT: hunter, schedule.FACE: face}.get(kind, happening.arranged)
        if happening.record:
            now_out = incidents.happen_now(happening, delta.sheet, rows, npc_changes, _rng(session, "incident-now", turn_no),
                                           here=here, clock_now=new_clock, turn_no=turn_no)
            delta.sheet = now_out.sheet
            delta.changes += now_out.changes
            delta.events += now_out.events
            new_threads += now_out.threads
        if happening.state:   # 地點狀況（第 9b 步）：這回合就看得到
            rows = {**rows, "place_states": rows["place_states"] + [happening.state]}
        rows = routes.mark(walk, rows, updates, name=sheet["name"], here=here, now=new_clock, turn_no=turn_no)
        if quest.pushes or shade.pushes:
            rows = {**rows, "pressure": pressure.apply(rows["pressure"], space.town_of(rows["locations"], here), quest.pushes + shade.pushes, new_clock)}
        delta.changes += quest.changes + walk.changes + deal.changes + shade.changes
        delta.events += quest.events + (walk.facts if walk.scene else []) + deal.events + deed.lines + spot_here.lines + spot_faction.lines + group.lines + shade.events + ([came["text"]] if came else [])
        delta.side, delta.aside = schedule.facts(hints + small + ([] if walk.scene else walk.facts) + echo.later(stale, gone) + heard + ticked.news)   # 旁支事實：痕跡 → 傳聞（第 2-1b、2-2 批），送【旁支】（第 2-3 批）
        updates.rumors += trail.rumors + shade.rumors + [rumors.make(rumors.AFTERMATH, e["place"], place=e["place"], when=new_clock, detail=echo.line(e).replace("你", sheet["name"])[:40])
                                                         for e in stale if not e["side"]]
        delta.marks += walk.marks + deal.marks
        # 天道（第 18-1 步）：這回合的事引起的注視與時間回落，再看天道要不要開口
        card = _heaven_card(conn, session["world_id"], rows["seed"])
        heaven_kind = happening.record["kind"] if kind == schedule.HEAVEN and happening.record else ""
        happened = laws.tags(verdict.action_type, player_input, retreating, "DYING" in (sheet["status"], delta.sheet["status"])) \
            | {t for t, on in (("怪談", zone_power is not None or z.scene or s.scene or r.scene), ("亡者", haunt or rose),
                               ("事端", plots.current(rows, self.plots, here)), (heaven_kind, heaven_kind),
                               ("抹殺之劫", any(games.ERASE in e for e in delta.events))) if on} \
            | ({happening.record["kind"]} if kind == schedule.EVENT and happening.record else set())   # 節日、獵場、押貨、路上……
        if happened & set(laws.HEAVEN_TAGS):   # 天道的手段都算劫
            happened.add("劫")
        delta.sheet, glimpsed, signs = laws.notice(delta.sheet, _scene(rows, delta.sheet, here_type, here, new_clock, happened),
                                                   card.get("obsession", ""), _rng(session, "notice", turn_no))   # 看見眼前的現象（第 3b-1 步第二批）
        delta.events += glimpsed
        delta.marks += signs
        delta.sheet = heaven.watch(delta.sheet, card, delta.marks + _slain(sheet, target, npc_changes),
                                   delta.clock_advance, retreating)
        delta.sheet, card, voice = self._heaven_voice(conn, session_id, session["world_id"], turn_no, card, sheet,
                                                      delta.sheet, new_clock, reveal, _my_games(rows, session_id))
        follow = party.names(delta.sheet)   # 隨行的人跟著到這裡（16i）
        rows = {**rows, "npcs": [{**p, "location": here} if p["name"] in follow else p for p in rows["npcs"]]}
        rows, met_here = people.meet(rows, here, life=session_id, clock_now=new_clock, kin=_kin(rows, delta.sheet),
                                     stranger=_stranger(rows, delta.sheet, here, session_id, new_clock), gap=_gap(rows, delta.sheet, here, session_id, new_clock),
                                     warm=origins.meet_bonus(delta.sheet), crowd=origins.crowd(delta.sheet))
        met = {**met, **met_here}
        delta.sheet, met, past_said = rebirths.tick(rows, delta.sheet, sheet, here=here, met=met, rested=verdict.action_type == judgment.REST,
                                                    now=new_clock, rng=_rng(session, "rebirth", turn_no))   # 殘夢、寄身借口、覺醒（第 6-6b2 批）
        rows = {**rows, "relations": {**rows["relations"], **met}}
        delta.events += past_said
        updates.notes += rebirths.recall(rows) if delta.sheet["rebirth"]["woke"] != sheet["rebirth"]["woke"] else []
        news.met(rows, updates, npc_changes, here=here, life=session_id, now=new_clock)   # 傳聞見面才算（第 1-5e 批）
        spread = spread or _told(rows, delta.sheet, met, here, session_id, new_clock)
        book = _contact(rows, session, delta.sheet, here, new_clock, threads, dead=dead, focus=focus)

        task = "" if delta.fallen else _appearance_task(session, delta.sheet, new_clock, turn_no, shift[0] if shift else rows["era"])
        fame = news.fame(rows, place=here, life=session_id, clock_now=new_clock,
                         name=identity.public(delta.sheet, new_clock))
        talk = "" if delta.fallen else _reputation_task(delta.sheet, fame)
        offer = _name_offer(session, turn_no, rows, here)
        look = _place_task(rows, here, delta.fallen)
        lore = _history_task(rows, here, player_input, delta.fallen)
        # 日常面板（16m 第 2 題）：沒事發生就不請說書人；有人上門、事件、天道開口、換時代照常交給說書人
        calm = routine and not (arranged or guests or foe or rose or happening.prompt or voice or shift or delta.fallen or past_said or walk.facts or walk.tail or deal.events or deed.lines or spot_here.lines or spot_faction.lines or group.lines or came or quest.events
                                or paid.events)
        full = rows["items_told"] >= proposals.MAX_PER_SESSION[proposals.ITEM]
        bases = () if full else items.bases(_rng(session, "item-bases", turn_no), verdict.action_type)   # 16p 第 6 題
        sight = "" if calm else _scene_task(rows, here, delta.fallen)   # 這裡還沒列環境物（16r）
        room = not happening.prompt and len(rows["new_events"]) < proposals.MAX_PER_SESSION[proposals.EVENT]
        event_bases = tuple(f"{s.name}：{s.scene}" for s in incident.bases(_rng(session, "event-bases", turn_no))) if room else ()
        absent = "" if routine or tag else _absent(player_input, sheet, recent, sights)
        if absent:   # 記進事實，前情提要才看得到，後面的回合不會當成真的（黃金戰甲）
            delta.events.append(f"查驗：{absent}不存在，主角沒有這樣東西")
        # 眼前的人講什麼：事端的人有自己的資料，其他人抽一條（16v 第 65 題）
        role = plots.person_note(rows, self.plots, delta.sheet, here, focus) if focus else ""
        said = ""
        act = reading.action(verdict.action_type, intent.targets, intent.target_npc, intent.aim, intent.tool, intent.destination, intent.way)   # 3-6a
        stranger, begged, told = "", None, ""
        seen = rows   # 這回合剛抽的心事也讀得到（只給話題和【眼前的人】讀，寫回照 updates）
        if focus and not calm and people.find(rows, focus):   # 沒有心事的從小表抽一條（第 9e-2 批）
            n = len(updates.ledger), len(updates.reasons)
            talks.draw(rows, updates, people.find(rows, focus), here, new_clock, _rng(session, "worry", turn_no))
            seen = {**rows, "ledger": rows.get("ledger", []) + updates.ledger[n[0]:], "npc_reasons": rows.get("npc_reasons", []) + updates.reasons[n[1]:]}
        if focus and not role and not calm and not came:   # 舊事的人來就是為了那件事
            delta.sheet, said = talks.turn(seen, self.plots, delta.sheet, focus, _rng(session, "talk", turn_no), here=here,
                                           asked=verdict.action_type == judgment.SOCIAL, now=new_clock, turn_no=turn_no,
                                           about=intent.inquiry_npc if intent.inquiry_npc != focus else "")
            mind = talks.mind(seen, people.find(seen, focus), new_clock) if said else None
            told = said if mind and said == mind[0].said else ""   # 心事說出口了，人物卡記住（9e-4-4）
            begged = sides.confide(seen, focus, mind[0], _rng(session, "confide", turn_no)) \
                if told and mind[1] and room and not quest.threads and not delta.sheet["asking"] else None
            delta.sheet = {**delta.sheet, "asking": begged} if begged else delta.sheet   # 心事說出口時開口求你（第 9-5 題，9e-3）
        elif looking and not focus and not arranged and not calm and not delta.fallen:   # 臨時路人（第 9c 批）
            delta.sheet, stranger, said, way = talks.stranger(rows, self.plots, delta.sheet, _rng(session, "passer", turn_no), here=here,
                                                             text=player_input, now=new_clock, turn_no=turn_no)
            delta.events += [f"指路：{way[0]}"] if way[0] else []
            steer = (steer[0], steer[1] or way[1])
        result = NarrationResult(daily.narrative(player_input, delta, start=now, end=new_clock, money=_money(rows),
                                                 near=(here, *_realm(rows, here))), [], "python") if calm \
            else self._narrate(conn, session_id, turn_no, NarrationRequest(
            kind="action", character=_character_view(rows, recent[-1:], delta.sheet, new_clock, session_id),
            clock_label=clock.describe(new_clock)["label"], player_input=player_input, action=act, speech=intent.speech,
            judgment=verdict.to_dict(), facts=[f for f in delta.facts() if not came or f != came["text"]], side=[people.mark(s, rows, here) for s in delta.side],   # 回音已在【主事】
            recent=_recap(recent, sheet["location"], full=self.big) + ([f"已離開{sheet['location']}，{budget.MOVED}"] if here != sheet["location"] else []),   # 16v 第 90 題
            fallen=delta.fallen, rules_text=self.rulebook.prompt_text(),
            realm_guide=realm.prompt_guide(delta.sheet["realm_lv"], laws.dao(delta.sheet)),
            sect_lore=region.sect_lore(rows["factions"], rows["bonds"],
                                       max(delta.sheet["realm_lv"], delta.sheet["lore_tier"])),   # 入門提前一層（16h）
            place_info=_place_info(rows, here, new_clock), contact=_with_undead(book.text, rows, h, here, new_clock),
            inspiration=_inspiration(session, turn_no), subjects=[*sorted(people.present_names(rows, here)), here],
            name_offer=offer, arrival=newcomer.describe(arranged) if arranged else "",
            incident=people.mark((walk.tail and walk.scene) or paid.scene or happening.prompt or walk.scene or shade.scene or deal.scene or deed.scene or spot_here.scene or spot_faction.scene or group.scene or quest.scene or _came_prompt(came, rows), rows, here),
            reputation=reputation.line(fame.levels), reputation_task=talk, heaven=voice,
            legend=_legend(rows, here, new_clock, asked=news.limit_for(intent, verdict) > news.OVERHEARD), zone=z.prompt, legend_line=s.prompt,
            era_line=era.prompt(shift[0] if shift else rows["era"], changed=bool(shift) or flipped, slow=bool(shift) and not long,
                                lost=character_mod.lost(delta.sheet, shift[0] if shift else rows["era"], new_clock)),
            era_words=tuple(era.pairs(shift[0] if shift else rows["era"])), era_keep=_names(rows, shift[0] if shift else rows["era"]),
            rite_line=r.prompt,
            appearance_task=task, place_task=look, history_task=lore,
            place_hint=(_place(rows, look).get("spot") or {}).get("hint", "") if look else "",
            proposal_kinds=_proposal_kinds(rows, here, book.open_threads, task, talk, look, lore, bases, sight, event_bases, self.acts),
            item_bases=bases, scene_task=sight, absent=absent, event_bases=event_bases,
            situation=last.get("situation", "") if here == sheet["location"] else "",   # 換了地點，舊局面不算數
            focus=people.focus_line(rows, npc_changes, focus, people.voice(rows, delta.sheet, focus, here=here, life=session_id, clock_now=new_clock,
                                                                           turn_no=turn_no, fresh=focus in met)) + role + talks.manner(seen, focus, new_clock) + _said(said)
            + (f"；說完心事開口求你：{begged['words']}，寫到他把話說完、主角還沒回答為止" if begged else "")
            if focus else stranger + _said(said) if stranger else "",
            stay=here == sheet["location"] and verdict.action_type != judgment.EXPLORE,
            plot=people.mark(plots.scene_note(rows, self.plots, delta.sheet, here), rows, here),
            route=people.mark(decks.note(delta.sheet, turn_no) + fated.scene(rows, delta.sheet)
                              + rebirths.scene(rows, delta.sheet, sorted(people.present_names(rows, here))), rows, here),   # 不在場的人標出來（away 警告第 2 條）；特殊命後章的場面
            held=decks.held(delta.sheet, turn_no), **_known_names(rows, here),
        ), warnings=lambda r: people.age_warnings(rows, here, new_clock, r.narrative, delta.sheet)
            + people.away_warnings(rows, here, r.narrative)
            + (["heaven_rejected"] if voice and not heaven.check_line(r.heaven) else []))
        if shade.tell:
            result = self._weave(conn, session_id, turn_no, result, shade.tell)
        if walk.tail:
            delta.events.append(walk.tail)
            result = result if walk.tail in result.narrative else dataclasses.replace(result, narrative=f"{result.narrative}\n\n{walk.tail}。")   # 模型常抄進去
        line = heaven.check_line(result.heaven) if voice else ""   # 不合格這回合就不出聲，不重試
        choices, choice_tags = _with_replies(result, happening.record)
        if not self.big:   # 選項過濾是因為提示管不住 9b；大模型照提示寫
            choices, choice_tags = people.here_only(*plots.hush(choices, choice_tags, rows, self.plots, delta.sheet, here, focus), rows, here)
        choices, choice_tags = _with_hint(choices, choice_tags, rows, delta.sheet, here, new_clock)
        point = plots.offer(rows, self.plots, delta.sheet, here, focus) or walk.lead or deal.lead or steer[1]   # 條件湊齊的轉折點（16t 第 5 題）、新路線、指路
        reply = [side.ACCEPT, side.DECLINE] if came and came["side"] or begged else []   # 支線開口
        extra = reply or favours.dues(rows, delta.sheet, new_clock, npc_changes) or ([paid.lead] if paid.lead else []) or shade.choices or deal.choices \
            or ([point] if point else [])   # 暗線的收買（16v 第 35-1 題）、命途的選擇
        if extra and choices:
            keep = max(0, len(choices) - len(extra))
            choices, choice_tags = [*choices[:keep], *extra], [*choice_tags[:keep], *({"nature": "", "difficulty": "", "target": ""} for _ in extra)]
        # 地點提案以出發地為準（抵達的新地點若由 AI 一併描寫，要能被採用）；NPC 登場在抵達後的所在地
        verdicts = _review_proposals(result, sheet, rows, turn_no=turn_no, here=here, open_threads=book.open_threads,
                                     clock_now=new_clock, appearance_task=task, reputation_task=talk,
                                     arranged=arranged, place_prefix=offer["place_prefix"], place_task=look,
                                     history_task=lore, scene_task=sight,
                                     said=(intent.speech, *re.findall("說「(.*?)」", "".join(t["delta"].get("act", "") for t in recent))))   # 3-7a
        rows = _with_history(rows, verdicts)   # 國史寫進骨架，交易裡跟著骨架寫回（16k）
        delta.events.extend(proposals.name_events(verdicts, result.narrative))
        came = arranged and any(v.accepted and v.kind == proposals.NPC and v.name == arranged["name"] for v in verdicts)
        if came:
            focus = people.greeted(focus, arranged["name"], target=target["name"] if target else "", text=player_input,
                                   narrative=result.narrative)
        if came and arranged.get("heaven_role"):   # 天道安排的宿敵登場了才記這一盤（第 18-2b 步）
            no = max((g["no"] for g in rows["games"]), default=0) + 1
            rows = {**rows, "games": rows["games"] + [
                games.new_game(session_id, no, games.RIVAL, arranged["name"], new_clock, turn_no)]}
            met[arranged["name"]] = people.fresh(arranged, arranged["name"], new_clock, games.RIVAL_START,   # 不看名聲
                                                 npc_name=arranged["name"], known_goal="", known_goal_shichen=None)
        delta.sheet = _apply_self_texts(delta.sheet, verdicts, new_clock, fame=fame, here=here)
        delta.events.extend(people.apply_relation_proposals(rows, verdicts, npc_changes))
        delta.sheet, owed_now = favours.proposed(rows, delta.sheet, verdicts, npc_changes, ok=verdict.rolled and verdict.is_success, asked=bool(ask),
                                                 now=new_clock, paid=delta.sheet["hp"] < sheet["hp"] or delta.sheet["money"] < sheet["money"])
        delta.events += owed_now
        notes = memory_book.turn_notes(
            protagonist=sheet["name"], before_sheet=sheet, after_sheet=delta.sheet, verdict=verdict, target=target,
            npc_changes=npc_changes, relations_before=people.relations_before(rows, npc_changes),
            verdicts=verdicts, care=care, here=here, clock_now=new_clock, turn_no=turn_no)
        updates.rumors += news.turn_rumors(   # 你這回合做的事傳開（第 10c-3a 步）
            protagonist=who, session_id=session_id, before_sheet=sheet, after_sheet=delta.sheet,
            verdict=verdict, target=target, npc_changes=npc_changes, notes=notes, care=care, verdicts=verdicts,
            open_threads=book.open_threads, here=here, clock_now=new_clock)
        frame = intent.faction if intent.ploy == factions.FRAME else ""   # 嫁禍（第 7-3b1b2 批）
        _witness(rows, updates, npc_changes, verdict, target, frame, life=session_id, who=who, here=here, now=new_clock, turn_no=turn_no,
                 place_type=here_type, my_lv=sheet["realm_lv"])
        # 殞落時身上的物品變成遺物（第 11-1 步）：殺你的人拿走最好的一件，其餘留在死處
        left = legacy.leave(_rng(session, "relics", turn_no), delta.sheet, life=session_id, clock_now=new_clock,
                            holder=_killer(target, npc_changes, verdict, guests)) if delta.fallen else []
        # 這回合死去的人會不會變成亡者（第 11-2 步；被儀式吞掉的不會）
        died = memory_book.dead_this_turn(npc_changes) | updates.dead
        delta.events += favours.inherit(rows, npc_changes, died, updates.notes, new_clock, turn_no)   # 人情帳轉給親人或徒弟（第 108、125-2、126-2 題）
        if delta.fallen:   # 主角死了，這一生的帳也照這個規矩傳下去（第 6-6a-1 題）
            delta.events += favours.bequeath(rows, npc_changes, updates, session_id, delta.sheet["name"], died)
        haunts.born(h, rows, [p for p in rows["npcs"] if p["name"] in died - z.swallowed], new_clock,
                    protagonist=delta.sheet if delta.fallen else None, life=session_id, threads=threads,
                    relations={n: people.changed_relation(rows, npc_changes, n) for n in rows["relations"]})
        # 客死異鄉（第 19-2 步）：前世的主角（退隱後）死在遠方，變成都市傳說
        sightings.ghosts(s, _rng(session, "legend-ghost", turn_no), rows, [p for p in rows["npcs"] if p["name"] in died],
                         new_clock)
        new_threads += quest.threads + [{**t, "origin": memory_mod.MAIN} for t in h.threads + z.threads + s.threads]
        care.changes.update({**h.closed, **z.closed, **s.closed, **auc.closed, **quest.closed})
        notes += h.notes + auc.notes
        updates.rumors += h.rumors + z.rumors + s.rumors + r.rumors

        turn = {
            "id": new_id("trn"), "session_id": session_id, "turn_no": turn_no, "request_id": request_id,
            "kind": "action", "player_input": player_input, "judgment": verdict.to_dict(),
            # 事件記在回合紀錄裡（第 9a 步）：下一回合結算應對、看剛發生過沒、連續幾回合沒事
            "delta": {**delta.to_dict(), "incident": happening.record,
                      "act": "，".join(filter(None, (act, reading.quote(intent.speech, 20)))),   # 前情提要用（3-6 第 5 題）
                      "quiet": 0 if happening.record else last.get("quiet", 0) + 1,
                      **({"domain": z.record} if z.record else {}),   # 領域上演的情境、規則之物（第 19-1 步）
                      **({"legend": s.record} if s.record else {}),   # 碰上的都市傳說（第 19-2 步）
                      **({"rite": r.record} if r.record else {}),     # 儀式的當夜（19-3）
                      **({"situation": result.situation} if result.situation else {}),   # 局面備忘（故事第 1 題）
                      **({"focus": focus} if focus and not calm else {}),   # 眼前的人（故事第 2 題）
                      **({"read": intent.said} if intent.said else {}),   # 讀懂照保守值走（3-3 第 12 題）
                      **({"left": parted} if parted else {}),               # 他走了，下回合還能跟過去
                      **({"heaven": line} if line else {})},   # 天道的台詞（第 18-1 步），畫面另起一段
            "narrative": result.narrative, "choices": choices, "choice_tags": choice_tags, "model": result.model,
        }
        with transaction(conn):
            if repos.get_character(conn, session_id) != stored:   # 例如另一個視窗在 AI 寫敘事時買賣了物品
                raise Conflict("這回合處理期間角色有了變動（例如買賣物品），請重送行動。", code="character_changed")
            repos.advance_session(conn, session_id, expected_turn_no=session["turn_no"], new_turn_no=turn_no,
                                  phase=ENDED if delta.fallen else PLAYING, clock_shichen=new_clock)
            if not up:   # 下界實際玩出的時間流進仙域（16l B4）
                realms.flow(conn, session["user_id"], new_clock - session["clock_shichen"])
            if writes.get("credit"):   # 戰功記在所屬（或僱主）仙宗的帳上（16l C2、C4c）；戰事裡打贏，對方扣（C3a）
                realms.add_merit(conn, session["user_id"], *writes["credit"])
                if writes["rival"]:
                    realms.add_merit(conn, session["user_id"], writes["rival"], -writes["credit"][1])
            if writes.get("took"):   # 搶到造化：這一處不能再搶，下一個百日結算歸你的仙宗（C3b）
                realms.claim(conn, session["user_id"], writes["took"]["key"], delta.sheet["sect"])
            if writes.get("champ"):   # 奪得仙戰魁首：下一個百日傳開（C4b）
                realms.champion(conn, session["user_id"], *writes["champ"], identity.public(delta.sheet, new_clock))
            if writes.get("enlist"):   # 宗主招收（C4d）
                realms.enlist(conn, session["user_id"], delta.sheet["sect"], writes["enlist"])
            if writes.get("lord"):   # 宗主經營（C5b1）：仙宗的實力、長老、差事；逐出、叛宗的人拿掉成員羈絆
                realms.set_sect(conn, session["user_id"], writes["lord"], writes["gone"], writes["heir"])
            if writes.get("refugees"):   # 投靠的門人已經當了同伴
                realms.refuged(conn, session["user_id"], session_id)
            if writes.get("pact"):   # 投盟、結盟、宣戰、停戰（C5b3）：補丁套在最新的骨架上
                realms.pact(conn, session["user_id"], writes["pact"])
            if delta.fallen and up:   # 宗主殞落沒傳位：長老接位、動盪、爭位（C5b2）
                realms.succeed(conn, session["user_id"], session_id, new_clock)
            for name, (life, _, _) in avatars.items():   # 化身（D1）：關係雙方都記得，他那一生記一則記事
                if "state" in npc_changes.get(name, {}):   # 傷勢寫回他的角色卡（D2）
                    repos.upsert_character(conn, life, avatar.wound(repos.get_character(conn, life),
                                                                    npc_changes[name]["state"]["condition"]))
                if name in met or "relation" in npc_changes.get(name, {}):
                    rel = npc_changes[name]["relation"] if "relation" in npc_changes.get(name, {}) else met[name]
                    me = identity.own_name(sheet)   # 他那一生看你：同樣的原因，另抄一份記在你名下
                    repos.upsert_relation(conn, session["world_id"], me, life,
                                          {**{k: rel[k] for k in ("affinity", "trust", "grudge")},
                                           "adds": [{**r, "id": None, "holder": me} for r in rel.get("adds", [])]})
                    repos.insert_memory(conn, session["world_id"], life,
                                        avatar.note(identity.own_name(sheet), here, verdict.action_type, new_clock))
            repos.upsert_character(conn, session_id, delta.sheet)
            repos.insert_turn(conn, turn)
            _write_found(conn, session, found_new)
            if opened:   # 第一次到的州（16k）：系統登錄，不屬於這一生
                _write_region(conn, session["world_id"], opened, new_clock)
            if rows["atlas"] != atlas_was:   # 生成了州、國與國的關係、國史（16k）
                repos.set_atlas(conn, session["world_id"], rows["atlas"])
            if rows["pressure"] != pressure_was:   # 地方壓力每月、聲勢也要存（第 7-3b1a 批補上：之前只有事件推了才存）
                repos.set_pressure(conn, session["world_id"], rows["pressure"])
            for st in (trap, bounty, spread, walk.state, *trail.states):   # 佈局、懸賞（16l）、身分傳開（16u 族徵）、路線到期的後果（16v）
                if st:
                    repos.insert_place_state(conn, session["world_id"], st)
            for woe in woes:   # 天災（16j）：地點狀況；受災地點的描述要重寫
                repos.insert_place_state(conn, session["world_id"], woe)
                repos.set_description(conn, session["world_id"], [woe["place"]] if woe["place"] else _towns(rows),
                                      NEW_PLACE_DESCRIPTION)
            if card != repos.get_heaven(conn, session["world_id"]):   # 舊世界補擲、或剛潤色過
                repos.set_heaven(conn, session["world_id"], card)
            _write_games(conn, session["world_id"], games_before, rows["games"])
            _write_spot(conn, session, rows, sheet, delta.sheet, verdict, nook, here, new_clock)   # 描述提案寫進去之前先登錄
            _write_proposals(conn, session, rows, turn_no, verdicts, origin=sheet["location"], verdict=verdict,
                             clock_now=new_clock, here=here)
            _write_scene(conn, session["world_id"], rows, verdicts, task=sight, start=sheet["location"],
                         spent=[f for f in used_sights if scene_mod.once(f)])
            background.write(conn, session, updates, known, new_clock)
            repos.close_ledger(conn, session["world_id"], died, _heirs(rows, died))
            people.write_changes(conn, session, npc_changes, met)
            if told:
                talks.heard(conn, session["world_id"], session_id, rows, focus, told)
            for name in follow:
                repos.update_npc(conn, session["world_id"], name, {"location": here})
            for name, goal in auc.goals.items():   # 放走的人想報恩（16i）
                repos.update_npc(conn, session["world_id"], name, goal)
            memory_book.write(conn, session, turn_no=turn_no, clock_now=new_clock, notes=notes, care=care,
                              verdicts=verdicts)
            _write_incident(conn, session, happening, new_threads, threads)
            for name, role in roles.items():   # 宿敵的天道角色（第 18-2b 步）：在背景演化寫完之後才寫，不被蓋掉
                repos.update_npc(conn, session["world_id"], name, {"heaven_role": role})
            _write_relics(conn, session, taken, left, died, new_clock, kept=s.relics)
            came = [(_system_npc(_rng(session, "route-people", turn_no), p, people.town(rows, p["location"])["scale"],
                                 new_clock, plot_mod.BY, turn_no),
                     people.town(rows, p["location"])["name"]) for p in walk.people]
            for p, _ in came:   # 路線新來的人（比事端先寫，事端取名才會避開）
                repos.insert_npc(conn, session["world_id"], "", p)
            for p, where in came:   # 帶家人（121-1）
                people.settle_family(conn, session["world_id"], p, where, new_clock)
            plots.write(conn, session["world_id"], ticked, _rng(session, "plots", turn_no), self.plots, new_clock, _system_npc,
                        plots.mine(delta.sheet))
            omens = _omens(rows, delta.sheet["location"], new_clock) if self.omens_on else []
            for o in [o for o in omens if o["omen"] <= new_clock and o["key"] not in planned]:   # 到了前兆時刻：放天災事端
                self._omen(conn, session, rows, o, plots.mine(delta.sheet))
            fronts = _fronts(rows, delta.sheet["location"], new_clock) + _homes(rows, delta.sheet["location"], new_clock) if self.wars_on else []
            for o in [o for o in fronts if o["town"] and o["key"] not in newwars.placed(rows["plots"], self.plots)]:   # 主角在打仗的邊境州
                self._front(conn, session, rows, o, new_clock, plots.mine(delta.sheet))
            haunts.write(conn, session["world_id"], h)
            zones.write(conn, session["world_id"], z)
            sightings.write(conn, session["world_id"], s)
            rites.write(conn, session["world_id"], r)
            if long:   # 一回合一年以上：勢力存續、改朝換代（第 8-2 批）
                _lapse(conn, session["world_id"], rows["seed"], now, new_clock, rows["era"]["era"])
            _write_era(conn, session["world_id"], rows["era"], shift)   # 最後：改地名要在其他寫入之後
            if writes.get("found"):   # 立宗（16l C4d）：遺址改名成新仙宗的山門，也在其他寫入之後
                realms.found(conn, session["user_id"], writes["found"]["sect"], writes["found"]["ruin"],
                             writes["found"]["followers"])
            if delta.fallen and not _retire_problem({**delta.sheet, "status": "ALIVE"}, {**rows, "npcs": repos.list_npcs(conn, session["world_id"])}):
                _pass_on(conn, session["world_id"], session_id, legacy.as_npc(delta.sheet, new_clock, turn_no, dead=True),
                         {p["name"] for p in rows["npcs"] if p["status"] == "ALIVE"} - died)   # 死了的上一世（第 6-6a 批）
        self._more(conn, session, rows, s, z, bool(ticked.towns))
        self._foretell(conn, session, rows, omens)
        self._enlist(conn, session, rows, fronts)
        return self.get_state(conn, user_id, session_id, turn=turn)

    # ── 飛升（16l B3）────────────────────────────────────────────────────
    def _ascend(self, conn, user_id: str, session: dict, sheet: dict, stored, words: str, request_id: str) -> dict:
        """回答接引：原世界的這一生以「飛升」收尾（大傳聞、未了的局作廢），同一個人在仙域開一局（等開場）。
        回傳原世界這一局的狀態，多一個 ascendedTo（仙域那一局）。"""
        pick = ascent.choose(sheet["ascent"]["offers"], words)
        if pick is None:
            raise Conflict(ascent.text(sheet["ascent"]["offers"]), code="ascent_pending")
        session_id, world_id, now, here = session["id"], session["world_id"], session["clock_shichen"], sheet["location"]
        turn_no = session["turn_no"] + 1
        line = (f"接引法陣光華大作，{sheet['name']}踏入{pick['sect']}的法陣" if pick["sect"]
                else f"{sheet['name']}拒絕了所有接引，一掌撕開虛空") + "——自此，此界再無此人。"
        turn = {"id": new_id("trn"), "session_id": session_id, "turn_no": turn_no, "request_id": request_id,
                "kind": "action", "player_input": words, "judgment": {"action_type": ascent.ENDING},
                "delta": {"clockAdvance": 0, "changes": [], "events": [line]}, "narrative": line, "choices": [],
                "choice_tags": [], "model": ""}
        mine = _my_games(_world_rows(conn, world_id, session_id), session_id)
        new_sid = new_id("ses")
        with transaction(conn):
            if repos.get_character(conn, session_id) != stored:
                raise Conflict("處理期間角色有了變動（例如買賣物品），請重送。", code="character_changed")
            repos.advance_session(conn, session_id, expected_turn_no=session["turn_no"], new_turn_no=turn_no,
                                  phase=ENDED, clock_shichen=now)
            repos.upsert_character(conn, session_id, {**sheet, "ascent": None, "ascended": True})
            repos.insert_turn(conn, turn)
            for g in [g for g in mine if not g["result"]]:   # 未了的局作廢（比照退隱）
                repos.end_game(conn, world_id, g["no"], games.VOID, now, turn_no)
            repos.insert_rumor(conn, world_id, rumors.make(rumors.ASCENDED, sheet["name"], place=here, when=now,
                                                           lv=ascent.LV, subject_lv=ascent.LV, life=session_id))
            target = realms.world(conn, user_id)
            clock_now = repos.get_world(conn, target)["clock_shichen"]
            carried = character_mod.carried(sheet, location=realms.land(conn, user_id, target, pick),
                                            clock_now=clock_now, was=now)
            carried = {**carried, "dao": realms.take_dao(conn, user_id, sheet, words)}   # 仙域裡以道號行走（D1b、第 44 題）
            if pick["sect"]:
                carried, _ = sect.join(_rng(session, "ascend", turn_no), carried, pick["sect"], judgment.SUCCESS,
                                       clock_now)
                carried = {**carried, "sect_rank": pick["rank"],   # 接引時立的誓記下來（C4c 檢查）
                           "sect_oath": oath_mod.make(pick["oath"], clock_now)}
            repos.insert_session(conn, session_id=new_sid, user_id=user_id, world_id=target,
                                 title=f"{sheet['name']}・{realms.NAME}"[:40], phase=NEED_OPENING,
                                 rng_seed=secrets.token_hex(16), clock_shichen=clock_now, shared=True)
            repos.upsert_character(conn, new_sid, carried)
            realms.link_life(conn, user_id, world_id, session_id, new_sid)   # 先上去的人，關係接過來（B3b）
            realms.mark_sync(conn, user_id, world_id)   # 這個世界之後開新一生要回流（B4）
        return {**self.get_state(conn, user_id, session_id, turn=turn), "ascendedTo": new_sid}

    # ── 退隱（第 11-1 步）────────────────────────────────────────────────
    def retire(self, conn, user_id: str, session_id: str, body: dict) -> dict:
        """退隱：再走一回合，說書人寫退場尾聲（不判定、不推進時間、沒有事件與訪客），這一生就此結束。
        舊主角登錄成 NPC，別人對他的原因、他的關係轉到 NPC 身上，身上的物品記在他名下；未了的天道之局作廢。行動欄的字當作退隱的心願（可空）。"""
        request_id = _request_id(body.get("requestId"))
        wish = str(body.get("input") or "").strip()
        if len(wish) > MAX_INPUT_CHARS:
            raise BadRequest(f"退隱的心願最多 {MAX_INPUT_CHARS} 字。", code="invalid_input")
        session = self.require_session(conn, user_id, session_id)
        replay = repos.get_turn_by_request(conn, session_id, request_id)
        if replay:
            return self.get_state(conn, user_id, session_id, turn=replay, replayed=True)
        if session["phase"] != PLAYING:
            raise Conflict("這一局目前不能退隱。", code=f"phase_{session['phase'].lower()}")
        stored = repos.get_character(conn, session_id)
        sheet = load_sheet(conn, session_id)
        rows = _world_rows(conn, session["world_id"], session_id)
        problem = _retire_problem(sheet, rows)
        if problem:
            raise Conflict(problem, code="cannot_retire")
        self._vetted(conn, session, {"心願": wish})
        world_id, here = session["world_id"], sheet["location"]
        turn_no, now = session["turn_no"] + 1, session["clock_shichen"]
        mine = _my_games(rows, session_id)
        after, card, voice = self._heaven_voice(conn, session_id, world_id, turn_no, _heaven_card(conn, world_id, rows["seed"]),
                                                sheet, sheet, now, "", mine, retired=True)
        threads = memory_mod.visible(repos.list_threads(conn, world_id), session_id)
        action = legacy.RETIRED + (f"：{wish}" if wish else "")
        result = self._narrate(conn, session_id, turn_no, NarrationRequest(
            kind="action", character=_character_view(rows, [], sheet, now, session_id),
            clock_label=clock.describe(now)["label"], player_input=action, action=action, judgment={"action_type": legacy.RETIRED},   # 心願上面查過（3-7b）
            facts=[f"主角決定在{here}退隱，從此不問世事"], fallen=True, retired=True,
            rules_text=self.rulebook.prompt_text(), realm_guide=realm.prompt_guide(sheet["realm_lv"], laws.dao(sheet)),
            place_info=_place_info(rows, here, now), contact=_contact(rows, session, sheet, here, now, threads).text,
            heaven=voice, proposal_kinds=(), **_known_names(rows, here),
        ), warnings=lambda r: ["heaven_rejected"] if voice and not heaven.check_line(r.heaven) else [])
        line = heaven.check_line(result.heaven) if voice else ""
        turn = {"id": new_id("trn"), "session_id": session_id, "turn_no": turn_no, "request_id": request_id,
                "kind": "action", "player_input": action, "judgment": {"action_type": legacy.RETIRED},
                "delta": {"clockAdvance": 0, "changes": [], "events": [], **({"heaven": line} if line else {})},
                "narrative": result.narrative, "choices": [], "choice_tags": [], "model": result.model}
        alive = {p["name"] for p in rows["npcs"] if p["status"] == "ALIVE"}
        with transaction(conn):
            if repos.get_character(conn, session_id) != stored:
                raise Conflict("處理期間角色有了變動（例如買賣物品），請再按一次退隱。", code="character_changed")
            repos.advance_session(conn, session_id, expected_turn_no=session["turn_no"], new_turn_no=turn_no,
                                  phase=ENDED, clock_shichen=now)
            repos.upsert_character(conn, session_id, after)
            repos.insert_turn(conn, turn)
            if card != repos.get_heaven(conn, world_id):
                repos.set_heaven(conn, world_id, card)
            for g in [g for g in mine if not g["result"]]:   # 未了的局作廢，宿敵的天道身分取消（敵意照原因算成仇家）
                repos.end_game(conn, world_id, g["no"], games.VOID, now, turn_no)
                if g["kind"] == games.RIVAL:
                    repos.update_npc(conn, world_id, g["name"], {"heaven_role": ""})
            realms.succeed(conn, user_id, session_id, now)   # 宗主退隱沒傳位（16l C5b2）
            _pass_on(conn, world_id, session_id, legacy.as_npc(sheet, now, turn_no), alive)
            _write_relics(conn, session, [], legacy.leave(_rng(session, "relics", turn_no), sheet, life=session_id,
                                                          clock_now=now, holder=sheet["name"]), set(), now)
        return self.get_state(conn, user_id, session_id, turn=turn)

    # ── 判定意圖（第 4 步混合分類）───────────────────────────────────────
    def _intent(self, conn, session: dict, sheet: dict, player_input: str, turn_no: int,
                rows: dict, tag: dict, pending: bool = False, with_whom: str = "") -> judgment.Intent:
        """決定這回合要判定什麼：移動與跟隨 → 選項標註 → 買賣與找人 → 關鍵字 → AI 分類 → 預設（探索）。
        pending：上回合留下要應對的事件，打字可能是在應對它（「買下情報」），買賣與找人不攔。
        with_whom：上回合眼前的人，或剛離開的人。

        突破、代價、移動、做工必須由玩家明確宣告（關鍵字或目的地），選項標了這幾種也要文字對得上才採用。
        """
        moving = _movement_intent(rows, sheet, player_input) or _follow(rows, sheet, with_whom, player_input)
        if moving:
            return moving
        craft = crafting.nature_of(player_input)   # 「煉製回氣丹」「鍛造精鐵短刀」：看點名的是丹方還是器方
        if craft:
            return judgment.intent_for(craft, player_input)
        if tag.get("nature") in judgment.NATURES and tag["nature"] not in DECLARED:
            return judgment.intent_for(tag["nature"], player_input, tag.get("difficulty", ""), source="choice")
        errand = None if pending or tag or judgment.asking(player_input) else _errand(rows, sheet, player_input)   # 問句只是問問
        if errand:
            return errand
        wish = sheet["race"] != races.HUMAN and form.order(player_input) is not None   # 只是收放族徵不擲骰（16u 族徵）
        detected = judgment.detect(form.rest(player_input) if wish else player_input)
        if detected:
            return detected
        if wish:
            return judgment.intent_for(judgment.OBSERVE, player_input)
        try:
            c = self._classify(conn, session["id"], turn_no, player_input, sheet)
        except UpstreamError:
            # 分類失敗不讓整回合失敗：退回預設（探索），之後的敘事若也失敗才回 502
            return judgment.intent_for(judgment.EXPLORE, player_input, source="default")
        if c.nature in (judgment.MOVE, judgment.EXPLORE, judgment.OBSERVE) and judgment.asking(player_input):
            return judgment.intent_for(judgment.SOCIAL, player_input, c.difficulty, source="ai")   # 問句是在問人（16t）
        if c.nature in (judgment.MOVE, judgment.EXPLORE):
            # 關鍵字沒抓到找、尋、走，AI 卻說探索：多半是雜事（穿戰甲、要靈石），當成觀察，不擲骰、不給靈石
            return judgment.intent_for(judgment.OBSERVE, player_input, c.difficulty, source="ai")
        return judgment.intent_for(c.nature, player_input, c.difficulty, source="ai")

    # ── AI 呼叫（含遙測）─────────────────────────────────────────────────
    def _narrate(self, conn, session_id: str, turn_no: int, request: NarrationRequest,
                 warnings=None) -> NarrationResult:
        """呼叫說書人，並把結果寫進 ai_calls（成功與失敗都記）。

        遙測寫在自己的交易裡，與遊戲狀態無關：AI 失敗時遊戲狀態仍完全不變。
        warnings：敘事寫好後的一致性檢查（只記錄、不阻擋），例如把成年 NPC 寫成孩童。
        送出前先過超額三關（第 2-5 批），丟了什麼記在同一筆的 warnings（dropped:…）。
        """
        request, dropped = (request, []) if self.big else budget.fit(request)   # 大模型不用壓在 9b 的 8K 上下文裡
        result, call = self._call_ai(conn, session_id, turn_no, request.kind, lambda: self.narrator.narrate(request),
                                     outcome=request.judgment.get("outcome", ""))
        call.update(ignored_keys=result.ignored_keys, tone_check=tone.check(request.judgment, result.narrative),
                    narrative_len=len(result.narrative),
                    warnings=dropped + (warnings(result) if warnings else []) + narrators.budget_warnings(result))
        with transaction(conn):
            repos.insert_ai_call(conn, call)
        return result

    def _classify(self, conn, session_id: str, turn_no: int, player_input: str, sheet: dict):
        context = (f"{sheet['name']}，境界{realm.stage_name(sheet['realm_lv'], sheet['stage_index'])}，"
                   f"所在：{sheet['location']}" + ("，瀕死" if sheet["status"] == "DYING" else ""))
        result, call = self._call_ai(conn, session_id, turn_no, "classify",
                                     lambda: self.narrator.classify(player_input, context))
        with transaction(conn):
            repos.insert_ai_call(conn, call)
        return result

    def _take(self, conn, session: dict, sheet: dict, text: str, turn_no: int, rows: dict, tag: dict,
              pending: bool = False, with_whom: str = "", answer: str | None = None, offers: list = (),
              looks: list = (), tasks: list = (), pasts: list = ()) -> judgment.Intent:
        """3-3a：讀懂判這回合要判定什麼（取代 `_intent` 那條鏈和分類呼叫）。清單照當回合的狀態列；
        回應哪一個、在查、在辦、貨留到 3-4。讀懂失敗老實說、這回合不算（第 7 題）；假說書人回空單就走原本的鏈（第 10 題）。
        3-3b：要緊的欄對不上就停下來問（Conflict asking，不寫回合）；answer＝按了的按鈕，取回問的那張單、不再呼叫讀懂。
        3-4a：offers（replies.offers）是回應哪一個的清單；點的跟選項一字不差就是那個，有代價的看第二把鑰匙。
        3-4b：looks（darks.clues）、tasks（sides.tasks）是在查哪一個、在辦哪件請託的清單，取代 spot。
        3-4c：買賣找人進 intent.deal（付錢 → 請託花錢那條路）；貨還不列清單。
        reads 每回合記一筆：驗證後的行動單（含確認）和照走的值；問的那筆 keyword 是 {"問": 欄}。"""
        here = sheet["location"]
        present = {p["name"]: p.get("job", "") for p in people.present(rows, here)}
        if answer is not None:
            checked = repos.asked_read(conn, session["id"], turn_no, text)
            q = checked and reading.ask(checked, present)
            if not q or answer not in [v for _, v in q["buttons"]]:
                raise BadRequest("這個回答對不上剛才的問題，請重新送出行動。", code="invalid_answer")
            checked, call = reading.answered(checked, q["field"], answer), None
        else:
            if reading.blank(text):   # 3-6b：沒中文或一個字，不呼叫讀懂
                self._unsure(conn, session["id"], turn_no, text, {"誰做": reading.LOST}, None, here, present)
            places = [l["name"] for l in rows["locations"] if l["name"] != here][-KNOWN_NAMES_FOR_PROMPT:]
            lists = reading.options(present, [e["name"] for e in sheet["items"]], [f["name"] for f in scene_mod.of(_place(rows, here))],
                                    places, [r.product for rs in crafting.RECIPES.values() for r in rs], 回應哪一個=[o.text for o in offers],
                                    在查哪一個=looks, 在辦哪件請託=tasks, 說出前世的事=pasts,
                                    說到哪個勢力=factions.around(rows, [t for _, _, ts in _scopes(rows, here) for t in ts],
                                                                 but={factions.home(rows, n) for n in present}) if present else ())
            try:
                got, call = self._call_ai(conn, session["id"], turn_no, "read",
                                          lambda: self.narrator.read(text, lists, reading.facts(here, present, with_whom)))
            except UpstreamError as exc:
                raise UpstreamError("沒接上，再送一次。") from exc
            if not got.sheet:
                return self._intent(conn, session, sheet, text, turn_no, rows, tag, pending, with_whom)
            era_now = rows["era"]["era"]
            carried = {e["name"]: (items.shown(e["name"], era_now), *items.aka(sheet, e["name"], e["tier"])) for e in sheet["items"]}
            clicked = next((o.text for o in offers if o.text == text.strip()), None)
            checked = reading.check({**got.sheet, "回應哪一個": clicked} if clicked else got.sheet, text, present, with_whom, carried,
                                    {o.text: o.keys for o in offers if o.cost})
            if checked.get("誰做") == reading.LOST:
                self._unsure(conn, session["id"], turn_no, text, checked, call, here, present)
            if q := reading.ask(checked, present):
                with transaction(conn):
                    repos.insert_ai_call(conn, call)
                    repos.insert_read(conn, session["id"], turn_no, text, checked, {"問": q["field"], "在": [here, *present]})
                raise Conflict(q["question"], code="asking", details={"buttons": [{"label": l, "value": v} for l, v in q["buttons"]]})
        settled = reading.settle(checked)
        pick = lambda k: "" if settled.get(k, "都不是") in ("都不是", "沒有", "清單外", "不挑") else settled[k]   # noqa: E731
        intent = dataclasses.replace(_from_sheet(rows, sheet, settled, text, tag, pending), said=reading.said(checked),
                                     reply=pick("回應哪一個"), look=pick("在查哪一個"), task=pick("在辦哪件請託"), deal=pick("買賣找人"),
                                     past=pick("說出前世的事"), ploy=pick("勢力之間"), faction=pick("說到哪個勢力"),
                                     amount=settled.get("數字", ""), aim=pick("對著什麼") or ("" if settled.get("對誰", "沒有") != "沒有" else settled.get("對象名", "")),   # 3-6a 收尾甲
                                     way=pick("做法"), tool=pick("用什麼"),
                                     speech=settled.get("主角說的話", ""))
        if intent.ploy in factions.TALKS and intent.nature == judgment.SOCIAL and intent.targets:   # 挑撥撮合調停一律判說服（第 7-3b1b2 批；9B 常填套話）
            intent = dataclasses.replace(intent, targets=(judgment.PERSUADE,))
        used = {"做什麼": intent.nature, "判什麼": "+".join(intent.targets), "對誰": intent.target_npc or "沒有",
                "去哪": intent.destination or reading.STAY, "在": [here, *present]}   # 在：地點、在場的人（3-6b 匯出）
        with transaction(conn):
            if call:
                repos.insert_ai_call(conn, call)
            repos.insert_read(conn, session["id"], turn_no, text, checked, used)
        return intent

    @staticmethod
    def _unsure(conn, session_id: str, turn_no: int, text: str, checked: dict, call, here: str, present: dict):
        """3-6b：看不懂就停下來，不寫回合、不過時間；reads 記一筆（地點、在場的人給 `readcheck.py 匯出`）。"""
        with transaction(conn):
            if call:
                repos.insert_ai_call(conn, call)
            repos.insert_read(conn, session_id, turn_no, text, checked, {reading.LOST: True, "在": [here, *present]})
        raise Conflict(reading.UNSURE, code="unsure", details={"hint": reading.hint(present)})

    def _vet(self, conn, session: dict, fields: dict[str, str]) -> dict:
        """3-7b：玩家的長期文字送去檢查，回傳模型的答案；都空不呼叫，呼叫失敗放行（_call_ai 記一筆）。"""
        if not (text := vet.joined(fields)):
            return {}
        try:
            got, call = self._call_ai(conn, session["id"], session["turn_no"], "vet", lambda: self.narrator.vet(text))
        except UpstreamError:
            return {}
        with transaction(conn):
            repos.insert_ai_call(conn, call)
        return got.sheet

    def _vetted(self, conn, session: dict, fields: dict[str, str]) -> None:
        if message := vet.problem(self._vet(conn, session, fields), fields):
            raise BadRequest(message, code="vetted")

    def _spot(self, conn, session_id: str, turn_no: int, player_input: str, detail: str) -> bool:
        """第 53-2 題：玩家這句是不是在查破綻。AI 失敗算沒查到，窗口內可以再試。"""
        try:
            result, call = self._call_ai(conn, session_id, turn_no, "spot", lambda: self.narrator.spot(player_input, detail))
        except UpstreamError:
            return False
        with transaction(conn):
            repos.insert_ai_call(conn, call)
        return result.text == narrators.SPOT

    def _weave(self, conn, session_id: str, turn_no: int, result: NarrationResult, detail: str) -> NarrationResult:
        """第 53-3 題：敘事寫完，模型改寫一句帶進破綻。AI 失敗就維持原文，這個破綻玩家看不到。"""
        try:
            woven, call = self._call_ai(conn, session_id, turn_no, "weave", lambda: self.narrator.weave(result.narrative, detail))
        except UpstreamError:
            return result
        with transaction(conn):
            repos.insert_ai_call(conn, call)
        return dataclasses.replace(result, narrative=woven.text)

    def _heaven_voice(self, conn, session_id: str, world_id: str, turn_no: int, card: dict, before: dict, after: dict,
                      clock_now: int, reveal: str, mine: list[dict], retired: bool = False) -> tuple[dict, dict, str]:
        """天道這回合要不要開口（第 18-1 步）：回傳（角色卡, 人格卡, 【天道開口】的內容；空＝不出聲）。
        第一次開口前先請 AI 潤色人設，不論成敗都只請這一次。reveal：這回合分出勝負的棋局；mine：這一生的棋局（第 18-2a 步）；
        retired：主角退隱（第 11-1 步）。"""
        remaining = character_mod.remaining_life_shichen(after, clock_now)
        when, point = heaven.occasion(before, after, aged=remaining is not None and remaining <= 0, reveal=reveal,
                                      retired=retired)
        if not when:
            return after, card, ""
        if not card["polished"]:   # 潤色完馬上存：之後敘事失敗、玩家重送，也不會再請一次
            card = {**card, "polished": True, "text": self._persona(conn, session_id, turn_no, card)}
            with transaction(conn):
                repos.set_heaven(conn, world_id, card)
        done = [g for g in mine if g["result"]]
        return heaven.seen(after, when), card, heaven.voice_task(
            card, after["realm_lv"], after["gaze"], point, games.score(done), games.score_text(done))

    def _persona(self, conn, session_id: str, turn_no: int, card: dict) -> str:
        """請 AI 把人格卡潤色成一段人設；審核不過或 AI 失敗回傳空字串（永遠用條列）。"""
        try:
            result, call = self._call_ai(conn, session_id, turn_no, "persona",
                                         lambda: self.narrator.persona(heaven.card_lines(card)))
        except UpstreamError:
            return ""
        text = heaven.check_polish(result.text)
        call.update(warnings=[] if text else ["persona_rejected"])
        with transaction(conn):
            repos.insert_ai_call(conn, call)
        return text

    def _call_ai(self, conn, session_id: str, turn_no: int, kind: str, invoke, outcome: str = ""):
        """呼叫 AI；失敗時寫遙測後重新丟出。成功時回傳（結果, 待補欄位的遙測紀錄），由呼叫端寫入。"""
        started = time.monotonic()
        call = {"id": new_id("aic"), "session_id": session_id, "turn_no": turn_no, "kind": kind,
                "model": getattr(self.narrator, "model", self.narrator.name), "outcome": outcome}
        try:
            result = invoke()
        except UpstreamError as exc:
            call.update(ok=False, attempts=exc.details.get("attempts", 1), error_code=exc.code,
                        error_message="\n".join([exc.message, *exc.details.get("rejected", [])]),
                        latency_ms=int((time.monotonic() - started) * 1000))
            with transaction(conn):
                repos.insert_ai_call(conn, call)
            raise
        call.update(ok=True, attempts=result.attempts,
                    error_message="\n".join(result.rejected),   # 重試前被拒絕的輸出，供 Step 0 報告判讀
                    latency_ms=int((time.monotonic() - started) * 1000))
        return result, call

    # ── 存檔匯出／匯入（game/saves.py）─────────────────────────────────────
    def export_save(self, conn, user_id: str, session_id: str) -> dict:
        """匯出這一局所屬的整個世界（世界＋其中所有的局）。"""
        return saves.export_world(conn, self.require_session(conn, user_id, session_id)["world_id"])

    def import_save(self, conn, user_id: str, save: dict) -> dict:
        session = repos.get_session_for_user(conn, saves.import_world(conn, user_id, save), user_id)
        cut = self._vet_import(conn, session)
        return {**self.get_state(conn, user_id, session["id"]), "vetted": cut}

    def _vet_import(self, conn, session: dict) -> list[str]:
        """3-7b：匯入的長期文字合成一次檢查，擋下的欄換回預設（背景、外貌空白、搭配卡拿掉、退隱者的背景只留境界那句）；回傳換掉的欄。"""
        world_id = session["world_id"]
        sheets = [(s["id"], sheet) for s in repos.list_sessions_in_world(conn, world_id) if (sheet := load_sheet(conn, s["id"]))]
        retired = {f"{p['name']}的背景": p for p in repos.list_npcs(conn, world_id) if p["created_by"] == legacy.RETIRED_BY}
        fields, spots = {k: p["profile"] for k, p in retired.items()}, {}
        for i, (sid, sheet) in enumerate(sheets, 1):
            for label, key in (("背景", "background"), ("外貌", "appearance"), *LOOK_PICKS.items()):
                look = key in LOOK_PICKS.values()
                fields[f"第{i}世{label}"] = sheet["look"].get(key, "") if look else sheet[key]
                spots[f"第{i}世{label}"] = (sid, "look" if look else key)
        cut = vet.blamed(self._vet(conn, session, fields), fields)
        with transaction(conn):
            for label in cut:
                if p := retired.get(label):
                    repos.update_npc(conn, world_id, p["name"], {"profile": p["profile"].split("。")[0] + "。"})
                else:
                    sid, key = spots[label]
                    repos.upsert_character(conn, sid, {**load_sheet(conn, sid), key: {} if key == "look" else ""})
        return cut

    # ── 輸出格式 ──────────────────────────────────────────────────────────
    @staticmethod
    def _public_session(s: dict) -> dict:
        view = {"id": s["id"], "worldId": s["world_id"], "title": s["title"], "phase": s["phase"],
                "turnNo": s["turn_no"], "clock": clock.describe(s["clock_shichen"]), "updatedAt": s["updated_at"]}
        if "world_name" in s:
            view["worldName"] = s["world_name"]
        return view

    @staticmethod
    def _public_turn(t: dict, rows: dict) -> dict:
        """新發現只算這一局的這一回合（同一世界的前世也有自己的回合序號）。"""
        def found(items, session_key, turn_key):
            return [x["name"] for x in items if x[session_key] == t["session_id"] and x[turn_key] == t["turn_no"]]
        return {"turnNo": t["turn_no"], "kind": t["kind"], "input": t["player_input"],
                "judgment": t["judgment"], "delta": t["delta"], "narrative": t["narrative"],
                "choices": t["choices"], "choiceTags": t["choice_tags"],
                "discoveries": {"locations": found(rows["locations"], "discovered_session_id", "discovered_turn"),
                                "npcs": found(rows["npcs"], "first_seen_session_id", "first_seen_turn")}}


def _valid_name(value, default: str, label: str, code: str) -> str:
    name = text_field(value, label, code) or default
    if len(name) > 40:
        raise BadRequest(f"{label}最多 40 字。", code=code)
    return name


def _world_rows(conn, world_id: str, session_id: str) -> dict:
    """這回合要用的世界資料，一次讀好往下傳（維護原則：資料每回合讀一次）。
    relations 只有這一生的（NPC 名字 → 關係）；seed 是世界的亂數種子（背景演化用）。"""
    world, me = repos.get_world(conn, world_id), load_sheet(conn, session_id) or {}
    past = [(s, load_sheet(conn, s["id"])) for s in repos.list_sessions_in_world(conn, world_id) if s["id"] != session_id]
    npcs, reasons, now = repos.list_npcs(conn, world_id), repos.list_book(conn, "reasons", world_id), world["clock_shichen"]
    every, factions = repos.list_bonds(conn, world_id, everyone=True), repos.list_factions(conn, world_id)
    relations = npc_mod.scored(repos.list_relations(conn, world_id), reasons, npcs, now, every, factions,
                               {session_id: origins.fond(me)})   # 纏絲（第 6-5d 批）
    bonds = [b for b in every if society.PLAYER not in (b["a_kind"], b["b_kind"])]   # 主角的關係只用在固定加減
    ledger = repos.list_book(conn, "ledger", world_id)
    conns, every_item = repos.list_connections(conn, world_id), repos.list_items(conn, world_id)
    atlas_ = repos.get_atlas(conn, world_id)
    here = atlas.state_of(atlas_, conns, me["location"]) if me.get("location") else None
    legends.use(repos.list_themes(conn, world_id))   # 這回合讀主題時先查這個世界模型寫的（第 128 系列乙）
    tales.use(repos.list_themes(conn, world_id, repos.TALES_W))
    newplots.use(repos.list_themes(conn, world_id, repos.PLOTS_M))   # 模型寫的事端（同上）
    return {"world": world, "seed": world["rng_seed"], "era": _era_card(conn, world_id, world["rng_seed"]),
            # 前幾生：結束的時間（轉生開場時世界脈動從這裡推進）、結局與傳說（第 11-1 步）
            "past_lives": [_past_life(s, sheet, relations) for s, sheet in past if sheet],
            "relics": repos.list_relics(conn, world_id),   # 遺物（第 11-1 步）
            "undead": repos.list_undead(conn, world_id),   # 亡者（第 11-2 步）
            "domains": repos.list_domains(conn, world_id),   # 前期領域（第 19-1 步）
            "legends": repos.list_legends(conn, world_id),   # 都市傳說（第 19-2 步）
            "rites": repos.list_rites(conn, world_id),       # 流傳中的玩法（19-3）
            "locations": repos.list_locations(conn, world_id), "npcs": npcs,
            "connections": conns,
            # 存著的關係＋算出來的友人、仇家、恩人（第 1-3 批，society.derived）
            "factions": factions,
            "bonds": bonds + society.derived(npcs, bonds, reasons, ledger, now, factions),
            "mine": [b for b in every if society.PLAYER in (b["a_kind"], b["b_kind"]) and session_id in (b["a"], b["b"])],   # 這一生的羈絆（分宮，第 129-1 題）
            # 世界長出來的新物品（16p）：這回合開頭你在的那一州拿得到的（模型寫的綁產地，第 128-6 題乙）；
            # 名字、說書人提案幾件看全部（撞名、每一生的上限）
            "new_items": newitems.local(every_item, here["name"] if here else ""), "item_names": frozenset(i["name"] for i in every_item),
            "items_told": newitems.told(every_item),
            # 模型寫的物品：名字 → （副作用, 在這一州的主作用倍數）（第 128-10 題）；身上的可能來自別州，所以看全部
            "perks": newitems.perks(every_item, atlas_["seed"] if atlas_ else "", here["name"] if here else ""),
            "new_events": repos.list_events(conn, world_id),   # 世界長出來的新事件（16p）
            "plots": repos.list_plots(conn, world_id),   # 世界裡的事端（16t）
            "memories": repos.list_memories(conn, world_id), "rumors": repos.list_rumors(conn, world_id),
            # 主角做的事、誰知道（第 1-5a 批，domain/hearsay.py）
            "happened": repos.list_book(conn, "events", world_id), "knows": repos.list_book(conn, "knows", world_id),
            # NPC 之間的原因（誰對被害的人什麼態度、信不信說的人）、帳（血仇、追查兇手；第 1-5b 批）
            "npc_reasons": [r for r in reasons if not r["session_id"]], "ledger": ledger,
            "place_states": repos.list_place_states(conn, world_id),
            "games": repos.list_games(conn, world_id),   # 棋譜（第 18-2a 步）
            "atlas": atlas_,    # 天下骨架（16k）
            "pressure": repos.get_pressure(conn, world_id),   # 村鎮的壓力（16v）
            # 這一生的關係：好感、信任由原因加起來（第 1-2 批，domain/opinion.py）
            "relations": {r["npc_name"]: r for r in relations if r["session_id"] == session_id},
            "my_lv": me.get("realm_lv", 0),   # 怕的境界差（第 121-10 題）
            "fate": truth.world(me, [b for b in every if session_id in (b["a"], b["b"])], session_id),   # 真相分法（第 6-5c 批）
            "my_open": route_mod.holder(me) if me else ("", ""),   # 你開著的那章的（人, 宮）：併章（第 7-4c 批、併章重設計）
            # 命數找上你的事還在等你的人（併章重設計第 4 題甲）
            "waiting": sides.waiting(me, [t for t in repos.list_threads(conn, world_id) if t["session_id"] == session_id]) if me else set(),
            "life": session_id}   # 這一生：人情換的報信、保密看帳和誰知道（第 4-10 題）


def _past_life(session: dict, sheet: dict, relations: list[dict]) -> dict:
    """前一生（第 11-1 步）：名字、結局、在哪裡結束、境界、他的友人與仇家（傳說用）。"""
    ties = {r["npc_name"] for r in relations if r["session_id"] == session["id"] and (
        r["affinity"] >= legacy.FRIEND_AT or r["affinity"] <= legacy.FOE_AT or r["grudge"])}
    return {"id": session["id"], "name": sheet["name"], "end": session["clock_shichen"],
            "ending": legacy.ending(sheet, session["clock_shichen"]), "place": sheet["location"],
            "lv": sheet["realm_lv"], "stage": sheet["stage_index"], "ties": ties, "home": sheet.get("home", "")}


def _legend(rows: dict, here: str, clock_now: int, asked: bool = False) -> str:
    """這回合說書人拿到的前人傳說（第 11-1 步，最多一則）。asked：主動打聽消息成功。"""
    lives = [{**life, "deeds": legacy.deeds(rows["rumors"], life["id"])} for life in rows["past_lives"]]
    return legacy.told(lives, here=here, place_type=_place(rows, here).get("type", ""), asked=asked,
                       present=people.present_names(rows, here), relics_here=legacy.at(rows["relics"], here, clock_now),
                       clock_now=clock_now)


def _public_world(rows: dict) -> dict:
    """玩家可見的世界登錄。不含局的 id：匯入成新世界後內容應完全相同。"""
    return {
        "locations": [{"name": l["name"], "description": l["description"], "type": era.label(l["type"], rows["era"]),
                       "parent": l["parent"], "scale": l["scale"], "danger": l["danger"],
                       "discoveredTurn": l["discovered_turn"]} for l in rows["locations"]],
        # 境界不放這裡（「深不可測」不能從世界登錄看穿）；在場人物的境界與關係見 people.people_view
        "npcs": [{"name": p["name"], "appearance": p["appearance"], "profile": p["profile"], "speech": p["speech"],
                  "location": p["location"], "status": p["status"], "condition": p["condition"],
                  "firstSeenTurn": p["first_seen_turn"]}
                 for p in rows["npcs"]],
        # 勢力（第 10a 步）；人物的目標、性格軸、天道角色都不公開；宗門的上宗（仙宗）也不公開（第 16b 步）
        "factions": [{"name": f["name"], "type": f["type"], "location": f["location"],
                      "discoveredTurn": f["discovered_turn"]} for f in rows["factions"]
                     if f["name"] not in region.hidden_names(rows["factions"])],
    }


def _heaven_card(conn, world_id: str, seed: str) -> dict:
    """天道人格卡（第 18-1 步）。舊世界還沒擲過：用世界種子補擲，結果固定，回合寫入時存起來。"""
    return repos.get_heaven(conn, world_id) or heaven.roll_card(random.Random(f"{seed}:heaven"))


def _era_card(conn, world_id: str, seed: str) -> dict:
    """時代卡（第 16e 節）。舊世界還沒擲過：用世界種子補擲（從紀元 0 的古代開始），_write_era 時存起來。"""
    return repos.get_era(conn, world_id) or era.new(random.Random(f"{seed}:era"))


def _next_era(card: dict, seed: str, clock_now: int, lean=dict, long: bool = True) -> tuple[dict, random.Random] | None:
    """世界時間過了門檻：回傳（新的時代卡, 接著用來挑古蹟的亂數）；還沒到回傳 None。
    lean：到了才呼叫，回傳修士處境的權重倍數（7-3c1 (67)，factions.era_lean）。
    long：這回合是不是長時間不在場（一年以上）；不是的話順延，延滿 50 年才換（125-12、第 8-1 批）。"""
    if not era.due(card, clock_now, long):
        return None
    rng = random.Random(f"{seed}:era:{card['next']}")
    new = era.advance(card, rng, clock_now, lean())
    return ({**new, "since": clock_now} if long else new), rng   # 長時間不在場：時代從回來那刻算（主角脫節一年，第 8-3 批）


def _lapse(conn, world_id: str, seed: str, start: int, end: int, era_now: str) -> None:
    """在交易內呼叫：跳過的歲月（第 8-2 批，domain/lapse.py）跨過幾個百年，勢力就擲幾次存續、國家擲幾次改朝換代。
    散了：traits 記覆滅、羈絆拿掉（人成散人）、自己那種據點改廢墟古蹟。換朝：國號、重擲一類國法。
    接手（8-2 丙）：空位照種類擲，重開或新開，據點改回去；結束時每個接手的勢力生一個現在的首領。"""
    marks = lapse.centuries(start, end)
    if not marks:
        return
    fs, bonds, places = repos.list_factions(conn, world_id), repos.list_bonds(conn, world_id), repos.list_locations(conn, world_id)
    npcs, kinds, a = {p["name"]: p for p in repos.list_npcs(conn, world_id)}, {l["name"]: l["type"] for l in places}, repos.get_atlas(conn, world_id)
    rows = {"atlas": a, "connections": repos.list_connections(conn, world_id), "locations": places}
    taken, heads = set(npcs) | set(kinds) | {f["name"] for f in fs}, []
    for t in marks:
        rng = random.Random(f"{seed}:lapse:{t}")
        for f in list(fs):
            crew = [npcs[b["a"]] for b in bonds if b["b"] == f["name"] and b["type"] in society.MEMBER_BONDS and b["a"] in npcs]
            if f["traits"].get(factions.FELL) or lapse.survives(rng, f["type"], crew, t):
                continue
            f["traits"] = {**f["traits"], factions.FELL: t}
            repos.set_traits(conn, world_id, f["name"], f["traits"])
            for b in [b for b in bonds if f["name"] in (b["a"], b["b"])]:
                repos.delete_bond(conn, world_id, b["a"], b["b"], (b["type"],))
            bonds = [b for b in bonds if f["name"] not in (b["a"], b["b"])]
            seat = lapse.SEAT.get(f["type"])
            if seat and kinds.get(f["location"]) == seat[0]:
                repos.set_location_type(conn, world_id, f["location"], seat[1])
                kinds[f["location"]] = seat[1]
        for f in [f for f in fs if lapse.vacant(f, t)]:   # 接手（第 8-2 丙）：剛在這個百年散的不擲
            town = space.town_of(places, f["location"]) or f["location"]
            f["traits"], new = lapse.take(rng, f, t, town, taken, people.local_race(rows, f["location"]))
            if new is None and f["traits"].get(factions.FELL):
                continue
            repos.set_traits(conn, world_id, f["name"], f["traits"])
            if new:
                repos.insert_faction(conn, world_id, "", new)
                fs.append(new)
                taken.add(new["name"])
            heads.append((new or f)["name"])
            seat = lapse.SEAT.get(f["type"])
            if seat and kinds.get(f["location"]) == seat[1]:
                repos.set_location_type(conn, world_id, f["location"], seat[0])
                kinds[f["location"]] = seat[0]
        for n in sorted((a or {}).get("nations", {})):
            if rng.random() >= lapse.REIGN:
                a["dynasty"] = lapse.new_reign(rng, a.get("dynasty", {}), n)
                if law := crime.nation(fs, n):
                    law["traits"] = lapse.reroll(rng, law["traits"], era_now)
                    repos.set_traits(conn, world_id, n, law["traits"])
    if a:
        repos.set_atlas(conn, world_id, a)
    by, scales, rng = {f["name"]: f for f in fs}, {l["name"]: l["scale"] for l in places}, random.Random(f"{seed}:lapse:heads:{end}")
    for f in [by[n] for n in dict.fromkeys(heads) if not by[n]["traits"].get(factions.FELL)]:   # 現在這一任首領（第 8-2 丙 2 題乙）
        p = lapse.head(rng, f, places, taken, people.local_race(rows, f["location"]))
        if p:
            taken.add(p["name"])
            repos.insert_npc(conn, world_id, "", _system_npc(rng, p, scales.get(f["location"], "鄉鎮"), end, lapse.BY))
            repos.insert_bond(conn, world_id, "", {**sect.member_bond(p["name"], f["name"], True), "clock_shichen": end})


def _write_era(conn, world_id: str, card: dict, shift: tuple[dict, random.Random] | None) -> None:
    """在交易內呼叫：換了時代就改地圖——起始區域的舊客棧、大宅三分之一留成古蹟，其他地名裡的類型字換成新時代的
    （新名字被用掉了就不改）；國家照新時代重擲國法特徵（16h）；存時代卡。"""
    if shift:
        new, rng = shift
        locations = repos.list_locations(conn, world_id)
        kept = era.relics(rng, locations)
        for law in [f for f in repos.list_factions(conn, world_id) if f["type"] == society.NATION]:   # 每一國（16k）
            repos.set_traits(conn, world_id, law["name"], crime.roll_nation(rng, new["era"]))
        taken = ({l["name"] for l in locations} | {p["name"] for p in repos.list_npcs(conn, world_id)}
                 | {f["name"] for f in repos.list_factions(conn, world_id)})
        for name in sorted(kept):
            repos.set_location_type(conn, world_id, name, era.RELIC)
        # 跟著活過來的人：在世上的照新時代重寫；不在的（遠方、飛升）回來時算不合時宜（第 8-3 批，era.behind）
        repos.set_rewrite(conn, world_id, [p["name"] for p in repos.list_npcs(conn, world_id) if p["status"] == "ALIVE"
                                           and p["location"] != society.AWAY and p["goal"] != npc_mod.ASCENDED
                                           and (p["appearance"] or p["profile"])], npc_mod.NEW_ERA)
        # 系統生成的地點描述換回預設，有人在場時請說書人照新時代重寫（地圖第二輪）
        repos.set_description(conn, world_id, [l["name"] for l in locations if l["discovered_session_id"] == ""],
                              NEW_PLACE_DESCRIPTION)
        for l in locations:
            name = era.rename(l["name"], card["era"], new["era"])
            if l["name"] not in kept and name not in taken:
                repos.rename_place(conn, world_id, l["name"], name)
                taken.add(name)
        card = new
    if repos.get_era(conn, world_id) != card:
        repos.set_era(conn, world_id, card)


def _year_season(shichen: int) -> str:
    d = clock.describe(shichen)
    return f"第 {d['year']} 年{d['season']}"


def _my_games(rows: dict, session_id: str) -> list[dict]:
    """這一生的棋局（第 18-2a 步）。"""
    return [g for g in rows["games"] if g["session_id"] == session_id]


def _play_games(rows: dict, session_id: str, settled: tuple[int, str] | None, verdict: judgment.Judgment,
                clock_now: int, turn_no: int) -> tuple[dict, str]:
    """這回合分出勝負的棋局寫進 rows["games"]：上回合天道落的子、衝關的渡劫。回傳（rows, 揭曉的要點）。"""
    played, reveals = list(rows["games"]), []
    if settled:
        no, result = settled
        played = [{**g, "result": result, "ended_shichen": clock_now, "ended_turn": turn_no} if g["no"] == no else g
                  for g in played]
        reveals += [games.reveal(g["kind"], result) for g in played if g["no"] == no]
    if verdict.action_type == judgment.BREAKTHROUGH and verdict.rolled:
        result = games.WIN if verdict.is_success else games.LOSE
        no = max((g["no"] for g in played), default=0) + 1
        played.append(games.new_game(session_id, no, games.TRIAL, games.TRIAL, clock_now, turn_no, result))
        reveals.append(games.reveal(games.TRIAL, result))
    return {**rows, "games": played}, "；".join(reveals)


def _ascent_offers(conn, session: dict, rows: dict, sheet: dict, turn_no: int) -> dict:
    """破空那一刻（16l B3）：有宗門的由自家上宗接引，散修由仙域擲 1～3 個仙宗搶人。記在角色卡，下一回合回答。"""
    hidden = region.hidden_names(rows["factions"])
    upper = next((b["b"] for b in rows["bonds"] if b["type"] == "從屬" and b["a"] == sheet["sect"] and b["b"] in hidden), "")
    found = ascent.offers(_rng(session, "ascent", turn_no), realms.ensure(conn, session["user_id"]), upper=upper,
                          heretic=sheet["heretic"], sheet=sheet)
    return {**sheet, "ascent": {"offers": found}}


def _breach_turn(session: dict, turn_no: int, rows: dict, delta, ctx, *, start: int, end: int) -> dict:
    """破格期（16l 第 2 題，domain/breach.py）：舊角色補上倒數；最後三成時間注視攀升；時間到降下抹殺之劫——
    抗性極難，撐不過被抹殺，撐過被逼當場衝一次破空。勝負記進棋局。角色卡改在 delta，回傳 rows。"""
    sheet = delta.sheet
    if sheet["realm_lv"] in realm.GATES and sheet["stage_index"] == realm.GATES[sheet["realm_lv"]] and not sheet["breach"]:
        sheet = breach.start(sheet, start)
    delta.marks += breach.marks(sheet, start, end)
    delta.sheet = sheet
    if not breach.due(sheet, end):
        return rows
    rng = _rng(session, "erase", turn_no)
    hold = judgment.roll_check(rng, judgment.WITHSTAND, judgment.chance_for(sheet, judgment.WITHSTAND, "極難"))
    won = hold.outcome in (judgment.SUCCESS, judgment.GREAT_SUCCESS)
    played = rows["games"]
    no = max((g["no"] for g in played), default=0) + 1
    played = played + [games.new_game(session["id"], no, games.ERASE, games.ERASE, end, turn_no,
                                      games.WIN if won else games.LOSE)]
    if not won:
        delta.sheet = {**sheet, "status": "FALLEN", "hp": 0, "erased": True}
        delta.events.append("天道降下抹殺之劫，沒能撐過去")
        return {**rows, "games": played}
    delta.events.append("天道降下抹殺之劫，硬撐了過去，被逼著當場破空")
    ready = {**sheet, "breach": {**sheet["breach"], "spared": True}, "cultivation": realm.PROGRESS_PER_STAGE,
             "breakthrough_ready_at": None}   # 不看前提，照一般規則衝一次
    v = judgment.judge_breakthrough(rng, ready, ctx)
    out = effects.apply(ready, v, clock_before=end)
    delta.sheet, delta.changes, delta.events, delta.marks = (out.sheet, delta.changes + out.changes,
                                                             delta.events + out.events, delta.marks + out.marks)
    played = played + [games.new_game(session["id"], no + 1, games.TRIAL, games.TRIAL, end, turn_no,
                                      games.WIN if v.is_success else games.LOSE)]
    return {**rows, "games": played}


def _heaven_move(session: dict, turn_no: int, rows: dict, sheet: dict, action: str, retreating: bool,
                 clock_now: int) -> games.Move | None:
    """天道這回合要不要落子（第 18-2a 步）：同一時間最多一盤，分勝負後冷卻一個月；欠了因果另算。"""
    mine = _my_games(rows, session["id"])
    normal = [g for g in mine if g["kind"] != games.RIVAL]
    rivals = [g for g in mine if g["kind"] == games.RIVAL]
    ends = [g["ended_shichen"] for g in normal if g["result"]]
    rival_end = max((g["ended_shichen"] for g in rivals if g["result"]), default=None)
    rival_ok = all(g["result"] for g in rivals) and (rival_end is None or clock_now - rival_end >= games.RIVAL_COOLDOWN)
    return games.move(_rng(session, "heaven-move", turn_no), sheet, heaven.stage(sheet["realm_lv"], sheet["gaze"]),
                      can=incident.possible(action, retreating=retreating, dying=sheet["status"] != "ALIVE"),
                      open_game=any(not g["result"] for g in normal), last_end=max(ends, default=None),
                      clock_now=clock_now, rival_ok=rival_ok,
                      calamity=breach.CALAMITY_BOOST if breach.late(sheet, clock_now) else 1)   # 破格期最後三成（16l）


def _assign_rival(session: dict, turn_no: int, rows: dict, sheet: dict, here: str, move: games.Move,
                  clock_now: int, dead: set[str]) -> tuple[dict, incidents.Happening, dict]:
    """天道指派宿敵（第 18-2b 步）：先挑結怨的人（當場記一盤、標上天道角色），沒有就安排新人物登場
    （說書人寫出名字、登錄成功才記）。這回合只給說書人一句異兆。回傳（rows, 這回合的事件, 要改的天道角色）。
    dead：這回合剛死的人（rows 裡還是活的，不能挑）。"""
    omen = incidents.Happening(None, f"異兆（只寫氣氛，不點明是誰的安排）：{move.omen}")
    name = games.rival_candidate([p for p in rows["npcs"] if p["name"] not in dead], rows["relations"], clock_now)
    if name:
        no = max((g["no"] for g in rows["games"]), default=0) + 1
        game = games.new_game(session["id"], no, games.RIVAL, name, clock_now, turn_no)
        rows = {**rows, "games": rows["games"] + [game],
                "npcs": [{**p, "heaven_role": games.RIVAL} if p["name"] == name else p for p in rows["npcs"]]}
        return rows, omen, {name: games.RIVAL}
    arranged = games.rival_newcomer(_rng(session, "rival", turn_no), sheet["realm_lv"], place=here,
                                    place_type=_place(rows, here).get("type", ""), taken=_taken(rows, sheet),
                                    land=people.local_race(rows, here))
    return rows, dataclasses.replace(omen, arranged=arranged), {}


def _judge_rival(rows: dict, session_id: str, before: dict, after: dict, target: dict | None, npc_changes: dict,
                 clock_now: int, turn_no: int) -> tuple[dict, str, dict]:
    """宿敵之局這回合分勝負了沒（第 18-2b 步，在找上門、偷襲之後）。回傳（rows, 結果（空＝還沒分）, 要改的天道角色）。
    結果寫進 rows["games"]；分勝負或作廢都清掉他的天道角色。"""
    game = next((g for g in _my_games(rows, session_id) if g["kind"] == games.RIVAL and not g["result"]), None)
    if game is None:
        return rows, "", {}
    name = game["name"]
    p, state = people.find(rows, name), npc_changes.get(name, {}).get("state", {})
    fought = target is not None and target["name"] == name
    result = games.rival_result(
        beaten=fought and state.get("condition") in games.RIVAL_DOWN,
        affinity=people.changed_relation(rows, npc_changes, name)["affinity"],
        down=fought and before["status"] == "ALIVE" and after["status"] == "DYING",
        fallen=after["status"] == "FALLEN", gone=p is None or p["status"] != "ALIVE" or state.get("status") == "FALLEN")
    if not result:
        return rows, "", {}
    ended = {"result": result, "ended_shichen": clock_now, "ended_turn": turn_no}
    rows = {**rows, "games": [{**g, **ended} if g["no"] == game["no"] else g for g in rows["games"]]}
    return rows, result, {name: ""}


def _with_replies(result: NarrationResult, rec: dict | None) -> tuple[list[str], list[dict]]:
    """天道落子那回合，換掉說書人最後的選項，保證有對應的應對（餌：收下與婉拒）。
    說書人自己給的選項跟保證的重複（例如「婉拒並轉身離開」）就先拿掉。"""
    if not rec or rec.get("source") != incident.TIANDAO or not result.choices:
        return result.choices, result.choice_tags
    replies = games.replies(rec)
    own = [(c, t) for c, t in zip(result.choices, result.choice_tags) if not games.overlaps(rec, c)]
    own = own[:max(0, len(result.choices) - len(replies))]
    return ([c for c, _ in own] + [r["text"] for r in replies],
            [t for _, t in own] + [{k: r[k] for k in ("nature", "difficulty", "target")} for r in replies])


def _hook(rows: dict, here: str, clock_now: int, legend: str, heard: list[str]) -> tuple[str, str]:
    """開場的鉤子（16m 第 12 題）：從世界裡挑一件近處真有的事 →（給說書人的事實, 通往它的選項）；都沒有回傳空字串。
    依序：前人的傳說、聽來的傳聞、此地或鄰近的天災、此地或鄰近的修士。"""
    near = [here] + [c["b"] if c["a"] == here else c["a"] for c in rows["connections"] if here in (c["a"], c["b"])]
    if legend:
        return "有人正說起此地流傳的一段前人往事", "向人打聽那段往事"
    if heard:
        return f"人們正議論：{heard[0]}", "向人打聽這件事的來龍去脈"
    woe = next(((k.name, p) for p in near for k in _woes(rows, p, clock_now)), None)
    if woe:
        return f"{woe[1]}正逢{woe[0]}", f"打聽{woe[1]}{woe[0]}的消息"
    p = next((p for p in rows["npcs"] if p["status"] == "ALIVE" and p["realm_lv"] >= 1 and p["location"] in near), None)
    if p is None:
        return "", ""
    if p["location"] == here:
        return f"修士{p['name']}就在這裡", f"上前與{p['name']}攀談"
    return f"聽說{p['location']}來了一位修士，名叫{p['name']}", f"前往{p['location']}"


def _standoff(rows: dict, updates: background.NpcUpdates, delta, verdict, target, guests, *, start: str, here: str,
              clock_now: int) -> None:
    """當面對峙（16m 第 7 題，規則見 domain/visitors.py）：了結的寫事實、打退說和的人離開此地；不理他就出手。
    這回合新上門的仇家接著對峙。直接改 delta。"""
    name = delta.sheet["standoff"]
    p = people.find(rows, name) if name else None
    if name and (p is None or p["status"] != "ALIVE" or p["location"] != start):   # 人死了、或已經不在
        delta.sheet = {**delta.sheet, "standoff": ""}
    elif name:
        delta.sheet, result = visitors.settle(delta.sheet, verdict, (target or {}).get("name", ""), here != start,
                                              clock_now)
        if result in (visitors.WON, visitors.TALKED):
            away = _next_place(rows, here)
            if away:
                updates.fields.setdefault(name, {}).update(location=away)
            delta.events.append((f"{name}負傷敗走" if result == visitors.WON else f"{name}被你說動，暫且離去")
                                + (f"，往{away}去了" if away else "") + "，一年內不會再找上門")
        elif not result and delta.sheet["status"] == "ALIVE":
            hp = max(1, delta.sheet["hp"] - visitors.ambush_damage(delta.sheet["hp_max"], p["realm_lv"],
                                                                   delta.sheet["realm_lv"]))
            delta.changes.append({"field": "hp", "from": delta.sheet["hp"], "to": hp})
            delta.sheet = {**delta.sheet, "hp": hp}
            delta.events.append(f"你沒有理會{name}，他出手了！你受了傷；他還在這裡，動手、交談或離開才能了結")
        elif result == visitors.FOUGHT:
            delta.events.append(f"{name}還在這裡，衝著你來")
    for v in guests:
        if v.hostile and delta.sheet["status"] == "ALIVE":
            delta.sheet = {**delta.sheet, "standoff": v.name}


def _next_place(rows: dict, here: str) -> str:
    """相連的第一個地點（沒有就空字串）。"""
    return next((c["b"] if c["a"] == here else c["a"] for c in rows["connections"] if here in (c["a"], c["b"])), "")


def _with_hint(choices: list[str], tags: list[dict], rows: dict, sheet: dict, here: str,
               clock_now: int) -> tuple[list[str], list[dict]]:
    """16m 第 10 題：派得上用場時補一個選項（最多一個、總數不超過四個），讓繞道、避風頭這類說法看得到。
    要去的地方有獸潮→繞道前往；在通緝你的國家、追捕者會找來的地方→避風頭；
    仇家在場、選項裡沒有離開的→前往相連的地點（離開就了結對峙，16n 第 21 題）。"""
    if not choices or len(choices) >= 4:
        return choices, tags
    beasts = next((c for c in choices if c.startswith("前往") and disaster.beasts(_woes(rows, c[2:], clock_now))), "")
    name = identity.public(sheet, clock_now)
    nation = (_law(rows, here) or {}).get("name", "")
    wanted = identity.level(sheet, name, clock_now)[0] and sheet["wanted"][name]["nation"] in ("", nation) \
        and _place(rows, here).get("type") in identity.HUNT_PLACES
    away = _next_place(rows, here) if sheet["standoff"] and not any(c.startswith("前往") for c in choices) else ""
    hint = f"前往{away}" if away else f"繞道{beasts}" if beasts else "找地方避風頭" if wanted else ""
    if not hint:
        return choices, tags
    blank = {"nature": "", "difficulty": "", "target": ""}
    return choices + [hint], tags + [blank] * (len(choices) - len(tags)) + [blank]


def _write_games(conn, world_id: str, before: list[dict], after: list[dict]) -> None:
    """棋譜：新的棋局寫入、這回合分出勝負的更新。"""
    old = {g["no"]: g for g in before}
    for g in after:
        if g["no"] not in old:
            repos.insert_game(conn, world_id, g)
        elif g["result"] != old[g["no"]]["result"]:
            repos.end_game(conn, world_id, g["no"], g["result"], g["ended_shichen"], g["ended_turn"])


def _heirs(rows: dict, dead: set[str]) -> dict[str, str]:
    """這回合死的人，NPC 之間的帳由誰接（第 8-4-4 題甲）。"""
    alive = {p["name"] for p in rows["npcs"] if p["status"] == "ALIVE"} - set(dead)
    return {d: society.heir(rows["bonds"], d, alive) for d in dead}


def _gone_now(rows: dict, npc_changes: dict, updates: background.NpcUpdates) -> set[str]:
    """已經死去的人（含這回合剛死的）：幽魂的恩怨看對象死了沒（第 11-2 步）。"""
    return ({p["name"] for p in rows["npcs"] if p["status"] != "ALIVE"} | memory_book.dead_this_turn(npc_changes)
            | updates.dead)


def _with_undead(contact: str, rows: dict, h: haunts.Haunts, here: str, clock_now: int) -> str:
    """聯絡簿多一行現身中的亡者（第 11-2 步）。"""
    u = undead.here([h.now(u) for u in rows["undead"]], here)
    return "\n".join(x for x in (contact, undead.line(u, clock_now) if u and u["awake"] else "") if x)


def _undead_view(rows: dict, here: str, clock_now: int) -> list[dict]:
    """畫面的在場人物：現身中的亡者（名字、戰力、狀況）。"""
    u = undead.here(rows["undead"], here)
    return [{"name": undead.label(u, clock_now), "undead": True, "condition": u["condition"],
             "realm": f"戰力約{realm.stage_name(undead.power(u, clock_now), 0)}"}] if u and u["awake"] else []


def _signs(rows: dict, here: str, clock_now: int) -> list[str]:
    """此地狀況（第 9b 步）＋亡者的異象（第 11-2 步，不點名）＋被怪談籠罩（第 19-1 步）＋村鎮的壓力（16v 第 98 題）。"""
    u = undead.here(rows["undead"], here)
    zone = zones.active(rows, zones.Zones(), place=here)
    return (incidents.states_text(rows, here, clock_now) + ([undead.SIGNS[u["form"]]] if u else [])
            + (["此地被怪談籠罩"] if zone else []) + pressure.words(rows.get("pressure", {}), space.town_of(rows["locations"], here)))


def _write_relics(conn, session: dict, taken: list[dict], left: list[dict], dead: set[str], clock_now: int,
                  kept: dict[str, str] | None = None) -> None:
    """遺物（第 11-1 步，在交易的最後寫：人物的所在地與生死都寫好了）：拿走的刪掉、新留下的寫入、
    這回合死去的人帶著的落在他死的地方（死在遠方的跟著下落不明）。"""
    for r in taken:
        repos.take_relic(conn, r["id"])
    for r in left:
        repos.insert_relic(conn, session["world_id"], r["life"], r)
    for name in dead:
        repos.drop_relics(conn, session["world_id"], name, clock_now, lost=evolution.AWAY, to=(kept or {}).get(name, ""))


def _slain(sheet: dict, target: dict | None, npc_changes: dict) -> list[tuple[str, int]]:
    """殺死境界比自己高的人：天道注視上升（第 18-1 步）；修魔道的殺人一律再加（道統）。"""
    if not target or npc_changes.get(target["name"], {}).get("state", {}).get("status") != "FALLEN":
        return []
    gain = heaven.slay_gain(target["realm_lv"], sheet["realm_lv"])
    demon = [(paths.SOURCE, paths.KILL_GAZE)] if paths.has(sheet, "魔門") else []
    return ([(heaven.SLAY, gain)] if gain else []) + demon


def _breakthrough_ctx(rows: dict, last: list[dict], sheet: dict, clock_now: int) -> breakthrough.Context:
    """突破契機只採用查得到的事實：所在地點的登錄類型、上一回合（last，最多一筆）是否閉關滿一個月。"""
    recent_retreat = bool(last) and last[-1]["judgment"].get("action_type") == judgment.CULTIVATE \
        and last[-1]["delta"].get("clockAdvance", 0) >= clock.SHICHEN_PER_MONTH
    return breakthrough.Context(clock_now=clock_now, location_type=_place(rows, sheet["location"]).get("type", ""),
                                recent_retreat=recent_retreat, pill=items.has_breakthrough_pill(sheet),
                                residues=laws.residue_count(sheet), applied=laws.law_count(sheet),
                                surge=disaster.SURGE in _woes(rows, sheet["location"], clock_now), owed=route_mod.owes(sheet))


def _spoils(rng: random.Random, sheet: dict, verdict: judgment.Judgment, lucky: bool, target: dict | None,
            npc_changes: dict[str, dict], relics: list[dict], clock_now: int,
            world: list[dict]) -> tuple[dict, list[str], list[dict]]:
    """這回合撿到、搶到的東西（第 8b 步）：探索大成功撿到靈材；把對手打到重傷或殞落，拿到戰利品。
    遺物（第 11-1 步）：在留有遺物的地方探索成功，找到最好的一件；對手帶著遺物就拿那件，不另擲戰利品。
    回傳（角色卡, 給說書人的事實, 拿走的遺物）。"""
    facts, taken = [], []

    def take(relic, fact):
        taken.append(relic)
        facts.append(fact)
        return rebirth.took(items.add(sheet, relic["name"], relic["tier"], relic["count"]), relic)   # 記下是誰的（信物，第 6-6b1 批）

    found = [c.outcome for c in verdict.all_checks if c.target == judgment.DISCOVER]
    if lucky and judgment.GREAT_SUCCESS in found:
        sheet, fact = items.find(rng, sheet, world)
        facts.append(fact)
    left = legacy.best(legacy.at(relics, sheet["location"], clock_now))
    if left and {judgment.SUCCESS, judgment.GREAT_SUCCESS} & set(found):
        sheet = take(left, f"找到{left['owner']}留下的遺物：{legacy.label(left)}")
    state = npc_changes.get(target["name"], {}).get("state") if target else None
    if state and state["condition"] in npc_mod.CONDITIONS[2:] and state["condition"] != target["condition"]:
        carried = legacy.best(legacy.held_by(relics, target["name"]))
        got = None if carried else items.loot(rng, sheet, target["realm_lv"], hot=True, world=world)   # 搶來的是贓物（16i）
        if carried:   # 退隱的前人帶著的是自己的東西，不叫遺物
            whose = "" if carried["owner"] == target["name"] else f"{carried['owner']}的遺物："
            sheet = take(carried, f"從{target['name']}身上拿到{whose}{legacy.label(carried)}")
        elif got:
            sheet, fact = got
            facts.append(f"從{target['name']}身上{fact}")
    return sheet, facts, taken


def _killer(target: dict | None, npc_changes: dict, verdict: judgment.Judgment, guests: list) -> str:
    """主角殞落時，殺死他的具名 NPC（第 11-1 步）：這回合交手的對手，或找上門偷襲的人；自己也死了就不算。"""
    names = [target["name"]] if target and any(c.target == judgment.STRIKE for c in verdict.all_checks) else []
    names += [v.name for v in guests if v.hostile]
    return next((n for n in names if npc_changes.get(n, {}).get("state", {}).get("status") != "FALLEN"), "")


def _pass_on(conn, world_id: str, life: str, npc: dict, alive: set[str]) -> None:
    """上一世登錄成 NPC（退隱的隱居、死了的已故；121-16、第 6-6a 批）：還活著的人對這一生的原因、這一生的家人師徒
    轉到他身上（不再是成員）；人情帳原封不動轉過去（死了的帳先照傳代規矩轉走了，這裡已經空了）。"""
    repos.insert_npc(conn, world_id, life, npc)
    for r in repos.list_book(conn, "reasons", world_id):
        if r["toward"] == opinion.ME and r["session_id"] == life and r["holder"] in alive:
            repos.insert_book(conn, "reasons", world_id, {**r, "id": None, "toward": npc["name"], "session_id": ""})
    repos.hand_over(conn, world_id, life, npc["name"])
    repos.hand_ledger(conn, world_id, life, npc["name"], alive)


def _retire_problem(sheet: dict, rows: dict) -> str:
    """能不能退隱（第 11-1 步）：瀕死不行；舊主角要登錄成 NPC，名字要合人物的格式、不能與人、地點、勢力同名。"""
    if sheet["status"] != "ALIVE":
        return "瀕死時不能退隱。"
    if not proposals.NAME_RE.match(sheet["name"]):
        return "名字要是 2 到 12 個中文字，退隱後才能以人物的身分留在世界裡。"
    if sheet["name"] in {x["name"] for key in ("npcs", "locations", "factions") for x in rows[key]}:
        return f"世界裡已經有叫「{sheet['name']}」的人或地方，不能以這個名字退隱。"
    return ""


TRADE = re.compile(r"(?<!出)[買賣](?![通命力弄關藝唱醉])")   # 買通、賣命這些不是買賣
SEEK = re.compile(r"(?:找|拜訪|見)([^，。、！？\s]{2,6})$")
NOT_PERSON = ("間", "家", "個", "份", "些", "點", "東西", "路", "處", "地方", "工作", "人", "藥")   # 「找間店」「找個地方」
ROLES = ("掌門", "師父", "師尊", "長老", "老闆", "掌櫃", "店家", "大夫", "郎中")   # 沒有名字的稱呼：當成跟那個人說話


def _shop(rows: dict, sheet: dict, text: str) -> None:
    """說要買賣：黑市、奴隸商人的話放行，其他地方請玩家用面板（打字第 3 題）。"""
    place = _place(rows, sheet["location"]).get("type", "")
    if place not in market.TYPES and not any(w in text for w in market.SLAVE_WORDS):
        _cannot_try("買賣請用「隨身物品」的按鈕。" if place in items.STOCK else "這裡沒有店，要到有店的地方才能買賣。")


def _sought(rows: dict, here: str, text: str, seen: bool = False) -> bool:
    """說要找人：找得到（在場、沒名字的稱呼，或讀懂的對誰在場 seen）回 True；原文抓得到名字卻不在場就說明。"""
    found = SEEK.search(text)
    who = found.group(1) if found else ""
    if seen or who in ROLES or who and who in people.present_names(rows, here):
        return True
    if who and not any(w in who for w in NOT_PERSON):
        _cannot_try(f"{who}不在這裡。" if any(p["name"] == who for p in rows["npcs"]) else f"你不知道{who}在哪裡。")
    return False


def _errand(rows: dict, sheet: dict, text: str) -> judgment.Intent | None:
    """打字第 3 題（舊鏈，假說書人空單）：買賣與找人先攔下來，不判成探索。買賣請玩家用面板；找得到人當成社交，找不到就說明。"""
    if TRADE.search(text):
        _shop(rows, sheet, text)
    return judgment.intent_for(judgment.SOCIAL, text) if _sought(rows, sheet["location"], text) else None


def _absent(text: str, sheet: dict, recent: list[dict], sights: list[dict] = ()) -> str:
    """打字第 9 題：玩家說要用的東西，背包、眼前、上回合敘事都沒有，就告訴說書人它不存在。"""
    thing = items.claimed(text)
    seen = items.carried_text(sheet) + "".join(f["name"] for f in sights) + (recent[-1]["narrative"] if recent else "")
    return "" if thing in seen else thing


def _work_here(intent: judgment.Intent, rows: dict, sheet: dict, text: str) -> judgment.Intent:
    """營生各有做得了的地方（WHITEPAPER 第 16 節、16o）；其他地方直接說做不了（16m 第 8 題，原本改成探索）。"""
    name = effects.job(text)
    if intent.nature == judgment.WORK and _place(rows, sheet["location"]).get("type") not in effects.JOBS[name].places:
        _cannot_try(f"這裡不能{name}，{effects.JOBS[name].where}。")
    return intent


def _cannot_try(reason: str, choices: tuple[str, ...] = ()) -> None:
    """未能嘗試的快速回覆（16m 第 3、8、9 題）：不寫回合、不過時間、不呼叫說書人；choices 是畫面上換掉的選項。"""
    raise Conflict(f"未能嘗試：{reason}", code="cannot_try", details={"choices": list(choices)})


def _study_law(intent: judgment.Intent, sheet: dict, player_input: str, here: dict) -> judgment.Intent:
    """參悟（第 3b-1 步）：挑一條現象（laws.pick）；凡人、沒說參悟什麼、沒見過、天道鎖定的系都不擲骰。"""
    if intent.nature != judgment.STUDY:
        return intent
    law, problem = laws.pick(sheet, player_input, here)
    return dataclasses.replace(intent, law=law, blocked=intent.blocked or problem
                               or lineage.banned(sheet, laws.system_of(law)))   # 魔族不能參悟光系（16k）


def _craft_recipe(intent: judgment.Intent, sheet: dict, player_input: str) -> judgment.Intent:
    """煉丹、煉器（第 3b-3 步）：從字面認出要煉的東西；凡人、沒說煉什麼、熟練度或材料不夠都不擲骰。"""
    if intent.nature not in judgment.CRAFTS:
        return intent
    recipe = intent.recipe if intent.recipe in {r.product for r in crafting.RECIPES[intent.nature]} \
        else crafting.recipe_in(intent.nature, player_input)   # 讀懂的做出什麼（3-3 第 7 題）
    return dataclasses.replace(intent, recipe=recipe,
                               blocked=intent.blocked or crafting.problem(sheet, intent.nature, recipe))


def _spend_items(before: dict, after: dict, verdict: judgment.Judgment, gear: items.Gear,
                 ctx: breakthrough.Context) -> tuple[dict, list[str]]:
    """這回合的物品（第 8 步）：交出上回合之後買賣服用的紀錄、丹毒化開；用掉點名的符籙；衝關時用掉破境丹。
    回傳（角色卡, 給說書人的事實）。"""
    after, facts = items.new_turn(after)
    if gear.used and items.useful(gear.used[0], {c.target for c in verdict.all_checks}, verdict.action_type, gear.side):
        after = items.remove(after, *gear.used, alias=gear.alias)
        facts.append(f"用掉了一張{gear.alias + '（' + items.TIER_LABELS[gear.used[1]] + '）' if gear.alias else items.label(*gear.used)}")
    if verdict.action_type == judgment.BREAKTHROUGH and verdict.rolled and ctx.pill:
        after = items.remove(after, items.BREAK_PILL, before["realm_lv"])
        facts.append(f"服下{items.label(items.BREAK_PILL, before['realm_lv'])}衝關")
    return after, facts


def _character_view(rows: dict, last: list[dict], sheet: dict, clock_now: int, life: str) -> dict:
    """前端與提示詞看到的角色：摘要＋年齡壽元；卡在瓶頸時附上突破成功率與缺少的條件。
    江湖傳言中的你（第 10c-3b 步）：所在地沒人聽過你時由 Python 寫「此地沒人聽過你」，不呼叫 AI。"""
    view = {**character_mod.summary(sheet, clock_now), "moneyName": _money(rows),   # 凡人錢的名稱（經濟第二輪）
            **identity.panel(sheet, clock_now), "identityText": _identity_text(rows, sheet, clock_now),
            "lawText": crime.text(law := _law(rows, sheet["location"]), lapse.reign(rows.get("atlas"), (law or {}).get("name", ""))),   # 這一國的國法（16h）、國號（第 8-2 批）
            **sect.panel(sheet, rows["factions"], clock_now),
            "sectText": "；".join(x for x in (sect.text(sheet, rows["factions"], clock_now),
                                              sect.hunt_text(sheet, clock_now)) if x),
            "party": party.panel(sheet), "partyText": party.text(sheet, rows["npcs"]), "scarsText": "；".join(stage.scar(x)[1] for x in sheet["scars"]),   # 隨行的人（16i）
            "auctionText": auction.text(sheet["auction"], clock_now, sheet["location"]),
            "weather": _sky(rows, clock_now, sheet["location"]),   # 16j；16k 起一州一種
            "weatherText": weather.text(_sky(rows, clock_now, sheet["location"]), _climate(rows, sheet["location"])),
            "learning": learn.text(sheet), "standing": rank.LEVELS[people.standing(rows, sheet, sheet["location"], life, clock_now)[0]],   # 學識、地位（第 7-1c 批）
            "factionText": "；".join(factions.card_line(rows, f) for f in sorted(   # 所屬的凡間勢力（第 7-3b1b2 批）
                {b["b"] for b in rows.get("mine", []) if b["type"] in society.MEMBER_BONDS} & set(factions.live(rows))))}
    if view["atBottleneck"]:
        view["breakthrough"] = breakthrough.odds(sheet, _breakthrough_ctx(rows, last, sheet, clock_now)).to_dict()
    heard = reputation.heard_of(news.fame(rows, place=sheet["location"], life=life, clock_now=clock_now,
                                          name=identity.public(sheet, clock_now)))
    view["reputation"] = ({"text": sheet["reputation"], "place": sheet["reputation_place"]} if heard
                          else {"text": NOBODY_HEARD, "place": ""})
    return view


def _identity_text(rows: dict, sheet: dict, clock_now: int) -> str:
    """給說書人的【身分】（16e.1）：化名、易容（在場誰認得出）、通緝。"""
    knowing = [p["name"] for p in people.present(rows, sheet["location"])
               if identity.disguised(sheet, clock_now) and identity.sees_through(sheet, p, rows["bonds"])]
    return identity.text(sheet, clock_now, knowing=knowing)


def _names(rows: dict, card: dict) -> tuple[str, ...]:
    """時代詞表不換的名字（第 8-1 批）：地名、人名、勢力名照舊（125-4 延續的名字照舊）。只給帶了詞表的詞的，
    不公開的勢力（仙宗）不給（說書人拿不到）。"""
    old, hidden = [a for a, _ in era.pairs(card)], region.hidden_names(rows["factions"])
    return tuple(x["name"] for k in ("locations", "npcs", "factions") for x in rows[k]
                 if x["name"] not in hidden and any(a in x["name"] for a in old))


def _known_names(rows: dict, here: str) -> dict:
    """給提示詞的名稱：地點只列最近的幾個；人只列在場的，全名單會讓模型把人帶著走（16v 第 90 題），重複登錄由審核擋。"""
    return {"known_locations": [l["name"] for l in rows["locations"]][-KNOWN_NAMES_FOR_PROMPT:],
            "known_npcs": sorted(people.present_names(rows, here))}


def _scene_task(rows: dict, here: str, fallen: bool = False) -> str:
    """這裡還沒列過環境物：這回合請說書人列（16r）。還沒登錄的地方下次到訪再請。"""
    place = _place(rows, here)
    return here if place and not fallen and place.get("features") is None else ""


def _write_scene(conn, world_id: str, rows: dict, verdicts: list, *, task: str, start: str, spent: list[dict] = ()) -> None:
    """環境物寫回地點（16r）：用了就沒的從出發地拿掉；請說書人列的，不夠就用類型表補。"""
    if spent:
        repos.set_features(conn, world_id, start, [f for f in scene_mod.of(_place(rows, start)) if f not in spent])
    if task and not (spent and task == start):
        listed = [v.record for v in verdicts if v.accepted and v.kind == proposals.PLACE_FEATURES]
        repos.set_features(conn, world_id, task, scene_mod.filled(listed, _place(rows, task).get("type", "")))


def _write_spot(conn, session: dict, rows: dict, before: dict, after: dict, verdict: judgment.Judgment, nook: dict | None,
                here: str, now: int) -> None:
    """小地方（第 9g 批）：第一次走進去就登錄；去過記時刻、叫回來，查到的記成裡面放了什麼；這裡超過五處收起一處。"""
    place, world_id = _place(rows, here), session["world_id"]
    if not place.get("spot"):
        return
    got = [c["text"] for c in after["clues"] if c not in before["clues"]]
    found = (got or ["有所發現"])[0] if verdict.action_type == judgment.EXPLORE and verdict.is_success else ""
    spot = spot_mod.visit(place["spot"], now, found)
    if nook and here == nook["name"]:
        repos.insert_location(conn, world_id, session["id"], {**nook, "spot": spot})
    else:
        repos.set_spot(conn, world_id, here, spot)
    keep = {here} | {p["location"] for p in rows["npcs"] if p["status"] == "ALIVE"} | {s["place"] for s in rows["place_states"]} \
        | {d["place"] for d in rows["domains"] if d["status"] == domains.ACTIVE}
    gone = spot_mod.tuck([{**l, "spot": spot} if l["name"] == here else l for l in rows["locations"]], place["parent"], keep)
    if gone:
        repos.set_spot(conn, world_id, gone, {**_place(rows, gone)["spot"], "stowed": True})


def _place_task(rows: dict, here: str, fallen: bool = False) -> str:
    """所在地的描述還是預設文字：這回合請說書人寫（地圖第二輪）。還沒登錄的地方由地點提案帶描述。"""
    return here if not fallen and _place(rows, here).get("description") == NEW_PLACE_DESCRIPTION else ""


HISTORY_WORDS = ("往事", "歷史", "來歷", "典故")


def _history_task(rows: dict, here: str, words: str, fallen: bool) -> str:
    """要請說書人寫往事的國（16k）：打聽某國的往事，或所在的國還沒人說過。"""
    a = rows.get("atlas")
    if fallen or not a:
        return ""
    asked = next((n for n in a["nations"] if n in words and any(w in words for w in HISTORY_WORDS)), "")
    return next((n for n in (asked, *_realm(rows, here)[:1]) if n and n not in a.get("history", {})), "")


def _with_history(rows: dict, verdicts: list) -> dict:
    told = {v.name: v.record["text"] for v in verdicts if v.accepted and v.kind == proposals.HISTORY_TEXT}
    return {**rows, "atlas": {**rows["atlas"], "history": {**rows["atlas"].get("history", {}), **told}}} if told else rows


def _proposal_kinds(rows: dict, here: str, open_threads: dict, appearance_task: str,
                    reputation_task: str = "", place_task: str = "", history_task: str = "",
                    bases: tuple = (), sight: str = "", event_bases: tuple = (), acts: bool = False) -> tuple[str, ...]:
    """這回合說書人可能用得到的提案種類（只送這些的說明與格式，讓小模型少讀一些）：
    有人在場才送人物更新與關係、有未了線頭才送結線、Python 要求時才送主角外貌、江湖傳言、所在地描述與國史，
    有給物品底才送新物品（16p）、這裡還沒列過才送環境物（16r）。"""
    skip = (set() if place_task else {"place_text"}) | (set() if history_task else {"history_text"}) \
        | (set() if bases else {"items"}) | (set() if sight else {"place_features"}) \
        | (set() if event_bases else {"incidents"}) \
        | ({"relations", "favours", "memories", "thread_opens"} if acts else {ACTS})   # 第 2-4b 批的開關
    if not people.present(rows, here):
        skip |= {"npc_updates", "relations", "favours"}
    if not open_threads:
        skip.add("thread_closes")
    if not appearance_task:
        skip.add("self_appearance")
    if not reputation_task:
        skip.add("self_reputation")
    return tuple(k for k in PROPOSAL_FIELDS if k not in skip)


def _review_proposals(result: NarrationResult, sheet: dict, rows: dict, *, turn_no: int, here: str = "",
                      open_threads: dict | None = None, clock_now: int = 0, appearance_task: str = "",
                      reputation_task: str = "", arranged: dict | None = None, place_prefix: str = "",
                      place_task: str = "", history_task: str = "", scene_task: str = "", said: tuple = ()) -> list:
    ctx = proposals.Context(
        narrative=result.narrative, turn_no=turn_no, player_name=sheet["name"],
        current_location=sheet["location"],
        known_locations=frozenset(proposals.normalize_name(l["name"]) for l in rows["locations"]),
        # 亡者的名字也算已知（第 11-2 步）：說書人把現身的幽魂當成新人物提案時擋下（真模型實測抓到）
        known_npcs=frozenset(proposals.normalize_name(p["name"]) for p in rows["npcs"] + rows["undead"]),
        place_scales={l["name"]: l["scale"] for l in rows["locations"]}, npc_location=here,
        npc_info={p["name"]: {"status": p["status"], "location": p["location"],
                              "minor": npc_mod.is_minor(p, clock_now)} for p in rows["npcs"]},
        open_threads=open_threads or {},
        known_factions=frozenset(f["name"] for f in rows["factions"]), bonds=tuple(rows["bonds"]),
        appearance_task=appearance_task, reputation_task=reputation_task, arranged=arranged, place_prefix=place_prefix,
        place_task=place_task, race=people.local_race(rows, here or sheet["location"]),   # 說書人寫的新人物是這一州的種族（16k）
        history_task=history_task, known_items=rows["item_names"], scene_task=scene_task,
        known_events=frozenset(e["name"] for e in rows["new_events"]), said=said,
    )
    counts = {proposals.LOCATION: len(rows["locations"]), proposals.NPC: len(rows["npcs"]),
              proposals.FACTION: len(rows["factions"]), proposals.ITEM: rows["items_told"],
              proposals.EVENT: len(rows["new_events"])}
    return proposals.review(result.proposals, ctx, counts)


def _write_proposals(conn, session: dict, rows: dict, turn_no: int, verdicts: list, *, origin: str, clock_now: int,
                     verdict: judgment.Judgment | None = None, here: str = "") -> None:
    """在回合的交易內呼叫：採用的寫入世界，所有審核結果都記進這一局的 proposal_log。

    新地點與出發地相連（距離用提案的分級）；這回合尋路抵達的地點，若 AI 沒有一併描寫，由 Python 以玩家說的名字登錄。
    新 NPC 的歲數與境界由 Python 依年齡層、實力層級、登場處（here，預設出發地）的規模擲出（第 6 步）。
    關係提案不在這裡寫：service 先換算好，連同判定造成的變化由 people.write_changes 一起寫。
    """
    world_id, session_id = session["world_id"], session["id"]
    arrived = verdict is not None and effects.arrives(verdict)
    destination = verdict.destination if arrived else ""
    place_scale = _place(rows, here or origin).get("scale", "")
    for v in verdicts:
        if v.accepted and v.kind == proposals.LOCATION:
            repos.insert_location(conn, world_id, session_id, v.record)
            if v.name == destination:
                _connect(conn, world_id, session_id, turn_no, origin, v.name, space.HALF_DAY, v.record["direction"])
            else:   # 眼前看到的地方：與這回合結束時的所在地相連
                _connect(conn, world_id, session_id, turn_no, destination or origin, v.name,
                         v.record["distance"], v.record["direction"])
        elif v.accepted and v.kind == proposals.NPC:
            rolled = npc_mod.roll_profile(_rng(session, f"npc:{v.name}", turn_no), v.record["age_band"],
                                          v.record["power_tier"], place_scale, clock_now)
            record = {**v.record, **rolled}
            repos.insert_npc(conn, world_id, session_id, {**record, **people.written_ages(record, record, clock_now)})
            # 在宗門、武館登場的新人物有六成加入（16h）
            if bond := sect.recruit(_rng(session, f"recruit:{v.name}", turn_no),
                                    [f for f in rows["factions"] if not (f.get("traits") or {}).get(factions.FELL)], rows["bonds"],
                                    v.name, record["location"]):
                repos.insert_bond(conn, world_id, session_id, {**bond, "clock_shichen": clock_now, "turn_no": turn_no})
        elif v.accepted and v.kind == proposals.NPC_UPDATE and not era.behind(people.find(rows, v.name), rows["era"]):
            texts = {k: v.record[k] for k in ("appearance", "profile") if k in v.record}
            repos.update_npc(conn, world_id, v.name, {**texts, **people.written_ages(people.find(rows, v.name), texts,
                                                                                      clock_now),
                                                      "rewrite_reason": ""})   # 重寫過了，改寫原因清掉
        elif v.accepted and v.kind == proposals.FACTION:
            repos.insert_faction(conn, world_id, session_id, v.record)
        elif v.accepted and v.kind == proposals.ITEM:
            repos.insert_item(conn, world_id, session_id, {**v.record, "source": newitems.TELLER})
        elif v.accepted and v.kind == proposals.EVENT:
            repos.insert_event(conn, world_id, session_id, v.record)
        elif v.accepted and v.kind == proposals.BOND and (felt := factions.pact_reasons(v.record, clock_now)):
            for r in felt:   # AI 寫的盟友、敵對改記原因（第 7-3b1b1 批，㊻③）
                repos.insert_book(conn, "reasons", world_id, r)
        elif v.accepted and v.kind == proposals.BOND:
            repos.insert_bond(conn, world_id, session_id, {**v.record, "clock_shichen": clock_now, "turn_no": turn_no})
        elif v.accepted and v.kind == proposals.PLACE_TEXT:
            repos.set_description(conn, world_id, [v.name], v.record["text"])
        repos.insert_proposal_log(conn, session_id, turn_no, v.kind, v.name, v.accepted, v.reason)
    if destination and verdict.action_type != judgment.MOVE and not verdict.spot:   # 小地方在 _write_spot 登錄
        if verdict.new_place and not any(v.accepted and v.name == destination for v in verdicts):
            repos.insert_location(conn, world_id, session_id, {
                "name": destination, "description": NEW_PLACE_DESCRIPTION, "type": "", "discovered_turn": turn_no})
        _connect(conn, world_id, session_id, turn_no, origin, destination, space.HALF_DAY, "")


# ── 人物的兩層設計（第 10a 步）────────────────────────────────────────────
def _inspiration(session: dict, turn_no: int) -> str:
    """這回合若有新人物登場，給 AI 的靈感素材（不必照用）。"""
    return "、".join(inspiration.draw(_rng(session, "inspiration", turn_no)))


def _name_offer(session: dict, turn_no: int, rows: dict, here: str) -> dict:
    """可用的名字（WHITEPAPER 12.6）：一個沒有地點用過的地名字首。沒用到就丟掉。人名只來自安排登場（_arrival）。"""
    return {"place_prefix": names.place_prefix(_rng(session, "names", turn_no), [l["name"] for l in rows["locations"]],
                                               people.local_race(rows, here))}


def _enrol(session: dict, turn_no: int, rows: dict, sheet: dict, here: str, p: dict) -> dict | None:
    """臨時路人登錄成正式的人（第 9-18、126-9 題）：照他的職業生一個有名字的人，說書人照新面孔寫。"""
    return newcomer.make(_rng(session, "enrol", turn_no), place=here, place_type=talks.place_type(rows, here), taken=_taken(rows, sheet),
                         land=people.local_race(rows, here), town=people.town(rows, here), role=p["job"])


def _arrival(session: dict, turn_no: int, rows: dict, verdict: judgment.Judgment, sheet: dict, here: str,
             dead: set[str]) -> dict | None:
    """這回合 Python 安排誰登場（WHITEPAPER 12.6 方案甲）。主角瀕死或殞落時不安排；
    上一回合才有人登場、或在場還有剛登場的人時也不安排（16m 第 4 題：連著來新面孔，說書人會把兩人混成一個）。
    玩家在找人、這裡又沒人時改給臨時路人（第 9c 批，talks.stranger），不再一定安排新面孔。"""
    present = [p for p in people.present(rows, here) if p["name"] not in dead]
    fresh = any(p.get("first_seen_session_id") == session["id"] and (p.get("first_seen_turn") or 0) >= max(1, turn_no - 1)
                for p in present)
    if sheet["status"] != "ALIVE" or fresh:
        return None
    place_type = _place(rows, here).get("type", "")
    return newcomer.arrange(_rng(session, "arrival", turn_no), nature=verdict.action_type, place=here,
                            place_type=place_type, present=len(present), taken=_taken(rows, sheet),
                            land=people.local_race(rows, here), town=people.town(rows, here))


def _write_incident(conn, session: dict, happening: incidents.Happening, new_threads: list[dict],
                    threads: list[dict]) -> None:
    """在回合的交易內呼叫：事件留下的地點狀況、事件開的線頭（第 9b 步）。主線不佔支線的位子（16v 第 78 題）。"""
    if happening.state:
        repos.insert_place_state(conn, session["world_id"], happening.state)
    room = memory_mod.MAX_ACTIVE_THREADS - sum(t["status"] in memory_mod.ACTIVE for t in threads)
    side = memory_mod.sides(new_threads)
    kept = [t for t in new_threads if t not in side] + side[:max(0, memory_mod.MAX_SIDE - len(memory_mod.sides(threads)))]
    for t in kept[:max(0, room)]:
        repos.insert_thread(conn, session["world_id"], session["id"], t)


def _taken(rows: dict, sheet: dict) -> set[str]:
    """已經有人或地方用掉的名字（新人物不能重名）。"""
    return {p["name"] for p in rows["npcs"]} | {l["name"] for l in rows["locations"]} | {sheet["name"]}


def _appearance_task(session: dict, sheet: dict, clock_now: int, turn_no: int, era_card: dict | None = None) -> str:
    """這回合要不要請 AI 寫主角外貌：還沒寫（附靈感）、或 Python 標記了要改寫。性別和族徵每次都講明。"""
    mark, minor = lineage.mark(sheet), character_mod.age(sheet, clock_now) < npc_mod.ADULT_AGE
    must = (LOOK_RULE.get(sheet["gender"], "") + (f"族徵要寫出來：{mark}。" if mark else "")
            + ("主角未成年，不要寫身材和媚態。" if minor else ""))
    card = f"照這張搭配卡寫，每一項都要寫到，不要加別的特徵：{looks.line(sheet['look'], mark)}。" if sheet["look"] else ""
    if not sheet["appearance"] and card:
        return f"主角的外貌還沒有描寫，{card}{must}"
    if not sheet["appearance"]:
        seeds ="、".join(inspiration.draw(_rng(session, "self-look", turn_no), appearance=3, personality=0,
                                           gender=sheet["gender"], minor=minor))
        return f"主角的外貌還沒有描寫，請依出身與背景寫一段。{must}可參考：{seeds}"
    reason = character_mod.appearance_due(sheet, clock_now, era_card)
    return f"主角的外貌需要改寫：{reason}。{card}{must}" if reason else ""


def _reputation_task(sheet: dict, fame: reputation.Fame) -> str:
    """這回合要不要請 AI 寫「江湖傳言中的你」（第 10c-3b 步）：附上此地的名聲等級與最重要的幾則傳聞（當地版本）。"""
    if not reputation.talk_due(sheet, fame):
        return ""
    return (f"此地的人對主角的評價：{reputation.levels_text(fame.levels)}；"
            f"此地流傳關於主角的事：{'；'.join(fame.told) or '（沒有細節）'}")


def _apply_self_texts(sheet: dict, verdicts: list, clock_now: int, *, fame: reputation.Fame, here: str) -> dict:
    """AI 寫的主角外貌採用後先套用（玩家之後可以修改或改回）；江湖傳言記下在哪裡聽來的、當時的名聲。
    有搭配卡時，模型寫錯或沒寫就用句型版（16u 外貌）。"""
    for v in verdicts:
        if v.accepted and v.kind == proposals.SELF_APPEARANCE:
            sheet = character_mod.apply_appearance(sheet, _checked_look(sheet, v.record["text"], clock_now), clock_now)
        elif v.accepted and v.kind == proposals.SELF_REPUTATION:
            sheet = character_mod.apply_reputation(sheet, v.record["text"], place=here, levels=fame.levels, big=fame.big)
    if sheet["look"] and not sheet["appearance"]:
        sheet = character_mod.apply_appearance(sheet, _checked_look(sheet, "", clock_now), clock_now)
    return sheet


def _checked_look(sheet: dict, written: str, clock_now: int) -> str:
    minor = character_mod.age(sheet, clock_now) < npc_mod.ADULT_AGE
    if not sheet["look"] or (written and looks.usable(written, sheet["gender"], minor, lineage.features(sheet))):
        return written
    return looks.text(sheet["look"], lineage.mark(sheet))


def _choice_tag(last: list[dict], player_input: str) -> dict:
    """玩家選了上一回合（last，最多一筆）的選項時，回傳該選項的 AI 標註；自己打字回傳空 dict。"""
    if not last or player_input not in last[-1]["choices"]:
        return {}
    tags = last[-1]["choice_tags"]
    index = last[-1]["choices"].index(player_input)
    return tags[index] if index < len(tags) else {}


# ── 長期記憶（第 17 步）───────────────────────────────────────────────────
def _upkeep_threads(session: dict, rows: dict, threads: list[dict], here: str, clock_now: int,
                    npc_changes: dict[str, dict], fallen: bool, also_dead: set[str] = frozenset(),
                    kept: str = "") -> tuple[memory_mod.ThreadUpkeep, list[dict]]:
    """線頭維護；失約扣關係（經 domain/npc，併進 npc_changes）。回傳（維護結果, 套用後的線頭）。
    threads：這一生看得到的線頭（回合開始時讀好的）。
    also_dead：背景演化中死去的人（第 10b、10c-1 步），綁在他們身上的線頭一樣落空。
    kept：如約前來的那條約定（第 10c-2a 步），算兌現，不再看期限。"""
    dead = memory_book.dead_this_turn(npc_changes) | set(also_dead)
    care = memory_mod.upkeep([t for t in threads if t["id"] != kept], clock_now=clock_now, session_id=session["id"],
                             here=here, present=people.present_names(rows, here) - dead, dead=dead,
                             protagonist_fallen=fallen)
    if kept:
        care.changes[kept] = {"status": memory_mod.RESOLVED, "closed_shichen": clock_now, "result_note": "如約前來"}
    for t in care.broken:
        updated, events = npc_mod.break_promise(t["subject"], people.changed_relation(rows, npc_changes, t["subject"]))
        npc_changes.setdefault(t["subject"], {})["relation"] = updated
        care.events += events
    return care, [{**t, **care.changes.get(t["id"], {})} for t in threads]


def _contact(rows: dict, session: dict, sheet: dict, here: str, clock_now: int, threads: list[dict],
             dead: set[str] = frozenset(), focus: str = "") -> memory_book.ContactBook:
    last_contact = {n["subject"]: n["clock_shichen"] for n in rows["memories"] if n["session_id"] == session["id"]}
    return memory_book.contact_book(
        session_id=session["id"], notes=rows["memories"], threads=threads, here=here,
        present=[p for p in people.present(rows, here) if p["name"] not in dead],
        protagonist_lifespan=character_mod.lifespan(sheet), clock_now=clock_now,
        people_line=lambda p: people.people_line(rows, p, clock_now), last_contact=last_contact, focus=focus)


# ── 起始區域與出生地（第 16b 步）─────────────────────────────────────────
def _write_region(conn, world_id: str, generated: dict, clock_now: int = 0) -> None:
    """新原初世界的起始區域：系統登錄（不屬於任何一局），描述留給第一次到訪時。
    宗門、武館的成員（16h）照所在地的規模換算境界與出生。本山的上宗從玩家的仙域挑（16l）。"""
    generated = realms.link_upper(conn, world_id, generated)
    for loc in generated["locations"]:
        repos.insert_location(conn, world_id, "", {**loc, "description": NEW_PLACE_DESCRIPTION})
    for edge in generated["connections"]:
        repos.insert_connection(conn, world_id, "", edge)
    for faction in generated["factions"]:
        repos.insert_faction(conn, world_id, "", faction)
    scales, rng = {l["name"]: l["scale"] for l in generated["locations"]}, random.Random(f"{world_id}:members")
    for p in generated.get("people", []):
        repos.insert_npc(conn, world_id, "", _system_npc(rng, p, scales[p["location"]], clock_now, sect.MEMBER_BY))
    for bond in generated["bonds"]:
        repos.insert_bond(conn, world_id, "", bond)


def _came_prompt(came: dict | None, rows: dict) -> str:
    """回音、支線開口放進【主事】（寫法在固定層，第 2-3 批）。女性模型常寫成「他」，這裡說清楚。"""
    if not came:
        return ""
    p = people.find(rows, came["who"])
    who = f"{p['name']}是女性，要寫「她」" if p and p["gender"] == "女" else ""
    return f"{'（請託）' if came['side'] else '（舊事）'}{came['text']}" + (f"。{who}" if who else "")


def _said(line: str) -> str:
    """給【眼前的人】：這回合他要講的事（16v 第 65 題）。"""
    return f"。這回合他會講到：{line}（用他的口氣親口說出來，帶上裡面的人名、地名、東西，不要多講這之外的秘密）" if line else ""


def _system_npc(rng: random.Random, p: dict, scale: str, clock_now: int, by: str, turn_no: int = 0) -> dict:
    """Python 生成的人物（宗門成員、黑市護衛、買來的人）：年齡層、實力換算成境界與出生，可以直接寫入。"""
    p = {**p, **newcomer.kin(p)}
    face = newcomer.looks(random.Random(f"{p['name']}:looks"), p["age_band"], p["gender"], p.get("job", ""), p["power_tier"],
                          p.get("race", races.HUMAN))   # 外貌 Python 定（16m 第 4 題）
    record = {**p, "appearance": face, "status": "ALIVE", "ai_driven": True, "created_by": by, "first_seen_turn": turn_no,
              **npc_mod.roll_profile(rng, p["age_band"], p["power_tier"], scale, clock_now)}
    return {**{k: v for k, v in record.items() if k not in ("age_band", "power_tier")},
            **people.written_ages(record, record, clock_now)}


def _bondage_turn(rows: dict, sheet: dict, verdict: judgment.Judgment, words: str, deal: str | None = None) -> tuple[dict, list[str]]:
    """身為奴（16k）：第一回合被賣或趁亂逃走；說要贖身；主人死了就自由。"""
    b = sheet["bondage"]
    if not b:
        return sheet, []
    owner = people.find(rows, b["owner"])
    if not owner or owner["status"] != "ALIVE":
        return {**sheet, "bondage": None}, [f"{b['owner']}死了，你恢復了自由"]
    if b["stage"] == bondage.FOR_SALE:
        sheet, fact = bondage.sale(sheet, verdict)
        return sheet, [fact]
    sheet, fact = bondage.ransom(sheet, words, people.relation(rows, b["owner"])["affinity"], deal)
    return sheet, [fact] if fact else []


def _runaway(rows: dict, sheet: dict, updates, *, here: str, who: str, clock_now: int) -> tuple[dict, list[str]]:
    """逃跑（16k）：為奴的人離主人家超過半日路程＝逃奴；主人親自來找（目標改成向你復仇，由找上門接手），
    蓄奴的國（販賣人口無罪）另記通緝 1 級。"""
    b = sheet["bondage"]
    if not b or b["stage"] != bondage.OWNED or space.distances_from(rows["connections"], b["house"]).get(
            here, bondage.ESCAPE_KM + 1) <= bondage.ESCAPE_KM:
        return sheet, []
    updates.fields.setdefault(b["owner"], {}).update(goal="復仇", goal_target=sheet["name"])
    sheet = {**sheet, "bondage": {**b, "stage": bondage.RUNAWAY}}
    law = _law(rows, b["house"])
    if not law or crime.code(crime.traits_of(law))[crime.TRAFFIC]:
        return sheet, [f"逃離了{b['owner']}家，{b['owner']}不會善罷甘休"]
    return (identity.accuse(sheet, who, 1, clock_now, nation=law["name"]),
            [f"逃離了{b['owner']}家，成了逃奴，被{law['name']}通緝"])


def _sold(conn, session: dict, sheet: dict) -> tuple[dict, dict | None, list[dict]]:
    """出身奴隸（16k，domain/bondage.py）：開局押在出生州主城的坊市（市集，或拍賣會的後台）；
    買主與他的宅子先安排好。回傳（角色卡, 主人的宅子, [主人]）；舊世界沒有生成區域就照一般的無家可歸。"""
    world_id = session["world_id"]
    a, locations = repos.get_atlas(conn, world_id), repos.list_locations(conn, world_id)
    state = atlas.state_of(a, repos.list_connections(conn, world_id), sheet["location"])
    town = state["capital"] if state else ""
    if not town:
        return sheet, None, []
    rng = _rng(session, "bondage")
    taken = {x["name"] for x in locations + repos.list_npcs(conn, world_id) + repos.list_factions(conn, world_id)}
    where = rng.choice((bondage.MARKET, bondage.AUCTION))
    p = bondage.buyer(rng, where, taken, people.land_race(conn, world_id, town))
    house =next(n for n in (f"{p['name']}宅", f"{town[:2]}{p['name']}宅", f"{p['name']}的宅子") if n not in taken)
    owner = _system_npc(rng, {**p, "location": house}, "鄉鎮", session["clock_shichen"], bondage.BY)
    market_place = next((l["name"] for l in locations if l["type"] == "坊市" and l["parent"] == town), town)
    place = {"name": house, "description": NEW_PLACE_DESCRIPTION, "type": "住家", "scale": "家", "parent": town,
             "danger": "", "discovered_turn": 0}
    return {**sheet, "location": market_place, "bondage": bondage.start(rng, owner, house, where)}, place, [owner]


def _settle_home(conn, session: dict, sheet: dict, body: dict, origin: origins.Origin) -> tuple[dict, dict | None, list[dict]]:
    """建角的落腳處與家人（第 19 步，domain/home.py）：回傳（角色卡, 要登錄的地點, 家人）。
    出生地不是生成區域裡的城鎮、村落、荒野（舊世界）就沒有落腳處。
    凡人身分（16g）填玩家沒指定的落腳處、家人、家運。
    租房的身分被玩家放到荒野：租不到房，住老家（山裡的小屋）、無父無母（追加第 1 題）。"""
    world_id = session["world_id"]
    locations = repos.list_locations(conn, world_id)
    born = next((l for l in locations if l["name"] == sheet["location"] and l["type"] in region.BIRTH_TYPES
                 and l["discovered_session_id"] == ""), None)
    if born is None:
        return sheet, None, []
    rng = _rng(session, "home")
    lost = origin.home == home.RENTED and born["type"] not in home.RENT_TYPES
    kind, family = (home.OLD_HOME, "無父無母") if lost else (origin.home, origin.family)
    sheet = home.assign(rng, sheet, kind=body.get("home") or kind, family=body.get("family") or family,
                        fortune=body.get("fortune") or origin.fortune, place_type=born["type"], boost=origins.fortune_boost(sheet))
    land = people.land_race(conn, world_id, born["name"])
    sheet = home.source(rng, sheet, body.get("surnameFrom"), land)
    taken = ({l["name"] for l in locations} | {p["name"] for p in repos.list_npcs(conn, world_id)}
             | {f["name"] for f in repos.list_factions(conn, world_id)})
    name = home.place_name(sheet, born["name"], born["type"], taken, (repos.get_era(conn, world_id) or era.DEFAULT)["era"])
    if not name:
        return {**sheet, **home.fields(), "surname": sheet["surname"]}, None, []
    links = repos.list_connections(conn, world_id)
    sheet = talks.past(rng, {**sheet, "home": name, "location": name}, born, locations, links)
    place = {"name": name, "description": NEW_PLACE_DESCRIPTION, "type": "住家", "scale": "家", "parent": born["name"],
             "danger": "", "discovered_turn": 0}
    return sheet, place, home.parents(rng, sheet, clock_now=session["clock_shichen"], taken=taken | {sheet["name"]}, land=land,
                                      town=born["name"])


def _birthplace(conn, session: dict, chosen, kinds: tuple = (), race: str = "人族") -> str:
    """建角時選的出生地；沒選就由這一局的種子隨機挑（凡人身分限定出生地類型就從那幾類挑，16g）。
    16k：沒選時先擲出生州（九成本族的州、一成別族的州；還沒生成就這時生成），再從那一州挑。
    舊世界沒有生成區域：一律起始山道。"""
    world_id = session["world_id"]
    a, locations = repos.get_atlas(conn, world_id), repos.list_locations(conn, world_id)
    options = region.birthplaces(locations, a)
    if not options:
        return character_mod.START_LOCATION
    if chosen:
        if chosen not in options:
            raise BadRequest(f"出生地只能選：{'、'.join(options)}。", code="invalid_birthplace")
        return chosen
    rng = _rng(session, "birthplace")
    if a:
        own = [s for s in a["states"] if atlas.race_of(a, s) == race]
        state = rng.choice(own if own and rng.random() < races.LOCAL else [s for s in a["states"] if s not in own])
        if not state["built"]:
            with transaction(conn):
                _build_state(conn, world_id, state, session["clock_shichen"])
            a, locations = repos.get_atlas(conn, world_id), repos.list_locations(conn, world_id)
        mine = atlas.state_map(a, repos.list_connections(conn, world_id))
        options = [n for n in region.birthplaces(locations, a) if mine.get(n, a["start"]) == state["name"]]
    typed = [l["name"] for l in locations if l["name"] in options and l["type"] in kinds]
    return rng.choice(typed or options)


# ── 地點與移動（第 7 步）──────────────────────────────────────────────────
def _place(rows: dict, name: str) -> dict:
    return next((l for l in rows["locations"] if l["name"] == name), {})


def _ensure_place(conn, world_id: str, name: str) -> None:
    """主角所在地一定要是登錄過的地點（才能有路線）。系統登錄的地點不算任何一局的新發現。"""
    if any(l["name"] == name for l in repos.list_locations(conn, world_id)):
        return
    base = space.START_PLACE if name == space.START_PLACE["name"] else {
        "name": name, "description": NEW_PLACE_DESCRIPTION, "type": "", "scale": "", "danger": "", "parent": ""}
    repos.insert_location(conn, world_id, "", {**base, "discovered_turn": 0})


def _ensure_place_now(conn, world_id: str, name: str) -> None:
    """第 7 步之前建立的局，起始地點沒有登錄：進入回合前補上（自己的交易，與回合無關、可重複）。"""
    if not any(l["name"] == name for l in repos.list_locations(conn, world_id)):
        with transaction(conn):
            _ensure_place(conn, world_id, name)


def _ensure_atlas(conn, world_id: str) -> None:
    """天下骨架（16k）：在交易內呼叫——新世界建立時、舊世界第一回合補上（起始區域變成起始州）。
    沒有生成區域的舊世界（沒有系統生成的城鎮或國家）不做。"""
    if repos.get_atlas(conn, world_id):
        return
    locations, factions = repos.list_locations(conn, world_id), repos.list_factions(conn, world_id)
    town = next((l["name"] for l in locations if l["type"] == "城鎮" and l["discovered_session_id"] == ""), None)
    if not town or not (law := crime.nation(factions)):
        return
    taken = {x["name"] for x in locations + factions + repos.list_npcs(conn, world_id)}
    seed = repos.get_world(conn, world_id)["rng_seed"]
    made = atlas.generate(random.Random(f"{seed}:atlas"), nation=law["name"], capital=town,
                          era_now=(repos.get_era(conn, world_id) or {}).get("era", era.ANCIENT), taken=taken)
    _write_region(conn, world_id, {**made, "bonds": []})
    repos.set_atlas(conn, world_id, {**made["atlas"], "seed": seed})   # 存檔讀回來世界種子會換，州的內容照這個生成


def _open_state(rows: dict, session: dict, here: str) -> tuple[dict, dict | None]:
    """主角第一次到某州的主城（16k）：生成那一州。回傳（放進新地點、新骨架的 rows, 要寫入的內容）；人物下一回合才看得到。"""
    state = atlas.unbuilt(rows["atlas"], here)
    if not state:
        return rows, None
    made = _state_content(rows["atlas"], state, rows["era"]["era"],
                          {x["name"] for x in rows["locations"] + rows["factions"] + rows["npcs"]})
    rows = {**_with_new(rows, session, {k: made[k] for k in ("locations", "connections", "factions", "bonds")}),
            "atlas": atlas.built(rows["atlas"], state["name"])}
    return rows, made


def _build_state(conn, world_id: str, state: dict, clock_now: int) -> None:
    """在交易內：建角時生在還沒生成的州（16k）。"""
    a, era_now = repos.get_atlas(conn, world_id), (repos.get_era(conn, world_id) or era.DEFAULT)["era"]
    taken = {x["name"] for x in repos.list_locations(conn, world_id) + repos.list_factions(conn, world_id)
             + repos.list_npcs(conn, world_id)}
    _write_region(conn, world_id, _state_content(a, state, era_now, taken), clock_now)
    repos.set_atlas(conn, world_id, atlas.built(a, state["name"]))


def _state_content(a: dict, state: dict, era_now: str, taken: set[str]) -> dict:
    """一州的內容：用「骨架種子＋州名」跑區域生成（同一個世界每次一樣），名字依種族、拿掉主城本身與國家；
    跟世界裡已有的名字撞名就冠上州名的頭一個字，客棧、大宅照現在的時代改叫法。"""
    here = state["capital"]
    made = region.generate(random.Random(f"{a['seed']}:{state['name']}"), town=here, race=atlas.race_of(a, state), avoid=taken)
    made = {**made, "locations": [l for l in made["locations"] if l["name"] != here], "race": atlas.race_of(a, state),
            "factions": [f for f in made["factions"] if f["type"] != society.NATION]}
    fix, used = {}, {here, *taken}
    for key in ("locations", "factions", "people"):
        for x in made[key]:
            name = era.rename(x["name"], era.ANCIENT, era_now) if key == "locations" else x["name"]
            fix[x["name"]] = next(n for n in ((state["name"][:k] + name)[:era.MAX_NAME]   # 字首用完才走到這裡：冠上兩個字以上
                                              for k in (0, *range(2, len(state["name"]) + 1))) if n not in used)
            used.add(fix[x["name"]])
    text = json.dumps(made, ensure_ascii=False)
    for old, new in fix.items():
        if old != new:
            text = text.replace(json.dumps(old, ensure_ascii=False), json.dumps(new, ensure_ascii=False))
    return json.loads(text)


def _connect(conn, world_id: str, session_id: str, turn_no: int, a: str, b: str, tier: str, direction: str) -> None:
    repos.insert_connection(conn, world_id, session_id, {
        "a": a, "b": b, "tier": tier, "distance_km": space.DISTANCE_TIERS[tier], "direction": direction,
        "discovered_turn": turn_no})


HEADING = re.compile(r"[往向朝](東北|東南|西北|西南|東|南|西|北)[邊方面]?(?:走|去|行|前進|出發)")


def _heading(rows: dict, sheet: dict, text: str) -> tuple[str, bool] | None:
    """「往東走」（打字第 8 題）：這個方向最近的相連地點；這個方向沒有路就說明。"""
    found = HEADING.search(text)
    if not found:
        return None
    near = space.neighbors(rows["connections"], sheet["location"])
    going = [n for n in near if n["direction"] == found.group(1)]
    if not going:
        _cannot_try(f"往{found.group(1)}沒有路，這裡相連的有：{'、'.join(n['name'] for n in near) or '（無）'}。")
    return going[0]["name"], True


FOLLOW = re.compile(r"(?:跟著|跟上|跟隨|尾隨).{0,4}(?:走|去|離開|$)")


def _follow(rows: dict, sheet: dict, who: str, text: str) -> judgment.Intent | None:
    """跟著眼前的人（故事第 2 題）：他走了就真的跟過去；還在這裡就是跟在身邊，不換地方、不擲骰。"""
    p = people.find(rows, who) if who and FOLLOW.search(text) else None
    if not p or p["status"] != "ALIVE":
        return None
    if p["location"] == sheet["location"]:
        return judgment.intent_for(judgment.OBSERVE, text)
    return _walk(rows, sheet, p["location"])


def _walk(rows: dict, sheet: dict, to: str) -> judgment.Intent | None:
    """走到已知的地方；同一個村鎮裡走動不算時間（16t 第 3 題）。沒有路回傳 None。"""
    if to in space.within(rows["locations"], sheet["location"]):
        return judgment.Intent(judgment.MOVE, destination=to)
    route = space.shortest_path(rows["connections"], sheet["location"], to)
    return judgment.Intent(judgment.MOVE, destination=to, travel=space.travel_shichen(route[0], sheet["realm_lv"])) if route else None


def _nearby(rows: dict, sheet: dict, text: str) -> tuple[str, bool] | None:
    """「去換物攤」「去客棧」：沒講全名，同一個村鎮裡有這種地方就是那裡（16u 試玩）。"""
    race, after = people.local_race(rows, sheet["location"]), space.going(text)
    near = space.within(rows["locations"], sheet["location"])
    spot = next((l["name"] for l in rows["locations"] if after and l["name"] in near and l["type"] and (
        names.label(era.label(l["type"], rows["era"]), race) in after)), "")
    return (spot, True) if spot else None


def _movement_intent(rows: dict, sheet: dict, player_input: str) -> judgment.Intent | None:
    """玩家說要前往某處：已知且有路線 → 直接移動；否則 → 辨向（成功才抵達）。"""
    if judgment.asking(player_input) and not any(v in player_input for v in space.MOVE_VERBS):
        return None   # 「要去客棧嗎？」是在問話，不是要走
    found = _heading(rows, sheet, player_input) \
        or space.extract_destination(player_input, [l["name"] for l in rows["locations"]]) \
        or _nearby(rows, sheet, player_input)
    return _go(rows, sheet, *found) if found else None


def _go(rows: dict, sheet: dict, name: str, known: bool, source: str = "keyword") -> judgment.Intent | None:
    """已知且有路線 → 直接移動；上一回合敘事提過（rows["told"]）→ 這裡的小地方，一定到、算當地查探（第 9g 批）；
    否則 → 辨向（成功才抵達）。就在這裡回傳 None。"""
    if name == sheet["location"]:
        return None
    if not known and spot_mod.told(name, rows.get("told", "")):
        return judgment.Intent(judgment.EXPLORE, (judgment.DISCOVER,), source=source, destination=name, new_place=True, spot=True)
    walk = _walk(rows, sheet, name) if known else None
    return dataclasses.replace(walk, source=source) if walk else judgment.Intent(
        judgment.EXPLORE, (judgment.ORIENT,), source=source, destination=name, new_place=not known,
        travel=space.travel_shichen(space.DISTANCE_TIERS[space.HALF_DAY], sheet["realm_lv"]))


DECLARED = (judgment.BREAKTHROUGH, judgment.PRICE, judgment.MOVE, judgment.WORK)   # 要明說的四種（做工：打字第 2 題）


def _staked(intent: judgment.Intent, text: str, target: dict | None, relation: dict | None, own: tuple = ()) -> judgment.Intent:
    """3-5（domain/stake.py）：讀懂那條路的說服、套話、偷東西，難度看要的有多大、對方的境界、他欠你的恩。
    已經不是普通的（Python 出的選項、荒野打聽）照用。"""
    stealing = intent.nature == judgment.STEALTH and any(w in text for w in crime.WORDS[crime.THEFT])
    if intent.source != "read" or intent.difficulty != judgment.NORMAL \
            or not (stealing or {judgment.PERSUADE, judgment.PRY} & set(intent.targets)):
        return intent
    number = "" if intent.deal in ("買", "賣", "付錢") else intent.amount   # 出價、付錢的數目是你給的，不是要的
    size = stake.worth(text, number, target["realm_lv"] if target else 0, own)
    hard = stake.level(size, favour.top((relation or {}).get("favours", [])))
    hard = stake.lips(hard, npc_mod.trait_level(target.get("discretion", 50))) if target and judgment.PRY in intent.targets else hard   # 口風（第 7-1b 批）
    return dataclasses.replace(intent, difficulty=hard)


def _from_sheet(rows: dict, sheet: dict, s: dict, text: str, tag: dict, pending: bool) -> judgment.Intent:
    """3-3a：行動單（跳確認的欄已換成保守值）→ 要判定什麼。誰做是別人＝開口請他、沒有行動＝觀察（第 5 題）；
    只說方向照 `_heading`（第 11 題）；沒去過的地方有地名才開新地點（第 2 題）；做什麼、難度照點的選項，
    要明說的四種除外（第 6 題）；買賣找人看讀懂那一欄（3-4c 第 1 題：買賣照 `_shop`，找人照 `_sought`）。"""
    nature, go, who = s.get("做什麼", judgment.OBSERVE), s.get("去哪", reading.STAY), s.get("對誰", "沒有")
    who = "" if who == "沒有" else who
    wish = sheet["race"] != races.HUMAN and form.order(text) is not None and not judgment.detect(form.rest(text))
    if s.get("誰做") == "沒有行動" or wish:   # 只是收放族徵不擲骰（16u）
        return judgment.Intent(judgment.OBSERVE, source="read")
    if s.get("誰做") == "別人":
        return judgment.Intent(judgment.SOCIAL, (judgment.PERSUADE,), source="read", target_npc=who)
    led = people.find(rows, go[2:]) if go.startswith("跟著") else None
    if led and led["status"] == "ALIVE":   # 他還在這裡就是跟在身邊（故事第 2 題）
        return judgment.Intent(judgment.OBSERVE, source="read") if led["location"] == sheet["location"] \
            else dataclasses.replace(_walk(rows, sheet, led["location"]) or judgment.Intent(judgment.OBSERVE), source="read")
    named = s.get("地名", "")
    found = _heading(rows, sheet, text) or (
        (named, named in {l["name"] for l in rows["locations"]}) if go == "沒去過的地方" and named
        else (go, True) if go not in (reading.STAY, "沒去過的地方") and not go.startswith("跟著") else None)
    moving = found and _go(rows, sheet, *found, source="read")
    if moving:
        return moving
    deal = None if pending or tag or judgment.asking(text) else s.get("買賣找人")   # 3-4c 第 1 題：取代 TRADE、SEEK，付錢不攔
    if deal in ("買", "賣"):
        _shop(rows, sheet, text)
    nature = judgment.SOCIAL if deal == "找人" and _sought(rows, sheet["location"], text, bool(who)) else nature
    nature, level = (tag["nature"], tag.get("difficulty", "")) if tag.get("nature") in judgment.NATURES and tag["nature"] not in DECLARED \
        else (judgment.EXPLORE if go == "沒去過的地方" and nature == judgment.MOVE else judgment.OBSERVE if nature == judgment.MOVE else nature, "")
    if nature == judgment.PRICE:
        burn = any(w in text for w in ("壽元", "精血", "燃燒"))
        return judgment.Intent(nature, source="read", price=judgment.BURN_LIFESPAN if burn else judgment.SACRIFICE_CULTIVATION)
    allowed = judgment.NATURE_TARGETS.get(nature, ()) + ((judgment.HIDE,) if nature == judgment.COMBAT else ())
    picked = tuple(t for t in s.get("判什麼", "").split("+") if t in allowed) or (() if nature == judgment.SOCIAL else allowed[:1])
    picked = (judgment.HIDE, *(t for t in picked if t != judgment.HIDE)) if nature == judgment.STEALTH else picked
    recipe = s.get("做出什麼", "沒有")
    return judgment.Intent(nature, picked[:judgment.MAX_CHECKS], level if level in judgment.DIFFICULTY else judgment.NORMAL, "read",
                           target_npc=who, recipe="" if recipe == "沒有" else recipe)


def _sect_turn(session: dict, turn_no: int, rows: dict, sheet: dict, verdict, *, exam: str,
               words: str, here: str, months: int, clock_now: int, merit_ranks: dict | None = None,
               bar: str = "", lord_pay: int = 0) -> tuple[dict, list[str]]:
    """門派（16h）：入門考核的結果（不收的理由、入門、一年內不再收）、辭別；回去、升等、月例、太久沒回除名。
    merit_ranks：仙域的仙宗升等看戰功（16l C2）；bar：仙宗另外不收的理由（16l C4a）；lord_pay：宗主的月例（C5b1）。
    同門 +10 照角色卡的門派算（存檔時寫成成員關係，society.bonus）。回傳（角色卡, 事實）。"""
    facts = []
    if exam and verdict.rolled:
        why = bar or sect.problem(sheet, exam, clock_now, identity.level(sheet, identity.own_name(sheet), clock_now)[0])
        if why:
            facts.append(f"{exam}不收你：{why}")
        elif verdict.is_success:
            sheet, joined = sect.join(_rng(session, "sect", turn_no), sheet, exam, verdict.outcome, clock_now)
            facts += joined
        else:
            sheet = sect.fail(sheet, exam, clock_now)
            facts.append(f"沒通過{exam}的考核，一年內不會再收你")
    elif sect.leaving(sheet, place=here, factions=rows["factions"], action=verdict.action_type, words=words):
        facts.append(f"辭別了{sheet['sect']}")
        sheet = sect.leave(sheet)
    sheet, kept, _ = sect.upkeep(sheet, months=months, place=here, factions=rows["factions"], clock_now=clock_now,
                                 merit_ranks=merit_ranks, lord_pay=lord_pay)
    return sheet, facts + kept


def _realm_turn(conn, session: dict, turn_no: int, rows: dict, delta, verdict, target, npc_changes: dict, *, words: str,
                here: str, clock_now: int) -> dict:
    """仙域裡的這回合（16l）：打贏敵盟的人得戰功（C0，不看地點；戰事裡打贏對方仙宗扣同樣的點數，C3a）、
    在自家山門兌換（C2）、在造化的地點搶造化（C3b）；打退仙宗的人算戰績、散仙應招攬、每個百日看有沒有人來招攬（C4a）；
    仙戰這一輪的勝負、打完換招攬條件（C4b）；受雇、替僱主打、出戰誓到期（C4c）；立宗、宗主招收（C4d）；宗門差事（C5a）；
    宗主經營（C5b1）。回傳交易裡要寫回骨架的：credit（仙宗, 戰功）、rival（要扣戰功的仙宗）、took（搶到的造化）、
    champ（奪魁的盟, 百日）、found（立宗的計畫）、enlist（宗主招收幾人）、lord（改過的仙宗）、gone（離宗的門人）、
    pay（宗主的月例）。"""
    realm_ = repos.get_immortal(conn, session["user_id"]) or {"sects": [], "alliances": [], "seed": ""}
    if not delta.sheet["dao"] and delta.sheet["alias"] in realm_.get("daos", []):   # D1b 把道號記在化名：搬進道號（第 44 題）
        delta.sheet = {**delta.sheet, "dao": delta.sheet["alias"], "alias": ""}
    delta.sheet, facts = fall.turn(_rng(session, "fall", turn_no), realm_, delta.sheet, session["id"], clock_now)
    delta.events += facts   # 滅宗清算：自己的宗不在了、追殺與不收換人、流落的門人來投靠
    champ, before = None, delta.sheet["contest"]
    delta.sheet, wins = contest.bout(delta.sheet, target["name"] if target else "", verdict)
    if wins is not None:
        host = contest.host(realm_, before["place"])
        delta.sheet, facts = contest.finish(_rng(session, "contest-end", turn_no), realm_, delta.sheet, host, wins,
                                            clock_now)
        delta.events += facts
        champ = (host, before["period"]) if wins == len(contest.PLACES) else None
    elif before and delta.sheet["contest"] and delta.sheet["contest"]["wins"] > before["wins"]:
        delta.events.append(f"仙戰第 {before['wins'] + 1} 輪勝出")
    mine, credit, fight = delta.sheet["sect"], None, None
    rival = merit.sect_of(realm_, rows["bonds"], target["name"]) if target else ""
    beat = merit.gain(verdict) if rival else 0
    delta.sheet = {**delta.sheet, "feats": delta.sheet["feats"] + bool(beat)}
    side, job = hire.side(delta.sheet), delta.sheet["hire"]
    if side and merit.foe(realm_, side, rival) and beat and (mine or here == job["place"]):
        fight = war.at(realm_, clock_now, here, side)   # 戰事裡打贏，對方仙宗扣同樣的戰功（C3a）
        credit, rival = (side, beat), rival if fight else ""
        where = f"在{fight['kind']}之戰" if fight else ""
        if mine:   # 仙宗弟子拿戰功（也算進出戰誓）；受雇的散仙拿靈石、戰功記在僱主帳上（C4c）
            delta.sheet = oath_mod.earn({**delta.sheet, "merit": delta.sheet["merit"] + beat}, beat)
            delta.events.append(f"{where}打退{'' if fight else '敵盟的'}{target['name']}，戰功 +{beat}")
        else:
            delta.sheet = {**delta.sheet, "spirit_stones": delta.sheet["spirit_stones"] + hire.PAY}
            delta.events.append(f"替{side}{where}打退{target['name']}，得 {hire.PAY} 靈石")
    else:
        rival = ""
    if mine:
        delta.sheet, kept = oath_mod.due(delta.sheet, clock_now)
        delta.events += kept
        if here == mine + ascent.GATE:
            delta.sheet, swapped = merit.exchange(delta.sheet, words)
            delta.events += swapped
    else:
        delta.sheet, joined = recruit.accept(_rng(session, "invite", turn_no), delta.sheet, words, clock_now)
        delta.sheet, hired = hire.take(realm_, delta.sheet, here, words, clock_now)
        delta.events += joined + hired
    period = clock_now // immortal.PERIOD
    if not delta.sheet["sect"] and delta.sheet["scouted"] < period:
        levels = news.fame(rows, place=here, life=session["id"], clock_now=clock_now,
                           name=identity.public(delta.sheet, clock_now)).levels
        found = recruit.scout(_rng(session, "scout", turn_no), realm_, delta.sheet, levels, clock_now)
        delta.sheet = {**delta.sheet, "scouted": period, "invites": delta.sheet["invites"] + found}
        delta.events += [f"{'、'.join(o['sect'] for o in found)}派人來招攬，條件留 30 天"] if found else []
    boon = next((b for b in war.boons(realm_, clock_now) if b["place"] == here), None)
    ok = False
    if boon:
        delta.sheet, facts, ok = war.claim(_rng(session, "boon", turn_no), delta.sheet, boon, verdict, words)
        delta.events += facts
    if lord.own(realm_, delta.sheet, session["id"]):   # C4d 立的宗記成真傳，補成宗主（C5b1）
        delta.sheet = {**delta.sheet, "sect_rank": sect.LORD}
    delta.sheet, facts = errand.turn(_rng(session, "errand", turn_no), realm_, delta.sheet, here=here, words=words,
                                     fought=fight["place"] if mine and credit and fight else "", took=ok,
                                     elapsed=delta.clock_advance, now=clock_now)   # 宗門差事（C5a）
    delta.events += facts
    found, enlist = _found_turn(session, turn_no, rows, delta, realm_, words=words, here=here, clock_now=clock_now)
    home = lord.own(realm_, delta.sheet, session["id"])
    run = _lord_turn(session, turn_no, rows, delta, npc_changes, realm_, home, words=words, here=here,
                     clock_now=clock_now) if home else {}
    return {"credit": credit, "rival": rival, "took": boon if ok else None, "champ": champ, "found": found,
            "enlist": enlist, "refugees": session["id"] in realm_.get("refugees", {}), **run}


def _found_turn(session: dict, turn_no: int, rows: dict, delta, realm_: dict, *, words: str, here: str,
                clock_now: int) -> tuple[dict | None, int]:
    """立宗、宗主招收（16l C4d）：條件夠就回傳新仙宗的計畫（交易裡寫進骨架）、扣靈石；宗主在自家山門說招收，
    回傳要收幾人（每個百日一次）。"""
    sheet, period = delta.sheet, clock_now // immortal.PERIOD
    if any(w in words for w in founding.ENLIST_WORDS) and sheet["sect"] and here == sheet["sect"] + ascent.GATE \
            and any(s["name"] == sheet["sect"] and s.get("founder") == session["id"] for s in realm_["sects"]):
        if sheet["enlisted"] >= period:
            delta.events.append("這個百日已經招收過了")
            return None, 0
        took = roster.enlist(realm_, random.Random(0), [sheet["sect"]], founding.ENLIST)[1]
        delta.sheet = {**sheet, "enlisted": period}
        delta.events.append(f"收了{'、'.join(took)}入門" if took else "散仙裡沒有人願意入門")
        return None, len(took)
    if not any(w in words for w in founding.WORDS) or _place(rows, here).get("type") != "廢墟":
        return None, 0
    followers = sorted(set(party.names(sheet)) | {
        p["name"] for p in people.present(rows, here)
        if people.relation(rows, p["name"])["affinity"] >= founding.AFFINITY
        and not merit.sect_of(realm_, rows["bonds"], p["name"])})
    levels = news.fame(rows, place=here, life=session["id"], clock_now=clock_now,
                       name=identity.public(sheet, clock_now)).levels
    cell = founding.cell_of(realm_, here, realms.RUIN)
    why = founding.problem(sheet, levels, followers, cell)
    new = {} if why else founding.plan(_rng(session, "found", turn_no), realm_, sheet, cell, session["id"])
    if not new:
        delta.events.append(f"立宗不成：{why or '想不出沒人用過的宗名'}")
        return None, 0
    paid = {**sheet, "spirit_stones": sheet["spirit_stones"] - founding.COST}
    delta.sheet, joined = sect.join(_rng(session, "found-art", turn_no), paid, new["name"], "", clock_now)
    delta.sheet = {**delta.sheet, "sect_rank": sect.LORD}   # 遺址在交易最後改名成山門
    delta.events += [f"花了 {founding.COST} 靈石在{here}開宗立派，立起{new['name']}，自任宗主",
                     f"{'、'.join(followers)}成了開宗長老"] + joined[1:]
    return {"sect": new, "ruin": here, "followers": followers}, 0


def _lord_turn(session: dict, turn_no: int, rows: dict, delta, npc_changes: dict, realm_: dict, home: dict, *,
               words: str, here: str, clock_now: int) -> dict:
    """宗主經營（16l C5b1）：無人主持、到期的差事擲勝負、在自家山門下令（逐出、封長老、派差事）、傳位（C5b2）、
    投盟結盟與盟主的權力（C5b3）。門人的好感、傷亡放進 npc_changes；回傳交易要寫的 lord（仙宗）、gone（離宗的門人）、
    heir（繼任者）、pact（盟的補丁）、pay（月例）。"""
    rng, members = _rng(session, "lord", turn_no), _members(rows, home["name"])
    s, facts = lord.neglect(home, delta.sheet, here, clock_now)
    shifts = [(n, lord.NEGLECT) for n in members] if facts else []
    s, done, hurt, more = lord.settle(rng, s, members, clock_now)
    told, moved, gone, heir = [], [], {}, ""
    if here == home["name"] + ascent.GATE:   # 在山門：傳位（C5b2），或其他命令
        handed = lord.abdicate(s, words)
        s, told, moved, heir = handed or (s, [], [], "")
        if not handed:
            s, told, moved, gone = lord.order(rng, s, words, members, clock_now)
    if heir:   # 自己當太上長老，或離宗（不算叛宗）
        out = any(w in words for w in lord.LEAVE_WORDS)
        delta.sheet = sect.leave({**delta.sheet, "sect_oath": None}) if out \
            else {**delta.sheet, "sect_rank": sect.RETIRED}
        told.append(f"交出宗主之位，離開了{home['name']}" if out else "退居太上長老")
    pact = None
    if not heir and any(w in words for w in ("盟", "投", "宣戰", "停戰", "議和")):   # 盟（C5b3）
        lead = {b["b"]: people.relation(rows, b["a"])["affinity"] for b in rows["bonds"] if b["type"] == "首領"}
        levels = news.fame(rows, place=here, life=session["id"], clock_now=clock_now,
                           name=identity.public(delta.sheet, clock_now)).levels
        pact, said = league.act(rng, lord._put(realm_, s), s, words=words, here=here, now=clock_now, levels=levels,
                                regard=lead)
        told += said
    for name, change in shifts + more + moved:
        npc_changes.setdefault(name, {})["relation"] = npc_mod.shift(
            name, people.changed_relation(rows, npc_changes, name), change)[0]
    for name, grudge in gone.items():
        npc_changes.setdefault(name, {})["relation"] = {**people.changed_relation(rows, npc_changes, name), "grudge": grudge}
    for name, condition in hurt.items():
        npc_changes.setdefault(name, {})["state"] = {"condition": condition,
                                                     "status": "FALLEN" if condition == npc_mod.CONDITIONS[-1] else "ALIVE"}
    delta.events += facts + done + told
    return {"lord": s if s != home else None, "gone": sorted(gone), "heir": heir, "pact": pact,
            "pay": s["power"] * lord.PAY}


def _lord_view(conn, session: dict, rows: dict, sheet: dict, clock_now: int) -> dict | None:
    """畫面的「宗門」（C5b1）：宗主才有。"""
    home = lord.own(repos.get_immortal(conn, session["user_id"]) or {"sects": []}, sheet, session["id"])
    if not home:
        return None
    return lord.panel(home, _members(rows, home["name"]), clock_now)


def _hall_path(rows: dict, hall: str) -> str:
    """宗門（下界的勢力、仙域的仙宗都登錄成勢力）的道統；沒有回傳空字串。"""
    return next((f.get("traits", {}).get("道統", "") for f in rows["factions"] if hall and f["name"] == hall), "")


def _master_path(rows: dict, sheet: dict) -> str:
    """主角的師父（羈絆「師父」）所屬宗門的道統。"""
    me = {sheet["name"], identity.own_name(sheet)}
    master = next((b["a"] for b in rows["bonds"] if b["type"] == "師父" and b["b"] in me), "")
    hall = next((b["b"] for b in rows["bonds"] if master and b["a"] == master and b["type"] in society.MEMBER_BONDS), "")
    return _hall_path(rows, hall)


def _members(rows: dict, hall: str) -> dict[str, tuple[int, int]]:
    """成形、活著的門人（化身不算）→ (對這一生的好感, 境界)。"""
    alive = {p["name"]: p for p in rows["npcs"] if p["status"] == "ALIVE" and p["created_by"] != avatar.BY}
    return {n: (people.relation(rows, n)["affinity"], alive[n]["realm_lv"])
            for n in sorted(sect.members(rows["bonds"], hall)) if n in alive}


def _party_turn(session: dict, turn_no: int, rows: dict, delta, verdict, target, npc_changes: dict, opponent, *,
                words: str, here: str, clock_now: int) -> dict:
    """隨行的人（16i）：這回合邀請、僱用、解散、擒住、簽契約；戰鬥失敗時同伴受傷、擋刀；付錢、離開、逃跑。回傳角色卡。"""
    sheet, money = delta.sheet, _money(rows)
    if target:
        state = npc_changes.get(target["name"], {}).get("state") or target
        sheet, facts = party.request(sheet, target, state, people.changed_relation(rows, npc_changes, target["name"]),
                                     action=verdict.action_type, words=words, ok=verdict.is_success,
                                     place_type=_place(rows, here).get("type", ""), clock_now=clock_now, money_name=money)
        delta.events += facts
    rng = _rng(session, "party", turn_no)
    if verdict.action_type == judgment.COMBAT:
        hurt, facts = party.hurt(rng, sheet, rows["npcs"], verdict.outcome)
        for name, condition in hurt.items():
            npc_changes.setdefault(name, {})["state"] = {
                "condition": condition, "status": "FALLEN" if condition == npc_mod.CONDITIONS[-1] else "ALIVE"}
        delta.events += facts
    now = [{**p, **npc_changes.get(p["name"], {}).get("state", {})} for p in rows["npcs"]]
    relations = {m["name"]: people.changed_relation(rows, npc_changes, m["name"]) for m in sheet["party"]}
    sheet, facts = party.upkeep(rng, sheet, now, relations, clock_now=clock_now, dying=sheet["status"] == "DYING",
                                foe_lv=opponent.realm_lv if opponent and verdict.action_type == judgment.COMBAT else None,
                                money_name=money)
    delta.events += facts
    return sheet


def _market_turn(session: dict, turn_no: int, rows: dict, before: dict, delta, verdict, *, words: str,
                 clock_now: int, deal: str | None = None) -> tuple[dict, dict]:
    """黑市與奴隸商人（16i 批次二，domain/market.py）：打聽到入口與暗號；到門口對暗號；第一次進去生成經營的集團與護衛；
    在裡面動手被護衛趕出去、列黑名單；官府突襲；出門被黑吃黑；跟奴隸商人買賣人。
    回傳（換上新東西的 rows, 要寫入的新東西），角色卡改在 delta.sheet。"""
    sheet, rng, events = delta.sheet, _rng(session, "market", turn_no), delta.events
    new = {"locations": [], "connections": [], "factions": [], "traits": [], "npcs": [], "bonds": []}
    here, came = sheet["location"], before["location"]
    place, taken = _place(rows, here), _taken(rows, sheet)
    way = market.way_in(sheet, [p["realm_lv"] for p in rows["npcs"] if p["name"] in party.names(sheet)])   # 門路（16l）
    if market.asking(verdict, place.get("type", ""), words):
        found = market.places(here, way)
        new["locations"] = [{**p, "description": NEW_PLACE_DESCRIPTION, "discovered_turn": turn_no}
                            for p in found if not _place(rows, p["name"])]
        new["connections"] = [{"a": p["parent"], "b": p["name"], "tier": space.NEAR, "direction": "",
                               "distance_km": space.DISTANCE_TIERS[space.NEAR], "discovered_turn": turn_no}
                              for p in new["locations"]]
        sheet = market.learn(sheet, [p["name"] for p in found], clock_now)
        events.append(f"打聽到{'、'.join(p['name'] for p in found)}的入口和今年的暗號")
        if not way:
            events.append("還聽說城裡另有修士黑市，可惜沒有門路")
    if place.get("type") in market.ALL and came != here:   # 拍賣場照修士黑市的門檻，另外要有這一季的邀請函、開拍中
        house = place["type"] == market.HOUSE
        why = market.gate(sheet, _place(rows, place["parent"]) if house else place, clock_now, way) \
            or (auction.closed(sheet, here, clock_now) if house else "")
        if why:
            sheet, here, place = {**sheet, "location": came}, came, _place(rows, came)
            events.append(why)
        elif not house and not market.operator(rows["factions"], place):
            main = (sect.main_sect(rows["factions"]) or {}).get("name", "")
            factions, new["bonds"], people_, new["traits"] = market.found(rng, place, rows["factions"], main, taken,
                                                                         clock_now, people.local_race(rows, here))
            new["factions"] = [{**f, "discovered_turn": turn_no} for f in factions]
            new["npcs"] = [_system_npc(rng, p, place["scale"], clock_now, market.BY, turn_no) for p in people_]
    if place.get("type") in market.ALL:
        out = (f"在{here}動手，被護衛壓制、趕了出去，一年內進不來" if market.brawl(verdict.action_type, words)
               else "官府突襲黑市，你趁亂逃了出來" if place["type"] == market.MORTAL and came == here
               and rng.random() < market.RAID else "")   # 突襲只在待著的回合
        if out:
            sheet = market.ban(sheet, here, clock_now) if "護衛" in out else sheet
            sheet, here = {**sheet, "location": place["parent"]}, place["parent"]
            events.append(out)
    if _place(rows, came).get("type") in market.ALL and _place(rows, here).get("type") not in market.ALL \
            and rng.random() < market.ROBBED:
        sheet, fact = market.robbed(sheet)
        events.append(fact)
    sheet, bought, facts = _slave_trade(rng, rows, sheet, verdict.action_type, words=words, here=here,
                                        clock_now=clock_now, taken=taken, turn_no=turn_no, deal=deal)
    new["npcs"] += bought
    events += facts
    delta.sheet = sheet
    return _with_new(rows, session, new), new


@dataclasses.dataclass
class _Auction:
    """拍賣會這回合的結果（_auction_turn）：要寫的新人物、改目標的人、新線頭、結掉的線頭、記事。"""
    npcs: list = dataclasses.field(default_factory=list)
    goals: dict = dataclasses.field(default_factory=dict)
    threads: list = dataclasses.field(default_factory=list)
    closed: dict = dataclasses.field(default_factory=dict)
    notes: list = dataclasses.field(default_factory=list)


def _auction_turn(session: dict, turn_no: int, rows: dict, delta, verdict, npc_changes: dict, threads: list[dict], *,
                  words: str, here: str, retreating: bool, clock_now: int, deal: str | None = None) -> _Auction:
    """拍賣會（16i 批次三，domain/auction.py）：寄邀請函、一件一回合競標、放走買來的人、送他回家、當爐鼎。
    角色卡改在 delta.sheet；回傳要寫入的東西。"""
    sheet, rng, out, events = delta.sheet, _rng(session, "auction", turn_no), _Auction(), delta.events
    taken = _taken(rows, sheet)
    house = next((l for l in rows["locations"] if l["type"] == market.HOUSE and l["parent"] in sheet["codes"]), None)
    if house and auction.due(sheet, clock_now):
        boss = next((f for f in rows["factions"] if market.CULTIVATOR in f["traits"].get(market.KEY, ())), None)
        crew = sect.members(rows["bonds"], boss["name"]) if boss else set()
        friendly = any(people.relation(rows, n)["affinity"] >= party.INVITE_AT for n in crew & set(rows["relations"]))
        if auction.invited(sheet, friendly):
            city = _place(rows, house["parent"]).get("parent", "")
            lots = auction.lots(rng, sheet["realm_lv"], auction.homes(rows["factions"], city), taken)
            leaders = {b["a"] for b in rows["bonds"] if b["type"] == "首領"}
            pool = [p for p in rows["npcs"] if p["status"] == "ALIVE" and not npc_mod.is_minor(p, clock_now)
                    and p["name"] not in party.names(sheet) and (p["realm_lv"] >= auction.INVITE_LV or p["name"] in leaders)]
            seats = auction.bidders(rng, pool, lots)
            out.npcs = [_system_npc(rng, auction.guest(rng, house["name"], taken, people.local_race(rows, here)), market.SCALE,
                                    clock_now, auction.GUEST_BY, turn_no) for _ in range(auction.MIN_BIDDERS - len(seats))]
            seats += [auction.seat(rng, p, lots) for p in out.npcs]   # 不到 3 人補遠方來客
            sheet = {**sheet, "auction": auction.card(lots, seats, house["name"], clock_now)}
            events.append(auction.notice(sheet["auction"]))
    a = sheet["auction"]
    if a and a["house"] == here and a["season"] == auction.season(clock_now) and auction.is_open(clock_now):
        sheet = _hammer(rng, rows, sheet, out, events, words=words, here=here, clock_now=clock_now, turn_no=turn_no, deal=deal)
    for m in list(sheet["party"]):   # 放走買來的人
        home = next((f for f in rows["factions"] if f["name"] == m["home"]), None)
        if m["name"] not in words:
            continue
        sheet, freed = auction.release(sheet, m["name"], words, (home or {}).get("location", ""), clock_now)
        if freed:
            relation, _ = npc_mod.shift(m["name"], people.changed_relation(rows, npc_changes, m["name"]), auction.GRATEFUL)
            npc_changes.setdefault(m["name"], {})["relation"] = relation
            out.goals[m["name"]] = {"goal": "報恩", "goal_target": sheet["name"]}
            if home and home["location"]:
                out.threads.append(auction.home_thread(m["name"], m["home"], clock_now, turn_no))
                events += [f"放了{m['name']}，他要跟著你回{m['home']}", f"未了的事：送{m['name']}回{m['home']}"]
            else:
                events.append(f"放了{m['name']}，他千恩萬謝地走了")
    for t in threads:   # 送到了：線頭了結，那個勢力欠你人情
        m = party.member(sheet, t["subject"]) if t["kind"] == memory_mod.MY_PROMISE and t["status"] in memory_mod.ACTIVE \
            and t["session_id"] == session["id"] else None
        home = next((f for f in rows["factions"] if m and f["name"] == m["home"]), None)
        if m and home and here in (home["location"], home["name"]) and t["text"] == f"送{m['name']}回{m['home']}":
            sheet = party.drop(sheet, {m["name"]})
            out.closed[t["id"]] = {"status": memory_mod.RESOLVED, "closed_shichen": clock_now, "result_note": "送到了"}
            out.notes.append(memory_mod.note(memory_mod.SELF, sheet["name"], memory_mod.MILESTONE,
                                             f"送{m['name']}回{m['home']}，{m['home']}欠你人情",
                                             clock_now=clock_now, turn_no=turn_no))
            events.append(f"把{m['name']}送回了{m['home']}，{m['home']}欠你一份人情")
    used = auction.furnace(sheet, verdict.action_type, retreating, words)
    if used:
        sheet, changes, gained = effects.gain(sheet, {"cultivation": auction.FURNACE_GAIN})
        delta.changes += changes
        state = npc_changes.get(used, {}).get("state") or people.find(rows, used) or {"condition": "無恙"}
        hurt = npc_mod.harm(state["condition"], 1)
        npc_changes.setdefault(used, {})["state"] = {"condition": hurt,
                                                    "status": "FALLEN" if hurt == npc_mod.CONDITIONS[-1] else "ALIVE"}
        relation, _ = npc_mod.shift(used, people.changed_relation(rows, npc_changes, used), auction.FURNACE_HURT)
        npc_changes[used]["relation"] = relation
        events += [f"以{used}為爐鼎，修為大進", f"{used}{hurt}"] + gained
    delta.sheet = sheet
    return out


def _hammer(rng: random.Random, rows: dict, sheet: dict, out: _Auction, events: list[str], *, words: str, here: str,
            clock_now: int, turn_no: int, deal: str | None = None) -> dict:
    """拍下一件（一回合一件）。主角得標：東西進背包、人進隨行名單當僕人；NPC 得標的人跟著他走。"""
    a = sheet["auction"]
    if a["next"] >= len(a["lots"]):
        return sheet
    bid = auction.offer(words, deal)
    lot = a["lots"][a["next"]]
    if bid is not None and lot["kind"] == "人" and len(sheet["party"]) >= party.MAX:
        events.append(f"身邊已經跟著 {party.MAX} 個人，標不了{lot['name']}")
        bid = None
    a, lot, winner, paid = auction.hammer(a, bid, sheet["spirit_stones"])
    sheet, label = {**sheet, "auction": a}, auction.lot_text(lot)
    if not winner:
        events.append(f"{label}流拍了")
        return sheet
    events.append(f"{'你' if winner == '你' else winner}以 {paid} 塊靈石標下了{label}")
    if lot["kind"] == "人":
        buyer = here if winner == "你" else (people.find(rows, winner) or {}).get("location") or here
        p = _system_npc(rng, auction.person(lot, buyer, rng), market.SCALE, clock_now, auction.GUEST_BY, turn_no)
        out.npcs.append(p if winner == "你" else {**p, "profile": f"{p['profile']}被{winner}買下。"})
    if winner != "你":
        return sheet
    sheet = {**sheet, "spirit_stones": sheet["spirit_stones"] - paid}
    if lot["kind"] == "物":
        return items.add(sheet, lot["name"], lot["tier"])
    return party.add(sheet, lot["name"], party.SERVANT, clock_now, clock_now + clock.SHICHEN_PER_MONTH,
                     physique=lot["physique"], home=lot["home"])


def _with_new(rows: dict, session: dict, new: dict) -> dict:
    """這回合新登錄的東西放進 rows（跟 _world_rows 讀出來的樣子一致），說書人這回合就看得到。"""
    sid = session["id"]
    shown = {"npcs": [{**repos.NPC_DEFAULTS, "first_seen_session_id": sid, **p} for p in new.get("npcs", [])],
             "locations": [{**l, "discovered_session_id": sid} for l in new.get("locations", [])],
             "factions": [{**f, "discovered_session_id": sid} for f in new.get("factions", [])],
             "bonds": [{**b, "session_id": sid} for b in new.get("bonds", [])],
             "connections": [{**c, "discovered_session_id": sid} for c in new.get("connections", [])]}
    return {**rows, **{k: rows[k] + v for k, v in shown.items()}}


def _towns(rows: dict) -> list[str]:
    return [l["name"] for l in rows["locations"] if l["type"] in ("城鎮", "村落")]


def _surge(rows: dict, here: str, clock_now: int) -> float:
    """天災期間（16j）、交戰的邊境州（16k，比照天災）凡人店漲價。"""
    era_now = rows["era"]["era"]
    war = disaster.SURGE_PRICE[era_now != era.ANCIENT] if _front(rows, here) else 1
    ease = any(disaster.eased(s) and disaster.here([s], here, clock_now, _region(rows, here)) for s in rows["place_states"])   # 早有防備（模型寫的天災）
    return max(war, disaster.price(_woes(rows, here, clock_now), era_now, ease))


def _front(rows: dict, place: str) -> bool:
    """這裡是不是跟敵國交戰的邊境州（16k）。"""
    state = atlas.state_of(rows.get("atlas"), rows["connections"], place)
    return bool(state) and state["name"] in atlas.fronts(rows["atlas"])


def _border(rows: dict, start: str, here: str) -> tuple[str, str] | None:
    """路上經過的交戰兩國之間的邊關（16k：邊關封閉，硬闖算闖入）：(甲國, 乙國)；沒經過回傳 None。"""
    a = rows.get("atlas")
    route = space.shortest_path(rows["connections"], start, here) if a and start != here else None
    owner = {s["capital"]: s["nation"] for s in (a or {}).get("states", [])}
    return next(((owner[x], owner[y]) for x, y in zip(route[1], route[1][1:])
                 if x in owner and y in owner and atlas.at_war(a, owner[x], owner[y])), None) if route else None


def _scopes(rows: dict, here: str) -> list[tuple[str, str, list[str]]]:
    """天災排定的範圍：[(決定年景的名字, 整片的天災記在哪, 局部的天災落在哪幾個城鎮村落)]。
    16k：主角所在州與相鄰州（已生成的）各一份，名字與整片都是州名；舊世界一份（國名、整個區域）。"""
    a = rows.get("atlas")
    state = atlas.state_of(a, rows["connections"], here)
    if not state:
        return [(_scope_name(rows, here), "", _towns(rows))]
    where, near = atlas.state_map(a, rows["connections"]), atlas.near_states(a, state)
    return [(s["name"], s["name"], [t for t in _towns(rows) if where.get(t, a["start"]) == s["name"]])
            for s in a["states"] if s["name"] in near and s["built"]]


def _fated(session: dict, turn_no: int, rows: dict, sheet: dict, npc_changes: dict, *, start: int, end: int,
           here: str) -> tuple[dict, dict]:
    """真相分法每年的效果（第 6-5c 批，domain/truth.py）：主角所在村鎮的壓力、壽元、眾推的成員。回傳（rows, 角色卡）。"""
    n, town = len(truth.years(start, end)), space.town_of(rows["locations"], here)
    if not n or not sheet["hidden"]:
        return rows, sheet
    rng, push = _rng(session, "fated", turn_no), truth.pushes(sheet, n)
    rows = {**rows, "pressure": pressure.apply(rows["pressure"], town, push, end, FATED_WHY)} if town and push else rows
    sheet = {**sheet, "lifespan_adjust": sheet["lifespan_adjust"] + truth.lifespan(sheet, rng, n, rows["relations"])}
    names, hit = truth.members(sheet, rows["mine"], rows["bonds"], rows["life"])
    for name in names:
        npc_changes.setdefault(name, {})["relation"] = npc_mod.shift(name, people.changed_relation(rows, npc_changes, name), [hit] * n)[0]
    return rows, sheet


FATED_WHY = "命裡的事"   # 特殊命 NPC 的章收了（第 122c-6 題）：小恩、記恨的原因


CALL_HOW = {"上門": "找上門來", "傷": "負著傷找來求你", "追": "被人追著逃到你這裡", "探": "在附近打聽了你幾天，才裝作偶遇",
            "話": "託人捎話來", "信": "託人送來一樣信物，附了一句話", "急": "重傷走不動，託人捎信來求你"}   # 併章重設計第 2 題甲


def _how(rows: dict, p: dict, rel: dict, came: bool) -> str:
    """怎麼找上你（併章重設計第 2 題甲）：到了你那看傷、被追（帳上有人受託對付他、他欠債）、好感低又疑心高；
    沒到看重傷、好感友善以上留信物、不然託人帶話。"""
    chased = any(l["status"] == society.OPEN and l["b"] == p["name"] and l["kind"] in (society.HIRED, society.DEBT) for l in rows.get("ledger", []))
    if not came:
        return CALL_HOW["急" if p["condition"] == "重傷" else "信" if rel["affinity"] >= society.FRIEND_AT else "話"]
    sly = rel["affinity"] < 0 and npc_mod.trait_level(p["suspicion"]) == "高"
    return CALL_HOW["傷" if p["condition"] == "負傷" else "追" if chased else "探" if sly else "上門"]


def _faced(rows: dict, updates, npc_changes: dict, sheet: dict, templates: list[dict], *, here: str, turn_no: int, now: int) -> dict:
    """特殊命 NPC 的章以你為命主（第 122c-b 批）：收章順著他欠你一份小恩、抗著記你一筆恨、放著不留。
    找上你（併章重設計）：好感不低照宮抽支線請託、低的抽做法牌當場結算，接在怎麼來（_how）後面排進回音隊；都抽不到寫宮那句。
    記一筆 society.CALLED（下次什麼時候來）、名字放進 called（你下一章他那宮 ×2、抽中他先）。"""
    for name, end in updates.owed:
        rel = people.changed_relation(rows, npc_changes, name)
        npc_changes.setdefault(name, {})["relation"] = {
            **rel, **({"favours": favour.add(rel["favours"], favour.make(favour.OWED, favour.SMALL, FATED_WHY, now))} if end == stage.ALONG
                      else {"grudge": FATED_WHY} if end == stage.AGAINST else {})}
    rng, life = random.Random(f"{rows.get('seed', '')}:faced:{now}"), rows.get("life", "")
    for name, where, came in updates.visits:
        p = people.find(rows, name)
        if not p:
            continue
        p, rel = {**p, **updates.fields.get(name, {})}, people.changed_relation(rows, npc_changes, name)
        how, o = _how(rows, p, rel, came), sides.fated(rows, p, where, rng) if rel["affinity"] >= 0 else None
        if o:
            sheet = echo.ask(sheet, {**o, "how": how}, here, turn_no, now)
        else:
            sheet, text = deeds.fated(rows, updates, sheet, templates, name, where, now=now, rng=rng) if rel["affinity"] < 0 else (sheet, None)
            sheet = echo.add(sheet, [(f"{{人}}{how}：{text or stage.palace_line(p['hidden'], where).replace('你', '他')}", name)], here, turn_no, now)
        updates.ledger.append({**society.owed(society.CALLED, name, life, now), "status": society.DONE, "session_id": life})
        sheet = {**sheet, "called": [*(c for c in sheet.get("called", []) if c != name), name]}
    return sheet


def _omens(rows: dict, here: str, end: int) -> list[dict]:
    """模型寫的天災（progress/模型生成內容.md 第九節天災第 1、3、8 題）：主角在的那一州，前兆前一季到結束後一年之內的凡間天災。
    回傳地點狀況那一筆加 key、omen（前兆時刻）、town（事端放在哪：局部的落在受災的村鎮，整州的落在主角在的村鎮）。"""
    a, era_now, y = rows.get("atlas"), rows["era"]["era"], end // clock.SHICHEN_PER_YEAR
    mine = (atlas.state_of(a, rows["connections"], here) or {}).get("name") if a else None
    town = space.town_of(rows["locations"], here)
    out = []
    for name, region, towns in [s for s in _scopes(rows, here) if not a or s[0] == mine]:
        odds = disaster.lean(rows.get("pressure", {}), towns)
        for s in (s for yr in (y - 1, y, y + 1) if yr >= 0 for s in disaster.of_year(name, _climate_of(name), era_now, yr, towns, region, odds)):
            omen = s["started_shichen"] - newdisasters.SEASON
            if s["name"] in newdisasters.KINDS and omen >= 0 and omen - newdisasters.SEASON <= end < s["ends_shichen"] + clock.SHICHEN_PER_YEAR:
                out.append({**s, "key": newdisasters.key(s), "omen": omen, "state": name, "town": s["place"] if s["place"] in towns else town})
    return [o for o in out if o["town"]]


def _disaster_slot(conn, world_id: str, seed: str, era_now: str, o: dict) -> dict:
    """這場天災的骨架（newdisasters.plan）：動機照那村鎮第一個對得上的勢力；風味照這個世界寫過幾場輪流。"""
    facs = sorted(plots._factions(conn, world_id, repos.list_locations(conn, world_id), o["town"]), key=lambda f: f["name"])
    ftype = next((f["type"] for f in facs if newdisasters.motive(f["type"])[0]), "")
    n = sum(newdisasters.mine(plot_mod.parse(t["body"])) for t in repos.list_themes(conn, world_id, repos.PLOTS_M))
    return newdisasters.plan(random.Random(f"{seed}:disaster:{o['key']}"), o["name"], era_now, ftype, o["key"], n, seed)


def _fronts(rows: dict, here: str, end: int) -> list[dict]:
    """模型寫的戰爭（第十一節第 5 題甲）：主角所在州和相鄰州裡正在打仗的邊境州，這一年各一場。
    回傳 {key, state, nation, foe, why（起因）, town（主角在那一州才有：放在主角在的村鎮）}。"""
    a = rows.get("atlas")
    st = atlas.state_of(a, rows["connections"], here) if a else None
    if not st:
        return []
    front, nation, town = atlas.fronts(a), {s["name"]: s["nation"] for s in a["states"]}, space.town_of(rows["locations"], here)
    return [{"key": newwars.key(nation[n], front[n], end // clock.SHICHEN_PER_YEAR, n), "state": n, "nation": nation[n], "foe": front[n],
             "why": newwars.cause(rows.get("npc_reasons", []), nation[n], front[n]), "town": town if n == st["name"] else ""}
            for n in sorted(atlas.near_states(a, st)) if n in front]


def _homes(rows: dict, here: str, end: int) -> list[dict]:
    """歸鄉（第二批第 1 題乙）：主角所在州和相鄰州裡，今年議和、有人回來的州各一條（_homecoming 記的）。
    跟 _fronts 一樣的欄位，多 kind（照真的擲的）、want（回來的人演受害者，等不等的伴侶演第三者）；town 是回來那個人的村鎮。"""
    a = rows.get("atlas")
    st = atlas.state_of(a, rows["connections"], here) if a else None
    if not st:
        return []
    year, near = end // clock.SHICHEN_PER_YEAR, atlas.near_states(a, st)
    return [{**h, "state": n, "why": newwars.cause(rows.get("npc_reasons", []), h["nation"], h["foe"]),
             "town": h["town"] if n == st["name"] else "",
             "want": {h["who"]: (plot_mod.VICTIM,), **({h["with"]: ("第三者",)} if h["with"] else {})}}
            for n, h in sorted(a.get("home", {}).items()) if n in near and h["town"] and int(h["key"].split("@")[2]) == year]


def _war_slot(conn, world_id: str, seed: str, era_now: str, o: dict) -> dict:
    """這一場戰時事端的骨架（newwars.plan）：母型、風味照這個世界寫過幾場輪流；歸鄉照 o["kind"]。"""
    n = sum(newwars.mine(plot_mod.parse(t["body"])) for t in repos.list_themes(conn, world_id, repos.PLOTS_M))
    return newwars.plan(random.Random(f"{seed}:war:{o['key']}"), era_now, o["nation"], o["foe"], o["why"], o["key"], n, seed,
                        kind=o.get("kind", ""))


def _war_name(conn, world_id: str, hand: list[dict], slot: dict, o: dict) -> str:
    taken = ({t["name"] for t in repos.list_themes(conn, world_id, repos.PLOTS_M)} | {plot_mod.name(t) for t in hand}
             | {l["name"] for l in repos.list_locations(conn, world_id)})
    return newwars.name(slot, o["state"], taken)


def _disaster_name(conn, world_id: str, hand: list[dict], era_now: str, o: dict) -> str:
    taken = ({t["name"] for t in repos.list_themes(conn, world_id, repos.PLOTS_M)} | {plot_mod.name(t) for t in hand}
             | {l["name"] for l in repos.list_locations(conn, world_id)})
    return newdisasters.name(o["state"] or o["town"], o["name"], era_now, taken)


def _disaster_turn(session: dict, turn_no: int, rows: dict, updates, *, start: int, end: int,
                   here: str, sheet: dict | None = None, planned: dict | None = None) -> tuple[dict, list[dict]]:
    """這回合開始的天災、天變（16j 批次二，domain/disaster.py；年景與天災由州名〔舊世界國名〕預先排定）：寫成地點狀況、
    傳聞傳開、受災地點的凡人可能罹難（照背景演化的死亡寫）。回傳（rows, 新的地點狀況）。
    planned：放了前兆的天災（newdisasters.placed），照記下的來（壓力變了也來）；爆發前主角傳話、揭穿過的早有防備。"""
    era_now = rows["era"]["era"]
    known = {(s["name"], s["started_shichen"]) for s in rows["place_states"]}
    fresh = [s for name, region, towns in _scopes(rows, here)
             for s in disaster.starting(name, _climate_of(name), era_now, start, end, towns, region,
                                        disaster.lean(rows.get("pressure", {}), towns))
             if (s["name"], s["started_shichen"]) not in known]
    for k in planned or {}:
        name, at, place = k.split("@")
        if start < int(at) <= end and (name, int(at)) not in known | {(s["name"], s["started_shichen"]) for s in fresh}:
            fresh.append(disaster.state(disaster.BY_NAME[name], place, int(at), era_now))
    told = {c["plot"] for c in (sheet or {}).get("clues", []) if c["key"] in newdisasters.EASE}
    tags = {k: plot_mod.tag(r) for k, r in (planned or {}).items()}
    fresh = [{**s, "text": s["text"] + disaster.EASED} if tags.get(newdisasters.key(s)) in told else s for s in fresh]
    rng, dead = _rng(session, "disaster", turn_no), set()
    fresh += [disaster.fated(rng, town, y, era_now) for town, y in   # 孤星（真相分法，第 6-5c 批）
              truth.struck(sheet or {}, rng, truth.years(start, end), _towns(rows), space.town_of(rows["locations"], here) or "")]
    a, places = rows.get("atlas"), {l["name"] for l in rows["locations"]}
    capitals = {s["name"]: s["capital"] for s in (a or {}).get("states", [])}
    region = atlas.state_map(a, rows["connections"]) if a else {}
    for s in fresh:
        where, what = s["place"] or "這一帶", disaster.label(s["name"], era_now)
        updates.events.append(f"天災：{where}{s['text']}")
        updates.rumors.append(rumors.make(rumors.DISASTER, where, when=s["started_shichen"], detail=s["text"],
                                          place=s["place"] if s["place"] in places else capitals.get(
                                              s["place"], (_towns(rows) or [""])[0])))
        here_now = [{**p, "region": region.get(p["location"], (a or {}).get("start"))} for p in rows["npcs"]
                    if p["name"] not in dead and p["location"] != evolution.AWAY]   # 遠方的人不算
        for name in disaster.victims(rng, s, here_now, era_now):
            dead.add(name)
            updates.fields.setdefault(name, {}).update(status="FALLEN", condition=npc_mod.CONDITIONS[-1])
            updates.world_notes.append(memory_mod.note(memory_mod.NPC, name, memory_mod.DEATH, f"死於{what}",
                                                       clock_now=s["started_shichen"], turn_no=turn_no))
    updates.dead |= dead
    npcs = [{**p, "status": "FALLEN", "condition": npc_mod.CONDITIONS[-1]} if p["name"] in dead else p
            for p in rows["npcs"]]
    return {**rows, "place_states": rows["place_states"] + fresh, "npcs": npcs}, fresh


def _relief(rows: dict, delta, verdict, target: dict | None, npc_changes: dict, disasters: list, *, words: str,
            here: str, who: str, life: str, clock_now: int) -> list[dict]:
    """救災（16j 第 5 題）：在場凡人記一筆幫忙、傳開成「賑災」（名聲往仁善）；瘟疫期間點名清心丹救治對象：
    用掉一顆，他記一筆救命。改的是 delta 與 npc_changes；回傳傳聞。"""
    if not disaster.relief(disasters, verdict, words):
        return []

    def warm(name: str, hits: list) -> list[str]:
        relation, events = npc_mod.shift(name, people.changed_relation(rows, npc_changes, name), hits)
        npc_changes.setdefault(name, {})["relation"] = relation
        return events

    for p in people.present(rows, here):
        if p["realm_lv"] == 0:
            warm(p["name"], disaster.RELIEF_HIT)
    delta.events.append("賑濟災民，在場的百姓都記著這份情")
    tier = min((e["tier"] for e in delta.sheet["items"] if e["name"] == items.CALM_PILL), default=None)
    if target and tier is not None and disaster.PLAGUE in disasters and items.CALM_PILL in words:
        delta.sheet = items.remove(delta.sheet, items.CALM_PILL, tier)
        delta.events += [f"用一顆{items.label(items.CALM_PILL, tier)}救治了{target['name']}",
                         *warm(target["name"], disaster.CURE_HIT)]
    return [rumors.make(rumors.RELIEF, who, place=here, when=clock_now, subject_lv=delta.sheet["realm_lv"], life=life)]


CONSCRIPT = 0.1   # 交戰的每一年，邊境州的凡人被徵兵的機率（16k，暫定）


def _proxy(session: dict, turn_no: int, rows: dict, updates, sheet: dict, verdict, target, relation, words: str, *,
           here: str, start: int, end: int, deal: str | None = None) -> tuple[dict, list[str], dict | None]:
    """借刀與懸賞（16l 第 6-3 題，domain/proxy.py）：帳上記受託（算成仇家）交給世界脈動；回傳（角色卡, 事件, 新貼的懸賞）。"""
    events, helper = [], (target or {}).get("name", "")
    foe = proxy.named(words, rows["npcs"], {sheet["name"], helper})
    deal = proxy.ask(verdict, words, helper, (relation or {}).get("affinity", 0), foe, sheet["money"], deal)
    if deal:
        updates.ledger.append(proxy.feud(helper, foe["name"], end))
        sheet, events = {**sheet, "money": sheet["money"] - deal[0]}, [deal[1]]
    posted = proxy.post(here, _place(rows, here).get("type", ""), words, foe, sheet["money"], end)
    if posted:
        sheet = {**sheet, "money": sheet["money"] - posted[1]}
        events.append(f"在{here}貼出懸賞捉拿{foe['name']}，付了 {posted[1]} 賞金")
    months = end // clock.SHICHEN_PER_MONTH - start // clock.SHICHEN_PER_MONTH
    wanted = proxy.open_bounties(rows["place_states"], rows["bonds"], end)
    for taker, name in proxy.takers(_rng(session, "bounty", turn_no), wanted, rows["npcs"], months):
        updates.ledger.append(proxy.feud(taker, name, end))
        events.append(f"有人揭了懸賞：{taker}去找{name}了")
    return sheet, events, posted[0] if posted else None


def _statecraft(rows: dict, updates, *, start: int, end: int, skip: set[str]) -> dict:
    """國與國（16k 批次四；第 7-3b2 批改由 game/nations 每年判）：跨過的每一年判一次（最多最近二十年）；變了是傳遍天下的大事；
    交戰的每一年，邊境州的凡人一成被徵兵（去了遠方）。回傳換上新骨架的 rows（交易裡寫回）。"""
    a = rows.get("atlas")
    if not a:
        return rows
    years = range(max(a.get("year", start // clock.SHICHEN_PER_YEAR) + 1, end // clock.SHICHEN_PER_YEAR - atlas.MAX_YEARS + 1),
                  end // clock.SHICHEN_PER_YEAR + 1)
    where = atlas.state_map(a, rows["connections"])
    for year in years:
        when, before = year * clock.SHICHEN_PER_YEAR, atlas.stances(a)
        a, news, told = nations.year(rows, updates, a, when)
        updates.events += [f"國事：{t}" for _, t in news]
        updates.rumors += [rumors.make(rumors.AFFAIRS, n, place=a["states"][0]["capital"], when=when, detail=t)
                           for n, t in news + told]
        a = _homecoming(rows, updates, a, before, when)
        front, drafted = atlas.fronts(a), dict(a.get("drafted", {}))
        rng = random.Random(f"{a['seed']}:conscript:{year}")
        for p in rows["npcs"]:
            if p["status"] == "ALIVE" and p["realm_lv"] == 0 and where.get(p["location"]) in front \
                    and p["name"] not in set(updates.fields) | skip and rng.random() < CONSCRIPT:
                updates.fields[p["name"]] = {"location": evolution.AWAY, "away_since": when, "away_from": p["location"]}
                updates.world_notes.append(memory_mod.note(memory_mod.NPC, p["name"], memory_mod.NEWS, "被徵去打仗",
                                                           clock_now=when, turn_no=0))
                drafted[p["name"]] = [where[p["location"]], front[where[p["location"]]]]   # 議和時回家（第二批第 1 題乙）
        a = {**a, "drafted": drafted}
    return {**rows, "atlas": a}


def _homecoming(rows: dict, updates, a: dict, before: dict, when: int) -> dict:
    """議和那年（第十一節第二批第 1 題乙）：被那場仗徵走、還在遠方的人全部回家；有人回來的州記一條歸鄉（atlas 的 home：
    州 → 鑰匙、回來的人、家在哪個村鎮、照真的擲的母型、伴侶），主角在那一州時 _homes 放。"""
    nation = {s["name"]: s["nation"] for s in a["states"]}
    peace = {k for k, s in before.items() if s == atlas.WAR and atlas.stances(a).get(k) != atlas.WAR}
    back = {n: v for n, v in a.get("drafted", {}).items() if atlas._key(nation.get(v[0], ""), v[1]) in peace}
    if not back:
        return a
    by, home = {p["name"]: p for p in rows["npcs"]}, dict(a.get("home", {}))
    for name, (state, foe) in sorted(back.items()):
        p = by.get(name)
        if not p or p["status"] != "ALIVE" or p["location"] != evolution.AWAY or not p.get("away_from"):
            continue   # 死了、早就自己回來了
        updates.fields.setdefault(name, {}).update(location=p["away_from"], away_since=None, away_from="")
        updates.world_notes.append(memory_mod.note(memory_mod.NPC, name, memory_mod.NEWS, "打完仗回來了", clock_now=when, turn_no=0))
        k = newwars.key(nation[state], foe, when // clock.SHICHEN_PER_YEAR, state, "歸")
        if home.get(state, {}).get("key") != k:   # 每州一條，第一個回來的人
            home[state] = {"key": k, "nation": nation[state], "foe": foe, "who": name,
                           "town": space.town_of(rows["locations"], p["away_from"]), **_came_home(rows, p)}
    return {**a, "home": home, "drafted": {n: v for n, v in a["drafted"].items() if n not in back}}


def _came_home(rows: dict, p: dict) -> dict:
    """家裡變了什麼（第二批第 2 題甲，照真的擲）：他走了以後親人死了＝物是人非；有活著的伴侶＝等不等；都沒有＝被佔。"""
    by = {q["name"]: q for q in rows["npcs"]}
    ties = [(b["a"] if b["b"] == p["name"] else b["b"], b["type"]) for b in rows["bonds"]
            if p["name"] in (b["a"], b["b"]) and b["type"] in plot_mod.KIN]
    if any(by.get(n, {}).get("status") == "FALLEN" and (by[n].get("evolved_shichen") or 0) >= (p.get("away_since") or 0)
           for n, kind in ties if kind == "親人"):
        return {"kind": "物是人非", "with": ""}
    mate = next((n for n, kind in ties if kind == "伴侶" and by.get(n, {}).get("status") == "ALIVE"), "")
    return {"kind": "等不等" if mate else "被佔", "with": mate}


def _scope_name(rows: dict, place: str) -> str:
    """決定天氣、氣候、年景的名字：州名（16k）；舊世界是國名（存檔讀回來世界種子會換，名字不會）；都沒有＝空字串。"""
    return _region(rows, place) or (crime.nation(rows["factions"]) or {}).get("name", "")


def _climate_of(name: str) -> str:
    return weather.climate(name) if name else weather.DEFAULT_CLIMATE   # 舊世界沒有國家就是溫和


def _climate(rows: dict, place: str) -> str:
    return _climate_of(_scope_name(rows, place))


def _sky(rows: dict, clock_now: int, place: str) -> str:
    return weather.today(_scope_name(rows, place), _climate(rows, place), clock_now)


def _far(rows: dict, start: str, here: str) -> tuple[set[str], set[str]]:
    """背景演化的範圍（16k）：回傳（遠方州的人＝不在所在州與相鄰州, 這回合走進另一州時那一州的人）。去了遠方的人照舊算。"""
    a = rows.get("atlas")
    state = atlas.state_of(a, rows["connections"], here)
    if not state:
        return set(), set()
    where, near = atlas.state_map(a, rows["connections"]), atlas.near_states(a, state)
    of = {p["name"]: where.get(p["location"], a["start"]) for p in rows["npcs"] if p["location"] != evolution.AWAY}
    moved = where.get(start, a["start"]) != state["name"]
    return ({n for n, s in of.items() if s not in near},
            {n for n, s in of.items() if moved and s == state["name"]})


def _region(rows: dict, place: str) -> str:
    """所在的州名（16k；舊世界空字串）。"""
    return (_realm(rows, place) or ["", ""])[1]


def _woes(rows: dict, place: str, clock_now: int) -> list:
    """此地進行中的天災、天變（16j；16k 起整片的天災記在州名）。"""
    return disaster.here(rows["place_states"], place, clock_now, _region(rows, place))


def _scene(rows: dict, sheet: dict, place_type: str, place: str, clock_now: int, happened: set[str]) -> dict:
    """眼前的情況（現象的條件，第 3b-1 步第二批）：地點、季節、時辰、族、道統，加上天氣、氣候、這一州的地勢、天災、這回合的事。"""
    a, region = rows.get("atlas"), _region(rows, place)
    return laws.scene(sheet, place_type, clock_now, 天氣=_sky(rows, clock_now, place), 氣候=_climate(rows, place),
                      地勢=newitems.land(a["seed"], region) if a and region else "",
                      災={k.name for k in _woes(rows, place, clock_now)},
                      事=happened | ({"戰事"} if _front(rows, place) else set()))


def _seen(rows: dict, sheet: dict, here: str, life: str, clock_now: int):
    """這個人認不認得出主角是他族（16u 族徵）：易容遮得住；當地傳開了就都認得；藏著的時候同族和高手看得穿。"""
    hidden = identity.disguised(sheet, clock_now)
    known = not hidden and form.exposed(rows["place_states"], space.town_of(rows["locations"], here), sheet["name"], clock_now)
    return lambda p: known or races.shown(sheet, viewer=p["name"], life=life, disguised=hidden,
                                          sharp=p.get("race") == sheet["race"] or p.get("realm_lv", 0) > sheet["realm_lv"])


def _stranger(rows: dict, sheet: dict, here: str, life: str, clock_now: int):
    """初見時認出主角是他族，好感扣多少（16k）：看種族關係；所在國的國法「包容」不扣。狐族看尾數知輩分（16u 族徵）。"""
    tolerant = (_law(rows, here) or {}).get("traits", {}).get(crime.OTHERS) == races.TOLERANT
    seen = _seen(rows, sheet, here, life, clock_now)
    return lambda p: races.senior(sheet, p) + races.first_view(sheet["race"], p.get("race", races.HUMAN), tolerant=tolerant, seen=seen(p))


def _gap(rows: dict, sheet: dict, here: str, life: str, clock_now: int):
    """初見看地位（第 7-1c 批）：他的地位 − 你的。"""
    me, of = people.standing(rows, sheet, here, life, clock_now)
    return lambda p: of(p) - me


def _records(verdict: judgment.Judgment, dead: set[str], care, helped: list, h) -> list[str]:
    """這回合的重大紀錄（16v 第 15 題）：牌的權重一直看。"""
    return [*([cards.KILLED] if dead and verdict.action_type == judgment.COMBAT else []), *([cards.BROKE] if care.broken else []),
            *([cards.SAVED] if helped or h.rested else [])]


def _form_turn(session: dict, turn_no: int, rows: dict, before: dict, sheet: dict, verdict: judgment.Judgment, here: str, text: str,
               dead: set[str], npc_changes: dict, clock_now: int) -> tuple[dict, list[str], dict | None]:
    """族徵（16u 族徵）：藥效到期、玩家下令收放、壓不住現形。回傳（角色卡, 事實, 當地傳開的地點狀況）。
    從藏著變成露著時，在場的外族都認出來，已經認識的人好感照種族關係扣。"""
    was_open = races.visible(sheet)
    sheet, facts = form.tick(sheet, clock_now)
    wish = form.order(text) if sheet["race"] != races.HUMAN else None
    if wish is not None:
        sheet, fact = form.command(sheet, wish)
        facts.append(fact)
    close = party.names(sheet) | {p["name"] for p in rows["npcs"] if p["created_by"] == home.FAMILY_BY}
    if sheet["status"] == "ALIVE" and form.slipped(_rng(session, "form", turn_no), before, sheet,
                                                   fumbled=verdict.outcome == judgment.GREAT_FAILURE, mourning=bool(close & dead),
                                                   fought=verdict.action_type == judgment.COMBAT):
        sheet = form.slip(sheet, clock_now)
        facts.append(f"你壓不住了，{'、'.join(lineage.features(sheet)[:2])}現了出來")
    crowd = [p for p in people.present(rows, here) if p.get("race", races.HUMAN) != sheet["race"] and p["name"] not in dead]
    if was_open or not races.visible(sheet) or not crowd or identity.disguised(sheet, clock_now):
        return sheet, facts, None
    tolerant = (_law(rows, here) or {}).get("traits", {}).get(crime.OTHERS) == races.TOLERANT
    for p in crowd:
        if p["name"] in rows["relations"]:
            drop = races.first_view(sheet["race"], p.get("race", races.HUMAN), seen=True, tolerant=tolerant)
            npc_changes.setdefault(p["name"], {})["relation"] = npc_mod.shift(
                p["name"], people.changed_relation(rows, npc_changes, p["name"]),
                opinion.near(opinion.RACE, opinion.LIKE, drop))[0]
    return sheet, facts + ["在場的人都看見了"], _exposed(rows, sheet, here, clock_now)


def _exposed(rows: dict, sheet: dict, here: str, clock_now: int) -> dict | None:
    """當地傳開（已經傳開就不再記）。"""
    town = space.town_of(rows["locations"], here)
    if form.exposed(rows["place_states"], town, sheet["name"], clock_now):
        return None
    return form.exposed_state(town, sheet["name"], sheet["race"], incident.WORLD, clock_now)


def _told(rows: dict, sheet: dict, met: dict, here: str, life: str, clock_now: int) -> dict | None:
    """藏著的時候被初見的人看穿：同族和交情好的不說，其他人傳出去（16u 族徵第 4 題）。"""
    if sheet["race"] == races.HUMAN or races.visible(sheet):
        return None
    seen = _seen(rows, sheet, here, life, clock_now)
    gossip = any(form.tells(sheet["race"], p.get("race", races.HUMAN), met[p["name"]]["affinity"]) and seen(p)
                 for p in rows["npcs"] if p["name"] in met)
    return _exposed(rows, sheet, here, clock_now) if gossip else None


def _alien(rows: dict, sheet: dict, law: dict | None, here: str, *, life: str, clock_now: int) -> bool:
    """排外的國，他族這回合進城被認出＝無照入境（16k）；帶著假路引不算。"""
    nation_race = (rows.get("atlas") or {}).get("nations", {}).get((law or {}).get("name"), races.HUMAN)
    return (here != sheet["location"] and _place(rows, here).get("type") in crime.BUSY
            and (law or {}).get("traits", {}).get(crime.OTHERS) == races.HOSTILE and sheet["race"] != nation_race
            and not market.papered(sheet, clock_now)
            and _seen(rows, sheet, here, life, clock_now)({"name": here, "race": nation_race}))


def _realm(rows: dict, place: str) -> list[str]:
    """[國, 州]（16k；舊世界是空的）。"""
    state = atlas.state_of(rows.get("atlas"), rows["connections"], place)
    return [state["nation"], state["name"]] if state else []


def _law(rows: dict, place: str) -> dict | None:
    """這個地方屬於哪一國（16k：沿路找所在的州；舊世界只有一國）。"""
    state = atlas.state_of(rows.get("atlas"), rows["connections"], place)
    return crime.nation(rows["factions"], state["nation"] if state else "")


def _shop_extra(rows: dict, here: str) -> tuple:
    """凡人黑市的集團跟本山有私交：法器流進來（16i 第 10-2 題）。"""
    main = (sect.main_sect(rows["factions"]) or {}).get("name", "")
    place = _place(rows, here)
    rare = (items.FORM_PILL,) if place and place["type"] in items.FORM_SHOPS and people.local_race(rows, here) == races.BEAST else ()
    if not place or not market.allied(rows["factions"], rows["bonds"], place, main):
        return rare
    return rare + tuple(n for n, i in items.CATALOG.items() if i.kind == items.ARTIFACT)


def _write_found(conn, session: dict, new: dict) -> None:
    """黑市這回合新登錄的地點、路、集團、護衛、買來的人、羈絆（_market_turn）。"""
    world, sid = session["world_id"], session["id"]
    for loc in new["locations"]:
        repos.insert_location(conn, world, sid, loc)
    for edge in new["connections"]:
        repos.insert_connection(conn, world, sid, edge)
    for f in new["factions"]:
        repos.insert_faction(conn, world, sid, f)
    for name, traits in new["traits"]:
        repos.set_traits(conn, world, name, traits)
    for p in new["npcs"]:
        repos.insert_npc(conn, world, sid, p)
    for b in new["bonds"]:
        repos.insert_bond(conn, world, sid, b)


def _slave_trade(rng: random.Random, rows: dict, sheet: dict, action: str, *, words: str, here: str, clock_now: int,
                 taken: set[str], turn_no: int, deal: str | None = None) -> tuple[dict, list[dict], list[str]]:
    """奴隸商人（16i 第 9 題）：販賣人口無罪的國家在坊市，有罪的只在黑市。賣俘虜、僕人換錢；買一個成年的僕人。
    回傳（角色卡, 要寫入的新人物, 事實）。"""
    deal = market.trading(action, words, deal)
    legal = crime.code(crime.traits_of(_law(rows, here)))[crime.TRAFFIC] == 0
    if not deal or not market.slavers(_place(rows, here).get("type", ""), legal):
        return sheet, [], []
    money = _money(rows)
    if deal == "賣":
        goods = [m for m in sheet["party"] if m["role"] in (party.CAPTIVE, party.SERVANT)]
        sold = next((m for m in goods if m["name"] in words), goods[0] if goods else None)
        if sold is None:
            return sheet, [], ["身邊沒有可以賣給奴隸商人的人"]
        cash, stones = market.price((people.find(rows, sold["name"]) or {}).get("realm_lv", 0))
        sheet = {**party.drop(sheet, {sold["name"]}), "money": sheet["money"] + cash,
                 "spirit_stones": sheet["spirit_stones"] + stones}
        return sheet, [], [f"把{sold['name']}賣給了奴隸商人，得到 {cash} {money}、{stones} 塊靈石"]
    if len(sheet["party"]) >= party.MAX:
        return sheet, [], [f"身邊已經跟著 {party.MAX} 個人，帶不了更多"]
    if sheet["money"] < market.BUY_COST:
        return sheet, [], [f"買一個人要 {market.BUY_COST} {money}，錢不夠"]
    person = _system_npc(rng, market.bought(rng, here, taken, people.local_race(rows, here)), market.SCALE, clock_now,
                         market.BY, turn_no)
    sheet = party.add({**sheet, "money": sheet["money"] - market.BUY_COST}, person["name"], party.SERVANT, clock_now,
                      clock_now + clock.SHICHEN_PER_MONTH)
    return sheet, [person], [f"花了 {market.BUY_COST} {money}，從奴隸商人手上買下{person['name']}當僕人"]


def _meddle(rows: dict, updates, npc_changes: dict, verdict, target, intent: judgment.Intent, sheet: dict, *,
            here: str, life: str, now: int) -> list[str]:
    """對某勢力的人交談（第 7-3b1b2 批，factions.meddle、gossip）：套話成了多知道他那個勢力的好惡；
    說服時讀懂挑了挑撥撮合調停、說到另一個勢力，照規則寫勢力之間的原因。挑撥沒成，他對你記一筆小的壞原因。"""
    f = factions.home(rows, target["name"]) if verdict is not None and target else ""
    got = {c.target: c.outcome for c in verdict.all_checks} if f else {}
    win = (judgment.SUCCESS, judgment.GREAT_SUCCESS)
    if got.get(judgment.PRY) in win:
        return [f"從{target['name']}的話裡聽出：{x}" for x in factions.gossip(rows, updates, f, now)]
    if judgment.PERSUADE not in got:
        return []
    me, of = people.standing(rows, sheet, here, life, now)
    line = factions.meddle(rows, updates, f, intent.faction, intent.ploy, got[judgment.PERSUADE] in win,
                           likes=lambda n: people.changed_relation(rows, npc_changes, n)["affinity"],
                           me=me, of=of, lv=sheet["realm_lv"], now=now)
    if line != factions.STIR:
        return [line] if line else []
    rel, said = npc_mod.shift(target["name"], people.changed_relation(rows, npc_changes, target["name"]),
                              [opinion.hit(factions.STIR, opinion.LIKE, opinion.SMALL, -1)])
    npc_changes.setdefault(target["name"], {})["relation"] = rel
    return [f"{target['name']}聽出你在挑撥", *said]


def _witness(rows: dict, updates, npc_changes: dict, verdict, target, frame: str = "", **at) -> None:
    """誰知道（第 1-5a 批）：這回合殺人、傷人、救命記成一件事，在場的人知道；之前的秘密照關係傳開。frame：嫁禍給哪個勢力（第 7-3b1b2 批）。"""
    if verdict is not None and target and any(c.target == judgment.STRIKE for c in verdict.all_checks):
        killed = npc_changes[target["name"]]["state"]["status"] == "FALLEN"
        news.witness(rows, updates, npc_changes, kind=hearsay.KILL if killed else hearsay.HURT, target=target["name"], lv=target["realm_lv"],
                     frame=frame, **at)
    for name in sorted(n for n, c in npc_changes.items()
                       if any(r["kind"] == opinion.SAVE and r["value"] > 0 for r in (c.get("relation") or {}).get("adds", []))):
        news.witness(rows, updates, npc_changes, kind=hearsay.SAVE, target=name, **at)
    news.spread(rows, updates, npc_changes, life=at["life"], now=at["now"])


def _kin(rows: dict, sheet: dict) -> set[str]:
    """初次見面時多同門固定加減的人（16h；認識的人存檔後由 society.bonus 算）。"""
    return sect.members(rows["bonds"], sheet["sect"]) if sheet["sect"] else set()


MORTAL_PLACES = ("城鎮", "村落", "坊市")   # 背景裡的修士在這些地方交手，曝光度 +1（16e.1 第 7 題）


def _crime_and_exposure(session: dict, turn_no: int, rows: dict, sheet: dict, delta, updates, verdict, target,
                        npc_changes: dict, *, who: str, seen: str, here: str, player_input: str,
                        clock_now: int) -> tuple[dict, dict, bool]:
    """國法（16h）：認出這回合的罪（要有人看見；小罪要判定失敗），罰金級當場罰、其餘加通緝（記在這一國）；
    跟官差行賄；偷竊得手得錢；人前出手破易容；曝光度累積、滿了翻轉處境（16e.1）。
    who：這回合對外的名字（易容中犯案記在「一個陌生人」）。回傳（角色卡, rows, 處境翻了沒）。"""
    after, place_type = delta.sheet, _place(rows, here).get("type", "")
    law = _law(rows, here)
    traits, country, money = crime.traits_of(law), (law or {}).get("name", ""), _money(rows)
    hit = target is not None and any(c.target == judgment.STRIKE for c in verdict.all_checks)
    killed = hit and npc_changes.get(target["name"], {}).get("state", {}).get("status") == "FALLEN"
    unmasked = identity.broken(after, clock_now, action=verdict.action_type, place_type=place_type)
    if unmasked:
        after = {**after, "disguise": None}
        delta.events.append("在人前施展修為，易容破了")
    others = [p for p in people.present(rows, here) if p["name"] != (target or {}).get("name")]
    scene = crime.Scene(
        action=verdict.action_type, failed=verdict.rolled and not verdict.is_success, words=player_input,
        place_type=place_type, place_name=here, target=target is not None, hit=hit, killed=killed,
        witnessed=bool(seen) or place_type in crime.BUSY or bool(others) or (target is not None and not killed),
        defending=target is not None and visitors.reason(target, sheet["name"]) in visitors.HOSTILE_REASONS,
        official=target is not None and (target.get("created_by") == era.OFFICIAL_BY or place_type == crime.COURT),
        cultivator=target is not None and target["realm_lv"] >= 1 and sheet["realm_lv"] >= 1,
        own_home=here == sheet["home"] or sect.own_room(sheet, _place(rows, here)), spotted=seen == era.HUNTED,
        unmasked=unmasked and not market.papered(after, clock_now),   # 帶著假路引不算易容入城（16i）
        alien=_alien(rows, sheet, law, here, life=session["id"], clock_now=clock_now),
        smuggled=bool(_border(rows, sheet["location"], here)) and not avoid.detour(player_input))   # 繞開邊關（16l）
    found = crime.offences(scene)
    if found and not hit:   # 誰知道（第 1-5a 批）：殺人、傷人另記
        news.witness(rows, updates, npc_changes, kind=hearsay.CRIME, life=session["id"], who=who, target=(target or {}).get("name", ""),
                     here=here, now=clock_now, turn_no=turn_no, crimes=found)
    rng = _rng(session, "crime", turn_no)
    if crime.bribing(scene):
        if crime.bribe_taken(rng, verdict.is_success, traits):
            after, fact = identity.bribe(after, clock_now, money)
            delta.events += [fact] if fact else []
        elif scene.witnessed:
            found.append(crime.BRIBE)
    if crime.got_away(scene, verdict.is_success):   # 偷竊得手
        after, changes, gained = effects.gain(after, incident.amounts(incident.GAIN_MONEY, after, rng))
        delta.changes += changes
        delta.events += gained
    me, of = people.standing(rows, sheet, here, session["id"], clock_now)
    up = target is not None and rank.upward(me, of(target)) and any(c in crime.PERSON for c in found)   # 以下犯上（第 7-1c 批）
    delta.events += ["以下犯上，罪加一等"] if up else []
    fines, amount, blood = crime.punish(crime.heavier(crime.code(traits), found) if up else crime.code(traits), found)
    if fines:
        after, fact = identity.charge(after, fines, who, clock_now, nation=country, money_name=money)
        delta.events.append(fact)
    if amount:
        after = identity.accuse(after, who, amount, clock_now, blood=blood, nation=country)
        updates.rumors.append(rumors.make(rumors.WANTED, who, place=here, when=clock_now, detail="、".join(found)))
        if who != identity.STRANGER:
            delta.events.append(f"在{here}犯了{'、'.join(found)}，被{country or '官府'}通緝")
    if target is not None and not killed and set(found) & set(crime.PETTY):   # 被害的人當場抓到你
        public = bool(people.present_names(rows, here) - {target["name"]})
        relation, events = npc_mod.shift(target["name"], people.changed_relation(rows, npc_changes, target["name"]),
                                         npc_mod.CAUGHT_PUBLIC if public else npc_mod.CAUGHT)
        npc_changes.setdefault(target["name"], {})["relation"] = relation
        delta.events += events
    for name in party.appalled(after, rows["npcs"], found):   # 善念高的同伴看不下去（16i 第 4 題）
        relation, events = npc_mod.shift(name, people.changed_relation(rows, npc_changes, name), party.APPALLED)
        npc_changes.setdefault(name, {})["relation"] = relation
        delta.events += events
    after = _sect_rules(rows, sheet, after, scene, found, npc_changes, target, delta, here=here, clock_now=clock_now)
    # 護短的門派：外人打傷它的人，派一個人來討公道（16h）
    provoked = sect.protected(rows["factions"], rows["bonds"], target["name"], sheet["sect"]) \
        if hit and not scene.defending else ""
    fights = sum(r["kind"] in (rumors.KILL, rumors.WOUND, rumors.HURT) and _place(rows, r["place"]).get("type") in
                 MORTAL_PLACES for r in updates.rumors)   # 這時候還只有背景演化的傳聞
    if _place(rows, here).get("type") in MORTAL_PLACES:   # 脫節的人在凡人地方引人側目（第 8-3-2 題甲）
        odd = character_mod.lost(sheet, rows["era"], clock_now) + sum(era.behind(p, rows["era"]) for p in people.present(rows, here))
        rng = _rng(session, "odd", turn_no)
        fights += sum(rng.random() < era.ODD for _ in range(odd))
    card, flipped = identity.expose(rows["era"], _rng(session, "expose", turn_no), (seen == era.HIDDEN) + fights)
    if flipped:
        delta.events.append(f"修士的事再也藏不住了，世道轉為「{card['stance']}」")
    return after, {**rows, "era": card}, flipped, provoked


def _sect_rules(rows: dict, sheet: dict, after: dict, scene: crime.Scene, found: list[str], npc_changes: dict,
                target: dict | None, delta, *, here: str, clock_now: int) -> dict:
    """宗規與叛門（16h 第三批，domain/sect.py）：要有同門看見——人在自己門派的地方、同門在場，或被害的同門還活著；
    國法的殺人、邪術照算；被國家通緝到 2 級＝辱沒門楣；跟敵對勢力的人結交到親近＝私投敵派。sheet：回合開始時的角色卡。"""
    hall = sheet["sect"]
    if not hall or not after["sect"]:
        return after
    halls, kin = sect.family(rows["factions"], rows["bonds"], hall), sect.kin(rows["factions"], rows["bonds"], hall)
    victim = target["name"] if target else ""
    territory = here in halls or _place(rows, here).get("parent") in halls
    seen = territory or bool((people.present_names(rows, here) - {victim}) & kin) or (victim in kin and not scene.killed)
    own = identity.own_name(sheet)
    close = npc_mod.AFFINITY_TIERS[0][0]
    befriended = {n for n, c in npc_changes.items() if "relation" in c
                  and people.relation(rows, n)["affinity"] < close <= c["relation"]["affinity"]}
    stole = scene.failed and crime.said(scene, crime.THEFT)
    found = sect.offences(
        hit=scene.hit and seen, killed=scene.killed, defending=scene.defending, kin_target=victim in kin,
        elder_target=target is not None and sect.elder(target, rows["bonds"]),
        cheat=seen and scene.failed and (stole or crime.said(scene, crime.FRAUD)),
        loot=seen and stole and scene.action == judgment.STEALTH and territory and victim not in kin, national=found,
        disgraced=identity.level(sheet, own, clock_now)[0] < 2 <= identity.level(after, own, clock_now)[0],
        defected=bool(befriended & sect.enemies(rows["factions"], rows["bonds"], hall)))
    top = next((f for f in rows["factions"] if f["name"] == sect.owner(rows["factions"], rows["bonds"], hall)), None)
    after, facts, _ = sect.punish(after, found, crime.traits_of(top), clock_now)   # 除名、叛門：成員關係存檔時拿掉，同門 +10 跟著沒了
    delta.events += facts
    return after


def _money(rows: dict) -> str:
    """這個時代凡人錢的名稱（經濟第二輪）。"""
    return era.MONEY[rows["era"]["era"]]


def _trip_km(rows: dict, start: str, here: str) -> int:
    """這回合走了多遠（路上事件的機率，地圖第二輪）：沒移動、在同一個村鎮裡走動是 0；尋路找到的新地方還沒有路線，算半日路程。"""
    if start == here or here in space.within(rows["locations"], start):
        return 0
    route = space.shortest_path(rows["connections"], start, here)
    return route[0] if route else space.DISTANCE_TIERS[space.HALF_DAY]


def _place_info(rows: dict, name: str, clock_now: int) -> str:
    """給說書人的所在地資訊：類型、危險度、描述、此地狀況（第 9b 步）、相連的地點。"""
    place = _place(rows, name)
    race = people.local_race(rows, name)
    tags = "，".join(x for x in ("".join(_realm(rows, name)), rows.get("atlas") and f"{race}的地盤",
                                 _front(rows, name) and "與敵國交戰的邊境",
                                 names.label(era.label(place.get("type", ""), rows["era"]), race),
                                 place.get("danger") and f"危險度{place['danger']}") if x)
    near = "、".join(f"{n['name']}（{n['tier']}）" for n in space.neighbors(rows["connections"], name))
    states = "；".join(_signs(rows, name, clock_now))
    nation = (_realm(rows, name) or [""])[0]
    told = (rows.get("atlas") or {}).get("history", {}).get(nation, "")   # 這一國的往事（16k）
    sights = "、".join(f["name"] for f in scene_mod.of(place))
    return (f"{name}" + (f"（{tags}）" if tags else "") + f"：{place.get('description', '')}"
            + (f"　眼前：{sights}" if sights else "")
            + (f"　此地狀況：{states}" if states else "") + (f"　相連：{near}" if near else "")
            + (f"　{nation}往事：{told}" if told else ""))


def _map_view(rows: dict, sheet: dict, clock_now: int) -> dict:
    """地點面板：目前位置與所屬區域、此地狀況、相連的地點（距離與預估時辰）、已知地點。"""
    here = sheet["location"]
    return {
        "current": here,
        "breadcrumb": _realm(rows, here) + space.breadcrumb({l["name"]: l["parent"] for l in rows["locations"]}, here),
        "danger": _place(rows, here).get("danger", ""),
        "states": _signs(rows, here, clock_now),
        "features": [f["name"] for f in scene_mod.of(_place(rows, here))],
        "neighbors": [{**n, "shichen": space.travel_shichen(n["km"], sheet["realm_lv"])}
                      for n in space.neighbors(rows["connections"], here)],
        "within": [n for n in space.within(rows["locations"], here) if not _place(rows, n).get("spot")],   # 同一個村鎮裡的幾處（16t 第 3 題）
        "spots": [n for n in spot_mod.shown(rows["locations"], space.town_of(rows["locations"], here)) if n != here],   # 這裡的小地方（第 9g 批）
        "clues": [("〔物證〕" if c["kind"] == plot_mod.EVIDENCE else "") + c["text"] for c in sheet["clues"]],   # 查到的線索（16t）
        "known": [l["name"] for l in rows["locations"]],
    }
