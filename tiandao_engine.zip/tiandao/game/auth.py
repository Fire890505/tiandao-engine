"""帳號與登入。密碼用 PBKDF2，token 只存雜湊值。"""
from __future__ import annotations

import hashlib
import hmac
import re
import secrets

from ..errors import BadRequest, Conflict, Unauthorized, text_field
from ..store import repos
from ..store.db import transaction
from ..util import iso, iso_in, new_id

_ITERATIONS = 200_000
_USERNAME_RE = re.compile(r"^[A-Za-z0-9_\-\u4e00-\u9fff]{2,24}$")


def hash_password(password: str, *, salt: bytes | None = None) -> str:
    salt = salt or secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, _ITERATIONS)
    return f"pbkdf2${_ITERATIONS}${salt.hex()}${digest.hex()}"


def verify_password(password: str, stored: str) -> bool:
    try:
        _, iterations, salt_hex, digest_hex = stored.split("$")
        digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), bytes.fromhex(salt_hex), int(iterations))
    except ValueError:
        return False
    return hmac.compare_digest(digest.hex(), digest_hex)


def _token_hash(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def register(conn, username: str, password: str) -> dict:
    username = text_field(username, "使用者名稱", "invalid_username")
    if not _USERNAME_RE.match(username):
        raise BadRequest("使用者名稱需為 2 到 24 個字，只能用中英文、數字、底線或連字號。", code="invalid_username")
    if not isinstance(password, str) or len(password) < 8:
        raise BadRequest("密碼至少需要 8 個字元。", code="invalid_password")
    with transaction(conn):
        if repos.get_user_by_username(conn, username):
            raise Conflict("這個使用者名稱已經有人使用。", code="username_taken")
        user_id = new_id("usr")
        repos.insert_user(conn, user_id, username, hash_password(password))
    return {"id": user_id, "username": username}


def login(conn, username: str, password: str, ttl_hours: int) -> dict:
    username = username.strip() if isinstance(username, str) else ""
    user = repos.get_user_by_username(conn, username) if username else None
    if not user or not isinstance(password, str) or not verify_password(password, user["password_hash"]):
        raise Unauthorized("使用者名稱或密碼錯誤。", code="bad_credentials")
    token = secrets.token_urlsafe(32)
    expires_at = iso_in(ttl_hours)
    with transaction(conn):
        repos.insert_token(conn, _token_hash(token), user["id"], expires_at)
    return {"token": token, "expiresAt": expires_at, "user": {"id": user["id"], "username": user["username"]}}


def resolve(conn, authorization_header: str | None) -> str:
    """回傳 user_id；無效時拋 Unauthorized。"""
    header = authorization_header or ""
    if not header.startswith("Bearer "):
        raise Unauthorized("請先登入。")
    user_id = repos.get_token_user(conn, _token_hash(header[7:].strip()), iso())
    if not user_id:
        raise Unauthorized("登入已失效，請重新登入。", code="token_expired")
    return user_id


def logout(conn, authorization_header: str | None) -> None:
    header = authorization_header or ""
    if header.startswith("Bearer "):
        with transaction(conn):
            repos.delete_token(conn, _token_hash(header[7:].strip()))
