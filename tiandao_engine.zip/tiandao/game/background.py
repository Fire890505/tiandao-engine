"""背景演化的遊戲流程：個別補算（第 10b 步）與世界脈動（第 10c-1 步）。整理給玩家與說書人的消息。

一回合各做一次：先補算回合結束時抵達處的人＋打聽的對象（開場時是開場地點的人），再推進世界脈動。
資料一律來自回合開始時讀好的 rows（見 service._world_rows），不在這裡重讀。
結果放在記憶體裡，由 service 在回合的交易中寫入：AI 失敗時什麼都不寫，重送會算出同樣的結果。
"""
from __future__ import annotations

import random
from dataclasses import dataclass, field, replace

from ..domain import atlas, crime, evolution, favour, legacy, opinion, origins, palace, realm, society, space, truth, visitors
from ..domain import chatter as chatter_mod
from ..domain import looks as outfit
from ..domain import memory as memory_mod
from ..domain import reunion as reunion_mod
from ..domain import npc as npc_mod
from ..domain import pulse as pulse_mod
from ..store import repos
from . import realms, rebirths
from .memory_book import date_label


@dataclass
class NpcUpdates:
    """補算與世界脈動的結果。"""
    fields: dict[str, dict] = field(default_factory=dict)      # NPC 名字 → 要寫回的欄位
    notes: list[dict] = field(default_factory=list)            # 屬於這一生的記事（重逢時補算的近況、打聽）
    world_notes: list[dict] = field(default_factory=list)      # 世界脈動的記事：不屬於任何一生
    bonds: list[dict] = field(default_factory=list)            # 世界脈動產生的羈絆（繼位）
    reasons: list[dict] = field(default_factory=list)          # NPC 之間的原因（第 1-3 批）
    ledger: list[dict] = field(default_factory=list)           # 帳：恩、受託（第 1-3 批）
    happened: list[dict] = field(default_factory=list)         # 主角做的事（events 表，第 1-5a 批；帶 session_id）
    knows: list[dict] = field(default_factory=list)            # 誰知道（knows 表）
    told: list[str] = field(default_factory=list)              # 說過了的知道（id）
    settled: list[str] = field(default_factory=list)           # 了結的帳（id）：追查兇手問到了（第 1-5b 批）
    rumors: list[dict] = field(default_factory=list)           # 這段時間的大事傳開的傳聞（第 10c-3a 步）
    events: list[str] = field(default_factory=list)            # 玩家與說書人都看得到的消息
    dead: set[str] = field(default_factory=set)
    visits: list[tuple[str, str, bool]] = field(default_factory=list)   # 特殊命 NPC 的章找上你：（他, 宮, 人到了你那），第 122c 批
    owed: list[tuple[str, str]] = field(default_factory=list)     # 以你為命主的章收了：（他, 結局）
    unbonds: list[tuple] = field(default_factory=list)            # 斷的關係（甲, 乙, 種類）：成親、除名（第 7-2a 批）
    chatted: dict[str, int] = field(default_factory=dict)         # 小事補到哪（那一處 → 時刻）
    cells: list[tuple[str, str]] = field(default_factory=list)    # 要開的牢房（村鎮, 牢房）
    factions: dict[str, dict] = field(default_factory=dict)      # 勢力要改的欄位：遷（location）、滅（traits），第 7-3b1b1 批
    founded: list[dict] = field(default_factory=list)            # 聚出來的新勢力（第 7-5a 批）
    mine: list[dict] = field(default_factory=list)               # NPC 對你的原因（帶那一生）：嫁禍被識破，第 7-3b1b2 批
    dropped: list[str] = field(default_factory=list)             # 要撤掉的原因（id）：嫁禍被識破，記給被栽贓那方的
    woke: list[str] = field(default_factory=list)                # 覺醒的轉世（待投胎那筆帳的 id，第 7-5c 批）
    born: list[dict] = field(default_factory=list)               # 重逢牌新登錄的人：孩子、徒弟（第 9f-2 批）


def update_npcs(session: dict, rows: dict, names: set[str], clock_now: int, *, protagonist: str, here: str,
                turn_no: int, relations: dict[str, dict] | None = None) -> tuple[dict, NpcUpdates]:
    """把 names 這幾個 NPC 補算到 clock_now。回傳（換上演算後 NPC 的 rows, 結果）。

    relations：這回合已經變過的關係（優先於 rows）。here：玩家此刻所在，重逢的消息只寫這裡的人。
    消息只給這一生認識的人（有關係紀錄或記事）：陌生人的近況對玩家沒有意義，但記事照樣寫。
    """
    result = NpcUpdates()
    targets = [p for p in rows["npcs"] if p["name"] in names]
    if not targets:
        return rows, result
    known = known_names(rows, session["id"])
    current = {**rows["relations"], **(relations or {})}
    by_name = {p["name"]: p for p in rows["npcs"]}
    world = evolution.World(places=rows["locations"], npcs=by_name, bonds=rows["bonds"], notes=rows["memories"],
                            protagonist=protagonist, gone=gone(rows, protagonist), factions=_faction_places(rows), my_lv=rows.get("my_lv", 0),
                            fate=rows.get("fate", truth.NONE), card=rows.get("era"), **seen(rows, protagonist, here))
    for p in targets:
        start = p["evolved_shichen"]
        out = evolution.evolve(p, rng=random.Random(f"{rows['seed']}:evolve:{p['name']}:{start}"), start=start,
                               end=clock_now, world=world, relation=current.get(p["name"]), turn_no=turn_no)
        by_name[p["name"]] = out.npc
        if out.fields:
            result.fields[p["name"]] = out.fields
        result.notes += out.notes
        if out.died_at is not None:
            result.dead.add(p["name"])
        result.rumors += [e.rumor for e in pulse_mod.outcome_events(out, clock_now) if e.rumor]
        result.visits += [(p["name"], *v) for v in out.visits]
        result.owed += [(p["name"], e) for e in out.owed]
        if p["location"] == here and p["name"] in known:
            result.events += reunion_news(p, out)
    return {**rows, "npcs": [by_name[p["name"]] for p in rows["npcs"]]}, result


def reunion_news(before: dict, out: evolution.Outcome) -> list[str]:
    """重逢時看得出來的變化（目標、性格不寫：玩家要打聽才知道）。"""
    name, after = before["name"], out.npc
    if out.died_at is not None:
        return [f"{name}已於{date_label(out.died_at)}壽終坐化"]
    news = []
    if after["location"] != before["location"]:
        news.append(f"{name}已離開{before['location']}")
    elif out.stages:
        news.append(f"{name}的氣息比從前深沉許多" if after["hidden_power"]
                    else f"{name}近況：修為已至{realm.stage_name(after['realm_lv'], after['stage_index'])}")
    return news


def seen(rows: dict, protagonist: str, here: str) -> dict:
    """特殊命 NPC 的章要看的（第 122c 批）：好感、你的羈絆（你那方換成名字）、離你多遠、你這章的命主和宮；
    命數找上你（併章重設計）：這一生找上你的時刻、你勸過他聽了的結局（帳 society.CALLED）、還在等你的人（rows["waiting"]）。"""
    life = rows.get("life", "")
    name = lambda n: protagonist if n == life else n
    mine = [{**b, "a": name(b["a"]), "b": name(b["b"])} for b in rows.get("mine", []) + palace.felt(rows.get("relations", {}), life)]
    book = sorted((l for l in rows.get("ledger", []) if l["kind"] == society.CALLED and l["b"] == life), key=lambda l: l["clock_shichen"])
    calls: dict[str, list[int]] = {}
    for l in book:
        if "勸" not in l["body"]:
            calls.setdefault(l["a"], []).append(l["clock_shichen"])
    who, where = rows.get("my_open") or ("", "")
    return {"like": like(rows, protagonist), "mine": mine, "here": here, "my_open": who, "my_palace": where, "calls": calls,
            "advice": {l["a"]: (l["clock_shichen"], l["body"]["勸"]) for l in book if "勸" in l["body"]},
            "waiting": frozenset(rows.get("waiting", ())), "near": space.distances_from(rows.get("connections", []), here) if here else {}}


def like(rows: dict, protagonist: str = ""):
    """甲在某時刻對乙的好感，只算那時以前的原因：對你看這一生的關係，NPC 之間看 society.liking。"""
    rel = rows.get("relations", {})

    def f(x: str, y: str, when: int) -> int:
        if y == protagonist and x in rel:
            r = rel[x]
            return opinion.score({**r, "had": [h for h in r["had"] if h["clock_shichen"] <= when], "adds": [], "now": when})["affinity"]
        return society.liking(rows["npcs"], rows["bonds"], [r for r in rows.get("npc_reasons", []) if r["clock_shichen"] <= when],
                              when, rows.get("factions", []))(x, y)
    return f


def gone(rows: dict, protagonist: str) -> frozenset[str]:
    """已不在人世的名字：死去的 NPC、前幾生的主角（與這一生同名的不算；退隱的還活著，是 NPC）。"""
    return frozenset({p["name"] for p in rows["npcs"] if p["status"] != "ALIVE"}
                     | {life["name"] for life in rows["past_lives"]
                        if life["name"] not in ("", protagonist) and life["ending"] != legacy.RETIRED})


# ── 世界脈動（第 10c-1 步）────────────────────────────────────────────────
def pulse(rows: dict, updates: NpcUpdates, start: int, end: int, *, protagonist: str, player_lv: int, here: str,
          turn_no: int, relations: dict[str, dict], skip: set[str]) -> dict:
    """推進 start 到 end 跨過的月份（不跨月不算）。結果併進 updates，回傳換上推進後 NPC 的 rows。

    relations：這回合已經變過的關係；skip：這回合被主角動過手的人（不參與）。
    大事年表：跨過一年以上挑最重大的幾件、不到一年只列發生在主角所在地的交手，併進 updates.events。
    """
    if evolution.months(end) <= evolution.months(start):
        return rows
    by_name = {p["name"]: p for p in rows["npcs"]}
    world = evolution.World(places=rows["locations"], npcs=dict(by_name), bonds=list(rows["bonds"]),
                            notes=rows["memories"] + updates.notes, protagonist=protagonist,
                            gone=gone(rows, protagonist) | updates.dead, factions=_faction_places(rows), my_lv=rows.get("my_lv", 0),
                            fate=rows.get("fate", truth.NONE), card=rows.get("era"), **seen(rows, protagonist, here))
    result = pulse_mod.advance(
        world, seed=rows["seed"], start=start, end=end,
        chosen=pulse_mod.choose(rows["npcs"], rows["bonds"], world.notes, skip | updates.dead),
        relations={**rows["relations"], **relations}, player_lv=player_lv,
        near=[n["name"] for n in space.neighbors(rows["connections"], here)], turn_no=turn_no)
    for name, p in result.npcs.items():
        changed = evolution.changed_fields(by_name[name], p)
        if changed:
            updates.fields.setdefault(name, {}).update(changed)
    updates.world_notes += result.notes
    for b in result.bonds:   # 原地補：world.bonds 是同一份，這回合後面（factions.pushes）也讀得到時刻
        b.update(clock_shichen=end, turn_no=turn_no)
    updates.bonds += result.bonds
    updates.reasons += result.reasons
    updates.rumors += [e.rumor for e in result.events if e.rumor]
    updates.dead |= result.dead
    updates.visits += result.visits
    updates.owed += result.owed
    updates.events += [f"江湖大事：{date_label(e.when)}・{e.text}"
                       for e in pulse_mod.headlines(result.events, start, end, here)]
    rows = {**rows, "npcs": [world.npcs[p["name"]] for p in rows["npcs"]], "bonds": world.bonds}
    rebirths.npcs(rows, updates, start, end)   # NPC 轉世：殘夢、覺醒（第 7-5c 批）
    return rows


# ── 村鎮小事（第 7-2a 批）────────────────────────────────────────────────
def towns(rows: dict, *places: str) -> set[str]:
    """這幾個地方算在哪幾處（子地點算上層的村鎮）。"""
    return {space.town_of(rows["locations"], p) for p in places if p}


def chatter(rows: dict, updates: NpcUpdates, places: set[str], end: int, *, known: set[str], turn_no: int) -> dict:
    """這幾處的 NPC 小事補到 end（domain/chatter.py），結果併進 updates；跟你認識的人有關、最重的一件寫成一行「聽說」。
    回傳換上進牢、出牢、除名和新戀人伴侶的 rows。"""
    by, bonds, told, moved, new = {l["name"]: l for l in rows["locations"]}, list(rows["bonds"]), [], {}, []
    for town in sorted(t for t in places if by.get(t, {}).get("type") in chatter_mod.PLACES):
        start = by[town].get("chat_shichen")
        start = max(0, end - chatter_mod.FIRST) if start is None else start
        if evolution.months(end) <= evolution.months(start):
            continue
        state = atlas.state_of(rows.get("atlas"), rows["connections"], town)
        traits = crime.traits_of(crime.nation(rows["factions"], state["nation"] if state else ""))
        out = chatter_mod.settle(random.Random(f"{rows['seed']}:chatter:{town}:{start}:{end}"), place=by[town],
                                 locations=rows["locations"], npcs=rows["npcs"], bonds=bonds,
                                 reasons=rows.get("npc_reasons", []) + updates.reasons, ledger=rows.get("ledger", []) + updates.ledger,
                                 factions=rows["factions"], laws=crime.code(traits), loose=chatter_mod.slack(traits, rows["locations"], town),
                                 start=start, end=end, turn_no=turn_no)
        for name, f in out.fields.items():
            updates.fields.setdefault(name, {}).update(f)
            moved.setdefault(name, {}).update(f)
        cell = chatter_mod.jail_of(rows["locations"], town)
        updates.cells += [(town, cell)] * any(f.get("location") == cell for f in out.fields.values())
        updates.reasons += out.reasons
        updates.bonds += out.bonds
        updates.unbonds += out.unbonds
        updates.ledger += out.ledger
        updates.settled += out.settled
        updates.world_notes += out.notes
        updates.rumors += out.rumors
        updates.chatted[town] = end
        updates.founded += out.factions
        new += out.factions
        cut = {(a, b, t) for a, b, ts in out.unbonds for t in ts}
        bonds = [b for b in bonds if (b["a"], b["b"], b["type"]) not in cut] + out.bonds
        told += [t for t in out.told if t[3] & known]
    best = max(told, key=lambda t: t[:2], default=None)
    updates.events += [f"聽說：{best[2]}"] if best else []
    return {**rows, "npcs": [{**p, **moved.get(p["name"], {})} for p in rows["npcs"]], "bonds": bonds,
            "factions": rows["factions"] + new}


def reunion(rows: dict, updates: NpcUpdates, names: set[str], places: set[str], end: int, *, known: set[str],
            here: set[str], turn_no: int) -> dict:
    """人物層牌（第 9f 批，domain/reunion.py）：你認識的人裡，在 names（在場、打聽的）或住在 places（你到的、打聽的那處）的，
    隔半年以上補抽；跟你同處的（here）和抽過的，算到哪改成 end。搬走的寫一行「聽說」。回傳換上新狀態的 rows。"""
    towns_ = [l["name"] for l in rows["locations"] if l["type"] in reunion_mod.TOWNS]
    kinds = {l["name"]: l["type"] for l in rows["locations"]}
    ctx = reunion_mod.Ctx("", [], [], (), npcs={p["name"]: dict(p) for p in rows["npcs"]}, bonds=list(rows["bonds"]),
                          factions=rows.get("factions", []), town_of={l["name"]: space.town_of(rows["locations"], l["name"]) for l in rows["locations"]},
                          known=known, taken={p["name"] for p in rows["npcs"]} | set(kinds) | {f["name"] for f in rows.get("factions", [])})
    born, marked = [], set()
    for name in [p["name"] for p in rows["npcs"]]:
        p = ctx.npcs[name]
        if name not in known or p["status"] != "ALIVE" or p["location"] == society.AWAY:
            continue
        town = ctx.town_of.get(p["location"], p["location"])
        if name not in names and town not in places:
            continue
        start = p.get("life_shichen")   # 化身（avatar）沒有這欄
        drew = start is not None and reunion_mod.draws(end - start) > 0
        if drew:
            near = [n["name"] for n in space.neighbors(rows["connections"], town) if n["name"] in towns_]
            out = reunion_mod.settle(random.Random(f"{rows['seed']}:reunion:{name}:{start}"), p,
                                     replace(ctx, town=town, near=near, far=[t for t in towns_ if t not in near and t != town],
                                             jobs=tuple(outfit.TABLE["職業"].get(kinds.get(town, ""), ()))),
                                     start=start, end=end, turn_no=turn_no,
                                     taken={reunion_mod.SKIP[k] for k in updates.fields.get(name, {}) if k in reunion_mod.SKIP})
            for who, f in {name: out.fields, **out.others}.items():
                updates.fields.setdefault(who, {}).update(f)
            updates.notes += out.notes
            updates.ledger += out.ledger
            updates.settled += [r["id"] for r in out.ledger]
            updates.bonds += out.bonds
            updates.unbonds += out.unbonds
            updates.dead |= out.dead
            born += out.born
            updates.events += [f"聽說：{name}{t}" for t in out.moved if name not in here]
        if drew or name in here or start is None:
            ctx.npcs[name] = {**ctx.npcs[name], "life_shichen": end}
            updates.fields.setdefault(name, {})["life_shichen"] = end
    born = [{**repos.NPC_DEFAULTS, **origins.npc(random.Random(f"{rows['seed']}|命|{c['name']}")),
             **npc_mod.roll_tempers(random.Random(f"{rows['seed']}|性|{c['name']}")), **c} for c in born]
    updates.born += born
    return {**rows, "npcs": [ctx.npcs[p["name"]] for p in rows["npcs"]] + born, "bonds": ctx.bonds}

def jail(conn, world_id: str, town: str, name: str, known: set[str]) -> str:
    """村鎮的牢房那一處；沒有就多開一處（第 4-11-15 題；NPC 小事傷人也關這裡，第 7-2a 批）。"""
    if name not in known:
        repos.insert_location(conn, world_id, "", {"name": name, "type": "住家", "scale": "家", "parent": town,
                                                   "description": "陰濕的牢房，關著犯了事的人。", "danger": "", "discovered_turn": 0})
        repos.insert_connection(conn, world_id, "", {"a": town, "b": name, "tier": space.NEAR,
                                                     "distance_km": space.DISTANCE_TIERS[space.NEAR]})
    return name


# ── 找上門（第 10c-2a 步）────────────────────────────────────────────────
def hostile_visit(rows: dict, *, protagonist: str, here: str, start: int, end: int,
                  skip: set[str], boost: float = 1, alias: str = "", hurt: bool = False,
                  blackmail: set[str] = frozenset()) -> visitors.Visit | None:
    """這段時間最早帶著敵意找上門的人（復仇者、宿敵、被你賴了債的人）。閉關時 service 會把閉關停在他到的那一刻。
    boost：你在此地的名聲讓人更容易找到你（第 10c-3b 步）。alias：正在用的化名，追捕化名的人也找得到你（16e.1）。
    怕你的人（第 121-10 題）：畏懼的不來；忌憚的等你受了傷（hurt）才來偷襲。blackmail：拿你把柄要錢的人（deeds.leverage）。
    做法牌（第 7-2b 批）：被雇來的人（帳上受託、乙＝這一生）來意「受託」；有人通風報信的仇家這一個月當作同處。"""
    dun = {n for n, r in rows.get("relations", {}).items()
           if any(f["kind"] == favour.DEBT and f["refused"] == favour.WELSHED for f in r.get("favours", []))}
    life = rows.get("life", "")
    book = [l for l in rows.get("ledger", []) if life and l["session_id"] == life and l["status"] == society.OPEN
            and (l["deadline_shichen"] or end) > start]
    hired = {l["a"] for l in book if l["kind"] == society.HIRED}
    tipped = {l["body"].get("仇家") for l in book if l["kind"] == society.DEED and l["body"].get("做") == "通風"}
    shy = {npc_mod.AWED} | (set() if hurt else {npc_mod.WARY})
    people = [{**p, "goal": visitors.BLACKMAIL, "goal_target": protagonist} if p["name"] in blackmail
              else {**p, "goal": visitors.DUN, "goal_target": protagonist} if p["name"] in dun
              else {**p, "goal": visitors.HIRED, "goal_target": protagonist} if p["name"] in hired
              else {**p, "goal_target": protagonist} if alias and p["goal_target"] == alias else p
              for p in rows["npcs"] if p["name"] not in skip and dread(rows, p) not in shy]
    people = [{**p, "location": here} if p["name"] in tipped else p for p in people]
    return visitors.first_visit(random.Random(f"{rows['seed']}:visit:hostile:{start}:{end}"),
                                people, protagonist=protagonist,
                                here=here, place_type=_place_type(rows, here), start=start, end=end,
                                reasons=visitors.HOSTILE_REASONS, boost=boost)


def friendly_visit(rows: dict, threads: list[dict], *, protagonist: str, here: str, start: int, end: int,
                   skip: set[str], events: list[str], boost: float = 1) -> tuple[visitors.Visit | None, str]:
    """善意的訪客，閉關結束那一刻才到。守約的人優先（不看名聲），其次報恩、追隨的人。回傳（訪客, 守約的線頭 id）。
    期限到時正好重傷的人來不了：事件寫「想來卻來不了」，線頭照舊逾期落空。"""
    by_name = {p["name"]: p for p in rows["npcs"]}
    keeper = None
    for t in threads:   # 每條到期的約定都要看：來不了的人要有消息
        p = by_name.get(t["subject"])
        if t["kind"] != memory_mod.THEIR_PROMISE or t["status"] != memory_mod.OPEN or not p \
                or p["name"] in skip or p["status"] != "ALIVE" or not visitors.promise_due(t, start, end):
            continue
        if p["condition"] == "重傷":
            events.append(f"傳來消息：{p['name']}身受重傷，想如約前來卻來不了")
        elif keeper is None and visitors.keeps_promise(random.Random(f"{rows['seed']}:promise:{t['id']}"), p):
            keeper = (visitors.Visit(p["name"], visitors.PROMISE, end), t["id"])
    if keeper:
        return keeper
    visit = visitors.first_visit(random.Random(f"{rows['seed']}:visit:friendly:{start}:{end}"),
                                 [p for p in rows["npcs"] if p["name"] not in skip], protagonist=protagonist,
                                 here=here, place_type=_place_type(rows, here), start=start, end=end,
                                 reasons=visitors.FRIENDLY_REASONS, boost=boost)
    return (visitors.Visit(visit.name, visit.reason, end) if visit else None), ""


def arrive(rows: dict, updates: NpcUpdates, visit: visitors.Visit, *, here: str, protagonist: str,
           turn_no: int) -> dict | None:
    """訪客移到你所在的地方（併進 updates），記一條這一生的記事。回傳換上新位置的 rows；他已經不在人世就回傳 None。"""
    p = next(x for x in rows["npcs"] if x["name"] == visit.name)
    if p["status"] != "ALIVE":
        return None
    if p["location"] != here:   # 從遠方來的：不在遠方了（第 10c-2b 步）
        updates.fields.setdefault(visit.name, {}).update(location=here, away_since=None, away_from="")
    purpose = visitors.PURPOSE[visit.reason].replace("你", protagonist)
    updates.notes.append(memory_mod.note(memory_mod.NPC, visit.name, memory_mod.NEWS, f"找上門來，{purpose}",
                                         clock_now=visit.when, turn_no=turn_no))
    return {**rows, "npcs": [{**x, "location": here} if x["name"] == visit.name else x for x in rows["npcs"]]}


def ambush(rows: dict, foe: visitors.Visit, sheet: dict, *, retreating: bool) -> tuple[dict, list[dict], list[str]]:
    """帶敵意的人偷襲（善念低、或膽識野心都高的人才會）。回傳（角色卡, 數值變化, 事件）。
    偷襲不會打死你，也不會讓你陷入瀕死：氣血最多扣到剩 1；已經瀕死就不再扣。"""
    p = next(x for x in rows["npcs"] if x["name"] == foe.name)
    if foe.reason == visitors.BLACKMAIL or not (visitors.ambusher(p) or dread(rows, p) == npc_mod.WARY) \
            or sheet["status"] != "ALIVE":   # 忌憚你的不當面叫陣；要封口費的不動手
        return sheet, [], []
    rng = random.Random(f"{rows['seed']}:ambush:{foe.name}:{foe.when}")
    if rng.random() < visitors.notice_chance(sheet["realm_lv"], p["realm_lv"], retreating):
        return sheet, [], [f"你察覺了{foe.name}的偷襲"]
    hp = max(1, sheet["hp"] - visitors.ambush_damage(sheet["hp_max"], p["realm_lv"], sheet["realm_lv"]))
    changes = [{"field": "hp", "from": sheet["hp"], "to": hp}] if hp != sheet["hp"] else []
    return {**sheet, "hp": hp}, changes, [f"{foe.name}暗中出手偷襲！你受了傷"]


def visit_event(visit: visitors.Visit, *, interrupted_months: int = 0, doing: str = "閉關") -> str:
    """doing：被打斷的是閉關還是做工（第 8 步）。"""
    purpose = visitors.PURPOSE[visit.reason]
    if interrupted_months:
        return f"{doing}第{interrupted_months}個月，{visit.name}找上門來（{purpose}），{doing}被迫中斷"
    return f"{visit.name}找上門來（{purpose}）" if visit.hostile else f"{visit.name}找到了你（{purpose}）"


def dread(rows: dict, p: dict) -> str:
    """他怕不怕這一生的你（npc.dread；rows["my_lv"]：回合開始時你的境界）。"""
    rel = rows.get("relations", {}).get(p["name"])
    return npc_mod.dread(rel, p, rows.get("my_lv", 0)) if rel else ""


def _faction_places(rows: dict) -> dict[str, str]:
    return {f["name"]: f["location"] for f in rows["factions"]}


def _place_type(rows: dict, name: str) -> str:
    return next((l["type"] for l in rows["locations"] if l["name"] == name), "")


# ── 打聽 ─────────────────────────────────────────────────────────────────
@dataclass
class Inquiry:
    subject: str
    text: str            # 打聽到的消息（給玩家與說書人）
    goal: str = ""       # 打聽到的目標（空＝沒打聽到）
    note: dict | None = None


def inquire(p: dict, outcome: str, *, protagonist: str, notes: list[dict], clock_now: int,
            turn_no: int) -> Inquiry:
    """打聽不在場的人：依套話的結果決定問到多少。最近的近況取自記事（含這回合剛補算出來的）。"""
    news = [n for n in notes if n["subject"] == p["name"] and n["kind"] in (memory_mod.NEWS, memory_mod.DEATH)]
    latest = max(news, key=lambda n: n["clock_shichen"])["text"] if news else ""
    text, goal = evolution.inquiry_text(p, outcome, protagonist, latest)
    heard = outcome in evolution.HEARD_OUTCOMES
    note = memory_mod.note(memory_mod.NPC, p["name"], memory_mod.HEARD, f"打聽到：{text}",
                           clock_now=clock_now, turn_no=turn_no) if heard else None
    return Inquiry(p["name"], text, goal, note)


def known_goals(rows: dict) -> dict[str, dict]:
    """玩家打聽到的目標：名字 → {text, date}（第 10b 步；目標要打聽才知道）。"""
    return {name: {"text": r["known_goal"], "date": date_label(r["known_goal_shichen"] or 0)}
            for name, r in rows["relations"].items() if r["known_goal"]}


def acquaintances(rows: dict, session_id: str) -> list[str]:
    """這一生認識的人，依登場順序。只有名字：人在哪裡要打聽才知道。"""
    names = known_names(rows, session_id)
    return [p["name"] for p in rows["npcs"] if p["name"] in names]


def known_names(rows: dict, session_id: str) -> set[str]:
    """這一生認識的人：有關係紀錄（只聽說過你、還沒見過面的不算，第 1-5e 批），或這一生有關於他的記事。"""
    return {n for n, r in rows["relations"].items() if r.get("met", 1)} | {n["subject"] for n in rows["memories"]
                                     if n["session_id"] == session_id and n["subject_kind"] == memory_mod.NPC}


# ── 寫入（在回合的交易內呼叫）────────────────────────────────────────────
def write(conn, session: dict, updates: NpcUpdates, known: dict[str, str], clock_now: int) -> None:
    """NPC 欄位、記事、羈絆、打聽到的目標。關係回歸由 service 併進這回合的關係變化一起寫。
    世界脈動的記事不屬於任何一生（session_id 空字串）；羈絆記在這一生（存檔要知道是哪一生登錄的）。"""
    world_id, session_id = session["world_id"], session["id"]
    known_places = {l["name"] for l in repos.list_locations(conn, world_id)} if updates.cells else set()
    for town, cell in dict(updates.cells).items():   # 牢房（第 7-2a 批）
        jail(conn, world_id, town, cell, known_places)
    for name, fields in updates.fields.items():
        repos.update_npc(conn, world_id, name, fields)
        if fields.get("goal") == npc_mod.ASCENDED:   # 破空（16l B3b）：搬不搬進仙域
            realms.npc_ascend(conn, session, name, clock_now)
    for n in updates.notes:
        repos.insert_memory(conn, world_id, session_id, n)
    for n in updates.world_notes:
        repos.insert_memory(conn, world_id, "", n)
    for p in updates.born:      # 重逢牌生的孩子、收的徒弟（第 9f-2 批）：要先寫，羈絆才接得上
        repos.insert_npc(conn, world_id, session_id, p)
    for f in updates.founded:   # 聚出來的新勢力（第 7-5a 批）：要先寫，成員的羈絆才接得上
        repos.insert_faction(conn, world_id, "", f)
    for name, fields in updates.factions.items():
        repos.update_faction(conn, world_id, name, fields)
    for b in updates.bonds:
        repos.insert_bond(conn, world_id, session_id, b)
    for a, b, types in updates.unbonds:
        repos.delete_bond(conn, world_id, a, b, types)
    for town, when in updates.chatted.items():
        repos.set_chat(conn, world_id, town, when)
    for r in updates.reasons:   # NPC 之間的：不屬於任何一生
        repos.insert_book(conn, "reasons", world_id, {**r, "session_id": ""})
    for r in updates.mine:      # NPC 對你的：帶那一生
        repos.insert_book(conn, "reasons", world_id, r)
    if updates.dropped:
        repos.drop_reasons(conn, updates.dropped)
    for r in updates.ledger:    # NPC 之間的寫空字串；血仇、追查兇手帶那一生（第 1-5b 批）
        repos.insert_book(conn, "ledger", world_id, {"session_id": "", **r})
    repos.settle(conn, updates.settled)
    for i in updates.woke:
        repos.wake(conn, i, clock_now)
    for table, rows in (("events", updates.happened), ("knows", updates.knows)):   # 這一生的：row 自己帶 session_id
        for r in rows:
            repos.insert_book(conn, table, world_id, r)
    repos.mark_told(conn, updates.told)
    for r in updates.rumors:
        repos.insert_rumor(conn, world_id, r)
    for name, goal in known.items():
        repos.set_known_goal(conn, world_id, name, session_id, goal, clock_now)
