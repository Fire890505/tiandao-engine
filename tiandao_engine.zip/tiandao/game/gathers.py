"""主角那群（第 7-5a 批，WHITEPAPER 7-5-3 題甲；數字暫定）。規則在 domain/gather.py。

- 你在一個村鎮時看：那裡對你友善以上又熟的人，兩兩好（gather.links），加上你到 gather.SIZE 根線。
- 群裡對你好感最高的人開口，當候選跟牌同一級；被挑中那回合帳上記一筆「聚過」（帶那一生），下回合你回。
- 回「結義」（或結拜、拜把）就兩兩結義、連你一起；其他回應都算不聚。只給一次：推掉的那群沒多出新的人不再問。
- 新勢力先不給你（勢力經營 121-11、121-12 沒做）。
"""
from __future__ import annotations

from ..domain import gather, pending, schedule, society, space
from ..util import new_id
from .deeds import Scene

YES = ("結義", "結拜", "拜把")
NO = "不聚"


def _asked(rows: dict) -> list[dict]:
    return [l for l in rows.get("ledger", []) if l["kind"] == society.GATHERED and l["session_id"] == rows.get("life")]


def waiting(rows: dict) -> bool:
    """上回合問過、還沒回。"""
    return any(l["status"] == society.OPEN for l in _asked(rows))


def offer(rows: dict, updates, here: str, *, now: int, turn_no: int) -> Scene:
    out, life = Scene(), rows.get("life", "")
    town = space.town_of(rows["locations"], here) if here else ""
    if not life or not town or waiting(rows):
        return out
    rels = rows["relations"]
    near = sorted(p["name"] for p in rows["npcs"] if p["status"] == "ALIVE" and p["location"] != society.AWAY
                  and space.town_of(rows["locations"], p["location"]) == town and rels.get(p["name"], {}).get("affinity", 0) >= society.FRIEND_AT
                  and rels[p["name"]].get("circle") in (society.KNOWN, society.KIN))
    group = gather.biggest(gather.links(near, rows["npcs"], rows["bonds"], rows.get("npc_reasons", []), rows.get("factions", []), now),
                           gather.SIZE - 1)
    sworn = {b["b"] if b["a"] == life else b["a"] for b in rows.get("mine", []) if b["type"] == gather.SWORN}
    if not group or set(group) <= sworn and gather.joined(group, rows["bonds"]) or any(
            set(group) <= set(l["body"].get("群", ())) for l in _asked(rows)):
        return out
    who = max(group, key=lambda n: (rels[n]["affinity"], n))
    text = f"{who}說{'、'.join(n for n in group if n != who)}跟你都是信得過的人，提議大夥一起拜把子"

    def run(sheet: dict) -> dict:
        out.scene, out.lines = f"（聚）{text}", [text]
        updates.ledger.append({**society.owed(society.GATHERED, who, town, now), "session_id": life, "id": new_id("led"),
                               "body": {"群": group}})
        return sheet
    out.ask = schedule.Ask(schedule.GATHER, pending.NOW, turn_no, run)
    return out


def answer(rows: dict, updates, text: str, *, now: int, turn_no: int) -> list[str]:
    """上回合問的，這回合回：結義寫羈絆，其他都算不聚。問過的那筆都了結。"""
    row = next((l for l in _asked(rows) if l["status"] == society.OPEN), None)
    if not row:
        return []
    updates.settled.append(row["id"])
    alive = {p["name"] for p in rows["npcs"] if p["status"] == "ALIVE"}
    group = [n for n in row["body"]["群"] if n in alive]
    if not group or not any(w in text for w in YES):
        return []
    updates.bonds += gather.ties(group, gather.SWORN, "", "", rows["bonds"] + rows.get("mine", []), now, turn_no,
                                 me=(rows["life"], society.PLAYER))
    return [f"你和{'、'.join(group)}拜了把子"]
