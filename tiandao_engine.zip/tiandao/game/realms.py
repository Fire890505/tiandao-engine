"""仙域骨架在資料庫裡（16l 草稿 B2）：每個玩家一份，所有世界共用。都在交易內呼叫。規則在 domain/immortal.py。"""
from __future__ import annotations

import random
import secrets

from ..domain import (ascent, avatar, contest, crime, fall, hire, identity, immortal, league, lord, memory, merit, npc,
                      opinion, races, roster, rumors, sect, society, space, war)
from ..domain import world as world_mod
from ..store import repos
from ..util import new_id
from .phases import NEED_OPENING, PLAYING

# 第 1-2 批對照表：叛宗＝背叛（信任當眾升成重、好感大）；敵盟之爭暫定大，等勢力（121-11）再換
TRAITOR = [opinion.hit(opinion.BETRAY, opinion.TRUST, opinion.GRAVE, -1), opinion.hit(opinion.BETRAY, opinion.LIKE, opinion.BIG, -1)]
FOE_LEAGUE = [opinion.hit(opinion.LEAGUE, opinion.LIKE, opinion.BIG, -1)]


def add_reasons(conn, world_id: str, name: str, life: str, hits: list, now: int, **extra) -> None:
    """不在這回合 rows 裡的關係（仙域）：讀出來加幾筆原因再寫回。"""
    p = next((x for x in repos.list_npcs(conn, world_id) if x["name"] == name), None)
    stored = repos.get_relation(conn, world_id, name, life) or {}
    rel = {**npc.relation_for(p, now), **{k: stored[k] for k in ("grudge", "favours") if k in stored},
           "had": opinion.pair(repos.list_book(conn, "reasons", world_id), name, opinion.ME, life)}
    repos.upsert_relation(conn, world_id, name, life, {**npc.shift(name, rel, hits)[0], **extra})


def carry_reasons(conn, src: str, dst: str, name: str, life: str, new_name: str, new_life: str, shift: int = 0) -> None:
    """人或主角搬到仙域：這一對人的原因跟著抄過去（時間照兩個世界的差移過去）。"""
    for r in opinion.pair(repos.list_book(conn, "reasons", src), name, opinion.ME, life):
        repos.insert_book(conn, "reasons", dst, {**r, "id": None, "holder": new_name, "session_id": new_life,
                                                 "clock_shichen": r["clock_shichen"] + shift})
DEFAULT_PATH = "劍修"   # 16h 之前生成的本山沒有道統
NAME = "仙域"
RUIN = "遺址"
AVATAR_PHASES = (PLAYING, NEED_OPENING)   # 這兩種一生在仙域裡是化身（D1）


def ensure(conn, user_id: str) -> dict:
    """玩家的仙域；第一次用到時生成第一紀元，並把舊世界已有的仙宗補進來。每次用到都補算百日演進（C1）：
    大事在仙域世界傳開，地圖同步進仙域世界。"""
    realm = repos.get_immortal(conn, user_id)
    if realm is None:
        seed = secrets.token_hex(16)
        realm = immortal.generate(random.Random(f"{seed}:immortal"), seed)
        for w in repos.list_worlds(conn, user_id):
            realm = adopt_world(conn, realm, w["id"])
        repos.set_immortal(conn, user_id, realm)
    was = realm
    realm, news = immortal.evolve(immortal.upgrade(realm), now(conn, realm))
    if realm.get("evolved", 0) // immortal.PERIOD > was.get("evolved", 0) // immortal.PERIOD:
        news += war.news(realm, now(conn, realm))   # 新的百日：這一輪的戰事傳開（C3a）
    live = realm.get("world") and repos.get_world_or_none(conn, realm["world"])
    gone = {s["name"] for s in was["sects"]} - {s["name"] for s in realm["sects"]}
    if gone and live:   # 滅宗清算：成形的人戰死、流落、投靠、被收編
        realm = _purge(conn, realm, sorted(gone))
    if realm != was:
        repos.set_immortal(conn, user_id, realm)
    if live:
        for text in news:
            repos.insert_rumor(conn, realm["world"], rumors.make(rumors.AFFAIRS, NAME, place="", detail=text,
                                                                 when=now(conn, realm)))
        if news or realm != was:
            sync_map(conn, realm)
    return realm


REFUGE = 60    # 好感親近：流落的門人來投靠
ABSORB = 0.5   # 其他流落的人被原盟最強的仙宗收走


def _purge(conn, realm: dict, gone: list[str]) -> dict:
    """覆滅的宗（第 39、40 題）：成形的首領、成員照名字排序，宗主與逢單的戰死、逢雙流落（拿掉羈絆）；認識戰死者的
    每一生記一則記事。流落的人：跟某一生好感親近就投靠（他是宗主入他的宗，否則記進 refugees 等他下回合當同伴），
    其他人 ABSORB 被原盟最強的仙宗收走；叛出這個宗的主角，流落的人記仇。回傳骨架（refugees 更新過）。"""
    w, clock_now = realm["world"], now(conn, realm)
    bonds, npcs = repos.list_bonds(conn, w), {p["name"]: p for p in repos.list_npcs(conn, w)}
    relations = npc.scored(repos.list_relations(conn, w), repos.list_book(conn, "reasons", w), list(npcs.values()), clock_now,
                           repos.list_bonds(conn, w, everyone=True), repos.list_factions(conn, w))
    sheets = {s["id"]: repos.get_character(conn, s["id"]) for s in repos.list_sessions_in_world(conn, w)}
    refugees = {k: list(v) for k, v in realm.get("refugees", {}).items()}
    for hall in gone:
        rng = random.Random(f"{realm['seed']}:purge:{hall}")
        mine = [b for b in bonds if b["b"] == hall and b["type"] in society.MEMBER_BONDS and b["a"] in npcs
                and npcs[b["a"]]["status"] == "ALIVE"]
        names_ = sorted({b["a"] for b in mine})
        lead = {b["a"] for b in mine if b["type"] == "首領"}
        dead = {n for i, n in enumerate(names_) if n in lead or i % 2 == 0}
        traitors = [sid for sid, sh in sheets.items() if sh and (sh["sect_hunt"] or {}).get("hall") == hall]
        heir = next(iter(fall.heirs(realm, hall)), None)
        for name in names_:
            repos.delete_bond(conn, w, name, hall, society.MEMBER_BONDS)
            if name in dead:
                repos.update_npc(conn, w, name, {"condition": npc.CONDITIONS[-1], "status": "FALLEN"})
                for r in relations:
                    if r["npc_name"] == name:
                        repos.insert_memory(conn, w, r["session_id"], memory.note(
                            memory.NPC, name, memory.NEWS, f"{name}隨{hall}覆滅而戰死", clock_now=clock_now, turn_no=0))
                continue
            for sid in traitors:
                add_reasons(conn, w, name, sid, TRAITOR, clock_now, grudge="叛宗之仇")
            close = max((r for r in relations if r["npc_name"] == name and r["affinity"] >= REFUGE
                         and r["session_id"] not in traitors), key=lambda r: r["affinity"], default=None)
            home = close and next((s["name"] for s in realm["sects"] if s.get("founder") == close["session_id"]), "")
            if home:
                repos.insert_bond(conn, w, "", sect.member_bond(name, home))
            elif close:
                refugees.setdefault(close["session_id"], []).append(name)
            elif heir and rng.random() < ABSORB:
                repos.insert_bond(conn, w, "", sect.member_bond(name, heir["name"]))
    return {**realm, "refugees": refugees} if refugees else realm


def sync_map(conn, realm: dict) -> None:
    """仙域世界的地點：每個仙宗的山門（地點與宗門勢力）、地盤相鄰的仙宗山門之間的路（同盟官道、跨盟邊關）。只補沒有的。"""
    w = realm["world"]
    places, factions = {l["name"] for l in repos.list_locations(conn, w)}, {f["name"] for f in repos.list_factions(conn, w)}
    for s in realm["sects"]:
        gate = s["name"] + ascent.GATE
        if gate not in places:
            repos.insert_location(conn, w, "", {"name": gate, "description": space.NEW_PLACE_DESCRIPTION, "type": "宗門",
                                                "scale": "國家", "discovered_turn": 0})
        if s["name"] not in factions:
            repos.insert_faction(conn, w, "", {"name": s["name"], "type": "宗門", "location": gate, "discovered_turn": 0,
                                               "traits": {"道統": s["path"], "門風": s["style"] or crime.STYLES[0].name}})
    staffed = {b["b"] for b in repos.list_bonds(conn, w) if b["type"] in society.MEMBER_BONDS}
    taken = {p["name"] for p in repos.list_npcs(conn, w)}
    for s in realm["sects"]:   # 宗主、長老（C0）：仙宗第一次登錄時就成形，之後的繼任照背景演化
        for rank in roster.LEADERS if s["name"] not in staffed else ():
            taken.add(_draw(conn, realm, s["name"], s["name"] + ascent.GATE, taken, rank=rank, leaders=True))
    secrets, names_ = [], {s["name"] for s in realm["sects"]}
    for a in realm["alliances"]:   # 各盟的秘境（C4b）：連著 anchor 的山門；併盟的照 was 改名成「大盟秘境・二」（第 45 題）
        first = next((s["name"] for s in realm["sects"] if s["alliance"] == a["name"]), "")
        for s in immortal.secrets(realm, a["name"]):
            secrets.append(s)
            if s["name"] in places:
                continue
            if s["was"] in places:
                repos.rename_place(conn, w, s["was"], s["name"])
                places = places - {s["was"]} | {s["name"]}
            elif first:
                gate = (s["anchor"] if s["anchor"] in names_ else first) + ascent.GATE
                repos.insert_location(conn, w, "", {"name": s["name"], "description": space.NEW_PLACE_DESCRIPTION,
                                                    "type": "秘境", "scale": "城市", "danger": "中", "discovered_turn": 0})
                repos.insert_connection(conn, w, "", {"a": gate, "b": s["name"], "tier": "官道", "direction": "",
                                                      "distance_km": space.STATE_ROADS["官道"], "discovered_turn": 0})
    live = {s["name"] + ascent.GATE for s in realm["sects"]} | {s["name"] for s in secrets}
    for gate in sorted(n for n in places if (n.endswith(ascent.GATE) or immortal.SECRET_NAME.match(n)) and n not in live):
        # 覆滅的山門（C3a）、不在了的盟的秘境（C4b）成了遺址
        ruin = (gate[:-len(ascent.GATE)] if gate.endswith(ascent.GATE) else gate) + RUIN   # 某宗遺址、某盟秘境（・二）遺址
        if ruin not in places:
            repos.rename_place(conn, w, gate, ruin)
            repos.set_location_type(conn, w, ruin, "廢墟")
    roads = {frozenset((c["a"], c["b"])) for c in repos.list_connections(conn, w)}
    for a, b in sorted(immortal.neighbors(realm)):
        x, y = a + ascent.GATE, b + ascent.GATE
        if frozenset((x, y)) not in roads:
            tier = "官道" if immortal._alliance(realm, a) == immortal._alliance(realm, b) != "" else "邊關"
            repos.insert_connection(conn, w, "", {"a": x, "b": y, "tier": tier, "distance_km": space.STATE_ROADS[tier],
                                                  "direction": "", "discovered_turn": 0})


def draw(conn, user_id: str, sect_name: str, place: str) -> str:
    """名冊上的下一個人在 place 成形（C0；sect_name 空＝散仙），回傳名字；沒有人可抽回傳空字串。"""
    realm = ensure(conn, user_id)
    return _draw(conn, realm, sect_name, place, {p["name"] for p in repos.list_npcs(conn, realm["world"])})


def encounter(conn, session: dict, sheet: dict, clock_now: int, rng: random.Random) -> str:
    """仙域的遭遇（C3a）：照盟與盟的關係擲（人在戰事的地點一定遇上），遇上了就讓敵盟仙宗名冊上的人在你身邊成形，
    跟這一生結下敵意。回傳名字（沒遇上回傳空字串）。"""
    realm = ensure(conn, session["user_id"])
    rival = war.meet(realm, rng, clock_now, sheet["location"], hire.side(sheet))   # 受雇的散仙算僱主那一邊（C4c）
    name = rival and draw(conn, session["user_id"], rival, sheet["location"])
    if name:
        add_reasons(conn, realm["world"], name, session["id"], FOE_LEAGUE, clock_now, grudge="敵盟之爭")
    return name


def contest_turn(conn, session: dict, sheet: dict, words: str, clock_now: int, rng: random.Random) -> tuple[dict, list[str]]:
    """仙戰（C4b），回合開始：棄權或報名；這一輪還沒有對手就抽一個在秘境成形（散仙名單，沒有就抽主辦盟的名冊）。"""
    realm = ensure(conn, session["user_id"])
    sheet, facts = contest.start(realm, sheet, words, clock_now)
    c = sheet["contest"]
    if not c or c["foe"]:
        return sheet, facts
    taken = {p["name"] for p in repos.list_npcs(conn, realm["world"])}
    hosts = sorted(s["name"] for s in realm["sects"] if s["alliance"] == contest.host(realm, c["place"]))
    name = _draw(conn, realm, "", c["place"], taken) or (_draw(conn, realm, rng.choice(hosts), c["place"], taken)
                                                        if hosts else "")
    if not name:
        return {**sheet, "contest": None}, facts + ["仙戰找不到對手，草草收場"]
    return {**sheet, "contest": {**c, "foe": name}}, facts + [f"仙戰第 {c['wins'] + 1} 輪，對手是{name}"]


def champion(conn, user_id: str, alliance: str, period: int, name: str) -> None:
    """主角奪得魁首（C4b）：下一個百日結算時傳開的是他。"""
    realm = ensure(conn, user_id)
    repos.set_immortal(conn, user_id, {**realm, "champions": {**realm.get("champions", {}), f"{period}:{alliance}": name}})


def found(conn, user_id: str, new: dict, ruin: str, followers: list[str]) -> None:
    """散仙立宗（C4d）：新仙宗寫進骨架（那一格不再是無主之地），遺址改回山門，追隨者成了長老。"""
    realm = ensure(conn, user_id)
    cell = tuple(new["cells"][0])
    new = {**new, "elders": followers}   # 開宗長老（C5b1：宗主可以任免）
    realm = {**realm, "sects": realm["sects"] + [new], "free": [c for c in realm.get("free", []) if tuple(c) != cell]}
    repos.set_immortal(conn, user_id, realm)
    gate = new["name"] + ascent.GATE
    repos.rename_place(conn, realm["world"], ruin, gate)
    repos.set_location_type(conn, realm["world"], gate, "宗門")
    for name in followers:
        repos.insert_bond(conn, realm["world"], "", sect.member_bond(name, new["name"]))
    sync_map(conn, realm)


def set_sect(conn, user_id: str, s: dict, gone: list[str], heir: str = "") -> None:
    """宗主經營（C5b1）：寫回這個仙宗（實力、長老、差事、門人成績）；gone：逐出或叛宗的門人，拿掉成員羈絆；
    heir：傳位的繼任者（C5b2），改成首領。"""
    realm = ensure(conn, user_id)
    repos.set_immortal(conn, user_id, {**realm, "sects": [s if x["name"] == s["name"] else x for x in realm["sects"]]})
    for name in gone:
        repos.delete_bond(conn, realm["world"], name, s["name"], society.MEMBER_BONDS)
    _lead(conn, realm["world"], heir, s["name"])


def refuged(conn, user_id: str, life: str) -> None:
    """投靠這一生的流落門人已經當了同伴（滅宗清算）。"""
    realm = ensure(conn, user_id)
    repos.set_immortal(conn, user_id, {**realm, "refugees": {k: v for k, v in realm.get("refugees", {}).items() if k != life}})


def pact(conn, user_id: str, patch: dict) -> None:
    """宗主投盟、結盟、宣戰、停戰（C5b3）：補丁套在最新的骨架上，地圖跟著補（新盟的秘境、官道）。"""
    realm = league.apply(ensure(conn, user_id), patch)
    repos.set_immortal(conn, user_id, realm)
    sync_map(conn, realm)


def succeed(conn, user_id: str, life: str, clock_now: int) -> None:
    """這一生結束（殞落、退隱）時還是宗主（C5b2）：長老接位、動盪、可能爭位分裂；仙域傳開。"""
    if repos.get_immortal(conn, user_id) is None:
        return
    realm = ensure(conn, user_id)
    s = next((x for x in realm["sects"] if x.get("founder") == life), None)
    if not s:
        return
    realm, facts, heir, split = lord.succeed(random.Random(f"{realm['seed']}:heir:{life}"), realm, s, clock_now)
    repos.set_immortal(conn, user_id, realm)
    _lead(conn, realm["world"], heir, s["name"])
    if split:
        repos.delete_bond(conn, realm["world"], split[0], s["name"], society.MEMBER_BONDS)
        _lead(conn, realm["world"], split[0] if split[1] else "", split[1])
    for text in facts:
        repos.insert_rumor(conn, realm["world"], rumors.make(rumors.AFFAIRS, NAME, place="", detail=text, when=clock_now))
    sync_map(conn, realm)


def _lead(conn, world_id: str, name: str, hall: str) -> None:
    """name 成了 hall 的首領（原本的成員羈絆換掉）。"""
    if name:
        repos.delete_bond(conn, world_id, name, hall, society.MEMBER_BONDS)
        repos.insert_bond(conn, world_id, "", sect.member_bond(name, hall, leader=True))


def enlist(conn, user_id: str, sect_name: str, n: int) -> list[str]:
    """宗主招收（C4d）：散仙名單裡還沒入宗的 n 個人收進名冊。回傳名字。"""
    realm, took = roster.enlist(ensure(conn, user_id), random.Random(0), [sect_name], n)
    repos.set_immortal(conn, user_id, realm)
    return took


def avatars(conn, session: dict, sheet: dict, clock_now: int) -> dict[str, tuple[str, dict, str]]:
    """這個仙域裡其他正在進行的一生（D1 化身）：道號 → (那一生, 這回合用的 NPC, 他的仙宗)。位置照時間推算（D1b），
    剛玩過的那一段照角色卡。萬一跟世界裡的人同名就不出現（D1b 之前飛升、沒有道號的舊角色）。"""
    realm = ensure(conn, session["user_id"])
    taken = {p["name"] for p in repos.list_npcs(conn, session["world_id"])} | {identity.own_name(sheet)}
    wilds, out = _wilds(conn, realm, clock_now), {}
    for s in repos.list_sessions_in_world(conn, session["world_id"]):
        other = repos.get_character(conn, s["id"]) if s["id"] != session["id"] and s["phase"] in AVATAR_PHASES else None
        name = other and identity.own_name(other)
        if other and other["status"] == "ALIVE" and name not in taken | set(out):
            out[name] = (s["id"], avatar.npc_of(other, name, _place_of(realm, s, other, wilds, clock_now)), other["sect"])
    return out


def resume(conn, session: dict, sheet: dict, clock_now: int) -> tuple[dict, list[str]]:
    """換玩這一生（D1b）：離開以後的最近 MAX_SLOTS 段，化身在各處碰上的人補算交情、記一則總結；所在地改成推算的位置。"""
    first, last = session["clock_shichen"] // avatar.SLOT + 1, clock_now // avatar.SLOT
    if first > last:
        return sheet, []
    realm, world_id = ensure(conn, session["user_id"]), session["world_id"]
    people, bonds, wilds = repos.list_npcs(conn, world_id), repos.list_bonds(conn, world_id), _wilds(conn, realm, clock_now)
    ally = {s["name"]: s["alliance"] for s in realm["sects"]}
    mine = ally.get(sheet["sect"], "")

    def kin(name: str) -> str:
        theirs = merit.sect_of(realm, bonds, name)
        if mine and ally.get(theirs) == mine:
            return "同盟"
        return "敵盟" if merit.foe(realm, sheet["sect"], theirs) else ""
    met, place = {}, sheet["location"]
    for slot in range(max(first, last - avatar.MAX_SLOTS + 1), last + 1):
        rng = random.Random(f"{realm['seed']}:{session['id']}:{slot}")
        place = avatar.where(rng, sheet, realm, wilds, war.current(realm, slot * avatar.SLOT))
        hit = avatar.mingle(rng, [p for p in people if p["location"] == place and p["status"] == "ALIVE"], kin)
        if hit:
            met[hit[0]] = met.get(hit[0], 0) + hit[1]
    for name, d in met.items():   # 同盟算幫忙、敵盟算冒犯，不到 5 不記（第 1-2 批）
        add_reasons(conn, world_id, name, session["id"],
                   opinion.near(opinion.HELP if d > 0 else opinion.INSULT, opinion.LIKE, d), clock_now)
    if met:
        repos.insert_memory(conn, world_id, session["id"], avatar.summary(sheet["name"], met, clock_now))
    return {**sheet, "location": place}, [avatar.summary(sheet["name"], met, clock_now)["text"]] if met else []


def _place_of(realm: dict, s: dict, sheet: dict, wilds: list[str], clock_now: int) -> str:
    slot = clock_now // avatar.SLOT
    if s["clock_shichen"] // avatar.SLOT >= slot:   # 剛玩過的這一段
        return sheet["location"]
    rng = random.Random(f"{realm['seed']}:{s['id']}:{slot}")
    return avatar.where(rng, sheet, realm, wilds, war.current(realm, slot * avatar.SLOT))


def _wilds(conn, realm: dict, clock_now: int) -> list[str]:
    """散仙的化身會去的地方：虛空裂隙、遺址、這個百日的造化。"""
    ruins = sorted(l["name"] for l in repos.list_locations(conn, realm["world"]) if l["type"] == "廢墟")
    return [ascent.VOID] + ruins + [b["place"] for b in war.boons(realm, clock_now)]


def claim(conn, user_id: str, key: str, sect_name: str) -> None:
    """玩家搶到造化（C3b）：這一處不能再搶；下一個百日結算歸他的仙宗（散仙空字串：照實力擲）。"""
    realm = ensure(conn, user_id)
    repos.set_immortal(conn, user_id, {**realm, "claimed": {**realm.get("claimed", {}), key: sect_name}})


def _draw(conn, realm: dict, sect_name: str, place: str, taken: set[str], *, rank: str = roster.MEMBER,
          leaders: bool = False) -> str:
    who = roster.next_up(realm, sect_name, taken, leaders)
    if who is None:
        return ""
    if isinstance(who, dict):   # 飛升上來的：從原世界搬
        return _move(conn, repos.get_world(conn, realm["world"])["user_id"], who, place)
    old, i = who
    s = next((x for x in realm["sects"] if x["name"] == old), None)
    origins = [f"{w['name']}的{b['sect']}" for b in (s or {}).get("branches", [])
               if (w := repos.get_world_or_none(conn, b["world"]))]
    p = roster.person(realm["seed"], old, i, rank=rank if sect_name else roster.LOOSE, origins=origins,
                      race=s["race"] if s else races.HUMAN, clock_now=now(conn, realm))
    repos.insert_npc(conn, realm["world"], "", {**p, "location": place, "created_by": sect.MEMBER_BY, "first_seen_turn": 0})
    if sect_name:
        repos.insert_bond(conn, realm["world"], "", sect.member_bond(p["name"], sect_name, rank == roster.LEADERS[0]))
    return p["name"]


def add_merit(conn, user_id: str, sect_name: str, points: int) -> None:
    """玩家打退敵盟替仙宗掙的戰功記在仙宗的帳上（C2），百日演進時算進實力。"""
    realm = ensure(conn, user_id)
    won = realm.get("merit", {})
    repos.set_immortal(conn, user_id, {**realm, "merit": {**won, sect_name: won.get(sect_name, 0) + points}})


def tick(conn, session: dict, up: bool) -> None:
    """每回合開始（在交易內）：補算仙域的演進；下界的世界順便看看本山的上宗是不是覆滅了（C1 雙向連動）。"""
    if repos.get_immortal(conn, session["user_id"]) is None:
        return
    realm = ensure(conn, session["user_id"])
    if up:
        return
    world_id, kept = session["world_id"], []
    for f in realm.get("fallen", []):
        mine = [b for b in f["branches"] if b["world"] == world_id]
        for b in mine:   # 上宗覆滅：本山被別的仙宗收編；這個世界傳開「本山背後出了大變故」（不說出仙宗名）
            home = next((x for x in repos.list_factions(conn, world_id) if x["name"] == b["sect"]), None)
            path = (home or {}).get("traits", {}).get("道統") or DEFAULT_PATH
            realm, new = immortal.pick(realm, random.Random(f"{world_id}:{b['sect']}:{f['name']}"), path, races.HUMAN)
            realm = immortal.branch(realm, new, world_id, b["sect"])
            if not any(x["name"] == new for x in repos.list_factions(conn, world_id)):
                repos.insert_faction(conn, world_id, "", {"name": new, "type": society.IMMORTAL_SECT, "location": "",
                                                          "discovered_turn": 0})
            repos.rebind(conn, world_id, b["sect"], f["name"], new)
            repos.insert_rumor(conn, world_id, rumors.make(rumors.AFFAIRS, b["sect"], place=(home or {}).get("location", ""),
                                                           detail=f"{b['sect']}背後的上宗出了大變故，換了靠山",
                                                           when=repos.get_world(conn, world_id)["clock_shichen"]))
        rest = [b for b in f["branches"] if b["world"] != world_id]
        kept += [{**f, "branches": rest}] if rest else []
    if kept != realm.get("fallen", []):
        repos.set_immortal(conn, session["user_id"], {**realm, "fallen": kept})


def adopt_world(conn, realm: dict, world_id: str) -> dict:
    """這個世界的本山從屬的仙宗：仙域裡沒有的補進來，並記下分支。"""
    factions = repos.list_factions(conn, world_id)
    uppers = {f["name"] for f in factions if f["type"] == society.IMMORTAL_SECT}
    paths = {f["name"]: f["traits"].get("道統") or DEFAULT_PATH for f in factions if f["type"] == "宗門"}
    for b in repos.list_bonds(conn, world_id):
        if b["type"] == "從屬" and b["a"] in paths and b["b"] in uppers:
            realm = immortal.branch(immortal.adopt(realm, b["b"], paths[b["a"]], races.HUMAN), b["b"], world_id, b["a"])
    return realm


def link_upper(conn, world_id: str, made: dict) -> dict:
    """生成的區域有本山：上宗換成仙域裡挑的仙宗（世界裡已經有這個仙宗就不再登錄一次），記下分支。"""
    upper = next((f for f in made["factions"] if f["type"] == society.IMMORTAL_SECT), None)
    home = next((f for f in made["factions"] if f["type"] == "宗門"), None)
    if not upper or not home:
        return made
    user = repos.get_world(conn, world_id)["user_id"]
    realm, name = immortal.pick(ensure(conn, user), random.Random(f"{world_id}:{home['name']}:upper"),
                                home["traits"]["道統"], made.get("race", races.HUMAN))
    realm = immortal.branch(realm, name, world_id, home["name"])
    repos.set_immortal(conn, user, realm)
    if realm.get("world") and repos.get_world_or_none(conn, realm["world"]):   # 新立的仙宗馬上登錄山門（C3a 補）
        sync_map(conn, realm)
    known = any(f["name"] == name for f in repos.list_factions(conn, world_id))
    return {**made, "factions": [{**f, "name": name} if f is upper else f for f in made["factions"]
                                 if not (f is upper and known)],
            "bonds": [{**b, "b": name} if b["b"] == upper["name"] else b for b in made["bonds"]]}


def world(conn, user_id: str) -> str:
    """玩家的仙域世界（16l B3）：第一個人飛升時才建立（時間從骨架記的仙域時間開始），id 記在仙域骨架。"""
    realm = ensure(conn, user_id)
    if realm.get("world") and repos.get_world_for_user(conn, realm["world"], user_id):
        return realm["world"]
    world_id = new_id("wld")
    repos.insert_world(conn, world_id=world_id, user_id=user_id, name=NAME, rng_seed=secrets.token_hex(16),
                       kind=world_mod.IMMORTAL, clock_shichen=realm.get("clock", 0))
    realm = {**realm, "world": world_id}
    repos.set_immortal(conn, user_id, realm)
    sync_map(conn, realm)
    return world_id


def land(conn, user_id: str, world_id: str, pick: dict) -> str:
    """落點：投入的仙宗的山門（sync_map 已經登錄），散仙落在虛空裂隙（第一次有人來才登錄）。回傳地名。"""
    name = ascent.landing(pick)
    realm = ensure(conn, user_id)
    if pick["sect"]:
        sync_map(conn, realm)
    elif not any(l["name"] == name for l in repos.list_locations(conn, world_id)):   # 虛空裂隙遠行可到最近的山門
        repos.insert_location(conn, world_id, "", {"name": name, "description": space.NEW_PLACE_DESCRIPTION,
                                                   "type": "荒野", "scale": "村落", "danger": "中", "discovered_turn": 0})
        gate = min(realm["sects"], key=lambda s: (abs(s["cells"][0][0]) + abs(s["cells"][0][1]), s["name"]))["name"]
        repos.insert_connection(conn, world_id, "", {"a": name, "b": gate + ascent.GATE, "tier": "遠行", "direction": "",
                                                     "distance_km": space.DISTANCE_TIERS["遠行"], "discovered_turn": 0})
    return name


def now(conn, realm: dict) -> int:
    """仙域現在的時間（時辰）：有仙域世界就看它的時鐘，還沒有就看骨架記的。"""
    w = realm.get("world") and repos.get_world_or_none(conn, realm["world"])
    return w["clock_shichen"] if w else realm.get("clock", 0)


def flow(conn, user_id: str, shichen: int) -> None:
    """下界實際玩出的時間流進仙域（16l 第 7 題）：天上一日，地上一年——下界 RATIO 個時辰＝仙域一個時辰，零頭累積。"""
    realm = repos.get_immortal(conn, user_id)
    if realm is None or shichen <= 0:
        return
    add, carry = divmod(realm.get("carry", 0) + shichen, immortal.RATIO)
    clock = now(conn, realm) + add
    if add and realm.get("world"):
        repos.set_world_clock(conn, realm["world"], clock)
    repos.set_immortal(conn, user_id, {**realm, "carry": carry, "clock": clock})


def mark_sync(conn, user_id: str, world_id: str) -> None:
    """有人從這個世界飛升上去：記下對時（以世界為單位，已經記過就不動，回流照最早那次累積）。"""
    realm = ensure(conn, user_id)
    synced = realm.get("synced", {})
    if world_id not in synced:
        repos.set_immortal(conn, user_id, {**realm, "synced": {**synced, world_id: now(conn, realm)}})


def backflow(conn, user_id: str, world_id: str) -> int:
    """回流（16l 第 7-1 題）：這個世界開新的一生時，上次對時以來仙域過了多久 × RATIO（下界的時辰），並重新對時。
    沒人從這裡飛升過回傳 0。回流的時間不再流進仙域（不經過 flow）。"""
    realm = repos.get_immortal(conn, user_id)
    if realm is None or world_id not in realm.get("synced", {}):
        return 0
    t = now(conn, realm)
    repos.set_immortal(conn, user_id, {**realm, "synced": {**realm["synced"], world_id: t}})
    return (t - realm["synced"][world_id]) * immortal.RATIO


def link_life(conn, user_id: str, origin_world: str, origin_life: str, new_life: str) -> None:
    """主角飛升（B3b）：記下他原本是哪一生；已經從同一個世界上來、跟他有關係的人，關係接到仙域這一局。"""
    realm = ensure(conn, user_id)
    repos.set_immortal(conn, user_id, {**realm, "lives": {**realm.get("lives", {}), origin_life: new_life}})
    arrived = {a["name"]: a.get("as", a["name"]) for a in realm.get("arrived", []) if a["world"] == origin_world}
    for r in repos.list_relations(conn, origin_world):   # 撞名取了道號的人，關係記在道號上（D1b）
        if r["session_id"] == origin_life and r["npc_name"] in arrived:
            repos.upsert_relation(conn, realm["world"], arrived[r["npc_name"]], new_life, r)
            carry_reasons(conn, origin_world, realm["world"], r["npc_name"], origin_life, arrived[r["npc_name"]], new_life)


def take_dao(conn, user_id: str, sheet: dict, words: str) -> str:
    """主角飛升取道號（D1b，第 26 題）：說了「道號某某」而且沒人用就用它，否則自動取；記進骨架 daos，
    之後仙域生成名冊、搬人上來都避開。"""
    realm = ensure(conn, user_id)
    up = world(conn, user_id)
    taken = ({p["name"] for p in repos.list_npcs(conn, up)} | {l["name"] for l in repos.list_locations(conn, up)}
             | set(realm.get("daos", [])))
    name = avatar.dao(random.Random(f"{realm['seed']}:{sheet['name']}:{len(realm.get('daos', []))}"), sheet["name"],
                      words, taken)
    if name:
        repos.set_immortal(conn, user_id, {**ensure(conn, user_id), "daos": realm.get("daos", []) + [name]})
    return name


def npc_ascend(conn, session: dict, name: str, clock_now: int) -> None:
    """NPC 破空（16l 第 4 題追加丙）：原世界傳開；都記進仙域名冊（C0：名字、原世界、上宗，沒有宗門的是散仙）。
    跟任何一生的主角有關係紀錄或記事的馬上搬進仙域，其他人等見面時（draw）才搬。"""
    world_id, user = session["world_id"], session["user_id"]
    p = next(x for x in repos.list_npcs(conn, world_id) if x["name"] == name)
    repos.insert_rumor(conn, world_id, rumors.make(rumors.ASCENDED, name, place=p["away_from"], when=clock_now,
                                                   lv=ascent.LV, subject_lv=ascent.LV))
    realm = ensure(conn, user)
    entry = {"name": name, "world": world_id, "sect": _upper_of(conn, world_id, name, realm)}
    if entry not in realm.get("ascended", []):
        repos.set_immortal(conn, user, {**realm, "ascended": realm.get("ascended", []) + [entry]})
    if any(r["npc_name"] == name for r in repos.list_relations(conn, world_id)) or any(
            n["subject_kind"] == memory.NPC and n["subject"] == name and n["session_id"]
            for n in repos.list_memories(conn, world_id)):
        _move(conn, user, entry, "")


def _move(conn, user: str, entry: dict, spot: str) -> str:
    """飛升上來的人帶著境界、性格、記事從原世界搬進仙域（spot 空＝有宗門的落在上宗山門，其他人落在虛空裂隙），
    已經飛升的主角跟他的關係接過去。仙域裡已經有人叫這個名字就取道號（D1b），記事、關係跟著換名。
    回傳他在仙域的名字（已經搬過的回傳空字串）。"""
    world_id, name = entry["world"], entry["name"]
    if any(a["world"] == world_id and a["name"] == name for a in ensure(conn, user).get("arrived", [])):
        return ""
    p = next(x for x in repos.list_npcs(conn, world_id) if x["name"] == name)
    up = world(conn, user)
    taken = {x["name"] for x in repos.list_npcs(conn, up)} | set(ensure(conn, user).get("daos", []))
    final = name if name not in taken else avatar.dao(random.Random(f"{world_id}:{name}"), name, "", taken)
    if not final:
        return ""
    shift = repos.get_world(conn, up)["clock_shichen"] - repos.get_world(conn, world_id)["clock_shichen"]
    spot = spot or land(conn, user, up, {"sect": entry["sect"], "rank": "", "oath": ""})
    repos.insert_npc(conn, up, "", {**p, "name": final, "location": spot, "goal": "求道", "goal_target": "",
                                    "away_since": None, "away_from": "",
                                    "evolved_shichen": repos.get_world(conn, up)["clock_shichen"],
                                    "birth_shichen": None if p["birth_shichen"] is None else p["birth_shichen"] + shift}, past=False)
    if entry["sect"]:
        repos.insert_bond(conn, up, "", sect.member_bond(final, entry["sect"]))
    relations = [r for r in repos.list_relations(conn, world_id) if r["npc_name"] == name]
    notes = [n for n in repos.list_memories(conn, world_id) if n["subject_kind"] == memory.NPC and n["subject"] == name]
    for n in notes:
        repos.insert_memory(conn, up, "", {**n, "id": None, "thread_id": None, "rumor_id": None, "subject": final,
                                           "clock_shichen": max(0, n["clock_shichen"] + shift)})
    realm = ensure(conn, user)
    lives = realm.get("lives", {})
    for r in relations:
        if r["session_id"] in lives:
            repos.upsert_relation(conn, up, final, lives[r["session_id"]], r)
            carry_reasons(conn, world_id, up, name, r["session_id"], final, lives[r["session_id"]], shift)
    repos.set_immortal(conn, user, {**realm, "arrived": realm.get("arrived", []) + [
        {"world": world_id, "name": name, "as": final}]})
    mark_sync(conn, user, world_id)
    return final


def _upper_of(conn, world_id: str, name: str, realm: dict) -> str:
    """這個人所屬本山的上宗（在仙域裡的才算）；沒有門派回傳空字串。"""
    bonds, sects = repos.list_bonds(conn, world_id), {s["name"] for s in realm["sects"]}
    halls = {b["b"] for b in bonds if b["a"] == name and b["type"] in ("成員", "首領")}
    return next((b["b"] for b in bonds if b["type"] == "從屬" and b["a"] in halls and b["b"] in sects), "")


def export(conn, user_id: str, world_id: str) -> list[dict]:
    """存檔帶走這個世界用到的仙宗（分支在匯入時照從屬關係重記）。"""
    return [{**{k: v for k, v in s.items() if k != "roster"}, "branches": [], "cells": []} for s in immortal.of_world(repos.get_immortal(conn, user_id) or {"sects": []},
                                                              world_id)]


def merge(conn, user_id: str, world_id: str, packed: list[dict]) -> None:
    """匯入的世界：帶來的仙宗同名就合併、沒有就加進仙域；再照從屬關係記下分支。"""
    realm = ensure(conn, user_id)
    for s in packed:
        if not any(x["name"] == s["name"] for x in realm["sects"]):   # 地盤照仙域現在的樣子重新安排
            realm = immortal.seat({**realm, "sects": realm["sects"] + [{**s, "branches": [], "cells": []}]},
                                  random.Random(f"{realm['seed']}:{s['name']}"), s["name"])
    repos.set_immortal(conn, user_id, adopt_world(conn, realm, world_id))
