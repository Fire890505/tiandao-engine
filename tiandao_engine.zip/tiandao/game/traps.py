"""陷阱在回合裡（WHITEPAPER 16v 第 81-6～81-10 題）：埋、識破、落下、應付、假線索。規則在 domain/trap.py。"""
from __future__ import annotations

from ..domain import dark, plot, space, status, trap
from ..domain.clock import SHICHEN_PER_DAY
from . import incidents, routes

SPOTS = {False: "處境不利", True: "處境險惡"}   # 判定加減見 domain/status.EDGE
DELAY = 5 * SHICHEN_PER_DAY                    # 拖延：路線期限近幾天
AIMS = {dark.MOVE: "把東西搬走", dark.SEND: "把知情的人送走", dark.KILL: "讓知情的人閉嘴", dark.BRIBE: "拿錢堵你的嘴", dark.RUSH: "提早動手",
        dark.FAKE: "再添一條假規矩", dark.WATCH: "盯上你", dark.TAKE_AWAY: "再帶走一個人", dark.SHIFT: "換個地方", dark.LIE: "放出錯的說法",
        dark.HAUNT: "纏上你", dark.SCARE: "嚇住知情的人", dark.SWAY: "說動知情的人",dark.BUY: "收買知情的人", dark.SMEAR: "放話壞你的名聲", dark.GRAB: "搶先拿走證據"}


def running(sheet: dict) -> bool:
    d, r = sheet.get("dark"), sheet["route"]
    return bool(d and r and d["key"] == r["key"] and d["state"] == dark.RUN)


def plan(rows: dict, sheet: dict, here: str, verdict) -> str:
    """這回合對手怎麼出手（牌組看這個決定要不要照舊抽機會、命運、代價）。"""
    if not (running(sheet) and routes.at(rows, sheet["route"], here) and verdict.action_type in trap.ACTS):
        return ""
    d = sheet["dark"]
    how = trap.plan(d, verdict.outcome, True)
    left = trap.options(dark.deck_of(sheet["route"]), d["step"], trap.ACTS[verdict.action_type], set(d["spent"]), True)
    return how if how == trap.SEE or left else ""   # 這條暗線的陷阱用完了：照舊抽代價、命運


def see(d: dict) -> tuple[dict, list[str]]:
    """識破最早埋下的那張。"""
    t = d["traps"][0]
    return {**d, "traps": d["traps"][1:]}, [f"識破了：{plot.fill(trap.card(t['sign']).seen, t['words'])}"]


def foresee(sheet: dict) -> tuple[dict, list[str]]:
    """機會牌的看破：有陷阱就識破一張，沒有就知道對手下一步的方向（不是全文）。"""
    d = sheet["dark"]
    if d["traps"]:
        d, said = see(d)
        return {**sheet, "dark": d}, said
    nxt = dark.tier(d, dark.deck_of(sheet["route"]))
    aim = AIMS.get(nxt[0].effect, "把事情鬧大" if nxt[0].effect else "再動一次手") if nxt else ""
    return sheet, [f"你隱約知道，對方下一步要{aim}"] if aim else []


def _place(c) -> str:
    """假線索指的地方：相連的村鎮，不是路線那裡。"""
    town = space.town_of(c.rows["locations"], c.here)
    near = sorted(n["name"] for n in space.neighbors(c.rows.get("connections", []), town) if n["name"] != c.r["place"])
    return c.rng.choice(near) if near else ""


def _spring(out, d: dict, card: trap.Card, words: dict, strong: bool) -> dict:
    fall = plot.fill(card.fall, words)
    out.choices = [plot.fill(w, words) for w, _ in card.ways]
    out.events.append(fall)
    out.scene = f"（陷阱）{fall}。寫到主角得決定怎麼應付為止"
    return {**d, "sprung": {"sign": card.sign, "words": words, "strong": strong}}


def _pay(out, c, d: dict, cost: str, words: dict, strong: bool) -> dict:
    n = 2 if strong else 1   # 加強版代價重一級
    if cost in (trap.HURT, trap.MONEY):
        for _ in range(n):
            got = incidents.pay(cost, out.sheet, c.rows, c.rng)
            out.sheet, out.changes, out.events = got.sheet, out.changes + got.changes, out.events + got.events
    elif cost == trap.SPOT:
        bad = status.make(SPOTS[strong], status.NEGATIVE, 20, c.now + SHICHEN_PER_DAY * n)
        out.sheet = {**out.sheet, "statuses": status.add([dict(s) for s in out.sheet["statuses"]], bad)}
        out.events.append(f"留下狀態「{bad['name']}」")
    elif cost == trap.DELAY:
        out.sheet = {**out.sheet, "route": {**out.sheet["route"], "since": out.sheet["route"]["since"] - DELAY * n}}
        out.events.append("耽擱了好幾天，這件事的期限更近了")
    elif cost == trap.DECOY:
        out.choices = [f"前往{words['地']}"]
        return {**d, "decoy": words["地"]}
    return d


def _answer(out, c, d: dict, text: str) -> dict:
    """落下的下一回合：照玩家說的應付，沒選算第一個。"""
    s = d["sprung"]
    card, words = trap.card(s["sign"]), s["words"]
    way, cost = trap.answer(tuple((plot.fill(w, words), x) for w, x in card.ways), text)
    out.events.append(f"應付：{way}")
    return _pay(out, c, {**d, "sprung": None}, cost, words, s["strong"])


def _arrive(out, c, d: dict) -> dict:
    """走到假線索指的地方：發現被騙，同時浮出一件真事（母型 5-c，第 5-5-10 題）：最早一條還沒看見的破綻，都看見過就是幕後的記號。"""
    d, said = dark.reveal(d)
    true = f"倒是打聽到一件真事：{said}" if said else f"倒是打點的人身上帶著{d['mark']}"
    out.events.append(f"到了{d['decoy']}才發現被騙了，這裡什麼都沒有；{true}")
    return {**d, "decoy": ""}


def turn(out, c, d: dict, *, verdict, text: str, spot, cast: dict, near: bool, crowded: bool) -> dict:
    """一回合最多一件：回話 → 到了假的地方 → 識破 → 埋或當場落下 → 埋著的落下。換階不拿掉，路線收場暗線就換了（第 81-11 題）。
    crowded：這回合已經有別的事，不落下，大失敗改成先埋（第 81-15 題）。"""
    if d["sprung"] or _decoyed(c, d):
        return _answer(out, c, d, text) if d["sprung"] else _arrive(out, c, d)
    looking = near and (verdict.is_success or not verdict.rolled) and verdict.action_type in trap.ACTS
    hit = next((t for t in d["traps"] if looking and spot(plot.fill(t["sign"], t["words"]))), None)
    if hit:   # 去查苗頭
        rest = [t for t in d["traps"] if t is not hit]
        d, said = see({**d, "traps": [hit, *rest]})
        out.events += said
        return d
    how = trap.plan(d, verdict.outcome, near and verdict.action_type in trap.ACTS)
    if how == trap.SEE:
        d, said = see(d)
        out.events += said
        return d
    if how == trap.STRONG and crowded:
        how = trap.BURY if len(d["traps"]) < trap.MAX else ""
    if how:
        place = _place(c)
        words = {**cast, "人": c.focus or "那個人", "地": place}
        card = trap.pick(c.rng, dark.deck_of(c.r), d["step"], trap.ACTS[verdict.action_type], set(d["spent"]), bool(place))
        if not card:
            return d
        d = {**d, "spent": [*d["spent"], card.sign]}
        if how == trap.STRONG:
            return _spring(out, d, card, words, True)
        out.events.append(plot.fill(card.sign, words))
        return {**d, "traps": [*d["traps"], {"sign": card.sign, "at": c.turn_no, "words": words}]}
    due = next((t for t in d["traps"] if t["at"] < c.turn_no), None) if near and not crowded else None
    if due:
        return _spring(out, {**d, "traps": [t for t in d["traps"] if t is not due]}, trap.card(due["sign"]), due["words"], False)
    return d


def _decoyed(c, d: dict) -> bool:
    return bool(d["decoy"]) and space.town_of(c.rows["locations"], c.here) == d["decoy"]


def after(out, c, d: dict, *, act: str, text: str, cast: dict, near: bool, crowded: bool) -> dict:
    """打斷之後（第 5-4a 批）：落下的照樣回話、假線索照樣到；反咬過，第一次離開那裡對手的人當場出手一張（大典第 32 條）。"""
    if d["sprung"] or _decoyed(c, d):
        return _answer(out, c, d, text) if d["sprung"] else _arrive(out, c, d)
    if not d["hunt"] or near or crowded:
        return d
    place = _place(c)
    card = trap.pick(c.rng, dark.deck_of(c.r), d["step"], act, set(d["spent"]), bool(place))
    d = {**d, "hunt": False}
    return _spring(out, {**d, "spent": [*d["spent"], card.sign]}, card, {**cast, "人": c.focus or "那個人", "地": place}, False) if card else d
