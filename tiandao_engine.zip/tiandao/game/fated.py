"""一般命的章（第 116c 批；第 116-5、116-6、116-7、116-12 題甲）：章是一條你的事端。特殊命照 routes 的命途。

- 開章（queue）：該開章、還沒開著：十二宮照分數抽（大限、上一章、偏宮各 ×2），在你境界那一級的範圍單位放一條同範圍的事端，
  不佔那個單位的名額；宮裡的人（上一章抗著的人先）對得上角色就演（plots.place 讀 town 的 fate、first）。
- 交會（第 7-4a 批，WHITEPAPER (69)）：宮裡排第一的那人跟你照命的類挑結（domain/knot），結的人排在後面先挑角色，記在 cast[knot.KNOT]。
  章收了判誰壓過（第 7-4b 批，_mark），記在那章紀錄的第五欄。
- 記下（turn）：放好的那條（cast[plot.CHAPTER]）記進 sheet["opened"]，連那時他對你的好感。天道手上空著先發它（routes._own）。
- 收章（turn）：事端走到結局或轉向、他不在了才收：死在你手上、被抓、好感降 SWING 以上＝抗著，升 SWING 以上＝順著，其他放著。
  沒收就衝關＝放著，照 115 罰（route.settle、route.owes）。
- 特殊命後章（第 116c-b 批）：命主定了，在章那裡的範圍單位放一條同範圍的事端當場面，命主先演；說書人多一句場面（scene）。
  事端只當場面，章照它的三條選擇收（第 116-6 題）；放過一次就不再放，事端走完了章照樣走。
"""
from __future__ import annotations

import random

from ..domain import knot, origins, palace, plot, route, stage
from ..domain.evolution import SWING
from . import people, routes


def _like(rows: dict, who: str) -> int:
    return people.relation(rows, who)["affinity"] if people.find(rows, who) else 0


def _mine(rows: dict, sheet: dict, ever: bool = False) -> dict | None:
    """這一生、這一章放好的那條事端（還在走的；ever：走完的也算）。"""
    head = f"{rows.get('life', '')}:{route.chapter_no(sheet)}:"
    return next((p for p in rows["plots"] if (ever or p["ended_shichen"] is None) and p["cast"].get(plot.CHAPTER, "").startswith(head)), None)


def _boss(sheet: dict) -> str:
    """特殊命手上這章是後章、命主定了：命主。不然空字串。"""
    r = sheet["route"]
    return r["cast"].get(stage.BOSS, "") if sheet["hidden"] and stage.later(r) and stage.number(r) == route.chapter_no(sheet) else ""


def queue(ticked, rows: dict, sheet: dict, here: str, now: int, rng: random.Random) -> None:
    """該開章就排一條進 ticked.towns，回合結束時放（plots.write）。範圍單位不在這裡（人在鎮上、章在村落級）就等。"""
    n, boss = route.chapter_no(sheet), _boss(sheet)
    if not n or not rows.get("life") or sheet["hidden"] and not boss or sheet.get("opened") or _mine(rows, sheet, bool(boss)):
        return
    u = stage.LADDER[route.scope(sheet["realm_lv"]) - 1]
    name = plot.units(rows["locations"], rows.get("connections", []), rows.get("atlas"), boss and sheet["route"]["place"] or here).get(u)
    town = next((l for l in rows["locations"] if l["name"] == name), None)
    if not town:
        return
    if boss:   # 特殊命後章：宮在開章時抽過了（routes._land）
        p, first = sheet["route"]["palace"], [boss]
    else:
        f = origins.FATES.get(sheet["fate"])
        p = routes.land(rows, sheet, rng, now, palace.PALACES, sheet["fate"], [f.lean] if f and f.lean else [])
        mine = palace.who(routes.board(rows, sheet), p)
        heir = routes.caller(sheet, mine) or routes._heir(rows, sheet, p)   # 命數找上過你的人先（併章重設計第 7 題乙）
        first = [heir] + [n for n in mine if n != heir] if heir else mine
    last = next((r["name"] for r in rows["plots"] if r["town"] == name and r["ended_shichen"] is None), "")   # 不跟那裡正在走的同一條
    town = town if town["scale"] == u else {**town, "unit": u}
    him = people.find(rows, first[0]) if first else None   # 交會（第 7-4a 批）：宮裡那人跟你照類挑結
    alive = {q["name"] for q in rows["npcs"] if q["status"] == "ALIVE"}
    knots = knot.pick(rng, rows.get("mine", []) + rows["bonds"], alive, {q["name"] for q in rows["npcs"]} - alive, rows["life"],
                      first[0], knot.kind(sheet), knot.kind(him)) if him else []
    knots = [{**k, "like": _like(rows, k["who"])} if "who" in k else k for k in knots]   # 開章好感，收場比（第 7-4b 批）
    ticked.towns.append(({**town, "fate": f"{rows['life']}:{n}:{p}", "first": first + [k["who"] for k in knots if k.get("who") not in (None, *first)],
                          "want": {k["who"]: k["try"] for k in knots if "try" in k}, "knots": knots}, last))


def scene(rows: dict, sheet: dict) -> str:
    """特殊命後章給說書人的場面句：命主在那條事端裡演誰，沒角色演就在背後。沒有回傳空字串。"""
    rec = _mine(rows, sheet) if _boss(sheet) else None
    if not rec:
        return ""
    *_, who, role = rec["cast"][plot.CHAPTER].split(":")
    return f"。這章的場面是{rec['town']}正在發生的「{rec['name']}」：{who}在裡面{'是' + role if role else '沒露面，卻在背後牽著'}"


def turn(rows: dict, sheet: dict, killed: set[str] = frozenset(), templates: list[dict] = ()) -> dict:
    """記下放好的章；該收就收（看回合開始時的資料，抓人、好感都寫進去了；死在你手上看這回合的 killed）。
    收過的章有交會就判誰壓過（_mark；特殊命的章在 routes._close 收，這裡同一回合補上）。"""
    return _mark(rows, _turn(rows, sheet, killed), templates, killed)


def _mark(rows: dict, sheet: dict, templates: list[dict], killed: set[str]) -> dict:
    """最後收的那章有結、還沒判：同類照 knot.judge，異類記「異」，接在那章紀錄最後一欄（第 7-4b 批）。"""
    c = (sheet["chapters"] or [""])[-1]
    rec = knot.of(rows["plots"], rows.get("life", ""), len(sheet["chapters"])) if c.count(":") == 3 else None
    if not rec:
        return sheet
    him = people.find(rows, rec["cast"][plot.CHAPTER].rsplit(":", 2)[1]) or {}
    k = knot.read(rec["cast"])[0]
    t = next((t for t in templates if plot.name(t) == rec["name"]), None)
    early = bool(t) and None not in (rec["ended_shichen"], rec["lit_shichen"]) and rec["ended_shichen"] < plot.end_time(rec, t)
    v = knot.judge(k, people.find(rows, k["who"]), _like(rows, k["who"]), rec, early, killed) if knot.kind(sheet) == knot.kind(him) else knot.BOTH
    return {**sheet, "chapters": [*sheet["chapters"][:-1], f"{c}:{v}"]}


def _turn(rows: dict, sheet: dict, killed: set[str]) -> dict:
    o = sheet.get("opened")
    if not o:
        rec = None if sheet["hidden"] else _mine(rows, sheet)
        if not rec:
            return sheet
        _, _, p, who, _ = rec["cast"][plot.CHAPTER].rsplit(":", 4)
        return {**sheet, "opened": {"plot": plot.tag(rec), "palace": p, "who": who, "like": _like(rows, who)},
                "gripped": [g for g in sheet["gripped"] if g != who], "called": []}   # 要脅過的人回來過就劃掉（第 6-6c 批）；找上過你的清掉（併章重設計）
    rec, who = next((r for r in rows["plots"] if plot.tag(r) == o["plot"]), None), people.find(rows, o["who"])
    over = not rec or rec["ended_shichen"] is not None or rec["turned_shichen"] is not None
    if not (over or o["who"] in killed or not who or who["status"] != "ALIVE"):
        return sheet
    d, alive = _like(rows, o["who"]) - o["like"], bool(who) and who["status"] == "ALIVE" and o["who"] not in killed
    caught = alive and plot.JAIL_SPOT in who["location"]
    end = stage.AGAINST if o["who"] in killed or caught or alive and d <= -SWING else stage.ALONG if alive and d >= SWING else stage.LEFT
    return {**sheet, "opened": None, "chapters": [*sheet["chapters"], f"{end}:0:{o['who']}:{o['palace']}"]}
