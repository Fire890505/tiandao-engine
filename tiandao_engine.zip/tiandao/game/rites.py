"""流傳中的玩法在回合流程裡（19-3「儀式型完整版」）：開始流傳、有人動心、做儀式、主角與 NPC 介入。

規則在 domain/rites.py。資料來自回合開始時讀好的 rows["rites"]；結果放在 Rites，由 service 在回合的交易裡寫入（write）。
出事時開出的領域、NPC 救人破解的領域放在 zones.Zones（z），NPC 的變化放在背景演化的結果（updates）。
當夜的情境記在回合紀錄（delta 的 rite），下一回合看主角怎麼收尾。
"""
from __future__ import annotations

import random
from dataclasses import dataclass, field

from ..domain import domains, judgment, laws, opinion, rumors, space
from ..domain import memory as m
from ..domain import npc as npc_mod
from ..domain import rites as R
from ..domain import society
from ..domain.clock import SHICHEN_PER_MONTH, describe
from ..domain.tales import Tale, theme
from ..store import repos
from . import people

SAVED = opinion.hit(opinion.SAVE, opinion.LIKE, opinion.GRAVE)   # 被救出怪談：救命 +60（第 1-3 批）

@dataclass
class Rites:
    born: list[dict] = field(default_factory=list)
    changed: dict[str, dict] = field(default_factory=dict)
    events: list[str] = field(default_factory=list)
    rumors: list[dict] = field(default_factory=list)
    record: dict | None = None
    scene: str = ""
    prompt: str = ""

    def now(self, x: dict) -> dict:
        return self.changed.get(x["id"], x)


def _active(rows: dict, r: Rites) -> list[dict]:
    return [x for x in (r.now(x) for x in rows["rites"]) if x["stage"] in R.ACTIVE]


def _near(rows: dict) -> dict[str, list[str]]:
    return {l["name"]: [n["name"] for n in space.neighbors(rows["connections"], l["name"])] for l in rows["locations"]}


# ── 開始流傳（zones.spawn 抽中儀式型主題時）──────────────────────────────
def start(r: Rites, rng: random.Random, rows: dict, place: str, tale: Tale, clock_now: int) -> None:
    """做儀式的地方 place 所在的城鎮或村落開始流傳這個玩法（同一個地方已經有在流傳的就不重複）。"""
    if any(x["place"] == place for x in _active(rows, r) + r.born):
        return
    loc = next(l for l in rows["locations"] if l["name"] == place)
    town = R.town_of(loc, rows["locations"])
    x = R.make(rng, tale=tale, place=place, town=town, neighbors=_near(rows), clock_now=clock_now)
    if x:
        r.born.append(x)
        r.rumors.append(rumors.make(rumors.RITE, town, place=town, when=clock_now, detail=f"{tale.name}——{R.wrong(x)}"))


# ── 世界脈動跨過的時間 ───────────────────────────────────────────────────
def due(r: Rites, z, rows: dict, updates, rng: random.Random, *, start: int, end: int, here: str, turn_no: int,
        last: dict) -> None:
    """流傳的挑人、準備的做儀式（沒人攔就出事）、親近的人勸住或去救。主角正好在做儀式的地方＝當夜的情境。
    last：上回合的紀錄——上回合已經上演當夜的那一筆，這回合由 play 看主角怎麼收尾。"""
    months = end // SHICHEN_PER_MONTH - start // SHICHEN_PER_MONTH
    alive = {p["name"]: p for p in rows["npcs"] if p["status"] == "ALIVE"}
    busy = {x["person"] for x in _active(rows, r)} | {d["person"] for d in rows["domains"] if d["status"] == domains.ACTIVE}
    staged = last.get("rite") or {}
    for x in _active(rows, r):
        if (x["tale"], x["place"]) == (staged.get("tale"), staged.get("place")):
            continue
        if x["stage"] == R.SPREAD and end - x["created_shichen"] >= R.LASTS:
            r.changed[x["id"]] = R.end(x, R.FADED, end)
            continue
        if x["stage"] == R.SPREAD and x["next_shichen"] <= end:
            x = _tempt(r, x, rows, alive, busy, rng, end)
        if x["stage"] == R.READY:
            x = _talked_out(x, rows, alive, updates, rng, months, end)
        if x["stage"] == R.READY and x["next_shichen"] <= end:
            if here == x["place"] and not r.record:   # 主角在場：當夜的情境，下一回合看怎麼收尾
                r.record = {"tale": x["tale"], "place": x["place"]}
                r.scene = f"（儀式）{x['person']}點起燭火，照著流傳的玩法開始做{x['tale']}。只寫到儀式開始、主角還沒應對為止"
                updates.fields.setdefault(x["person"], {}).update(location=x["place"])
            else:
                x = _done(z, x, rows, updates, rng, x["next_shichen"])
        r.changed[x["id"]] = x
    _rescue(z, rows, updates, rng, alive, months, end, turn_no)


def _tempt(r: Rites, x: dict, rows: dict, alive: dict, busy: set[str], rng: random.Random, end: int) -> dict:
    """挑一個住在流傳地、會照玩法去做的人；沒有就下個月再挑。"""
    tale, spots = theme(x["tale"]), R.area(x["town"], rows["locations"])
    mourners = domains.mourners(rows["bonds"], {p["name"] for p in rows["npcs"] if p["status"] != "ALIVE"})
    who = sorted(n for n, p in alive.items() if p["location"] in spots and n not in busy and domains.doer(tale, p, mourners))
    if not who:
        return {**x, "next_shichen": end + SHICHEN_PER_MONTH}
    name = rng.choice(who)
    busy.add(name)
    r.rumors.append(rumors.make(rumors.PREP, name, place=x["town"], when=x["next_shichen"], detail=x["tale"]))
    return {**x, "stage": R.READY, "person": name, "next_shichen": x["next_shichen"] + R.PREP}


def _close(rows: dict, name: str, alive: dict) -> list[str]:
    """和他親近的人（親人、伴侶、友人、師徒），活著的。"""
    return sorted({b["b"] if b["a"] == name else b["a"] for b in rows["bonds"] if b["type"] in R.CLOSE
                   and b["a_kind"] == b["b_kind"] == society.NPC and name in (b["a"], b["b"])} & set(alive) - {name})


def _talked_out(x: dict, rows: dict, alive: dict, updates, rng: random.Random, months: int, end: int) -> dict:
    """親近的人每月可能勸住他（看善念、膽識）。"""
    for c in _close(rows, x["person"], alive):
        if rng.random() < R.chance(R.talk_chance(alive[c]), months):
            updates.rumors.append(rumors.make(rumors.FAVOUR, c, target=x["person"], place=x["town"], when=end))
            updates.events.append(f"{c}勸住了{x['person']}，他不打算做{x['tale']}了")
            return R.back_to_spread(x, end)
    return x


def _done(z, x: dict, rows: dict, updates, rng: random.Random, when: int) -> dict:
    """沒人攔：照 19-1 出事——他重傷、困在做儀式的地方、三個月期限。那裡已經被籠罩、或沒有路，就只是淡掉。"""
    up, near = {l["name"]: l["parent"] for l in rows["locations"]}, _near(rows)
    taken = [d["place"] for d in rows["domains"] if z.now(d)["status"] == domains.ACTIVE] + [d["place"] for d in z.born]
    loc = next((l for l in rows["locations"] if l["name"] == x["place"]), None)
    if loc is None or not near.get(x["place"]) or any(domains.overlaps(up, x["place"], p) for p in taken):
        return R.end(x, R.FADED, when)
    tale = theme(x["tale"])
    d = domains.make(rng, (x["place"], loc["scale"], tale), locations=rows["locations"], neighbors=near,
                     npcs=rows["npcs"], undead=rows["undead"], clock_now=when)
    d = {**d, "person": x["person"]}
    z.born.append(d)
    z.rumors.append(rumors.make(rumors.TALE, d["place"], place=d["place"], when=when, detail=domains.rumor_text(d),
                                lv=domains.power(d)))
    updates.fields.setdefault(x["person"], {}).update(condition="重傷", location=x["place"])
    return R.end(x, R.DONE, when)


def _rescue(z, rows: dict, updates, rng: random.Random, alive: dict, months: int, end: int, turn_no: int) -> None:
    """出事之後，和他親近、境界不低於規則之物的修士每月可能去救：救成＝破解（他記救命之恩、帳上記一筆恩），救不成＝他負傷。"""
    for d in [z.now(d) for d in rows["domains"]]:
        if d["status"] != domains.ACTIVE or not theme(d["tale"]).doer or d["person"] not in alive:
            continue
        for c in _close(rows, d["person"], alive):
            if alive[c]["realm_lv"] < domains.power(d) or rng.random() >= R.chance(R.RESCUE_CHANCE, months):
                continue
            if rng.random() < R.RESCUE_WIN:
                z.changed[d["id"]] = {**d, "status": domains.CLEARED, "chased": False, "solved_shichen": end}
                updates.reasons.append(opinion.reason(d["person"], c, SAVED, end))   # 恩人不存：記救命和一筆恩
                updates.ledger.append(society.owed(society.OWE, c, d["person"], end))
                updates.rumors.append(rumors.make(rumors.CLEARED, c, place=d["place"], when=end, lv=domains.power(d),
                                                  subject_lv=alive[c]["realm_lv"]))
                updates.events.append(f"{c}破了{d['place']}的怪談，救出了{d['person']}")
            else:
                updates.fields.setdefault(c, {}).update(condition="負傷")
                updates.world_notes.append(m.note(m.NPC, c, m.NEWS, f"去{d['place']}救{d['person']}，負傷而回",
                                                  clock_now=end, turn_no=turn_no))
            break


# ── 主角介入 ─────────────────────────────────────────────────────────────
def play(r: Rites, z, rows: dict, sheet: dict, *, life: str, verdict: judgment.Judgment, target: str, text: str,
         last: dict, clock_now: int, rng: random.Random, npc_changes: dict, updates) -> dict:
    """當夜怎麼收尾、找源頭與斷根、勸住或拿走道具、打聽。回傳角色卡。"""
    here, nature, ok = sheet["location"], verdict.action_type, verdict.is_success
    rec = last.get("rite") or {}
    present = {p["name"] for p in people.present(rows, here)}
    for x in _active(rows, r):
        tale = x["tale"]
        if x["stage"] == R.READY and (x["tale"], x["place"]) == (rec.get("tale"), rec.get("place")):   # 上回合的當夜
            sheet, x = _night(r, z, x, rows, sheet, life=life, nature=nature, ok=ok, target=target, text=text,
                              clock_now=clock_now, rng=rng, npc_changes=npc_changes, updates=updates)
        if here == x["source"] and x["stage"] in R.ACTIVE:
            if nature == judgment.EXPLORE and ok and x["known"] != life:
                x = {**x, "known": life}
                r.events.append(f"在{here}找到了{tale}玩法的源頭：流傳的「{R.wrong(x)}」是錯的，正確：{R.right(x)}")
            if x["known"] == life and any(w in text for w in R.CUT_WORDS):
                x = R.end(x, R.CUT, clock_now) if x["stage"] == R.SPREAD else {**x, "cut": True}
                r.events.append(f"把{tale}錯的玩法毀掉了，這一帶不會再有人照著做")
        if x["stage"] == R.READY and x["person"] in present:
            if nature == judgment.SOCIAL and ok and target == x["person"]:
                x = R.back_to_spread(x, clock_now)
                r.events.append(f"勸住了{target}，他不打算做{tale}了")
            elif nature == judgment.STEALTH and ok and any(w in text for w in R.TAKE_WORDS):
                x = {**x, "next_shichen": x["next_shichen"] + R.DELAY}
                r.events.append(f"拿走了{x['person']}準備做{tale}的東西，他得重新張羅")
        if (here in R.area(x["town"], rows["locations"]) and nature == judgment.SOCIAL and ok
                and any(w in text for w in ("打聽", "玩法", "儀式")) and x["stage"] in R.ACTIVE):
            plan = f"；{x['person']}在張羅，打算{describe(x['next_shichen'])['label']}夜裡做" if x["stage"] == R.READY else ""
            r.events.append(f"打聽到：這一帶流傳{tale}的玩法，說「{R.wrong(x)}」{plan}")
        r.changed[x["id"]] = x
    r.prompt = "；".join(f"這一帶最近流傳{x['tale']}的玩法（說：{R.wrong(x)}）"
                        + (f"，{x['person']}最近在張羅{x['tale']}要用的東西" if x["stage"] == R.READY
                           and x["person"] in present else "")
                        for x in _active(rows, r) if here in R.area(x["town"], rows["locations"]))
    return sheet


def _night(r: Rites, z, x: dict, rows: dict, sheet: dict, *, life: str, nature: str, ok: bool, target: str, text: str,
           clock_now: int, rng: random.Random, npc_changes: dict, updates) -> tuple[dict, dict]:
    """當夜：知道正確玩法、寫出正確的收尾＝平安結束；當場勸停；其他照常出事（主角就在現場）。"""
    name, tale = x["person"], theme(x["tale"])
    if x["known"] == life and any(w in text for w in R.finish(x)):
        if sheet["realm_lv"] >= 1:
            insight, reached = laws.reward(sheet, tale.law, R.CALM_INSIGHT)
            sheet = {**sheet, "insight": insight}
            r.events += reached
        relation, events = npc_mod.shift(name, people.changed_relation(rows, npc_changes, name), R.CALM)
        npc_changes.setdefault(name, {})["relation"] = relation
        r.events += [f"照著正確的玩法收了尾，{name}的{x['tale']}平安結束", *events]
        return sheet, R.back_to_spread(x, clock_now)
    if nature == judgment.SOCIAL and ok and target == name:
        r.events.append(f"當場勸停了{name}")
        return sheet, R.back_to_spread(x, clock_now)
    r.events.append(f"{name}的{x['tale']}出事了")
    return sheet, _done(z, x, rows, updates, rng, clock_now)


def write(conn, world_id: str, r: Rites) -> None:
    for x in r.born:
        repos.insert_rite(conn, world_id, x)
    for rid, x in r.changed.items():
        repos.update_rite(conn, rid, x)
