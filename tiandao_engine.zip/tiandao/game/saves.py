"""存檔：匯出整個世界、匯入成新世界、檢查存檔內容。

- 匯出不含亂數種子（不能從存檔預知未來的骰子）。
- 匯入一律建立新的世界與新的亂數種子；舊 id 不沿用。
- 存檔由使用者持有、可能被改過，所以每一項都重新檢查（checksum 只偵測損毀，不防竄改）。
  檢查寫成「欄位 → 檢查」的表，不合格時錯誤訊息會指出是哪一筆、哪個欄位。
"""
from __future__ import annotations

import hashlib
import secrets

from ..domain import character as character_mod
from ..domain import atlas, auction, bondage, chains, crime, disaster, effects, era, family, games, heaven, home, house, legacy, market
from ..domain import items as items_mod
from ..domain import undead as undead_mod
from ..domain import domains as domains_mod
from ..domain import legends as legends_mod
from ..domain import rites as rites_mod
from ..domain import tales as tales_mod
from ..domain import memory as memory_mod
from ..domain import npc as npc_mod
from ..domain import evolution, favour, form, hearsay, learn, looks, immortal, opinion, origins, pending, plot, prep, pressure, proxy, realm, route, scene, society, space, spots, voice
from ..domain import sect as sect_mod
from ..domain import incident, lapse, newitems, newlegends, newplots, newtales
from ..domain import rumors as rumors_mod
from ..domain import world as world_mod
from ..errors import BadRequest
from ..store import repos
from ..store.db import transaction
from ..util import dumps, iso, new_id
from . import proposals, realms
from .phases import ENDED, NEED_CHARACTER, PHASES, PLAYING

SAVE_FORMAT, SAVE_VERSION = "tiandao-save", 51   # v51：地點上說書立下的規矩（domain/house.py）；v50：地點裡的小地方（第 9g 批）；v49：NPC 人物層牌算到哪、家運（第 9f-1 批）； v48：人物卡的快照、聽過的心事（第 9e-4 批）；v47：小事補到哪、關押、記過（第 7-2a 批）；v46：NPC 的特點、口頭禪（第 7-1d 批）；v45：NPC 的學識、專長（第 7-1c 批）；v44：氣量、口風（第 7-1b 批）；v43：NPC 的出身（第 7-1a 批）；v42：NPC 的命、走過的章（實作第 122a、122b 批）；v41：見過面（實作第 1-5e 批）；v40：封口、封口費綁著那件事、受恩有人在場（實作第 1-5d 批）；v39：發生的事、誰知道（實作第 1-5a 批）；v38：主角的人情搬到帳上（實作第 1-4a 批）；v37：主角的關係（家人；實作第 1-3b 批）；v36：帳、友人仇家恩人同門不存、好感信任不存（實作第 1-3 批）；v35：好感原因（實作第 1-2 批）；v34：人情帳（16v 第 87 題）；v33：支線辦到哪（16v 第 76 題）；v32：線頭的來源、下一步（16v 第 78 題）
# v1：單局、沒有地點與 NPC（第 1 步之前）；v2：單局＋地點與 NPC（第 16 步之前）；v3：整個世界（含所有的局）；
# v4：世界多了路線，地點多了上層地點、規模、危險度（第 7 步）；v5：NPC 多了出生、境界、狀態等欄位，世界多了關係（第 6 步）；
# v6：世界多了記事與線頭（第 17 步）；v7：NPC 多了目標、性格、天道角色，世界多了勢力與羈絆，角色卡 v4 有外貌（第 10a 步）；
# v8：NPC 多了演算時間與修為，關係多了打聽到的目標（第 10b 步）；v9：記事多了 actor、attitude（不必解析記事文字）；
# v10：記事可以不屬於任何一生（life 為 None：世界脈動的記事，第 10c-1 步）；
# v11：NPC 多了去遠方的時間與地點（第 10c-2b 步）；v12：世界多了傳聞，記事可以指向聽到的傳聞（第 10c-3a 步）；
# v13：角色卡 v5 有江湖傳言中的你（第 10c-3b 步）；v14：世界多了地點狀況（第 9b 步）；
# v15：世界多了天道人格卡（第 18-1 步）；v16：世界多了棋譜（第 18-2a 步）；
# v17：世界多了遺物，人物可以是退隱的前人（created_by「retired」，第 11-1 步）；v18：世界多了亡者（第 11-2 步）；
# v19：世界多了前期領域（第 19-1 步；life＝最近進去的那一生，None＝還沒有人進去過）；v20：領域多了規模（v19 的照 OLD_SCALE 補）；
# v21：世界多了都市傳說（第 19-2 步；met／haunts＝碰上它、被它纏上的那一生，None＝沒有），人物可以是建角登錄的家人
# v24：勢力多了特徵（國家、宗門；16h），勢力可以是國家，人物可以是追捕者（created_by「official」）、
#      開世界時生成的宗門成員（created_by「sect」，不屬於任何一生：first_seen_life 為 None）
# v25：世界多了新物品（16p），角色卡 v36 有物品的叫法；v26：地點多了環境物（16r）；v27：世界多了新事件（16p）
# v28：世界多了事端（16t），人物可以是事端的人（created_by「plot」）
# v29：人物多了性別和支系（16u）
# v30：人物多了職業（16u 外貌第二批）；v31：世界多了世界碼和壓力（16v）
SUPPORTED_SAVE_VERSIONS = tuple(range(1, SAVE_VERSION + 1))
MAX_WORLD_NAMES = 1000   # 一個世界的地點、人物上限：事端和系統生成的也算，比說書人提案的上限（proposals.MAX_PER_SESSION）大

LOCATION_FIELDS = ("name", "description", "type", "parent", "scale", "danger", "discovered_turn", "features", "chat_shichen", "spot", "rules")
CONNECTION_FIELDS = ("a", "b", "distance_km", "tier", "direction", "discovered_turn")
NPC_FIELDS = ("name", "appearance", "profile", "speech", "location", "status", "ai_driven", "created_by", "race",
              "gender", "lineage", "job", "birth_shichen", "realm_lv", "stage_index", "hidden_power", "condition",
              "appearance_age", "profile_age", "speech_age", "goal", "goal_target", "ambition", "kindness",
              "courage", "suspicion", "heaven_role", "rewrite_reason", "evolved_shichen", "cultivation",
              "away_since", "away_from", "first_seen_turn", *origins.NPC_KEYS, "chapters", "opened", "origin", *npc_mod.TEMPERS, "learning", "knacks", "quirks", "catchphrase", "life_shichen", "fortune")
RELATION_FIELDS = ("npc_name", "grudge", "known_goal", "known_goal_shichen", "met", "seen", "heard")   # v36 起好感、信任只由原因算；v38 起人情在帳上；v41 見過面；v48 人物卡
HAPPENED_FIELDS = ("kind", "actor", "target", "place", "detail", "secret", "era", "clock_shichen", "turn_no")   # v39：誰知道
KNOW_FIELDS = ("who", "knows_who", "knows_why", "via", "clock_shichen", "told")
LEDGER_FIELDS = ("kind", "a", "b", "settle", "deadline_shichen", "waiting", "status", "era", "body", "clock_shichen")
REASON_FIELDS = ("holder", "toward", "axis", "size", "value", "kind", "clock_shichen")   # life：主角那一生，None＝NPC 之間
MEMORY_FIELDS = ("subject_kind", "subject", "kind", "text", "source", "clock_shichen", "turn_no", "actor", "attitude")
THREAD_FIELDS = ("no", "kind", "subject_kind", "subject", "text", "status", "deadline_shichen", "opened_shichen",
                 "opened_turn", "touched_shichen", "closed_shichen", "result_note", "origin", "next_step", "task")
FACTION_FIELDS = ("name", "type", "location", "discovered_turn", "traits")
BOND_FIELDS = ("a_kind", "a", "b_kind", "b", "type", "clock_shichen", "turn_no")
RUMOR_FIELDS = ("kind", "subject", "target", "place", "detail", "lv", "subject_lv", "size", "clock_shichen")
PLACE_STATE_FIELDS = ("place", "name", "text", "source", "game", "started_shichen", "ends_shichen")
GAME_FIELDS = ("no", "kind", "name", "result", "started_shichen", "started_turn", "ended_shichen", "ended_turn")
RELIC_FIELDS, UNDEAD_FIELDS = repos.RELIC_FIELDS, repos.UNDEAD_FIELDS
DOMAIN_FIELDS = tuple(k for k in repos.DOMAIN_FIELDS if k != "life")
RITE_FIELDS = tuple(k for k in repos.RITE_FIELDS if k != "known")
LEGEND_LIVES = ("met", "haunts", "rewarded")   # 記的是哪一生：存檔用索引
LEGEND_FIELDS = tuple(k for k in repos.LEGEND_FIELDS if k not in LEGEND_LIVES)
TURN_FIELDS = ("turn_no", "request_id", "kind", "player_input", "judgment", "delta", "narrative", "choices",
               "choice_tags", "model", "created_at")

# 舊版存檔沒有的欄位：讀入時補上的預設值
LOCATION_DEFAULTS = {"parent": "", "scale": "", "danger": "", "features": None, "chat_shichen": None, "spot": None, "rules": None}   # rules：v51 之前   # v4、v26、v47、v50 之前
NPC_DEFAULTS = {"speech": "", "race": "人族", "birth_shichen": None, "realm_lv": 0, "stage_index": 0,   # v5 之前
                "hidden_power": False, "condition": npc_mod.CONDITIONS[0], "appearance_age": None,
                "profile_age": None, "speech_age": None,
                "goal": "", "goal_target": "", **{t: 50 for t in npc_mod.TRAITS}, "heaven_role": "",  # v7 之前
                "rewrite_reason": "",
                "evolved_shichen": None, "cultivation": 0,                                             # v8 之前
                "away_since": None, "away_from": "",                                                   # v11 之前
                "gender": "", "lineage": "",                                                           # v29 之前
                "job": "",                                                                             # v30 之前
                "fate": "", "hidden": "", "reading": 0, "chapters": [], "opened": "",                  # v42 之前
                "origin": "", **{t: 50 for t in npc_mod.TEMPERS}, "learning": "", "knacks": [], "quirks": [], "catchphrase": "",
                "life_shichen": None, "fortune": 0}   # v43～v46 之前；v49 之前
RELATION_DEFAULTS = {"known_goal": "", "known_goal_shichen": None, "met": 1, "seen": {}, "heard": []}   # v8 之前；met v41 之前；人物卡 v48 之前
MEMORY_DEFAULTS = {"actor": "", "attitude": "", "thread_no": None,                          # v9 之前
                   "rumor_no": None}                                                        # v12 之前
FACTION_DEFAULTS = {"traits": {}}                                                           # v24 之前


def load_sheet(conn, session_id: str) -> dict | None:
    """讀角色卡並升級到最新版本（第 3 步之前建立的角色沒有年齡等欄位）。"""
    sheet = repos.get_character(conn, session_id)
    return character_mod.upgrade(sheet) if sheet else None


def checksum(payload: dict) -> str:
    """偵測檔案損毀用，不是防竄改（使用者可以自行重算）。真正的防線是 validate()。"""
    return hashlib.sha256(dumps(payload).encode("utf-8")).hexdigest()


# ── 匯出 ─────────────────────────────────────────────────────────────────
def export_world(conn, world_id: str) -> dict:
    """匯出整個世界（世界＋其中所有的一生）。「第幾生」用索引表示：系統登錄的地點與路線不屬於任何一生（None）。"""
    world = repos.get_world(conn, world_id)
    lives = repos.list_sessions_in_world(conn, world_id)
    life = {s["id"]: i for i, s in enumerate(lives)}

    def pick(row: dict, fields: tuple, **extra) -> dict:
        return {k: row[k] for k in fields} | extra

    threads = repos.list_threads(conn, world_id)
    thread_no = {t["id"]: t["no"] for t in threads}
    rumors = repos.list_rumors(conn, world_id)
    rumor_no = {r["id"]: i for i, r in enumerate(rumors)}   # 記事用索引指向聽到的傳聞
    happened = repos.list_book(conn, "events", world_id)
    event_no = {e["id"]: i for i, e in enumerate(happened)}   # 誰知道用索引指向那件事
    payload = {
        "world": {
            "name": world["name"], "kind": world["kind"], "clock_shichen": world["clock_shichen"],
            "uid": world["uid"], "pressure": repos.get_pressure(conn, world_id),   # v31：世界碼、壓力（16v）
            "heaven": repos.get_heaven(conn, world_id),
            "era": repos.get_era(conn, world_id),   # 時代卡（v22，第 16e 節）
            "atlas": repos.get_atlas(conn, world_id),   # 天下骨架（16k；沒有就第一回合補上）
            "immortal": realms.export(conn, world["user_id"], world_id),   # 用到的仙宗（16l；匯入時同名合併）
            "locations": [pick(l, LOCATION_FIELDS, discovered_life=life.get(l["discovered_session_id"]))
                          for l in repos.list_locations(conn, world_id)],
            "npcs": [pick(n, NPC_FIELDS, first_seen_life=life.get(n["first_seen_session_id"]))
                     for n in repos.list_npcs(conn, world_id)],
            "connections": [pick(c, CONNECTION_FIELDS, discovered_life=life.get(c["discovered_session_id"]))
                            for c in repos.list_connections(conn, world_id)],
            "relations": [pick(r, RELATION_FIELDS, life=life[r["session_id"]])
                          for r in repos.list_relations(conn, world_id)],
            "reasons": [pick(r, REASON_FIELDS, life=life.get(r["session_id"]), event_no=event_no.get(r["event_id"]))   # 第 7-3c2 批：因果鏈的根
                        for r in repos.list_book(conn, "reasons", world_id)],
            "ledger": [{**pick(r, LEDGER_FIELDS, life=life.get(r["session_id"]), event_no=event_no.get(r["event_id"])),   # 主角那方寫空字串，同羈絆
                        **{k: "" for k in ("a", "b") if r[k] == r["session_id"]}} for r in repos.list_book(conn, "ledger", world_id)
                       if r["kind"] not in pending.KINDS],   # 等你處理的事跟著角色卡走（第 1-6 批）
            "events": [{**pick(e, HAPPENED_FIELDS, life=life.get(e["session_id"])), "actor": e["actor"] if e["kind"] in (plot.TRUTH, chains.WAR) else "",
                        **({"detail": {**e["detail"], "from": event_no.get(e["detail"]["from"])}} if e["kind"] in chains.KINDS else {})}
                       for e in happened],   # 主角做的 actor 寫空字串；事端的真相、開戰寫做的人、不屬於哪一生（第 4-11-16 題、第 7-3c2 批）
            "knows": [pick(k, KNOW_FIELDS, life=life.get(k["session_id"]), event_no=event_no[k["event_id"]])
                      for k in repos.list_book(conn, "knows", world_id) if k["event_id"] in event_no],
            "memories": [pick(n, MEMORY_FIELDS, life=life.get(n["session_id"]), thread_no=thread_no.get(n["thread_id"]),
                              rumor_no=rumor_no.get(n["rumor_id"])) for n in repos.list_memories(conn, world_id)],
            "rumors": [pick(r, RUMOR_FIELDS, life=life.get(r["life"])) for r in rumors],
            "place_states": [pick(s, PLACE_STATE_FIELDS) for s in repos.list_place_states(conn, world_id)],
            "heaven_games": [pick(g, GAME_FIELDS, life=life[g["session_id"]]) for g in repos.list_games(conn, world_id)],
            "relics": [pick(r, RELIC_FIELDS, life=life[r["session_id"]]) for r in repos.list_relics(conn, world_id)],
            "undead": [pick(u, UNDEAD_FIELDS, life=life[u["session_id"]]) for u in repos.list_undead(conn, world_id)],
            "domains": [pick(d, DOMAIN_FIELDS, life=life.get(d["life"])) for d in repos.list_domains(conn, world_id)],
            "rites": [pick(x, RITE_FIELDS, known=life.get(x["known"])) for x in repos.list_rites(conn, world_id)],
            "legends": [pick(g, LEGEND_FIELDS, **{k: life.get(g[k]) for k in LEGEND_LIVES})
                        for g in repos.list_legends(conn, world_id)],
            "threads": [pick(t, THREAD_FIELDS, life=life[t["session_id"]]) for t in threads],
            # 起始區域的勢力與從屬關係是系統生成的（第 16b 步），不屬於任何一生（None）
            "factions": [pick(f, FACTION_FIELDS, discovered_life=life.get(f["discovered_session_id"]))
                         for f in repos.list_factions(conn, world_id)],
            # 主角那方寫空字串（匯入時換成新的那一生）；主角的成員照角色卡重建，不匯出
            "bonds": [{**pick(b, BOND_FIELDS, life=life.get(b["session_id"])),
                       **{k: "" for k in ("a", "b") if b[f"{k}_kind"] == society.PLAYER}}
                      for b in repos.list_bonds(conn, world_id, everyone=True)
                      if not (b["a_kind"] == society.PLAYER and b["type"] in society.MEMBER_BONDS)],
            "items": [pick(i, repos.ITEM_FIELDS, discovered_life=life.get(i["discovered_session_id"]))
                      for i in repos.list_items(conn, world_id)],
            "incidents": [pick(e, repos.EVENT_FIELDS, discovered_life=life.get(e["discovered_session_id"]))
                          for e in repos.list_events(conn, world_id)],
            "themes": [pick(t, repos.THEME_FIELDS) for t in repos.list_themes(conn, world_id)],   # 模型寫的傳說主題（第 128 系列乙）
            "tale_themes": [pick(t, repos.THEME_FIELDS) for t in repos.list_themes(conn, world_id, repos.TALES_W)],   # 模型寫的怪談
            "plot_themes": [pick(t, repos.THEME_FIELDS) for t in repos.list_themes(conn, world_id, repos.PLOTS_M)],   # 模型寫的事端
            "plots": [pick(p, repos.PLOT_FIELDS) for p in repos.list_plots(conn, world_id)],
        },
        "lives": [{
            "session": {k: s[k] for k in ("title", "phase", "turn_no", "clock_shichen")},
            "character": load_sheet(conn, s["id"]),
            "turns": [pick(t, TURN_FIELDS) for t in repos.list_turns(conn, s["id"], limit=1_000_000)],
        } for s in lives],
    }
    return {"format": SAVE_FORMAT, "version": SAVE_VERSION, "exportedAt": iso(),
            "checksum": checksum(payload), "payload": payload}


# ── 匯入 ─────────────────────────────────────────────────────────────────
def import_world(conn, user_id: str, save: dict) -> str:
    """檢查後建立新的世界。回傳進行中的那一局；整個世界都已結束時回傳最後一局。"""
    payload = validate(save)
    w = payload["world"]
    world_id = new_id("wld")
    session_ids = [new_id("ses") for _ in payload["lives"]]

    def life_session(index):
        return "" if index is None else session_ids[index]

    with transaction(conn):
        repos.insert_world(conn, world_id=world_id, user_id=user_id, name=w["name"], kind=w["kind"],
                           rng_seed=secrets.token_hex(16), clock_shichen=w["clock_shichen"], uid=w.get("uid") or "")
        repos.set_pressure(conn, world_id, w.get("pressure") or {})
        if w.get("heaven"):
            repos.set_heaven(conn, world_id, w["heaven"])
        if w.get("era"):
            repos.set_era(conn, world_id, w["era"])
        if w.get("atlas"):
            repos.set_atlas(conn, world_id, w["atlas"])
        for session_id, life in zip(session_ids, payload["lives"]):
            s = life["session"]
            repos.insert_session(conn, session_id=session_id, user_id=user_id, world_id=world_id,
                                 title=s["title"], phase=s["phase"], rng_seed=secrets.token_hex(16),
                                 turn_no=s["turn_no"], clock_shichen=s["clock_shichen"],
                                 shared=w["kind"] == world_mod.IMMORTAL)   # 仙域同時有好幾局（16l）
            if life["character"] is not None:
                repos.upsert_character(conn, session_id, life["character"])
            for t in life["turns"]:
                repos.insert_turn(conn, {**t, "id": new_id("trn"), "session_id": session_id})
        for loc in w["locations"]:
            repos.insert_location(conn, world_id, life_session(loc["discovered_life"]), loc)
        for npc in w["npcs"]:
            repos.insert_npc(conn, world_id, life_session(npc["first_seen_life"]), npc, past=False)
        for edge in w["connections"]:
            repos.insert_connection(conn, world_id, life_session(edge["discovered_life"]), edge)
        for r in w["relations"]:
            repos.upsert_relation(conn, world_id, r["npc_name"], session_ids[r["life"]], {"grudge": r["grudge"], "met": r["met"]})   # 只帶檢查過的
            repos.set_card(conn, world_id, r["npc_name"], session_ids[r["life"]], seen=r["seen"], heard=r["heard"])
            if r["known_goal"]:
                repos.set_known_goal(conn, world_id, r["npc_name"], session_ids[r["life"]], r["known_goal"],
                                     r["known_goal_shichen"])
        happened_ids = [new_id("evt") for _ in w["events"]]
        for r in w["reasons"]:
            repos.insert_book(conn, "reasons", world_id, {**r, "session_id": life_session(r["life"]),
                                                          "event_id": "" if r.get("event_no") is None else happened_ids[r["event_no"]]})
        for r in w["ledger"]:
            sid = life_session(r["life"])
            repos.insert_book(conn, "ledger", world_id, {**r, "session_id": sid, **{k: sid for k in ("a", "b") if r[k] == ""},
                                                         "event_id": "" if r.get("event_no") is None else happened_ids[r["event_no"]]})
        for i, e in zip(happened_ids, w["events"]):
            sid = life_session(e["life"])
            repos.insert_book(conn, "events", world_id, {**e, "id": i, "session_id": sid, "actor": e["actor"] or sid,
                                                         **({"detail": {**e["detail"], "from": happened_ids[e["detail"]["from"]]}} if e["kind"] in chains.KINDS else {})})
        for k in w["knows"]:
            repos.insert_book(conn, "knows", world_id, {**k, "id": None, "event_id": happened_ids[k["event_no"]], "session_id": life_session(k["life"])})
        thread_ids = {t["no"]: repos.insert_thread(conn, world_id, session_ids[t["life"]], t)["id"]
                      for t in w["threads"]}
        rumor_ids = [new_id("rum") for _ in w["rumors"]]
        for rid, r in zip(rumor_ids, w["rumors"]):
            repos.insert_rumor(conn, world_id, {**r, "id": rid, "life": life_session(r["life"])})
        for n in w["memories"]:
            repos.insert_memory(conn, world_id, life_session(n["life"]), {
                **n, "thread_id": thread_ids.get(n["thread_no"]),
                "rumor_id": None if n["rumor_no"] is None else rumor_ids[n["rumor_no"]]})
        for f in w["factions"]:
            repos.insert_faction(conn, world_id, life_session(f["discovered_life"]), f)
        for b in w["bonds"]:
            sid = life_session(b["life"])
            repos.insert_bond(conn, world_id, sid, {**b, **{k: sid for k in ("a", "b") if b[f"{k}_kind"] == society.PLAYER}})
        for i in w["items"]:
            repos.insert_item(conn, world_id, life_session(i["discovered_life"]), i)
        for e in w["incidents"]:
            repos.insert_event(conn, world_id, life_session(e["discovered_life"]), e)
        for t in w["themes"]:
            repos.insert_theme(conn, world_id, t)
        for t in w["tale_themes"]:
            repos.insert_theme(conn, world_id, t, repos.TALES_W)
        for t in w["plot_themes"]:
            repos.insert_theme(conn, world_id, t, repos.PLOTS_M)
        for p in w["plots"]:
            repos.insert_plot(conn, world_id, p)
        realms.merge(conn, user_id, world_id, w.get("immortal") or [])   # 仙宗併進玩家的仙域（16l）
        for s in w["place_states"]:
            repos.insert_place_state(conn, world_id, s)
        for g in w["heaven_games"]:
            repos.insert_game(conn, world_id, {**g, "session_id": session_ids[g["life"]]})
        for r in w["relics"]:
            repos.insert_relic(conn, world_id, session_ids[r["life"]], r)
        for u in w["undead"]:
            repos.insert_undead(conn, world_id, session_ids[u["life"]], u)
        for d in w["domains"]:
            repos.insert_domain(conn, world_id, {**d, "life": life_session(d["life"])})
        for x in w["rites"]:
            repos.insert_rite(conn, world_id, {**x, "known": life_session(x["known"])})
        for g in w["legends"]:
            repos.insert_legend(conn, world_id, {**g, **{k: life_session(g[k]) for k in LEGEND_LIVES}})
    active =[sid for sid, life in zip(session_ids, payload["lives"]) if life["session"]["phase"] != ENDED]
    return (active or session_ids)[-1]


# ── 檢查 ─────────────────────────────────────────────────────────────────
class InvalidSave(Exception):
    """validate 內部用：任何一處不合法就中止，由 validate 轉成 BadRequest。"""


def _bad(msg: str):
    raise InvalidSave(msg)


def _check(label: str, item, checks: dict) -> dict:
    """item 的每個欄位依表檢查：checks＝欄位 → 判斷函式(值, 整筆)。第一個不合格的欄位就中止，訊息帶欄位名稱。"""
    if not isinstance(item, dict):
        _bad(f"{label}的格式不合法。")
    for name, ok in checks.items():
        try:
            good = ok(item.get(name), item)
        except (KeyError, TypeError, ValueError, IndexError):   # 欄位缺了、或塞了陣列物件（拿去查表會出錯）＝不合法
            good = False
        if not good:
            who = item.get("name") or item.get("npc_name") or item.get("subject") or ""
            _bad(f"{label}{f'「{who}」' if isinstance(who, str) and who else ''}的 {name} 不合法：{str(item.get(name))[:40]}")
    return item


def _count(v, _=None) -> bool:
    return _int(v) and v >= 0


def _text(low: int, high: int):
    return lambda v, _=None: isinstance(v, str) and low <= len(v) <= high


def _one_of(*values):
    return lambda v, _=None: v in values


def _count_or_none(v, _=None) -> bool:
    return v is None or _count(v)


def _int(v) -> bool:
    """整數，而且放得進資料庫（SQLite 的整數是 64 位元，太大的數字寫入時會出錯）。"""
    return isinstance(v, int) and not isinstance(v, bool) and -2 ** 63 <= v < 2 ** 63


def validate(save) -> dict:
    """驗證存檔並轉成 v3 形狀：{"world": {...}, "lives": [{"session", "character", "turns"}, ...]}。
    v1／v2 是單局存檔（第 16 步之前），讀入時包成只有一生的新世界。"""
    try:
        if not isinstance(save, dict) or save.get("format") != SAVE_FORMAT:
            _bad("不是天道棋盤的存檔檔案。")
        if save.get("version") not in SUPPORTED_SAVE_VERSIONS:
            _bad(f"不支援的存檔版本 {save.get('version')!r}。")
        payload = save.get("payload")
        if not isinstance(payload, dict) or save.get("checksum") != checksum(payload):
            _bad("檔案內容已損毀（校驗碼不符）。")
        payload = payload if save["version"] >= 3 else _single_life_to_world(payload, save["version"])
        lives = payload.get("lives")
        if not isinstance(lives, list) or not lives:
            _bad("缺少角色的一生紀錄。")
        lives = [_validated_life(life) for life in lives]
        if sum(1 for life in lives if life["session"]["phase"] != ENDED) > 1:
            _bad("一個世界同時只能有一局在進行。")
        return {"world": _validated_world(payload.get("world"), lives), "lives": lives}
    except InvalidSave as exc:
        raise BadRequest(f"存檔無法讀取：{exc}", code="invalid_save") from None


def _single_life_to_world(payload: dict, version: int) -> dict:
    s = payload.get("session") if isinstance(payload.get("session"), dict) else {}
    world = {"locations": [], "npcs": []} if version == 1 else payload.get("world")
    if not isinstance(world, dict) or not isinstance(world.get("locations"), list) \
            or not isinstance(world.get("npcs"), list):
        _bad("地點或人物資料不合法。")
    return {
        "world": {"name": s.get("title"), "kind": world_mod.ORIGIN, "clock_shichen": s.get("clock_shichen"),
                  "locations": [{**l, "discovered_life": 0} if isinstance(l, dict) else l for l in world["locations"]],
                  "npcs": [{**n, "first_seen_life": 0} if isinstance(n, dict) else n for n in world["npcs"]],
                  "connections": []},
        "lives": [{"session": s, "character": payload.get("character"), "turns": payload.get("turns")}],
    }


SESSION_CHECKS = {"title": _text(1, 40), "phase": _one_of(*PHASES), "turn_no": _count, "clock_shichen": _count}
def _texts(v) -> bool:
    return isinstance(v, list) and all(isinstance(x, str) for x in v)


SEEN_KEYS = {"kin", "age", "realm", "condition", "attitude", "trust", "palace", "origin", "quirks", "goal", "worry", "manner", "date", "place"}


def _seen_ok(v) -> bool:
    """人物卡快照（第 9e-4 批，talks.remember）：特點最多兩條，其他都是短字。"""
    return isinstance(v, dict) and set(v) <= SEEN_KEYS and all(
        _texts(x) and len(x) <= 2 and all(len(q) <= 80 for q in x) if k == "quirks" else _text(0, 200)(x) for k, x in v.items())


def _judgment_ok(j, _=None) -> bool:
    """回合的判定：下一回合的前情提要、突破契機會讀（2026-10-06 深度檢查補上）。"""
    checks = j.get("checks", []) if isinstance(j, dict) else None
    return (isinstance(checks, list) and all(isinstance(c, dict) and isinstance(c.get("target"), str)
                                              and isinstance(c.get("outcome"), str) for c in checks)
            and all(isinstance(j.get(k, ""), str) for k in ("action_type", "outcome")))


def _delta_ok(d, _=None) -> bool:
    """回合的變化：下一回合的前情提要讀數值變化與事件、結算讀事件（世界的照事件表、天道的照 games）。"""
    if not isinstance(d, dict):
        return False
    rec, line, zone, legend = d.get("incident"), d.get("heaven", ""), d.get("domain"), d.get("legend")
    rite = d.get("rite")
    return ((legend is None or isinstance(legend, dict) and all(isinstance(legend.get(k), str) for k in ("theme", "root")))
            and (rite is None or isinstance(rite, dict) and all(isinstance(rite.get(k), str) for k in ("tale", "place")))
            and (zone is None or isinstance(zone, dict) and isinstance(zone.get("place"), str)   # 領域的情境（第 19-1 步）
             and (zone.get("scene") is None or _count(zone["scene"])) and isinstance(zone.get("thing", False), bool))
            and all(isinstance(d.get(k, ""), str) for k in ("situation", "focus", "left", "read", "act"))
            and isinstance(d.get("changes", []), list)
            and all(isinstance(c, dict) and c.get("field") in effects.FIELD_LABELS and _int(c.get("from"))
                    and _int(c.get("to")) for c in d.get("changes", []))
            and _texts(d.get("events", [])) and _texts(d.get("side", [])) and _texts(d.get("aside", [])) and _count(d.get("quiet", 0)) and _count(d.get("clockAdvance", 0))
            # 天道的台詞（第 18-1 步）存在 delta 裡，要過得了同一套驗證
            and isinstance(line, str) and heaven.check_line(line) == line
            and (rec is None or isinstance(rec, dict) and (games.valid_record(rec) if rec.get("source") == incident.TIANDAO
                                                            else incident.valid_record(rec))))


TURN_CHECKS = {"narrative": lambda v, _: isinstance(v, str), "request_id": lambda v, _: isinstance(v, str),
               "kind": _one_of("opening", "action"), "player_input": lambda v, _: isinstance(v, str),
               "model": lambda v, _: isinstance(v, str), "created_at": lambda v, _: v is None or isinstance(v, str),
               "choices": lambda v, _: _texts(v),
               "choice_tags": lambda v, t: isinstance(t.get("choice_tags", []), list) and all(
                   isinstance(x, dict) and all(isinstance(s, str) for s in x.values()) for x in t.get("choice_tags", [])),
               "judgment": _judgment_ok, "delta": _delta_ok}


def _validated_life(life) -> dict:
    if not isinstance(life, dict):
        _bad("一生的紀錄格式不合法。")
    s = _check("一生", life.get("session"), SESSION_CHECKS)
    sheet = life.get("character")
    if sheet is None:
        if s["phase"] != NEED_CHARACTER:
            _bad("缺少角色資料。")
    else:
        sheet = character_mod.validate_sheet(sheet)   # 舊版角色卡會被升級
        sheet = {**sheet, "background": sheet["background"][:character_mod.BACKGROUND_MAX],   # 3-7a：玩家寫的長期文字照建立時的上限截
                 "look": {k: v[:looks.MAX_PICK] for k, v in sheet["look"].items()}}
    turns = life.get("turns")
    if not isinstance(turns, list):
        _bad("回合紀錄格式不合法。")
    expected = list(range(0, s["turn_no"] + 1)) if s["phase"] in (PLAYING, ENDED) else []
    if [t.get("turn_no") if isinstance(t, dict) else None for t in turns] != expected:
        _bad("回合紀錄與目前回合數不一致。")
    for t in turns:
        _check("回合", t, TURN_CHECKS)
    if len({t["request_id"] for t in turns}) != len(turns):   # 寫入時有唯一索引（重送靠它認出同一回合）
        _bad("回合紀錄的 request_id 重複。")
    return {"session": s, "character": sheet, "turns": turns}


def _validated_world(world, lives: list[dict]) -> dict:
    if not isinstance(world, dict) or not isinstance(world.get("locations"), list) \
            or not isinstance(world.get("npcs"), list):
        _bad("地點或人物資料不合法。")
    _check("世界", world, {"name": _text(1, 40), "kind": _one_of(world_mod.ORIGIN, world_mod.LANDED, world_mod.IMMORTAL),
                          "clock_shichen": lambda v, _: _count(v) and all(v >= l["session"]["clock_shichen"]
                                                                          for l in lives),
                          "uid": lambda v, _: v is None or isinstance(v, str) and len(v) <= 40,   # v31 之前沒有：匯入時新開
                          "pressure": lambda v, _: v is None or pressure.valid(v),
                          "heaven": lambda v, _: v is None or heaven.valid_card(v),   # v15 之前沒有：匯入後再擲
                          # v22 之前沒有：從古代補擲。時代不能從世界時間之後才開始
                          "era": lambda v, x: v is None or era.valid(v) and v["since"] <= x["clock_shichen"],
                          "atlas": lambda v, _: v is None or atlas.valid(v),   # 16k 之前沒有：第一回合補上
                          "immortal": lambda v, _: v is None or isinstance(v, list) and all(  # 16l 之前沒有
                              immortal.valid_sect(s) for s in v)})
    now = world["clock_shichen"]

    def moment(v, _=None) -> bool:   # 不晚於世界時間
        return _count(v) and v <= now

    def in_life(life_key: str, turn_key: str, system_ok: bool = False):
        """登錄於第幾生、第幾回合：那一生必須存在，回合不能超過那一生的回合數。系統登錄的不屬於任何一生（None）。"""
        def ok(v, x) -> bool:
            if v is None and system_ok:
                return _count(x.get(turn_key))
            return _count(v) and v < len(lives) and _count(x.get(turn_key)) \
                and x[turn_key] <= lives[v]["session"]["turn_no"]
        return ok

    def life_ok(v, _=None) -> bool:
        return _count(v) and v < len(lives)

    def items(key: str, defaults: dict | None = None) -> list[dict]:
        found = world.get(key, [])
        if not isinstance(found, list) or not all(isinstance(x, dict) for x in found):
            _bad(f"{key} 資料不合法。")
        return [{**(defaults or {}), **x} for x in found]

    locations = [_check("地點", loc, {
        "name": lambda v, _: isinstance(v, str) and bool(proposals.NAME_RE.match(v)),
        "description": _text(*proposals.DESCRIPTION_LEN), "type": _one_of("", *proposals.LOCATION_TYPES, *market.ALL),
        "scale": _one_of("", *space.SCALES), "danger": _one_of("", *space.DANGER), "parent": _text(0, 40),
        "features": lambda v, _: scene.valid(v), "chat_shichen": _count_or_none, "spot": lambda v, _: spots.valid(v),
        "rules": lambda v, _: house.valid(v),
        "discovered_life": in_life("discovered_life", "discovered_turn", system_ok=True),
    }) for loc in items("locations", LOCATION_DEFAULTS)]
    places = {l["name"] for l in locations}

    connections = [_check("路線", c, {
        "a": lambda v, _: v in places, "b": lambda v, x: v in places and v != x["a"],
        "tier": _one_of(*space.ALL_TIERS),
        "distance_km": lambda v, x: v == space.ALL_TIERS.get(x["tier"]),
        "direction": _one_of("", *space.DIRECTIONS),
        "discovered_life": in_life("discovered_life", "discovered_turn", system_ok=True),
    }) for c in items("connections", {"direction": ""})]

    npcs = [_check("人物", n, {
        "name": lambda v, _: isinstance(v, str) and bool(proposals.NAME_RE.match(v)),
        "appearance": _text(0, proposals.NPC_TEXT_LEN[1]), "profile": _text(0, proposals.NPC_TEXT_LEN[1]),
        "speech": _text(0, proposals.NPC_TEXT_LEN[1]), "location": _text(1, 40),
        "status": _one_of("ALIVE", "FALLEN"), "ai_driven": lambda v, _: isinstance(v, bool),
        "created_by": _one_of("narrator", legacy.RETIRED_BY, home.FAMILY_BY, era.OFFICIAL_BY, sect_mod.MEMBER_BY,
                             sect_mod.HUNTER_BY, market.BY, auction.GUEST_BY, bondage.BY, plot.BY, family.BY, lapse.BY), "race": _text(1, 10),
        "gender": _one_of("", *character_mod.GENDERS), "lineage": _text(0, 10), "job": _text(0, 10),
        "birth_shichen": lambda v, _: v is None or (_int(v) and v <= now),
        "realm_lv": lambda v, _: _count(v) and v < len(realm.TIERS),
        "stage_index": lambda v, x: _count(v) and _count(x["realm_lv"]) and x["realm_lv"] < len(realm.TIERS)
        and v <= realm.last_stage(x["realm_lv"]),
        "hidden_power": lambda v, _: isinstance(v, bool),
        # 死亡不可逆：殞落的人一定是 FALLEN
        "condition": lambda v, x: v in npc_mod.CONDITIONS and (v != npc_mod.CONDITIONS[-1] or x["status"] == "FALLEN"),
        "appearance_age": _count_or_none, "profile_age": _count_or_none, "speech_age": _count_or_none,
        "goal": _one_of("", *npc_mod.GOALS, npc_mod.ASCENDED), "goal_target": _text(0, proposals.GOAL_TARGET_LEN),
        **{t: lambda v, _: _count(v) and v <= npc_mod.TRAIT_RANGE[1] for t in (*npc_mod.TRAITS, *npc_mod.TEMPERS)},
        "heaven_role": _one_of(*npc_mod.HEAVEN_ROLES), "rewrite_reason": _one_of(*npc_mod.REWRITE_REASONS),
        "evolved_shichen": lambda v, _: v is None or moment(v),
        "cultivation": lambda v, _: _count(v) and v <= realm.PROGRESS_PER_STAGE,
        "away_since": lambda v, _: v is None or moment(v), "away_from": _text(0, 40),
        "life_shichen": lambda v, _: v is None or moment(v), "fortune": lambda v, _: _int(v) and abs(v) <= 1,   # 重逢（第 9f-1 批）
        "reading": lambda v, x: origins.fated(x),   # 命三欄一起驗（第 122a 批）
        "chapters": lambda v, x: evolution.chapters_ok(v) and (not v or bool(x["hidden"])),   # 走過的章（第 122b 批）
        "opened": lambda v, x: evolution.opened_ok(v) and (not v or bool(x["hidden"])),       # 開著的章（第 122c 批）
        "origin": _text(0, proposals.NPC_TEXT_LEN[1]),   # 出身（第 7-1a 批）
        "knacks": lambda v, x: learn.valid(x),           # 學識、專長（第 7-1c 批）
        "quirks": lambda v, x: voice.valid(x),           # 特點、口頭禪（第 7-1d 批）
        "first_seen_life": in_life("first_seen_life", "first_seen_turn", system_ok=True),   # 宗門成員是系統登錄的
    }) for n in items("npcs", NPC_DEFAULTS)]
    npc_names = {n["name"] for n in npcs}
    names = [l["name"] for l in locations] + [n["name"] for n in npcs]
    if len(names) != len(set(names)):
        _bad("地點與人物有重複的名字。")
    if max(len(locations), len(npcs)) > MAX_WORLD_NAMES:
        _bad("地點或人物的數量超過上限。")

    relations = [_check("人物關係", r, {
        "npc_name": lambda v, _: v in npc_names, "life": life_ok,
        "grudge": _text(0, 20),
        "known_goal": _text(0, 40), "known_goal_shichen": lambda v, _: v is None or moment(v), "met": _one_of(0, 1),
        "seen": lambda v, _: _seen_ok(v), "heard": lambda v, _: isinstance(v, list) and len(v) <= 5 and all(_text(1, 80)(x, None) for x in v),
    }) for r in items("relations", RELATION_DEFAULTS)]
    if len({(r["npc_name"], r["life"]) for r in relations}) != len(relations):
        _bad("人物關係有重複。")
    reasons = [_check("好感原因", r, {   # v35 之前沒有（舊存檔的好感照存的數字，沒有原因）
        "holder": _text(1, 40), "toward": _text(1, 40), "axis": _one_of(*opinion.AXES), "size": _one_of(*opinion.LEVELS),
        "value": lambda v, _: _int(v) and abs(v) <= 2 * opinion.RANGE[1], "kind": _text(1, 10),   # 家運要抵掉親人的 +60
        "clock_shichen": moment, "life": lambda v, _: v is None or life_ok(v),
        "event_no": lambda v, _: v is None or _count(v) and v < len(items("events")),   # 第 7-3c2 批：因果鏈的根
    }) for r in items("reasons")]
    def mine(x: dict) -> bool:   # 主角的人情（v38）：剛好一方空字串、要有那一生、內容是合法的一筆
        return (x.get("life") is not None and (x["a"] == "") != (x["b"] == "")
                and favour.valid([favour.back({**x, "session_id": ""})]))

    n_events = len(items("events"))
    ledger = [_check("帳", r, {   # v36 之前沒有
        "kind": _one_of(society.OWE, society.HIRED, society.DEBT, society.FEUD, society.HUNT, society.HUSH, society.WATCH, society.JAILED, society.MARKED, society.DEED, society.GATHERED, society.WAITING, society.CALLED, society.WORRY), "a": _text(0, 40), "b": _text(0, 40), "settle": _text(0, 40),
        "event_no": lambda v, x: v is None and x["kind"] not in society.ABOUT or _count(v) and v < n_events,   # v39：血仇、追查兇手（v40 封口）指向那件事；封口費可以有
        "deadline_shichen": _count_or_none, "waiting": _text(0, 40), "status": _text(1, 10), "era": _text(0, 20),
        "clock_shichen": moment, "life": lambda v, _: v is None or life_ok(v),
        "body": lambda v, x: isinstance(v, dict) and (
            x["a"] != "" == x["b"] and x.get("life") is not None if x["kind"] in (*society.ABOUT, society.WATCH, society.DEED, society.CALLED) or x["kind"] == society.HIRED and x["b"] == ""   # 乙＝那一生（雇來找你的受託，第 7-2b 批）
            else mine(x) if "" in (x["a"], x["b"]) else True),   # 第 6-6a 批起 NPC 之間也有債（前世的帳轉過去）
    }) for r in items("ledger")]
    happened = [_check("發生的事", e, {   # v39 之前沒有；主角做的 actor 寫空字串；事端的真相寫做的人、life 是 None（第 4-11-16 題）
        "kind": _one_of(*hearsay.KINDS, hearsay.CHASE, plot.TRUTH, *chains.KINDS),
        "actor": lambda v, x: v == "" if x["kind"] not in (plot.TRUTH, chains.WAR) else _text(1, 40)(v, x),
        "target": _text(0, 40), "place": _text(0, 40),
        "detail": lambda v, x: isinstance(v, dict) and (
            isinstance(v.get("text"), str) if x["kind"] == plot.TRUTH
            else _count(v.get("from")) and v["from"] < len(items("events")) if x["kind"] in chains.KINDS   # 世界事件（第 7-3c2 批）
            else isinstance(v.get("name"), str) and all(_count(v.get(k)) and v[k] < len(realm.TIERS) for k in ("lv", "my_lv"))),
        "secret": _one_of(0, 1), "era": _text(0, 20), "clock_shichen": moment, "turn_no": _count,
        "life": lambda v, x: v is None if x["kind"] in (plot.TRUTH, *chains.KINDS) else life_ok(v),
    }) for e in items("events")]
    knows = [_check("誰知道", k, {
        "event_no": lambda v, _: _count(v) and v < len(happened), "who": _text(1, 40), "via": _text(1, 40),
        "knows_who": _one_of(0, 1), "knows_why": _one_of(0, 1), "told": _one_of(0, 1), "clock_shichen": moment,
        "life": lambda v, _: v is None or life_ok(v),
    }) for k in items("knows")]

    threads = [_check("線頭", t, {
        "no": lambda v, _: _int(v) and v >= 1, "life": life_ok, "kind": _one_of(*memory_mod.THREAD_KINDS),
        "subject_kind": _one_of(memory_mod.NPC, memory_mod.PLACE), "subject": _text(1, 40), "text": _text(1, 80),
        "status": _one_of(*memory_mod.THREAD_STATUSES), "deadline_shichen": _count_or_none,
        "opened_shichen": moment, "touched_shichen": moment, "opened_turn": _count,
        # 還沒結束的線頭沒有結束時間，結束的一定有
        "closed_shichen": lambda v, x: (v is None or moment(v)) and (x["status"] in memory_mod.ACTIVE) == (v is None),
        "result_note": _text(0, 40), "origin": _text(0, 10), "next_step": _text(0, 40), "task": lambda v, _: isinstance(v, dict),
    }) for t in items("threads", {"origin": "", "next_step": "", "task": {}})]
    numbers = {t["no"] for t in threads}
    if len(numbers) != len(threads):
        _bad("線頭編號重複。")

    rumor_list = [_check("傳聞", r, {
        "kind": _one_of(*rumors_mod.KINDS), "subject": _text(1, 40), "target": _text(0, 40), "place": _text(0, 40),
        "detail": _text(0, 40), "lv": lambda v, _: _count(v) and v < len(realm.TIERS),
        "subject_lv": lambda v, _: _count(v) and v < len(realm.TIERS),
        # 大小由種類與境界決定，不能自己改；怪談、破怪談看規模（v19 時還不分規模，所以只要是合法的大小）
        "size": lambda v, x: v == rumors_mod.size_of(x["kind"], x["lv"])
        or x["kind"] in (rumors_mod.TALE, rumors_mod.CLEARED, rumors_mod.FORCED) and v in rumors_mod.SIZES,
        "life": lambda v, _: v is None or life_ok(v), "clock_shichen": moment,
    }) for r in items("rumors")]

    memories = [_check("記事", n, {
        "life": lambda v, _: v is None or life_ok(v),   # None：世界脈動的記事，不屬於任何一生
        "subject_kind": _one_of(*memory_mod.SUBJECT_KINDS), "subject": _text(1, 40),
        "kind": _one_of(*memory_mod.MEMORY_KINDS), "text": _text(1, 80),
        # 說書人寫的只能是說、做、見；其他種類都是 Python 寫的
        "source": lambda v, x: v in (memory_mod.PYTHON, memory_mod.NARRATOR)
        and (v == memory_mod.NARRATOR) == (x["kind"] in memory_mod.NARRATOR_KINDS),
        "clock_shichen": moment, "turn_no": _count, "thread_no": lambda v, _: v is None or v in numbers,
        "actor": _text(0, 40), "attitude": _one_of("", *(label for _, label in npc_mod.AFFINITY_TIERS)),
        "rumor_no": lambda v, _: v is None or (_count(v) and v < len(rumor_list)),
    }) for n in items("memories", MEMORY_DEFAULTS)]

    factions = [_check("勢力", f, {
        # 宗門、武館與自己所在的地點同名（第 16b 步）；與其他地點、人物同名不行
        "name": lambda v, x: isinstance(v, str) and bool(proposals.NAME_RE.match(v)) and v not in npc_names
        and (v not in places or v == x.get("location")),
        "type": _one_of(*society.FACTION_TYPES, society.IMMORTAL_SECT, society.NATION),
        # 仙宗在仙域、國家是整片地方，都不是這個世界的某個地點
        "location": lambda v, x: v in places or (v == "" and x["type"] in (society.IMMORTAL_SECT, society.NATION)),
        "discovered_life": lambda v, _: v is None or life_ok(v), "discovered_turn": _count,
        "traits": lambda v, x: crime.valid(x["type"], v),
    }) for f in items("factions", FACTION_DEFAULTS)]
    if len({f["name"] for f in factions}) != len(factions):
        _bad("勢力名稱重複。")

    kinds = {n["name"]: society.NPC for n in npcs} | {f["name"]: society.FACTION for f in factions}
    by_name = {n["name"]: n for n in npcs}

    def adults(x: dict) -> bool:   # 戀人、伴侶雙方在結成時都必須成年（未成年底線）
        return x["type"] not in society.ADULT_ONLY_BONDS or not any(
            npc_mod.is_minor(by_name[p], x["clock_shichen"]) for p in (x["a"], x["b"]) if p in by_name)

    def side(v, x, k):   # 主角那方：名字空字串、要有那一生（第 1-3b 批）
        return kinds.get(x.get(k)) == v or (v == society.PLAYER and x.get(k) == "" and x.get("life") is not None)

    bonds = [_check("羈絆", b, {
        "life": lambda v, _: v is None or life_ok(v), "a_kind": lambda v, x: side(v, x, "a"),
        "b_kind": lambda v, x: side(v, x, "b") and (x["a"], x["a_kind"]) != (x.get("b"), v),
        "clock_shichen": moment, "turn_no": _count,
        "type": lambda v, x: society.allowed(v, x["a_kind"], x["b_kind"]) and adults(x),
    }) for b in items("bonds") if not isinstance(b, dict) or b.get("type") not in society.DERIVED]   # v36 之前存著算出來的

    new_items = [_check("新物品", i, {   # v25 之前沒有
        "name": lambda v, _: isinstance(v, str) and bool(proposals.NAME_RE.match(v)) and v not in items_mod.CATALOG,
        "base": _one_of(*items_mod.BASES), "description": _text(*proposals.DESCRIPTION_LEN),
        "discovered_life": in_life("discovered_life", "discovered_turn", system_ok=True),   # TXT 基本款不屬於任何一生
        "source": lambda v, _: v in (None, "", *newitems.SOURCES),   # 第 128 系列：來源、產地（舊存檔沒有就空）
        "state": lambda v, _: v is None or isinstance(v, str) and len(v) <= 40,
        "part": lambda v, _: v is None or isinstance(v, str) and len(v) <= 10,   # 第 128-10 題：零件詞
    }) for i in items("items")]
    item_names = {i["name"] for i in new_items}
    told = [i for i in new_items if i.get("source") in (None, "", newitems.TELLER)]   # 上限只算說書人提案的
    if len(item_names) != len(new_items) or len(told) > proposals.MAX_PER_SESSION[proposals.ITEM]:
        _bad("新物品有重複的名字或超過上限。")
    if any(k not in item_names for life in lives if life["character"] for v in life["character"]["aka"].values() for k in v):
        _bad("角色卡有世界裡沒有的物品叫法。")
    new_events = [_check("新事件", e, {   # v27 之前沒有
        "name": lambda v, _: isinstance(v, str) and bool(proposals.NAME_RE.match(v)),
        "base": _one_of(*incident.BASES), "scene": _text(*incident.SCENE_LEN),
        "discovered_life": in_life("discovered_life", "discovered_turn", system_ok=True),
    }) for e in items("incidents")]
    if len({e["name"] for e in new_events}) != len(new_events) or len(new_events) > proposals.MAX_PER_SESSION[proposals.EVENT]:
        _bad("新事件有重複的名字或超過上限。")
    plots = [_check("事端", p, {   # v28 之前沒有
        "name": _text(1, 20), "town": lambda v, _: v in places, "started_shichen": moment, "stage": _count,
        "ended_shichen": lambda v, _: v is None or moment(v), "turned_shichen": lambda v, _: v is None or moment(v),
        "killed": _one_of(0, 1), "brew_until": _count, "lit_shichen": lambda v, _: v is None or moment(v),
        "cast": lambda v, _: isinstance(v, dict) and all(isinstance(x, str) for x in v.values()),
    }) for p in items("plots")]

    regions = {"", *(s["name"] for s in (world.get("atlas") or {}).get("states", []))}
    place_states = [_check("地點狀況", s, {
        # 天災（16j）可以是整個區域（place 空字串）或整個州（16k：州名）
        "place": lambda v, x: v in places or (v in regions and x["name"] in disaster.BY_NAME),
        "name": _one_of(*(seed.name for seed in incident.SEEDS), *disaster.BY_NAME, prep.LAID, proxy.BOUNTY, plot.TRACE, form.EXPOSED, route.TRACE),
        "text": _text(1, 80), "source": _one_of(incident.WORLD, incident.TIANDAO),
        "game": lambda v, _: v is None or (isinstance(v, str) and len(v) <= 40),
        "started_shichen": moment, "ends_shichen": lambda v, x: _int(v) and _int(x["started_shichen"])
        and v > x["started_shichen"],
    }) for s in items("place_states")]

    game_names = {games.TRIAL: games.TRIAL, games.ERASE: games.ERASE, **{s.name: s.kind for s in games.SEEDS}}   # 事件名 → 手段
    heaven_games = [_check("棋局", g, {
        "no": lambda v, _: _int(v) and v >= 1, "life": life_ok,
        "kind": _one_of(games.TRIAL, games.CALAMITY, games.DEMON, games.BAIT, games.RIVAL, games.ERASE),
        # 宿敵之局的 name 是宿敵的名字（第 18-2b 步），其他是事件名
        "name": lambda v, x: isinstance(v, str) and (v in npc_names if x.get("kind") == games.RIVAL
                                                     else game_names.get(v) == x.get("kind")),
        "result": _one_of("", games.WIN, games.LOSE, games.VOID), "started_shichen": moment,
        "started_turn": lambda v, x: _count(v) and v <= lives[x["life"]]["session"]["turn_no"],
        # 分了勝負的一定有結束時間，還沒分的沒有
        "ended_shichen": lambda v, x: (v is None or moment(v)) and (v is None) == (x["result"] == ""),
        "ended_turn": lambda v, x: (v is None or _count(v)) and (v is None) == (x["result"] == ""),
    }) for g in items("heaven_games")]
    if len({g["no"] for g in heaven_games}) != len(heaven_games):
        _bad("棋局編號重複。")

    relics = [_check("遺物", r, {
        "life": life_ok, "owner": _text(1, 12), "name": lambda v, _: v in items_mod.CATALOG,
        "tier": lambda v, x: _int(v) and v in items_mod.tiers_of(x["name"]), "count": lambda v, _: _int(v) and v >= 1,
        # 記在某個人名下、或落在某個地點上，兩者只有一個；落在地上的才有落地時間
        "holder": lambda v, x: v in ("", *npc_names) and (v == "") != (x.get("place") == ""),
        "place": lambda v, _: v in ("", *places),
        "placed_shichen": lambda v, x: (v is None) == (x["place"] == "") and (v is None or moment(v)),
        "lasts": lambda v, _: _int(v) and v > 0,
    }) for r in items("relics")]

    undead_list = [_check("亡者", u, {
        "life": life_ok, "name": _text(1, 12), "lv": lambda v, _: _count(v) and v <= realm.MAX_LV,
        "died_shichen": moment, "grudge_on": _text(0, 12),
        # 形態、狀況、地點、執念要彼此對得上（undead.valid）
        "form": lambda v, x: undead_mod.valid(x, places),
    }) for u in items("undead")]
    if len({u["place"] for u in undead_list if u["condition"] != undead_mod.GONE}) \
            != sum(u["condition"] != undead_mod.GONE for u in undead_list):
        _bad("同一個地點有兩個亡者。")

    def tale_ok(v, x) -> bool:   # 全文要讀得成一篇怪談，名字對得上（tales.parse）
        try:
            return isinstance(v, str) and len(v) <= 6000 and tales_mod.parse(v, x["state"]).name == x["name"]
        except (StopIteration, KeyError, ValueError, IndexError):
            return False

    tale_themes = [_check("模型寫的怪談", t, {"name": _text(2, 8), "state": _text(1, 40), "source": _one_of(newtales.MODEL),
                                          "body": tale_ok}) for t in items("tale_themes")]   # 第 128 系列乙第二批之前沒有
    if len({t["name"] for t in tale_themes}) != len(tale_themes):
        _bad("模型寫的怪談有重複的名字。")
    tales_mod.use(tale_themes)   # 下面檢查領域時，主題要查得到這個世界的

    def plot_ok(v, x) -> bool:   # 全文要讀得成一條事端，名字對得上（plot.parse）
        try:
            return isinstance(v, str) and len(v) <= 12000 and plot.name(plot.parse(v)) == x["name"] and newplots.model(plot.parse(v))
        except (KeyError, IndexError):
            return False

    plot_themes = [_check("模型寫的事端", t, {"name": _text(2, 8), "state": _one_of(*era.ERAS), "source": _one_of(newplots.MODEL),
                                          "body": plot_ok}) for t in items("plot_themes")]   # 模型事端之前沒有
    if len({t["name"] for t in plot_themes}) != len(plot_themes):
        _bad("模型寫的事端有重複的名字。")

    domain_list = [_check("領域", d, {
        "life": lambda v, _: v is None or life_ok(v), "created_shichen": moment,
        "solved_shichen": lambda v, x: (v is None or moment(v)) and (v is None) == (x["status"] == domains_mod.ACTIVE),
        # 主題、地點、守則編號、進度、狀態要彼此對得上（domains.valid）
        "tale": lambda v, x: domains_mod.valid(x, places, npc_names),
    }) for d in ({**d, "scale": d.get("scale") or domains_mod.OLD_SCALE.get(d.get("tale"), tales_mod.VILLAGE)}
                 if isinstance(d.get("tale"), str) else d for d in items("domains"))]
    up = {l["name"]: l["parent"] for l in locations}
    zoned = [d["place"] for d in domain_list if d["status"] == domains_mod.ACTIVE]
    if any(domains_mod.overlaps(up, a, b) for i, a in enumerate(zoned) for b in zoned[i + 1:]):
        _bad("同一個地方只能有一個領域。")

    def theme_ok(v, x) -> bool:   # 全文要讀得成一篇傳說，名字對得上（legends.parse）
        try:
            return isinstance(v, str) and len(v) <= 4000 and legends_mod.parse(v, x["state"]).name == x["name"]
        except StopIteration:
            return False

    themes = [_check("模型寫的傳說", t, {"name": _text(2, 8), "state": _text(1, 40), "source": _one_of(newlegends.MODEL),
                                     "body": theme_ok}) for t in items("themes")]   # 第 128 系列乙之前沒有
    if len({t["name"] for t in themes}) != len(themes):
        _bad("模型寫的傳說有重複的名字。")
    legends_mod.use(themes)   # 下面檢查傳說紀錄時，主題要查得到這個世界的

    legend_list = [_check("都市傳說", g, {
        **{k: lambda v, _: v is None or life_ok(v) for k in LEGEND_LIVES},
        "created_shichen": moment, "moved_shichen": moment,
        "solved_shichen": lambda v, x: (v is None or moment(v)) and (v is None) == (x["status"] == legends_mod.ACTIVE),
        # 主題、地點、進度、狀態要彼此對得上（legends.valid）
        "theme": lambda v, x: legends_mod.valid({**x, **{k: "" for k in LEGEND_LIVES}}, places),
    }) for g in items("legends", {"rewarded": None})]   # v23 之前沒有 rewarded
    centers = [g["center"] for g in legend_list if g["status"] == legends_mod.ACTIVE]
    if len(centers) != len(set(centers)):
        _bad("同一個地方只能有一個都市傳說。")

    rite_list = [_check("流傳的玩法", x, {
        "known": lambda v, _: v is None or life_ok(v), "created_shichen": moment, "next_shichen": _count,
        "ended_shichen": lambda v, _: v is None or moment(v),
        "tale": lambda v, x: rites_mod.valid(x, places, npc_names),   # 主題、地點、階段、人要彼此對得上
    }) for x in items("rites")]   # v23 之前沒有

    return {**world, "locations": locations, "connections": connections, "npcs": npcs, "relations": relations,
            "reasons": reasons, "ledger": ledger, "events": happened, "knows": knows,"threads": threads, "memories": memories, "factions": factions, "bonds": bonds, "rumors": rumor_list,
            "place_states": place_states, "heaven_games": heaven_games, "relics": relics, "undead": undead_list,
            "legends": legend_list, "rites": rite_list, "items": new_items, "incidents": new_events, "themes": themes,
            "tale_themes": tale_themes, "plot_themes": plot_themes,
            "plots": plots, "domains": domain_list}
