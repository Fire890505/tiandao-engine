"""暗線在回合裡（WHITEPAPER 16v 第 32～36、42、46 題）：啟動、走一步、查破綻、收買、走完、反咬（第 5-4a 批）。規則在 domain/dark.py。"""
from __future__ import annotations

import math
import random
import re
from dataclasses import dataclass, field
from types import SimpleNamespace

from ..domain import cards, dark, domains, effects, favour, hearsay, identity, incident, judgment, lead, legends, opinion, plot, region, route, rumors
from ..domain import side, society, space, stage, trap
from ..domain import memory as m
from ..domain import npc as npc_mod
from ..domain.clock import SHICHEN_PER_DAY, SHICHEN_PER_YEAR
from ..domain.evolution import AWAY
from ..domain.tales import theme
from ..domain.tales import fill as tale_fill
from . import incidents, people, plots, routes, sightings, traps, zones

LOOKING = (judgment.EXPLORE, judgment.SOCIAL, judgment.OBSERVE, judgment.STEALTH)


@dataclass
class Shade:
    """這回合暗線的變化。scene：放進【主事】；choices：收買的兩個選項；tell：這回合新的破綻，敘事寫完帶進去。"""
    sheet: dict
    events: list[str] = field(default_factory=list)
    changes: list[dict] = field(default_factory=list)
    rumors: list[dict] = field(default_factory=list)
    choices: list[str] = field(default_factory=list)
    scene: str = ""
    tell: str = ""
    pushes: list[str] = field(default_factory=list)   # 對手推動的壓力（龍脈的收網）
    mine: list[tuple] = field(default_factory=list)   # 反咬：（對手, 他對你的原因, 記的仇），service 記進他對你的關係（第 5-4-2 題）


@dataclass
class Case:
    """手上這條路線背後的東西。rec、t：事端；zone：怪談；tale：傳說；fate：命途（路線本身）。"""
    rows: dict
    r: dict
    ticked: object
    z: object
    s: object
    updates: object
    rng: random.Random
    here: str
    focus: str
    now: int
    turn_no: int
    life: str
    rec: dict | None = None
    t: dict | None = None
    zone: dict | None = None
    tale: dict | None = None
    fate: dict | None = None

    def next_clue(self, sheet: dict) -> list[str] | None:
        return plot.next_clue(self.rec, self.t, sheet) if self.t else None


def _open(rows: dict, r: dict, templates: list[dict], z, s) -> dict:
    """找到路線的紀錄。"""
    if r["kind"] == route.PLOT:
        rec, t = plots.case(rows, templates, r["key"])
        return {"rec": rec, "t": t}
    if r["kind"] == route.FATE:
        return {"fate": r}
    if r["kind"] == route.ZONE:
        return {"zone": next((z.now(d) for d in reversed(rows["domains"]) if d["place"] == r["key"]), None)}
    return {"tale": next((s.now(g) for g in rows["legends"] if routes.legend_key(g) == r["key"]), None)}


def _ready(sheet: dict, r: dict, c: dict, now: int) -> bool:
    """第 34 題：走得深、有物證、惹到它、拖得久，任一成立；注視高時路線一開始就啟動。"""
    if route.band(sheet) >= dark.GAZE_BAND:
        return True
    if c.get("fate"):   # 命途：路線的人定好了、走到「點破」才開始（第 81-3 題）
        return bool(r["cast"]) and r["stage"] >= 1
    if c.get("t"):
        rec, t = c["rec"], c["t"]
        clues = [x for x in plot.found(sheet, rec) if x["kind"] != plot.POINT]
        return len(clues) >= 2 or any(x["kind"] == plot.EVIDENCE for x in clues) or plot.half_gone(rec, t, now)
    late = now - r["since"] >= dark.LATE
    d, g = c.get("zone"), c.get("tale")
    return bool(d) and (d["step"] >= 1 or d["strikes"] >= 1 or late) or bool(g) and (g["step"] >= 1 or g["misses"] >= 1 or late)


def _backer(rows: dict, here: str, rng: random.Random) -> tuple[str, str]:
    """第 42 題：暗線啟動時定幕後，附近的勢力；沒有就沒有，不憑空生。有成員敵視主角（或記恨）的勢力優先（127-5，第 5-5-8 題）。"""
    near, hidden = routes.around(rows, here), region.hidden_names(rows["factions"])
    picks = [f for f in rows["factions"] if f["location"] in near and f["name"] not in hidden and f["type"] in dark.MARKS]
    foes = {n for n, x in rows.get("relations", {}).items() if x.get("affinity", 0) <= society.FOE_AT or x.get("grudge")}
    mad = [f for f in picks if any(b["b"] == f["name"] and b["type"] in society.MEMBER_BONDS and b["a"] in foes for b in rows["bonds"])]
    f = rng.choice(mad or picks) if picks else None
    return (f["name"], dark.MARKS[f["type"]]) if f else ("", dark.NO_MARK)


# ── 隱藏牌的效果：_gate 挑門路，_can 看做不做得到，_do 真的改世界，回傳填空 ─────────────────
def _gates(c: Case, sheet: dict) -> dict:
    """事端的門路（草稿 3-1）：人＝知道還沒查到的線索的人，物＝下一條線索的地方，證＝還沒查到的物證，名＝這裡。
    隱瞞者不算，動他事情會轉向；眼前的人不算，不然話說到一半人沒了。"""
    known, dead = {x["key"] for x in plot.found(sheet, c.rec)}, plots.gone(c.rows)
    rows = [(row, plot.fill(row[2], c.rec["cast"])) for row in c.t["線索"] if row[0] not in known]
    people = [] if c.rec["turned_shichen"] is not None else \
        [who for _, who in rows if (role := plot.role_of(c.rec, c.t, who)) and role[0] != plot.KEY_ROLE and who not in dead | {c.focus}]
    nxt = c.next_clue(sheet)
    return {"人": list(dict.fromkeys(people)), "物": [plot.fill(nxt[2], c.rec["cast"])] if nxt and _spots(c, sheet) else [],
            "證": [who for row, who in rows if row[1] == plot.EVIDENCE], "名": [c.r["place"]]}


def _gate(card: dark.Card, c: Case, sheet: dict, d: dict, cast: dict) -> str | None:
    """這張牌動哪個門路：命途照牌上寫的；事端挑對手知道你碰過的，不堵最後一條（草稿 2、3-2）。不針對＝空字串，挑不到＝None。"""
    if not card.aim:
        return ""
    kind, _, what = card.aim.partition(":")
    if not c.t:
        return plot.fill(what, cast) or c.r["place"]
    gates = _gates(c, sheet)
    left = {g for gs in gates.values() for g in gs} - {t["gate"] for t in d["tells"] if not t["fixed"]}   # 補回來的可以再動
    known = _known(c, d)
    pool = [g for g in gates[kind] if card.effect != dark.SWAY or _fond(c, d, g)]
    return min((g for g in pool if g in left and left - {g}), key=lambda g: (g != d["back"], g not in known), default=None)


def _fond(c: Case, d: dict, who: str) -> bool:
    """不知情的幫兇（第 5-5-14 題）：對對手那一方的人好感友善以上，才說得動。"""
    like = society.liking(c.rows["npcs"], c.rows["bonds"], c.rows.get("npc_reasons", []), c.now, c.rows.get("factions", []))
    return any(like(who, x) >= society.FRIEND_AT for x in _his(c, d) - {who, ""})


def _known(c: Case, d: dict) -> set[str]:
    """對手知道你碰過的門路（追查傳到對手的，第 5-1-2 題）。"""
    told = {k["event_id"] for k in [*c.rows.get("knows", []), *c.updates.knows] if d["foe"] and k["who"] == d["foe"]}
    return {e["target"] for e in _chases(c, d) if e["id"] in told}


def _filled(card: dark.Card, cast: dict) -> bool:
    """牌上的空都填得上（摻假的藥沒有隱瞞處）。"""
    text = card.tell + card.found + card.hit + "".join(card.fixes)
    return all(k in cast or k in plot.WORDS or k in dark.FILLED for k in re.findall(r"\{(\w+)\}", text))


def _spots(c: Case, sheet: dict) -> list[str]:
    """下一條線索可以搬去的地方。"""
    row = c.next_clue(sheet)
    return [p for p in (c.rec["cast"][k] for k, *_ in c.t["處"]) if row and p != plot.fill(row[2], c.rec["cast"])]


def _spare(c: Case) -> list[int]:
    """還沒放上去的假規則。"""
    tale = theme(c.zone["tale"])
    return [i for i in domains.pool(tale, "", c.zone["scale"]) if tale.rules[i].fake and i not in c.zone["rules"]]


def _inside(c: Case) -> bool:
    return domains.covers(zones.parents(c.rows), c.zone["place"], c.here)


def _victims(c: Case, sheet: dict) -> list[str]:
    """怪談帶得走的人：不動做儀式的人、事端的人、同伴、眼前的人。"""
    up, kept = zones.parents(c.rows), {c.zone["person"], c.focus, *(n for p in c.rows["plots"] for n in p["cast"].values())}
    return sorted(p["name"] for p in c.rows["npcs"] if p["status"] == "ALIVE" and p["name"] not in kept
                  and domains.covers(up, c.zone["place"], p["location"]))


def _wild(c: Case) -> bool:
    return next((l.get("type") for l in c.rows["locations"] if l["name"] == c.here), "") in dark.WILD


def _fits(card: dark.Card, c: Case, cast: dict) -> bool:
    """合不合眼前的場景（第 53、64 題）。寫的不是有名字的人（這裡的人）就算在。"""
    if card.scene == dark.TOWN:
        return not _wild(c)
    if card.scene == dark.IN_PERSON:
        who = next((cast[k] for k in dark.PEOPLE if f"{{{k}}}" in card.tell and k in cast), "")
        return who == c.focus or all(p["name"] != who or p["location"] == c.here for p in c.rows["npcs"])
    return True


def _can(card: dark.Card, c: Case, sheet: dict) -> bool:
    e = card.effect
    if e == dark.GRAB:
        return bool(_spots(c, sheet))
    if e == dark.RUSH:
        return plot.room(c.rec, c.t, c.now) >= dark.EARLY_LEFT + 1
    if e == dark.FAKE:
        return bool(_spare(c))
    if e == dark.WATCH:
        return _inside(c)
    if e == dark.SHIFT:
        return bool(sightings.ways(c.rows, c.s, c.tale))
    return True


def _gone(c: Case, name: str, why: str) -> None:
    c.updates.fields.setdefault(name, {}).update(status="FALLEN", condition=npc_mod.CONDITIONS[-1])
    c.updates.dead.add(name)
    c.updates.world_notes.append(m.note(m.NPC, name, m.DEATH, why, clock_now=c.now, turn_no=c.turn_no))


def _do(card: dark.Card, c: Case, sheet: dict, d: dict, who: str) -> tuple[dict, dict, dict]:
    """回傳（角色卡, 暗線, 填空）。who：動的門路。嚇住記他怕對手、收買記他欠對手（第 5-3-1 題）；擋路在 held。"""
    e = card.effect
    if e == dark.SCARE and d["foe"]:
        c.updates.reasons.append(opinion.reason(who, d["foe"], opinion.mood(opinion.THREAT, opinion.BIG), c.now))
    elif e == dark.BUY and d["foe"]:
        c.updates.ledger.append(society.owed(society.OWE, d["foe"], who, c.now))
    elif e == dark.MOVE:
        to = c.rng.choice(_spots(c, sheet))
        return sheet, {**d, "moved": {**d["moved"], c.next_clue(sheet)[0]: to}}, {"新地": to}
    if e == dark.KILL:
        _gone(c, who, "說是舊病發作，死得不明不白")
    elif e == dark.SEND:
        known = {x["key"] for x in plot.found(sheet, c.rec)}
        row = next(r for r in c.t["線索"] if r[0] not in known and plot.fill(r[2], c.rec["cast"]) == who)
        c.updates.fields.setdefault(who, {}).update(location=AWAY)
        return sheet, {**d, "moved": {**d["moved"], row[0]: c.rec["cast"][plot.role_of(c.rec, c.t, who)[1]]}}, {}
    elif e == dark.RUSH:
        plots.rush(c.ticked, c.rec, c.t, min(dark.EARLY, plot.room(c.rec, c.t, c.now) - dark.EARLY_LEFT))
    elif e == dark.FAKE:
        c.z.changed[c.zone["id"]] = {**c.zone, "rules": sorted([*c.zone["rules"], c.rng.choice(_spare(c))])}
    elif e == dark.WATCH:
        return domains.marked(sheet, True), d, {}
    elif e == dark.TAKE_AWAY:
        for who in c.rng.sample(_victims(c, sheet), min(1, len(_victims(c, sheet)))):   # 這裡沒有有名字的人：不見的是沒名字的
            _gone(c, who, f"在{c.zone['place']}不見了，沒有人記得")
            c.z.swallowed.add(who)
    elif e == dark.SHIFT:
        return sheet, d, {"新地": sightings.move(c.s, c.rows, c.tale, c.rng, c.now)}
    elif e == dark.LIE:
        said = c.rng.choice([x for x in legends.theme(c.tale["theme"]).sayings if not x.true])
        c.updates.rumors.append(rumors.make(rumors.LEGEND, c.tale["root"], place=c.tale["center"], when=c.now,
                                            detail=tale_fill(said.text, legends.names(c.tale))[:40]))
    elif e == dark.HAUNT:
        c.s.changed[c.tale["id"]] = {**c.tale, "haunts": c.life, "haunt_until": c.now + legends.HAUNT_YEARS * SHICHEN_PER_YEAR}
    return sheet, d, {}


def _step(out: Shade, c: Case, d: dict, cast: dict, near: bool) -> dict:
    """走一步：抽這一階做得到的牌，這一階都做不到就往上一階，只是場景不合就先等。每一步都留破綻（暗線 2～3 步）。
    人不在那裡（第 81-10 題）：聽聞的牌優先，不抽當面的、收買，破綻寫成旁人說的。"""
    picks = []
    while not picks and d["step"] < dark.STEPS:
        gates = {x: _gate(x, c, out.sheet, d, cast) for x in dark.tier(d, dark.deck_of(c.r))}
        able = [x for x, g in gates.items() if g is not None and _filled(x, cast) and _can(x, c, out.sheet) and (near or x.effect != dark.BRIBE)]
        picks = [x for x in able if _fits(x, c, cast)] if near else \
            [x for x in able if x.scene == dark.HEARD] or [x for x in able if x.scene != dark.IN_PERSON]
        if able and not picks:
            return d
        d = {**d, "step": d["step"] + 1, "owed": False}
    if not picks:
        return d
    known = _known(c, d)
    card = c.rng.choice([x for x in picks if d["back"] and gates[x] == d["back"]] or [x for x in picks if gates[x] in known] or picks)   # 反撲、對手知道你碰過的優先
    out.sheet, d, filled = _do(card, c, out.sheet, d, gates[card])
    d = {**d, "last": c.now, "back": ""}
    out.pushes += [card.effect[len(stage.PRESS):]] if card.effect.startswith(stage.PRESS) else []
    out.sheet = {**out.sheet, "route": stage.rival(out.sheet["route"], d["step"], c.turn_no)}   # 對手走一步，主線往前（第 81-1 題）
    away = sorted(routes.around(c.rows, c.r["place"]) - {c.r["place"]})
    words = {"新地": away[0] if away else c.r["place"], "證人": gates[card], **cast, **filled, "記號": d["mark"]}
    text, found = plot.fill(card.tell, words), plot.fill(card.found, words)
    trace = plot.fill(card.trace, words) if d["by"] or c.t else ""
    if card.effect == dark.BRIBE:
        out.choices, out.scene = [dark.TAKE, dark.REFUSE], f"（暗線）{text}。寫到東西送到主角手上、主角還沒決定為止"
        return {**d, "offer": {"found": found, "until": c.turn_no + dark.WINDOW}}
    if near and not out.tell:   # 人不在那裡：回去才聽說（第 5-1-1 題）
        out.tell = f"旁人說：{text}" if card.scene == dark.HEARD else text
    used = {t["used"] for t in d["tells"] if t["gate"] == gates[card] and t["used"]}   # 大典第 9 條：上次補回來的做法這次不管用
    fixes = [plot.fill(f, words) for f in card.fixes]
    return {**d, "tells": [*d["tells"], {"text": text, "found": found, "trace": trace, "seen": near, "gate": gates[card], "aim": card.aim.partition(":")[0],
                                         "hit": plot.fill(card.hit, words), "fixes": [f for f in fixes if f.split(":")[0] not in used] or fixes,
                                         "hits": 0, "fixed": False, "back": False, "used": "", "means": card.effect}]}


def _again(out: Shade, c: Case, d: dict, cast: dict, near: bool) -> dict:
    """第 5-4-7 題：三步走完以後補回來，照樣反撲一次：再抽第三階，不算步數、不推主線；這張的破綻補回來不再反撲。
    場景不合就先等（back 留著）。"""
    r, n = out.sheet["route"], len(d["tells"])
    d = _step(out, c, {**d, "step": dark.STEPS - 1}, cast, near)
    out.sheet = {**out.sheet, "route": r}
    if d["step"] < dark.STEPS:
        return {**d, "step": dark.STEPS}
    tells = [*d["tells"][:n], *({**t, "back": True} for t in d["tells"][n:])]
    return {**d, "tells": tells, "back": "", "owed": False}


def _grip(c: Case, sheet: dict) -> str:
    """把柄（第 36 題）：事端下一條線索，怪談揭穿一條假規則，傳說一條隱藏條件。"""
    if c.t:
        h = plot.hint(c.rec, c.t, sheet, plots.gone(c.rows))
        return f"這件事接下來要{h['做法']}{h['線索地']}" if h else ""
    if c.tale:
        return legends.hint(c.tale)
    if not c.zone:
        return ""
    tale, names = theme(c.zone["tale"]), domains.names(c.zone, None)
    i = next((i for i in c.zone["rules"] if tale.rules[i].fake), None)
    if i is None:
        return ""
    c.z.changed[c.zone["id"]] = {**c.zone, "rules": [x for x in c.zone["rules"] if x != i],   # 上演過的也拿掉（存檔要對得上）
                                 "staged": [x for x in c.zone["staged"] if x != i]}
    rule = tale.rules[i]
    return f"守則「{tale_fill(rule.text, names)}」是假的" + ("" if rule.truth == domains.LIE else f"，正確的是：{tale_fill(rule.truth, names)}")


def _cut(out: Shade, c: Case, d: dict, found: str, left: str = dark.LEFT) -> dict:
    """打斷：給把柄；對手還活著就問要揭穿還是要脅（第 5-4-1 題）。"""
    grip = _grip(c, out.sheet)
    line = "；".join(x for x in (found, grip) if x)
    bite = _alive(c, d["foe"])
    out.events.append(f"主角查到了：{line}")
    out.scene = f"（查到）{line}。{left}。寫到主角發現這件事為止" + ("，還沒決定怎麼用它" if bite else "")
    out.choices = [dark.EXPOSE, dark.THREATEN] if bite else []
    return {**d, "state": dark.CUT, "offer": {"until": c.turn_no + dark.WINDOW} if bite else None}


def _alive(c: Case, name: str) -> bool:
    return any(p["name"] == name and p["status"] == "ALIVE" for p in c.rows["npcs"]) if name else False


def _bite(out: Shade, c: Case, d: dict, text: str) -> dict:
    """反咬（第 5-4-2 題）：揭穿＝傳聞、他在當地名聲變壞、記恨你，人、名補回來；要脅＝他怕你、恨你，物、證、地補回來，
    搬走的線索回原處。都補回來不反撲。之後第一次離開那裡，他的人出手（traps.after）。沒回應、過了期限只剩把柄。"""
    expose = any(w in text for w in dark.EXPOSE_WORDS)
    if not expose and not any(w in text for w in dark.THREATEN_WORDS):
        return {**d, "offer": None} if c.turn_no > d["offer"]["until"] else d
    foe, me, aims = d["foe"], out.sheet["name"], dark.EXPOSED if expose else dark.GRIPPED
    if expose:
        where = c.r["place"] or c.here   # 有的路線沒有地方：就在主角揭穿的地方
        town = space.town_of(c.rows["locations"], where)
        c.updates.reasons += [opinion.reason(p["name"], foe, opinion.mood(opinion.SHAME, opinion.BIG), c.now) for p in c.rows["npcs"]
                              if p["status"] == "ALIVE" and p["name"] != foe and space.town_of(c.rows["locations"], p["location"]) == town]
        out.rumors.append(rumors.make(rumors.AFTERMATH, where, place=where, when=c.now, detail=f"{foe}做的事被{me}當眾揭穿"[:40]))
        out.mine.append((foe, [opinion.mood(opinion.SHAME, opinion.BIG)], "被當眾揭穿"))
        said = f"被{me}當眾揭穿"
    else:
        out.mine.append((foe, [opinion.mood(opinion.THREAT, opinion.BIG), opinion.hit(opinion.THREAT, opinion.LIKE, opinion.GRAVE, -1)], "被拿住把柄"))
        said = f"被{me}拿住把柄"
        out.sheet = {**out.sheet, "gripped": [*(g for g in out.sheet["gripped"] if g != foe), foe]}   # 下一章先挑他（第 6-6c 批）
    if c.t and not expose:
        spots = {t["gate"] for t in d["tells"] if t["aim"] == "物"}
        back = {row[0] for row in c.t["線索"] if plot.fill(row[2], c.rec["cast"]) in spots}
        d = {**d, "moved": {k: v for k, v in d["moved"].items() if k not in back}}
    fixed = [t for t in d["tells"] if t["aim"] in aims and t["hit"] and not t["fixed"]]
    c.updates.notes.append(m.note(m.NPC, foe, m.TURN, said, clock_now=c.now, turn_no=c.turn_no))
    out.events += [f"{'當眾揭穿了' if expose else '私下拿這件事要脅'}{foe}", *(f"{t['gate']}那邊回到原樣" for t in fixed)]
    out.scene = f"（{'揭穿' if expose else '要脅'}）主角{'當眾揭穿了' if expose else '私下拿這件事要脅'}{foe}。寫到{foe}當下的反應為止"
    tells = [{**t, "fixed": True, "back": True} if t in fixed else t for t in d["tells"]]
    return {**d, "tells": tells, "offer": None, "hunt": True}


def _tip(c: Case, sheet: dict) -> dict | None:
    """第 48-1 題：這件別管，去管那件。附近別的地方還在的事，記成線頭，走到那裡就接上；線頭滿了就不說。"""
    near = routes.around(c.rows, c.here)
    tips = [(route.PLOT, plot.tag(p), p["town"]) for p in c.rows["plots"] if p["ended_shichen"] is None and p["town"] in near] \
        + [(route.ZONE, x["place"], x["place"]) for x in c.rows["domains"] if x["status"] == domains.ACTIVE and x["place"] in near] \
        + [(route.LEGEND, routes.legend_key(g), g["root"]) for g in c.rows["legends"] if g["status"] == legends.ACTIVE and g["center"] in near]
    tips = [t for t in tips if t[2] != c.r["place"] and not route.holds(sheet, t[1])]
    if not tips or len(sheet["leads"]) >= lead.MAX:
        return None
    kind, key, place = c.rng.choice(tips)
    return lead.make(kind, key, place, f"{place}那邊有事，比這件值得管", c.now)


def _take(out: Shade, c: Case) -> None:
    amount = dark.BRIBE_MONEY * 2 ** out.sheet["realm_lv"]
    sheet, out.changes, _ = effects.gain(out.sheet, {"money": amount})
    tip = _tip(c, sheet)
    out.sheet = {**sheet, "records": sorted({*sheet["records"], dark.PAID}), "leads": sheet["leads"] + ([tip] if tip else [])}
    out.events += [f"收下了 {amount} 錢的封口銀子", *([f"送錢的人順口說：{tip['text']}"] if tip else [])]


def _answer(out: Shade, c: Case, d: dict, text: str) -> dict:
    """第 35-1 題：收下得錢、暗線停、沒有案中案；拒絕算打斷。沒回應就算了，暗線照走。"""
    if any(w in text for w in dark.TAKE_WORDS):
        _take(out, c)
        return {**d, "state": dark.BOUGHT, "offer": None}
    if any(w in text for w in dark.REFUSE_WORDS):
        return _cut(out, c, d, d["offer"]["found"], dark.RETURNED)
    return {**d, "offer": None} if c.turn_no > d["offer"]["until"] else d


def _finish(out: Shade, c: Case, d: dict, cast: dict) -> dict:
    """走完沒打斷：沒有案中案，傳聞收尾（第 40 題）。"""
    out.rumors.append(rumors.make(rumors.AFTERMATH, c.r["place"], place=c.r["place"], when=c.now,
                                  detail=plot.fill(dark.ENDS[c.r["kind"]], cast)[:40]))
    return {**d, "state": dark.DONE}


def clues(sheet: dict, turn_no: int) -> list[str]:
    """讀懂「在查哪一個」的清單（3-4b）：期限內的破綻＋埋著的陷阱跡象，字跟 turn 交給 spot 的一樣。"""
    d = sheet["dark"] or {}
    return [t["text"] for t in d.get("tells", ())] + [plot.fill(t["sign"], t["words"]) for t in d.get("traps", ())]


def turn(rows: dict, sheet: dict, ticked, z, s, h, updates, rng: random.Random, *, templates: list[dict], verdict: judgment.Judgment,
         text: str, spot, moved: bool, crowded: bool, focus: str, here: str, now: int, turn_no: int, life: str,
         reply: str | None = None) -> Shade:
    """一回合。spot(破綻)：玩家這句是不是在查它，要問模型，條件都成立才呼叫。moved：這回合路線有推進。
    reply：回收買、陷阱的字（3-4a，game/replies.py；沒給照原文）。
    crowded：當場的事已經拿走這回合（陷阱不落下）。對手欠了就在回合結尾走，不當候選（第 5-1-1 題）。"""
    out = Shade(sheet)
    r, d = sheet["route"], sheet["dark"]
    found = _open(rows, r, templates, z, s) if r and dark.deck_of(r) else {}
    if not any(found.values()):
        return out
    if not d or d["key"] != r["key"]:
        ch = sheet.get("chain")
        if ch and ch["key"] == r["key"]:   # 案中案的下一層：一開始就啟動，沿用幕後，沒有幕後就重新挑（第 5-5-3 題）
            by, mark = (ch["by"], ch["mark"]) if ch["by"] else _backer(rows, here, rng)
            foe = ch["foe"] or _foe(rows, r, found, by)   # 下一層的對手：宿敵或首領（game/chains.py）
            out.sheet = {**sheet, "chain": None, "dark": dark.start(r["key"], by, mark, foe, now, ch["layer"], ch["witness"])}
        elif _ready(sheet, r, found, now):
            by, mark = _backer(rows, here, rng)
            out.sheet = {**sheet, "dark": dark.start(r["key"], by, mark, _foe(rows, r, found, by), now)}
        return out
    cut = d["state"] == dark.CUT and any(d[k] for k in ("offer", "hunt", "sprung", "decoy"))   # 打斷之後：反咬、他的人出手
    late = d["state"] == dark.DONE and bool(d["back"] or d["offer"])   # 走完以後補回來：照樣反撲（第 5-4-7 題）
    if d["state"] != dark.RUN and not cut and not late:
        return out
    c = Case(rows, r, ticked, z, s, updates, rng, here, focus, now, turn_no, life, **found)
    cast, near = routes.cast(rows, r, z, s, h, here), routes.at(rows, r, here)
    said = text if reply is None else reply
    if cut:
        d = _bite(out, c, d, said) if d["offer"] else \
            traps.after(out, c, d, act=trap.ACTS.get(verdict.action_type, "查探"), text=said, cast=cast, near=near, crowded=crowded)
    elif late:
        d = _answer(out, c, d, said) if d["offer"] else _again(out, c, d, cast, near)
    if cut or late:
        out.sheet = {**out.sheet, "dark": d}
        return out
    spot = (lambda _: False) if stage.chosen(r, text) else spot   # 選主線的選項不問模型
    looking = near and verdict.action_type in LOOKING and (verdict.is_success or not verdict.rolled)
    if d["offer"]:
        d = _answer(out, c, d, text if reply is None else reply)
    else:
        hit = next((t for t in d["tells"] if looking and spot(t["text"])), None)
        if hit:
            d = _cut(out, c, d, f"{hit['found']}{'，' + hit['trace'] if hit['trace'] else ''}")
    d = _spill(out, c, d, verdict) if d["state"] == dark.RUN and not out.choices and not out.events else d
    if d["state"] == dark.RUN and not out.choices and not out.events:   # 陷阱（第 81-6、81-7 題）：這回合沒有別的暗線的事才動；落下算當場的危險
        d = traps.turn(out, c, d, verdict=verdict, text=text if reply is None else reply, spot=spot, cast=cast, near=near, crowded=crowded)
    if d["state"] == dark.RUN:
        d = _watch(out, c, d, verdict, near)
        d = _heard(out, d, near)
        pushed = stage.pushed_by_player(r, turn_no) if stage.now(r) else moved   # 有階段表：玩家推動換階才欠一步（第 81-2 題）
        n = 0 if d["offer"] else dark.due(d, pushed, now)
        d = {**d, "last": now} if pushed else d
        for _ in range(n):   # 欠了就在回合結尾走，人不在那裡照樣走（第 81-10、5-1-1 題）
            was = d["step"]
            d = _step(out, c, {**d, "owed": True}, cast, near)
            if d["step"] == was or d["offer"]:
                break
        d = {**d, "owed": n > 0 and d.get("owed", False)}
        d = _again(out, c, d, cast, near) if d["step"] >= dark.STEPS and d["back"] and not d["offer"] else d
        d = _end(out, c, d, cast)
    out.sheet = {**out.sheet, "dark": d}
    return out


def _heard(out: Shade, d: dict, near: bool) -> dict:
    """人不在那裡時走的那幾步：回到那裡才聽人說起，一回合說一條（第 5-1-1 題）。"""
    d, said = dark.reveal(d) if near and not out.tell else (d, "")
    out.tell = f"旁人說：{said}" if said else out.tell
    return d


def _spill(out: Shade, c: Case, d: dict, verdict) -> dict:
    """上一層被推出來頂的人：找他交談，恨透了背後的人，吐一條還沒看見的破綻，只一次（第 5-5-13 題）。"""
    if not d["witness"] or c.focus != d["witness"] or verdict.action_type != judgment.SOCIAL:
        return d
    d, said = dark.reveal(d)
    if not said:
        return d
    out.events.append(f"{d['witness']}恨透了背後的人，說了一件真事：{said}")
    return {**d, "witness": ""}


def _end(out: Shade, c: Case, d: dict, cast: dict) -> dict:
    """走完最後一步再過 PACE 才收（給最後一個破綻時間）；有階段表的已經推到收場，不另外收尾（第 81-5 題）。"""
    if d["step"] < dark.STEPS or d["offer"] or c.now - d["last"] < dark.PACE:
        return d
    return {**d, "state": dark.DONE} if stage.now(c.r) else _finish(out, c, d, cast)


# ── 對手知道你在查什麼（第 114-2、126-5、5-1-2～5-1-4 題）：記成「追查」，傳到對手或他的人才算 ─────
def _foe(rows: dict, r: dict, found: dict, by: str) -> str:
    """事端＝隱瞞者；命途＝立場寫敵的角色；怪談、傳說＝幕後勢力的首領；都沒有＝空字串。"""
    if found.get("rec"):
        return found["rec"]["cast"].get(plot.KEY_ROLE, "")
    if found.get("fate"):
        return next((who for who in r["cast"].values() if stage.side(r, r["cast"], who) == "敵"), "")
    return next((b["a"] for b in rows["bonds"] if b["type"] == "首領" and b["b"] == by), "") if by else ""


def _his(c: Case, d: dict) -> set[str]:
    """對手和他的人：幕後勢力的成員、欠對手帳的人。"""
    led = {l["b"] for l in c.rows.get("ledger", []) if l["kind"] == society.OWE and l["a"] == d["foe"] and l["status"] == society.OPEN}
    return {d["foe"], *led, *(b["a"] for b in c.rows["bonds"] if d["by"] and b["b"] == d["by"] and b["type"] in society.MEMBER_BONDS)}


def _leans(c: Case, d: dict, who: str) -> bool:
    """通風報信（第 126-4 題的比法）：對你的好感＋欠你的帳，比不上對對手的好感＋怕＋欠對手的帳（他的人加一級），就傳。"""
    rel = c.rows.get("relations", {}).get(who, {})
    mine = rel.get("affinity", 0) + opinion.SIZES[opinion.BIG] * sum(f["way"] == favour.OWED for f in rel.get("favours", []))
    like = society.liking(c.rows["npcs"], c.rows["bonds"], c.rows.get("npc_reasons", []), c.now, c.rows.get("factions", []))
    fear = society.liking(c.rows["npcs"], c.rows["bonds"], c.rows.get("npc_reasons", []), c.now, axis=opinion.FEAR)
    theirs = like(who, d["foe"]) + fear(who, d["foe"]) + opinion.SIZES[opinion.BIG] * (who in _his(c, d) - {d["foe"]})
    return theirs > mine


def _chases(c: Case, d: dict) -> list[dict]:
    rows = [*c.rows.get("happened", []), *c.updates.happened]
    return [e for e in rows if e["kind"] == hearsay.CHASE and e["session_id"] == c.life and e["detail"].get("key") == d["key"]]


def _watch(out: Shade, c: Case, d: dict, verdict, near: bool) -> dict:
    """這回合碰了哪個門路（路線的人、路線的地方）：記一件追查，在場的人知道；盯梢、通風報信當天傳到對手，風聲照傳聞的速度。"""
    if not d["foe"]:
        return d
    knows = [*c.rows.get("knows", []), *c.updates.knows]
    had = {(k["event_id"], k["who"]) for k in knows}
    seen = False
    if near and verdict.action_type in LOOKING:
        gate = c.focus or c.here   # 門路：問的人，沒有人就是這個地方
        e = next((e for e in _chases(c, d) if e["target"] == gate), None)
        if not e:
            e = hearsay.event(hearsay.CHASE, c.life, gate, c.here, c.now, c.turn_no, name="", lv=0, my_lv=0, key=d["key"])
            c.updates.happened.append(e)
        new = [hearsay.know(e, p["name"], c.now) for p in people.present(c.rows, c.here) if (e["id"], p["name"]) not in had]
        c.updates.knows += new
        had |= {(k["event_id"], k["who"]) for k in new}
        bad = verdict.rolled and not verdict.is_success
        loud = verdict.outcome == judgment.GREAT_FAILURE or verdict.action_type == judgment.COMBAT
        watched = bad and verdict.action_type in trap.ACTS and any(p["name"] in _his(c, d) for p in people.present(c.rows, c.here))
        told = c.focus and c.focus != d["foe"] and _leans(c, d, c.focus)
        if (watched or told or c.focus == d["foe"]) and (e["id"], d["foe"]) not in had:   # 盯梢、通風報信：當天到
            c.updates.knows.append(hearsay.know(e, d["foe"], c.now, via=c.focus if told else hearsay.SEEN))
            had.add((e["id"], d["foe"]))
            seen = True
        if loud:   # 風聲：當眾鬧大，這個村鎮都聽說了
            c.updates.knows.append(hearsay.know(e, space.town_of(c.rows["locations"], c.here), c.now, via=hearsay.TOWN))
    far = space.distances_from(c.rows["connections"], space.town_of(c.rows["locations"], _where(c, d["foe"])))
    for k in knows:   # 傳聞傳到對手那裡（rumors.KM_PER_DAY）
        e = next((e for e in _chases(c, d) if e["id"] == k["event_id"]), None)
        km = 0 if k["who"] == space.town_of(c.rows["locations"], _where(c, d["foe"])) else far.get(k["who"])
        if e and k["via"] == hearsay.TOWN and km is not None and (e["id"], d["foe"]) not in had \
                and k["clock_shichen"] + math.ceil(km / rumors.KM_PER_DAY) * SHICHEN_PER_DAY <= c.now:
            c.updates.knows.append(hearsay.know(e, d["foe"], c.now, via=hearsay.TOWN))
            had.add((e["id"], d["foe"]))
    if seen:
        out.events.append(dark.HUNCH)
    return d


def _where(c: Case, name: str) -> str:
    return next((p["location"] for p in c.rows["npcs"] if p["name"] == name), "")


# ── 擋路、看見、補回來、反撲（第 5-3 批）：碰到被對手動過的門路 ─────────────────
def _light(rows: dict, r: dict, templates: list[dict], updates, rng, here: str, focus: str, now: int) -> Case:
    return Case(rows, r, None, None, None, updates, rng, here, focus, now, 0, "", **_open(rows, r, templates, None, None))


def _talk(c: Case, t: dict) -> bool:
    """門路是真的人：比一次兩邊誰拉得動他（第 5-3-1 題）。命途寫的「鄰居」這種不是人，照地物證名擋。"""
    return t["aim"] == "人" and any(p["name"] == t["gate"] for p in c.rows["npcs"])


def _shaky(c: Case, sheet: dict, d: dict) -> bool:
    """重傷、名聲變壞、被放話（大典第 2 條的時機）：補回來的人再比一次。"""
    wanted = identity.level(sheet, identity.own_name(sheet), c.now)[0]
    return sheet["hp"] * dark.HURT <= sheet["hp_max"] or bool(wanted) or any(t["aim"] == "名" and t["hit"] and not t["fixed"] for t in d["tells"])


def _fix(t: dict, tag: str, ok: bool, paying: bool) -> tuple[str, str] | None:
    """對得上哪個解法（第 5-3-4 題）：行動種類對、這回合本來判定成功；給要這回合真的付錢。回傳（行動, 結果）。"""
    for f in t["fixes"] if ok else ():
        act, _, res = f.split(":", 2)
        if paying if act == side.GIVE else side.ACTS.get(act) == tag:
            return act, res
    return None


def _meet(c: Case, sheet: dict, on, stops, tag: str, ok: bool, paying: bool) -> tuple[dict, bool, list[str], list[dict]]:
    """碰到被動過的門路（第 5-3-3～5-3-5 題）。on(破綻)：這回合碰到了沒；stops(破綻)：這樣碰到算不算被擋。
    真的人比輸了才擋；補回來的人在重傷、名聲變壞時再比一次，比輸了翻回去。被擋過再碰到，對得上解法就補回來、出結果那句，
    第一次補回來對手要反撲。還擋著就出碰到時那句，第一次整句，之後只寫還是一樣。回傳（角色卡, 擋住沒, 事實, 變化）。"""
    d = sheet["dark"]
    shaky, tells, stop, facts, changes, turned = _shaky(c, sheet, d), [], False, [], [], []
    for t in d["tells"]:
        if t["hit"] and on(t):
            lost = stops(t) and (not _talk(c, t) or _leans(c, d, t["gate"]))
            t = {**t, "fixed": False, "hits": 0} if t["fixed"] and lost and shaky and _talk(c, t) else t
            got = None if t["fixed"] or not t["hits"] else _fix(t, tag, ok, paying and sheet["money"] > 0)
            if got:
                paid = incidents.pay(incident.LOSE_MONEY, sheet, c.rows, c.rng) if got[0] == side.GIVE else None
                sheet, changes, facts = (paid.sheet, changes + paid.changes, facts + paid.events) if paid else (sheet, changes, facts)
                sway = t["means"] == dark.SWAY   # 不知情的幫兇（第 5-5-16 題）：不說破（查）對手不知道，說破（問）他翻臉
                d = d if t["back"] or sway and got[0] == "查" else {**d, "owed": True, "back": t["gate"]}
                turned += [t["gate"]] if sway and got[0] == "問" else []
                t = {**t, "fixed": True, "back": True, "used": got[0]}
                facts.append(got[1])
            elif not t["fixed"] and lost:
                facts.append(f"{t['gate']}{dark.SAME}" if t["hits"] else t["hit"])
                t, stop = {**t, "hits": t["hits"] + 1}, True
        tells.append(t)
    d = {**d, "tells": tells}
    if turned:   # 說破：他記恨對手，吐一條還沒看見的破綻
        c.updates.reasons += [opinion.reason(who, d["foe"], opinion.hit(opinion.BETRAY, opinion.LIKE, opinion.BIG, -1), c.now) for who in turned if d["foe"]]
        d, said = dark.reveal(d)
        facts += [f"{turned[0]}說了一件真事：{said}"] if said else []
    return {**sheet, "dark": d}, stop, facts, changes


def held(rows: dict, templates: list[dict], sheet: dict, updates, rng: random.Random, *, here: str, focus: str, verdict: judgment.Judgment,
         paying: bool, now: int) -> tuple[dict, set[str], list[str], list[dict]]:
    """事端（第 5-3-1～5-3-3 題）：這回合本來查得到的線索，門路被動過就擋住。人＝問到他；證＝搜那裡；名＝在那個村鎮問
    （搜和看照常）；物＝搜原本的地方（東西已經搬走，只出那句）。回傳（角色卡, 擋住的線索, 事實, 變化）。"""
    r, d = sheet["route"], sheet["dark"]
    c = _light(rows, r, templates, updates, rng, here, focus, now) if r and d and d["key"] == r["key"] and r["kind"] == route.PLOT else None
    tail = c and cards.TAGS.get(verdict.action_type) == side.ACTS["查"] and any(t["means"] == dark.SWAY and t["gate"] == focus for t in d["tells"])
    seen = SimpleNamespace(**{**vars(verdict), "action_type": judgment.SOCIAL}) if tail else verdict   # 暗中跟著被說動的人也算碰到（第 5-5-16 題）
    would = c and c.t and plot.search(c.rec, c.t, {**sheet, "dark": {**d, "moved": {}}}, here, focus, seen, plots.gone(rows))
    if not would:
        return sheet, set(), [], []
    row = next(x for x in c.t["線索"] if x[0] == would["key"])
    spot = {"物": plot.fill(row[2], c.rec["cast"]), "名": space.town_of(rows["locations"], here)}
    there, asked = plot.where(row, c.rec, c.t, plots.gone(rows), sheet)[0], verdict.action_type == judgment.SOCIAL
    sheet, stop, facts, changes = _meet(c, sheet, lambda t: t["gate"] == spot.get(t["aim"], there), lambda t: t["aim"] != "名" or asked,
                                        cards.TAGS.get(verdict.action_type, ""), verdict.is_success or not verdict.rolled, paying)
    return sheet, {would["key"]} if stop else set(), facts, changes


def stall(rows: dict, sheet: dict, after: dict, rng: random.Random, *, focus: str, tag: str, ok: bool, paying: bool,
          now: int) -> tuple[dict, list[str], list[dict]]:
    """命途（第 5-3-3b 題）：真的人＝找他說話時比一次；其他＝對手動過以後，玩家這回合本來推得動也推不動。
    回傳（角色卡，route 換成這回合走到的階, 事實, 變化）。"""
    r, d = sheet["route"], sheet.get("dark")
    if not (d and d["key"] == r["key"] and r["kind"] == route.FATE):
        return {**sheet, "route": after}, [], []
    c = _light(rows, r, [], None, rng, "", focus, now)
    pushed = after["stage"] != r["stage"] and after["pushed"] == stage.PLAYER
    sheet, stop, facts, changes = _meet(c, sheet, lambda t: focus == t["gate"] and tag == side.ACTS["問"] if _talk(c, t) else pushed,
                                        lambda t: True, tag, ok, paying)
    back = {**after, **{k: r[k] for k in ("stage", "moved", "pushed")}}
    return {**sheet, "route": back if stop and pushed else after}, facts, changes
