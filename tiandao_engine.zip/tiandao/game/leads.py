"""線頭在回合裡（WHITEPAPER 16v 第 23、28 題）：聽到就記、碰到抽事件卡、過期給結果。規則在 domain/lead.py。"""
from __future__ import annotations

from dataclasses import dataclass, field

from ..domain import domains, echo, lead, legends, plot, route, rumors, space
from ..domain.evolution import REACH
from . import people, plots, routes


@dataclass
class Trail:
    """這回合線頭的變化。touched：碰到的那條傳聞，抽事件卡；states：留在地點上的後果。"""
    sheet: dict
    touched: str = ""
    rumors: list[dict] = field(default_factory=list)
    states: list[dict] = field(default_factory=list)


def _about(rows: dict, r: dict, sheet: dict, here: str, now: int) -> dict | None:
    """這則傳聞指向哪件還在的事。怪談同範圍才記、低的要人在那裡、高的只是傳聞（第 116-13 題）。"""
    place, raised = r["subject"], r["kind"] == rumors.AFTERMATH
    if r["kind"] in (rumors.TALE, rumors.AFTERMATH):
        d = next((d for d in rows["domains"] if d["place"] == place and d["status"] == domains.ACTIVE), None)
        g = route.gap(d["scale"], sheet.get("realm_lv", 0)) if d else 1
        if g == 0 or g < 0 and space.town_of(rows["locations"], here) == d["place"]:
            return lead.make(route.ZONE, d["place"], d["place"], rumors.text(r), now, raised)
    if r["kind"] in (rumors.LEGEND, rumors.AFTERMATH):
        g = next((g for g in rows["legends"] if place in (g["center"], g["root"]) and g["status"] == legends.ACTIVE), None)
        if g:
            return lead.make(route.LEGEND, routes.legend_key(g), g["root"], rumors.text(r), now, raised)
    return None


def _plots(rows: dict, templates: list[dict], sheet: dict, here: str) -> list[tuple[dict, dict]]:
    """聽得到風聲的事端（第 116-3、116-10 題）：同範圍的在範圍裡哪裡都聽得到，低的要在主地點或它的一處，高的聽不到。"""
    live = plots.current(rows, templates, here)
    mine = plot.units(rows["locations"], rows.get("connections", []), rows.get("atlas"), here)
    by_name, places = {plot.name(t): t for t in templates}, {l["name"]: l for l in rows["locations"]}
    out = []
    for rec in rows["plots"]:
        t = by_name.get(rec["name"])
        if t and rec["ended_shichen"] is None and rec["town"] in places:
            g, hit = plots.gap(rows, rec, t, sheet), bool(live) and plot.tag(live[0]) == plot.tag(rec)
            out += [(rec, t)] if g < 0 and hit or g == 0 and (hit or mine.get(plot.scope(t, places[rec["town"]])) == rec["town"]) else []
    return out


def _heard(rows: dict, templates: list[dict], notes: list[dict], sheet: dict, here: str, now: int) -> list[dict]:
    """這回合聽到的：傳聞，和事端的風聲。"""
    ids = {n.get("rumor_id") for n in notes}
    found = [_about(rows, r, sheet, here, now) for r in rows["rumors"] if r["id"] in ids]
    found += [lead.make(route.PLOT, plot.tag(rec), rec["town"], plot.fill(t["風聲"][0][0], rec["cast"]), now)
              for rec, t in _plots(rows, templates, sheet, here)]
    return [l for l in found if l and not route.holds(sheet, l["key"])]


def _plea(rows: dict, templates: list[dict], sheet: dict, key: str, here: str, now: int, turn_no: int) -> dict:
    """同範圍的事端第一次聽到：受害者來請託（第 116-10 題），腳程 REACH 內到得了才來。答應就接下這條事端（sides._answer）。"""
    rec, t = plots.case(rows, templates, key)
    p = people.find(rows, rec["cast"].get(plot.VICTIM, "")) if t and plots.gap(rows, rec, t, sheet) == 0 else None
    km = space.distances_from(rows["connections"], here).get(p["location"]) if p and p["status"] == "ALIVE" else None
    if km is None or space.travel_shichen(km, p["realm_lv"]) > REACH:
        return sheet
    o = {"name": rec["name"], "who": p["name"], "words": f"{plot.fill(t['風聲'][0][0], rec['cast'])}，想請你查查", "next": "",
         "span": "一月", "origin": route.PLOT, "route": "", "ways": [], "left": "", "left_by": [], "gain": [], "dark": "",
         "plot": key, "place": rec["town"]}
    return echo.ask(sheet, o, rec["town"], turn_no, now)


def _settle(out: Trail, l: dict, rows: dict, templates: list[dict], ticked, now: int) -> None:
    """過期或被擠掉：事端走到結局，其他留後果，第一次還會傳開。都有一則收場的傳聞，不能就這麼遺忘。"""
    if l["kind"] == route.PLOT:
        rec = next((p for p in rows["plots"] if plot.tag(p) == l["key"]), None)
        t = next((t for t in templates if rec and plot.name(t) == rec["name"]), None)
        if t:
            ticked.changes = [c for c in ticked.changes if c[0]["id"] != rec["id"]] + [(rec, t, now)]
            out.rumors.append(rumors.make(rumors.AFTERMATH, rec["town"], place=rec["town"], when=now, detail=f"{rec['town']}：{plot.result(rec, t)}"[:40]))
        return
    state = route.aftermath(l, now)
    if state:
        out.states.append(state)
        out.rumors += [] if l["raised"] else [rumors.make(rumors.AFTERMATH, l["place"], place=l["place"], when=now, detail=state["text"][:40])]


def turn(rows: dict, templates: list[dict], sheet: dict, notes: list[dict], ticked, z, s, h, *, before: dict | None, here: str,
         now: int, turn_no: int = 0) -> Trail:
    """一回合。before：回合開始時的路線（天道發的新路線在這之後才落實，不算碰到）。新聽到的同範圍事端排請託（_plea）。"""
    out = Trail(sheet)
    r = sheet["route"]
    hit = next((l for l in sheet["leads"] if r and r != before and l["key"] == r["key"]), None)
    out.touched = hit["text"] if hit else ""
    leads = [l for l in sheet["leads"] if not route.holds(sheet, l["key"]) and not routes.over(rows, {"route": l}, ticked, z, s, h)[0]]
    leads, done = leads[-lead.MAX:], leads[:-lead.MAX]   # 案中案翻面記的線頭可能多一條（game/chains.py）
    for new in _heard(rows, templates, notes, sheet, here, now):
        leads, squeezed = lead.add(leads, new)
        done += squeezed
    done += [l for l in leads if now >= l["until"]]
    had = {l["key"] for l in sheet["leads"]}
    out.sheet = {**sheet, "leads": [l for l in leads if now < l["until"]]}
    for l in [l for l in out.sheet["leads"] if l["kind"] == route.PLOT and l["key"] not in had]:
        out.sheet = _plea(rows, templates, out.sheet, l["key"], here, now, turn_no)
    for l in done:
        _settle(out, l, rows, templates, ticked, now)
    return out
