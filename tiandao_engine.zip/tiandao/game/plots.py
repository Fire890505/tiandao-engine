"""事端在世界裡的流程（WHITEPAPER 16t）：放進村鎮、照時間走到結局、結束一陣子再放新的。

規則在 domain/plot.py；這裡只把世界資料接上規則。tick 不碰資料庫，write 在回合的交易內呼叫。
"""
from __future__ import annotations

import dataclasses
import random

from ..domain import atlas, era, family, hearsay, home, knot, lapse, names, newcomer, newdisasters, newplots, opinion, party, plot, pressure, route, rumors, sect
from ..domain import laws, newghosts, newwars, origins, side, society, space, undead
from ..domain import npc as npc_mod
from ..store import repos
from ..domain import favour
from . import background, favours, incidents, people
from .people import land_race, local_race, settle_family


@dataclasses.dataclass
class Tick:
    news: list[str] = dataclasses.field(default_factory=list)   # 主角在這個村鎮時看得到的事
    changes: list[tuple[dict, dict, int | None]] = dataclasses.field(default_factory=list)   # （改過的事端, 模板, 結束的時候）
    towns: list[tuple[dict, str]] = dataclasses.field(default_factory=list)   # 要放新事端的（村鎮, 上一條的名字）
    boss: dict[str, str] = dataclasses.field(default_factory=dict)   # 村鎮 → 指定的隱瞞者（案中案，第 5-5-1 題）
    results: list[tuple[dict, dict, str, str]] = dataclasses.field(default_factory=list)   # （事端, 模板, 結果欄, 那一句）：write 結算
    mine: list[tuple[str, str, str, str]] = dataclasses.field(default_factory=list)   # 轉折算在你身上的（plot.mine）：回合裡結算


def _spot(town: str, short: str, known: set[str]) -> str:
    """子地點的名字。去掉「的」就跟已有的地方一樣（主角家「柳樹屯的老屋」對「柳樹屯老屋」）就加方位，照住家（family.SPOTS）。"""
    near = {k.replace("的", "") for k in known if "的" in k}
    return next((n for n in (f"{town}{s}{short}" for s in family.SPOTS) if n not in near), f"{town}{short}")


def _pool(conn, world_id: str, town: str, npcs: list[dict], locs: list[dict], now: int, skip: set[str],
          first: set[str] = frozenset()) -> tuple[list[dict], dict]:
    """當地能演事端的現成的人（第 4-11-4 題）：住在這個村鎮、有職業的凡人（小孩、修士沒有職業）；你的家人和自家人、隨行的同伴、路線裡的人（skip）、
    已經在進行中的事端裡的不算。first：章那一宮的人，不在這裡、沒職業也算（第 116-7 題）。
    回傳（人, 他們之間的羈絆 {(甲, 乙): {種類}}，連算出來的仇家、友人、恩人）。"""
    every = repos.list_bonds(conn, world_id, everyone=True)
    mine = {b[k] for b in every for k, other in (("a", "b"), ("b", "a")) if b[f"{other}_kind"] == society.PLAYER}
    busy = {n for p in repos.list_plots(conn, world_id) if p["ended_shichen"] is None for n in p["cast"].values()}
    ok = lambda p: (p["realm_lv"] == 0 and p["job"] and not p["hidden_power"] and p["created_by"] != home.FAMILY_BY   # noqa: E731  有職業＝成年凡人
                    and p["name"] not in mine | skip and space.town_of(locs, p["location"]) == town)
    pool = sorted((p for p in npcs if p["status"] == "ALIVE" and p["name"] not in busy and (p["name"] in first or ok(p))), key=lambda p: p["name"])
    bonds = [b for b in every if society.PLAYER not in (b["a_kind"], b["b_kind"])]
    bonds += society.derived(pool, bonds, repos.list_book(conn, "reasons", world_id), repos.list_book(conn, "ledger", world_id),
                             now, repos.list_factions(conn, world_id))
    ties: dict = {}
    for b in bonds:
        for pair in ((b["a"], b["b"]), (b["b"], b["a"])):
            ties.setdefault(pair, set()).add(b["type"])
    return pool, ties


def _home(knots: list[dict], t: dict, npcs: list[dict], locs: list[dict], near: list[dict], parents: dict) -> str:
    """物與地的結（第 7-4a 批）：受害者住的那一處不在主地點、他住的村鎮在範圍裡，就放到那裡（改 parents）。回傳放到的村鎮。"""
    him = next((k["of"] for k in knots if k["kind"] == knot.LAND), "")
    p = next((q for q in npcs if q["name"] == him), None)
    key = next((r[1] for r in t["人物"] if r[0] == plot.VICTIM), "")
    row = next((r for r in t["處"] if r[0] == key), None)
    town = space.town_of(locs, p["location"]) if p else ""
    if not row or plot.at(row) in plot.MAIN or town not in {l["name"] for l in near}:
        return ""
    parents[key] = town
    return town


def place(conn, world_id: str, rng: random.Random, templates: list[dict], town: dict, clock_now: int, make_npc, last: str = "",
          skip: set[str] = frozenset(), boss: str = "", fixed: dict | None = None) -> None:
    """放一條事端：幾處是子地點，角色先找當地現成的人，找不到才生新人（第 126-12 題），留在這裡直到結束（第 8 題）。
    現成的人搬到角色住的那一處、目的不改；新人照角色條件生（職業、性格），跟現成角色的羈絆補一筆原因。skip：主角那邊的人。
    boss：指定的隱瞞者（案中案的下一層，幕後那一方的人，第 5-5-1 題）。town["unit"]：範圍不是村鎮本身那一級時才有（tick）。
    處照「在」放到範圍裡那種地點底下（第 116-9 題）。town["fate"]、town["first"]：一般命的章（game/fated.py），宮裡的人先演。
    fixed：模型寫的天災、戰時事端（domain/newdisasters.py、newwars.py）只放這一條、一放就爆發（時間線從放的那刻算）；一般事端不挑這兩種。"""
    templates = [fixed] if fixed else [t for t in templates if not newdisasters.mine(t) and not newwars.mine(t)]
    land = land_race(conn, world_id, town["name"])
    locs, npcs, conns = repos.list_locations(conn, world_id), repos.list_npcs(conn, world_id), repos.list_connections(conn, world_id)
    known, taken = {l["name"] for l in locs}, {p["name"] for p in npcs}
    had = {p["started_shichen"] for p in repos.list_plots(conn, world_id) if p["town"] == town["name"]}
    later = range(clock_now + 1, clock_now + 12) if fixed else ()   # 天災的前兆可能落在開局那刻（0），往前沒得錯開就往後幾個時辰
    at = next((x for x in [*range(clock_now, -1, -1), *later] if x not in had), None)   # 同一處同一刻已有一條：往前錯開（plot.tag 只看地點和時刻；存檔不許晚於現在）
    if at is None:
        return
    fate, first, knots = town.get("fate", ""), list(town.get("first", ())), town.get("knots", [])
    era_now = (repos.get_era(conn, world_id) or era.DEFAULT)["era"]   # 照時代挑模板和表面（第 8-6 批）
    used = {p["name"] for p in repos.list_plots(conn, world_id)}
    fresh = [t for t in templates if newplots.model(t) and plot.name(t) not in used and not fate and not fixed
             and plot.fits(t, town, land, town.get("unit", ""), era_now)]   # 模型寫的、還沒用過的先用（第 7 題甲）
    pool, ties = _pool(conn, world_id, town["name"], npcs, locs, clock_now, skip, set(first))
    want = {**(town.get("want") or {}), **({n: (plot.KEY_ROLE,) for n in _members(conn, world_id, locs, town["name"]) if n in {p["name"] for p in pool}}
                                           if fresh else {})}   # 隱瞞者先挑那處勢力的成員（第 5 題乙）
    t, got = plot.choose(rng, fresh or templates, town, last, land, pool, ties,
                         unit=town.get("unit", ""), first=set(first), want=want, era_now=era_now)
    if boss and t and any(r[0] == plot.KEY_ROLE for r in t["人物"]):
        got = {**{k: v for k, v in got.items() if v != boss}, plot.KEY_ROLE: boss}
    if not t or max(len(known), len(taken)) >= plot.MAX_NAMES:
        return
    dead = _dead(conn, world_id, rng, town["name"], npcs, locs, taken, land) if newghosts.mine(t) else None
    if newghosts.mine(t) and not dead:
        return
    if dead and dead["kin"]:   # 舊亡魂：死人還活著的家人、立約的人先演受害者（第十節第 5 題丙）
        t, got = plot.choose(rng, [t], town, "", land, pool, ties, unit=town.get("unit", ""), first=set(first),
                             want={**want, **{n: (plot.VICTIM,) for n in dead["kin"]}}, era_now=era_now)
    sky = repos.get_atlas(conn, world_id)
    states = atlas.state_map(sky, conns) if sky else {}
    near = plot.members(locs, conns, sky, plot.scope(t, town), town["name"], states) if any(plot.at(r) not in plot.MAIN for r in t["處"]) else []
    parents = {r[0]: plot.seat(rng, plot.at(r), town["name"], near, states, sky) for r in t["處"]}
    knot_town = _home(knots, t, npcs, locs, near, parents)
    cast = {"村": town["name"], **names.words(land), **plot.faces(rng, t, era_now)}
    cast |= {**{key: _spot(parents[key], plot.fill(short, cast), known) for key, short, *_ in t["處"]}, **got}
    cast |= {newghosts.DEAD: dead["name"]} if dead else {}
    people = []
    for row in t["人物"]:
        role, where = row[0], row[1]
        if role in got:
            continue
        need = dict(plot.wants(row)[0])
        p = newcomer.make(rng, place=town["name"], place_type=town["type"], taken=taken, land=land, town=town,
                          role=need.get("職業", "").split("、")[0])
        if p is None:
            return
        taken.add(p["name"])
        cast[role] = p["name"]
        people.append({**p, **plot.temper(need),
                       "power_tier": npc_mod.MORTAL, "goal": plot.HOME_GOAL, "goal_target": town["name"], "location": cast[where],
                       "profile": "", "speech": ""})
    for row in t["人物"]:
        if row[0] in got and got[row[0]] not in first:   # 宮裡的人不搬
            repos.update_npc(conn, world_id, got[row[0]], {"location": cast[row[1]]})
    for spot in plot.spots(t, town["name"], cast, parents):
        if spot["name"] not in known:
            repos.insert_location(conn, world_id, "", spot)
            repos.insert_connection(conn, world_id, "", {"a": spot["parent"], "b": spot["name"], "tier": space.NEAR,
                                                         "distance_km": space.DISTANCE_TIERS[space.NEAR]})
    people = [make_npc(rng, p, town["scale"], clock_now, plot.BY) for p in people]   # 境界照村鎮的規模算
    for p in people:
        repos.insert_npc(conn, world_id, "", p)
    for p in people:   # 帶家人（121-1）：人都登錄了才取名，不會撞名
        settle_family(conn, world_id, p, town["name"], clock_now)
    if newplots.model(t):
        _sides(conn, world_id, rng, t, town, cast, clock_now, make_npc, taken | {p["name"] for p in people}, land)
        if not _hostage(conn, world_id, rng, t, town["name"], cast, clock_now):
            return
    for row in t["人物"]:   # 「跟某角色:仇家」配到新人：兩邊各記一筆結怨，戲照樣成立（第 4-11-3 題）
        for other, kind in plot.wants(row)[1].items():
            a, b = cast[row[0]], cast[other]
            if not {row[0], other} <= set(got):
                for x, y in ((a, b), (b, a)):
                    repos.insert_book(conn, "reasons", world_id, opinion.reason(x, y, plot.TIE_HITS[kind], clock_now))
    if fate:   # 章的人（第 116-7 題）：宮裡的人演到角色就是他，沒演到就是把你拉進來的人，宮裡沒人看受害者
        role = next((r for r, n in got.items() if n in first), "")
        who = got.get(role) or next(iter(first), "") or cast.get(plot.VICTIM, "")
        cast[plot.CHAPTER] = f"{fate}:{who}:{role or ('' if first else plot.VICTIM)}"
        if knots:
            cast[knot.KNOT] = knot.record(knots, got, knot_town)
    repos.insert_plot(conn, world_id, {"name": plot.name(t), "town": town["name"], "started_shichen": at, "stage": 0,
                                       "ended_shichen": None, "turned_shichen": None, "killed": 0,
                                       "brew_until": plot.brew_until(rng, clock_now), "lit_shichen": at if fixed else None, "cast": cast})
    if dead:   # 舊亡魂：在留處記一筆幽魂（冤魂的執念對著隱瞞者，其他對著受害者）
        on = cast[plot.KEY_ROLE if newghosts.grudge(t) == undead.GRUDGE else plot.VICTIM]
        repos.insert_undead(conn, world_id, "", newghosts.ghost(dead["name"], dead["lv"], dead["died"] if dead["died"] is not None
                                                                else newghosts.died(t, clock_now), cast["留處"], newghosts.grudge(t), on))
    for res, in t.get("放下去", []):   # 模型寫的事端第二批 a：一放就算的（謠言傳開、借刀挑起的恨）
        _settle(conn, world_id, rng, {"id": "", "town": town["name"], "cast": cast}, t, res, plot.fill(t["風聲"][0][0], cast), clock_now)


def _dead(conn, world_id: str, rng: random.Random, town: str, npcs: list[dict], locs: list[dict], taken: set[str], land: str) -> dict | None:
    """舊亡魂的亡者（第十節第 5 題丙）：這個村鎮死了、還沒變亡者、也不在別條亡魂裡、有羈絆或帳的人；沒有就生一個名字
    （凡人，不進 NPC 表，死期照模板的年數）。kin：他還活著的家人、立約的人。名字用完了回 None（不放）。"""
    bonds = repos.list_bonds(conn, world_id, everyone=True)
    used = {u["name"] for u in repos.list_undead(conn, world_id)} | {p["cast"].get(newghosts.DEAD) for p in repos.list_plots(conn, world_id)}
    alive = {p["name"] for p in npcs if p["status"] == "ALIVE"}
    ledger = repos.list_book(conn, "ledger", world_id)
    p = next((p for p in npcs if p["status"] == "FALLEN" and p["name"] not in used and space.town_of(locs, p["location"]) == town
              and undead.knotted(p["name"], ledger, bonds)), None)
    if p:
        kin = {b["a"] if b["b"] == p["name"] else b["b"] for b in bonds
               if p["name"] in (b["a"], b["b"]) and b["type"] in society.BLOOD + society.PACT}
        return {"name": p["name"], "lv": p["realm_lv"], "died": p.get("evolved_shichen") or 0, "kin": sorted(kin & alive)}
    name = names.person_names(rng, taken | used, 1, race=land)
    taken |= set(name)
    return {"name": name[0], "lv": 0, "died": None, "kin": []} if name else None


def _factions(conn, world_id: str, locs: list[dict], town: str) -> list[dict]:
    """那個村鎮還在的勢力（據點在村鎮或它底下）。"""
    return [f for f in repos.list_factions(conn, world_id) if f["location"] and space.town_of(locs, f["location"]) == town
            and not f["traits"].get(lapse.FELL)]


def _members(conn, world_id: str, locs: list[dict], town: str) -> set[str]:
    bonds = repos.list_bonds(conn, world_id, everyone=True)
    return {n for f in _factions(conn, world_id, locs, town) for n in sect.members(bonds, f["name"])}


def _sides(conn, world_id: str, rng: random.Random, t: dict, town: dict, cast: dict, now: int, make_npc, taken: set[str], land: str) -> None:
    """模型寫的事端（第 5 題乙、第 10 題甲、第 11-1 題乙）：隱瞞者（一個行當、一個弟子的受害者）是那處某種勢力的人——還不是就加入；
    那勢力的首領填進旁人（沒有首領就生一個），結果欄算在他身上。推給仇家：仇家是當地另一個人（兩邊各記一筆結怨），沒有就叫外地人。"""
    locs, npcs = repos.list_locations(conn, world_id), repos.list_npcs(conn, world_id)
    alive, taken = {p["name"] for p in npcs if p["status"] == "ALIVE"}, taken | {p["name"] for p in npcs}   # 剛帶進來的家人也算（不然生首領會撞名）
    facs, bonds, done = _factions(conn, world_id, locs, town["name"]), repos.list_bonds(conn, world_id, everyone=True), set()
    by_role = {role: key for key, role in t.get("旁人", [])}
    for role, kinds in t.get("勢力", []):
        mine = [f for f in facs if f["type"] in kinds.split("、") and f["name"] not in done]
        f = next((f for f in mine if cast[role] in sect.members(bonds, f["name"])), None) or (rng.choice(mine) if mine else None)
        if not f:
            continue
        done.add(f["name"])
        if cast[role] not in sect.members(bonds, f["name"]):
            repos.insert_bond(conn, world_id, "", {**sect.member_bond(cast[role], f["name"]), "clock_shichen": now})
        head = next((b["a"] for b in bonds if b["b"] == f["name"] and b["type"] == "首領" and b["a"] in alive), "")
        p = None if head else lapse.head(rng, f, locs, taken, land)
        if p:
            p = make_npc(rng, p, town["scale"], now, plot.BY)
            repos.insert_npc(conn, world_id, "", p)
            repos.insert_bond(conn, world_id, "", {**sect.member_bond(p["name"], f["name"], True), "clock_shichen": now})
            head = p["name"]
            taken.add(head)
        cast |= {"勢力": f["name"]} if role == plot.KEY_ROLE else {}
        cast |= {by_role[role]: head} if head and role in by_role else {}
    if "仇家" in {k for k, _ in t.get("旁人", [])}:
        foes = sorted(p["name"] for p in npcs if p["name"] in alive and p["name"] not in cast.values() and p["realm_lv"] == 0
                      and space.town_of(locs, p["location"]) == town["name"])
        cast["仇家"] = rng.choice(foes) if foes else "外地人"
        for x, y in ((cast["仇家"], cast[plot.KEY_ROLE]), (cast[plot.KEY_ROLE], cast["仇家"])) if foes else ():
            repos.insert_book(conn, "reasons", world_id, opinion.reason(x, y, plot.TIE_HITS["仇家"], now))


def _hostage(conn, world_id: str, rng: random.Random, t: dict, town: str, cast: dict, now: int) -> bool:
    """綁架（第二批 b 第 3 題甲）：人質＝受害者還活著的親人、伴侶；沒有就照 121-1 帶家人生，最多擲 10 次。挑不到回傳 False（不放）。"""
    if plot.HOSTAGE not in {k for k, _ in t.get("旁人", [])}:
        return True
    victim = cast[plot.VICTIM]
    for _ in range(10):
        npcs = repos.list_npcs(conn, world_id)
        alive = {p["name"] for p in npcs if p["status"] == "ALIVE"} - set(cast.values())
        kin = sorted({b["a"] if b["b"] == victim else b["b"] for b in repos.list_bonds(conn, world_id, everyone=True)
                      if victim in (b["a"], b["b"]) and b["type"] in plot.KIN} & alive)
        if kin:
            cast[plot.HOSTAGE] = rng.choice(kin)
            return True
        settle_family(conn, world_id, next(p for p in npcs if p["name"] == victim), town, now, rng=rng)
    return False


def ensure(conn, world_id: str, rng: random.Random, templates: list[dict], born: str, clock_now: int, make_npc) -> None:
    """出生地附近沒有事端，就在最近的村鎮放一條（16v 第 66 題）：玩家會先在出生地找事做。"""
    near = [born, *(n["name"] for n in space.neighbors(repos.list_connections(conn, world_id), born))]
    if any(p["town"] in near and p["ended_shichen"] is None for p in repos.list_plots(conn, world_id)):
        return
    towns = {l["name"]: l for l in repos.list_locations(conn, world_id) if l["type"] in home.RENT_TYPES}
    town = next((towns[n] for n in near if n in towns), None)
    if town:
        place(conn, world_id, rng, templates, town, clock_now, make_npc)


def current(rows: dict, templates: list[dict], here: str) -> tuple[dict, dict] | None:
    """這個村鎮進行中的事端：（事端, 模板）。這裡是哪條事端的一處先算那條（範圍事端的處放在別的村鎮底下，第 116-9 題）；你的章先算。"""
    town = space.town_of(rows["locations"], here)
    by_name = {plot.name(t): t for t in templates}
    live = [(rec, by_name[rec["name"]]) for rec in rows["plots"] if rec["ended_shichen"] is None and rec["name"] in by_name]
    live.sort(key=lambda x: plot.CHAPTER not in x[0]["cast"])   # 你的章跟別條在同一處：先算章
    return next((x for x in live if here in {x[0]["cast"].get(r[0]) for r in x[1]["處"]}), None) \
        or next((x for x in live if x[0]["town"] == town), None)


def gap(rows: dict, rec: dict, t: dict, sheet: dict) -> int:
    """這條事端的範圍比你境界的範圍高幾級（route.gap，第 116-3 題）。"""
    town = next((l for l in rows["locations"] if l["name"] == rec["town"]), {"scale": ""})
    return route.gap(plot.scope(t, town), sheet.get("realm_lv", 0))


def high(rows: dict, live: tuple[dict, dict], sheet: dict) -> str:
    """境界不到這條的範圍：回傳範圍，到了是空的（第 116-11 題）。"""
    return plot.scope(live[1], next((l for l in rows["locations"] if l["name"] == live[0]["town"]), {"scale": ""})) \
        if gap(rows, *live, sheet) > 0 else ""


def case(rows: dict, templates: list[dict], key: str) -> tuple[dict | None, dict | None]:
    """路線的 key 找事端：（事端, 模板）。"""
    rec = next((p for p in rows["plots"] if plot.tag(p) == key), None)
    return rec, next((t for t in templates if rec and plot.name(t) == rec["name"]), None)


def rush(out: Tick, rec: dict, t: dict, hours: int) -> None:
    """暗線：時間線起點往前移（16v 第 35 題）。"""
    field = "lit_shichen" if rec["turned_shichen"] is None else "turned_shichen"
    was = next((c for c in out.changes if c[0]["id"] == rec["id"]), (rec, t, None))
    out.changes = [c for c in out.changes if c[0]["id"] != rec["id"]] + [({**was[0], field: rec[field] - hours}, t, was[2])]


def _noted(sheet: dict, rec: dict, note: dict, now: int) -> dict:
    """記下線索或轉折，看要不要接下這條路線（16v 第 5 題）。"""
    sheet = {**sheet, "clues": [*sheet["clues"], note]}
    return route.clue(sheet, rec["name"], plot.tag(rec), len(plot.found(sheet, rec)), rec["town"], now)


def gone(rows: dict) -> set[str]:
    return {p["name"] for p in rows["npcs"] if p["status"] != "ALIVE"}


def search(rows: dict, templates: list[dict], sheet: dict, here: str, who: str, verdict, now: int,
           skip: set[str] = frozenset()) -> tuple[dict, list[str]]:
    """這回合有沒有查到線索：回傳（角色卡, 事實）。skip：暗線擋住的線索（第 5-3 批）。"""
    live = current(rows, templates, here)
    clue = plot.search(*live, sheet, here, who, verdict, gone(rows), skip, bool(high(rows, live, sheet))) if live else None
    if not clue:
        return sheet, []
    held = "（這件東西現在在主角手上）" if clue["kind"] == plot.EVIDENCE else ""
    return _noted(sheet, live[0], clue, now), [f"主角查到了：{clue['text']}{held}"]


def turning_point(rows: dict, templates: list[dict], sheet: dict, here: str, who: str, verdict, text: str, out: Tick,
                  now: int) -> tuple[dict, list[str]]:
    """第 5 題：玩家做到了就觸發。回傳（角色卡, 事實）；收場的事端記進 out，交易裡寫入。"""
    live = current(rows, templates, here)
    row = plot.point(*live, sheet, here, who, verdict, text, bool(high(rows, live, sheet))) if live else None
    if not row:
        return sheet, []
    rec, t = live
    key, *_, fact, trace, res = row
    done = fill_note(rec, key, fact)
    if trace:
        out.changes = [c for c in out.changes if c[0]["id"] != rec["id"]] + [({**rec, "trace": trace}, t, now)]
    out.results.append((rec, t, res, done["text"]))
    out.mine += [e for e in plot.effects(rec, t, res) if plot.mine(e) or e[2:] == (newghosts.RESULT, "安息")]   # 安息的感悟算在你身上
    return _noted(sheet, rec, done, now), [done["text"]]


def fill_note(rec: dict, key: str, fact: str) -> dict:
    return {"plot": plot.tag(rec), "key": key, "kind": plot.POINT, "text": plot.fill(fact, rec["cast"])}


def offer(rows: dict, templates: list[dict], sheet: dict, here: str, who: str) -> str:
    live = current(rows, templates, here)
    return plot.offer(*live, sheet, here, who, bool(high(rows, live, sheet))) if live else ""


def hush(choices: list[str], tags: list[dict], rows: dict, templates: list[dict], sheet: dict, here: str,
         who: str) -> tuple[list[str], list[dict]]:
    """背景的事端：拿掉提到它的人名、地名的選項（16v 第 5 題；提示管不住模型）。玩家自己找上那個人時不管。"""
    live = current(rows, templates, here)
    if not live or not route.busy(sheet, plot.tag(live[0])):
        return choices, tags
    words = plot.names_of(*live)
    keep = [(c, t) for c, t in zip(choices, tags) if not any(w in c for w in words)]
    return ([c for c, _ in keep], [t for _, t in keep]) if keep and who not in words else (choices, tags)


def small(rows: dict, templates: list[dict], sheet: dict, here: str, rng: random.Random) -> list[str]:
    """第 6 題：待在有事端的地方，偶爾發生一件和它有關的小事。背景的事端只有風聲（16v 第 5 題）。"""
    live = current(rows, templates, here)
    if not live or route.busy(sheet, plot.tag(live[0])) or rng.random() >= plot.SMALL_CHANCE:
        return []
    return [plot.fill(rng.choice(live[1]["小事"])[0], live[0]["cast"])]


def person_note(rows: dict, templates: list[dict], sheet: dict, here: str, who: str) -> str:
    live = current(rows, templates, here)
    return plot.person_note(*live, sheet, who, high(rows, live, sheet)) if live else ""


def scene_note(rows: dict, templates: list[dict], sheet: dict, here: str) -> str:
    live = current(rows, templates, here)
    return plot.scene_note(*live, sheet) if live else ""


def _step(rec: dict, t: dict, now: int, town: str, killed: set[str], dead: set[str], sheet: dict) -> tuple[dict, list[str], int | None, list]:
    """一條事端走到 now：回傳（改過的事端, 這次發生的事, 結束的時候, [(結果欄, 那一句)]）。
    關鍵人物死了先轉向（第 9 題）；還在醞釀時，玩家走進來就爆發，到期沒人來就走到結局（第 11 題）。
    手上有別條路線，走進來不點燃（16v 第 5 題）。"""
    lines = []
    row = plot.turning(t, rec, dead)
    if row:
        rec, fact = plot.turn(rec, row, killed, now)
        lines.append(fact)
    if plot.brewing(rec):
        if rec["town"] != town or route.busy(sheet, plot.tag(rec)):
            due = now >= rec["brew_until"]   # 醞釀到期：放著到結局，結局的結果照算
            return rec, [], rec["brew_until"] if due else None, [(plot.ending(t)[3], plot.result(rec, t))] if due else []
        rec = {**rec, "lit_shichen": min(now, rec["brew_until"])}   # 閉關、趕路時早過了醞釀期：事情照期滿那時走
    stage, steps, ended = plot.advance(rec, t, now)
    ended = ended or plot.heir_dead(t, {**rec, "stage": stage}, dead)
    res = list(zip(plot.outcomes(rec, t, stage, ended), steps + [plot.result(rec, t)]))
    rec, lines = {**rec, "stage": stage}, lines + steps + ([plot.result(rec, t)] if ended else [])
    return rec, lines, (now if plot.heir_dead(t, rec, dead) else plot.end_time(rec, t)) if ended else None, res


def tick(rows: dict, templates: list[dict], here: str, now: int, killed: set[str] = frozenset(), sheet: dict | None = None) -> Tick:
    """走到 now：事端往前走；結束夠久的範圍單位、這裡所屬還沒放過的範圍單位要放新的（一個單位同時一條，第 116-4 題）。
    killed：這回合死在玩家手上的人。sheet：看手上的路線。"""
    out = Tick()
    if not templates:
        return out
    by_name = {plot.name(t): t for t in templates}
    town = space.town_of(rows["locations"], here)
    dead = {p["name"] for p in rows["npcs"] if p["status"] != "ALIVE"} | set(killed)
    places = {l["name"]: l for l in rows["locations"]}
    latest: dict[tuple[str, str], dict] = {}
    for rec in rows["plots"]:
        p = places.get(rec["town"], {"scale": ""})
        t = by_name.get(rec["name"])
        if plot.CHAPTER not in rec["cast"] and not newdisasters.mine(t or {}) and not newwars.mine(t or {}):   # 章、天災、戰時事端不佔名額（第 116-5 題）
            latest[(plot.scope(t, p) if t else p["scale"], rec["town"])] = rec
        if t and rec["ended_shichen"] is None and newwars.over(t, rows.get("atlas")):   # 議和：還沒收尾的照放著收（第十一節第 5 題甲）
            f = "lit_shichen" if rec["turned_shichen"] is None else "turned_shichen"
            rec = {**rec, f: min(now if rec[f] is None else rec[f], now - newwars.LASTS)}
        if t and rec["ended_shichen"] is None:
            changed, lines, ended, res = _step(rec, t, now, town, set(killed), dead, sheet or {})
            if changed != rec or ended is not None:
                out.changes.append((changed, t, ended))
            out.results += [(changed, t, r, line) for r, line in res if r]
            out.news += lines if rec["town"] == town else []
    unit = lambda u, name: places[name] if u == places[name]["scale"] else {**places[name], "unit": u}
    for (u, name), rec in latest.items():
        if rec["ended_shichen"] is not None and now - rec["ended_shichen"] >= plot.REST and name in places:
            out.towns.append((unit(u, name), rec["name"]))
    for u, name in plot.units(rows["locations"], rows.get("connections", []), rows.get("atlas"), here).items():
        if (u, name) not in latest and any(plot.fits(t, places[name], local_race(rows, name), u, (rows.get("era") or era.DEFAULT)["era"])
                                           for t in templates):
            out.towns.append((unit(u, name), ""))
    return out


OWED = {"救命之恩": favour.LIFE, "人情:救命": favour.LIFE, "人情:大": favour.BIG, "人情:小": favour.SMALL, "欠情": favour.SMALL}


def pay(rows: dict, out: Tick, sheet: dict, npc_changes: dict, why: str, rng: random.Random, now: int) -> tuple[dict, list[str]]:
    """轉折算在你身上的（第 4-11-7 題）：他對你的好感、他欠你的帳、你的財。回傳（角色卡, 事件）。"""
    events = []
    for who, _, kind, value in out.mine:
        p = people.find(rows, who) if who else None
        if kind == newghosts.RESULT:   # 讓舊亡魂安息：照幽魂安息拿感悟（game/haunts.settle）
            if sheet["realm_lv"] >= 1:
                insight, reached = laws.reward(sheet, undead.REST_LAW, round(undead.REST_INSIGHT * origins.rest(sheet)))
                sheet, events = {**sheet, "insight": insight}, events + reached
        elif kind == "財":
            o = incidents.pay(value, sheet, rows, rng)
            sheet, events = o.sheet, events + o.events
        elif kind == "帳":
            events += favours.give(rows, npc_changes, who, favour.OWED, OWED[value], why, now)
        elif p and p["status"] == "ALIVE":
            rel, said = npc_mod.shift(who, people.changed_relation(rows, npc_changes, who), [opinion.mood(*value.split(":"))])
            npc_changes.setdefault(who, {})["relation"] = rel
            events += said
    return sheet, events


def _settle(conn, world_id: str, rng: random.Random, rec: dict, t: dict, res: str, line: str, now: int) -> None:
    """結果欄裡不算在你身上的（第 126-13、4-11-6～4-11-16 題）：角色之間的好感、法、地、聞、知情。
    你的好感、帳、財在回合裡結算（service 讀 Tick.mine）；舊聞等 125-6 再接。"""
    town, locs = rec["town"], repos.list_locations(conn, world_id)
    for who, toward, kind, value in plot.effects(rec, t, res):
        if plot.mine((who, toward, kind, value)):
            continue
        if kind == "好感":
            repos.insert_book(conn, "reasons", world_id, opinion.reason(who, toward, opinion.mood(*value.split(":")), now))
        elif kind == plot.LAW:
            where = _jail(conn, world_id, rec, locs) if value == plot.JAIL else _exile(conn, world_id, town, locs, rng)
            repos.update_npc(conn, world_id, who, {"location": where, **({"job": ""} if value == plot.JAIL else {})})   # 關著的沒有職業，不再演事端
        elif kind == "地" and value in (plot.LOCK, plot.BACK):   # 第二批 b：人質關進藏處、救回苦主家
            repos.update_npc(conn, world_id, who, {"location": rec["cast"][plot.STASH if value == plot.LOCK else plot.HOME]})
        elif kind == plot.DIE:   # 撕票：同村鎮小事死人（game/local.py）；一定變幽魂、恩怨對著隱瞞者（第十節第 4 題乙）
            repos.update_npc(conn, world_id, who, {"status": "FALLEN", "condition": npc_mod.CONDITIONS[-1]})
            p = next((p for p in repos.list_npcs(conn, world_id) if p["name"] == who), None)
            if p and p["location"] not in {u["place"] for u in repos.list_undead(conn, world_id) if u["condition"] != undead.GONE}:
                repos.insert_undead(conn, world_id, "", newghosts.ghost(who, p["realm_lv"], now, p["location"], undead.GRUDGE,
                                                                         rec["cast"][plot.KEY_ROLE]))
        elif kind == "地" and value == side.GONE:
            repos.update_npc(conn, world_id, who, {"location": society.AWAY, "away_since": now})
        elif kind == "地":
            repos.set_pressure(conn, world_id, pressure.apply(repos.get_pressure(conn, world_id), town, [value.split(":", 1)[1]], now))
        elif kind == "勢" and value == "衰" and rec["cast"].get("勢力"):   # 天災：揭穿壓消息的人，他的勢力聲勢降一格
            repos.set_pressure(conn, world_id, pressure.apply(repos.get_pressure(conn, world_id), rec["cast"]["勢力"], ["聲勢-1"], now))   # 同 game/factions.KEY
        elif kind == "災" and value == "短":   # 天災的轉機：這場天災剩下的時間減半
            name, start, where = newdisasters.key_of(t).split("@")
            s = next((s for s in repos.list_place_states(conn, world_id)
                      if (s["place"], s["name"], s["started_shichen"]) == (where, name, int(start))), None)
            if s and s["ends_shichen"] > now:
                repos.cut_place_state(conn, world_id, where, name, int(start), now + (s["ends_shichen"] - now) // 2)
        elif kind == newghosts.RESULT:   # 舊亡魂：安息、散＝亡者那筆消散；怒＝作祟（幽魂變屍變，現身就撲人）
            u = next((u for u in repos.list_undead(conn, world_id) if u["name"] == rec["cast"].get(newghosts.DEAD)
                      and u["condition"] != undead.GONE), None)
            if u and value == "怒":
                repos.update_undead(conn, u["id"], u["condition"], u["awake"], undead.CORPSE)
            elif u:
                repos.update_undead(conn, u["id"], undead.GONE, False)
        elif kind == plot.NEWS and value == plot.SPREAD:
            repos.insert_rumor(conn, world_id, rumors.make(rumors.AFTERMATH, who or town, place=town, when=now, detail=f"{town}：{line}"[:40]))
        elif kind == plot.NEWS and value == plot.CHAT:
            repos.insert_rumor(conn, world_id, rumors.make(rumors.CHAT, town, place=town, when=now, detail=line[:40]))
        elif kind == plot.RUMOR:   # 第二批第 3 題乙：那個村鎮的人聽信謠言，各記一筆小的（認識＝住在同一個村鎮）
            victim, cast = rec["cast"][plot.VICTIM], set(rec["cast"].values())
            for p in repos.list_npcs(conn, world_id):
                if p["status"] == "ALIVE" and p["name"] not in cast and space.town_of(locs, p["location"]) == town:
                    repos.insert_book(conn, "reasons", world_id, opinion.reason(p["name"], victim, opinion.mood(opinion.RUMOR, opinion.SMALL), now))
        elif kind == plot.DROP:   # 揭開了：撤掉受害者那頭這種原因（聽信的謠言、被挑起的恨；同嫁禍識破）
            victim = rec["cast"][plot.VICTIM]
            ids = [r["id"] for r in repos.list_book(conn, "reasons", world_id) if r["kind"] == value and victim in (r["holder"], r["toward"])]
            if ids:
                repos.drop_reasons(conn, ids)
        elif kind == plot.KNOW:
            e = repos.insert_book(conn, "events", world_id, {   # 一條事端一件真相（同一個 id 只留第一筆）
                "id": f"evt_{rec['id']}", "session_id": "", "kind": plot.TRUTH, "actor": rec["cast"][plot.KEY_ROLE], "target": "",
                "place": town, "detail": {"text": plot.truth(t, rec["cast"])}, "secret": 1, "era": "",
                "clock_shichen": now, "turn_no": 0})
            repos.insert_book(conn, "knows", world_id, hearsay.know(e, who or opinion.ME, now))


def _jail(conn, world_id: str, rec: dict, locs: list[dict]) -> str:
    """事端的牢房那一處；沒有就在這個村鎮多開一處（第 4-11-15 題）。"""
    known = {l["name"] for l in locs}
    return background.jail(conn, world_id, rec["town"], rec["cast"].get(plot.JAIL_SPOT) or _spot(rec["town"], plot.JAIL_SPOT, known), known)


def _exile(conn, world_id: str, town: str, locs: list[dict], rng: random.Random) -> str:
    """流放：別國一個現成的村鎮（第 4-11-10 題）；只有一國的舊世界去遠方。"""
    sky = repos.get_atlas(conn, world_id)
    if not sky:
        return society.AWAY
    states, nation = atlas.state_map(sky, repos.list_connections(conn, world_id)), {s["name"]: s["nation"] for s in sky["states"]}
    of = lambda name: nation.get(states.get(name, sky["start"]))
    far = sorted(l["name"] for l in locs if l["type"] in home.RENT_TYPES and of(l["name"]) != of(town))
    return rng.choice(far) if far else society.AWAY


def mine(sheet: dict) -> set[str]:
    """主角那邊的人：隨行的同伴、路線裡的人，不拿來演事端（第 4-11-4 題）。"""
    return party.names(sheet) | set((sheet["route"] or {}).get("cast", {}).values())


def write(conn, world_id: str, out: Tick, rng: random.Random, templates: list[dict], now: int, make_npc,
          skip: set[str] = frozenset()) -> None:
    for rec, t, ended in out.changes:   # 結束的時候可能比 now 早：玩家閉關時早就結束了
        repos.update_plot(conn, {**rec, "ended_shichen": ended})
        for where in _range(conn, world_id, rec, t) if ended is not None else ():
            repos.insert_place_state(conn, world_id, plot.trace_state(rec, t, ended, where))
    for rec, t, res, line in out.results:
        _settle(conn, world_id, rng, rec, t, res, line, now)
    for town, last in out.towns:   # 同一處同一刻放兩條（不同範圍、你的章）：place 往前錯開一個時辰
        place(conn, world_id, rng, templates, town, now, make_npc, last, skip, out.boss.get(town["name"], ""))


def _range(conn, world_id: str, rec: dict, t: dict) -> list[str]:
    """痕跡留在哪（第 116-2 題）：模板寫了範圍的留在範圍裡每個村鎮，沒寫的只留在主地點。"""
    if not plot.ranged(t):
        return [rec["town"]]
    locs, conns, sky = repos.list_locations(conn, world_id), repos.list_connections(conn, world_id), repos.get_atlas(conn, world_id)
    town = next((l for l in locs if l["name"] == rec["town"]), None)
    near = plot.members(locs, conns, sky, plot.scope(t, town), rec["town"]) if town else []
    return [rec["town"], *(l["name"] for l in near if l["type"] in home.RENT_TYPES and l["name"] != rec["town"])]
