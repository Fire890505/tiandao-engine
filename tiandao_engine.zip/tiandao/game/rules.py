"""外部規則檔載入。

資料夾結構沿用舊專案 rules.py::_GENRE_DIRS 的 24 個分類。
第一階段只把 cultivation 分類放進提示詞（上限 MAX_PROMPT_CHARS），其他分類
在移植對應功能時再接上。規則檔缺失不會讓伺服器停止，但會在 /api/health 回報。
"""
from __future__ import annotations

from pathlib import Path

from ..domain import deck, plot

GENRE_DIRS = (
    "cultivation", "tomb", "magic", "mythology", "fate", "spirits", "settlements", "ecology",
    "sects", "advanced", "legacy", "battlefield", "spirit-fields", "market", "realm-endgame",
    "commission", "escort", "pawn", "urgent-quests", "mortal-truth", "companion",
    "heaven-counter", "near-death", "law-trial",
)
PROMPT_GENRES = ("cultivation",)
MAX_PROMPT_CHARS = 4000


def _table(path: Path, fields: tuple[str, ...]) -> list[dict]:
    """「｜」分隔的 TXT：一行一筆，# 開頭是註解。檔案不在就是空的。"""
    lines = path.read_text(encoding="utf-8").splitlines() if path.is_file() else []
    return [dict(zip(fields, line.split("｜"))) for line in lines if line.strip() and not line.startswith("#")]


def _plots(folder: Path) -> list[dict]:
    """事端模板（16t）：一條一檔，「欄位｜內容｜內容」一行一列。回傳 {欄位: [[內容, 內容], ...]}。"""
    return [plot.parse(path.read_text(encoding="utf-8")) for path in sorted(folder.glob("*.txt"))] if folder.is_dir() else []


class RuleBook:
    def __init__(self, root: Path):
        self.root = root
        self.texts: dict[str, list[str]] = {}
        for genre in GENRE_DIRS:
            folder = root / genre
            files = sorted(folder.glob("*.txt")) if folder.is_dir() else []
            self.texts[genre] = [f.read_text(encoding="utf-8").strip() for f in files]
        self.items = _table(root / "content" / "items.txt", ("name", "base", "description"))   # 16p 第 11 題
        found = root / "content" / "encounters.txt"   # 第 4-2 題：有底的那幾行是換句話說
        self.events = [{"name": c.name, "base": c.more[-1], "scene": c.text}
                       for c in (deck.read(found) if found.is_file() else ()) if c.more[-1]]
        self.plots = _plots(root / "content" / "plots")

    def status(self) -> dict:
        missing = [g for g in GENRE_DIRS if not (self.root / g).is_dir()]
        empty = [g for g in GENRE_DIRS if g not in missing and not self.texts[g]]
        return {"genres": len(GENRE_DIRS), "missingDirs": missing, "emptyDirs": empty}

    def prompt_text(self) -> str:
        parts = [t for g in PROMPT_GENRES for t in self.texts.get(g, []) if t]
        return "\n\n".join(parts)[:MAX_PROMPT_CHARS]
