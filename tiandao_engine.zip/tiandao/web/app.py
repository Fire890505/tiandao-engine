"""HTTP 應用層（與 http.server 解耦，方便直接測試）。

權限在路由表上宣告，由 dispatch() 統一執行，個別 handler 不需要、也不應該自己檢查：
  PUBLIC  不需登入
  USER    需要有效 token
  SESSION 需要有效 token，且 URL 中的 {sid} 必須屬於這個使用者（否則 404）
對應舊專案稽核 B-01、B-05、F-01：權限散落在每條路由各自判斷，漏一條就是漏洞。
tests/test_http.py 會逐條確認所有非 PUBLIC 路由在沒有 token 時都回 401。
"""
from __future__ import annotations

import json
import logging
import mimetypes
import re
import traceback
from dataclasses import dataclass
from typing import Callable
from urllib.parse import parse_qs, urlsplit

from ..ai.narrators import build_narrator
from ..config import Settings
from ..errors import AppError, BadRequest, MethodNotAllowed, NotFound
from ..game import auth
from ..game.rules import RuleBook
from ..game.service import GameService
from ..store import repos
from ..store.db import connect, migrate

log = logging.getLogger(__name__)
PUBLIC, USER, SESSION = "public", "user", "session"


@dataclass
class Request:
    method: str
    path: str
    query: dict
    headers: dict
    body: dict
    params: dict
    conn: object = None
    user_id: str = ""


@dataclass(frozen=True)
class Route:
    method: str
    pattern: str
    access: str
    handler: Callable

    @property
    def regex(self) -> re.Pattern:
        return re.compile("^" + re.sub(r"\{(\w+)\}", r"(?P<\1>[A-Za-z0-9_\\-]+)", self.pattern) + "$")


class App:
    def __init__(self, settings: Settings, narrator=None):
        self.settings = settings
        self.schema_version = migrate(settings.db_path)
        self.rulebook = RuleBook(settings.rules_dir)
        self.narrator = narrator or build_narrator(settings)
        self.game = GameService(self.narrator, self.rulebook)
        self.game.acts = settings.acts
        g = self.game
        self.routes: list[Route] = [
            Route("GET", "/api/health", PUBLIC, self._health),
            Route("POST", "/api/auth/register", PUBLIC,
                  lambda r: (201, auth.register(r.conn, r.body.get("username"), r.body.get("password")))),
            Route("POST", "/api/auth/login", PUBLIC,
                  lambda r: auth.login(r.conn, r.body.get("username"), r.body.get("password"),
                                       self.settings.token_ttl_hours)),
            Route("POST", "/api/auth/logout", USER,
                  lambda r: (auth.logout(r.conn, r.headers.get("authorization")), {"ok": True})[1]),
            Route("GET", "/api/me", USER, self._me),
            Route("GET", "/api/worlds", USER, lambda r: {"worlds": g.list_worlds(r.conn, r.user_id)}),
            Route("GET", "/api/sessions", USER, lambda r: {"sessions": g.list_sessions(r.conn, r.user_id)}),
            Route("POST", "/api/sessions", USER,
                  lambda r: (201, g.create_session(r.conn, r.user_id, r.body.get("title", ""),
                                                   world_id=r.body.get("worldId") or None, span=r.body.get("span"),
                                                   world_name=r.body.get("worldName"),
                                                   start_era=r.body.get("era")))),
            Route("GET", "/api/sessions/{sid}", SESSION, lambda r: g.get_state(r.conn, r.user_id, r.params["sid"])),
            Route("POST", "/api/sessions/{sid}/character", SESSION,
                  lambda r: g.create_character(r.conn, r.user_id, r.params["sid"], r.body)),
            Route("GET", "/api/look", USER, lambda r: g.look_card(r.query)),
            Route("POST", "/api/sessions/{sid}/appearance", SESSION,
                  lambda r: g.edit_appearance(r.conn, r.user_id, r.params["sid"], r.body)),
            Route("POST", "/api/sessions/{sid}/alias", SESSION,   # 化名（身分與追捕）
                  lambda r: g.set_alias(r.conn, r.user_id, r.params["sid"], r.body)),
            Route("POST", "/api/sessions/{sid}/opening", SESSION,
                  lambda r: g.opening(r.conn, r.user_id, r.params["sid"], r.body)),
            Route("POST", "/api/sessions/{sid}/turns", SESSION,
                  lambda r: g.play_turn(r.conn, r.user_id, r.params["sid"], r.body)),
            Route("POST", "/api/sessions/{sid}/retire", SESSION,
                  lambda r: g.retire(r.conn, r.user_id, r.params["sid"], r.body)),
            Route("POST", "/api/sessions/{sid}/items", SESSION,
                  lambda r: g.use_items(r.conn, r.user_id, r.params["sid"], r.body)),
            Route("GET", "/api/sessions/{sid}/export", SESSION,
                  lambda r: g.export_save(r.conn, r.user_id, r.params["sid"])),
            Route("POST", "/api/saves/import", USER, lambda r: (201, g.import_save(r.conn, r.user_id, r.body))),
        ]

    # ── 對外入口 ──────────────────────────────────────────────────────────
    def dispatch(self, method: str, raw_path: str, headers: dict, raw_body: bytes) -> tuple[int, dict, bytes]:
        parts = urlsplit(raw_path)
        path = parts.path
        headers = {k.lower(): v for k, v in headers.items()}
        try:
            if not path.startswith("/api/"):
                if method != "GET":
                    raise NotFound("找不到這個頁面。")
                return self._static(path)
            route, params = self._match(method, path)
            body = self._parse_body(raw_body) if method == "POST" else {}
            req = Request(method, path, {k: v[-1] for k, v in parse_qs(parts.query).items()},
                          headers, body, params)
            conn = connect(self.settings.db_path)
            try:
                req.conn = conn
                if route.access in (USER, SESSION):
                    req.user_id = auth.resolve(conn, headers.get("authorization"))
                if route.access == SESSION:
                    self.game.require_session(conn, req.user_id, params["sid"])
                result = route.handler(req)
            finally:
                conn.close()
            status, payload = result if isinstance(result, tuple) else (200, result)
            return self._json(status, payload)
        except AppError as exc:
            return self._json(exc.status, {"error": {"code": exc.code, "message": exc.message, **exc.details}})
        except Exception:  # 程式錯誤：完整記錄後回 500，不吞掉、不降級
            log.error("未預期的錯誤：%s %s\n%s", method, path, traceback.format_exc())
            if self.settings.debug:
                raise
            return self._json(500, {"error": {"code": "internal", "message": "伺服器內部錯誤，請查看伺服器紀錄。"}})

    # ── 內部 ──────────────────────────────────────────────────────────────
    def _match(self, method: str, path: str) -> tuple[Route, dict]:
        allowed = False
        for route in self.routes:
            m = route.regex.match(path)
            if m:
                if route.method == method:
                    return route, m.groupdict()
                allowed = True
        if allowed:
            raise MethodNotAllowed("這個網址不支援此請求方法。")
        raise NotFound("找不到這個 API。", code="no_route")

    def _parse_body(self, raw: bytes) -> dict:
        if len(raw) > self.settings.max_body_bytes:
            raise BadRequest("請求內容太大。", code="body_too_large")
        if not raw:
            return {}
        try:
            data = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            raise BadRequest("請求內容不是合法的 JSON。", code="invalid_json") from None
        if not isinstance(data, dict):
            raise BadRequest("請求內容必須是 JSON 物件。", code="invalid_json")
        return data

    def _health(self, r: Request) -> dict:
        return {"ok": True, "schemaVersion": self.schema_version,
                "narrator": self.narrator.name, "rules": self.rulebook.status()}

    def _me(self, r: Request) -> dict:
        user = repos.get_user(r.conn, r.user_id)
        return {"id": user["id"], "username": user["username"]}

    def _static(self, path: str) -> tuple[int, dict, bytes]:
        root = self.settings.frontend_dir.resolve()
        rel = "index.html" if path in ("", "/") else path.lstrip("/")
        target = (root / rel).resolve()
        if not target.is_relative_to(root) or not target.is_file():
            raise NotFound("找不到這個頁面。")
        ctype = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
        if ctype.startswith("text/") or ctype in ("application/javascript",):
            ctype += "; charset=utf-8"
        return 200, {"Content-Type": ctype, "Cache-Control": "no-store"}, target.read_bytes()

    @staticmethod
    def _json(status: int, payload) -> tuple[int, dict, bytes]:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        return status, {"Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store"}, body
