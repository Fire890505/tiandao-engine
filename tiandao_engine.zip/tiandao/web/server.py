"""http.server 轉接層：只負責收送位元組，所有邏輯在 App.dispatch。"""
from __future__ import annotations

import logging
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from .app import App

log = logging.getLogger(__name__)


def make_server(app: App, host: str, port: int) -> ThreadingHTTPServer:
    class Handler(BaseHTTPRequestHandler):
        server_version = "Tiandao/0.1"

        def _handle(self, method: str) -> None:
            length = int(self.headers.get("Content-Length") or 0)
            if length > app.settings.max_body_bytes:
                self._send(*app._json(400, {"error": {"code": "body_too_large", "message": "請求內容太大。"}}))
                return
            raw = self.rfile.read(length) if length else b""
            self._send(*app.dispatch(method, self.path, dict(self.headers.items()), raw))

        def _send(self, status: int, headers: dict, body: bytes) -> None:
            self.send_response(status)
            for key, value in headers.items():
                self.send_header(key, value)
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):  # noqa: N802
            self._handle("GET")

        def do_POST(self):  # noqa: N802
            self._handle("POST")

        def log_message(self, fmt, *args):
            log.info("%s %s", self.address_string(), fmt % args)

    return ThreadingHTTPServer((host, port), Handler)
