"""執行期設定。所有可調參數集中在這裡，其他模組只讀 Settings，不讀環境變數。"""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent


@dataclass(frozen=True)
class Settings:
    db_path: Path = PROJECT_ROOT / "data" / "tiandao.db"
    host: str = "127.0.0.1"
    port: int = 8790
    frontend_dir: Path = PROJECT_ROOT / "frontend"
    rules_dir: Path = PROJECT_ROOT / "rules"
    # AI：backend 只能是 "ollama" 或 "mock"。mock 必須明確指定，不會在 Ollama 失敗時自動退回。
    ai_backend: str = "ollama"
    ollama_url: str = "http://127.0.0.1:11434"
    narrator_model: str = "yi:34b-chat"
    ai_timeout_seconds: float = 300.0
    token_ttl_hours: int = 24 * 14
    max_body_bytes: int = 4 * 1024 * 1024
    debug: bool = False
    acts: bool = False   # 合成提案（第 2-4b 批）：TIANDAO_ACTS=1 開

    @classmethod
    def from_env(cls, **overrides) -> "Settings":
        env = os.environ
        values = {
            "db_path": Path(env["TIANDAO_DB"]) if "TIANDAO_DB" in env else cls.db_path,
            "ai_backend": env.get("TIANDAO_AI", cls.ai_backend),
            "ollama_url": env.get("TIANDAO_OLLAMA_URL", cls.ollama_url),
            "narrator_model": env.get("TIANDAO_NARRATOR_MODEL", cls.narrator_model),
            "debug": env.get("TIANDAO_DEBUG") == "1",
            "acts": env.get("TIANDAO_ACTS") == "1",
        }
        values.update({k: v for k, v in overrides.items() if v is not None})
        if values["ai_backend"] not in ("ollama", "mock"):
            raise ValueError(f"TIANDAO_AI 只能是 ollama 或 mock，收到 {values['ai_backend']!r}")
        return cls(**values)
